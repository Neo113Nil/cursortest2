package com.civis.melbet.galba.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.civis.melbet.galba.R;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import defpackage.fv;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class ActivityMain2Binding {
    public final TextView bannerAward;
    public final View bar0;
    public final View bar1;
    public final View bar2;
    public final View bar3;
    public final View bar4;
    public final View bar5;
    public final View bar6;
    public final LinearLayout bottomBar;
    public final TextView buttonCancel;
    public final TextView buttonDelete;
    public final TextView buttonEmptyAdd;
    public final TextView buttonSave;
    public final MaterialCardView cardStreak;
    public final MaterialCardView cardToday;
    public final LinearLayout chartLabels;
    public final LinearLayout chartRow;
    public final TextView chipHealth;
    public final TextView chipHome;
    public final TextView chipMind;
    public final TextView chipOther;
    public final TextView chipSport;
    public final TextView chipWork;
    public final View color0;
    public final View color1;
    public final View color2;
    public final View color3;
    public final View color4;
    public final View color5;
    public final View color6;
    public final LinearLayout emptyHabits;
    public final FloatingActionButton fabAdd;
    public final MaterialCardView formCard;
    public final ImageView iconNavAwards;
    public final ImageView iconNavStats;
    public final ImageView iconNavToday;
    public final EditText inputTitle;
    public final TextView label0;
    public final TextView label1;
    public final TextView label2;
    public final TextView label3;
    public final TextView label4;
    public final TextView label5;
    public final TextView label6;
    public final LinearLayout listAwards;
    public final LinearLayout listHabits;
    public final LinearLayout listTopHabits;
    public final LinearLayout navAwards;
    public final LinearLayout navStats;
    public final LinearLayout navToday;
    public final View orbOne;
    public final View orbThree;
    public final View orbTwo;
    public final FrameLayout overlayForm;
    public final ScrollView panelAwards;
    public final FrameLayout panelHost;
    public final ScrollView panelStats;
    public final ScrollView panelToday;
    public final ProgressBar progressToday;
    public final ProgressBar progressWeek;
    public final CoordinatorLayout root;
    private final CoordinatorLayout rootView;
    public final ConstraintLayout screen;
    public final View scrim;
    public final TextView tabAwards;
    public final LinearLayout tabRow;
    public final TextView tabStats;
    public final TextView tabToday;
    public final TextView textDate;
    public final TextView textFormTitle;
    public final TextView textGreeting;
    public final TextView textQuote;
    public final TextView textStatBest;
    public final TextView textStatDone;
    public final TextView textStatHabits;
    public final TextView textStatRate;
    public final TextView textStatsPercent;
    public final TextView textStreakValue;
    public final TextView textTodayValue;
    public final TextView textTopEmpty;
    public final FrameLayout wrapColor0;
    public final FrameLayout wrapColor1;
    public final FrameLayout wrapColor2;
    public final FrameLayout wrapColor3;
    public final FrameLayout wrapColor4;
    public final FrameLayout wrapColor5;
    public final FrameLayout wrapColor6;

    private ActivityMain2Binding(CoordinatorLayout coordinatorLayout, TextView textView, View view, View view2, View view3, View view4, View view5, View view6, View view7, LinearLayout linearLayout, TextView textView2, TextView textView3, TextView textView4, TextView textView5, MaterialCardView materialCardView, MaterialCardView materialCardView2, LinearLayout linearLayout2, LinearLayout linearLayout3, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, View view8, View view9, View view10, View view11, View view12, View view13, View view14, LinearLayout linearLayout4, FloatingActionButton floatingActionButton, MaterialCardView materialCardView3, ImageView imageView, ImageView imageView2, ImageView imageView3, EditText editText, TextView textView12, TextView textView13, TextView textView14, TextView textView15, TextView textView16, TextView textView17, TextView textView18, LinearLayout linearLayout5, LinearLayout linearLayout6, LinearLayout linearLayout7, LinearLayout linearLayout8, LinearLayout linearLayout9, LinearLayout linearLayout10, View view15, View view16, View view17, FrameLayout frameLayout, ScrollView scrollView, FrameLayout frameLayout2, ScrollView scrollView2, ScrollView scrollView3, ProgressBar progressBar, ProgressBar progressBar2, CoordinatorLayout coordinatorLayout2, ConstraintLayout constraintLayout, View view18, TextView textView19, LinearLayout linearLayout11, TextView textView20, TextView textView21, TextView textView22, TextView textView23, TextView textView24, TextView textView25, TextView textView26, TextView textView27, TextView textView28, TextView textView29, TextView textView30, TextView textView31, TextView textView32, TextView textView33, FrameLayout frameLayout3, FrameLayout frameLayout4, FrameLayout frameLayout5, FrameLayout frameLayout6, FrameLayout frameLayout7, FrameLayout frameLayout8, FrameLayout frameLayout9) {
        this.rootView = coordinatorLayout;
        this.bannerAward = textView;
        this.bar0 = view;
        this.bar1 = view2;
        this.bar2 = view3;
        this.bar3 = view4;
        this.bar4 = view5;
        this.bar5 = view6;
        this.bar6 = view7;
        this.bottomBar = linearLayout;
        this.buttonCancel = textView2;
        this.buttonDelete = textView3;
        this.buttonEmptyAdd = textView4;
        this.buttonSave = textView5;
        this.cardStreak = materialCardView;
        this.cardToday = materialCardView2;
        this.chartLabels = linearLayout2;
        this.chartRow = linearLayout3;
        this.chipHealth = textView6;
        this.chipHome = textView7;
        this.chipMind = textView8;
        this.chipOther = textView9;
        this.chipSport = textView10;
        this.chipWork = textView11;
        this.color0 = view8;
        this.color1 = view9;
        this.color2 = view10;
        this.color3 = view11;
        this.color4 = view12;
        this.color5 = view13;
        this.color6 = view14;
        this.emptyHabits = linearLayout4;
        this.fabAdd = floatingActionButton;
        this.formCard = materialCardView3;
        this.iconNavAwards = imageView;
        this.iconNavStats = imageView2;
        this.iconNavToday = imageView3;
        this.inputTitle = editText;
        this.label0 = textView12;
        this.label1 = textView13;
        this.label2 = textView14;
        this.label3 = textView15;
        this.label4 = textView16;
        this.label5 = textView17;
        this.label6 = textView18;
        this.listAwards = linearLayout5;
        this.listHabits = linearLayout6;
        this.listTopHabits = linearLayout7;
        this.navAwards = linearLayout8;
        this.navStats = linearLayout9;
        this.navToday = linearLayout10;
        this.orbOne = view15;
        this.orbThree = view16;
        this.orbTwo = view17;
        this.overlayForm = frameLayout;
        this.panelAwards = scrollView;
        this.panelHost = frameLayout2;
        this.panelStats = scrollView2;
        this.panelToday = scrollView3;
        this.progressToday = progressBar;
        this.progressWeek = progressBar2;
        this.root = coordinatorLayout2;
        this.screen = constraintLayout;
        this.scrim = view18;
        this.tabAwards = textView19;
        this.tabRow = linearLayout11;
        this.tabStats = textView20;
        this.tabToday = textView21;
        this.textDate = textView22;
        this.textFormTitle = textView23;
        this.textGreeting = textView24;
        this.textQuote = textView25;
        this.textStatBest = textView26;
        this.textStatDone = textView27;
        this.textStatHabits = textView28;
        this.textStatRate = textView29;
        this.textStatsPercent = textView30;
        this.textStreakValue = textView31;
        this.textTodayValue = textView32;
        this.textTopEmpty = textView33;
        this.wrapColor0 = frameLayout3;
        this.wrapColor1 = frameLayout4;
        this.wrapColor2 = frameLayout5;
        this.wrapColor3 = frameLayout6;
        this.wrapColor4 = frameLayout7;
        this.wrapColor5 = frameLayout8;
        this.wrapColor6 = frameLayout9;
    }

    public static ActivityMain2Binding bind(View view) {
        View viewP;
        View viewP2;
        View viewP3;
        View viewP4;
        View viewP5;
        View viewP6;
        View viewP7;
        View viewP8;
        View viewP9;
        View viewP10;
        View viewP11;
        View viewP12;
        View viewP13;
        View viewP14;
        View viewP15;
        View viewP16;
        View viewP17;
        View viewP18;
        int i = R.id.bannerAward;
        TextView textView = (TextView) fv.p(view, i);
        if (textView != null && (viewP = fv.p(view, (i = R.id.bar0))) != null && (viewP2 = fv.p(view, (i = R.id.bar1))) != null && (viewP3 = fv.p(view, (i = R.id.bar2))) != null && (viewP4 = fv.p(view, (i = R.id.bar3))) != null && (viewP5 = fv.p(view, (i = R.id.bar4))) != null && (viewP6 = fv.p(view, (i = R.id.bar5))) != null && (viewP7 = fv.p(view, (i = R.id.bar6))) != null) {
            i = R.id.bottomBar;
            LinearLayout linearLayout = (LinearLayout) fv.p(view, i);
            if (linearLayout != null) {
                i = R.id.buttonCancel;
                TextView textView2 = (TextView) fv.p(view, i);
                if (textView2 != null) {
                    i = R.id.buttonDelete;
                    TextView textView3 = (TextView) fv.p(view, i);
                    if (textView3 != null) {
                        i = R.id.buttonEmptyAdd;
                        TextView textView4 = (TextView) fv.p(view, i);
                        if (textView4 != null) {
                            i = R.id.buttonSave;
                            TextView textView5 = (TextView) fv.p(view, i);
                            if (textView5 != null) {
                                i = R.id.cardStreak;
                                MaterialCardView materialCardView = (MaterialCardView) fv.p(view, i);
                                if (materialCardView != null) {
                                    i = R.id.cardToday;
                                    MaterialCardView materialCardView2 = (MaterialCardView) fv.p(view, i);
                                    if (materialCardView2 != null) {
                                        i = R.id.chartLabels;
                                        LinearLayout linearLayout2 = (LinearLayout) fv.p(view, i);
                                        if (linearLayout2 != null) {
                                            i = R.id.chartRow;
                                            LinearLayout linearLayout3 = (LinearLayout) fv.p(view, i);
                                            if (linearLayout3 != null) {
                                                i = R.id.chipHealth;
                                                TextView textView6 = (TextView) fv.p(view, i);
                                                if (textView6 != null) {
                                                    i = R.id.chipHome;
                                                    TextView textView7 = (TextView) fv.p(view, i);
                                                    if (textView7 != null) {
                                                        i = R.id.chipMind;
                                                        TextView textView8 = (TextView) fv.p(view, i);
                                                        if (textView8 != null) {
                                                            i = R.id.chipOther;
                                                            TextView textView9 = (TextView) fv.p(view, i);
                                                            if (textView9 != null) {
                                                                i = R.id.chipSport;
                                                                TextView textView10 = (TextView) fv.p(view, i);
                                                                if (textView10 != null) {
                                                                    i = R.id.chipWork;
                                                                    TextView textView11 = (TextView) fv.p(view, i);
                                                                    if (textView11 != null && (viewP8 = fv.p(view, (i = R.id.color0))) != null && (viewP9 = fv.p(view, (i = R.id.color1))) != null && (viewP10 = fv.p(view, (i = R.id.color2))) != null && (viewP11 = fv.p(view, (i = R.id.color3))) != null && (viewP12 = fv.p(view, (i = R.id.color4))) != null && (viewP13 = fv.p(view, (i = R.id.color5))) != null && (viewP14 = fv.p(view, (i = R.id.color6))) != null) {
                                                                        i = R.id.emptyHabits;
                                                                        LinearLayout linearLayout4 = (LinearLayout) fv.p(view, i);
                                                                        if (linearLayout4 != null) {
                                                                            i = R.id.fabAdd;
                                                                            FloatingActionButton floatingActionButton = (FloatingActionButton) fv.p(view, i);
                                                                            if (floatingActionButton != null) {
                                                                                i = R.id.formCard;
                                                                                MaterialCardView materialCardView3 = (MaterialCardView) fv.p(view, i);
                                                                                if (materialCardView3 != null) {
                                                                                    i = R.id.iconNavAwards;
                                                                                    ImageView imageView = (ImageView) fv.p(view, i);
                                                                                    if (imageView != null) {
                                                                                        i = R.id.iconNavStats;
                                                                                        ImageView imageView2 = (ImageView) fv.p(view, i);
                                                                                        if (imageView2 != null) {
                                                                                            i = R.id.iconNavToday;
                                                                                            ImageView imageView3 = (ImageView) fv.p(view, i);
                                                                                            if (imageView3 != null) {
                                                                                                i = R.id.inputTitle;
                                                                                                EditText editText = (EditText) fv.p(view, i);
                                                                                                if (editText != null) {
                                                                                                    i = R.id.label0;
                                                                                                    TextView textView12 = (TextView) fv.p(view, i);
                                                                                                    if (textView12 != null) {
                                                                                                        i = R.id.label1;
                                                                                                        TextView textView13 = (TextView) fv.p(view, i);
                                                                                                        if (textView13 != null) {
                                                                                                            i = R.id.label2;
                                                                                                            TextView textView14 = (TextView) fv.p(view, i);
                                                                                                            if (textView14 != null) {
                                                                                                                i = R.id.label3;
                                                                                                                TextView textView15 = (TextView) fv.p(view, i);
                                                                                                                if (textView15 != null) {
                                                                                                                    i = R.id.label4;
                                                                                                                    TextView textView16 = (TextView) fv.p(view, i);
                                                                                                                    if (textView16 != null) {
                                                                                                                        i = R.id.label5;
                                                                                                                        TextView textView17 = (TextView) fv.p(view, i);
                                                                                                                        if (textView17 != null) {
                                                                                                                            i = R.id.label6;
                                                                                                                            TextView textView18 = (TextView) fv.p(view, i);
                                                                                                                            if (textView18 != null) {
                                                                                                                                i = R.id.listAwards;
                                                                                                                                LinearLayout linearLayout5 = (LinearLayout) fv.p(view, i);
                                                                                                                                if (linearLayout5 != null) {
                                                                                                                                    i = R.id.listHabits;
                                                                                                                                    LinearLayout linearLayout6 = (LinearLayout) fv.p(view, i);
                                                                                                                                    if (linearLayout6 != null) {
                                                                                                                                        i = R.id.listTopHabits;
                                                                                                                                        LinearLayout linearLayout7 = (LinearLayout) fv.p(view, i);
                                                                                                                                        if (linearLayout7 != null) {
                                                                                                                                            i = R.id.navAwards;
                                                                                                                                            LinearLayout linearLayout8 = (LinearLayout) fv.p(view, i);
                                                                                                                                            if (linearLayout8 != null) {
                                                                                                                                                i = R.id.navStats;
                                                                                                                                                LinearLayout linearLayout9 = (LinearLayout) fv.p(view, i);
                                                                                                                                                if (linearLayout9 != null) {
                                                                                                                                                    i = R.id.navToday;
                                                                                                                                                    LinearLayout linearLayout10 = (LinearLayout) fv.p(view, i);
                                                                                                                                                    if (linearLayout10 != null && (viewP15 = fv.p(view, (i = R.id.orbOne))) != null && (viewP16 = fv.p(view, (i = R.id.orbThree))) != null && (viewP17 = fv.p(view, (i = R.id.orbTwo))) != null) {
                                                                                                                                                        i = R.id.overlayForm;
                                                                                                                                                        FrameLayout frameLayout = (FrameLayout) fv.p(view, i);
                                                                                                                                                        if (frameLayout != null) {
                                                                                                                                                            i = R.id.panelAwards;
                                                                                                                                                            ScrollView scrollView = (ScrollView) fv.p(view, i);
                                                                                                                                                            if (scrollView != null) {
                                                                                                                                                                i = R.id.panelHost;
                                                                                                                                                                FrameLayout frameLayout2 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                if (frameLayout2 != null) {
                                                                                                                                                                    i = R.id.panelStats;
                                                                                                                                                                    ScrollView scrollView2 = (ScrollView) fv.p(view, i);
                                                                                                                                                                    if (scrollView2 != null) {
                                                                                                                                                                        i = R.id.panelToday;
                                                                                                                                                                        ScrollView scrollView3 = (ScrollView) fv.p(view, i);
                                                                                                                                                                        if (scrollView3 != null) {
                                                                                                                                                                            i = R.id.progressToday;
                                                                                                                                                                            ProgressBar progressBar = (ProgressBar) fv.p(view, i);
                                                                                                                                                                            if (progressBar != null) {
                                                                                                                                                                                i = R.id.progressWeek;
                                                                                                                                                                                ProgressBar progressBar2 = (ProgressBar) fv.p(view, i);
                                                                                                                                                                                if (progressBar2 != null) {
                                                                                                                                                                                    CoordinatorLayout coordinatorLayout = (CoordinatorLayout) view;
                                                                                                                                                                                    i = R.id.screen;
                                                                                                                                                                                    ConstraintLayout constraintLayout = (ConstraintLayout) fv.p(view, i);
                                                                                                                                                                                    if (constraintLayout != null && (viewP18 = fv.p(view, (i = R.id.scrim))) != null) {
                                                                                                                                                                                        i = R.id.tabAwards;
                                                                                                                                                                                        TextView textView19 = (TextView) fv.p(view, i);
                                                                                                                                                                                        if (textView19 != null) {
                                                                                                                                                                                            i = R.id.tabRow;
                                                                                                                                                                                            LinearLayout linearLayout11 = (LinearLayout) fv.p(view, i);
                                                                                                                                                                                            if (linearLayout11 != null) {
                                                                                                                                                                                                i = R.id.tabStats;
                                                                                                                                                                                                TextView textView20 = (TextView) fv.p(view, i);
                                                                                                                                                                                                if (textView20 != null) {
                                                                                                                                                                                                    i = R.id.tabToday;
                                                                                                                                                                                                    TextView textView21 = (TextView) fv.p(view, i);
                                                                                                                                                                                                    if (textView21 != null) {
                                                                                                                                                                                                        i = R.id.textDate;
                                                                                                                                                                                                        TextView textView22 = (TextView) fv.p(view, i);
                                                                                                                                                                                                        if (textView22 != null) {
                                                                                                                                                                                                            i = R.id.textFormTitle;
                                                                                                                                                                                                            TextView textView23 = (TextView) fv.p(view, i);
                                                                                                                                                                                                            if (textView23 != null) {
                                                                                                                                                                                                                i = R.id.textGreeting;
                                                                                                                                                                                                                TextView textView24 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                if (textView24 != null) {
                                                                                                                                                                                                                    i = R.id.textQuote;
                                                                                                                                                                                                                    TextView textView25 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                    if (textView25 != null) {
                                                                                                                                                                                                                        i = R.id.textStatBest;
                                                                                                                                                                                                                        TextView textView26 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                        if (textView26 != null) {
                                                                                                                                                                                                                            i = R.id.textStatDone;
                                                                                                                                                                                                                            TextView textView27 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                            if (textView27 != null) {
                                                                                                                                                                                                                                i = R.id.textStatHabits;
                                                                                                                                                                                                                                TextView textView28 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                if (textView28 != null) {
                                                                                                                                                                                                                                    i = R.id.textStatRate;
                                                                                                                                                                                                                                    TextView textView29 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                    if (textView29 != null) {
                                                                                                                                                                                                                                        i = R.id.textStatsPercent;
                                                                                                                                                                                                                                        TextView textView30 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                        if (textView30 != null) {
                                                                                                                                                                                                                                            i = R.id.textStreakValue;
                                                                                                                                                                                                                                            TextView textView31 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                            if (textView31 != null) {
                                                                                                                                                                                                                                                i = R.id.textTodayValue;
                                                                                                                                                                                                                                                TextView textView32 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                                if (textView32 != null) {
                                                                                                                                                                                                                                                    i = R.id.textTopEmpty;
                                                                                                                                                                                                                                                    TextView textView33 = (TextView) fv.p(view, i);
                                                                                                                                                                                                                                                    if (textView33 != null) {
                                                                                                                                                                                                                                                        i = R.id.wrapColor0;
                                                                                                                                                                                                                                                        FrameLayout frameLayout3 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                        if (frameLayout3 != null) {
                                                                                                                                                                                                                                                            i = R.id.wrapColor1;
                                                                                                                                                                                                                                                            FrameLayout frameLayout4 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                            if (frameLayout4 != null) {
                                                                                                                                                                                                                                                                i = R.id.wrapColor2;
                                                                                                                                                                                                                                                                FrameLayout frameLayout5 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                                if (frameLayout5 != null) {
                                                                                                                                                                                                                                                                    i = R.id.wrapColor3;
                                                                                                                                                                                                                                                                    FrameLayout frameLayout6 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                                    if (frameLayout6 != null) {
                                                                                                                                                                                                                                                                        i = R.id.wrapColor4;
                                                                                                                                                                                                                                                                        FrameLayout frameLayout7 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                                        if (frameLayout7 != null) {
                                                                                                                                                                                                                                                                            i = R.id.wrapColor5;
                                                                                                                                                                                                                                                                            FrameLayout frameLayout8 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                                            if (frameLayout8 != null) {
                                                                                                                                                                                                                                                                                i = R.id.wrapColor6;
                                                                                                                                                                                                                                                                                FrameLayout frameLayout9 = (FrameLayout) fv.p(view, i);
                                                                                                                                                                                                                                                                                if (frameLayout9 != null) {
                                                                                                                                                                                                                                                                                    return new ActivityMain2Binding(coordinatorLayout, textView, viewP, viewP2, viewP3, viewP4, viewP5, viewP6, viewP7, linearLayout, textView2, textView3, textView4, textView5, materialCardView, materialCardView2, linearLayout2, linearLayout3, textView6, textView7, textView8, textView9, textView10, textView11, viewP8, viewP9, viewP10, viewP11, viewP12, viewP13, viewP14, linearLayout4, floatingActionButton, materialCardView3, imageView, imageView2, imageView3, editText, textView12, textView13, textView14, textView15, textView16, textView17, textView18, linearLayout5, linearLayout6, linearLayout7, linearLayout8, linearLayout9, linearLayout10, viewP15, viewP16, viewP17, frameLayout, scrollView, frameLayout2, scrollView2, scrollView3, progressBar, progressBar2, coordinatorLayout, constraintLayout, viewP18, textView19, linearLayout11, textView20, textView21, textView22, textView23, textView24, textView25, textView26, textView27, textView28, textView29, textView30, textView31, textView32, textView33, frameLayout3, frameLayout4, frameLayout5, frameLayout6, frameLayout7, frameLayout8, frameLayout9);
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }

    public static ActivityMain2Binding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_main2, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public CoordinatorLayout getRoot() {
        return this.rootView;
    }

    public static ActivityMain2Binding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }
}
