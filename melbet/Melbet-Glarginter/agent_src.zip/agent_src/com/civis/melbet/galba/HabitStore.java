package com.civis.melbet.galba;

import android.content.Context;
import android.content.SharedPreferences;
import defpackage.wd;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
/* loaded from: classes.dex */
public final class HabitStore {
    public static final Companion Companion = new Companion(null);
    private static final String KEY_AWARDS = "awards";
    private static final String KEY_HABITS = "habits";
    private static final String PREFS = "win_habit_store";
    private final SharedPreferences prefs;

    public HabitStore(Context context) {
        context.getClass();
        this.prefs = context.getSharedPreferences(PREFS, 0);
    }

    public final Map<String, Long> loadAwards() {
        String string = this.prefs.getString(KEY_AWARDS, "{}");
        String str = string != null ? string : "{}";
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        try {
            JSONObject jSONObject = new JSONObject(str);
            Iterator<String> itKeys = jSONObject.keys();
            itKeys.getClass();
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                linkedHashMap.put(next, Long.valueOf(jSONObject.optLong(next, 0L)));
            }
            return linkedHashMap;
        } catch (Exception unused) {
            return new LinkedHashMap();
        }
    }

    public final List<HabitItem> loadHabits() throws JSONException {
        String string = this.prefs.getString(KEY_HABITS, "[]");
        String str = string != null ? string : "[]";
        ArrayList arrayList = new ArrayList();
        try {
            JSONArray jSONArray = new JSONArray(str);
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("days");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                int length2 = jSONArrayOptJSONArray.length();
                for (int i2 = 0; i2 < length2; i2++) {
                    String string2 = jSONArrayOptJSONArray.getString(i2);
                    string2.getClass();
                    linkedHashSet.add(string2);
                }
                String string3 = jSONObject.getString("id");
                string3.getClass();
                String string4 = jSONObject.getString("title");
                string4.getClass();
                String strOptString = jSONObject.optString("category", "other");
                strOptString.getClass();
                arrayList.add(new HabitItem(string3, string4, strOptString, jSONObject.optInt("color", 0), jSONObject.optLong("created", 0L), linkedHashSet));
            }
            return arrayList;
        } catch (Exception unused) {
            return new ArrayList();
        }
    }

    public final void saveAwards(Map<String, Long> map) {
        map.getClass();
        JSONObject jSONObject = new JSONObject();
        for (Map.Entry<String, Long> entry : map.entrySet()) {
            jSONObject.put(entry.getKey(), entry.getValue().longValue());
        }
        this.prefs.edit().putString(KEY_AWARDS, jSONObject.toString()).apply();
    }

    public final void saveHabits(List<HabitItem> list) {
        list.getClass();
        JSONArray jSONArray = new JSONArray();
        for (HabitItem habitItem : list) {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("id", habitItem.getId());
            jSONObject.put("title", habitItem.getTitle());
            jSONObject.put("category", habitItem.getCategory());
            jSONObject.put("color", habitItem.getColorIndex());
            jSONObject.put("created", habitItem.getCreatedAt());
            JSONArray jSONArray2 = new JSONArray();
            Iterator<T> it = habitItem.getDays().iterator();
            while (it.hasNext()) {
                jSONArray2.put((String) it.next());
            }
            jSONObject.put("days", jSONArray2);
            jSONArray.put(jSONObject);
        }
        this.prefs.edit().putString(KEY_HABITS, jSONArray.toString()).apply();
    }

    /* compiled from: r8-map-id-7dfc45f22ae3786b04e2dd485905db8418b47ddd6e63ef6425c892c2191409f2 */
    public static final class Companion {
        public /* synthetic */ Companion(wd wdVar) {
            this();
        }

        private Companion() {
        }
    }
}
