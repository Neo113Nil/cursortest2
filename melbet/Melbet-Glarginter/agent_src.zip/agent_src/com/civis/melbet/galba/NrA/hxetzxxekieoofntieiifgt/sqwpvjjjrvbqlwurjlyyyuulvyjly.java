package com.civis.melbet.galba.NrA.hxetzxxekieoofntieiifgt;

/* loaded from: classes.dex */
public final class sqwpvjjjrvbqlwurjlyyyuulvyjly {
    public static final int IDSROEAKOH = 136193130;
    public static final int JAHJKJLOJU = -903102709;
    public static final int JYXLDABBEY = 996299633;
    public static final int LDATDPESBS = 966735309;
    public static final int VGWFIRREDQ = -719033514;
}
