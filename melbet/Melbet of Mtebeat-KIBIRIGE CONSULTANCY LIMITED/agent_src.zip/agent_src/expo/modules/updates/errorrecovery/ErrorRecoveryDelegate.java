package expo.modules.updates.errorrecovery;

/* compiled from: ErrorRecoveryDelegate.kt */
@kotlin.Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001:\u0001\u0013J\b\u0010\u0002\u001a\u00020\u0003H&J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H&J\u0014\u0010\u0007\u001a\u00020\u00032\n\u0010\b\u001a\u00060\tj\u0002`\nH&J\b\u0010\u000b\u001a\u00020\u0003H&J\b\u0010\f\u001a\u00020\u0003H&J\b\u0010\r\u001a\u00020\u000eH&J\b\u0010\u000f\u001a\u00020\u0010H&J\b\u0010\u0011\u001a\u00020\u0012H&¨\u0006\u0014"}, d2 = {"Lexpo/modules/updates/errorrecovery/ErrorRecoveryDelegate;", "", "loadRemoteUpdate", "", "relaunch", "callback", "Lexpo/modules/updates/launcher/Launcher$LauncherCallback;", "throwException", "exception", "Ljava/lang/Exception;", "Lkotlin/Exception;", "markFailedLaunchForLaunchedUpdate", "markSuccessfulLaunchForLaunchedUpdate", "getRemoteLoadStatus", "Lexpo/modules/updates/errorrecovery/ErrorRecoveryDelegate$RemoteLoadStatus;", "getCheckAutomaticallyConfiguration", "Lexpo/modules/updates/UpdatesConfiguration$CheckAutomaticallyConfiguration;", "getLaunchedUpdateSuccessfulLaunchCount", "", "RemoteLoadStatus", "expo-updates_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface ErrorRecoveryDelegate {
    expo.modules.updates.UpdatesConfiguration.CheckAutomaticallyConfiguration getCheckAutomaticallyConfiguration();

    int getLaunchedUpdateSuccessfulLaunchCount();

    expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus getRemoteLoadStatus();

    void loadRemoteUpdate();

    void markFailedLaunchForLaunchedUpdate();

    void markSuccessfulLaunchForLaunchedUpdate();

    void relaunch(expo.modules.updates.launcher.Launcher.LauncherCallback callback);

    void throwException(java.lang.Exception exception);

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: ErrorRecoveryDelegate.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lexpo/modules/updates/errorrecovery/ErrorRecoveryDelegate$RemoteLoadStatus;", "", "<init>", "(Ljava/lang/String;I)V", "IDLE", "NEW_UPDATE_LOADING", "NEW_UPDATE_LOADED", "expo-updates_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class RemoteLoadStatus {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[] $VALUES;
        public static final expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus IDLE = new expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus("IDLE", 0);
        public static final expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus NEW_UPDATE_LOADING = new expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus("NEW_UPDATE_LOADING", 1);
        public static final expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus NEW_UPDATE_LOADED = new expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus("NEW_UPDATE_LOADED", 2);

        private static final /* synthetic */ expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[] $values() {
            return new expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[]{IDLE, NEW_UPDATE_LOADING, NEW_UPDATE_LOADED};
        }

        public static kotlin.enums.EnumEntries<expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus> getEntries() {
            return $ENTRIES;
        }

        private RemoteLoadStatus(java.lang.String str, int i) {
        }

        static {
            expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[] remoteLoadStatusArr$values = $values();
            $VALUES = remoteLoadStatusArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(remoteLoadStatusArr$values);
        }

        public static expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus valueOf(java.lang.String str) {
            return (expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus) java.lang.Enum.valueOf(expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus.class, str);
        }

        public static expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[] values() {
            return (expo.modules.updates.errorrecovery.ErrorRecoveryDelegate.RemoteLoadStatus[]) $VALUES.clone();
        }
    }
}
