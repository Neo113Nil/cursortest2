package expo.modules;

/* compiled from: ReactActivityDelegateWrapper.kt */
@kotlin.Metadata(d1 = {"\u0000ê\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \u0084\u00012\u00020\u0001:\u0002\u0084\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0001¢\u0006\u0004\b\u0007\u0010\bB\u0019\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0001¢\u0006\u0004\b\u0007\u0010\tJ\n\u00102\u001a\u0004\u0018\u000103H\u0014J\n\u00104\u001a\u0004\u0018\u000105H\u0014J\n\u00106\u001a\u0004\u0018\u000107H\u0014J\b\u00108\u001a\u00020\u0019H\u0014J\n\u00109\u001a\u0004\u0018\u00010\u001fH\u0016J\b\u0010:\u001a\u00020;H\u0016J\n\u0010<\u001a\u0004\u0018\u00010\u0016H\u0016J\u0012\u0010=\u001a\u00020*2\b\u0010>\u001a\u0004\u0018\u00010\u0016H\u0014J\u0012\u0010?\u001a\u00020*2\b\u0010@\u001a\u0004\u0018\u000103H\u0017J\b\u0010A\u001a\u00020*H\u0016J\b\u0010B\u001a\u00020*H\u0016J\b\u0010C\u001a\u00020*H\u0016J\b\u0010D\u001a\u00020*H\u0016J\"\u0010E\u001a\u00020*2\u0006\u0010F\u001a\u00020G2\u0006\u0010H\u001a\u00020G2\b\u0010I\u001a\u0004\u0018\u00010JH\u0016J\u0018\u0010K\u001a\u00020\u00052\u0006\u0010L\u001a\u00020G2\u0006\u0010M\u001a\u00020NH\u0016J\u0018\u0010O\u001a\u00020\u00052\u0006\u0010L\u001a\u00020G2\u0006\u0010M\u001a\u00020NH\u0016J\u0018\u0010P\u001a\u00020\u00052\u0006\u0010L\u001a\u00020G2\u0006\u0010M\u001a\u00020NH\u0016J\b\u0010Q\u001a\u00020\u0005H\u0016J\u0012\u0010R\u001a\u00020\u00052\b\u0010S\u001a\u0004\u0018\u00010JH\u0016J\u0010\u0010T\u001a\u00020*2\u0006\u0010U\u001a\u00020\u0005H\u0016J/\u0010V\u001a\u00020*2\u000e\u0010W\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160X2\u0006\u0010F\u001a\u00020G2\b\u0010Y\u001a\u0004\u0018\u00010ZH\u0016¢\u0006\u0002\u0010[J-\u0010\\\u001a\u00020*2\u0006\u0010F\u001a\u00020G2\u000e\u0010W\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160X2\u0006\u0010]\u001a\u00020^H\u0016¢\u0006\u0002\u0010_J\b\u0010`\u001a\u00020aH\u0014J\b\u0010b\u001a\u00020cH\u0014J\b\u0010d\u001a\u00020\u0005H\u0014J\b\u0010e\u001a\u00020\u0005H\u0014J\n\u0010f\u001a\u0004\u0018\u000103H\u0014J\u0010\u0010g\u001a\u00020*2\u0006\u0010h\u001a\u00020iH\u0016J\u001b\u0010j\u001a\u0002Hk\"\u0004\b\u0000\u0010k2\u0006\u0010l\u001a\u00020\u0016H\u0002¢\u0006\u0002\u0010mJC\u0010j\u001a\u0002Hk\"\u0004\b\u0000\u0010k\"\u0004\b\u0001\u0010n2\u0006\u0010l\u001a\u00020\u00162\u0010\u0010o\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030p0X2\f\u0010q\u001a\b\u0012\u0004\u0012\u0002Hn0XH\u0001¢\u0006\u0004\br\u0010sJ \u0010t\u001a\u00020*2\b\u0010>\u001a\u0004\u0018\u00010\u00162\u0006\u0010u\u001a\u00020\u0005H\u0082@¢\u0006\u0002\u0010vJ\u0018\u0010w\u001a\u00020*2\b\u0010#\u001a\u0004\u0018\u00010$H\u0082@¢\u0006\u0002\u0010xJB\u0010y\u001a\u00020*2\b\b\u0002\u0010z\u001a\u00020{2(\u0010|\u001a$\b\u0001\u0012\u0004\u0012\u00020.\u0012\n\u0012\b\u0012\u0004\u0012\u00020*0~\u0012\u0006\u0012\u0004\u0018\u00010\u007f0}¢\u0006\u0003\b\u0080\u0001H\u0002¢\u0006\u0003\u0010\u0081\u0001J\u000f\u0010\u0082\u0001\u001a\u00020*H\u0001¢\u0006\u0003\b\u0083\u0001R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u00020\u00018AX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001c\u0010\u000e\u001a\u0010\u0012\f\u0012\n \u0011*\u0004\u0018\u00010\u00100\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0012\u001a\u0010\u0012\f\u0012\n \u0011*\u0004\u0018\u00010\u00130\u00130\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00170\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u0018\u001a\u00020\u00198BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001a\u0010\u001bR\u001d\u0010\u001e\u001a\u0004\u0018\u00010\u001f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\"\u0010\u001d\u001a\u0004\b \u0010!R\u001d\u0010#\u001a\u0004\u0018\u00010$8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b'\u0010\u001d\u001a\u0004\b%\u0010&R\u0014\u0010(\u001a\b\u0012\u0004\u0012\u00020*0)X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010-\u001a\u00020.8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b1\u0010\u001d\u001a\u0004\b/\u00100¨\u0006\u0085\u0001"}, d2 = {"Lexpo/modules/ReactActivityDelegateWrapper;", "Lcom/facebook/react/ReactActivityDelegate;", "activity", "Lcom/facebook/react/ReactActivity;", "isNewArchitectureEnabled", "", "delegate", "<init>", "(Lcom/facebook/react/ReactActivity;ZLcom/facebook/react/ReactActivityDelegate;)V", "(Lcom/facebook/react/ReactActivity;Lcom/facebook/react/ReactActivityDelegate;)V", "getDelegate$expo_release", "()Lcom/facebook/react/ReactActivityDelegate;", "setDelegate$expo_release", "(Lcom/facebook/react/ReactActivityDelegate;)V", "reactActivityLifecycleListeners", "", "Lexpo/modules/core/interfaces/ReactActivityLifecycleListener;", "kotlin.jvm.PlatformType", "reactActivityHandlers", "Lexpo/modules/core/interfaces/ReactActivityHandler;", "methodMap", "Landroidx/collection/ArrayMap;", "", "Ljava/lang/reflect/Method;", "_reactNativeHost", "Lcom/facebook/react/ReactNativeHost;", "get_reactNativeHost", "()Lcom/facebook/react/ReactNativeHost;", "_reactNativeHost$delegate", "Lkotlin/Lazy;", "_reactHost", "Lcom/facebook/react/ReactHost;", "get_reactHost", "()Lcom/facebook/react/ReactHost;", "_reactHost$delegate", "delayLoadAppHandler", "Lexpo/modules/core/interfaces/ReactActivityHandler$DelayLoadAppHandler;", "getDelayLoadAppHandler", "()Lexpo/modules/core/interfaces/ReactActivityHandler$DelayLoadAppHandler;", "delayLoadAppHandler$delegate", "loadAppReady", "Lkotlinx/coroutines/CompletableDeferred;", "", "mutex", "Lkotlinx/coroutines/sync/Mutex;", "applicationCoroutineScope", "Lkotlinx/coroutines/CoroutineScope;", "getApplicationCoroutineScope", "()Lkotlinx/coroutines/CoroutineScope;", "applicationCoroutineScope$delegate", "getLaunchOptions", "Landroid/os/Bundle;", "createRootView", "Lcom/facebook/react/ReactRootView;", "getReactDelegate", "Lcom/facebook/react/ReactDelegate;", "getReactNativeHost", "getReactHost", "getReactInstanceManager", "Lcom/facebook/react/ReactInstanceManager;", "getMainComponentName", "loadApp", "appKey", "onCreate", "savedInstanceState", "onResume", "onPause", "onUserLeaveHint", "onDestroy", "onActivityResult", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "onKeyDown", "keyCode", androidx.core.app.NotificationCompat.CATEGORY_EVENT, "Landroid/view/KeyEvent;", "onKeyUp", "onKeyLongPress", "onBackPressed", "onNewIntent", "intent", "onWindowFocusChanged", "hasFocus", "requestPermissions", "permissions", "", "listener", "Lcom/facebook/react/modules/core/PermissionListener;", "([Ljava/lang/String;ILcom/facebook/react/modules/core/PermissionListener;)V", "onRequestPermissionsResult", "grantResults", "", "(I[Ljava/lang/String;[I)V", "getContext", "Landroid/content/Context;", "getPlainActivity", "Landroid/app/Activity;", "isFabricEnabled", "isWideColorGamutEnabled", "composeLaunchOptions", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "invokeDelegateMethod", androidx.exifinterface.media.ExifInterface.GPS_DIRECTION_TRUE, "name", "(Ljava/lang/String;)Ljava/lang/Object;", androidx.exifinterface.media.ExifInterface.GPS_MEASUREMENT_IN_PROGRESS, "argTypes", "Ljava/lang/Class;", "args", "invokeDelegateMethod$expo_release", "(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;", "loadAppImpl", "supportsDelayLoad", "(Ljava/lang/String;ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "awaitDelayLoadAppWhenReady", "(Lexpo/modules/core/interfaces/ReactActivityHandler$DelayLoadAppHandler;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "launchLifecycleScopeWithLock", "start", "Lkotlinx/coroutines/CoroutineStart;", "block", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;)V", "setLoadAppReadyForTesting", "setLoadAppReadyForTesting$expo_release", "Companion", "expo_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ReactActivityDelegateWrapper extends com.facebook.react.ReactActivityDelegate {
    private static final java.lang.String TAG = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(com.facebook.react.ReactActivityDelegate.class).getSimpleName();

    /* renamed from: _reactHost$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy _reactHost;

    /* renamed from: _reactNativeHost$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy _reactNativeHost;
    private final com.facebook.react.ReactActivity activity;

    /* renamed from: applicationCoroutineScope$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy applicationCoroutineScope;

    /* renamed from: delayLoadAppHandler$delegate, reason: from kotlin metadata */
    private final kotlin.Lazy delayLoadAppHandler;
    private com.facebook.react.ReactActivityDelegate delegate;
    private final boolean isNewArchitectureEnabled;
    private final kotlinx.coroutines.CompletableDeferred<kotlin.Unit> loadAppReady;
    private final androidx.collection.ArrayMap<java.lang.String, java.lang.reflect.Method> methodMap;
    private final kotlinx.coroutines.sync.Mutex mutex;
    private final java.util.List<expo.modules.core.interfaces.ReactActivityHandler> reactActivityHandlers;
    private final java.util.List<expo.modules.core.interfaces.ReactActivityLifecycleListener> reactActivityLifecycleListeners;

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper", f = "ReactActivityDelegateWrapper.kt", i = {0}, l = {453}, m = "loadAppImpl", n = {"appKey"}, s = {"L$0"})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$loadAppImpl$1, reason: invalid class name and case insensitive filesystem */
    static final class C01231 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        java.lang.Object L$0;
        int label;
        /* synthetic */ java.lang.Object result;

        C01231(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01231> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return expo.modules.ReactActivityDelegateWrapper.this.loadAppImpl(null, false, this);
        }
    }

    /* renamed from: getDelegate$expo_release, reason: from getter */
    public final com.facebook.react.ReactActivityDelegate getDelegate() {
        return this.delegate;
    }

    public final void setDelegate$expo_release(com.facebook.react.ReactActivityDelegate reactActivityDelegate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reactActivityDelegate, "<set-?>");
        this.delegate = reactActivityDelegate;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ReactActivityDelegateWrapper(com.facebook.react.ReactActivity activity, boolean z, com.facebook.react.ReactActivityDelegate delegate) {
        super(activity, (java.lang.String) null);
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(activity, "activity");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(delegate, "delegate");
        this.activity = activity;
        this.isNewArchitectureEnabled = z;
        this.delegate = delegate;
        java.util.List<expo.modules.core.interfaces.Package> packageList = expo.modules.ExpoModulesPackage.INSTANCE.getPackageList();
        java.util.ArrayList arrayList = new java.util.ArrayList();
        java.util.Iterator<T> it = packageList.iterator();
        while (it.hasNext()) {
            java.util.List<? extends expo.modules.core.interfaces.ReactActivityLifecycleListener> listCreateReactActivityLifecycleListeners = ((expo.modules.core.interfaces.Package) it.next()).createReactActivityLifecycleListeners(this.activity);
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(listCreateReactActivityLifecycleListeners, "createReactActivityLifecycleListeners(...)");
            kotlin.collections.CollectionsKt.addAll(arrayList, listCreateReactActivityLifecycleListeners);
        }
        this.reactActivityLifecycleListeners = arrayList;
        java.util.List<expo.modules.core.interfaces.Package> packageList2 = expo.modules.ExpoModulesPackage.INSTANCE.getPackageList();
        java.util.ArrayList arrayList2 = new java.util.ArrayList();
        java.util.Iterator<T> it2 = packageList2.iterator();
        while (it2.hasNext()) {
            java.util.List<? extends expo.modules.core.interfaces.ReactActivityHandler> listCreateReactActivityHandlers = ((expo.modules.core.interfaces.Package) it2.next()).createReactActivityHandlers(this.activity);
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(listCreateReactActivityHandlers, "createReactActivityHandlers(...)");
            kotlin.collections.CollectionsKt.addAll(arrayList2, listCreateReactActivityHandlers);
        }
        this.reactActivityHandlers = arrayList2;
        this.methodMap = new androidx.collection.ArrayMap<>();
        this._reactNativeHost = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return expo.modules.ReactActivityDelegateWrapper._reactNativeHost_delegate$lambda$2(this.f$0);
            }
        });
        this._reactHost = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return expo.modules.ReactActivityDelegateWrapper._reactHost_delegate$lambda$3(this.f$0);
            }
        });
        this.delayLoadAppHandler = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return expo.modules.ReactActivityDelegateWrapper.delayLoadAppHandler_delegate$lambda$5(this.f$0);
            }
        });
        this.loadAppReady = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
        this.mutex = kotlinx.coroutines.sync.MutexKt.Mutex$default(false, 1, null);
        this.applicationCoroutineScope = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return expo.modules.ReactActivityDelegateWrapper.applicationCoroutineScope_delegate$lambda$6();
            }
        });
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ReactActivityDelegateWrapper(com.facebook.react.ReactActivity activity, com.facebook.react.ReactActivityDelegate delegate) {
        this(activity, false, delegate);
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(activity, "activity");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(delegate, "delegate");
    }

    private final com.facebook.react.ReactNativeHost get_reactNativeHost() {
        return (com.facebook.react.ReactNativeHost) this._reactNativeHost.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.facebook.react.ReactNativeHost _reactNativeHost_delegate$lambda$2(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper) {
        return (com.facebook.react.ReactNativeHost) reactActivityDelegateWrapper.invokeDelegateMethod("getReactNativeHost");
    }

    private final com.facebook.react.ReactHost get_reactHost() {
        return (com.facebook.react.ReactHost) this._reactHost.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.facebook.react.ReactHost _reactHost_delegate$lambda$3(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper) {
        return reactActivityDelegateWrapper.delegate.getReactHost();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler getDelayLoadAppHandler() {
        return (expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler) this.delayLoadAppHandler.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler delayLoadAppHandler_delegate$lambda$5(final expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper) {
        return (expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler) kotlin.sequences.SequencesKt.firstOrNull(kotlin.sequences.SequencesKt.mapNotNull(kotlin.collections.CollectionsKt.asSequence(reactActivityDelegateWrapper.reactActivityHandlers), new kotlin.jvm.functions.Function1() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return expo.modules.ReactActivityDelegateWrapper.delayLoadAppHandler_delegate$lambda$5$lambda$4(this.f$0, (expo.modules.core.interfaces.ReactActivityHandler) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler delayLoadAppHandler_delegate$lambda$5$lambda$4(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper, expo.modules.core.interfaces.ReactActivityHandler reactActivityHandler) {
        return reactActivityHandler.getDelayLoadAppHandler(reactActivityDelegateWrapper.activity, reactActivityDelegateWrapper.getReactNativeHost());
    }

    private final kotlinx.coroutines.CoroutineScope getApplicationCoroutineScope() {
        return (kotlinx.coroutines.CoroutineScope) this.applicationCoroutineScope.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlinx.coroutines.CoroutineScope applicationCoroutineScope_delegate$lambda$6() {
        return kotlinx.coroutines.CoroutineScopeKt.CoroutineScope(kotlinx.coroutines.Dispatchers.getMain());
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected android.os.Bundle getLaunchOptions() {
        return (android.os.Bundle) invokeDelegateMethod("getLaunchOptions");
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected com.facebook.react.ReactRootView createRootView() {
        return (com.facebook.react.ReactRootView) invokeDelegateMethod("createRootView");
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected com.facebook.react.ReactDelegate getReactDelegate() {
        return (com.facebook.react.ReactDelegate) invokeDelegateMethod("getReactDelegate");
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected com.facebook.react.ReactNativeHost getReactNativeHost() {
        return get_reactNativeHost();
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public com.facebook.react.ReactHost getReactHost() {
        return get_reactHost();
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public com.facebook.react.ReactInstanceManager getReactInstanceManager() {
        com.facebook.react.ReactInstanceManager reactInstanceManager = this.delegate.getReactInstanceManager();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(reactInstanceManager, "getReactInstanceManager(...)");
        return reactInstanceManager;
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public java.lang.String getMainComponentName() {
        return this.delegate.getMainComponentName();
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$loadApp$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {123}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$loadApp$1, reason: invalid class name and case insensitive filesystem */
    static final class C01221 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ java.lang.String $appKey;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01221(java.lang.String str, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01221> continuation) {
            super(2, continuation);
            this.$appKey = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01221(this.$appKey, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01221) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppImpl(this.$appKey, true, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected void loadApp(java.lang.String appKey) {
        launchLifecycleScopeWithLock(kotlinx.coroutines.CoroutineStart.UNDISPATCHED, new expo.modules.ReactActivityDelegateWrapper.C01221(appKey, null));
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onCreate(android.os.Bundle savedInstanceState) throws java.lang.IllegalAccessException, java.lang.NoSuchFieldException, java.lang.IllegalArgumentException {
        com.facebook.react.ReactActivityDelegate reactActivityDelegate = (com.facebook.react.ReactActivityDelegate) kotlin.sequences.SequencesKt.firstOrNull(kotlin.sequences.SequencesKt.mapNotNull(kotlin.collections.CollectionsKt.asSequence(this.reactActivityHandlers), new kotlin.jvm.functions.Function1() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return expo.modules.ReactActivityDelegateWrapper.onCreate$lambda$7(this.f$0, (expo.modules.core.interfaces.ReactActivityHandler) obj);
            }
        }));
        if (reactActivityDelegate != null && !kotlin.jvm.internal.Intrinsics.areEqual(reactActivityDelegate, this)) {
            java.lang.reflect.Field declaredField = com.facebook.react.ReactActivity.class.getDeclaredField("mDelegate");
            declaredField.setAccessible(true);
            java.lang.reflect.Field declaredField2 = java.lang.reflect.Field.class.getDeclaredField("accessFlags");
            declaredField2.setAccessible(true);
            declaredField2.setInt(declaredField, declaredField.getModifiers() & (-17));
            declaredField.set(this.activity, reactActivityDelegate);
            this.delegate = reactActivityDelegate;
            reactActivityDelegate.onCreate(savedInstanceState);
        } else {
            launchLifecycleScopeWithLock(kotlinx.coroutines.CoroutineStart.UNDISPATCHED, new expo.modules.ReactActivityDelegateWrapper.C01261(null));
        }
        java.util.Iterator<T> it = this.reactActivityLifecycleListeners.iterator();
        while (it.hasNext()) {
            ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onCreate(this.activity, savedInstanceState);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final com.facebook.react.ReactActivityDelegate onCreate$lambda$7(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper, expo.modules.core.interfaces.ReactActivityHandler reactActivityHandler) {
        return reactActivityHandler.onDidCreateReactActivityDelegate(reactActivityDelegateWrapper.activity, reactActivityDelegateWrapper);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onCreate$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {151, 185}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onCreate$1, reason: invalid class name and case insensitive filesystem */
    static final class C01261 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C01261(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01261> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01261(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01261) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:25:0x00cf, code lost:
        
            if (r12.loadAppImpl(r12.getMainComponentName(), false, r11) == r0) goto L26;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object invokeSuspend(java.lang.Object obj) throws java.lang.IllegalAccessException, java.lang.NoSuchFieldException, java.lang.IllegalArgumentException {
            com.facebook.react.ReactDelegate reactDelegate;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
                this.label = 1;
                if (reactActivityDelegateWrapper.awaitDelayLoadAppWhenReady(reactActivityDelegateWrapper.getDelayLoadAppHandler(), this) != coroutine_suspended) {
                }
                return coroutine_suspended;
            }
            if (i != 1) {
                if (i != 2) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
                return kotlin.Unit.INSTANCE;
            }
            kotlin.ResultKt.throwOnFailure(obj);
            expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.complete(kotlin.Unit.INSTANCE);
            if (android.os.Build.VERSION.SDK_INT >= 26 && expo.modules.ReactActivityDelegateWrapper.this.isWideColorGamutEnabled()) {
                expo.modules.ReactActivityDelegateWrapper.this.activity.getWindow().setColorMode(1);
            }
            android.os.Bundle bundleComposeLaunchOptions = expo.modules.ReactActivityDelegateWrapper.this.composeLaunchOptions();
            if (expo.modules.rncompatibility.ReactNativeFeatureFlags.INSTANCE.getEnableBridgelessArchitecture()) {
                reactDelegate = new com.facebook.react.ReactDelegate(expo.modules.ReactActivityDelegateWrapper.this.getPlainActivity(), expo.modules.ReactActivityDelegateWrapper.this.getReactHost(), expo.modules.ReactActivityDelegateWrapper.this.getMainComponentName(), bundleComposeLaunchOptions);
            } else {
                android.app.Activity plainActivity = expo.modules.ReactActivityDelegateWrapper.this.getPlainActivity();
                com.facebook.react.ReactNativeHost reactNativeHost = expo.modules.ReactActivityDelegateWrapper.this.getReactNativeHost();
                java.lang.String mainComponentName = expo.modules.ReactActivityDelegateWrapper.this.getMainComponentName();
                boolean fabricEnabled = expo.modules.ReactActivityDelegateWrapper.this.getFabricEnabled();
                final expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper2 = expo.modules.ReactActivityDelegateWrapper.this;
                reactDelegate = new com.facebook.react.ReactDelegate(bundleComposeLaunchOptions, plainActivity, reactNativeHost, mainComponentName, fabricEnabled) { // from class: expo.modules.ReactActivityDelegateWrapper.onCreate.1.1
                    @Override // com.facebook.react.ReactDelegate
                    protected com.facebook.react.ReactRootView createRootView() {
                        com.facebook.react.ReactRootView reactRootViewCreateRootView = reactActivityDelegateWrapper2.createRootView();
                        return reactRootViewCreateRootView == null ? super.createRootView() : reactRootViewCreateRootView;
                    }
                };
            }
            java.lang.reflect.Field declaredField = com.facebook.react.ReactActivityDelegate.class.getDeclaredField("mReactDelegate");
            declaredField.setAccessible(true);
            declaredField.set(expo.modules.ReactActivityDelegateWrapper.this.getDelegate(), reactDelegate);
            if (expo.modules.ReactActivityDelegateWrapper.this.getMainComponentName() != null) {
                expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper3 = expo.modules.ReactActivityDelegateWrapper.this;
                this.label = 2;
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onResume$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {197}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onResume$1, reason: invalid class name and case insensitive filesystem */
    static final class C01301 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C01301(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01301> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01301(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01301) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onResume();
            java.util.List list = expo.modules.ReactActivityDelegateWrapper.this.reactActivityLifecycleListeners;
            expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
            java.util.Iterator it = list.iterator();
            while (it.hasNext()) {
                ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onResume(reactActivityDelegateWrapper.activity);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onResume() {
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01301(null), 1, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onPause$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {207}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onPause$1, reason: invalid class name and case insensitive filesystem */
    static final class C01281 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C01281(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01281> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01281(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01281) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            java.util.List list = expo.modules.ReactActivityDelegateWrapper.this.reactActivityLifecycleListeners;
            expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
            java.util.Iterator it = list.iterator();
            while (it.hasNext()) {
                ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onPause(reactActivityDelegateWrapper.activity);
            }
            if (expo.modules.ReactActivityDelegateWrapper.this.getDelayLoadAppHandler() != null) {
                try {
                    expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onPause();
                    kotlin.Unit unit = kotlin.Unit.INSTANCE;
                } catch (java.lang.Exception e) {
                    kotlin.coroutines.jvm.internal.Boxing.boxInt(android.util.Log.e(expo.modules.ReactActivityDelegateWrapper.TAG, "Exception occurred during onPause with delayed app loading", e));
                }
            } else {
                expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onPause();
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onPause() {
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01281(null), 1, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onUserLeaveHint$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {229}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onUserLeaveHint$1, reason: invalid class name and case insensitive filesystem */
    static final class C01311 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C01311(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01311> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01311(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01311) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            java.util.List list = expo.modules.ReactActivityDelegateWrapper.this.reactActivityLifecycleListeners;
            expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
            java.util.Iterator it = list.iterator();
            while (it.hasNext()) {
                ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onUserLeaveHint(reactActivityDelegateWrapper.activity);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onUserLeaveHint();
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onUserLeaveHint() {
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01311(null), 1, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onDestroy$1", f = "ReactActivityDelegateWrapper.kt", i = {0, 1}, l = {androidx.core.app.FrameMetricsAggregator.EVERY_DURATION, 242}, m = "invokeSuspend", n = {"$this$withLock_u24default$iv", "$this$withLock_u24default$iv"}, s = {"L$0", "L$0"})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onDestroy$1, reason: invalid class name and case insensitive filesystem */
    static final class C01271 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        java.lang.Object L$0;
        java.lang.Object L$1;
        int label;

        C01271(kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01271> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01271(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01271) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:24:0x0071 A[Catch: all -> 0x001b, LOOP:0: B:22:0x006b->B:24:0x0071, LOOP_END, TryCatch #1 {all -> 0x001b, blocks: (B:7:0x0017, B:21:0x0061, B:22:0x006b, B:24:0x0071, B:25:0x0081, B:27:0x0087, B:32:0x00a9, B:31:0x00a2, B:30:0x0092), top: B:41:0x0017, inners: #2 }] */
        /* JADX WARN: Removed duplicated region for block: B:31:0x00a2 A[Catch: all -> 0x001b, TryCatch #1 {all -> 0x001b, blocks: (B:7:0x0017, B:21:0x0061, B:22:0x006b, B:24:0x0071, B:25:0x0081, B:27:0x0087, B:32:0x00a9, B:31:0x00a2, B:30:0x0092), top: B:41:0x0017, inners: #2 }] */
        /* JADX WARN: Removed duplicated region for block: B:43:0x0087 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object invokeSuspend(java.lang.Object obj) throws java.lang.Throwable {
            kotlinx.coroutines.sync.Mutex mutex;
            expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper;
            kotlinx.coroutines.sync.Mutex mutex2;
            java.lang.Throwable th;
            expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper2;
            java.util.Iterator it;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            try {
                if (i == 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    mutex = expo.modules.ReactActivityDelegateWrapper.this.mutex;
                    reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
                    this.L$0 = mutex;
                    this.L$1 = reactActivityDelegateWrapper;
                    this.label = 1;
                    if (mutex.lock(null, this) != coroutine_suspended) {
                    }
                    return coroutine_suspended;
                }
                if (i != 1) {
                    if (i != 2) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    reactActivityDelegateWrapper2 = (expo.modules.ReactActivityDelegateWrapper) this.L$1;
                    mutex2 = (kotlinx.coroutines.sync.Mutex) this.L$0;
                    try {
                        kotlin.ResultKt.throwOnFailure(obj);
                        it = reactActivityDelegateWrapper2.reactActivityLifecycleListeners.iterator();
                        while (it.hasNext()) {
                            ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onDestroy(reactActivityDelegateWrapper2.activity);
                        }
                        if (reactActivityDelegateWrapper2.getDelayLoadAppHandler() == null) {
                            try {
                                reactActivityDelegateWrapper2.getDelegate().onDestroy();
                                kotlin.Unit unit = kotlin.Unit.INSTANCE;
                            } catch (java.lang.Exception e) {
                                kotlin.coroutines.jvm.internal.Boxing.boxInt(android.util.Log.e(expo.modules.ReactActivityDelegateWrapper.TAG, "Exception occurred during onDestroy with delayed app loading", e));
                            }
                        } else {
                            reactActivityDelegateWrapper2.getDelegate().onDestroy();
                        }
                        kotlin.Unit unit2 = kotlin.Unit.INSTANCE;
                        mutex2.unlock(null);
                        return kotlin.Unit.INSTANCE;
                    } catch (java.lang.Throwable th2) {
                        th = th2;
                        mutex2.unlock(null);
                        throw th;
                    }
                }
                reactActivityDelegateWrapper = (expo.modules.ReactActivityDelegateWrapper) this.L$1;
                kotlinx.coroutines.sync.Mutex mutex3 = (kotlinx.coroutines.sync.Mutex) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                mutex = mutex3;
                kotlinx.coroutines.CompletableDeferred completableDeferred = reactActivityDelegateWrapper.loadAppReady;
                this.L$0 = mutex;
                this.L$1 = reactActivityDelegateWrapper;
                this.label = 2;
                if (completableDeferred.await(this) != coroutine_suspended) {
                    reactActivityDelegateWrapper2 = reactActivityDelegateWrapper;
                    mutex2 = mutex;
                    it = reactActivityDelegateWrapper2.reactActivityLifecycleListeners.iterator();
                    while (it.hasNext()) {
                    }
                    if (reactActivityDelegateWrapper2.getDelayLoadAppHandler() == null) {
                    }
                    kotlin.Unit unit22 = kotlin.Unit.INSTANCE;
                    mutex2.unlock(null);
                    return kotlin.Unit.INSTANCE;
                }
                return coroutine_suspended;
            } catch (java.lang.Throwable th3) {
                mutex2 = mutex;
                th = th3;
                mutex2.unlock(null);
                throw th;
            }
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onDestroy() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(getApplicationCoroutineScope(), null, null, new expo.modules.ReactActivityDelegateWrapper.C01271(null), 3, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onActivityResult$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {278}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onActivityResult$1, reason: invalid class name and case insensitive filesystem */
    static final class C01241 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ android.content.Intent $data;
        final /* synthetic */ int $requestCode;
        final /* synthetic */ int $resultCode;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01241(int i, int i2, android.content.Intent intent, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01241> continuation) {
            super(2, continuation);
            this.$requestCode = i;
            this.$resultCode = i2;
            this.$data = intent;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01241(this.$requestCode, this.$resultCode, this.$data, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01241) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            if (!expo.modules.rncompatibility.ReactNativeFeatureFlags.INSTANCE.getEnableBridgelessArchitecture() && expo.modules.ReactActivityDelegateWrapper.this.getDelegate().getReactInstanceManager().getCurrentReactContext() == null) {
                final expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper = expo.modules.ReactActivityDelegateWrapper.this;
                final int i2 = this.$requestCode;
                final int i3 = this.$resultCode;
                final android.content.Intent intent = this.$data;
                expo.modules.ReactActivityDelegateWrapper.this.getDelegate().getReactInstanceManager().addReactInstanceEventListener(new com.facebook.react.ReactInstanceEventListener() { // from class: expo.modules.ReactActivityDelegateWrapper$onActivityResult$1$reactContextListener$1
                    @Override // com.facebook.react.ReactInstanceEventListener
                    public void onReactContextInitialized(com.facebook.react.bridge.ReactContext context) {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
                        reactActivityDelegateWrapper.getDelegate().getReactInstanceManager().removeReactInstanceEventListener(this);
                        reactActivityDelegateWrapper.getDelegate().onActivityResult(i2, i3, intent);
                    }
                });
                return kotlin.Unit.INSTANCE;
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onActivityResult(this.$requestCode, this.$resultCode, this.$data);
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01241(requestCode, resultCode, data, null), 1, null);
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        boolean z;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(event, "event");
        if (!this.loadAppReady.isCompleted()) {
            return false;
        }
        java.util.List<expo.modules.core.interfaces.ReactActivityHandler> list = this.reactActivityHandlers;
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
        java.util.Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(java.lang.Boolean.valueOf(((expo.modules.core.interfaces.ReactActivityHandler) it.next()).onKeyDown(keyCode, event)));
        }
        java.util.Iterator it2 = arrayList.iterator();
        loop1: while (true) {
            z = false;
            while (it2.hasNext()) {
                boolean zBooleanValue = ((java.lang.Boolean) it2.next()).booleanValue();
                if (z || zBooleanValue) {
                    z = true;
                }
            }
        }
        return z || this.delegate.onKeyDown(keyCode, event);
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        boolean z;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(event, "event");
        if (!this.loadAppReady.isCompleted()) {
            return false;
        }
        java.util.List<expo.modules.core.interfaces.ReactActivityHandler> list = this.reactActivityHandlers;
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
        java.util.Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(java.lang.Boolean.valueOf(((expo.modules.core.interfaces.ReactActivityHandler) it.next()).onKeyUp(keyCode, event)));
        }
        java.util.Iterator it2 = arrayList.iterator();
        loop1: while (true) {
            z = false;
            while (it2.hasNext()) {
                boolean zBooleanValue = ((java.lang.Boolean) it2.next()).booleanValue();
                if (z || zBooleanValue) {
                    z = true;
                }
            }
        }
        return z || this.delegate.onKeyUp(keyCode, event);
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public boolean onKeyLongPress(int keyCode, android.view.KeyEvent event) {
        boolean z;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(event, "event");
        if (!this.loadAppReady.isCompleted()) {
            return false;
        }
        java.util.List<expo.modules.core.interfaces.ReactActivityHandler> list = this.reactActivityHandlers;
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
        java.util.Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(java.lang.Boolean.valueOf(((expo.modules.core.interfaces.ReactActivityHandler) it.next()).onKeyLongPress(keyCode, event)));
        }
        java.util.Iterator it2 = arrayList.iterator();
        loop1: while (true) {
            z = false;
            while (it2.hasNext()) {
                boolean zBooleanValue = ((java.lang.Boolean) it2.next()).booleanValue();
                if (z || zBooleanValue) {
                    z = true;
                }
            }
        }
        return z || this.delegate.onKeyLongPress(keyCode, event);
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public boolean onBackPressed() {
        boolean z;
        if (!this.loadAppReady.isCompleted()) {
            return false;
        }
        java.util.List<expo.modules.core.interfaces.ReactActivityLifecycleListener> list = this.reactActivityLifecycleListeners;
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
        java.util.Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(java.lang.Boolean.valueOf(((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onBackPressed()));
        }
        java.util.Iterator it2 = arrayList.iterator();
        loop1: while (true) {
            z = false;
            while (it2.hasNext()) {
                boolean zBooleanValue = ((java.lang.Boolean) it2.next()).booleanValue();
                if (z || zBooleanValue) {
                    z = true;
                }
            }
        }
        return z || this.delegate.onBackPressed();
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public boolean onNewIntent(android.content.Intent intent) {
        boolean z;
        if (!this.loadAppReady.isCompleted()) {
            return false;
        }
        java.util.List<expo.modules.core.interfaces.ReactActivityLifecycleListener> list = this.reactActivityLifecycleListeners;
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list, 10));
        java.util.Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(java.lang.Boolean.valueOf(((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onNewIntent(intent)));
        }
        java.util.Iterator it2 = arrayList.iterator();
        loop1: while (true) {
            z = false;
            while (it2.hasNext()) {
                boolean zBooleanValue = ((java.lang.Boolean) it2.next()).booleanValue();
                if (z || zBooleanValue) {
                    z = true;
                }
            }
        }
        return z || this.delegate.onNewIntent(intent);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onWindowFocusChanged$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {352}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onWindowFocusChanged$1, reason: invalid class name and case insensitive filesystem */
    static final class C01321 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ boolean $hasFocus;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01321(boolean z, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01321> continuation) {
            super(2, continuation);
            this.$hasFocus = z;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01321(this.$hasFocus, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01321) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onWindowFocusChanged(this.$hasFocus);
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onWindowFocusChanged(boolean hasFocus) {
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01321(hasFocus, null), 1, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$requestPermissions$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {359}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$requestPermissions$1, reason: invalid class name and case insensitive filesystem */
    static final class C01331 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ com.facebook.react.modules.core.PermissionListener $listener;
        final /* synthetic */ java.lang.String[] $permissions;
        final /* synthetic */ int $requestCode;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01331(java.lang.String[] strArr, int i, com.facebook.react.modules.core.PermissionListener permissionListener, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01331> continuation) {
            super(2, continuation);
            this.$permissions = strArr;
            this.$requestCode = i;
            this.$listener = permissionListener;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01331(this.$permissions, this.$requestCode, this.$listener, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01331) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().requestPermissions(this.$permissions, this.$requestCode, this.$listener);
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void requestPermissions(java.lang.String[] permissions, int requestCode, com.facebook.react.modules.core.PermissionListener listener) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(permissions, "permissions");
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01331(permissions, requestCode, listener, null), 1, null);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onRequestPermissionsResult$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {366}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onRequestPermissionsResult$1, reason: invalid class name and case insensitive filesystem */
    static final class C01291 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int[] $grantResults;
        final /* synthetic */ java.lang.String[] $permissions;
        final /* synthetic */ int $requestCode;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01291(int i, java.lang.String[] strArr, int[] iArr, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01291> continuation) {
            super(2, continuation);
            this.$requestCode = i;
            this.$permissions = strArr;
            this.$grantResults = iArr;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01291(this.$requestCode, this.$permissions, this.$grantResults, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01291) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onRequestPermissionsResult(this.$requestCode, this.$permissions, this.$grantResults);
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onRequestPermissionsResult(int requestCode, java.lang.String[] permissions, int[] grantResults) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(permissions, "permissions");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(grantResults, "grantResults");
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01291(requestCode, permissions, grantResults, null), 1, null);
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected android.content.Context getContext() {
        return (android.content.Context) invokeDelegateMethod("getContext");
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected android.app.Activity getPlainActivity() {
        return (android.app.Activity) invokeDelegateMethod("getPlainActivity");
    }

    @Override // com.facebook.react.ReactActivityDelegate
    /* renamed from: isFabricEnabled */
    protected boolean getFabricEnabled() {
        return ((java.lang.Boolean) invokeDelegateMethod("isFabricEnabled")).booleanValue();
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected boolean isWideColorGamutEnabled() {
        return ((java.lang.Boolean) invokeDelegateMethod("isWideColorGamutEnabled")).booleanValue();
    }

    @Override // com.facebook.react.ReactActivityDelegate
    protected android.os.Bundle composeLaunchOptions() {
        return (android.os.Bundle) invokeDelegateMethod("composeLaunchOptions");
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$onConfigurationChanged$1", f = "ReactActivityDelegateWrapper.kt", i = {}, l = {393}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$onConfigurationChanged$1, reason: invalid class name and case insensitive filesystem */
    static final class C01251 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ android.content.res.Configuration $newConfig;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C01251(android.content.res.Configuration configuration, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.C01251> continuation) {
            super(2, continuation);
            this.$newConfig = configuration;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return expo.modules.ReactActivityDelegateWrapper.this.new C01251(this.$newConfig, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.C01251) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (expo.modules.ReactActivityDelegateWrapper.this.loadAppReady.await(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            expo.modules.ReactActivityDelegateWrapper.this.getDelegate().onConfigurationChanged(this.$newConfig);
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // com.facebook.react.ReactActivityDelegate
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(newConfig, "newConfig");
        launchLifecycleScopeWithLock$default(this, null, new expo.modules.ReactActivityDelegateWrapper.C01251(newConfig, null), 1, null);
    }

    private final <T> T invokeDelegateMethod(java.lang.String name) throws java.lang.NoSuchMethodException, java.lang.SecurityException {
        java.lang.reflect.Method declaredMethod = this.methodMap.get(name);
        if (declaredMethod == null) {
            declaredMethod = com.facebook.react.ReactActivityDelegate.class.getDeclaredMethod(name, new java.lang.Class[0]);
            declaredMethod.setAccessible(true);
            this.methodMap.put(name, declaredMethod);
        }
        kotlin.jvm.internal.Intrinsics.checkNotNull(declaredMethod);
        return (T) declaredMethod.invoke(this.delegate, new java.lang.Object[0]);
    }

    public final <T, A> T invokeDelegateMethod$expo_release(java.lang.String name, java.lang.Class<?>[] argTypes, A[] args) throws java.lang.NoSuchMethodException, java.lang.SecurityException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(name, "name");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(argTypes, "argTypes");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(args, "args");
        java.lang.reflect.Method declaredMethod = this.methodMap.get(name);
        if (declaredMethod == null) {
            declaredMethod = com.facebook.react.ReactActivityDelegate.class.getDeclaredMethod(name, (java.lang.Class[]) java.util.Arrays.copyOf(argTypes, argTypes.length));
            declaredMethod.setAccessible(true);
            this.methodMap.put(name, declaredMethod);
        }
        kotlin.jvm.internal.Intrinsics.checkNotNull(declaredMethod);
        return (T) declaredMethod.invoke(this.delegate, java.util.Arrays.copyOf(args, args.length));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object loadAppImpl(java.lang.String str, boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) throws java.lang.IllegalAccessException, java.lang.NoSuchFieldException, java.lang.NoSuchMethodException, java.lang.SecurityException, java.lang.IllegalArgumentException {
        expo.modules.ReactActivityDelegateWrapper.C01231 c01231;
        if (continuation instanceof expo.modules.ReactActivityDelegateWrapper.C01231) {
            c01231 = (expo.modules.ReactActivityDelegateWrapper.C01231) continuation;
            if ((c01231.label & Integer.MIN_VALUE) != 0) {
                c01231.label -= Integer.MIN_VALUE;
            } else {
                c01231 = new expo.modules.ReactActivityDelegateWrapper.C01231(continuation);
            }
        }
        java.lang.Object obj = c01231.result;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = c01231.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            android.view.ViewGroup viewGroup = (android.view.ViewGroup) kotlin.sequences.SequencesKt.firstOrNull(kotlin.sequences.SequencesKt.mapNotNull(kotlin.collections.CollectionsKt.asSequence(this.reactActivityHandlers), new kotlin.jvm.functions.Function1() { // from class: expo.modules.ReactActivityDelegateWrapper$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function1
                public final java.lang.Object invoke(java.lang.Object obj2) {
                    return expo.modules.ReactActivityDelegateWrapper.loadAppImpl$lambda$18(this.f$0, (expo.modules.core.interfaces.ReactActivityHandler) obj2);
                }
            }));
            if (viewGroup != null) {
                java.lang.reflect.Field declaredField = com.facebook.react.ReactActivityDelegate.class.getDeclaredField("mReactDelegate");
                declaredField.setAccessible(true);
                java.lang.Object obj2 = declaredField.get(this.delegate);
                kotlin.jvm.internal.Intrinsics.checkNotNull(obj2, "null cannot be cast to non-null type com.facebook.react.ReactDelegate");
                com.facebook.react.ReactDelegate reactDelegate = (com.facebook.react.ReactDelegate) obj2;
                if (str != null) {
                    reactDelegate.loadApp(str);
                    com.facebook.react.ReactRootView reactRootView = reactDelegate.getReactRootView();
                    android.view.ViewParent parent = reactRootView != null ? reactRootView.getParent() : null;
                    android.view.ViewGroup viewGroup2 = parent instanceof android.view.ViewGroup ? (android.view.ViewGroup) parent : null;
                    if (viewGroup2 != null) {
                        viewGroup2.removeView(reactRootView);
                    }
                    viewGroup.addView(reactRootView, -1);
                    this.activity.setContentView(viewGroup);
                    java.util.Iterator<T> it = this.reactActivityLifecycleListeners.iterator();
                    while (it.hasNext()) {
                        ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it.next()).onContentChanged(this.activity);
                    }
                    return kotlin.Unit.INSTANCE;
                }
                throw new java.lang.IllegalArgumentException("Required value was null.".toString());
            }
            if (z) {
                expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler delayLoadAppHandler = getDelayLoadAppHandler();
                c01231.L$0 = str;
                c01231.label = 1;
                if (awaitDelayLoadAppWhenReady(delayLoadAppHandler, c01231) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                invokeDelegateMethod$expo_release("loadApp", new java.lang.Class[]{java.lang.String.class}, new java.lang.String[]{str});
                java.util.Iterator<T> it2 = this.reactActivityLifecycleListeners.iterator();
                while (it2.hasNext()) {
                    ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it2.next()).onContentChanged(this.activity);
                }
                return kotlin.Unit.INSTANCE;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            str = (java.lang.String) c01231.L$0;
            kotlin.ResultKt.throwOnFailure(obj);
        }
        invokeDelegateMethod$expo_release("loadApp", new java.lang.Class[]{java.lang.String.class}, new java.lang.String[]{str});
        java.util.Iterator<T> it3 = this.reactActivityLifecycleListeners.iterator();
        while (it3.hasNext()) {
            ((expo.modules.core.interfaces.ReactActivityLifecycleListener) it3.next()).onContentChanged(this.activity);
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final android.view.ViewGroup loadAppImpl$lambda$18(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper, expo.modules.core.interfaces.ReactActivityHandler reactActivityHandler) {
        return reactActivityHandler.createReactRootViewContainer(reactActivityDelegateWrapper.activity);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final java.lang.Object awaitDelayLoadAppWhenReady(expo.modules.core.interfaces.ReactActivityHandler.DelayLoadAppHandler delayLoadAppHandler, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) throws java.lang.Throwable {
        if (delayLoadAppHandler == null) {
            return kotlin.Unit.INSTANCE;
        }
        kotlin.coroutines.SafeContinuation safeContinuation = new kotlin.coroutines.SafeContinuation(kotlin.coroutines.intrinsics.IntrinsicsKt.intercepted(continuation));
        final kotlin.coroutines.SafeContinuation safeContinuation2 = safeContinuation;
        delayLoadAppHandler.whenReady(new java.lang.Runnable() { // from class: expo.modules.ReactActivityDelegateWrapper$awaitDelayLoadAppWhenReady$2$1
            @Override // java.lang.Runnable
            public final void run() throws expo.modules.kotlin.exception.Exceptions.IncorrectThreadException {
                expo.modules.kotlin.Utils utils = expo.modules.kotlin.Utils.INSTANCE;
                if (java.lang.Thread.currentThread() == android.os.Looper.getMainLooper().getThread()) {
                    kotlin.coroutines.Continuation<kotlin.Unit> continuation2 = safeContinuation2;
                    kotlin.Result.Companion companion = kotlin.Result.INSTANCE;
                    continuation2.resumeWith(kotlin.Result.m955constructorimpl(kotlin.Unit.INSTANCE));
                } else {
                    java.lang.String name = java.lang.Thread.currentThread().getName();
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                    java.lang.String name2 = android.os.Looper.getMainLooper().getThread().getName();
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(name2, "getName(...)");
                    throw new expo.modules.kotlin.exception.Exceptions.IncorrectThreadException(name, name2);
                }
            }
        });
        java.lang.Object orThrow = safeContinuation.getOrThrow();
        if (orThrow == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            kotlin.coroutines.jvm.internal.DebugProbesKt.probeCoroutineSuspended(continuation);
        }
        return orThrow == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? orThrow : kotlin.Unit.INSTANCE;
    }

    static /* synthetic */ void launchLifecycleScopeWithLock$default(expo.modules.ReactActivityDelegateWrapper reactActivityDelegateWrapper, kotlinx.coroutines.CoroutineStart coroutineStart, kotlin.jvm.functions.Function2 function2, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            coroutineStart = kotlinx.coroutines.CoroutineStart.DEFAULT;
        }
        reactActivityDelegateWrapper.launchLifecycleScopeWithLock(coroutineStart, function2);
    }

    /* compiled from: ReactActivityDelegateWrapper.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "expo.modules.ReactActivityDelegateWrapper$launchLifecycleScopeWithLock$1", f = "ReactActivityDelegateWrapper.kt", i = {0, 0, 1}, l = {androidx.core.app.FrameMetricsAggregator.EVERY_DURATION, 485}, m = "invokeSuspend", n = {"$this$launch", "$this$withLock_u24default$iv", "$this$withLock_u24default$iv"}, s = {"L$0", "L$1", "L$0"})
    /* renamed from: expo.modules.ReactActivityDelegateWrapper$launchLifecycleScopeWithLock$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> $block;
        private /* synthetic */ java.lang.Object L$0;
        java.lang.Object L$1;
        java.lang.Object L$2;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        AnonymousClass1(kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> function2, kotlin.coroutines.Continuation<? super expo.modules.ReactActivityDelegateWrapper.AnonymousClass1> continuation) {
            super(2, continuation);
            this.$block = function2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            expo.modules.ReactActivityDelegateWrapper.AnonymousClass1 anonymousClass1 = expo.modules.ReactActivityDelegateWrapper.this.new AnonymousClass1(this.$block, continuation);
            anonymousClass1.L$0 = obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((expo.modules.ReactActivityDelegateWrapper.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) throws java.lang.Throwable {
            kotlinx.coroutines.CoroutineScope coroutineScope;
            kotlinx.coroutines.sync.Mutex mutex;
            kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> function2;
            kotlinx.coroutines.sync.Mutex mutex2;
            java.lang.Throwable th;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            try {
                if (i == 0) {
                    kotlin.ResultKt.throwOnFailure(obj);
                    coroutineScope = (kotlinx.coroutines.CoroutineScope) this.L$0;
                    mutex = expo.modules.ReactActivityDelegateWrapper.this.mutex;
                    function2 = this.$block;
                    this.L$0 = coroutineScope;
                    this.L$1 = mutex;
                    this.L$2 = function2;
                    this.label = 1;
                    if (mutex.lock(null, this) != coroutine_suspended) {
                    }
                    return coroutine_suspended;
                }
                if (i != 1) {
                    if (i != 2) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    mutex2 = (kotlinx.coroutines.sync.Mutex) this.L$0;
                    try {
                        kotlin.ResultKt.throwOnFailure(obj);
                        kotlin.Unit unit = kotlin.Unit.INSTANCE;
                        mutex2.unlock(null);
                        return kotlin.Unit.INSTANCE;
                    } catch (java.lang.Throwable th2) {
                        th = th2;
                        mutex2.unlock(null);
                        throw th;
                    }
                }
                function2 = (kotlin.jvm.functions.Function2) this.L$2;
                kotlinx.coroutines.sync.Mutex mutex3 = (kotlinx.coroutines.sync.Mutex) this.L$1;
                coroutineScope = (kotlinx.coroutines.CoroutineScope) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                mutex = mutex3;
                this.L$0 = mutex;
                this.L$1 = null;
                this.L$2 = null;
                this.label = 2;
                if (function2.invoke(coroutineScope, this) != coroutine_suspended) {
                    mutex2 = mutex;
                    kotlin.Unit unit2 = kotlin.Unit.INSTANCE;
                    mutex2.unlock(null);
                    return kotlin.Unit.INSTANCE;
                }
                return coroutine_suspended;
            } catch (java.lang.Throwable th3) {
                mutex2 = mutex;
                th = th3;
                mutex2.unlock(null);
                throw th;
            }
        }
    }

    private final void launchLifecycleScopeWithLock(kotlinx.coroutines.CoroutineStart start, kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> block) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.LifecycleOwnerKt.getLifecycleScope(this.activity), null, start, new expo.modules.ReactActivityDelegateWrapper.AnonymousClass1(block, null), 1, null);
    }

    public final void setLoadAppReadyForTesting$expo_release() {
        this.loadAppReady.complete(kotlin.Unit.INSTANCE);
    }
}
