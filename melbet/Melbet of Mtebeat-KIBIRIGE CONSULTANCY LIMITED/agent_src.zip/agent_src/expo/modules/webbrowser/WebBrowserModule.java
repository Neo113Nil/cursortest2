package expo.modules.webbrowser;

/* compiled from: WebBrowserModule.kt */
@kotlin.Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\b\u001a\u00020\tH\u0016J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0012\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001bH\u0002R\u0014\u0010\u0004\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\n\u001a\u00020\u000bX\u0080.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0080.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015¨\u0006\u001d"}, d2 = {"Lexpo/modules/webbrowser/WebBrowserModule;", "Lexpo/modules/kotlin/modules/Module;", "<init>", "()V", "context", "Landroid/content/Context;", "getContext", "()Landroid/content/Context;", "definition", "Lexpo/modules/kotlin/modules/ModuleDefinitionData;", "customTabsResolver", "Lexpo/modules/webbrowser/CustomTabsActivitiesHelper;", "getCustomTabsResolver$expo_web_browser_release", "()Lexpo/modules/webbrowser/CustomTabsActivitiesHelper;", "setCustomTabsResolver$expo_web_browser_release", "(Lexpo/modules/webbrowser/CustomTabsActivitiesHelper;)V", "connectionHelper", "Lexpo/modules/webbrowser/CustomTabsConnectionHelper;", "getConnectionHelper$expo_web_browser_release", "()Lexpo/modules/webbrowser/CustomTabsConnectionHelper;", "setConnectionHelper$expo_web_browser_release", "(Lexpo/modules/webbrowser/CustomTabsConnectionHelper;)V", "createCustomTabsIntent", "Landroidx/browser/customtabs/CustomTabsIntent;", "options", "Lexpo/modules/webbrowser/OpenBrowserOptions;", "givenOrPreferredPackageName", "", "packageName", "expo-web-browser_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class WebBrowserModule extends expo.modules.kotlin.modules.Module {
    public expo.modules.webbrowser.CustomTabsConnectionHelper connectionHelper;
    public expo.modules.webbrowser.CustomTabsActivitiesHelper customTabsResolver;

    /* JADX INFO: Access modifiers changed from: private */
    public final android.content.Context getContext() throws expo.modules.kotlin.exception.Exceptions.ReactContextLost {
        android.content.Context reactContext = getAppContext().getReactContext();
        if (reactContext != null) {
            return reactContext;
        }
        throw new expo.modules.kotlin.exception.Exceptions.ReactContextLost();
    }

    @Override // expo.modules.kotlin.modules.Module
    public expo.modules.kotlin.modules.ModuleDefinitionData definition() {
        expo.modules.kotlin.functions.UntypedAsyncFunctionComponent untypedAsyncFunctionComponent;
        expo.modules.kotlin.functions.AsyncFunctionWithPromiseComponent asyncFunctionWithPromiseComponent;
        expo.modules.kotlin.functions.UntypedAsyncFunctionComponent untypedAsyncFunctionComponent2;
        expo.modules.kotlin.functions.AsyncFunctionWithPromiseComponent asyncFunctionWithPromiseComponent2;
        expo.modules.kotlin.functions.UntypedAsyncFunctionComponent untypedAsyncFunctionComponent3;
        expo.modules.kotlin.functions.UntypedAsyncFunctionComponent untypedAsyncFunctionComponent4;
        expo.modules.kotlin.functions.UntypedAsyncFunctionComponent untypedAsyncFunctionComponent5;
        expo.modules.webbrowser.WebBrowserModule webBrowserModule = this;
        androidx.tracing.Trace.beginSection("[ExpoModulesCore] " + (webBrowserModule.getClass() + ".ModuleDefinition"));
        try {
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder = new expo.modules.kotlin.modules.ModuleDefinitionBuilder(webBrowserModule);
            moduleDefinitionBuilder.Name("ExpoWebBrowser");
            moduleDefinitionBuilder.getEventListeners().put(expo.modules.kotlin.events.EventName.MODULE_CREATE, new expo.modules.kotlin.events.BasicEventListener(expo.modules.kotlin.events.EventName.MODULE_CREATE, new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$OnCreate$1
                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                    invoke2();
                    return kotlin.Unit.INSTANCE;
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.setCustomTabsResolver$expo_web_browser_release(new expo.modules.webbrowser.CustomTabsActivitiesHelper(this.this$0.getAppContext()));
                    this.this$0.setConnectionHelper$expo_web_browser_release(new expo.modules.webbrowser.CustomTabsConnectionHelper(this.this$0.getContext()));
                }
            }));
            moduleDefinitionBuilder.getEventListeners().put(expo.modules.kotlin.events.EventName.ACTIVITY_DESTROYS, new expo.modules.kotlin.events.BasicEventListener(expo.modules.kotlin.events.EventName.ACTIVITY_DESTROYS, new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$OnActivityDestroys$1
                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                    invoke2();
                    return kotlin.Unit.INSTANCE;
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.getConnectionHelper$expo_web_browser_release().destroy();
                }
            }));
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder2 = moduleDefinitionBuilder;
            if (kotlin.jvm.internal.Intrinsics.areEqual(java.lang.String.class, expo.modules.kotlin.Promise.class)) {
                asyncFunctionWithPromiseComponent = new expo.modules.kotlin.functions.AsyncFunctionWithPromiseComponent("warmUpAsync", new expo.modules.kotlin.types.AnyType[0], new kotlin.jvm.functions.Function2<java.lang.Object[], expo.modules.kotlin.Promise, kotlin.Unit>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$1
                    /* JADX WARN: Multi-variable type inference failed */
                    /* renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(java.lang.Object[] objArr, expo.modules.kotlin.Promise promise) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<unused var>");
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(promise, "promise");
                        java.lang.String strGivenOrPreferredPackageName = this.this$0.givenOrPreferredPackageName((java.lang.String) promise);
                        this.this$0.getConnectionHelper$expo_web_browser_release().warmUp(strGivenOrPreferredPackageName);
                        androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("servicePackage", strGivenOrPreferredPackageName));
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(java.lang.Object[] objArr, expo.modules.kotlin.Promise promise) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        invoke2(objArr, promise);
                        return kotlin.Unit.INSTANCE;
                    }
                });
            } else {
                expo.modules.kotlin.types.TypeConverterProvider converters = moduleDefinitionBuilder2.getConverters();
                expo.modules.kotlin.types.AnyType[] anyTypeArr = new expo.modules.kotlin.types.AnyType[1];
                expo.modules.kotlin.types.AnyType anyType = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true));
                if (anyType == null) {
                    anyType = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$2
                        @Override // kotlin.jvm.functions.Function0
                        public final kotlin.reflect.KType invoke() {
                            return kotlin.jvm.internal.Reflection.nullableTypeOf(java.lang.String.class);
                        }
                    }), converters);
                }
                anyTypeArr[0] = anyType;
                kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle> function1 = new kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$3
                    @Override // kotlin.jvm.functions.Function1
                    public final android.os.Bundle invoke(java.lang.Object[] objArr) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<destruct>");
                        java.lang.String strGivenOrPreferredPackageName = this.this$0.givenOrPreferredPackageName((java.lang.String) objArr[0]);
                        this.this$0.getConnectionHelper$expo_web_browser_release().warmUp(strGivenOrPreferredPackageName);
                        return androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("servicePackage", strGivenOrPreferredPackageName));
                    }
                };
                if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Integer.TYPE)) {
                    if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Boolean.TYPE)) {
                        if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Double.TYPE)) {
                            if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Float.TYPE)) {
                                if (kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.String.class)) {
                                    untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.StringAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                                } else {
                                    untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.UntypedAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                                }
                            } else {
                                untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.FloatAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                            }
                        } else {
                            untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.DoubleAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                        }
                    } else {
                        untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.BoolAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                    }
                } else {
                    untypedAsyncFunctionComponent = new expo.modules.kotlin.functions.IntAsyncFunctionComponent("warmUpAsync", anyTypeArr, function1);
                }
                asyncFunctionWithPromiseComponent = untypedAsyncFunctionComponent;
            }
            moduleDefinitionBuilder2.getAsyncFunctions().put("warmUpAsync", asyncFunctionWithPromiseComponent);
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder3 = moduleDefinitionBuilder;
            if (kotlin.jvm.internal.Intrinsics.areEqual(java.lang.String.class, expo.modules.kotlin.Promise.class)) {
                asyncFunctionWithPromiseComponent2 = new expo.modules.kotlin.functions.AsyncFunctionWithPromiseComponent("coolDownAsync", new expo.modules.kotlin.types.AnyType[0], new kotlin.jvm.functions.Function2<java.lang.Object[], expo.modules.kotlin.Promise, kotlin.Unit>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$4
                    /* JADX WARN: Multi-variable type inference failed */
                    /* renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(java.lang.Object[] objArr, expo.modules.kotlin.Promise promise) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<unused var>");
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(promise, "promise");
                        java.lang.String strGivenOrPreferredPackageName = this.this$0.givenOrPreferredPackageName((java.lang.String) promise);
                        if (this.this$0.getConnectionHelper$expo_web_browser_release().coolDown(strGivenOrPreferredPackageName)) {
                            androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("servicePackage", strGivenOrPreferredPackageName));
                        } else {
                            new android.os.Bundle();
                        }
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ kotlin.Unit invoke(java.lang.Object[] objArr, expo.modules.kotlin.Promise promise) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        invoke2(objArr, promise);
                        return kotlin.Unit.INSTANCE;
                    }
                });
            } else {
                expo.modules.kotlin.types.TypeConverterProvider converters2 = moduleDefinitionBuilder3.getConverters();
                expo.modules.kotlin.types.AnyType[] anyTypeArr2 = new expo.modules.kotlin.types.AnyType[1];
                expo.modules.kotlin.types.AnyType anyType2 = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true));
                if (anyType2 == null) {
                    anyType2 = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$5
                        @Override // kotlin.jvm.functions.Function0
                        public final kotlin.reflect.KType invoke() {
                            return kotlin.jvm.internal.Reflection.nullableTypeOf(java.lang.String.class);
                        }
                    }), converters2);
                }
                anyTypeArr2[0] = anyType2;
                kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle> function12 = new kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$6
                    @Override // kotlin.jvm.functions.Function1
                    public final android.os.Bundle invoke(java.lang.Object[] objArr) throws expo.modules.webbrowser.NoPreferredPackageFound {
                        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<destruct>");
                        java.lang.String strGivenOrPreferredPackageName = this.this$0.givenOrPreferredPackageName((java.lang.String) objArr[0]);
                        if (this.this$0.getConnectionHelper$expo_web_browser_release().coolDown(strGivenOrPreferredPackageName)) {
                            return androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("servicePackage", strGivenOrPreferredPackageName));
                        }
                        return new android.os.Bundle();
                    }
                };
                if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Integer.TYPE)) {
                    if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Boolean.TYPE)) {
                        if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Double.TYPE)) {
                            if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Float.TYPE)) {
                                if (kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.String.class)) {
                                    untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.StringAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                                } else {
                                    untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.UntypedAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                                }
                            } else {
                                untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.FloatAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                            }
                        } else {
                            untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.DoubleAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                        }
                    } else {
                        untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.BoolAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                    }
                } else {
                    untypedAsyncFunctionComponent2 = new expo.modules.kotlin.functions.IntAsyncFunctionComponent("coolDownAsync", anyTypeArr2, function12);
                }
                asyncFunctionWithPromiseComponent2 = untypedAsyncFunctionComponent2;
            }
            moduleDefinitionBuilder3.getAsyncFunctions().put("coolDownAsync", asyncFunctionWithPromiseComponent2);
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder4 = moduleDefinitionBuilder;
            expo.modules.kotlin.types.TypeConverterProvider converters3 = moduleDefinitionBuilder4.getConverters();
            expo.modules.kotlin.types.AnyType[] anyTypeArr3 = new expo.modules.kotlin.types.AnyType[2];
            expo.modules.kotlin.types.AnyType anyType3 = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), false));
            if (anyType3 == null) {
                anyType3 = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), false, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$7
                    @Override // kotlin.jvm.functions.Function0
                    public final kotlin.reflect.KType invoke() {
                        return kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class);
                    }
                }), converters3);
            }
            anyTypeArr3[0] = anyType3;
            expo.modules.kotlin.types.AnyType anyType4 = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true));
            if (anyType4 == null) {
                anyType4 = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), true, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$8
                    @Override // kotlin.jvm.functions.Function0
                    public final kotlin.reflect.KType invoke() {
                        return kotlin.jvm.internal.Reflection.nullableTypeOf(java.lang.String.class);
                    }
                }), converters3);
            }
            anyTypeArr3[1] = anyType4;
            kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle> function13 = new kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$9
                @Override // kotlin.jvm.functions.Function1
                public final android.os.Bundle invoke(java.lang.Object[] objArr) throws expo.modules.webbrowser.NoPreferredPackageFound {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<destruct>");
                    java.lang.Object obj = objArr[0];
                    java.lang.String strGivenOrPreferredPackageName = this.this$0.givenOrPreferredPackageName((java.lang.String) objArr[1]);
                    expo.modules.webbrowser.CustomTabsConnectionHelper connectionHelper$expo_web_browser_release = this.this$0.getConnectionHelper$expo_web_browser_release();
                    android.net.Uri uri = android.net.Uri.parse((java.lang.String) obj);
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(uri, "parse(...)");
                    connectionHelper$expo_web_browser_release.mayInitWithUrl(strGivenOrPreferredPackageName, uri);
                    return androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("servicePackage", strGivenOrPreferredPackageName));
                }
            };
            if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Integer.TYPE)) {
                if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Boolean.TYPE)) {
                    if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Double.TYPE)) {
                        if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Float.TYPE)) {
                            if (kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.String.class)) {
                                untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.StringAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
                            } else {
                                untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.UntypedAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
                            }
                        } else {
                            untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.FloatAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
                        }
                    } else {
                        untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.DoubleAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
                    }
                } else {
                    untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.BoolAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
                }
            } else {
                untypedAsyncFunctionComponent3 = new expo.modules.kotlin.functions.IntAsyncFunctionComponent("mayInitWithUrlAsync", anyTypeArr3, function13);
            }
            moduleDefinitionBuilder4.getAsyncFunctions().put("mayInitWithUrlAsync", untypedAsyncFunctionComponent3);
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder5 = moduleDefinitionBuilder;
            expo.modules.kotlin.types.AnyType[] anyTypeArr4 = new expo.modules.kotlin.types.AnyType[0];
            kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle> function14 = new kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$10
                @Override // kotlin.jvm.functions.Function1
                public final android.os.Bundle invoke(java.lang.Object[] it) {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
                    java.util.ArrayList<java.lang.String> customTabsResolvingActivities = this.this$0.getCustomTabsResolver$expo_web_browser_release().getCustomTabsResolvingActivities();
                    java.util.ArrayList<java.lang.String> customTabsResolvingServices = this.this$0.getCustomTabsResolver$expo_web_browser_release().getCustomTabsResolvingServices();
                    java.lang.String preferredCustomTabsResolvingActivity = this.this$0.getCustomTabsResolver$expo_web_browser_release().getPreferredCustomTabsResolvingActivity(customTabsResolvingActivities);
                    java.lang.String defaultCustomTabsResolvingActivity = this.this$0.getCustomTabsResolver$expo_web_browser_release().getDefaultCustomTabsResolvingActivity();
                    if (!kotlin.collections.CollectionsKt.contains(customTabsResolvingActivities, defaultCustomTabsResolvingActivity)) {
                        defaultCustomTabsResolvingActivity = null;
                    }
                    android.os.Bundle bundle = new android.os.Bundle();
                    bundle.putStringArrayList("browserPackages", customTabsResolvingActivities);
                    bundle.putStringArrayList("servicePackages", customTabsResolvingServices);
                    bundle.putString("preferredBrowserPackage", preferredCustomTabsResolvingActivity);
                    bundle.putString("defaultBrowserPackage", defaultCustomTabsResolvingActivity);
                    return bundle;
                }
            };
            if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Integer.TYPE)) {
                if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Boolean.TYPE)) {
                    if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Double.TYPE)) {
                        if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Float.TYPE)) {
                            if (kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.String.class)) {
                                untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.StringAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
                            } else {
                                untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.UntypedAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
                            }
                        } else {
                            untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.FloatAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
                        }
                    } else {
                        untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.DoubleAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
                    }
                } else {
                    untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.BoolAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
                }
            } else {
                untypedAsyncFunctionComponent4 = new expo.modules.kotlin.functions.IntAsyncFunctionComponent("getCustomTabsSupportingBrowsersAsync", anyTypeArr4, function14);
            }
            moduleDefinitionBuilder5.getAsyncFunctions().put("getCustomTabsSupportingBrowsersAsync", untypedAsyncFunctionComponent4);
            expo.modules.kotlin.modules.ModuleDefinitionBuilder moduleDefinitionBuilder6 = moduleDefinitionBuilder;
            expo.modules.kotlin.types.TypeConverterProvider converters4 = moduleDefinitionBuilder6.getConverters();
            expo.modules.kotlin.types.AnyType[] anyTypeArr5 = new expo.modules.kotlin.types.AnyType[2];
            expo.modules.kotlin.types.AnyType anyType5 = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), false));
            if (anyType5 == null) {
                anyType5 = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(java.lang.String.class), false, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$11
                    @Override // kotlin.jvm.functions.Function0
                    public final kotlin.reflect.KType invoke() {
                        return kotlin.jvm.internal.Reflection.typeOf(java.lang.String.class);
                    }
                }), converters4);
            }
            anyTypeArr5[0] = anyType5;
            expo.modules.kotlin.types.AnyType anyType6 = expo.modules.kotlin.types.AnyTypeProvider.INSTANCE.getTypesMap().get(new kotlin.Pair(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(expo.modules.webbrowser.OpenBrowserOptions.class), false));
            if (anyType6 == null) {
                anyType6 = new expo.modules.kotlin.types.AnyType(new expo.modules.kotlin.types.LazyKType(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(expo.modules.webbrowser.OpenBrowserOptions.class), false, new kotlin.jvm.functions.Function0<kotlin.reflect.KType>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$12
                    @Override // kotlin.jvm.functions.Function0
                    public final kotlin.reflect.KType invoke() {
                        return kotlin.jvm.internal.Reflection.typeOf(expo.modules.webbrowser.OpenBrowserOptions.class);
                    }
                }), converters4);
            }
            anyTypeArr5[1] = anyType6;
            kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle> function15 = new kotlin.jvm.functions.Function1<java.lang.Object[], android.os.Bundle>() { // from class: expo.modules.webbrowser.WebBrowserModule$definition$lambda$10$$inlined$AsyncFunction$13
                @Override // kotlin.jvm.functions.Function1
                public final android.os.Bundle invoke(java.lang.Object[] objArr) throws expo.modules.webbrowser.NoMatchingActivityException, expo.modules.webbrowser.NoUrlProvidedException {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(objArr, "<destruct>");
                    java.lang.Object obj = objArr[0];
                    androidx.browser.customtabs.CustomTabsIntent customTabsIntentCreateCustomTabsIntent = this.this$0.createCustomTabsIntent((expo.modules.webbrowser.OpenBrowserOptions) objArr[1]);
                    customTabsIntentCreateCustomTabsIntent.intent.setData(android.net.Uri.parse((java.lang.String) obj));
                    if (!this.this$0.getCustomTabsResolver$expo_web_browser_release().canResolveIntent(customTabsIntentCreateCustomTabsIntent)) {
                        throw new expo.modules.webbrowser.NoMatchingActivityException();
                    }
                    this.this$0.getCustomTabsResolver$expo_web_browser_release().startCustomTabs(customTabsIntentCreateCustomTabsIntent);
                    return androidx.core.os.BundleKt.bundleOf(kotlin.TuplesKt.to("type", "opened"));
                }
            };
            if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Integer.TYPE)) {
                if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Boolean.TYPE)) {
                    if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Double.TYPE)) {
                        if (!kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.Float.TYPE)) {
                            if (kotlin.jvm.internal.Intrinsics.areEqual(android.os.Bundle.class, java.lang.String.class)) {
                                untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.StringAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
                            } else {
                                untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.UntypedAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
                            }
                        } else {
                            untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.FloatAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
                        }
                    } else {
                        untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.DoubleAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
                    }
                } else {
                    untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.BoolAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
                }
            } else {
                untypedAsyncFunctionComponent5 = new expo.modules.kotlin.functions.IntAsyncFunctionComponent("openBrowserAsync", anyTypeArr5, function15);
            }
            moduleDefinitionBuilder6.getAsyncFunctions().put("openBrowserAsync", untypedAsyncFunctionComponent5);
            return moduleDefinitionBuilder.buildModule();
        } finally {
            androidx.tracing.Trace.endSection();
        }
    }

    public final expo.modules.webbrowser.CustomTabsActivitiesHelper getCustomTabsResolver$expo_web_browser_release() {
        expo.modules.webbrowser.CustomTabsActivitiesHelper customTabsActivitiesHelper = this.customTabsResolver;
        if (customTabsActivitiesHelper != null) {
            return customTabsActivitiesHelper;
        }
        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("customTabsResolver");
        return null;
    }

    public final void setCustomTabsResolver$expo_web_browser_release(expo.modules.webbrowser.CustomTabsActivitiesHelper customTabsActivitiesHelper) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customTabsActivitiesHelper, "<set-?>");
        this.customTabsResolver = customTabsActivitiesHelper;
    }

    public final expo.modules.webbrowser.CustomTabsConnectionHelper getConnectionHelper$expo_web_browser_release() {
        expo.modules.webbrowser.CustomTabsConnectionHelper customTabsConnectionHelper = this.connectionHelper;
        if (customTabsConnectionHelper != null) {
            return customTabsConnectionHelper;
        }
        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("connectionHelper");
        return null;
    }

    public final void setConnectionHelper$expo_web_browser_release(expo.modules.webbrowser.CustomTabsConnectionHelper customTabsConnectionHelper) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customTabsConnectionHelper, "<set-?>");
        this.connectionHelper = customTabsConnectionHelper;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final androidx.browser.customtabs.CustomTabsIntent createCustomTabsIntent(expo.modules.webbrowser.OpenBrowserOptions options) {
        androidx.browser.customtabs.CustomTabsIntent.Builder builder = new androidx.browser.customtabs.CustomTabsIntent.Builder();
        java.lang.Integer toolbarColor = options.getToolbarColor();
        if (toolbarColor != null) {
            androidx.browser.customtabs.CustomTabColorSchemeParams customTabColorSchemeParamsBuild = new androidx.browser.customtabs.CustomTabColorSchemeParams.Builder().setSecondaryToolbarColor(toolbarColor.intValue()).build();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(customTabColorSchemeParamsBuild, "build(...)");
            builder.setDefaultColorSchemeParams(customTabColorSchemeParamsBuild);
        }
        java.lang.Integer secondaryToolbarColor = options.getSecondaryToolbarColor();
        if (secondaryToolbarColor != null) {
            androidx.browser.customtabs.CustomTabColorSchemeParams customTabColorSchemeParamsBuild2 = new androidx.browser.customtabs.CustomTabColorSchemeParams.Builder().setSecondaryToolbarColor(secondaryToolbarColor.intValue()).build();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(customTabColorSchemeParamsBuild2, "build(...)");
            builder.setDefaultColorSchemeParams(customTabColorSchemeParamsBuild2);
        }
        builder.setShowTitle(options.getShowTitle());
        if (options.getEnableDefaultShareMenuItem()) {
            builder.setShareState(1);
        }
        androidx.browser.customtabs.CustomTabsIntent customTabsIntentBuild = builder.build();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(customTabsIntentBuild, "build(...)");
        customTabsIntentBuild.intent.putExtra(androidx.browser.customtabs.CustomTabsIntent.EXTRA_ENABLE_URLBAR_HIDING, options.getEnableBarCollapsing());
        java.lang.String browserPackage = options.getBrowserPackage();
        if (!android.text.TextUtils.isEmpty(browserPackage)) {
            customTabsIntentBuild.intent.setPackage(browserPackage);
        }
        if (options.getShouldCreateTask()) {
            customTabsIntentBuild.intent.addFlags(268435456);
            if (!options.getShowInRecents()) {
                customTabsIntentBuild.intent.addFlags(8388608);
                customTabsIntentBuild.intent.addFlags(1073741824);
            }
        }
        return customTabsIntentBuild;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x000d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.String givenOrPreferredPackageName(java.lang.String packageName) throws expo.modules.webbrowser.NoPreferredPackageFound {
        if (packageName != null) {
            try {
                if (packageName.length() <= 0) {
                    packageName = null;
                }
            } catch (expo.modules.core.errors.CurrentActivityNotFoundException unused) {
                throw new expo.modules.webbrowser.NoPreferredPackageFound();
            } catch (expo.modules.webbrowser.PackageManagerNotFoundException unused2) {
                throw new expo.modules.webbrowser.NoPreferredPackageFound();
            }
        }
        if (packageName == null) {
            packageName = getCustomTabsResolver$expo_web_browser_release().getPreferredCustomTabsResolvingActivity(null);
        }
        if (packageName != null) {
            java.lang.String str = packageName.length() > 0 ? packageName : null;
            if (str != null) {
                return str;
            }
        }
        throw new expo.modules.webbrowser.NoPreferredPackageFound();
    }
}
