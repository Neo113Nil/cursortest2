package com.pairip.application;

/* loaded from: classes2.dex */
public class Application extends com.messagettothpuvbluc.app.MainApplication {
    @Override // android.content.ContextWrapper
    protected void attachBaseContext(android.content.Context context) {
        com.pairip.licensecheck.LicenseClient.checkLicense(context);
        super.attachBaseContext(context);
    }
}
