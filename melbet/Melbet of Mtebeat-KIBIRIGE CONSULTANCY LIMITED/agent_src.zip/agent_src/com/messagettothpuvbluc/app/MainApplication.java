package com.messagettothpuvbluc.app;

/* compiled from: MainApplication.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\b\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016R\u0014\u0010\u0005\u001a\u00020\u0006X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\f¨\u0006\u0012"}, d2 = {"Lcom/messagettothpuvbluc/app/MainApplication;", "Landroid/app/Application;", "Lcom/facebook/react/ReactApplication;", "<init>", "()V", "reactNativeHost", "Lcom/facebook/react/ReactNativeHost;", "getReactNativeHost", "()Lcom/facebook/react/ReactNativeHost;", "reactHost", "Lcom/facebook/react/ReactHost;", "getReactHost", "()Lcom/facebook/react/ReactHost;", "onCreate", "", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public class MainApplication extends android.app.Application implements com.facebook.react.ReactApplication {
    private final com.facebook.react.ReactNativeHost reactNativeHost = new expo.modules.ReactNativeHostWrapper(this, new com.facebook.react.defaults.DefaultReactNativeHost(this) { // from class: com.messagettothpuvbluc.app.MainApplication$reactNativeHost$1
        private final boolean isNewArchEnabled;

        @Override // com.facebook.react.ReactNativeHost
        public boolean getUseDeveloperSupport() {
            return false;
        }

        {
            super(this);
            this.isNewArchEnabled = true;
        }

        @Override // com.facebook.react.ReactNativeHost
        protected java.util.List<com.facebook.react.ReactPackage> getPackages() {
            java.util.ArrayList<com.facebook.react.ReactPackage> packages = new com.facebook.react.PackageList(this).getPackages();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(packages, "apply(...)");
            return packages;
        }

        @Override // com.facebook.react.ReactNativeHost
        protected java.lang.String getJSMainModuleName() {
            return ".expo/.virtual-metro-entry";
        }

        @Override // com.facebook.react.defaults.DefaultReactNativeHost
        /* renamed from: isNewArchEnabled, reason: from getter */
        protected boolean getIsNewArchEnabled() {
            return this.isNewArchEnabled;
        }
    });

    @Override // com.facebook.react.ReactApplication
    public com.facebook.react.ReactNativeHost getReactNativeHost() {
        return this.reactNativeHost;
    }

    @Override // com.facebook.react.ReactApplication
    public com.facebook.react.ReactHost getReactHost() {
        expo.modules.ReactNativeHostWrapper.Companion companion = expo.modules.ReactNativeHostWrapper.INSTANCE;
        android.content.Context applicationContext = getApplicationContext();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
        return companion.createReactHost(applicationContext, getReactNativeHost());
    }

    @Override // android.app.Application
    public void onCreate() {
        com.facebook.react.common.ReleaseLevel releaseLevelValueOf;
        super.onCreate();
        com.facebook.react.defaults.DefaultNewArchitectureEntryPoint defaultNewArchitectureEntryPoint = com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.INSTANCE;
        try {
            java.lang.String upperCase = com.messagettothpuvbluc.app.BuildConfig.REACT_NATIVE_RELEASE_LEVEL.toUpperCase(java.util.Locale.ROOT);
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            releaseLevelValueOf = com.facebook.react.common.ReleaseLevel.valueOf(upperCase);
        } catch (java.lang.IllegalArgumentException unused) {
            releaseLevelValueOf = com.facebook.react.common.ReleaseLevel.STABLE;
        }
        defaultNewArchitectureEntryPoint.setReleaseLevel(releaseLevelValueOf);
        com.facebook.react.ReactNativeApplicationEntryPoint.loadReactNative(this);
        expo.modules.ApplicationLifecycleDispatcher.onApplicationCreate(this);
    }

    @Override // android.app.Application, android.content.ComponentCallbacks
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        expo.modules.ApplicationLifecycleDispatcher.onConfigurationChanged(this, newConfig);
    }
}
