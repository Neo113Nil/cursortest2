package com.messagettothpuvbluc.app;

/* loaded from: classes3.dex */
public final class BuildConfig {
    public static final java.lang.String APPLICATION_ID = "com.messagettothpuvbluc.app";
    public static final java.lang.String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final boolean IS_EDGE_TO_EDGE_ENABLED = true;
    public static final boolean IS_HERMES_ENABLED = true;
    public static final boolean IS_NEW_ARCHITECTURE_ENABLED = true;
    public static final java.lang.String REACT_NATIVE_RELEASE_LEVEL = "stable";
    public static final int VERSION_CODE = 2;
    public static final java.lang.String VERSION_NAME = "1.0.1";
}
