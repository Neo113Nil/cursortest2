package com.reactnativecommunity.webview;

/* loaded from: classes3.dex */
public class RNCWebChromeClient extends android.webkit.WebChromeClient implements com.facebook.react.bridge.LifecycleEventListener {
    protected static final int COMMON_PERMISSION_REQUEST = 3;
    protected static final android.widget.FrameLayout.LayoutParams FULLSCREEN_LAYOUT_PARAMS = new android.widget.FrameLayout.LayoutParams(-1, -1, 17);
    protected static final int FULLSCREEN_SYSTEM_UI_VISIBILITY = 7942;
    protected android.webkit.GeolocationPermissions.Callback geolocationPermissionCallback;
    protected java.lang.String geolocationPermissionOrigin;
    protected java.util.List<java.lang.String> grantedPermissions;
    protected android.webkit.WebChromeClient.CustomViewCallback mCustomViewCallback;
    protected android.view.View mVideoView;
    protected com.reactnativecommunity.webview.RNCWebView mWebView;
    protected android.webkit.PermissionRequest permissionRequest;
    protected boolean permissionsRequestShown = false;
    protected java.util.List<java.lang.String> pendingPermissions = new java.util.ArrayList();
    protected com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter progressChangedFilter = null;
    protected boolean mAllowsProtectedMedia = false;
    protected boolean mHasOnOpenWindowEvent = false;
    private com.facebook.react.modules.core.PermissionListener webviewPermissionsListener = new com.facebook.react.modules.core.PermissionListener() { // from class: com.reactnativecommunity.webview.RNCWebChromeClient$$ExternalSyntheticLambda0
        @Override // com.facebook.react.modules.core.PermissionListener
        public final boolean onRequestPermissionsResult(int i, java.lang.String[] strArr, int[] iArr) {
            return this.f$0.lambda$new$0(i, strArr, iArr);
        }
    };

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostDestroy() {
    }

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostPause() {
    }

    public RNCWebChromeClient(com.reactnativecommunity.webview.RNCWebView rNCWebView) {
        this.mWebView = rNCWebView;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onCreateWindow(final android.webkit.WebView webView, boolean z, boolean z2, android.os.Message message) {
        android.webkit.WebView webView2 = new android.webkit.WebView(webView.getContext());
        if (this.mHasOnOpenWindowEvent) {
            webView2.setWebViewClient(new android.webkit.WebViewClient() { // from class: com.reactnativecommunity.webview.RNCWebChromeClient.1
                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(android.webkit.WebView webView3, java.lang.String str) {
                    com.facebook.react.bridge.WritableMap writableMapCreateMap = com.facebook.react.bridge.Arguments.createMap();
                    writableMapCreateMap.putString("targetUrl", str);
                    android.webkit.WebView webView4 = webView;
                    ((com.reactnativecommunity.webview.RNCWebView) webView4).dispatchEvent(webView4, new com.reactnativecommunity.webview.events.TopOpenWindowEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView), writableMapCreateMap));
                    return true;
                }
            });
        }
        ((android.webkit.WebView.WebViewTransport) message.obj).setWebView(webView2);
        message.sendToTarget();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onConsoleMessage(android.webkit.ConsoleMessage consoleMessage) {
        if (com.facebook.react.common.build.ReactBuildConfig.DEBUG) {
            return super.onConsoleMessage(consoleMessage);
        }
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public void onProgressChanged(android.webkit.WebView webView, int i) {
        super.onProgressChanged(webView, i);
        java.lang.String url = webView.getUrl();
        if (this.progressChangedFilter.isWaitingForCommandLoadUrl()) {
            return;
        }
        int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
        com.facebook.react.bridge.WritableMap writableMapCreateMap = com.facebook.react.bridge.Arguments.createMap();
        writableMapCreateMap.putDouble("target", reactTagFromWebView);
        writableMapCreateMap.putString("title", webView.getTitle());
        writableMapCreateMap.putString("url", url);
        writableMapCreateMap.putBoolean("canGoBack", webView.canGoBack());
        writableMapCreateMap.putBoolean("canGoForward", webView.canGoForward());
        writableMapCreateMap.putDouble("progress", i / 100.0f);
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag(this.mWebView.getThemedReactContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopLoadingProgressEvent(reactTagFromWebView, writableMapCreateMap));
    }

    @Override // android.webkit.WebChromeClient
    public void onPermissionRequest(android.webkit.PermissionRequest permissionRequest) {
        this.grantedPermissions = new java.util.ArrayList();
        java.util.ArrayList arrayList = new java.util.ArrayList();
        java.lang.String[] resources = permissionRequest.getResources();
        int length = resources.length;
        int i = 0;
        while (true) {
            java.lang.String str = null;
            if (i >= length) {
                break;
            }
            java.lang.String str2 = resources[i];
            if (str2.equals("android.webkit.resource.AUDIO_CAPTURE")) {
                str = "android.permission.RECORD_AUDIO";
            } else if (str2.equals("android.webkit.resource.VIDEO_CAPTURE")) {
                str = "android.permission.CAMERA";
            } else if (str2.equals("android.webkit.resource.PROTECTED_MEDIA_ID")) {
                if (!this.mAllowsProtectedMedia) {
                    str = "android.webkit.resource.PROTECTED_MEDIA_ID";
                } else {
                    this.grantedPermissions.add(str2);
                }
            }
            if (str != null) {
                if (androidx.core.content.ContextCompat.checkSelfPermission(this.mWebView.getThemedReactContext(), str) == 0) {
                    this.grantedPermissions.add(str2);
                } else {
                    arrayList.add(str);
                }
            }
            i++;
        }
        if (arrayList.isEmpty()) {
            permissionRequest.grant((java.lang.String[]) this.grantedPermissions.toArray(new java.lang.String[0]));
            this.grantedPermissions = null;
        } else {
            this.permissionRequest = permissionRequest;
            requestPermissions(arrayList);
        }
    }

    @Override // android.webkit.WebChromeClient
    public void onGeolocationPermissionsShowPrompt(java.lang.String str, android.webkit.GeolocationPermissions.Callback callback) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(this.mWebView.getThemedReactContext(), "android.permission.ACCESS_FINE_LOCATION") != 0) {
            this.geolocationPermissionCallback = callback;
            this.geolocationPermissionOrigin = str;
            requestPermissions(java.util.Collections.singletonList("android.permission.ACCESS_FINE_LOCATION"));
            return;
        }
        callback.invoke(str, true, false);
    }

    private com.facebook.react.modules.core.PermissionAwareActivity getPermissionAwareActivity() {
        android.content.ComponentCallbacks2 currentActivity = this.mWebView.getThemedReactContext().getCurrentActivity();
        if (currentActivity == null) {
            throw new java.lang.IllegalStateException("Tried to use permissions API while not attached to an Activity.");
        }
        if (!(currentActivity instanceof com.facebook.react.modules.core.PermissionAwareActivity)) {
            throw new java.lang.IllegalStateException("Tried to use permissions API but the host Activity doesn't implement PermissionAwareActivity.");
        }
        return (com.facebook.react.modules.core.PermissionAwareActivity) currentActivity;
    }

    private synchronized void requestPermissions(java.util.List<java.lang.String> list) {
        if (this.permissionsRequestShown) {
            this.pendingPermissions.addAll(list);
            return;
        }
        com.facebook.react.modules.core.PermissionAwareActivity permissionAwareActivity = getPermissionAwareActivity();
        this.permissionsRequestShown = true;
        permissionAwareActivity.requestPermissions((java.lang.String[]) list.toArray(new java.lang.String[0]), 3, this.webviewPermissionsListener);
        this.pendingPermissions.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean lambda$new$0(int i, java.lang.String[] strArr, int[] iArr) {
        android.webkit.PermissionRequest permissionRequest;
        java.util.List<java.lang.String> list;
        java.util.List<java.lang.String> list2;
        java.util.List<java.lang.String> list3;
        java.util.List<java.lang.String> list4;
        android.webkit.GeolocationPermissions.Callback callback;
        java.lang.String str;
        this.permissionsRequestShown = false;
        boolean z = false;
        for (int i2 = 0; i2 < strArr.length; i2++) {
            java.lang.String str2 = strArr[i2];
            boolean z2 = iArr[i2] == 0;
            if (str2.equals("android.permission.ACCESS_FINE_LOCATION") && (callback = this.geolocationPermissionCallback) != null && (str = this.geolocationPermissionOrigin) != null) {
                if (z2) {
                    callback.invoke(str, true, false);
                } else {
                    callback.invoke(str, false, false);
                }
                this.geolocationPermissionCallback = null;
                this.geolocationPermissionOrigin = null;
            }
            if (str2.equals("android.permission.RECORD_AUDIO")) {
                if (z2 && (list4 = this.grantedPermissions) != null) {
                    list4.add("android.webkit.resource.AUDIO_CAPTURE");
                }
                z = true;
            }
            if (str2.equals("android.permission.CAMERA")) {
                if (z2 && (list3 = this.grantedPermissions) != null) {
                    list3.add("android.webkit.resource.VIDEO_CAPTURE");
                }
                z = true;
            }
            if (str2.equals("android.webkit.resource.PROTECTED_MEDIA_ID")) {
                if (z2 && (list2 = this.grantedPermissions) != null) {
                    list2.add("android.webkit.resource.PROTECTED_MEDIA_ID");
                }
                z = true;
            }
        }
        if (z && (permissionRequest = this.permissionRequest) != null && (list = this.grantedPermissions) != null) {
            permissionRequest.grant((java.lang.String[]) list.toArray(new java.lang.String[0]));
            this.permissionRequest = null;
            this.grantedPermissions = null;
        }
        if (this.pendingPermissions.isEmpty()) {
            return true;
        }
        requestPermissions(this.pendingPermissions);
        return false;
    }

    protected void openFileChooser(android.webkit.ValueCallback<android.net.Uri> valueCallback, java.lang.String str) {
        ((com.reactnativecommunity.webview.RNCWebViewModule) this.mWebView.getThemedReactContext().getNativeModule(com.reactnativecommunity.webview.RNCWebViewModule.class)).startPhotoPickerIntent(valueCallback, str);
    }

    protected void openFileChooser(android.webkit.ValueCallback<android.net.Uri> valueCallback) {
        ((com.reactnativecommunity.webview.RNCWebViewModule) this.mWebView.getThemedReactContext().getNativeModule(com.reactnativecommunity.webview.RNCWebViewModule.class)).startPhotoPickerIntent(valueCallback, "");
    }

    protected void openFileChooser(android.webkit.ValueCallback<android.net.Uri> valueCallback, java.lang.String str, java.lang.String str2) {
        ((com.reactnativecommunity.webview.RNCWebViewModule) this.mWebView.getThemedReactContext().getNativeModule(com.reactnativecommunity.webview.RNCWebViewModule.class)).startPhotoPickerIntent(valueCallback, str);
    }

    @Override // android.webkit.WebChromeClient
    public boolean onShowFileChooser(android.webkit.WebView webView, android.webkit.ValueCallback<android.net.Uri[]> valueCallback, android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {
        return ((com.reactnativecommunity.webview.RNCWebViewModule) this.mWebView.getThemedReactContext().getNativeModule(com.reactnativecommunity.webview.RNCWebViewModule.class)).startPhotoPickerIntent(valueCallback, fileChooserParams.getAcceptTypes(), fileChooserParams.getMode() == 1, fileChooserParams.isCaptureEnabled());
    }

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostResume() {
        android.view.View view = this.mVideoView;
        if (view == null || view.getSystemUiVisibility() == FULLSCREEN_SYSTEM_UI_VISIBILITY) {
            return;
        }
        this.mVideoView.setSystemUiVisibility(FULLSCREEN_SYSTEM_UI_VISIBILITY);
    }

    protected android.view.ViewGroup getRootView() {
        return (android.view.ViewGroup) this.mWebView.getThemedReactContext().getCurrentActivity().findViewById(android.R.id.content);
    }

    public void setProgressChangedFilter(com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter progressChangedFilter) {
        this.progressChangedFilter = progressChangedFilter;
    }

    public void setAllowsProtectedMedia(boolean z) {
        this.mAllowsProtectedMedia = z;
    }

    public void setHasOnOpenWindowEvent(boolean z) {
        this.mHasOnOpenWindowEvent = z;
    }
}
