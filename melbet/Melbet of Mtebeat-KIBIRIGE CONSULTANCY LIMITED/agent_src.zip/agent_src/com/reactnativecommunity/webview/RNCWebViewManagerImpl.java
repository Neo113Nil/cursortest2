package com.reactnativecommunity.webview;

/* compiled from: RNCWebViewManagerImpl.kt */
@kotlin.Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\u0017\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b;\u0018\u0000 \u0083\u00012\u00020\u0001:\u0002\u0083\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cJ\u000e\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001b\u001a\u00020\u001cJ\u0016\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001f\u001a\u00020\u001aJ\u0010\u0010 \u001a\u00020!2\u0006\u0010\u001f\u001a\u00020\u001aH\u0002J\u0018\u0010\"\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010$\u001a\u0004\u0018\u00010\u0007J\u0018\u0010%\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010&\u001a\u0004\u0018\u00010\u0007J\u0010\u0010'\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001eH\u0002J\u0018\u0010(\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010)\u001a\u0004\u0018\u00010\u0010J\u000e\u0010*\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001eJ\u000e\u0010+\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001eJ\u0014\u0010D\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020-\u0018\u00010EJ\u001e\u0010F\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010G\u001a\u00020\u00072\u0006\u0010H\u001a\u00020IJ\u0018\u0010J\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010K\u001a\u0004\u0018\u00010\u0007J\u0016\u0010L\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010M\u001a\u00020\u0003J\n\u0010N\u001a\u0004\u0018\u00010\u0007H\u0002J\n\u0010O\u001a\u0004\u0018\u00010\u0007H\u0002J\u0018\u0010P\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010Q\u001a\u0004\u0018\u00010\u0010J\u001a\u0010R\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010Q\u001a\u0004\u0018\u00010\u0010H\u0002J\u0018\u0010S\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010T\u001a\u0004\u0018\u00010\u0007J\u0016\u0010U\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0016\u0010W\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0018\u0010X\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010Y\u001a\u0004\u0018\u00010\u0007J\u0018\u0010Z\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010T\u001a\u0004\u0018\u00010\u0007J\u0016\u0010[\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010\\\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0018\u0010]\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010T\u001a\u0004\u0018\u00010\u0007J\u0016\u0010^\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010_\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010`\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010a\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010b\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010c\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010d\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0016\u0010e\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010f\u001a\u00020\u0003J\u0016\u0010g\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010h\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0018\u0010i\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010j\u001a\u0004\u0018\u00010\u0007J\u0018\u0010k\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010l\u001a\u0004\u0018\u00010\u0007J\u0016\u0010m\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0010\u0010n\u001a\u00020!2\b\u0010T\u001a\u0004\u0018\u00010\u0007J\u0016\u0010o\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0016\u0010p\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0010\u0010q\u001a\u00020!2\b\u0010T\u001a\u0004\u0018\u00010\u0007J\u0016\u0010r\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010s\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020-J\u0016\u0010t\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0018\u0010u\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010T\u001a\u0004\u0018\u00010IJ\u0016\u0010v\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0018\u0010w\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\b\u0010x\u001a\u0004\u0018\u00010\u0007J\u0016\u0010y\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010z\u001a\u00020\u0003J\u0016\u0010{\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010|\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010}\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010~\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020\u0003J\u0016\u0010\u007f\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010T\u001a\u00020-J\u0017\u0010\u0080\u0001\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0017\u0010\u0081\u0001\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003J\u0017\u0010\u0082\u0001\u001a\u00020!2\u0006\u0010#\u001a\u00020\u001e2\u0006\u0010V\u001a\u00020\u0003R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0007X\u0082D¢\u0006\u0002\n\u0000R\u0014\u0010,\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b.\u0010/R\u0014\u00100\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b1\u0010/R\u0014\u00102\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b3\u0010/R\u0014\u00104\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b5\u0010/R\u0014\u00106\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b7\u0010/R\u0014\u00108\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b9\u0010/R\u0014\u0010:\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b;\u0010/R\u0014\u0010<\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b=\u0010/R\u0014\u0010>\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b?\u0010/R\u0014\u0010@\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\bA\u0010/R\u0014\u0010B\u001a\u00020-X\u0086D¢\u0006\b\n\u0000\u001a\u0004\bC\u0010/¨\u0006\u0084\u0001"}, d2 = {"Lcom/reactnativecommunity/webview/RNCWebViewManagerImpl;", "", "newArch", "", "<init>", "(Z)V", "TAG", "", "mWebViewConfig", "Lcom/reactnativecommunity/webview/RNCWebViewConfig;", "mAllowsFullscreenVideo", "mAllowsProtectedMedia", "mDownloadingMessage", "mLackPermissionToDownloadMessage", "mHasOnOpenWindowEvent", "mPendingSource", "Lcom/facebook/react/bridge/ReadableMap;", "mUserAgent", "mUserAgentWithApplicationName", "HTML_ENCODING", "HTML_MIME_TYPE", "HTTP_METHOD_POST", "BLANK_URL", "DEFAULT_DOWNLOADING_MESSAGE", "DEFAULT_LACK_PERMISSION_TO_DOWNLOAD_MESSAGE", "createRNCWebViewInstance", "Lcom/reactnativecommunity/webview/RNCWebView;", "context", "Lcom/facebook/react/uimanager/ThemedReactContext;", "createViewInstance", "Lcom/reactnativecommunity/webview/RNCWebViewWrapper;", "webView", "setupWebChromeClient", "", "setUserAgent", "viewWrapper", "userAgent", "setApplicationNameForUserAgent", "applicationName", "setUserAgentString", "setBasicAuthCredential", "credential", "onAfterUpdateTransaction", "onDropViewInstance", "COMMAND_GO_BACK", "", "getCOMMAND_GO_BACK", "()I", "COMMAND_GO_FORWARD", "getCOMMAND_GO_FORWARD", "COMMAND_RELOAD", "getCOMMAND_RELOAD", "COMMAND_STOP_LOADING", "getCOMMAND_STOP_LOADING", "COMMAND_POST_MESSAGE", "getCOMMAND_POST_MESSAGE", "COMMAND_INJECT_JAVASCRIPT", "getCOMMAND_INJECT_JAVASCRIPT", "COMMAND_LOAD_URL", "getCOMMAND_LOAD_URL", "COMMAND_FOCUS", "getCOMMAND_FOCUS", "COMMAND_CLEAR_FORM_DATA", "getCOMMAND_CLEAR_FORM_DATA", "COMMAND_CLEAR_CACHE", "getCOMMAND_CLEAR_CACHE", "COMMAND_CLEAR_HISTORY", "getCOMMAND_CLEAR_HISTORY", "getCommandsMap", "", "receiveCommand", "commandId", "args", "Lcom/facebook/react/bridge/ReadableArray;", "setMixedContentMode", "mixedContentMode", "setAllowUniversalAccessFromFileURLs", "allow", "getDownloadingMessageOrDefault", "getLackPermissionToDownloadMessageOrDefault", "setSource", "source", "loadSource", "setMessagingModuleName", "value", "setCacheEnabled", "enabled", "setIncognito", "setInjectedJavaScript", "injectedJavaScript", "setInjectedJavaScriptBeforeContentLoaded", "setInjectedJavaScriptForMainFrameOnly", "setInjectedJavaScriptBeforeContentLoadedForMainFrameOnly", "setInjectedJavaScriptObject", "setJavaScriptCanOpenWindowsAutomatically", "setShowsVerticalScrollIndicator", "setShowsHorizontalScrollIndicator", "setMessagingEnabled", "setMediaPlaybackRequiresUserAction", "setHasOnScroll", "setJavaScriptEnabled", "setAllowFileAccess", "allowFileAccess", "setAllowFileAccessFromFileURLs", "setAllowsFullscreenVideo", "setAndroidLayerType", "layerTypeString", "setCacheMode", "cacheModeString", "setDomStorageEnabled", "setDownloadingMessage", "setForceDarkOn", "setGeolocationEnabled", "setLackPermissionToDownloadMessage", "setHasOnOpenWindowEvent", "setMinimumFontSize", "setAllowsProtectedMedia", "setMenuCustomItems", "setNestedScrollEnabled", "setOverScrollMode", "overScrollModeString", "setSaveFormDataDisabled", "disabled", "setScalesPageToFit", "setSetBuiltInZoomControls", "setSetDisplayZoomControls", "setSetSupportMultipleWindows", "setTextZoom", "setThirdPartyCookiesEnabled", "setWebviewDebuggingEnabled", "setPaymentRequestEnabled", "Companion", "react-native-webview_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class RNCWebViewManagerImpl {
    public static final java.lang.String NAME = "RNCWebView";
    private final java.lang.String BLANK_URL;
    private final int COMMAND_CLEAR_CACHE;
    private final int COMMAND_CLEAR_FORM_DATA;
    private final int COMMAND_CLEAR_HISTORY;
    private final int COMMAND_FOCUS;
    private final int COMMAND_GO_BACK;
    private final int COMMAND_GO_FORWARD;
    private final int COMMAND_INJECT_JAVASCRIPT;
    private final int COMMAND_LOAD_URL;
    private final int COMMAND_POST_MESSAGE;
    private final int COMMAND_RELOAD;
    private final int COMMAND_STOP_LOADING;
    private final java.lang.String DEFAULT_DOWNLOADING_MESSAGE;
    private final java.lang.String DEFAULT_LACK_PERMISSION_TO_DOWNLOAD_MESSAGE;
    private final java.lang.String HTML_ENCODING;
    private final java.lang.String HTML_MIME_TYPE;
    private final java.lang.String HTTP_METHOD_POST;
    private final java.lang.String TAG;
    private boolean mAllowsFullscreenVideo;
    private boolean mAllowsProtectedMedia;
    private java.lang.String mDownloadingMessage;
    private boolean mHasOnOpenWindowEvent;
    private java.lang.String mLackPermissionToDownloadMessage;
    private com.facebook.react.bridge.ReadableMap mPendingSource;
    private java.lang.String mUserAgent;
    private java.lang.String mUserAgentWithApplicationName;
    private com.reactnativecommunity.webview.RNCWebViewConfig mWebViewConfig;
    private final boolean newArch;

    public RNCWebViewManagerImpl() {
        this(false, 1, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void mWebViewConfig$lambda$0(android.webkit.WebView webView) {
    }

    public RNCWebViewManagerImpl(boolean z) {
        this.newArch = z;
        this.TAG = "RNCWebViewManagerImpl";
        this.mWebViewConfig = new com.reactnativecommunity.webview.RNCWebViewConfig() { // from class: com.reactnativecommunity.webview.RNCWebViewManagerImpl$$ExternalSyntheticLambda0
            @Override // com.reactnativecommunity.webview.RNCWebViewConfig
            public final void configWebView(android.webkit.WebView webView) {
                com.reactnativecommunity.webview.RNCWebViewManagerImpl.mWebViewConfig$lambda$0(webView);
            }
        };
        this.HTML_ENCODING = "UTF-8";
        this.HTML_MIME_TYPE = "text/html";
        this.HTTP_METHOD_POST = androidx.browser.trusted.sharing.ShareTarget.METHOD_POST;
        this.BLANK_URL = "about:blank";
        this.DEFAULT_DOWNLOADING_MESSAGE = "Downloading";
        this.DEFAULT_LACK_PERMISSION_TO_DOWNLOAD_MESSAGE = "Cannot download files as permission was denied. Please provide permission to write to storage, in order to download files.";
        this.COMMAND_GO_BACK = 1;
        this.COMMAND_GO_FORWARD = 2;
        this.COMMAND_RELOAD = 3;
        this.COMMAND_STOP_LOADING = 4;
        this.COMMAND_POST_MESSAGE = 5;
        this.COMMAND_INJECT_JAVASCRIPT = 6;
        this.COMMAND_LOAD_URL = 7;
        this.COMMAND_FOCUS = 8;
        this.COMMAND_CLEAR_FORM_DATA = 1000;
        this.COMMAND_CLEAR_CACHE = 1001;
        this.COMMAND_CLEAR_HISTORY = 1002;
    }

    public /* synthetic */ RNCWebViewManagerImpl(boolean z, int i, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? false : z);
    }

    public final com.reactnativecommunity.webview.RNCWebView createRNCWebViewInstance(com.facebook.react.uimanager.ThemedReactContext context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        return new com.reactnativecommunity.webview.RNCWebView(context);
    }

    public final com.reactnativecommunity.webview.RNCWebViewWrapper createViewInstance(com.facebook.react.uimanager.ThemedReactContext context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        return createViewInstance(context, createRNCWebViewInstance(context));
    }

    public final com.reactnativecommunity.webview.RNCWebViewWrapper createViewInstance(com.facebook.react.uimanager.ThemedReactContext context, final com.reactnativecommunity.webview.RNCWebView webView) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(webView, "webView");
        setupWebChromeClient(webView);
        context.addLifecycleEventListener(webView);
        this.mWebViewConfig.configWebView(webView);
        android.webkit.WebSettings settings = webView.getSettings();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(settings, "getSettings(...)");
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(1);
        webView.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, -1));
        if (com.facebook.react.common.build.ReactBuildConfig.DEBUG) {
            android.webkit.WebView.setWebContentsDebuggingEnabled(true);
        }
        webView.setDownloadListener(new android.webkit.DownloadListener() { // from class: com.reactnativecommunity.webview.RNCWebViewManagerImpl$$ExternalSyntheticLambda1
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, long j) {
                com.reactnativecommunity.webview.RNCWebViewManagerImpl.createViewInstance$lambda$1(webView, this, str, str2, str3, str4, j);
            }
        });
        return new com.reactnativecommunity.webview.RNCWebViewWrapper(context, webView);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void createViewInstance$lambda$1(com.reactnativecommunity.webview.RNCWebView rNCWebView, com.reactnativecommunity.webview.RNCWebViewManagerImpl rNCWebViewManagerImpl, java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, long j) {
        rNCWebView.setIgnoreErrFailedForThisURL(str);
        com.reactnativecommunity.webview.RNCWebViewModule rNCWebViewModule = (com.reactnativecommunity.webview.RNCWebViewModule) rNCWebView.getReactApplicationContext().getNativeModule(com.reactnativecommunity.webview.RNCWebViewModule.class);
        if (rNCWebViewModule == null) {
            return;
        }
        try {
            android.app.DownloadManager.Request request = new android.app.DownloadManager.Request(android.net.Uri.parse(str));
            java.lang.String strGuessFileName = com.reactnativecommunity.webview.URLUtil.guessFileName(str, str3, str4);
            kotlin.jvm.internal.Intrinsics.checkNotNull(strGuessFileName);
            java.lang.String strReplace = com.reactnativecommunity.webview.RNCWebViewManagerImplKt.getInvalidCharRegex().replace(strGuessFileName, "_");
            java.lang.String str5 = "Downloading " + strReplace;
            try {
                java.net.URL url = new java.net.URL(str);
                request.addRequestHeader(com.google.common.net.HttpHeaders.COOKIE, android.webkit.CookieManager.getInstance().getCookie(url.getProtocol() + "://" + url.getHost()));
            } catch (java.net.MalformedURLException e) {
                android.util.Log.w(rNCWebViewManagerImpl.TAG, "Error getting cookie for DownloadManager", e);
            }
            request.addRequestHeader("User-Agent", str2);
            request.setTitle(strReplace);
            request.setDescription(str5);
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(1);
            request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, strReplace);
            rNCWebViewModule.setDownloadRequest(request);
            if (rNCWebViewModule.grantFileDownloaderPermissions(rNCWebViewManagerImpl.getDownloadingMessageOrDefault(), rNCWebViewManagerImpl.getLackPermissionToDownloadMessageOrDefault())) {
                rNCWebViewModule.downloadFile(rNCWebViewManagerImpl.getDownloadingMessageOrDefault());
            }
        } catch (java.lang.IllegalArgumentException e2) {
            android.util.Log.w(rNCWebViewManagerImpl.TAG, "Unsupported URI, aborting download", e2);
        }
    }

    private final void setupWebChromeClient(final com.reactnativecommunity.webview.RNCWebView webView) {
        final android.app.Activity currentActivity = webView.getThemedReactContext().getCurrentActivity();
        if (this.mAllowsFullscreenVideo && currentActivity != null) {
            final int requestedOrientation = currentActivity.getRequestedOrientation();
            com.reactnativecommunity.webview.RNCWebChromeClient rNCWebChromeClient = new com.reactnativecommunity.webview.RNCWebChromeClient(webView) { // from class: com.reactnativecommunity.webview.RNCWebViewManagerImpl$setupWebChromeClient$webChromeClient$1
                @Override // android.webkit.WebChromeClient
                public android.graphics.Bitmap getDefaultVideoPoster() {
                    return android.graphics.Bitmap.createBitmap(50, 50, android.graphics.Bitmap.Config.ARGB_8888);
                }

                @Override // android.webkit.WebChromeClient
                public void onShowCustomView(android.view.View view, android.webkit.WebChromeClient.CustomViewCallback callback) {
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(view, "view");
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(callback, "callback");
                    if (this.mVideoView != null) {
                        callback.onCustomViewHidden();
                        return;
                    }
                    this.mVideoView = view;
                    this.mCustomViewCallback = callback;
                    currentActivity.setRequestedOrientation(-1);
                    this.mVideoView.setSystemUiVisibility(7942);
                    currentActivity.getWindow().setFlags(512, 512);
                    this.mVideoView.setBackgroundColor(androidx.core.view.ViewCompat.MEASURED_STATE_MASK);
                    android.view.ViewGroup rootView = getRootView();
                    rootView.addView(this.mVideoView, com.reactnativecommunity.webview.RNCWebChromeClient.FULLSCREEN_LAYOUT_PARAMS);
                    if (rootView.getRootView() != this.mWebView.getRootView()) {
                        this.mWebView.getRootView().setVisibility(8);
                    } else {
                        this.mWebView.setVisibility(8);
                    }
                    this.mWebView.getThemedReactContext().addLifecycleEventListener(this);
                }

                @Override // android.webkit.WebChromeClient
                public void onHideCustomView() {
                    if (this.mVideoView == null) {
                        return;
                    }
                    android.view.ViewGroup rootView = getRootView();
                    if (rootView.getRootView() != this.mWebView.getRootView()) {
                        this.mWebView.getRootView().setVisibility(0);
                    } else {
                        this.mWebView.setVisibility(0);
                    }
                    currentActivity.getWindow().clearFlags(512);
                    rootView.removeView(this.mVideoView);
                    this.mCustomViewCallback.onCustomViewHidden();
                    this.mVideoView = null;
                    this.mCustomViewCallback = null;
                    currentActivity.setRequestedOrientation(requestedOrientation);
                    this.mWebView.getThemedReactContext().removeLifecycleEventListener(this);
                }
            };
            rNCWebChromeClient.setAllowsProtectedMedia(this.mAllowsProtectedMedia);
            rNCWebChromeClient.setHasOnOpenWindowEvent(this.mHasOnOpenWindowEvent);
            webView.setWebChromeClient(rNCWebChromeClient);
            return;
        }
        com.reactnativecommunity.webview.RNCWebChromeClient rNCWebChromeClient2 = (com.reactnativecommunity.webview.RNCWebChromeClient) webView.getWebChromeClient();
        if (rNCWebChromeClient2 != null) {
            rNCWebChromeClient2.onHideCustomView();
        }
        com.reactnativecommunity.webview.RNCWebChromeClient rNCWebChromeClient3 = new com.reactnativecommunity.webview.RNCWebChromeClient(webView) { // from class: com.reactnativecommunity.webview.RNCWebViewManagerImpl.setupWebChromeClient.1
            @Override // android.webkit.WebChromeClient
            public android.graphics.Bitmap getDefaultVideoPoster() {
                return android.graphics.Bitmap.createBitmap(50, 50, android.graphics.Bitmap.Config.ARGB_8888);
            }
        };
        com.reactnativecommunity.webview.RNCWebViewManagerImpl.AnonymousClass1 anonymousClass1 = (com.reactnativecommunity.webview.RNCWebViewManagerImpl.AnonymousClass1) rNCWebChromeClient3;
        anonymousClass1.setAllowsProtectedMedia(this.mAllowsProtectedMedia);
        anonymousClass1.setHasOnOpenWindowEvent(this.mHasOnOpenWindowEvent);
        webView.setWebChromeClient(rNCWebChromeClient3);
    }

    public final void setUserAgent(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String userAgent) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        this.mUserAgent = userAgent;
        setUserAgentString(viewWrapper);
    }

    public final void setApplicationNameForUserAgent(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String applicationName) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        if (applicationName != null) {
            this.mUserAgentWithApplicationName = android.webkit.WebSettings.getDefaultUserAgent(viewWrapper.getWebView().getContext()) + " " + applicationName;
        } else {
            this.mUserAgentWithApplicationName = null;
        }
        setUserAgentString(viewWrapper);
    }

    private final void setUserAgentString(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper) {
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (this.mUserAgent != null) {
            webView.getSettings().setUserAgentString(this.mUserAgent);
        } else if (this.mUserAgentWithApplicationName != null) {
            webView.getSettings().setUserAgentString(this.mUserAgentWithApplicationName);
        } else {
            webView.getSettings().setUserAgentString(android.webkit.WebSettings.getDefaultUserAgent(webView.getContext()));
        }
    }

    public final void setBasicAuthCredential(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, com.facebook.react.bridge.ReadableMap credential) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setBasicAuthCredential((credential != null && credential.hasKey(androidx.autofill.HintConstants.AUTOFILL_HINT_USERNAME) && credential.hasKey(androidx.autofill.HintConstants.AUTOFILL_HINT_PASSWORD)) ? new com.reactnativecommunity.webview.RNCBasicAuthCredential(credential.getString(androidx.autofill.HintConstants.AUTOFILL_HINT_USERNAME), credential.getString(androidx.autofill.HintConstants.AUTOFILL_HINT_PASSWORD)) : null);
    }

    public final void onAfterUpdateTransaction(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.facebook.react.bridge.ReadableMap readableMap = this.mPendingSource;
        if (readableMap != null) {
            loadSource(viewWrapper, readableMap);
        }
        this.mPendingSource = null;
    }

    public final void onDropViewInstance(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        webView.getThemedReactContext().removeLifecycleEventListener(webView);
        webView.cleanupCallbacksAndDestroy();
        webView.mWebChromeClient = null;
    }

    public final int getCOMMAND_GO_BACK() {
        return this.COMMAND_GO_BACK;
    }

    public final int getCOMMAND_GO_FORWARD() {
        return this.COMMAND_GO_FORWARD;
    }

    public final int getCOMMAND_RELOAD() {
        return this.COMMAND_RELOAD;
    }

    public final int getCOMMAND_STOP_LOADING() {
        return this.COMMAND_STOP_LOADING;
    }

    public final int getCOMMAND_POST_MESSAGE() {
        return this.COMMAND_POST_MESSAGE;
    }

    public final int getCOMMAND_INJECT_JAVASCRIPT() {
        return this.COMMAND_INJECT_JAVASCRIPT;
    }

    public final int getCOMMAND_LOAD_URL() {
        return this.COMMAND_LOAD_URL;
    }

    public final int getCOMMAND_FOCUS() {
        return this.COMMAND_FOCUS;
    }

    public final int getCOMMAND_CLEAR_FORM_DATA() {
        return this.COMMAND_CLEAR_FORM_DATA;
    }

    public final int getCOMMAND_CLEAR_CACHE() {
        return this.COMMAND_CLEAR_CACHE;
    }

    public final int getCOMMAND_CLEAR_HISTORY() {
        return this.COMMAND_CLEAR_HISTORY;
    }

    public final java.util.Map<java.lang.String, java.lang.Integer> getCommandsMap() {
        return com.facebook.react.common.MapBuilder.builder().put("goBack", java.lang.Integer.valueOf(this.COMMAND_GO_BACK)).put("goForward", java.lang.Integer.valueOf(this.COMMAND_GO_FORWARD)).put("reload", java.lang.Integer.valueOf(this.COMMAND_RELOAD)).put("stopLoading", java.lang.Integer.valueOf(this.COMMAND_STOP_LOADING)).put("postMessage", java.lang.Integer.valueOf(this.COMMAND_POST_MESSAGE)).put("injectJavaScript", java.lang.Integer.valueOf(this.COMMAND_INJECT_JAVASCRIPT)).put("loadUrl", java.lang.Integer.valueOf(this.COMMAND_LOAD_URL)).put("requestFocus", java.lang.Integer.valueOf(this.COMMAND_FOCUS)).put("clearFormData", java.lang.Integer.valueOf(this.COMMAND_CLEAR_FORM_DATA)).put("clearCache", java.lang.Integer.valueOf(this.COMMAND_CLEAR_CACHE)).put("clearHistory", java.lang.Integer.valueOf(this.COMMAND_CLEAR_HISTORY)).build();
    }

    public final void receiveCommand(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String commandId, com.facebook.react.bridge.ReadableArray args) throws org.json.JSONException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(commandId, "commandId");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(args, "args");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        switch (commandId.hashCode()) {
            case -1241591313:
                if (commandId.equals("goBack")) {
                    webView.goBack();
                    return;
                }
                return;
            case -948122918:
                if (commandId.equals("stopLoading")) {
                    webView.stopLoading();
                    return;
                }
                return;
            case -934641255:
                if (commandId.equals("reload")) {
                    webView.reload();
                    return;
                }
                return;
            case -759238347:
                if (commandId.equals("clearCache")) {
                    webView.clearCache(args.getBoolean(0));
                    return;
                }
                return;
            case -318289731:
                if (commandId.equals("goForward")) {
                    webView.goForward();
                    return;
                }
                return;
            case -265032709:
                if (commandId.equals("clearFormData")) {
                    webView.clearFormData();
                    return;
                }
                return;
            case 336631465:
                if (commandId.equals("loadUrl")) {
                    java.lang.String string = args.getString(0);
                    if (string == null) {
                        throw new java.lang.RuntimeException("Arguments for loading an url are null!");
                    }
                    webView.progressChangedFilter.setWaitingForCommandLoadUrl(false);
                    webView.loadUrl(string);
                    return;
                }
                return;
            case 903120263:
                if (commandId.equals("clearHistory")) {
                    webView.clearHistory();
                    return;
                }
                return;
            case 1280029577:
                if (commandId.equals("requestFocus")) {
                    webView.requestFocus();
                    return;
                }
                return;
            case 1490029383:
                if (commandId.equals("postMessage")) {
                    try {
                        org.json.JSONObject jSONObject = new org.json.JSONObject();
                        jSONObject.put("data", args.getString(0));
                        webView.evaluateJavascriptWithFallback("(function () {var event;var data = " + jSONObject + ";try {event = new MessageEvent('message', data);} catch (e) {event = document.createEvent('MessageEvent');event.initMessageEvent('message', true, true, data.data, data.origin, data.lastEventId, data.source);}document.dispatchEvent(event);})();");
                        return;
                    } catch (org.json.JSONException e) {
                        throw new java.lang.RuntimeException(e);
                    }
                }
                return;
            case 2104576510:
                if (commandId.equals("injectJavaScript")) {
                    webView.evaluateJavascriptWithFallback(args.getString(0));
                    return;
                }
                return;
            default:
                return;
        }
    }

    public final void setMixedContentMode(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String mixedContentMode) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (mixedContentMode == null || kotlin.jvm.internal.Intrinsics.areEqual("never", mixedContentMode)) {
            webView.getSettings().setMixedContentMode(1);
        } else if (kotlin.jvm.internal.Intrinsics.areEqual("always", mixedContentMode)) {
            webView.getSettings().setMixedContentMode(0);
        } else if (kotlin.jvm.internal.Intrinsics.areEqual("compatibility", mixedContentMode)) {
            webView.getSettings().setMixedContentMode(2);
        }
    }

    public final void setAllowUniversalAccessFromFileURLs(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean allow) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setAllowUniversalAccessFromFileURLs(allow);
    }

    private final java.lang.String getDownloadingMessageOrDefault() {
        java.lang.String str = this.mDownloadingMessage;
        return str == null ? this.DEFAULT_DOWNLOADING_MESSAGE : str;
    }

    private final java.lang.String getLackPermissionToDownloadMessageOrDefault() {
        java.lang.String str = this.mLackPermissionToDownloadMessage;
        return str == null ? this.DEFAULT_LACK_PERMISSION_TO_DOWNLOAD_MESSAGE : str;
    }

    public final void setSource(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, com.facebook.react.bridge.ReadableMap source) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        this.mPendingSource = source;
    }

    private final void loadSource(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, com.facebook.react.bridge.ReadableMap source) {
        byte[] bytes;
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (source != null) {
            if (source.hasKey("html")) {
                java.lang.String string = source.getString("html");
                java.lang.String string2 = source.hasKey("baseUrl") ? source.getString("baseUrl") : "";
                kotlin.jvm.internal.Intrinsics.checkNotNull(string);
                webView.loadDataWithBaseURL(string2, string, this.HTML_MIME_TYPE, this.HTML_ENCODING, null);
                return;
            }
            if (source.hasKey(expo.modules.av.player.PlayerData.STATUS_URI_KEY_PATH)) {
                java.lang.String string3 = source.getString(expo.modules.av.player.PlayerData.STATUS_URI_KEY_PATH);
                java.lang.String url = webView.getUrl();
                if (url == null || !kotlin.jvm.internal.Intrinsics.areEqual(url, string3)) {
                    if (source.hasKey("method") && kotlin.text.StringsKt.equals(source.getString("method"), this.HTTP_METHOD_POST, true)) {
                        if (source.hasKey(com.google.android.exoplayer2.text.ttml.TtmlNode.TAG_BODY)) {
                            java.lang.String string4 = source.getString(com.google.android.exoplayer2.text.ttml.TtmlNode.TAG_BODY);
                            try {
                                kotlin.jvm.internal.Intrinsics.checkNotNull(string4);
                                java.nio.charset.Charset charsetForName = java.nio.charset.Charset.forName("UTF-8");
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(charsetForName, "forName(...)");
                                bytes = string4.getBytes(charsetForName);
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            } catch (java.io.UnsupportedEncodingException unused) {
                                kotlin.jvm.internal.Intrinsics.checkNotNull(string4);
                                bytes = string4.getBytes(kotlin.text.Charsets.UTF_8);
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            }
                        } else {
                            bytes = null;
                        }
                        if (bytes == null) {
                            bytes = new byte[0];
                        }
                        kotlin.jvm.internal.Intrinsics.checkNotNull(string3);
                        webView.postUrl(string3, bytes);
                        return;
                    }
                    java.util.HashMap map = new java.util.HashMap();
                    if (source.hasKey("headers")) {
                        if (this.newArch) {
                            com.facebook.react.bridge.ReadableArray array = source.getArray("headers");
                            kotlin.jvm.internal.Intrinsics.checkNotNull(array);
                            java.util.Iterator<java.lang.Object> it = array.toArrayList().iterator();
                            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                            while (it.hasNext()) {
                                java.lang.Object next = it.next();
                                kotlin.jvm.internal.Intrinsics.checkNotNull(next, "null cannot be cast to non-null type java.util.HashMap<kotlin.String, kotlin.String>");
                                java.util.HashMap map2 = (java.util.HashMap) next;
                                java.lang.String str = (java.lang.String) map2.get("name");
                                if (str == null) {
                                    str = "";
                                }
                                java.lang.String str2 = (java.lang.String) map2.get("value");
                                if (str2 == null) {
                                    str2 = "";
                                }
                                java.util.Locale ENGLISH = java.util.Locale.ENGLISH;
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(ENGLISH, "ENGLISH");
                                java.lang.String lowerCase = str.toLowerCase(ENGLISH);
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                if (kotlin.jvm.internal.Intrinsics.areEqual("user-agent", lowerCase)) {
                                    webView.getSettings().setUserAgentString(str2);
                                } else {
                                    map.put(str, str2);
                                }
                            }
                        } else {
                            com.facebook.react.bridge.ReadableMap map3 = source.getMap("headers");
                            kotlin.jvm.internal.Intrinsics.checkNotNull(map3);
                            com.facebook.react.bridge.ReadableMapKeySetIterator readableMapKeySetIteratorKeySetIterator = map3.keySetIterator();
                            while (readableMapKeySetIteratorKeySetIterator.hasNextKey()) {
                                java.lang.String strNextKey = readableMapKeySetIteratorKeySetIterator.nextKey();
                                java.util.Locale ENGLISH2 = java.util.Locale.ENGLISH;
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(ENGLISH2, "ENGLISH");
                                java.lang.String lowerCase2 = strNextKey.toLowerCase(ENGLISH2);
                                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                if (kotlin.jvm.internal.Intrinsics.areEqual("user-agent", lowerCase2)) {
                                    webView.getSettings().setUserAgentString(map3.getString(strNextKey));
                                } else {
                                    map.put(strNextKey, map3.getString(strNextKey));
                                }
                            }
                        }
                    }
                    kotlin.jvm.internal.Intrinsics.checkNotNull(string3);
                    webView.loadUrl(string3, map);
                    return;
                }
                return;
            }
        }
        webView.loadUrl(this.BLANK_URL);
    }

    public final void setMessagingModuleName(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().messagingModuleName = value;
    }

    public final void setCacheEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setCacheMode(enabled ? -1 : 2);
    }

    public final void setIncognito(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (enabled) {
            android.webkit.CookieManager.getInstance().removeAllCookies(null);
            webView.getSettings().setCacheMode(2);
            webView.clearHistory();
            webView.clearCache(true);
            webView.clearFormData();
            webView.getSettings().setSavePassword(false);
            webView.getSettings().setSaveFormData(false);
        }
    }

    public final void setInjectedJavaScript(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String injectedJavaScript) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().injectedJS = injectedJavaScript;
    }

    public final void setInjectedJavaScriptBeforeContentLoaded(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().injectedJSBeforeContentLoaded = value;
    }

    public final void setInjectedJavaScriptForMainFrameOnly(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().injectedJavaScriptForMainFrameOnly = value;
    }

    public final void setInjectedJavaScriptBeforeContentLoadedForMainFrameOnly(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().injectedJavaScriptBeforeContentLoadedForMainFrameOnly = value;
    }

    public final void setInjectedJavaScriptObject(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setInjectedJavaScriptObject(value);
    }

    public final void setJavaScriptCanOpenWindowsAutomatically(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setJavaScriptCanOpenWindowsAutomatically(value);
    }

    public final void setShowsVerticalScrollIndicator(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setVerticalScrollBarEnabled(value);
    }

    public final void setShowsHorizontalScrollIndicator(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setHorizontalScrollBarEnabled(value);
    }

    public final void setMessagingEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setMessagingEnabled(value);
    }

    public final void setMediaPlaybackRequiresUserAction(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setMediaPlaybackRequiresUserGesture(value);
    }

    public final void setHasOnScroll(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().setHasScrollEvent(value);
    }

    public final void setJavaScriptEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setJavaScriptEnabled(enabled);
    }

    public final void setAllowFileAccess(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean allowFileAccess) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setAllowFileAccess(allowFileAccess);
    }

    public final void setAllowFileAccessFromFileURLs(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setAllowFileAccessFromFileURLs(value);
    }

    public final void setAllowsFullscreenVideo(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        this.mAllowsFullscreenVideo = value;
        setupWebChromeClient(webView);
    }

    public final void setAndroidLayerType(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String layerTypeString) {
        int i;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (kotlin.jvm.internal.Intrinsics.areEqual(layerTypeString, "hardware")) {
            i = 2;
        } else {
            i = kotlin.jvm.internal.Intrinsics.areEqual(layerTypeString, "software") ? 1 : 0;
        }
        webView.setLayerType(i, null);
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final void setCacheMode(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String cacheModeString) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        android.webkit.WebSettings settings = viewWrapper.getWebView().getSettings();
        int i = -1;
        if (cacheModeString != null) {
            switch (cacheModeString.hashCode()) {
                case -2059164003:
                    if (cacheModeString.equals("LOAD_NO_CACHE")) {
                        i = 2;
                        break;
                    }
                    break;
                case -1215135800:
                    cacheModeString.equals("LOAD_DEFAULT");
                    break;
                case -873877826:
                    if (cacheModeString.equals("LOAD_CACHE_ELSE_NETWORK")) {
                        i = 1;
                        break;
                    }
                    break;
                case 1548620642:
                    if (cacheModeString.equals("LOAD_CACHE_ONLY")) {
                        i = 3;
                        break;
                    }
                    break;
            }
        }
        settings.setCacheMode(i);
    }

    public final void setDomStorageEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setDomStorageEnabled(value);
    }

    public final void setDownloadingMessage(java.lang.String value) {
        this.mDownloadingMessage = value;
    }

    public final void setForceDarkOn(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (android.os.Build.VERSION.SDK_INT > 28) {
            if (androidx.webkit.WebViewFeature.isFeatureSupported("FORCE_DARK")) {
                androidx.webkit.WebSettingsCompat.setForceDark(webView.getSettings(), enabled ? 2 : 0);
            }
            if (enabled && androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.FORCE_DARK_STRATEGY)) {
                androidx.webkit.WebSettingsCompat.setForceDarkStrategy(webView.getSettings(), 2);
            }
        }
    }

    public final void setGeolocationEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setGeolocationEnabled(value);
    }

    public final void setLackPermissionToDownloadMessage(java.lang.String value) {
        this.mLackPermissionToDownloadMessage = value;
    }

    public final void setHasOnOpenWindowEvent(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        this.mHasOnOpenWindowEvent = value;
        setupWebChromeClient(webView);
    }

    public final void setMinimumFontSize(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, int value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setMinimumFontSize(value);
    }

    public final void setAllowsProtectedMedia(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        android.webkit.WebChromeClient webChromeClient;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        this.mAllowsProtectedMedia = enabled;
        if (android.os.Build.VERSION.SDK_INT < 26 || (webChromeClient = webView.getWebChromeClient()) == null || !(webChromeClient instanceof com.reactnativecommunity.webview.RNCWebChromeClient)) {
            return;
        }
        ((com.reactnativecommunity.webview.RNCWebChromeClient) webChromeClient).setAllowsProtectedMedia(enabled);
    }

    public final void setMenuCustomItems(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, com.facebook.react.bridge.ReadableArray value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (value == null) {
            webView.setMenuCustomItems(null);
            return;
        }
        java.util.ArrayList<java.lang.Object> arrayList = value.toArrayList();
        kotlin.jvm.internal.Intrinsics.checkNotNull(arrayList, "null cannot be cast to non-null type kotlin.collections.List<kotlin.collections.Map<kotlin.String, kotlin.String>>");
        webView.setMenuCustomItems(arrayList);
    }

    public final void setNestedScrollEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().nestedScrollEnabled = value;
    }

    public final void setOverScrollMode(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, java.lang.String overScrollModeString) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        int i = 0;
        if (overScrollModeString != null) {
            int iHashCode = overScrollModeString.hashCode();
            if (iHashCode == -1414557169) {
                overScrollModeString.equals("always");
            } else if (iHashCode != 104712844) {
                if (iHashCode == 951530617 && overScrollModeString.equals(com.facebook.common.util.UriUtil.LOCAL_CONTENT_SCHEME)) {
                    i = 1;
                }
            } else if (overScrollModeString.equals("never")) {
                i = 2;
            }
        }
        webView.setOverScrollMode(i);
    }

    public final void setSaveFormDataDisabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean disabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setSaveFormData(!disabled);
    }

    public final void setScalesPageToFit(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        webView.getSettings().setLoadWithOverviewMode(value);
        webView.getSettings().setUseWideViewPort(value);
    }

    public final void setSetBuiltInZoomControls(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setBuiltInZoomControls(value);
    }

    public final void setSetDisplayZoomControls(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setDisplayZoomControls(value);
    }

    public final void setSetSupportMultipleWindows(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setSupportMultipleWindows(value);
    }

    public final void setTextZoom(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, int value) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        viewWrapper.getWebView().getSettings().setTextZoom(value);
    }

    public final void setThirdPartyCookiesEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(viewWrapper.getWebView(), enabled);
    }

    public final void setWebviewDebuggingEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView.setWebContentsDebuggingEnabled(enabled);
    }

    public final void setPaymentRequestEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper viewWrapper, boolean enabled) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewWrapper, "viewWrapper");
        com.reactnativecommunity.webview.RNCWebView webView = viewWrapper.getWebView();
        if (androidx.webkit.WebViewFeature.isFeatureSupported("PAYMENT_REQUEST")) {
            androidx.webkit.WebSettingsCompat.setPaymentRequestEnabled(webView.getSettings(), enabled);
        }
    }
}
