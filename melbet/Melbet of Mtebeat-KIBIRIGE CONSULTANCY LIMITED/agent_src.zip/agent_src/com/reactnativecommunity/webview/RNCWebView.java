package com.reactnativecommunity.webview;

/* loaded from: classes3.dex */
public class RNCWebView extends android.webkit.WebView implements com.facebook.react.bridge.LifecycleEventListener {
    protected static final java.lang.String JAVASCRIPT_INTERFACE = "ReactNativeWebView";
    protected androidx.webkit.WebViewCompat.WebMessageListener bridgeListener;
    protected com.reactnativecommunity.webview.RNCWebView.RNCWebViewBridge fallbackBridge;
    protected boolean hasScrollEvent;
    protected java.lang.String injectedJS;
    protected java.lang.String injectedJSBeforeContentLoaded;
    protected boolean injectedJavaScriptBeforeContentLoadedForMainFrameOnly;
    protected boolean injectedJavaScriptForMainFrameOnly;
    protected java.lang.String injectedJavaScriptObject;
    protected com.reactnativecommunity.webview.RNCWebViewMessagingModule mMessagingJSModule;
    private com.facebook.react.views.scroll.OnScrollDispatchHelper mOnScrollDispatchHelper;
    protected com.reactnativecommunity.webview.RNCWebViewClient mRNCWebViewClient;
    android.webkit.WebChromeClient mWebChromeClient;
    protected java.util.List<java.util.Map<java.lang.String, java.lang.String>> menuCustomItems;
    protected boolean messagingEnabled;
    protected java.lang.String messagingModuleName;
    protected boolean nestedScrollEnabled;
    protected com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter progressChangedFilter;
    protected boolean sendContentSizeChangeEvents;

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostPause() {
    }

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostResume() {
    }

    public RNCWebView(com.facebook.react.uimanager.ThemedReactContext themedReactContext) {
        super(themedReactContext);
        this.bridgeListener = null;
        this.injectedJavaScriptForMainFrameOnly = true;
        this.injectedJavaScriptBeforeContentLoadedForMainFrameOnly = true;
        this.messagingEnabled = false;
        this.sendContentSizeChangeEvents = false;
        this.hasScrollEvent = false;
        this.nestedScrollEnabled = false;
        this.injectedJavaScriptObject = null;
        this.mMessagingJSModule = (com.reactnativecommunity.webview.RNCWebViewMessagingModule) ((com.facebook.react.uimanager.ThemedReactContext) getContext()).getReactApplicationContext().getJSModule(com.reactnativecommunity.webview.RNCWebViewMessagingModule.class);
        this.progressChangedFilter = new com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter();
    }

    public void setIgnoreErrFailedForThisURL(java.lang.String str) {
        this.mRNCWebViewClient.setIgnoreErrFailedForThisURL(str);
    }

    public void setBasicAuthCredential(com.reactnativecommunity.webview.RNCBasicAuthCredential rNCBasicAuthCredential) {
        this.mRNCWebViewClient.setBasicAuthCredential(rNCBasicAuthCredential);
    }

    public void setSendContentSizeChangeEvents(boolean z) {
        this.sendContentSizeChangeEvents = z;
    }

    public void setHasScrollEvent(boolean z) {
        this.hasScrollEvent = z;
    }

    public void setNestedScrollEnabled(boolean z) {
        this.nestedScrollEnabled = z;
    }

    @Override // com.facebook.react.bridge.LifecycleEventListener
    public void onHostDestroy() {
        cleanupCallbacksAndDestroy();
    }

    @Override // android.webkit.WebView, android.view.View
    public boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        if (this.nestedScrollEnabled) {
            requestDisallowInterceptTouchEvent(true);
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.webkit.WebView, android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (this.sendContentSizeChangeEvents) {
            dispatchEvent(this, new com.facebook.react.uimanager.events.ContentSizeChangeEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(this), i, i2));
        }
    }

    public void setMenuCustomItems(java.util.List<java.util.Map<java.lang.String, java.lang.String>> list) {
        this.menuCustomItems = list;
    }

    @Override // android.view.View
    public android.view.ActionMode startActionMode(final android.view.ActionMode.Callback callback, int i) {
        if (this.menuCustomItems == null) {
            return super.startActionMode(callback, i);
        }
        return super.startActionMode(new android.view.ActionMode.Callback2() { // from class: com.reactnativecommunity.webview.RNCWebView.1
            @Override // android.view.ActionMode.Callback
            public void onDestroyActionMode(android.view.ActionMode actionMode) {
            }

            @Override // android.view.ActionMode.Callback
            public boolean onPrepareActionMode(android.view.ActionMode actionMode, android.view.Menu menu) {
                return false;
            }

            @Override // android.view.ActionMode.Callback
            public boolean onCreateActionMode(android.view.ActionMode actionMode, android.view.Menu menu) {
                for (int i2 = 0; i2 < com.reactnativecommunity.webview.RNCWebView.this.menuCustomItems.size(); i2++) {
                    menu.add(0, i2, i2, com.reactnativecommunity.webview.RNCWebView.this.menuCustomItems.get(i2).get(org.bouncycastle.jcajce.util.AnnotatedPrivateKey.LABEL));
                }
                return true;
            }

            @Override // android.view.ActionMode.Callback
            public boolean onActionItemClicked(final android.view.ActionMode actionMode, final android.view.MenuItem menuItem) {
                final com.facebook.react.bridge.WritableMap writableMapCreateMap = com.facebook.react.bridge.Arguments.createMap();
                com.reactnativecommunity.webview.RNCWebView.this.evaluateJavascript("(function(){return {selection: window.getSelection().toString()} })()", new android.webkit.ValueCallback<java.lang.String>() { // from class: com.reactnativecommunity.webview.RNCWebView.1.1
                    @Override // android.webkit.ValueCallback
                    public void onReceiveValue(java.lang.String str) throws org.json.JSONException {
                        java.lang.String string;
                        java.util.Map<java.lang.String, java.lang.String> map = com.reactnativecommunity.webview.RNCWebView.this.menuCustomItems.get(menuItem.getItemId());
                        writableMapCreateMap.putString(org.bouncycastle.jcajce.util.AnnotatedPrivateKey.LABEL, map.get(org.bouncycastle.jcajce.util.AnnotatedPrivateKey.LABEL));
                        writableMapCreateMap.putString("key", map.get("key"));
                        try {
                            string = new org.json.JSONObject(str).getString("selection");
                        } catch (org.json.JSONException unused) {
                            string = "";
                        }
                        writableMapCreateMap.putString("selectedText", string);
                        com.reactnativecommunity.webview.RNCWebView.this.dispatchEvent(com.reactnativecommunity.webview.RNCWebView.this, new com.reactnativecommunity.webview.events.TopCustomMenuSelectionEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(com.reactnativecommunity.webview.RNCWebView.this), writableMapCreateMap));
                        actionMode.finish();
                    }
                });
                return true;
            }

            @Override // android.view.ActionMode.Callback2
            public void onGetContentRect(android.view.ActionMode actionMode, android.view.View view, android.graphics.Rect rect) {
                android.view.ActionMode.Callback callback2 = callback;
                if (callback2 instanceof android.view.ActionMode.Callback2) {
                    ((android.view.ActionMode.Callback2) callback2).onGetContentRect(actionMode, view, rect);
                } else {
                    super.onGetContentRect(actionMode, view, rect);
                }
            }
        }, i);
    }

    @Override // android.webkit.WebView
    public void setWebViewClient(android.webkit.WebViewClient webViewClient) {
        super.setWebViewClient(webViewClient);
        if (webViewClient instanceof com.reactnativecommunity.webview.RNCWebViewClient) {
            com.reactnativecommunity.webview.RNCWebViewClient rNCWebViewClient = (com.reactnativecommunity.webview.RNCWebViewClient) webViewClient;
            this.mRNCWebViewClient = rNCWebViewClient;
            rNCWebViewClient.setProgressChangedFilter(this.progressChangedFilter);
        }
    }

    @Override // android.webkit.WebView
    public void setWebChromeClient(android.webkit.WebChromeClient webChromeClient) {
        this.mWebChromeClient = webChromeClient;
        super.setWebChromeClient(webChromeClient);
        if (webChromeClient instanceof com.reactnativecommunity.webview.RNCWebChromeClient) {
            ((com.reactnativecommunity.webview.RNCWebChromeClient) webChromeClient).setProgressChangedFilter(this.progressChangedFilter);
        }
    }

    @Override // android.webkit.WebView
    public android.webkit.WebChromeClient getWebChromeClient() {
        return this.mWebChromeClient;
    }

    public com.reactnativecommunity.webview.RNCWebViewClient getRNCWebViewClient() {
        return this.mRNCWebViewClient;
    }

    public boolean getMessagingEnabled() {
        return this.messagingEnabled;
    }

    protected void createRNCWebViewBridge(com.reactnativecommunity.webview.RNCWebView rNCWebView) {
        if (androidx.webkit.WebViewFeature.isFeatureSupported("WEB_MESSAGE_LISTENER")) {
            if (this.bridgeListener == null) {
                this.bridgeListener = new androidx.webkit.WebViewCompat.WebMessageListener() { // from class: com.reactnativecommunity.webview.RNCWebView.2
                    @Override // androidx.webkit.WebViewCompat.WebMessageListener
                    public void onPostMessage(android.webkit.WebView webView, androidx.webkit.WebMessageCompat webMessageCompat, android.net.Uri uri, boolean z, androidx.webkit.JavaScriptReplyProxy javaScriptReplyProxy) {
                        com.reactnativecommunity.webview.RNCWebView.this.onMessage(webMessageCompat.getData(), uri.toString());
                    }
                };
                androidx.webkit.WebViewCompat.addWebMessageListener(rNCWebView, JAVASCRIPT_INTERFACE, com.reactnativecommunity.webview.RNCWebView$$ExternalSyntheticBackport0.m(new java.lang.Object[]{androidx.webkit.ProxyConfig.MATCH_ALL_SCHEMES}), this.bridgeListener);
            }
        } else if (this.fallbackBridge == null) {
            com.reactnativecommunity.webview.RNCWebView.RNCWebViewBridge rNCWebViewBridge = new com.reactnativecommunity.webview.RNCWebView.RNCWebViewBridge(rNCWebView);
            this.fallbackBridge = rNCWebViewBridge;
            addJavascriptInterface(rNCWebViewBridge, JAVASCRIPT_INTERFACE);
        }
        injectJavascriptObject();
    }

    private void injectJavascriptObject() {
        if (getSettings().getJavaScriptEnabled()) {
            evaluateJavascriptWithFallback("(function(){\n    window.ReactNativeWebView = window.ReactNativeWebView || {};\n    window.ReactNativeWebView.injectedObjectJson = function () { return " + (this.injectedJavaScriptObject == null ? null : "`" + this.injectedJavaScriptObject + "`") + "; };\n})();");
        }
    }

    public void setMessagingEnabled(boolean z) {
        if (this.messagingEnabled == z) {
            return;
        }
        this.messagingEnabled = z;
        if (z) {
            createRNCWebViewBridge(this);
        }
    }

    protected void evaluateJavascriptWithFallback(java.lang.String str) {
        evaluateJavascript(str, null);
    }

    public void callInjectedJavaScript() {
        java.lang.String str;
        if (!getSettings().getJavaScriptEnabled() || (str = this.injectedJS) == null || android.text.TextUtils.isEmpty(str)) {
            return;
        }
        evaluateJavascriptWithFallback("(function() {\n" + this.injectedJS + ";\n})();");
        injectJavascriptObject();
    }

    public void callInjectedJavaScriptBeforeContentLoaded() {
        java.lang.String str;
        if (!getSettings().getJavaScriptEnabled() || (str = this.injectedJSBeforeContentLoaded) == null || android.text.TextUtils.isEmpty(str)) {
            return;
        }
        evaluateJavascriptWithFallback("(function() {\n" + this.injectedJSBeforeContentLoaded + ";\n})();");
        injectJavascriptObject();
    }

    public void setInjectedJavaScriptObject(java.lang.String str) {
        this.injectedJavaScriptObject = str;
        injectJavascriptObject();
    }

    public void onMessage(final java.lang.String str, final java.lang.String str2) {
        getThemedReactContext();
        if (this.mRNCWebViewClient != null) {
            post(new java.lang.Runnable() { // from class: com.reactnativecommunity.webview.RNCWebView.3
                @Override // java.lang.Runnable
                public void run() {
                    if (com.reactnativecommunity.webview.RNCWebView.this.mRNCWebViewClient == null) {
                        return;
                    }
                    com.facebook.react.bridge.WritableMap writableMapCreateWebViewEvent = com.reactnativecommunity.webview.RNCWebView.this.mRNCWebViewClient.createWebViewEvent(this, str2);
                    writableMapCreateWebViewEvent.putString("data", str);
                    if (com.reactnativecommunity.webview.RNCWebView.this.mMessagingJSModule != null) {
                        com.reactnativecommunity.webview.RNCWebView.this.dispatchDirectMessage(writableMapCreateWebViewEvent);
                    } else {
                        com.reactnativecommunity.webview.RNCWebView.this.dispatchEvent(this, new com.reactnativecommunity.webview.events.TopMessageEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(this), writableMapCreateWebViewEvent));
                    }
                }
            });
            return;
        }
        com.facebook.react.bridge.WritableMap writableMapCreateMap = com.facebook.react.bridge.Arguments.createMap();
        writableMapCreateMap.putString("data", str);
        if (this.mMessagingJSModule != null) {
            dispatchDirectMessage(writableMapCreateMap);
        } else {
            dispatchEvent(this, new com.reactnativecommunity.webview.events.TopMessageEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(this), writableMapCreateMap));
        }
    }

    protected void dispatchDirectMessage(com.facebook.react.bridge.WritableMap writableMap) {
        com.facebook.react.bridge.WritableNativeMap writableNativeMap = new com.facebook.react.bridge.WritableNativeMap();
        writableNativeMap.putMap("nativeEvent", writableMap);
        writableNativeMap.putString("messagingModuleName", this.messagingModuleName);
        this.mMessagingJSModule.onMessage(writableNativeMap);
    }

    protected boolean dispatchDirectShouldStartLoadWithRequest(com.facebook.react.bridge.WritableMap writableMap) {
        com.facebook.react.bridge.WritableNativeMap writableNativeMap = new com.facebook.react.bridge.WritableNativeMap();
        writableNativeMap.putMap("nativeEvent", writableMap);
        writableNativeMap.putString("messagingModuleName", this.messagingModuleName);
        this.mMessagingJSModule.onShouldStartLoadWithRequest(writableNativeMap);
        return true;
    }

    @Override // android.webkit.WebView, android.view.View
    protected void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        if (this.hasScrollEvent) {
            if (this.mOnScrollDispatchHelper == null) {
                this.mOnScrollDispatchHelper = new com.facebook.react.views.scroll.OnScrollDispatchHelper();
            }
            if (this.mOnScrollDispatchHelper.onScrollChanged(i, i2)) {
                dispatchEvent(this, com.facebook.react.views.scroll.ScrollEvent.obtain(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(this), com.facebook.react.views.scroll.ScrollEventType.SCROLL, i, i2, this.mOnScrollDispatchHelper.getXFlingVelocity(), this.mOnScrollDispatchHelper.getYFlingVelocity(), computeHorizontalScrollRange(), computeVerticalScrollRange(), getWidth(), getHeight()));
            }
        }
    }

    protected void dispatchEvent(android.webkit.WebView webView, com.facebook.react.uimanager.events.Event event) {
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag(getThemedReactContext(), com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView)).dispatchEvent(event);
    }

    protected void cleanupCallbacksAndDestroy() {
        setWebViewClient(null);
        destroy();
    }

    @Override // android.webkit.WebView
    public void destroy() {
        android.webkit.WebChromeClient webChromeClient = this.mWebChromeClient;
        if (webChromeClient != null) {
            webChromeClient.onHideCustomView();
        }
        super.destroy();
    }

    public com.facebook.react.uimanager.ThemedReactContext getThemedReactContext() {
        return (com.facebook.react.uimanager.ThemedReactContext) getContext();
    }

    public com.facebook.react.bridge.ReactApplicationContext getReactApplicationContext() {
        return getThemedReactContext().getReactApplicationContext();
    }

    protected class RNCWebViewBridge {
        private java.lang.String TAG = "RNCWebViewBridge";
        com.reactnativecommunity.webview.RNCWebView mWebView;

        RNCWebViewBridge(com.reactnativecommunity.webview.RNCWebView rNCWebView) {
            this.mWebView = rNCWebView;
        }

        @android.webkit.JavascriptInterface
        public void postMessage(final java.lang.String str) {
            if (this.mWebView.getMessagingEnabled()) {
                this.mWebView.post(new java.lang.Runnable() { // from class: com.reactnativecommunity.webview.RNCWebView$RNCWebViewBridge$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$postMessage$0(str);
                    }
                });
            } else {
                com.facebook.common.logging.FLog.w(this.TAG, "ReactNativeWebView.postMessage method was called but messaging is disabled. Pass an onMessage handler to the WebView.");
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$postMessage$0(java.lang.String str) {
            com.reactnativecommunity.webview.RNCWebView rNCWebView = this.mWebView;
            rNCWebView.onMessage(str, rNCWebView.getUrl());
        }
    }

    protected static class ProgressChangedFilter {
        private boolean waitingForCommandLoadUrl = false;

        protected ProgressChangedFilter() {
        }

        public void setWaitingForCommandLoadUrl(boolean z) {
            this.waitingForCommandLoadUrl = z;
        }

        public boolean isWaitingForCommandLoadUrl() {
            return this.waitingForCommandLoadUrl;
        }
    }
}
