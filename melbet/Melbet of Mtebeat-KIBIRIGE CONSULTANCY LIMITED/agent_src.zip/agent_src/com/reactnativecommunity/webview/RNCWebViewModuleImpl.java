package com.reactnativecommunity.webview;

/* loaded from: classes3.dex */
public class RNCWebViewModuleImpl implements com.facebook.react.bridge.ActivityEventListener {
    public static final int FILE_DOWNLOAD_PERMISSION_REQUEST = 1;
    public static final java.lang.String NAME = "RNCWebViewModule";
    public static final int PICKER = 1;
    public static final int PICKER_LEGACY = 3;
    protected static final com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock shouldOverrideUrlLoadingLock = new com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock();
    private final com.facebook.react.bridge.ReactApplicationContext mContext;
    private android.app.DownloadManager.Request mDownloadRequest;
    private android.webkit.ValueCallback<android.net.Uri[]> mFilePathCallback;
    private android.webkit.ValueCallback<android.net.Uri> mFilePathCallbackLegacy;
    private java.io.File mOutputImage;
    private java.io.File mOutputVideo;

    public boolean isFileUploadSupported() {
        return true;
    }

    @Override // com.facebook.react.bridge.ActivityEventListener
    public void onNewIntent(android.content.Intent intent) {
    }

    public RNCWebViewModuleImpl(com.facebook.react.bridge.ReactApplicationContext reactApplicationContext) {
        this.mContext = reactApplicationContext;
        reactApplicationContext.addActivityEventListener(this);
    }

    @Override // com.facebook.react.bridge.ActivityEventListener
    public void onActivityResult(android.app.Activity activity, int i, int i2, android.content.Intent intent) {
        if (this.mFilePathCallback == null && this.mFilePathCallbackLegacy == null) {
            return;
        }
        java.io.File file = this.mOutputImage;
        boolean z = file != null && file.length() > 0;
        java.io.File file2 = this.mOutputVideo;
        boolean z2 = file2 != null && file2.length() > 0;
        if (i != 1) {
            if (i == 3) {
                if (i2 != -1) {
                    this.mFilePathCallbackLegacy.onReceiveValue(null);
                } else if (z) {
                    this.mFilePathCallbackLegacy.onReceiveValue(getOutputUri(this.mOutputImage));
                } else if (z2) {
                    this.mFilePathCallbackLegacy.onReceiveValue(getOutputUri(this.mOutputVideo));
                } else {
                    this.mFilePathCallbackLegacy.onReceiveValue(intent.getData());
                }
            }
        } else if (i2 != -1) {
            android.webkit.ValueCallback<android.net.Uri[]> valueCallback = this.mFilePathCallback;
            if (valueCallback != null) {
                valueCallback.onReceiveValue(null);
            }
        } else if (z) {
            this.mFilePathCallback.onReceiveValue(new android.net.Uri[]{getOutputUri(this.mOutputImage)});
        } else if (z2) {
            this.mFilePathCallback.onReceiveValue(new android.net.Uri[]{getOutputUri(this.mOutputVideo)});
        } else {
            this.mFilePathCallback.onReceiveValue(getSelectedFiles(intent, i2));
        }
        java.io.File file3 = this.mOutputImage;
        if (file3 != null && !z) {
            file3.delete();
        }
        java.io.File file4 = this.mOutputVideo;
        if (file4 != null && !z2) {
            file4.delete();
        }
        this.mFilePathCallback = null;
        this.mFilePathCallbackLegacy = null;
        this.mOutputImage = null;
        this.mOutputVideo = null;
    }

    protected static class ShouldOverrideUrlLoadingLock {
        private double nextLockIdentifier = 1.0d;
        private final java.util.HashMap<java.lang.Double, java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState>> shouldOverrideLocks = new java.util.HashMap<>();

        protected enum ShouldOverrideCallbackState {
            UNDECIDED,
            SHOULD_OVERRIDE,
            DO_NOT_OVERRIDE
        }

        protected ShouldOverrideUrlLoadingLock() {
        }

        public synchronized androidx.core.util.Pair<java.lang.Double, java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState>> getNewLock() {
            double d;
            java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState> atomicReference;
            d = this.nextLockIdentifier;
            this.nextLockIdentifier = 1.0d + d;
            atomicReference = new java.util.concurrent.atomic.AtomicReference<>(com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState.UNDECIDED);
            this.shouldOverrideLocks.put(java.lang.Double.valueOf(d), atomicReference);
            return new androidx.core.util.Pair<>(java.lang.Double.valueOf(d), atomicReference);
        }

        public synchronized java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState> getLock(java.lang.Double d) {
            return this.shouldOverrideLocks.get(d);
        }

        public synchronized void removeLock(java.lang.Double d) {
            this.shouldOverrideLocks.remove(d);
        }
    }

    private enum MimeType {
        DEFAULT("*/*"),
        IMAGE("image"),
        VIDEO("video");

        private final java.lang.String value;

        MimeType(java.lang.String str) {
            this.value = str;
        }
    }

    private com.facebook.react.modules.core.PermissionListener getWebviewFileDownloaderPermissionListener(final java.lang.String str, final java.lang.String str2) {
        return new com.facebook.react.modules.core.PermissionListener() { // from class: com.reactnativecommunity.webview.RNCWebViewModuleImpl.1
            @Override // com.facebook.react.modules.core.PermissionListener
            public boolean onRequestPermissionsResult(int i, java.lang.String[] strArr, int[] iArr) {
                if (i != 1) {
                    return false;
                }
                if (iArr.length > 0 && iArr[0] == 0) {
                    if (com.reactnativecommunity.webview.RNCWebViewModuleImpl.this.mDownloadRequest != null) {
                        com.reactnativecommunity.webview.RNCWebViewModuleImpl.this.downloadFile(str);
                    }
                } else {
                    android.widget.Toast.makeText(com.reactnativecommunity.webview.RNCWebViewModuleImpl.this.mContext, str2, 1).show();
                }
                return true;
            }
        };
    }

    public void shouldStartLoadWithLockIdentifier(boolean z, double d) {
        java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState> lock = shouldOverrideUrlLoadingLock.getLock(java.lang.Double.valueOf(d));
        if (lock != null) {
            synchronized (lock) {
                lock.set(z ? com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState.DO_NOT_OVERRIDE : com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState.SHOULD_OVERRIDE);
                lock.notify();
            }
        }
    }

    public android.net.Uri[] getSelectedFiles(android.content.Intent intent, int i) {
        if (intent == null) {
            return null;
        }
        if (intent.getClipData() != null) {
            int itemCount = intent.getClipData().getItemCount();
            android.net.Uri[] uriArr = new android.net.Uri[itemCount];
            for (int i2 = 0; i2 < itemCount; i2++) {
                uriArr[i2] = intent.getClipData().getItemAt(i2).getUri();
            }
            return uriArr;
        }
        if (intent.getData() == null || i != -1) {
            return null;
        }
        return android.webkit.WebChromeClient.FileChooserParams.parseResult(i, intent);
    }

    public void startPhotoPickerIntent(java.lang.String str, android.webkit.ValueCallback<android.net.Uri> valueCallback) {
        android.content.Intent videoIntent;
        android.content.Intent photoIntent;
        this.mFilePathCallbackLegacy = valueCallback;
        android.app.Activity currentActivity = this.mContext.getCurrentActivity();
        android.content.Intent intentCreateChooser = android.content.Intent.createChooser(getFileChooserIntent(str), "");
        java.util.ArrayList arrayList = new java.util.ArrayList();
        if (acceptsImages(str).booleanValue() && (photoIntent = getPhotoIntent()) != null) {
            arrayList.add(photoIntent);
        }
        if (acceptsVideo(str).booleanValue() && (videoIntent = getVideoIntent()) != null) {
            arrayList.add(videoIntent);
        }
        intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", (android.os.Parcelable[]) arrayList.toArray(new android.os.Parcelable[0]));
        if (intentCreateChooser.resolveActivity(currentActivity.getPackageManager()) != null) {
            currentActivity.startActivityForResult(intentCreateChooser, 3);
        } else {
            android.util.Log.w("RNCWebViewModule", "there is no Activity to handle this Intent");
        }
    }

    public boolean startPhotoPickerIntent(java.lang.String[] strArr, boolean z, android.webkit.ValueCallback<android.net.Uri[]> valueCallback, boolean z2) {
        android.content.Intent videoIntent;
        this.mFilePathCallback = valueCallback;
        android.app.Activity currentActivity = this.mContext.getCurrentActivity();
        java.util.ArrayList arrayList = new java.util.ArrayList();
        android.content.Intent photoIntent = null;
        if (!needsCameraPermission()) {
            if (acceptsImages(strArr).booleanValue() && (photoIntent = getPhotoIntent()) != null) {
                arrayList.add(photoIntent);
            }
            if (acceptsVideo(strArr).booleanValue() && (videoIntent = getVideoIntent()) != null) {
                arrayList.add(videoIntent);
            }
        }
        android.content.Intent intent = new android.content.Intent("android.intent.action.CHOOSER");
        if (!z2) {
            intent.putExtra("android.intent.extra.INTENT", getFileChooserIntent(strArr, z));
            intent.putExtra("android.intent.extra.INITIAL_INTENTS", (android.os.Parcelable[]) arrayList.toArray(new android.os.Parcelable[0]));
            photoIntent = intent;
        }
        if (photoIntent == null) {
            android.util.Log.w("RNCWebViewModule", "there is no Camera permission");
        } else if (photoIntent.resolveActivity(currentActivity.getPackageManager()) == null) {
            android.util.Log.w("RNCWebViewModule", "there is no Activity to handle this Intent");
        } else {
            currentActivity.startActivityForResult(photoIntent, 1);
        }
        return true;
    }

    public void setDownloadRequest(android.app.DownloadManager.Request request) {
        this.mDownloadRequest = request;
    }

    public void downloadFile(java.lang.String str) {
        try {
            ((android.app.DownloadManager) this.mContext.getSystemService("download")).enqueue(this.mDownloadRequest);
            android.widget.Toast.makeText(this.mContext, str, 1).show();
        } catch (java.lang.IllegalArgumentException | java.lang.SecurityException e) {
            android.util.Log.w("RNCWebViewModule", "Unsupported URI, aborting download", e);
        }
    }

    public boolean grantFileDownloaderPermissions(java.lang.String str, java.lang.String str2) {
        android.app.Activity currentActivity = this.mContext.getCurrentActivity();
        if (android.os.Build.VERSION.SDK_INT > 28) {
            return true;
        }
        boolean z = androidx.core.content.ContextCompat.checkSelfPermission(currentActivity, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
        if (!z) {
            getPermissionAwareActivity().requestPermissions(new java.lang.String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1, getWebviewFileDownloaderPermissionListener(str, str2));
        }
        return z;
    }

    protected boolean needsCameraPermission() {
        android.app.Activity currentActivity = this.mContext.getCurrentActivity();
        try {
            if (java.util.Arrays.asList(currentActivity.getPackageManager().getPackageInfo(currentActivity.getApplicationContext().getPackageName(), 4096).requestedPermissions).contains("android.permission.CAMERA")) {
                return androidx.core.content.ContextCompat.checkSelfPermission(currentActivity, "android.permission.CAMERA") != 0;
            }
            return false;
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return true;
        }
    }

    public android.content.Intent getPhotoIntent() {
        android.content.Intent intent;
        java.lang.Exception e;
        android.net.Uri outputUri;
        try {
            java.io.File capturedFile = getCapturedFile(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.IMAGE);
            this.mOutputImage = capturedFile;
            outputUri = getOutputUri(capturedFile);
            intent = new android.content.Intent("android.media.action.IMAGE_CAPTURE");
        } catch (java.io.IOException | java.lang.IllegalArgumentException e2) {
            intent = null;
            e = e2;
        }
        try {
            intent.putExtra("output", outputUri);
            return intent;
        } catch (java.io.IOException e3) {
            e = e3;
            android.util.Log.e("CREATE FILE", "Error occurred while creating the File", e);
            e.printStackTrace();
            return intent;
        } catch (java.lang.IllegalArgumentException e4) {
            e = e4;
            android.util.Log.e("CREATE FILE", "Error occurred while creating the File", e);
            e.printStackTrace();
            return intent;
        }
    }

    public android.content.Intent getVideoIntent() {
        android.content.Intent intent;
        java.lang.Exception e;
        android.net.Uri outputUri;
        try {
            java.io.File capturedFile = getCapturedFile(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.VIDEO);
            this.mOutputVideo = capturedFile;
            outputUri = getOutputUri(capturedFile);
            intent = new android.content.Intent("android.media.action.VIDEO_CAPTURE");
        } catch (java.io.IOException | java.lang.IllegalArgumentException e2) {
            intent = null;
            e = e2;
        }
        try {
            intent.putExtra("output", outputUri);
            return intent;
        } catch (java.io.IOException e3) {
            e = e3;
            android.util.Log.e("CREATE FILE", "Error occurred while creating the File", e);
            e.printStackTrace();
            return intent;
        } catch (java.lang.IllegalArgumentException e4) {
            e = e4;
            android.util.Log.e("CREATE FILE", "Error occurred while creating the File", e);
            e.printStackTrace();
            return intent;
        }
    }

    private android.content.Intent getFileChooserIntent(java.lang.String str) {
        java.lang.String mimeTypeFromExtension = str.isEmpty() ? com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.DEFAULT.value : str;
        if (str.matches("\\.\\w+")) {
            mimeTypeFromExtension = getMimeTypeFromExtension(str.replace(".", ""));
        }
        android.content.Intent intent = new android.content.Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType(mimeTypeFromExtension);
        return intent;
    }

    private android.content.Intent getFileChooserIntent(java.lang.String[] strArr, boolean z) {
        android.content.Intent intent = new android.content.Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.DEFAULT.value);
        intent.putExtra("android.intent.extra.MIME_TYPES", getAcceptedMimeType(strArr));
        intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", z);
        return intent;
    }

    private java.lang.Boolean acceptsImages(java.lang.String str) {
        if (str.matches("\\.\\w+")) {
            str = getMimeTypeFromExtension(str.replace(".", ""));
        }
        return java.lang.Boolean.valueOf(str.isEmpty() || str.toLowerCase().contains(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.IMAGE.value));
    }

    private java.lang.Boolean acceptsImages(java.lang.String[] strArr) {
        java.lang.String[] acceptedMimeType = getAcceptedMimeType(strArr);
        return java.lang.Boolean.valueOf(arrayContainsString(acceptedMimeType, com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.DEFAULT.value).booleanValue() || arrayContainsString(acceptedMimeType, com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.IMAGE.value).booleanValue());
    }

    private java.lang.Boolean acceptsVideo(java.lang.String str) {
        if (str.matches("\\.\\w+")) {
            str = getMimeTypeFromExtension(str.replace(".", ""));
        }
        return java.lang.Boolean.valueOf(str.isEmpty() || str.toLowerCase().contains(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.VIDEO.value));
    }

    private java.lang.Boolean acceptsVideo(java.lang.String[] strArr) {
        java.lang.String[] acceptedMimeType = getAcceptedMimeType(strArr);
        return java.lang.Boolean.valueOf(arrayContainsString(acceptedMimeType, com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.DEFAULT.value).booleanValue() || arrayContainsString(acceptedMimeType, com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.VIDEO.value).booleanValue());
    }

    private java.lang.Boolean arrayContainsString(java.lang.String[] strArr, java.lang.String str) {
        for (java.lang.String str2 : strArr) {
            if (str2.contains(str)) {
                return true;
            }
        }
        return false;
    }

    private java.lang.String[] getAcceptedMimeType(java.lang.String[] strArr) {
        if (noAcceptTypesSet(strArr).booleanValue()) {
            return new java.lang.String[]{com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.DEFAULT.value};
        }
        java.lang.String[] strArr2 = new java.lang.String[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            java.lang.String str = strArr[i];
            if (str.matches("\\.\\w+")) {
                java.lang.String mimeTypeFromExtension = getMimeTypeFromExtension(str.replace(".", ""));
                if (mimeTypeFromExtension != null) {
                    strArr2[i] = mimeTypeFromExtension;
                } else {
                    strArr2[i] = str;
                }
            } else {
                strArr2[i] = str;
            }
        }
        return strArr2;
    }

    private java.lang.String getMimeTypeFromExtension(java.lang.String str) {
        if (str != null) {
            return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(str);
        }
        return null;
    }

    public android.net.Uri getOutputUri(java.io.File file) {
        return androidx.core.content.FileProvider.getUriForFile(this.mContext, this.mContext.getPackageName() + ".fileprovider", file);
    }

    /* renamed from: com.reactnativecommunity.webview.RNCWebViewModuleImpl$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$reactnativecommunity$webview$RNCWebViewModuleImpl$MimeType;

        static {
            int[] iArr = new int[com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.values().length];
            $SwitchMap$com$reactnativecommunity$webview$RNCWebViewModuleImpl$MimeType = iArr;
            try {
                iArr[com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.IMAGE.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$reactnativecommunity$webview$RNCWebViewModuleImpl$MimeType[com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType.VIDEO.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
        }
    }

    public java.io.File getCapturedFile(com.reactnativecommunity.webview.RNCWebViewModuleImpl.MimeType mimeType) throws java.io.IOException {
        java.lang.String str;
        java.lang.String str2;
        int i = com.reactnativecommunity.webview.RNCWebViewModuleImpl.AnonymousClass2.$SwitchMap$com$reactnativecommunity$webview$RNCWebViewModuleImpl$MimeType[mimeType.ordinal()];
        if (i == 1) {
            java.lang.String str3 = android.os.Environment.DIRECTORY_PICTURES;
            str = "image-";
            str2 = ".jpg";
        } else if (i != 2) {
            str = "";
            str2 = "";
        } else {
            java.lang.String str4 = android.os.Environment.DIRECTORY_MOVIES;
            str = "video-";
            str2 = ".mp4";
        }
        java.lang.String str5 = str + java.lang.String.valueOf(java.lang.System.currentTimeMillis()) + str2;
        return java.io.File.createTempFile(str, str2, this.mContext.getExternalFilesDir(null));
    }

    private java.lang.Boolean noAcceptTypesSet(java.lang.String[] strArr) {
        java.lang.String str;
        boolean z = true;
        if (strArr.length != 0 && (strArr.length != 1 || (str = strArr[0]) == null || str.length() != 0)) {
            z = false;
        }
        return java.lang.Boolean.valueOf(z);
    }

    private com.facebook.react.modules.core.PermissionAwareActivity getPermissionAwareActivity() {
        android.content.ComponentCallbacks2 currentActivity = this.mContext.getCurrentActivity();
        if (currentActivity == null) {
            throw new java.lang.IllegalStateException("Tried to use permissions API while not attached to an Activity.");
        }
        if (!(currentActivity instanceof com.facebook.react.modules.core.PermissionAwareActivity)) {
            throw new java.lang.IllegalStateException("Tried to use permissions API but the host Activity doesn't implement PermissionAwareActivity.");
        }
        return (com.facebook.react.modules.core.PermissionAwareActivity) currentActivity;
    }
}
