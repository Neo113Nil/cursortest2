package com.reactnativecommunity.webview;

/* loaded from: classes3.dex */
public class RNCWebViewClient extends android.webkit.WebViewClient {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    protected static final int SHOULD_OVERRIDE_URL_LOADING_TIMEOUT = 250;
    private static java.lang.String TAG = "RNCWebViewClient";
    protected boolean mLastLoadFailed = false;
    protected com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter progressChangedFilter = null;
    protected java.lang.String ignoreErrFailedForThisURL = null;
    protected com.reactnativecommunity.webview.RNCBasicAuthCredential basicAuthCredential = null;

    public void setIgnoreErrFailedForThisURL(java.lang.String str) {
        this.ignoreErrFailedForThisURL = str;
    }

    public void setBasicAuthCredential(com.reactnativecommunity.webview.RNCBasicAuthCredential rNCBasicAuthCredential) {
        this.basicAuthCredential = rNCBasicAuthCredential;
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(android.webkit.WebView webView, java.lang.String str) {
        super.onPageFinished(webView, str);
        if (android.webkit.CookieManager.getInstance().getCookie(str) != null) {
            android.webkit.CookieManager.getInstance().flush();
        }
        if (this.mLastLoadFailed) {
            return;
        }
        ((com.reactnativecommunity.webview.RNCWebView) webView).callInjectedJavaScript();
        emitFinishEvent(webView, str);
    }

    @Override // android.webkit.WebViewClient
    public void doUpdateVisitedHistory(android.webkit.WebView webView, java.lang.String str, boolean z) {
        super.doUpdateVisitedHistory(webView, str, z);
        ((com.reactnativecommunity.webview.RNCWebView) webView).dispatchEvent(webView, new com.reactnativecommunity.webview.events.TopLoadingStartEvent(com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView), createWebViewEvent(webView, str)));
    }

    @Override // android.webkit.WebViewClient
    public void onPageStarted(android.webkit.WebView webView, java.lang.String str, android.graphics.Bitmap bitmap) {
        super.onPageStarted(webView, str, bitmap);
        this.mLastLoadFailed = false;
        ((com.reactnativecommunity.webview.RNCWebView) webView).callInjectedJavaScriptBeforeContentLoaded();
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, java.lang.String str) {
        com.reactnativecommunity.webview.RNCWebView rNCWebView = (com.reactnativecommunity.webview.RNCWebView) webView;
        if (rNCWebView.getReactApplicationContext().getJavaScriptContextHolder().getContext() != 0 && rNCWebView.mMessagingJSModule != null) {
            androidx.core.util.Pair<java.lang.Double, java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState>> newLock = com.reactnativecommunity.webview.RNCWebViewModuleImpl.shouldOverrideUrlLoadingLock.getNewLock();
            double dDoubleValue = newLock.first.doubleValue();
            java.util.concurrent.atomic.AtomicReference<com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState> atomicReference = newLock.second;
            com.facebook.react.bridge.WritableMap writableMapCreateWebViewEvent = createWebViewEvent(webView, str);
            writableMapCreateWebViewEvent.putDouble("lockIdentifier", dDoubleValue);
            rNCWebView.dispatchDirectShouldStartLoadWithRequest(writableMapCreateWebViewEvent);
            try {
                synchronized (atomicReference) {
                    long jElapsedRealtime = android.os.SystemClock.elapsedRealtime();
                    while (atomicReference.get() == com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState.UNDECIDED) {
                        if (android.os.SystemClock.elapsedRealtime() - jElapsedRealtime > 250) {
                            com.facebook.common.logging.FLog.w(TAG, "Did not receive response to shouldOverrideUrlLoading in time, defaulting to allow loading.");
                            com.reactnativecommunity.webview.RNCWebViewModuleImpl.shouldOverrideUrlLoadingLock.removeLock(java.lang.Double.valueOf(dDoubleValue));
                            return false;
                        }
                        atomicReference.wait(250L);
                    }
                    boolean z = atomicReference.get() == com.reactnativecommunity.webview.RNCWebViewModuleImpl.ShouldOverrideUrlLoadingLock.ShouldOverrideCallbackState.SHOULD_OVERRIDE;
                    com.reactnativecommunity.webview.RNCWebViewModuleImpl.shouldOverrideUrlLoadingLock.removeLock(java.lang.Double.valueOf(dDoubleValue));
                    return z;
                }
            } catch (java.lang.InterruptedException e) {
                com.facebook.common.logging.FLog.e(TAG, "shouldOverrideUrlLoading was interrupted while waiting for result.", e);
                com.reactnativecommunity.webview.RNCWebViewModuleImpl.shouldOverrideUrlLoadingLock.removeLock(java.lang.Double.valueOf(dDoubleValue));
                return false;
            }
        }
        com.facebook.common.logging.FLog.w(TAG, "Couldn't use blocking synchronous call for onShouldStartLoadWithRequest due to debugging or missing Catalyst instance, falling back to old event-and-load.");
        this.progressChangedFilter.setWaitingForCommandLoadUrl(true);
        int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag((com.facebook.react.bridge.ReactContext) webView.getContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopShouldStartLoadWithRequestEvent(reactTagFromWebView, createWebViewEvent(webView, str)));
        return true;
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest) {
        return shouldOverrideUrlLoading(webView, webResourceRequest.getUrl().toString());
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedHttpAuthRequest(android.webkit.WebView webView, android.webkit.HttpAuthHandler httpAuthHandler, java.lang.String str, java.lang.String str2) {
        com.reactnativecommunity.webview.RNCBasicAuthCredential rNCBasicAuthCredential = this.basicAuthCredential;
        if (rNCBasicAuthCredential != null) {
            httpAuthHandler.proceed(rNCBasicAuthCredential.username, this.basicAuthCredential.password);
        } else {
            super.onReceivedHttpAuthRequest(webView, httpAuthHandler, str, str2);
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedSslError(android.webkit.WebView webView, android.webkit.SslErrorHandler sslErrorHandler, android.net.http.SslError sslError) {
        java.lang.String str;
        java.lang.String url = webView.getUrl();
        java.lang.String url2 = sslError.getUrl();
        sslErrorHandler.cancel();
        if (!url.equalsIgnoreCase(url2)) {
            android.util.Log.w(TAG, "Resource blocked from loading due to SSL error. Blocked URL: " + url2);
            return;
        }
        int primaryError = sslError.getPrimaryError();
        if (primaryError == 0) {
            str = "The certificate is not yet valid";
        } else if (primaryError == 1) {
            str = "The certificate has expired";
        } else if (primaryError == 2) {
            str = "Hostname mismatch";
        } else if (primaryError == 3) {
            str = "The certificate authority is not trusted";
        } else if (primaryError == 4) {
            str = "The date of the certificate is invalid";
        } else if (primaryError == 5) {
            str = "A generic error occurred";
        } else {
            str = "Unknown SSL Error";
        }
        onReceivedError(webView, primaryError, "SSL error: ".concat(str), url2);
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedError(android.webkit.WebView webView, int i, java.lang.String str, java.lang.String str2) {
        java.lang.String str3 = this.ignoreErrFailedForThisURL;
        if (str3 != null && str2.equals(str3) && i == -1 && str.equals("net::ERR_FAILED")) {
            setIgnoreErrFailedForThisURL(null);
            return;
        }
        super.onReceivedError(webView, i, str, str2);
        this.mLastLoadFailed = true;
        emitFinishEvent(webView, str2);
        com.facebook.react.bridge.WritableMap writableMapCreateWebViewEvent = createWebViewEvent(webView, str2);
        writableMapCreateWebViewEvent.putDouble("code", i);
        writableMapCreateWebViewEvent.putString("description", str);
        int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag((com.facebook.react.bridge.ReactContext) webView.getContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopLoadingErrorEvent(reactTagFromWebView, writableMapCreateWebViewEvent));
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedHttpError(android.webkit.WebView webView, android.webkit.WebResourceRequest webResourceRequest, android.webkit.WebResourceResponse webResourceResponse) {
        super.onReceivedHttpError(webView, webResourceRequest, webResourceResponse);
        if (webResourceRequest.isForMainFrame()) {
            com.facebook.react.bridge.WritableMap writableMapCreateWebViewEvent = createWebViewEvent(webView, webResourceRequest.getUrl().toString());
            writableMapCreateWebViewEvent.putInt("statusCode", webResourceResponse.getStatusCode());
            writableMapCreateWebViewEvent.putString("description", webResourceResponse.getReasonPhrase());
            int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
            com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag((com.facebook.react.bridge.ReactContext) webView.getContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopHttpErrorEvent(reactTagFromWebView, writableMapCreateWebViewEvent));
        }
    }

    @Override // android.webkit.WebViewClient
    public boolean onRenderProcessGone(android.webkit.WebView webView, android.webkit.RenderProcessGoneDetail renderProcessGoneDetail) {
        if (android.os.Build.VERSION.SDK_INT < 26) {
            return false;
        }
        super.onRenderProcessGone(webView, renderProcessGoneDetail);
        if (renderProcessGoneDetail.didCrash()) {
            android.util.Log.e(TAG, "The WebView rendering process crashed.");
        } else {
            android.util.Log.w(TAG, "The WebView rendering process was killed by the system.");
        }
        if (webView == null) {
            return true;
        }
        com.facebook.react.bridge.WritableMap writableMapCreateWebViewEvent = createWebViewEvent(webView, webView.getUrl());
        writableMapCreateWebViewEvent.putBoolean("didCrash", renderProcessGoneDetail.didCrash());
        int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag((com.facebook.react.bridge.ReactContext) webView.getContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopRenderProcessGoneEvent(reactTagFromWebView, writableMapCreateWebViewEvent));
        return true;
    }

    protected void emitFinishEvent(android.webkit.WebView webView, java.lang.String str) {
        int reactTagFromWebView = com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView);
        com.facebook.react.uimanager.UIManagerHelper.getEventDispatcherForReactTag((com.facebook.react.bridge.ReactContext) webView.getContext(), reactTagFromWebView).dispatchEvent(new com.reactnativecommunity.webview.events.TopLoadingFinishEvent(reactTagFromWebView, createWebViewEvent(webView, str)));
    }

    protected com.facebook.react.bridge.WritableMap createWebViewEvent(android.webkit.WebView webView, java.lang.String str) {
        com.facebook.react.bridge.WritableMap writableMapCreateMap = com.facebook.react.bridge.Arguments.createMap();
        writableMapCreateMap.putDouble("target", com.reactnativecommunity.webview.RNCWebViewWrapper.getReactTagFromWebView(webView));
        writableMapCreateMap.putString("url", str);
        writableMapCreateMap.putBoolean("loading", (this.mLastLoadFailed || webView.getProgress() == 100) ? false : true);
        writableMapCreateMap.putString("title", webView.getTitle());
        writableMapCreateMap.putBoolean("canGoBack", webView.canGoBack());
        writableMapCreateMap.putBoolean("canGoForward", webView.canGoForward());
        return writableMapCreateMap;
    }

    public void setProgressChangedFilter(com.reactnativecommunity.webview.RNCWebView.ProgressChangedFilter progressChangedFilter) {
        this.progressChangedFilter = progressChangedFilter;
    }
}
