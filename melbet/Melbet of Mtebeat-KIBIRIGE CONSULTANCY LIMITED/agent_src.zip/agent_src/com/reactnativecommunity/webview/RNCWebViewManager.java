package com.reactnativecommunity.webview;

@com.facebook.react.module.annotations.ReactModule(name = com.reactnativecommunity.webview.RNCWebViewManagerImpl.NAME)
/* loaded from: classes3.dex */
public class RNCWebViewManager extends com.facebook.react.uimanager.ViewGroupManager<com.reactnativecommunity.webview.RNCWebViewWrapper> implements com.facebook.react.viewmanagers.RNCWebViewManagerInterface<com.reactnativecommunity.webview.RNCWebViewWrapper> {
    private final com.facebook.react.uimanager.ViewManagerDelegate<com.reactnativecommunity.webview.RNCWebViewWrapper> mDelegate = new com.facebook.react.viewmanagers.RNCWebViewManagerDelegate(this);
    private final com.reactnativecommunity.webview.RNCWebViewManagerImpl mRNCWebViewManagerImpl = new com.reactnativecommunity.webview.RNCWebViewManagerImpl(true);

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowingReadAccessToURL(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowsAirPlayForMediaPlayback(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowsBackForwardNavigationGestures(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowsInlineMediaPlayback(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowsLinkPreview(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAllowsPictureInPictureMediaPlayback(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAutoManageStatusBarEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setAutomaticallyAdjustContentInsets(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setBounces(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setContentInset(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableMap readableMap) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setContentInsetAdjustmentBehavior(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setContentMode(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setDataDetectorTypes(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableArray readableArray) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setDecelerationRate(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, double d) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setDirectionalLockEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setEnableApplePay(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setFraudulentWebsiteWarningEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setHasOnFileDownload(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setHideKeyboardAccessoryView(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setIndicatorStyle(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setKeyboardDisplayRequiresUserAction(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setLimitsNavigationsToAppBoundDomains(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setMediaCapturePermissionGrantType(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setPagingEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setPullToRefreshEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setRefreshControlLightMode(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setScrollEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setSharedCookiesEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "suppressMenuItems")
    public void setSuppressMenuItems(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableArray readableArray) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setTextInteractionEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void setUseSharedProcessPool(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
    }

    @Override // com.facebook.react.uimanager.ViewManager
    protected com.facebook.react.uimanager.ViewManagerDelegate<com.reactnativecommunity.webview.RNCWebViewWrapper> getDelegate() {
        return this.mDelegate;
    }

    @Override // com.facebook.react.uimanager.ViewManager, com.facebook.react.bridge.NativeModule
    public java.lang.String getName() {
        return com.reactnativecommunity.webview.RNCWebViewManagerImpl.NAME;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.facebook.react.uimanager.ViewManager
    public com.reactnativecommunity.webview.RNCWebViewWrapper createViewInstance(com.facebook.react.uimanager.ThemedReactContext themedReactContext) {
        return this.mRNCWebViewManagerImpl.createViewInstance(themedReactContext);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "allowFileAccess")
    public void setAllowFileAccess(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setAllowFileAccess(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "allowFileAccessFromFileURLs")
    public void setAllowFileAccessFromFileURLs(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setAllowFileAccessFromFileURLs(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "allowUniversalAccessFromFileURLs")
    public void setAllowUniversalAccessFromFileURLs(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setAllowUniversalAccessFromFileURLs(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "allowsFullscreenVideo")
    public void setAllowsFullscreenVideo(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setAllowsFullscreenVideo(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "allowsProtectedMedia")
    public void setAllowsProtectedMedia(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setAllowsProtectedMedia(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "androidLayerType")
    public void setAndroidLayerType(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setAndroidLayerType(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "applicationNameForUserAgent")
    public void setApplicationNameForUserAgent(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setApplicationNameForUserAgent(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "basicAuthCredential")
    public void setBasicAuthCredential(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableMap readableMap) {
        this.mRNCWebViewManagerImpl.setBasicAuthCredential(rNCWebViewWrapper, readableMap);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "cacheEnabled")
    public void setCacheEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setCacheEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "cacheMode")
    public void setCacheMode(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setCacheMode(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "domStorageEnabled")
    public void setDomStorageEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setDomStorageEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "downloadingMessage")
    public void setDownloadingMessage(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setDownloadingMessage(str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "forceDarkOn")
    public void setForceDarkOn(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setForceDarkOn(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "geolocationEnabled")
    public void setGeolocationEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setGeolocationEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "hasOnScroll")
    public void setHasOnScroll(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setHasOnScroll(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "incognito")
    public void setIncognito(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setIncognito(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "injectedJavaScript")
    public void setInjectedJavaScript(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setInjectedJavaScript(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "injectedJavaScriptBeforeContentLoaded")
    public void setInjectedJavaScriptBeforeContentLoaded(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setInjectedJavaScriptBeforeContentLoaded(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "injectedJavaScriptForMainFrameOnly")
    public void setInjectedJavaScriptForMainFrameOnly(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setInjectedJavaScriptForMainFrameOnly(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "injectedJavaScriptBeforeContentLoadedForMainFrameOnly")
    public void setInjectedJavaScriptBeforeContentLoadedForMainFrameOnly(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setInjectedJavaScriptBeforeContentLoadedForMainFrameOnly(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "injectedJavaScriptObject")
    public void setInjectedJavaScriptObject(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setInjectedJavaScriptObject(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "javaScriptCanOpenWindowsAutomatically")
    public void setJavaScriptCanOpenWindowsAutomatically(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setJavaScriptCanOpenWindowsAutomatically(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "javaScriptEnabled")
    public void setJavaScriptEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setJavaScriptEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "lackPermissionToDownloadMessage")
    public void setLackPermissionToDownloadMessage(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setLackPermissionToDownloadMessage(str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "hasOnOpenWindowEvent")
    public void setHasOnOpenWindowEvent(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setHasOnOpenWindowEvent(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "mediaPlaybackRequiresUserAction")
    public void setMediaPlaybackRequiresUserAction(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setMediaPlaybackRequiresUserAction(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "menuItems")
    public void setMenuItems(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableArray readableArray) {
        this.mRNCWebViewManagerImpl.setMenuCustomItems(rNCWebViewWrapper, readableArray);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "messagingEnabled")
    public void setMessagingEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setMessagingEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "messagingModuleName")
    public void setMessagingModuleName(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setMessagingModuleName(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "minimumFontSize")
    public void setMinimumFontSize(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, int i) {
        this.mRNCWebViewManagerImpl.setMinimumFontSize(rNCWebViewWrapper, i);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "mixedContentMode")
    public void setMixedContentMode(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setMixedContentMode(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "nestedScrollEnabled")
    public void setNestedScrollEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setNestedScrollEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "overScrollMode")
    public void setOverScrollMode(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setOverScrollMode(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "saveFormDataDisabled")
    public void setSaveFormDataDisabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setSaveFormDataDisabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "scalesPageToFit")
    public void setScalesPageToFit(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setScalesPageToFit(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "setBuiltInZoomControls")
    public void setSetBuiltInZoomControls(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setSetBuiltInZoomControls(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "setDisplayZoomControls")
    public void setSetDisplayZoomControls(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setSetDisplayZoomControls(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "setSupportMultipleWindows")
    public void setSetSupportMultipleWindows(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setSetSupportMultipleWindows(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "showsHorizontalScrollIndicator")
    public void setShowsHorizontalScrollIndicator(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setShowsHorizontalScrollIndicator(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "showsVerticalScrollIndicator")
    public void setShowsVerticalScrollIndicator(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setShowsVerticalScrollIndicator(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "newSource")
    public void setNewSource(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, com.facebook.react.bridge.ReadableMap readableMap) {
        this.mRNCWebViewManagerImpl.setSource(rNCWebViewWrapper, readableMap);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "textZoom")
    public void setTextZoom(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, int i) {
        this.mRNCWebViewManagerImpl.setTextZoom(rNCWebViewWrapper, i);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "thirdPartyCookiesEnabled")
    public void setThirdPartyCookiesEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setThirdPartyCookiesEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "webviewDebuggingEnabled")
    public void setWebviewDebuggingEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setWebviewDebuggingEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "paymentRequestEnabled")
    public void setPaymentRequestEnabled(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        this.mRNCWebViewManagerImpl.setPaymentRequestEnabled(rNCWebViewWrapper, z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    @com.facebook.react.uimanager.annotations.ReactProp(name = "userAgent")
    public void setUserAgent(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        this.mRNCWebViewManagerImpl.setUserAgent(rNCWebViewWrapper, str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void goBack(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().goBack();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void goForward(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().goForward();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void reload(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().reload();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void stopLoading(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().stopLoading();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void injectJavaScript(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        rNCWebViewWrapper.getWebView().evaluateJavascriptWithFallback(str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void requestFocus(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.requestFocus();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void postMessage(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) throws org.json.JSONException {
        try {
            org.json.JSONObject jSONObject = new org.json.JSONObject();
            jSONObject.put("data", str);
            rNCWebViewWrapper.getWebView().evaluateJavascriptWithFallback("(function () {var event;var data = " + jSONObject.toString() + ";try {event = new MessageEvent('message', data);} catch (e) {event = document.createEvent('MessageEvent');event.initMessageEvent('message', true, true, data.data, data.origin, data.lastEventId, data.source);}document.dispatchEvent(event);})();");
        } catch (org.json.JSONException e) {
            throw new java.lang.RuntimeException(e);
        }
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void loadUrl(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str) {
        rNCWebViewWrapper.getWebView().loadUrl(str);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void clearFormData(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().clearFormData();
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void clearCache(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, boolean z) {
        rNCWebViewWrapper.getWebView().clearCache(z);
    }

    @Override // com.facebook.react.viewmanagers.RNCWebViewManagerInterface
    public void clearHistory(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().clearHistory();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.facebook.react.uimanager.BaseViewManager, com.facebook.react.uimanager.ViewManager
    public void addEventEmitters(com.facebook.react.uimanager.ThemedReactContext themedReactContext, com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        rNCWebViewWrapper.getWebView().setWebViewClient(new com.reactnativecommunity.webview.RNCWebViewClient());
    }

    @Override // com.facebook.react.uimanager.BaseViewManager, com.facebook.react.uimanager.ViewManager
    public java.util.Map<java.lang.String, java.lang.Object> getExportedCustomDirectEventTypeConstants() {
        java.util.Map<java.lang.String, java.lang.Object> exportedCustomDirectEventTypeConstants = super.getExportedCustomDirectEventTypeConstants();
        if (exportedCustomDirectEventTypeConstants == null) {
            exportedCustomDirectEventTypeConstants = com.facebook.react.common.MapBuilder.newHashMap();
        }
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopLoadingStartEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onLoadingStart"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopLoadingFinishEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onLoadingFinish"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopLoadingErrorEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onLoadingError"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopMessageEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onMessage"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopLoadingProgressEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onLoadingProgress"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopShouldStartLoadWithRequestEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onShouldStartLoadWithRequest"));
        exportedCustomDirectEventTypeConstants.put(com.facebook.react.views.scroll.ScrollEventType.getJSEventName(com.facebook.react.views.scroll.ScrollEventType.SCROLL), com.facebook.react.common.MapBuilder.of("registrationName", "onScroll"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopHttpErrorEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onHttpError"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopRenderProcessGoneEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onRenderProcessGone"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopCustomMenuSelectionEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onCustomMenuSelection"));
        exportedCustomDirectEventTypeConstants.put(com.reactnativecommunity.webview.events.TopOpenWindowEvent.EVENT_NAME, com.facebook.react.common.MapBuilder.of("registrationName", "onOpenWindow"));
        return exportedCustomDirectEventTypeConstants;
    }

    @Override // com.facebook.react.uimanager.ViewManager
    public java.util.Map<java.lang.String, java.lang.Integer> getCommandsMap() {
        return this.mRNCWebViewManagerImpl.getCommandsMap();
    }

    @Override // com.facebook.react.uimanager.ViewManager
    public void receiveCommand(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper, java.lang.String str, com.facebook.react.bridge.ReadableArray readableArray) {
        super.receiveCommand((com.reactnativecommunity.webview.RNCWebViewManager) rNCWebViewWrapper, str, readableArray);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.facebook.react.uimanager.BaseViewManager, com.facebook.react.uimanager.ViewManager
    public void onAfterUpdateTransaction(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        super.onAfterUpdateTransaction((com.reactnativecommunity.webview.RNCWebViewManager) rNCWebViewWrapper);
        this.mRNCWebViewManagerImpl.onAfterUpdateTransaction(rNCWebViewWrapper);
    }

    @Override // com.facebook.react.uimanager.BaseViewManager, com.facebook.react.uimanager.ViewManager
    public void onDropViewInstance(com.reactnativecommunity.webview.RNCWebViewWrapper rNCWebViewWrapper) {
        this.mRNCWebViewManagerImpl.onDropViewInstance(rNCWebViewWrapper);
        super.onDropViewInstance((com.reactnativecommunity.webview.RNCWebViewManager) rNCWebViewWrapper);
    }
}
