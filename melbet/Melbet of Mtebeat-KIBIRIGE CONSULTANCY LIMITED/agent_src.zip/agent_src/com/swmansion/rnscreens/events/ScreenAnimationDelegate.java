package com.swmansion.rnscreens.events;

/* compiled from: ScreenAnimationDelegate.kt */
@kotlin.Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 \u00162\u00020\u0001:\u0003\u0014\u0015\u0016B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\b\u0010\f\u001a\u00020\rH\u0002J\u0010\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u0011\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u0012\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u0013\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate;", "Landroid/animation/Animator$AnimatorListener;", "wrapper", "Lcom/swmansion/rnscreens/ScreenStackFragmentWrapper;", "eventEmitter", "Lcom/swmansion/rnscreens/events/ScreenEventEmitter;", "animationType", "Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate$AnimationType;", "<init>", "(Lcom/swmansion/rnscreens/ScreenStackFragmentWrapper;Lcom/swmansion/rnscreens/events/ScreenEventEmitter;Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate$AnimationType;)V", "currentState", "Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate$LifecycleState;", "progressState", "", "onAnimationStart", "animation", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationCancel", "onAnimationRepeat", "AnimationType", "LifecycleState", "Companion", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class ScreenAnimationDelegate implements android.animation.Animator.AnimatorListener {
    public static final java.lang.String TAG = "ScreenEventDelegate";
    private final com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType animationType;
    private com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState currentState;
    private final com.swmansion.rnscreens.events.ScreenEventEmitter eventEmitter;
    private final com.swmansion.rnscreens.ScreenStackFragmentWrapper wrapper;

    /* compiled from: ScreenAnimationDelegate.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.values().length];
            try {
                iArr[com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.INITIALIZED.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                iArr[com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.START_DISPATCHED.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                iArr[com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.END_DISPATCHED.ordinal()] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.values().length];
            try {
                iArr2[com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.ENTER.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused4) {
            }
            try {
                iArr2[com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.EXIT.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationCancel(android.animation.Animator animation) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animation, "animation");
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationRepeat(android.animation.Animator animation) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animation, "animation");
    }

    public ScreenAnimationDelegate(com.swmansion.rnscreens.ScreenStackFragmentWrapper wrapper, com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter, com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType animationType) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(wrapper, "wrapper");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animationType, "animationType");
        this.wrapper = wrapper;
        this.eventEmitter = screenEventEmitter;
        this.animationType = animationType;
        this.currentState = com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.INITIALIZED;
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: ScreenAnimationDelegate.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate$AnimationType;", "", "<init>", "(Ljava/lang/String;I)V", "ENTER", "EXIT", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class AnimationType {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[] $VALUES;
        public static final com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType ENTER = new com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType("ENTER", 0);
        public static final com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType EXIT = new com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType("EXIT", 1);

        private static final /* synthetic */ com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[] $values() {
            return new com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[]{ENTER, EXIT};
        }

        public static kotlin.enums.EnumEntries<com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType> getEntries() {
            return $ENTRIES;
        }

        private AnimationType(java.lang.String str, int i) {
        }

        static {
            com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[] animationTypeArr$values = $values();
            $VALUES = animationTypeArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(animationTypeArr$values);
        }

        public static com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType valueOf(java.lang.String str) {
            return (com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType) java.lang.Enum.valueOf(com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.class, str);
        }

        public static com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[] values() {
            return (com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType[]) $VALUES.clone();
        }
    }

    private final void progressState() {
        com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState lifecycleState;
        int i = com.swmansion.rnscreens.events.ScreenAnimationDelegate.WhenMappings.$EnumSwitchMapping$0[this.currentState.ordinal()];
        if (i == 1) {
            lifecycleState = com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.START_DISPATCHED;
        } else {
            if (i != 2 && i != 3) {
                throw new kotlin.NoWhenBranchMatchedException();
            }
            lifecycleState = com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.END_DISPATCHED;
        }
        this.currentState = lifecycleState;
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationStart(android.animation.Animator animation) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animation, "animation");
        if (this.currentState == com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.INITIALIZED) {
            progressState();
            int i = com.swmansion.rnscreens.events.ScreenAnimationDelegate.WhenMappings.$EnumSwitchMapping$1[this.animationType.ordinal()];
            if (i == 1) {
                com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter = this.eventEmitter;
                if (screenEventEmitter != null) {
                    screenEventEmitter.dispatchOnWillAppear();
                }
            } else {
                if (i != 2) {
                    throw new kotlin.NoWhenBranchMatchedException();
                }
                com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter2 = this.eventEmitter;
                if (screenEventEmitter2 != null) {
                    screenEventEmitter2.dispatchOnWillDisappear();
                }
            }
            boolean z = this.animationType == com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.EXIT;
            com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter3 = this.eventEmitter;
            if (screenEventEmitter3 != null) {
                screenEventEmitter3.dispatchTransitionProgress(0.0f, z, z);
            }
        }
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationEnd(android.animation.Animator animation) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(animation, "animation");
        if (this.currentState == com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.START_DISPATCHED) {
            progressState();
            animation.removeListener(this);
            int i = com.swmansion.rnscreens.events.ScreenAnimationDelegate.WhenMappings.$EnumSwitchMapping$1[this.animationType.ordinal()];
            if (i == 1) {
                com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter = this.eventEmitter;
                if (screenEventEmitter != null) {
                    screenEventEmitter.dispatchOnAppear();
                }
            } else {
                if (i != 2) {
                    throw new kotlin.NoWhenBranchMatchedException();
                }
                com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter2 = this.eventEmitter;
                if (screenEventEmitter2 != null) {
                    screenEventEmitter2.dispatchOnDisappear();
                }
            }
            boolean z = this.animationType == com.swmansion.rnscreens.events.ScreenAnimationDelegate.AnimationType.EXIT;
            com.swmansion.rnscreens.events.ScreenEventEmitter screenEventEmitter3 = this.eventEmitter;
            if (screenEventEmitter3 != null) {
                screenEventEmitter3.dispatchTransitionProgress(1.0f, z, z);
            }
            this.wrapper.getScreen().endRemovalTransition();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: ScreenAnimationDelegate.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/swmansion/rnscreens/events/ScreenAnimationDelegate$LifecycleState;", "", "<init>", "(Ljava/lang/String;I)V", "INITIALIZED", "START_DISPATCHED", "END_DISPATCHED", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private static final class LifecycleState {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
        private static final /* synthetic */ com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[] $VALUES;
        public static final com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState INITIALIZED = new com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState("INITIALIZED", 0);
        public static final com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState START_DISPATCHED = new com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState("START_DISPATCHED", 1);
        public static final com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState END_DISPATCHED = new com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState("END_DISPATCHED", 2);

        private static final /* synthetic */ com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[] $values() {
            return new com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[]{INITIALIZED, START_DISPATCHED, END_DISPATCHED};
        }

        public static kotlin.enums.EnumEntries<com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState> getEntries() {
            return $ENTRIES;
        }

        private LifecycleState(java.lang.String str, int i) {
        }

        static {
            com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[] lifecycleStateArr$values = $values();
            $VALUES = lifecycleStateArr$values;
            $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(lifecycleStateArr$values);
        }

        public static com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState valueOf(java.lang.String str) {
            return (com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState) java.lang.Enum.valueOf(com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState.class, str);
        }

        public static com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[] values() {
            return (com.swmansion.rnscreens.events.ScreenAnimationDelegate.LifecycleState[]) $VALUES.clone();
        }
    }
}
