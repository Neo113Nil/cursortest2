package com.swmansion.rnscreens.gamma.tabs;

/* compiled from: TabsHost.kt */
@kotlin.Metadata(d1 = {"\u0000\u0096\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u000e\n\u0002\b\u0012\n\u0002\u0010\u0007\n\u0002\b\u001b\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \u0096\u00012\u00020\u00012\u00020\u0002:\u0004\u0095\u0001\u0096\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J#\u0010i\u001a\u00020j\"\u0004\b\u0000\u0010k2\u0006\u0010l\u001a\u0002Hk2\u0006\u0010m\u001a\u0002HkH\u0002¢\u0006\u0002\u0010nJ\b\u0010o\u001a\u00020jH\u0014J\u001d\u0010p\u001a\u00020j2\u0006\u0010q\u001a\u00020r2\u0006\u0010s\u001a\u00020 H\u0000¢\u0006\u0002\btJ\u0015\u0010u\u001a\u00020j2\u0006\u0010s\u001a\u00020 H\u0000¢\u0006\u0002\bvJ\u0015\u0010w\u001a\u00020j2\u0006\u0010x\u001a\u00020rH\u0000¢\u0006\u0002\byJ\r\u0010z\u001a\u00020jH\u0000¢\u0006\u0002\b{J\u0018\u0010|\u001a\u00020j2\u0006\u0010q\u001a\u00020r2\u0006\u0010}\u001a\u00020#H\u0016J\u0010\u0010~\u001a\u00020j2\u0006\u0010q\u001a\u00020rH\u0016J\u0012\u0010\u007f\u001a\u0004\u0018\u00010\u001e2\u0006\u0010q\u001a\u00020rH\u0016J\u001b\u0010\u0080\u0001\u001a\u00020j2\u0006\u0010q\u001a\u00020r2\b\u0010\u0081\u0001\u001a\u00030\u0082\u0001H\u0016J\t\u0010\u0083\u0001\u001a\u00020jH\u0002J\t\u0010\u0084\u0001\u001a\u00020jH\u0002J\t\u0010\u0087\u0001\u001a\u00020jH\u0002J\t\u0010\u0088\u0001\u001a\u00020jH\u0016J\u0015\u0010\u0089\u0001\u001a\u00020j2\n\u0010\u008a\u0001\u001a\u0005\u0018\u00010\u0082\u0001H\u0014J\u0012\u0010\u008b\u0001\u001a\u00020j2\u0007\u0010\u008c\u0001\u001a\u00020 H\u0002J\t\u0010\u008d\u0001\u001a\u00020jH\u0002J\u0014\u0010\u008e\u0001\u001a\u0004\u0018\u00010\u001e2\u0007\u0010\u008f\u0001\u001a\u00020 H\u0002J\u0010\u0010\u0090\u0001\u001a\u0004\u0018\u00010 H\u0002¢\u0006\u0002\u0010)J\u0014\u0010\u0091\u0001\u001a\u0005\u0018\u00010\u0092\u00012\u0006\u0010q\u001a\u00020rH\u0002J\u000f\u0010\u0093\u0001\u001a\u00020jH\u0000¢\u0006\u0003\b\u0094\u0001R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0012\u0010\t\u001a\u00060\nR\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0011\u001a\u00020\u0012X\u0080.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0014\"\u0004\b\u0015\u0010\u0016R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0019\u001a\u00020\u00188BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u001f\u001a\u0004\u0018\u00010 X\u0082\u000e¢\u0006\u0004\n\u0002\u0010!R\u000e\u0010\"\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u0004¢\u0006\u0002\n\u0000R/\u0010'\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b,\u0010-\u001a\u0004\b(\u0010)\"\u0004\b*\u0010+R/\u0010.\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b1\u0010-\u001a\u0004\b/\u0010)\"\u0004\b0\u0010+R+\u00102\u001a\u00020#2\u0006\u0010&\u001a\u00020#8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b6\u0010-\u001a\u0004\b2\u00103\"\u0004\b4\u00105R/\u00107\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b:\u0010-\u001a\u0004\b8\u0010)\"\u0004\b9\u0010+R/\u0010<\u001a\u0004\u0018\u00010;2\b\u0010&\u001a\u0004\u0018\u00010;8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bA\u0010-\u001a\u0004\b=\u0010>\"\u0004\b?\u0010@R/\u0010B\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bE\u0010-\u001a\u0004\bC\u0010)\"\u0004\bD\u0010+R/\u0010F\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bI\u0010-\u001a\u0004\bG\u0010)\"\u0004\bH\u0010+R/\u0010J\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bM\u0010-\u001a\u0004\bK\u0010)\"\u0004\bL\u0010+R/\u0010O\u001a\u0004\u0018\u00010N2\b\u0010&\u001a\u0004\u0018\u00010N8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bT\u0010-\u001a\u0004\bP\u0010Q\"\u0004\bR\u0010SR/\u0010U\u001a\u0004\u0018\u00010N2\b\u0010&\u001a\u0004\u0018\u00010N8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bX\u0010-\u001a\u0004\bV\u0010Q\"\u0004\bW\u0010SR/\u0010Y\u001a\u0004\u0018\u00010;2\b\u0010&\u001a\u0004\u0018\u00010;8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\\\u0010-\u001a\u0004\bZ\u0010>\"\u0004\b[\u0010@R/\u0010]\u001a\u0004\u0018\u00010;2\b\u0010&\u001a\u0004\u0018\u00010;8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b`\u0010-\u001a\u0004\b^\u0010>\"\u0004\b_\u0010@R/\u0010a\u001a\u0004\u0018\u00010 2\b\u0010&\u001a\u0004\u0018\u00010 8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bd\u0010-\u001a\u0004\bb\u0010)\"\u0004\bc\u0010+R/\u0010e\u001a\u0004\u0018\u00010;2\b\u0010&\u001a\u0004\u0018\u00010;8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bh\u0010-\u001a\u0004\bf\u0010>\"\u0004\bg\u0010@R\u0010\u0010\u0085\u0001\u001a\u00030\u0086\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0097\u0001"}, d2 = {"Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;", "Landroid/widget/LinearLayout;", "Lcom/swmansion/rnscreens/gamma/tabs/TabScreenDelegate;", "reactContext", "Lcom/facebook/react/uimanager/ThemedReactContext;", "<init>", "(Lcom/facebook/react/uimanager/ThemedReactContext;)V", "getReactContext", "()Lcom/facebook/react/uimanager/ThemedReactContext;", "containerUpdateCoordinator", "Lcom/swmansion/rnscreens/gamma/tabs/TabsHost$ContainerUpdateCoordinator;", "wrappedContext", "Landroidx/appcompat/view/ContextThemeWrapper;", "bottomNavigationView", "Lcom/google/android/material/bottomnavigation/BottomNavigationView;", "contentView", "Landroid/widget/FrameLayout;", "eventEmitter", "Lcom/swmansion/rnscreens/gamma/tabs/TabsHostEventEmitter;", "getEventEmitter$react_native_screens_release", "()Lcom/swmansion/rnscreens/gamma/tabs/TabsHostEventEmitter;", "setEventEmitter$react_native_screens_release", "(Lcom/swmansion/rnscreens/gamma/tabs/TabsHostEventEmitter;)V", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "requireFragmentManager", "getRequireFragmentManager", "()Landroidx/fragment/app/FragmentManager;", "tabScreenFragments", "", "Lcom/swmansion/rnscreens/gamma/tabs/TabScreenFragment;", "lastAppliedUiMode", "", "Ljava/lang/Integer;", "isLayoutEnqueued", "", "appearanceCoordinator", "Lcom/swmansion/rnscreens/gamma/tabs/TabsHostAppearanceCoordinator;", "<set-?>", "tabBarBackgroundColor", "getTabBarBackgroundColor", "()Ljava/lang/Integer;", "setTabBarBackgroundColor", "(Ljava/lang/Integer;)V", "tabBarBackgroundColor$delegate", "Lkotlin/properties/ReadWriteProperty;", "tabBarItemActiveIndicatorColor", "getTabBarItemActiveIndicatorColor", "setTabBarItemActiveIndicatorColor", "tabBarItemActiveIndicatorColor$delegate", "isTabBarItemActiveIndicatorEnabled", "()Z", "setTabBarItemActiveIndicatorEnabled", "(Z)V", "isTabBarItemActiveIndicatorEnabled$delegate", "tabBarItemIconColor", "getTabBarItemIconColor", "setTabBarItemIconColor", "tabBarItemIconColor$delegate", "", "tabBarItemTitleFontFamily", "getTabBarItemTitleFontFamily", "()Ljava/lang/String;", "setTabBarItemTitleFontFamily", "(Ljava/lang/String;)V", "tabBarItemTitleFontFamily$delegate", "tabBarItemIconColorActive", "getTabBarItemIconColorActive", "setTabBarItemIconColorActive", "tabBarItemIconColorActive$delegate", "tabBarItemTitleFontColor", "getTabBarItemTitleFontColor", "setTabBarItemTitleFontColor", "tabBarItemTitleFontColor$delegate", "tabBarItemTitleFontColorActive", "getTabBarItemTitleFontColorActive", "setTabBarItemTitleFontColorActive", "tabBarItemTitleFontColorActive$delegate", "", "tabBarItemTitleFontSize", "getTabBarItemTitleFontSize", "()Ljava/lang/Float;", "setTabBarItemTitleFontSize", "(Ljava/lang/Float;)V", "tabBarItemTitleFontSize$delegate", "tabBarItemTitleFontSizeActive", "getTabBarItemTitleFontSizeActive", "setTabBarItemTitleFontSizeActive", "tabBarItemTitleFontSizeActive$delegate", "tabBarItemTitleFontWeight", "getTabBarItemTitleFontWeight", "setTabBarItemTitleFontWeight", "tabBarItemTitleFontWeight$delegate", "tabBarItemTitleFontStyle", "getTabBarItemTitleFontStyle", "setTabBarItemTitleFontStyle", "tabBarItemTitleFontStyle$delegate", "tabBarItemRippleColor", "getTabBarItemRippleColor", "setTabBarItemRippleColor", "tabBarItemRippleColor$delegate", "tabBarItemLabelVisibilityMode", "getTabBarItemLabelVisibilityMode", "setTabBarItemLabelVisibilityMode", "tabBarItemLabelVisibilityMode$delegate", "updateNavigationMenuIfNeeded", "", androidx.exifinterface.media.ExifInterface.GPS_DIRECTION_TRUE, "oldValue", "newValue", "(Ljava/lang/Object;Ljava/lang/Object;)V", "onAttachedToWindow", "mountReactSubviewAt", "tabScreen", "Lcom/swmansion/rnscreens/gamma/tabs/TabScreen;", "index", "mountReactSubviewAt$react_native_screens_release", "unmountReactSubviewAt", "unmountReactSubviewAt$react_native_screens_release", "unmountReactSubview", "reactSubview", "unmountReactSubview$react_native_screens_release", "unmountAllReactSubviews", "unmountAllReactSubviews$react_native_screens_release", "onTabFocusChangedFromJS", "isFocused", "onMenuItemAttributesChange", "getFragmentForTabScreen", "onFragmentConfigurationChange", "config", "Landroid/content/res/Configuration;", "updateBottomNavigationViewAppearance", "updateSelectedTab", "layoutCallback", "Landroid/view/Choreographer$FrameCallback;", "refreshLayout", "requestLayout", "onConfigurationChanged", "newConfig", "applyDayNightUiModeIfNeeded", "uiMode", "forceSubtreeMeasureAndLayoutPass", "getFragmentForMenuItemId", "itemId", "getSelectedTabScreenFragmentId", "getMenuItemForTabScreen", "Landroid/view/MenuItem;", "onViewManagerAddEventEmitters", "onViewManagerAddEventEmitters$react_native_screens_release", "ContainerUpdateCoordinator", "Companion", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class TabsHost extends android.widget.LinearLayout implements com.swmansion.rnscreens.gamma.tabs.TabScreenDelegate {
    static final /* synthetic */ kotlin.reflect.KProperty<java.lang.Object>[] $$delegatedProperties = {kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarBackgroundColor", "getTabBarBackgroundColor()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemActiveIndicatorColor", "getTabBarItemActiveIndicatorColor()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "isTabBarItemActiveIndicatorEnabled", "isTabBarItemActiveIndicatorEnabled()Z", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemIconColor", "getTabBarItemIconColor()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontFamily", "getTabBarItemTitleFontFamily()Ljava/lang/String;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemIconColorActive", "getTabBarItemIconColorActive()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontColor", "getTabBarItemTitleFontColor()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontColorActive", "getTabBarItemTitleFontColorActive()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontSize", "getTabBarItemTitleFontSize()Ljava/lang/Float;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontSizeActive", "getTabBarItemTitleFontSizeActive()Ljava/lang/Float;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontWeight", "getTabBarItemTitleFontWeight()Ljava/lang/String;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemTitleFontStyle", "getTabBarItemTitleFontStyle()Ljava/lang/String;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemRippleColor", "getTabBarItemRippleColor()Ljava/lang/Integer;", 0)), kotlin.jvm.internal.Reflection.mutableProperty1(new kotlin.jvm.internal.MutablePropertyReference1Impl(com.swmansion.rnscreens.gamma.tabs.TabsHost.class, "tabBarItemLabelVisibilityMode", "getTabBarItemLabelVisibilityMode()Ljava/lang/String;", 0))};
    public static final java.lang.String TAG = "TabsHost";
    private final com.swmansion.rnscreens.gamma.tabs.TabsHostAppearanceCoordinator appearanceCoordinator;
    private final com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView;
    private final com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator;
    private final android.widget.FrameLayout contentView;
    public com.swmansion.rnscreens.gamma.tabs.TabsHostEventEmitter eventEmitter;
    private androidx.fragment.app.FragmentManager fragmentManager;
    private boolean isLayoutEnqueued;

    /* renamed from: isTabBarItemActiveIndicatorEnabled$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty isTabBarItemActiveIndicatorEnabled;
    private java.lang.Integer lastAppliedUiMode;
    private final android.view.Choreographer.FrameCallback layoutCallback;
    private final com.facebook.react.uimanager.ThemedReactContext reactContext;

    /* renamed from: tabBarBackgroundColor$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarBackgroundColor;

    /* renamed from: tabBarItemActiveIndicatorColor$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemActiveIndicatorColor;

    /* renamed from: tabBarItemIconColor$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemIconColor;

    /* renamed from: tabBarItemIconColorActive$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemIconColorActive;

    /* renamed from: tabBarItemLabelVisibilityMode$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemLabelVisibilityMode;

    /* renamed from: tabBarItemRippleColor$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemRippleColor;

    /* renamed from: tabBarItemTitleFontColor$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontColor;

    /* renamed from: tabBarItemTitleFontColorActive$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontColorActive;

    /* renamed from: tabBarItemTitleFontFamily$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontFamily;

    /* renamed from: tabBarItemTitleFontSize$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontSize;

    /* renamed from: tabBarItemTitleFontSizeActive$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontSizeActive;

    /* renamed from: tabBarItemTitleFontStyle$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontStyle;

    /* renamed from: tabBarItemTitleFontWeight$delegate, reason: from kotlin metadata */
    private final kotlin.properties.ReadWriteProperty tabBarItemTitleFontWeight;
    private final java.util.List<com.swmansion.rnscreens.gamma.tabs.TabScreenFragment> tabScreenFragments;
    private final androidx.appcompat.view.ContextThemeWrapper wrappedContext;

    public final com.facebook.react.uimanager.ThemedReactContext getReactContext() {
        return this.reactContext;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TabsHost(com.facebook.react.uimanager.ThemedReactContext reactContext) {
        super(reactContext);
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reactContext, "reactContext");
        this.reactContext = reactContext;
        this.containerUpdateCoordinator = new com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator();
        androidx.appcompat.view.ContextThemeWrapper contextThemeWrapper = new androidx.appcompat.view.ContextThemeWrapper(reactContext, com.google.android.material.R.style.Theme_Material3_DayNight_NoActionBar);
        this.wrappedContext = contextThemeWrapper;
        com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView = new com.google.android.material.bottomnavigation.BottomNavigationView(contextThemeWrapper);
        bottomNavigationView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, -2));
        this.bottomNavigationView = bottomNavigationView;
        android.widget.FrameLayout frameLayout = new android.widget.FrameLayout(reactContext);
        android.widget.LinearLayout.LayoutParams layoutParams = new android.widget.LinearLayout.LayoutParams(-1, -2);
        layoutParams.weight = 1.0f;
        frameLayout.setLayoutParams(layoutParams);
        frameLayout.setId(com.swmansion.rnscreens.gamma.helpers.ViewIdGenerator.INSTANCE.generateViewId());
        this.contentView = frameLayout;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        this.tabScreenFragments = arrayList;
        this.appearanceCoordinator = new com.swmansion.rnscreens.gamma.tabs.TabsHostAppearanceCoordinator(contextThemeWrapper, bottomNavigationView, arrayList);
        kotlin.properties.Delegates delegates = kotlin.properties.Delegates.INSTANCE;
        final java.lang.Object obj = null;
        this.tabBarBackgroundColor = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$1
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates2 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemActiveIndicatorColor = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$2
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates3 = kotlin.properties.Delegates.INSTANCE;
        final boolean z = true;
        this.isTabBarItemActiveIndicatorEnabled = new kotlin.properties.ObservableProperty<java.lang.Boolean>(z) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$3
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Boolean oldValue, java.lang.Boolean newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                boolean zBooleanValue = newValue.booleanValue();
                this.updateNavigationMenuIfNeeded(java.lang.Boolean.valueOf(oldValue.booleanValue()), java.lang.Boolean.valueOf(zBooleanValue));
            }
        };
        kotlin.properties.Delegates delegates4 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemIconColor = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$4
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates5 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontFamily = new kotlin.properties.ObservableProperty<java.lang.String>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$5
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.String oldValue, java.lang.String newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates6 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemIconColorActive = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$6
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates7 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontColor = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$7
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates8 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontColorActive = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$8
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates9 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontSize = new kotlin.properties.ObservableProperty<java.lang.Float>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$9
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Float oldValue, java.lang.Float newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates10 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontSizeActive = new kotlin.properties.ObservableProperty<java.lang.Float>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$10
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Float oldValue, java.lang.Float newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates11 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontWeight = new kotlin.properties.ObservableProperty<java.lang.String>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$11
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.String oldValue, java.lang.String newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates12 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemTitleFontStyle = new kotlin.properties.ObservableProperty<java.lang.String>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$12
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.String oldValue, java.lang.String newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates13 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemRippleColor = new kotlin.properties.ObservableProperty<java.lang.Integer>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$13
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.Integer oldValue, java.lang.Integer newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        kotlin.properties.Delegates delegates14 = kotlin.properties.Delegates.INSTANCE;
        this.tabBarItemLabelVisibilityMode = new kotlin.properties.ObservableProperty<java.lang.String>(obj) { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$special$$inlined$observable$14
            @Override // kotlin.properties.ObservableProperty
            protected void afterChange(kotlin.reflect.KProperty<?> property, java.lang.String oldValue, java.lang.String newValue) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(property, "property");
                com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost = this;
                tabsHost.updateNavigationMenuIfNeeded(oldValue, newValue);
            }
        };
        setOrientation(1);
        addView(frameLayout);
        addView(bottomNavigationView);
        bottomNavigationView.addOnLayoutChangeListener(new android.view.View.OnLayoutChangeListener() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda0
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(android.view.View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                com.swmansion.rnscreens.gamma.tabs.TabsHost._init_$lambda$19(view, i, i2, i3, i4, i5, i6, i7, i8);
            }
        });
        bottomNavigationView.setOnItemSelectedListener(new com.google.android.material.navigation.NavigationBarView.OnItemSelectedListener() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda1
            @Override // com.google.android.material.navigation.NavigationBarView.OnItemSelectedListener
            public final boolean onNavigationItemSelected(android.view.MenuItem menuItem) {
                return com.swmansion.rnscreens.gamma.tabs.TabsHost._init_$lambda$20(this.f$0, menuItem);
            }
        });
        this.layoutCallback = new android.view.Choreographer.FrameCallback() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda2
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j) {
                com.swmansion.rnscreens.gamma.tabs.TabsHost.layoutCallback$lambda$43(this.f$0, j);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: TabsHost.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0007\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\tJ\u0006\u0010\u000b\u001a\u00020\tJ\u0006\u0010\f\u001a\u00020\tJ\u0006\u0010\r\u001a\u00020\tJ\b\u0010\u000e\u001a\u00020\tH\u0002J\u0006\u0010\u000f\u001a\u00020\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/swmansion/rnscreens/gamma/tabs/TabsHost$ContainerUpdateCoordinator;", "", "<init>", "(Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;)V", "isUpdatePending", "", "isSelectedTabInvalidated", "isBottomNavigationMenuInvalidated", "invalidateSelectedTab", "", "invalidateNavigationMenu", "invalidateAll", "postContainerUpdateIfNeeded", "postContainerUpdate", "runContainerUpdateIfNeeded", "runContainerUpdate", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    final class ContainerUpdateCoordinator {
        private boolean isBottomNavigationMenuInvalidated;
        private boolean isSelectedTabInvalidated;
        private boolean isUpdatePending;

        public ContainerUpdateCoordinator() {
        }

        public final void invalidateSelectedTab() {
            this.isSelectedTabInvalidated = true;
        }

        public final void invalidateNavigationMenu() {
            this.isBottomNavigationMenuInvalidated = true;
        }

        public final void invalidateAll() {
            invalidateSelectedTab();
            invalidateNavigationMenu();
        }

        public final void postContainerUpdateIfNeeded() {
            if (this.isUpdatePending) {
                return;
            }
            postContainerUpdate();
        }

        public final void postContainerUpdate() {
            this.isUpdatePending = true;
            com.swmansion.rnscreens.gamma.tabs.TabsHost.this.post(new java.lang.Runnable() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$ContainerUpdateCoordinator$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.runContainerUpdateIfNeeded();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void runContainerUpdateIfNeeded() {
            if (this.isUpdatePending) {
                runContainerUpdate();
            }
        }

        public final void runContainerUpdate() {
            this.isUpdatePending = false;
            if (this.isSelectedTabInvalidated) {
                this.isSelectedTabInvalidated = false;
                com.swmansion.rnscreens.gamma.tabs.TabsHost.this.updateSelectedTab();
            }
            if (this.isBottomNavigationMenuInvalidated) {
                this.isBottomNavigationMenuInvalidated = false;
                com.swmansion.rnscreens.gamma.tabs.TabsHost.this.updateBottomNavigationViewAppearance();
            }
        }
    }

    public final com.swmansion.rnscreens.gamma.tabs.TabsHostEventEmitter getEventEmitter$react_native_screens_release() {
        com.swmansion.rnscreens.gamma.tabs.TabsHostEventEmitter tabsHostEventEmitter = this.eventEmitter;
        if (tabsHostEventEmitter != null) {
            return tabsHostEventEmitter;
        }
        kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException("eventEmitter");
        return null;
    }

    public final void setEventEmitter$react_native_screens_release(com.swmansion.rnscreens.gamma.tabs.TabsHostEventEmitter tabsHostEventEmitter) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabsHostEventEmitter, "<set-?>");
        this.eventEmitter = tabsHostEventEmitter;
    }

    private final androidx.fragment.app.FragmentManager getRequireFragmentManager() {
        androidx.fragment.app.FragmentManager fragmentManager = this.fragmentManager;
        if (fragmentManager != null) {
            return fragmentManager;
        }
        throw new java.lang.IllegalStateException("[RNScreens] Nullish fragment manager".toString());
    }

    public final java.lang.Integer getTabBarBackgroundColor() {
        return (java.lang.Integer) this.tabBarBackgroundColor.getValue(this, $$delegatedProperties[0]);
    }

    public final void setTabBarBackgroundColor(java.lang.Integer num) {
        this.tabBarBackgroundColor.setValue(this, $$delegatedProperties[0], num);
    }

    public final java.lang.Integer getTabBarItemActiveIndicatorColor() {
        return (java.lang.Integer) this.tabBarItemActiveIndicatorColor.getValue(this, $$delegatedProperties[1]);
    }

    public final void setTabBarItemActiveIndicatorColor(java.lang.Integer num) {
        this.tabBarItemActiveIndicatorColor.setValue(this, $$delegatedProperties[1], num);
    }

    public final boolean isTabBarItemActiveIndicatorEnabled() {
        return ((java.lang.Boolean) this.isTabBarItemActiveIndicatorEnabled.getValue(this, $$delegatedProperties[2])).booleanValue();
    }

    public final void setTabBarItemActiveIndicatorEnabled(boolean z) {
        this.isTabBarItemActiveIndicatorEnabled.setValue(this, $$delegatedProperties[2], java.lang.Boolean.valueOf(z));
    }

    public final java.lang.Integer getTabBarItemIconColor() {
        return (java.lang.Integer) this.tabBarItemIconColor.getValue(this, $$delegatedProperties[3]);
    }

    public final void setTabBarItemIconColor(java.lang.Integer num) {
        this.tabBarItemIconColor.setValue(this, $$delegatedProperties[3], num);
    }

    public final java.lang.String getTabBarItemTitleFontFamily() {
        return (java.lang.String) this.tabBarItemTitleFontFamily.getValue(this, $$delegatedProperties[4]);
    }

    public final void setTabBarItemTitleFontFamily(java.lang.String str) {
        this.tabBarItemTitleFontFamily.setValue(this, $$delegatedProperties[4], str);
    }

    public final java.lang.Integer getTabBarItemIconColorActive() {
        return (java.lang.Integer) this.tabBarItemIconColorActive.getValue(this, $$delegatedProperties[5]);
    }

    public final void setTabBarItemIconColorActive(java.lang.Integer num) {
        this.tabBarItemIconColorActive.setValue(this, $$delegatedProperties[5], num);
    }

    public final java.lang.Integer getTabBarItemTitleFontColor() {
        return (java.lang.Integer) this.tabBarItemTitleFontColor.getValue(this, $$delegatedProperties[6]);
    }

    public final void setTabBarItemTitleFontColor(java.lang.Integer num) {
        this.tabBarItemTitleFontColor.setValue(this, $$delegatedProperties[6], num);
    }

    public final java.lang.Integer getTabBarItemTitleFontColorActive() {
        return (java.lang.Integer) this.tabBarItemTitleFontColorActive.getValue(this, $$delegatedProperties[7]);
    }

    public final void setTabBarItemTitleFontColorActive(java.lang.Integer num) {
        this.tabBarItemTitleFontColorActive.setValue(this, $$delegatedProperties[7], num);
    }

    public final java.lang.Float getTabBarItemTitleFontSize() {
        return (java.lang.Float) this.tabBarItemTitleFontSize.getValue(this, $$delegatedProperties[8]);
    }

    public final void setTabBarItemTitleFontSize(java.lang.Float f) {
        this.tabBarItemTitleFontSize.setValue(this, $$delegatedProperties[8], f);
    }

    public final java.lang.Float getTabBarItemTitleFontSizeActive() {
        return (java.lang.Float) this.tabBarItemTitleFontSizeActive.getValue(this, $$delegatedProperties[9]);
    }

    public final void setTabBarItemTitleFontSizeActive(java.lang.Float f) {
        this.tabBarItemTitleFontSizeActive.setValue(this, $$delegatedProperties[9], f);
    }

    public final java.lang.String getTabBarItemTitleFontWeight() {
        return (java.lang.String) this.tabBarItemTitleFontWeight.getValue(this, $$delegatedProperties[10]);
    }

    public final void setTabBarItemTitleFontWeight(java.lang.String str) {
        this.tabBarItemTitleFontWeight.setValue(this, $$delegatedProperties[10], str);
    }

    public final java.lang.String getTabBarItemTitleFontStyle() {
        return (java.lang.String) this.tabBarItemTitleFontStyle.getValue(this, $$delegatedProperties[11]);
    }

    public final void setTabBarItemTitleFontStyle(java.lang.String str) {
        this.tabBarItemTitleFontStyle.setValue(this, $$delegatedProperties[11], str);
    }

    public final java.lang.Integer getTabBarItemRippleColor() {
        return (java.lang.Integer) this.tabBarItemRippleColor.getValue(this, $$delegatedProperties[12]);
    }

    public final void setTabBarItemRippleColor(java.lang.Integer num) {
        this.tabBarItemRippleColor.setValue(this, $$delegatedProperties[12], num);
    }

    public final java.lang.String getTabBarItemLabelVisibilityMode() {
        return (java.lang.String) this.tabBarItemLabelVisibilityMode.getValue(this, $$delegatedProperties[13]);
    }

    public final void setTabBarItemLabelVisibilityMode(java.lang.String str) {
        this.tabBarItemLabelVisibilityMode.setValue(this, $$delegatedProperties[13], str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final <T> void updateNavigationMenuIfNeeded(T oldValue, T newValue) {
        if (kotlin.jvm.internal.Intrinsics.areEqual(newValue, oldValue)) {
            return;
        }
        com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
        containerUpdateCoordinator.invalidateNavigationMenu();
        containerUpdateCoordinator.postContainerUpdateIfNeeded();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$19(android.view.View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        com.swmansion.rnscreens.utils.RNSLog.INSTANCE.d(TAG, "BottomNavigationView layout changed {" + i + ", " + i2 + "} {" + (i3 - i) + ", " + (i4 - i2) + "}");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean _init_$lambda$20(com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost, android.view.MenuItem item) {
        java.lang.String tabKey;
        com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "item");
        com.swmansion.rnscreens.utils.RNSLog.INSTANCE.d(TAG, "Item selected " + item);
        com.swmansion.rnscreens.gamma.tabs.TabScreenFragment fragmentForMenuItemId = tabsHost.getFragmentForMenuItemId(item.getItemId());
        if (fragmentForMenuItemId == null || (tabScreen = fragmentForMenuItemId.getTabScreen()) == null || (tabKey = tabScreen.getTabKey()) == null) {
            tabKey = "undefined";
        }
        tabsHost.getEventEmitter$react_native_screens_release().emitOnNativeFocusChange(tabKey);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        com.swmansion.rnscreens.utils.RNSLog.INSTANCE.d(TAG, "TabsHost [" + getId() + "] attached to window");
        super.onAttachedToWindow();
        androidx.fragment.app.FragmentManager fragmentManagerFindFragmentManagerForView = com.swmansion.rnscreens.gamma.helpers.FragmentManagerHelper.INSTANCE.findFragmentManagerForView(this);
        if (fragmentManagerFindFragmentManagerForView != null) {
            this.fragmentManager = fragmentManagerFindFragmentManagerForView;
            com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
            containerUpdateCoordinator.invalidateAll();
            containerUpdateCoordinator.runContainerUpdate();
            return;
        }
        throw new java.lang.IllegalStateException("[RNScreens] Nullish fragment manager - can't run container operations".toString());
    }

    public final void mountReactSubviewAt$react_native_screens_release(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, int index) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabScreen, "tabScreen");
        if (index >= this.bottomNavigationView.getMaxItemCount()) {
            throw new java.lang.IllegalArgumentException(("[RNScreens] Attempt to insert TabScreen at index " + index + "; BottomNavigationView supports at most " + this.bottomNavigationView.getMaxItemCount() + " items").toString());
        }
        this.tabScreenFragments.add(index, new com.swmansion.rnscreens.gamma.tabs.TabScreenFragment(tabScreen));
        tabScreen.setTabScreenDelegate$react_native_screens_release(this);
        com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
        containerUpdateCoordinator.invalidateAll();
        containerUpdateCoordinator.postContainerUpdateIfNeeded();
    }

    public final void unmountReactSubviewAt$react_native_screens_release(int index) {
        this.tabScreenFragments.remove(index).getTabScreen().setTabScreenDelegate$react_native_screens_release(null);
        com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
        containerUpdateCoordinator.invalidateAll();
        containerUpdateCoordinator.postContainerUpdateIfNeeded();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean unmountReactSubview$lambda$27(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, com.swmansion.rnscreens.gamma.tabs.TabScreenFragment it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return it.getTabScreen() == tabScreen;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean unmountReactSubview$lambda$28(kotlin.jvm.functions.Function1 function1, java.lang.Object obj) {
        return ((java.lang.Boolean) function1.invoke(obj)).booleanValue();
    }

    public final void unmountReactSubview$react_native_screens_release(final com.swmansion.rnscreens.gamma.tabs.TabScreen reactSubview) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(reactSubview, "reactSubview");
        java.util.List<com.swmansion.rnscreens.gamma.tabs.TabScreenFragment> list = this.tabScreenFragments;
        final kotlin.jvm.functions.Function1 function1 = new kotlin.jvm.functions.Function1() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return java.lang.Boolean.valueOf(com.swmansion.rnscreens.gamma.tabs.TabsHost.unmountReactSubview$lambda$27(reactSubview, (com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) obj));
            }
        };
        java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(list.removeIf(new java.util.function.Predicate() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda5
            @Override // java.util.function.Predicate
            public final boolean test(java.lang.Object obj) {
                return com.swmansion.rnscreens.gamma.tabs.TabsHost.unmountReactSubview$lambda$28(function1, obj);
            }
        }));
        if (!boolValueOf.booleanValue()) {
            boolValueOf = null;
        }
        if (boolValueOf != null) {
            boolValueOf.booleanValue();
            reactSubview.setTabScreenDelegate$react_native_screens_release(null);
            com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
            containerUpdateCoordinator.invalidateAll();
            containerUpdateCoordinator.postContainerUpdateIfNeeded();
        }
    }

    public final void unmountAllReactSubviews$react_native_screens_release() {
        java.util.Iterator<T> it = this.tabScreenFragments.iterator();
        while (it.hasNext()) {
            ((com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) it.next()).getTabScreen().setTabScreenDelegate$react_native_screens_release(null);
        }
        this.tabScreenFragments.clear();
        com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
        containerUpdateCoordinator.invalidateAll();
        containerUpdateCoordinator.postContainerUpdateIfNeeded();
    }

    @Override // com.swmansion.rnscreens.gamma.tabs.TabScreenDelegate
    public void onTabFocusChangedFromJS(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, boolean isFocused) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabScreen, "tabScreen");
        com.swmansion.rnscreens.gamma.tabs.TabsHost.ContainerUpdateCoordinator containerUpdateCoordinator = this.containerUpdateCoordinator;
        containerUpdateCoordinator.invalidateAll();
        containerUpdateCoordinator.postContainerUpdateIfNeeded();
    }

    @Override // com.swmansion.rnscreens.gamma.tabs.TabScreenDelegate
    public void onMenuItemAttributesChange(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabScreen, "tabScreen");
        android.view.MenuItem menuItemForTabScreen = getMenuItemForTabScreen(tabScreen);
        if (menuItemForTabScreen != null) {
            this.appearanceCoordinator.updateMenuItemAppearance(menuItemForTabScreen, tabScreen);
        }
    }

    @Override // com.swmansion.rnscreens.gamma.tabs.TabScreenDelegate
    public com.swmansion.rnscreens.gamma.tabs.TabScreenFragment getFragmentForTabScreen(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen) {
        java.lang.Object next;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabScreen, "tabScreen");
        java.util.Iterator<T> it = this.tabScreenFragments.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) next).getTabScreen() == tabScreen) {
                break;
            }
        }
        return (com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) next;
    }

    @Override // com.swmansion.rnscreens.gamma.tabs.TabScreenDelegate
    public void onFragmentConfigurationChange(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, android.content.res.Configuration config) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(tabScreen, "tabScreen");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(config, "config");
        onConfigurationChanged(config);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateBottomNavigationViewAppearance() {
        com.swmansion.rnscreens.utils.RNSLog.INSTANCE.d(TAG, "updateBottomNavigationViewAppearance");
        this.appearanceCoordinator.updateTabAppearance(this);
        com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView = this.bottomNavigationView;
        java.lang.Integer selectedTabScreenFragmentId = getSelectedTabScreenFragmentId();
        if (selectedTabScreenFragmentId != null) {
            bottomNavigationView.setSelectedItemId(selectedTabScreenFragmentId.intValue());
            post(new java.lang.Runnable() { // from class: com.swmansion.rnscreens.gamma.tabs.TabsHost$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    com.swmansion.rnscreens.gamma.tabs.TabsHost.updateBottomNavigationViewAppearance$lambda$38(this.f$0);
                }
            });
            return;
        }
        throw new java.lang.IllegalStateException("[RNScreens] A single selected tab must be present".toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void updateBottomNavigationViewAppearance$lambda$38(com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost) {
        tabsHost.refreshLayout();
        com.swmansion.rnscreens.utils.RNSLog.INSTANCE.d(TAG, "BottomNavigationView request layout");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateSelectedTab() {
        java.lang.Object next;
        java.util.Iterator<T> it = this.tabScreenFragments.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) next).getTabScreen().getIsFocusedTab()) {
                    break;
                }
            }
        }
        if (next == null) {
            throw new java.lang.IllegalStateException("[RNScreens] No focused tab present".toString());
        }
        com.swmansion.rnscreens.gamma.tabs.TabScreenFragment tabScreenFragment = (com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) next;
        if (getRequireFragmentManager().getFragments().size() > 1) {
            throw new java.lang.IllegalStateException("[RNScreens] There can be only a single focused tab".toString());
        }
        java.util.List<androidx.fragment.app.Fragment> fragments = getRequireFragmentManager().getFragments();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(fragments, "getFragments(...)");
        androidx.fragment.app.Fragment fragment = (androidx.fragment.app.Fragment) kotlin.collections.CollectionsKt.firstOrNull((java.util.List) fragments);
        if (tabScreenFragment == fragment) {
            return;
        }
        androidx.fragment.app.FragmentTransaction reorderingAllowed = getRequireFragmentManager().beginTransaction().setReorderingAllowed(true);
        if (fragment != null) {
            reorderingAllowed.remove(fragment);
        }
        reorderingAllowed.add(this.contentView.getId(), tabScreenFragment);
        reorderingAllowed.commitNowAllowingStateLoss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void layoutCallback$lambda$43(com.swmansion.rnscreens.gamma.tabs.TabsHost tabsHost, long j) {
        tabsHost.isLayoutEnqueued = false;
        tabsHost.forceSubtreeMeasureAndLayoutPass();
    }

    private final void refreshLayout() {
        if (this.isLayoutEnqueued || this.layoutCallback == null) {
            return;
        }
        this.isLayoutEnqueued = true;
        com.facebook.react.modules.core.ReactChoreographer.INSTANCE.getInstance().postFrameCallback(com.facebook.react.modules.core.ReactChoreographer.CallbackType.NATIVE_ANIMATED_MODULE, this.layoutCallback);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        super.requestLayout();
        refreshLayout();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig != null) {
            applyDayNightUiModeIfNeeded(newConfig.uiMode & 48);
        }
    }

    private final void applyDayNightUiModeIfNeeded(int uiMode) {
        java.lang.Integer num = this.lastAppliedUiMode;
        if (num != null && uiMode == num.intValue()) {
            return;
        }
        if (uiMode == 16) {
            this.wrappedContext.setTheme(com.google.android.material.R.style.Theme_Material3_Light_NoActionBar);
        } else if (uiMode == 32) {
            this.wrappedContext.setTheme(com.google.android.material.R.style.Theme_Material3_Dark_NoActionBar);
        } else {
            this.wrappedContext.setTheme(com.google.android.material.R.style.Theme_Material3_DayNight_NoActionBar);
        }
        this.appearanceCoordinator.updateTabAppearance(this);
        this.lastAppliedUiMode = java.lang.Integer.valueOf(uiMode);
    }

    private final void forceSubtreeMeasureAndLayoutPass() {
        measure(android.view.View.MeasureSpec.makeMeasureSpec(getWidth(), 1073741824), android.view.View.MeasureSpec.makeMeasureSpec(getHeight(), 1073741824));
        layout(getLeft(), getTop(), getRight(), getBottom());
    }

    private final com.swmansion.rnscreens.gamma.tabs.TabScreenFragment getFragmentForMenuItemId(int itemId) {
        return (com.swmansion.rnscreens.gamma.tabs.TabScreenFragment) kotlin.collections.CollectionsKt.getOrNull(this.tabScreenFragments, itemId);
    }

    private final java.lang.Integer getSelectedTabScreenFragmentId() {
        if (this.tabScreenFragments.isEmpty()) {
            return null;
        }
        java.util.Iterator<com.swmansion.rnscreens.gamma.tabs.TabScreenFragment> it = this.tabScreenFragments.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            }
            if (it.next().getTabScreen().getIsFocusedTab()) {
                break;
            }
            i++;
        }
        return java.lang.Integer.valueOf(i);
    }

    private final android.view.MenuItem getMenuItemForTabScreen(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen) {
        java.util.Iterator<com.swmansion.rnscreens.gamma.tabs.TabScreenFragment> it = this.tabScreenFragments.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            }
            if (it.next().getTabScreen() == tabScreen) {
                break;
            }
            i++;
        }
        java.lang.Integer numValueOf = java.lang.Integer.valueOf(i);
        if (numValueOf.intValue() == -1) {
            numValueOf = null;
        }
        if (numValueOf == null) {
            return null;
        }
        return this.bottomNavigationView.getMenu().findItem(numValueOf.intValue());
    }

    public final void onViewManagerAddEventEmitters$react_native_screens_release() {
        if (getId() == -1) {
            throw new java.lang.IllegalStateException("[RNScreens] TabsHost must have its tag set when registering event emitters".toString());
        }
        setEventEmitter$react_native_screens_release(new com.swmansion.rnscreens.gamma.tabs.TabsHostEventEmitter(this.reactContext, getId()));
    }
}
