package com.swmansion.rnscreens.gamma.tabs;

/* compiled from: TabScreenDelegate.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b`\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H&J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0018\u0010\t\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000bH&J\u0012\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u000e"}, d2 = {"Lcom/swmansion/rnscreens/gamma/tabs/TabScreenDelegate;", "", "onTabFocusChangedFromJS", "", "tabScreen", "Lcom/swmansion/rnscreens/gamma/tabs/TabScreen;", "isFocused", "", "onMenuItemAttributesChange", "onFragmentConfigurationChange", "config", "Landroid/content/res/Configuration;", "getFragmentForTabScreen", "Landroidx/fragment/app/Fragment;", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface TabScreenDelegate {
    androidx.fragment.app.Fragment getFragmentForTabScreen(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen);

    void onFragmentConfigurationChange(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, android.content.res.Configuration config);

    void onMenuItemAttributesChange(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen);

    void onTabFocusChangedFromJS(com.swmansion.rnscreens.gamma.tabs.TabScreen tabScreen, boolean isFocused);
}
