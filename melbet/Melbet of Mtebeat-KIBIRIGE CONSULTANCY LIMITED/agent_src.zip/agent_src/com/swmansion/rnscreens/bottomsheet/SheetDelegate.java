package com.swmansion.rnscreens.bottomsheet;

/* compiled from: SheetDelegate.kt */
@kotlin.Metadata(d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000 =2\u00020\u00012\u00020\u0002:\u0003;<=B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\"\u001a\u00020#H\u0002J\u0018\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020)H\u0016J\b\u0010*\u001a\u00020%H\u0002J\b\u0010+\u001a\u00020%H\u0002J\b\u0010,\u001a\u00020%H\u0002J\u0010\u0010-\u001a\u00020%2\u0006\u0010.\u001a\u00020\u000eH\u0002J5\u0010/\u001a\b\u0012\u0004\u0012\u00020\u00040\u001b2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\u00040\u001b2\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u00101\u001a\u00020\u000eH\u0000¢\u0006\u0002\b2J\u0018\u00103\u001a\u0002042\u0006\u00105\u001a\u00020#2\u0006\u00106\u001a\u000204H\u0016J\u0010\u00107\u001a\u00020\n2\u0006\u00108\u001a\u00020\u000eH\u0002J\u000f\u00109\u001a\u0004\u0018\u00010\u000eH\u0002¢\u0006\u0002\u0010:R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R$\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\u000e@BX\u0086\u000e¢\u0006\u000e\n\u0000\u0012\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0011R\u0012\u0010\u0016\u001a\u00060\u0017R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0018\u001a\u00060\u0019R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u001a\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u001b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001e\u001a\u00020\u001f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b \u0010!¨\u0006>"}, d2 = {"Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/core/view/OnApplyWindowInsetsListener;", "screen", "Lcom/swmansion/rnscreens/Screen;", "<init>", "(Lcom/swmansion/rnscreens/Screen;)V", "getScreen", "()Lcom/swmansion/rnscreens/Screen;", "isKeyboardVisible", "", "keyboardState", "Lcom/swmansion/rnscreens/KeyboardState;", "value", "", "lastStableDetentIndex", "getLastStableDetentIndex", "()I", "lastStableState", "getLastStableState$annotations", "()V", "getLastStableState", "sheetStateObserver", "Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate$SheetStateObserver;", "keyboardHandlerCallback", "Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate$KeyboardHandler;", "sheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "getSheetBehavior", "()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "stackFragment", "Lcom/swmansion/rnscreens/ScreenStackFragment;", "getStackFragment", "()Lcom/swmansion/rnscreens/ScreenStackFragment;", "requireDecorView", "Landroid/view/View;", "onStateChanged", "", "source", "Landroidx/lifecycle/LifecycleOwner;", androidx.core.app.NotificationCompat.CATEGORY_EVENT, "Landroidx/lifecycle/Lifecycle$Event;", "handleHostFragmentOnStart", "handleHostFragmentOnResume", "handleHostFragmentOnPause", "onSheetStateChanged", "newState", "configureBottomSheetBehaviour", "behavior", "selectedDetentIndex", "configureBottomSheetBehaviour$react_native_screens_release", "onApplyWindowInsets", "Landroidx/core/view/WindowInsetsCompat;", "v", "insets", "shouldDismissSheetInState", "state", "tryResolveContainerHeight", "()Ljava/lang/Integer;", "KeyboardHandler", "SheetStateObserver", "Companion", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SheetDelegate implements androidx.lifecycle.LifecycleEventObserver, androidx.core.view.OnApplyWindowInsetsListener {
    public static final java.lang.String TAG = "SheetDelegate";
    private boolean isKeyboardVisible;
    private final com.swmansion.rnscreens.bottomsheet.SheetDelegate.KeyboardHandler keyboardHandlerCallback;
    private com.swmansion.rnscreens.KeyboardState keyboardState;
    private int lastStableDetentIndex;
    private int lastStableState;
    private final com.swmansion.rnscreens.Screen screen;
    private final com.swmansion.rnscreens.bottomsheet.SheetDelegate.SheetStateObserver sheetStateObserver;

    /* compiled from: SheetDelegate.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[androidx.lifecycle.Lifecycle.Event.values().length];
            try {
                iArr[androidx.lifecycle.Lifecycle.Event.ON_START.ordinal()] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                iArr[androidx.lifecycle.Lifecycle.Event.ON_RESUME.ordinal()] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                iArr[androidx.lifecycle.Lifecycle.Event.ON_PAUSE.ordinal()] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public static /* synthetic */ void getLastStableState$annotations() {
    }

    private final boolean shouldDismissSheetInState(int state) {
        return state == 5;
    }

    public SheetDelegate(com.swmansion.rnscreens.Screen screen) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(screen, "screen");
        this.screen = screen;
        this.keyboardState = com.swmansion.rnscreens.KeyboardNotVisible.INSTANCE;
        this.lastStableDetentIndex = screen.getSheetInitialDetentIndex();
        this.lastStableState = com.swmansion.rnscreens.bottomsheet.SheetUtils.INSTANCE.sheetStateFromDetentIndex(screen.getSheetInitialDetentIndex(), screen.getSheetDetents().size());
        com.swmansion.rnscreens.bottomsheet.SheetDelegate.SheetStateObserver sheetStateObserver = new com.swmansion.rnscreens.bottomsheet.SheetDelegate.SheetStateObserver();
        this.sheetStateObserver = sheetStateObserver;
        this.keyboardHandlerCallback = new com.swmansion.rnscreens.bottomsheet.SheetDelegate.KeyboardHandler();
        boolean z = screen.getFragment() instanceof com.swmansion.rnscreens.ScreenStackFragment;
        androidx.fragment.app.Fragment fragment = screen.getFragment();
        kotlin.jvm.internal.Intrinsics.checkNotNull(fragment);
        fragment.getLifecycle().addObserver(this);
        com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> sheetBehavior = getSheetBehavior();
        if (sheetBehavior == null) {
            throw new java.lang.IllegalStateException("[RNScreens] Sheet delegate accepts screen with initialized sheet behaviour only.".toString());
        }
        sheetBehavior.addBottomSheetCallback(sheetStateObserver);
    }

    public final com.swmansion.rnscreens.Screen getScreen() {
        return this.screen;
    }

    public final int getLastStableDetentIndex() {
        return this.lastStableDetentIndex;
    }

    public final int getLastStableState() {
        return this.lastStableState;
    }

    private final com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> getSheetBehavior() {
        return this.screen.getSheetBehavior();
    }

    private final com.swmansion.rnscreens.ScreenStackFragment getStackFragment() {
        androidx.fragment.app.Fragment fragment = this.screen.getFragment();
        kotlin.jvm.internal.Intrinsics.checkNotNull(fragment, "null cannot be cast to non-null type com.swmansion.rnscreens.ScreenStackFragment");
        return (com.swmansion.rnscreens.ScreenStackFragment) fragment;
    }

    private final android.view.View requireDecorView() {
        android.app.Activity currentActivity = this.screen.getReactContext().getCurrentActivity();
        if (currentActivity == null) {
            throw new java.lang.IllegalStateException("[RNScreens] Attempt to access activity on detached context".toString());
        }
        android.view.View decorView = currentActivity.getWindow().getDecorView();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(decorView, "getDecorView(...)");
        return decorView;
    }

    @Override // androidx.lifecycle.LifecycleEventObserver
    public void onStateChanged(androidx.lifecycle.LifecycleOwner source, androidx.lifecycle.Lifecycle.Event event) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(source, "source");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(event, "event");
        int i = com.swmansion.rnscreens.bottomsheet.SheetDelegate.WhenMappings.$EnumSwitchMapping$0[event.ordinal()];
        if (i == 1) {
            handleHostFragmentOnStart();
        } else if (i == 2) {
            handleHostFragmentOnResume();
        } else {
            if (i != 3) {
                return;
            }
            handleHostFragmentOnPause();
        }
    }

    private final void handleHostFragmentOnStart() {
        com.swmansion.rnscreens.InsetsObserverProxy.INSTANCE.registerOnView(requireDecorView());
    }

    private final void handleHostFragmentOnResume() {
        com.swmansion.rnscreens.InsetsObserverProxy.INSTANCE.addOnApplyWindowInsetsListener(this);
    }

    private final void handleHostFragmentOnPause() {
        com.swmansion.rnscreens.InsetsObserverProxy.INSTANCE.removeOnApplyWindowInsetsListener(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onSheetStateChanged(int newState) {
        boolean zIsStateStable = com.swmansion.rnscreens.bottomsheet.SheetUtils.INSTANCE.isStateStable(newState);
        if (zIsStateStable) {
            this.lastStableState = newState;
            this.lastStableDetentIndex = com.swmansion.rnscreens.bottomsheet.SheetUtils.INSTANCE.detentIndexFromSheetState(newState, this.screen.getSheetDetents().size());
        }
        this.screen.onSheetDetentChanged$react_native_screens_release(this.lastStableDetentIndex, zIsStateStable);
        if (shouldDismissSheetInState(newState)) {
            getStackFragment().dismissSelf$react_native_screens_release();
        }
    }

    public static /* synthetic */ com.google.android.material.bottomsheet.BottomSheetBehavior configureBottomSheetBehaviour$react_native_screens_release$default(com.swmansion.rnscreens.bottomsheet.SheetDelegate sheetDelegate, com.google.android.material.bottomsheet.BottomSheetBehavior bottomSheetBehavior, com.swmansion.rnscreens.KeyboardState keyboardState, int i, int i2, java.lang.Object obj) {
        if ((i2 & 2) != 0) {
            keyboardState = com.swmansion.rnscreens.KeyboardNotVisible.INSTANCE;
        }
        if ((i2 & 4) != 0) {
            i = sheetDelegate.lastStableDetentIndex;
        }
        return sheetDelegate.configureBottomSheetBehaviour$react_native_screens_release(bottomSheetBehavior, keyboardState, i);
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x015b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> configureBottomSheetBehaviour$react_native_screens_release(com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> behavior, com.swmansion.rnscreens.KeyboardState keyboardState, int selectedDetentIndex) {
        java.lang.Integer numValueOf;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(behavior, "behavior");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(keyboardState, "keyboardState");
        if (tryResolveContainerHeight() == null) {
            throw new java.lang.IllegalStateException("[RNScreens] Failed to find window height during bottom sheet behaviour configuration".toString());
        }
        behavior.setHideable(true);
        behavior.setDraggable(true);
        behavior.addBottomSheetCallback(this.sheetStateObserver);
        com.swmansion.rnscreens.ScreenFooter footer = this.screen.getFooter();
        if (footer != null) {
            footer.registerWithSheetBehavior(behavior);
        }
        if (keyboardState instanceof com.swmansion.rnscreens.KeyboardNotVisible) {
            int size = this.screen.getSheetDetents().size();
            if (size != 1) {
                if (size == 2) {
                    return com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useTwoDetents(behavior, java.lang.Integer.valueOf(com.swmansion.rnscreens.bottomsheet.SheetUtils.INSTANCE.sheetStateFromDetentIndex(selectedDetentIndex, this.screen.getSheetDetents().size())), java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(0).doubleValue() * r3.intValue())), java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(1).doubleValue() * r3.intValue())));
                }
                if (size == 3) {
                    return com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useThreeDetents(behavior, java.lang.Integer.valueOf(com.swmansion.rnscreens.bottomsheet.SheetUtils.INSTANCE.sheetStateFromDetentIndex(selectedDetentIndex, this.screen.getSheetDetents().size())), java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(0).doubleValue() * r3.intValue())), java.lang.Float.valueOf((float) (this.screen.getSheetDetents().get(1).doubleValue() / this.screen.getSheetDetents().get(2).doubleValue())), java.lang.Integer.valueOf((int) ((1 - this.screen.getSheetDetents().get(2).doubleValue()) * r3.intValue())));
                }
                throw new java.lang.IllegalStateException("[RNScreens] Invalid detent count " + this.screen.getSheetDetents().size() + ". Expected at most 3.");
            }
            if (com.swmansion.rnscreens.bottomsheet.SheetUtilsKt.isSheetFitToContents(this.screen)) {
                com.swmansion.rnscreens.ScreenContentWrapper contentWrapper = this.screen.getContentWrapper();
                if (contentWrapper != null) {
                    numValueOf = java.lang.Integer.valueOf(contentWrapper.getHeight());
                    numValueOf.intValue();
                    if (!com.swmansion.rnscreens.bottomsheet.SheetUtilsKt.isLaidOutOrHasCachedLayout(contentWrapper)) {
                        numValueOf = null;
                    }
                }
            } else {
                numValueOf = java.lang.Integer.valueOf((int) (((java.lang.Number) kotlin.collections.CollectionsKt.first((java.util.List) this.screen.getSheetDetents())).doubleValue() * r3.intValue()));
            }
            com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useSingleDetent$default(behavior, numValueOf, false, 2, null);
            return behavior;
        }
        if (keyboardState instanceof com.swmansion.rnscreens.KeyboardVisible) {
            int size2 = this.screen.getSheetDetents().size();
            if (size2 == 1) {
                behavior.addBottomSheetCallback(this.keyboardHandlerCallback);
                return behavior;
            }
            if (size2 == 2) {
                com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useTwoDetents$default(behavior, 3, null, null, 6, null);
                behavior.addBottomSheetCallback(this.keyboardHandlerCallback);
                return behavior;
            }
            if (size2 == 3) {
                com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useThreeDetents$default(behavior, 3, null, null, null, 14, null);
                behavior.addBottomSheetCallback(this.keyboardHandlerCallback);
                return behavior;
            }
            throw new java.lang.IllegalStateException("[RNScreens] Invalid detent count " + this.screen.getSheetDetents().size() + ". Expected at most 3.");
        }
        if (!(keyboardState instanceof com.swmansion.rnscreens.KeyboardDidHide)) {
            throw new kotlin.NoWhenBranchMatchedException();
        }
        behavior.removeBottomSheetCallback(this.keyboardHandlerCallback);
        int size3 = this.screen.getSheetDetents().size();
        if (size3 == 1) {
            return com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useSingleDetent(behavior, java.lang.Integer.valueOf((int) (((java.lang.Number) kotlin.collections.CollectionsKt.first((java.util.List) this.screen.getSheetDetents())).doubleValue() * r3.intValue())), false);
        }
        if (size3 == 2) {
            return com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useTwoDetents$default(behavior, null, java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(0).doubleValue() * r3.intValue())), java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(1).doubleValue() * r3.intValue())), 1, null);
        }
        if (size3 == 3) {
            return com.swmansion.rnscreens.bottomsheet.BottomSheetBehaviorExtKt.useThreeDetents$default(behavior, null, java.lang.Integer.valueOf((int) (this.screen.getSheetDetents().get(0).doubleValue() * r3.intValue())), java.lang.Float.valueOf((float) (this.screen.getSheetDetents().get(1).doubleValue() / this.screen.getSheetDetents().get(2).doubleValue())), java.lang.Integer.valueOf((int) ((1 - this.screen.getSheetDetents().get(2).doubleValue()) * r3.intValue())), 1, null);
        }
        throw new java.lang.IllegalStateException("[RNScreens] Invalid detent count " + this.screen.getSheetDetents().size() + ". Expected at most 3.");
    }

    @Override // androidx.core.view.OnApplyWindowInsetsListener
    public androidx.core.view.WindowInsetsCompat onApplyWindowInsets(android.view.View v, androidx.core.view.WindowInsetsCompat insets) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(v, "v");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(insets, "insets");
        boolean zIsVisible = insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.ime());
        androidx.core.graphics.Insets insets2 = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime());
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        if (zIsVisible) {
            this.isKeyboardVisible = true;
            this.keyboardState = new com.swmansion.rnscreens.KeyboardVisible(insets2.bottom);
            com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> sheetBehavior = getSheetBehavior();
            if (sheetBehavior != null) {
                configureBottomSheetBehaviour$react_native_screens_release$default(this, sheetBehavior, this.keyboardState, 0, 4, null);
            }
            androidx.core.graphics.Insets insets3 = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars());
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(insets3, "getInsets(...)");
            androidx.core.view.WindowInsetsCompat windowInsetsCompatBuild = new androidx.core.view.WindowInsetsCompat.Builder(insets).setInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars(), androidx.core.graphics.Insets.of(insets3.left, insets3.top, insets3.right, 0)).build();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(windowInsetsCompatBuild, "build(...)");
            return windowInsetsCompatBuild;
        }
        com.google.android.material.bottomsheet.BottomSheetBehavior<com.swmansion.rnscreens.Screen> sheetBehavior2 = getSheetBehavior();
        if (sheetBehavior2 != null) {
            if (this.isKeyboardVisible) {
                configureBottomSheetBehaviour$react_native_screens_release$default(this, sheetBehavior2, com.swmansion.rnscreens.KeyboardDidHide.INSTANCE, 0, 4, null);
            } else if (!kotlin.jvm.internal.Intrinsics.areEqual(this.keyboardState, com.swmansion.rnscreens.KeyboardNotVisible.INSTANCE)) {
                configureBottomSheetBehaviour$react_native_screens_release$default(this, sheetBehavior2, com.swmansion.rnscreens.KeyboardNotVisible.INSTANCE, 0, 4, null);
            }
        }
        this.keyboardState = com.swmansion.rnscreens.KeyboardNotVisible.INSTANCE;
        this.isKeyboardVisible = false;
        androidx.core.graphics.Insets insets4 = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars());
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(insets4, "getInsets(...)");
        androidx.core.view.WindowInsetsCompat windowInsetsCompatBuild2 = new androidx.core.view.WindowInsetsCompat.Builder(insets).setInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars(), androidx.core.graphics.Insets.of(insets4.left, insets4.top, insets4.right, 0)).build();
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(windowInsetsCompatBuild2, "build(...)");
        return windowInsetsCompatBuild2;
    }

    private final java.lang.Integer tryResolveContainerHeight() {
        android.view.WindowMetrics currentWindowMetrics;
        android.graphics.Rect bounds;
        android.util.DisplayMetrics displayMetrics;
        com.swmansion.rnscreens.ScreenContainer container = this.screen.getContainer();
        if (container != null) {
            return java.lang.Integer.valueOf(container.getHeight());
        }
        com.facebook.react.uimanager.ThemedReactContext reactContext = this.screen.getReactContext();
        android.content.res.Resources resources = reactContext.getResources();
        if (resources != null && (displayMetrics = resources.getDisplayMetrics()) != null) {
            return java.lang.Integer.valueOf(displayMetrics.heightPixels);
        }
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            java.lang.Object systemService = reactContext.getSystemService("window");
            android.view.WindowManager windowManager = systemService instanceof android.view.WindowManager ? (android.view.WindowManager) systemService : null;
            if (windowManager != null && (currentWindowMetrics = windowManager.getCurrentWindowMetrics()) != null && (bounds = currentWindowMetrics.getBounds()) != null) {
                return java.lang.Integer.valueOf(bounds.height());
            }
        }
        return null;
    }

    /* compiled from: SheetDelegate.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0018\u0010\n\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fH\u0016¨\u0006\r"}, d2 = {"Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate$KeyboardHandler;", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior$BottomSheetCallback;", "<init>", "(Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;)V", "onStateChanged", "", "bottomSheet", "Landroid/view/View;", "newState", "", "onSlide", "slideOffset", "", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private final class KeyboardHandler extends com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback {
        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback
        public void onSlide(android.view.View bottomSheet, float slideOffset) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
        }

        public KeyboardHandler() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback
        public void onStateChanged(android.view.View bottomSheet, int newState) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            if (newState == 4 && androidx.core.view.WindowInsetsCompat.toWindowInsetsCompat(bottomSheet.getRootWindowInsets()).isVisible(androidx.core.view.WindowInsetsCompat.Type.ime())) {
                bottomSheet.requestFocus();
                ((android.view.inputmethod.InputMethodManager) com.swmansion.rnscreens.bottomsheet.SheetDelegate.this.getScreen().getReactContext().getSystemService(android.view.inputmethod.InputMethodManager.class)).hideSoftInputFromWindow(bottomSheet.getWindowToken(), 0);
            }
        }
    }

    /* compiled from: SheetDelegate.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0018\u0010\n\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fH\u0016¨\u0006\r"}, d2 = {"Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate$SheetStateObserver;", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior$BottomSheetCallback;", "<init>", "(Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;)V", "onStateChanged", "", "bottomSheet", "Landroid/view/View;", "newState", "", "onSlide", "slideOffset", "", "react-native-screens_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private final class SheetStateObserver extends com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback {
        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback
        public void onSlide(android.view.View bottomSheet, float slideOffset) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
        }

        public SheetStateObserver() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback
        public void onStateChanged(android.view.View bottomSheet, int newState) {
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            com.swmansion.rnscreens.bottomsheet.SheetDelegate.this.onSheetStateChanged(newState);
        }
    }
}
