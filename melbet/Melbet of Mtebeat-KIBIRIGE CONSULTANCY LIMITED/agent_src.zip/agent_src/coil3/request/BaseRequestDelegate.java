package coil3.request;

/* compiled from: RequestDelegate.kt */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0081@\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0006\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\b\u0010\tJ\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000\u0088\u0001\u0002\u0092\u0001\u00020\u0003¨\u0006\u0012"}, d2 = {"Lcoil3/request/BaseRequestDelegate;", "Lcoil3/request/RequestDelegate;", "job", "Lkotlinx/coroutines/Job;", "constructor-impl", "(Lkotlinx/coroutines/Job;)Lkotlinx/coroutines/Job;", "dispose", "", "dispose-impl", "(Lkotlinx/coroutines/Job;)V", "equals", "", "other", "", "hashCode", "", "toString", "", "coil-core_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
@kotlin.jvm.JvmInline
/* loaded from: classes.dex */
public final class BaseRequestDelegate implements coil3.request.RequestDelegate {
    private final kotlinx.coroutines.Job job;

    /* renamed from: box-impl, reason: not valid java name */
    public static final /* synthetic */ coil3.request.BaseRequestDelegate m153boximpl(kotlinx.coroutines.Job job) {
        return new coil3.request.BaseRequestDelegate(job);
    }

    /* renamed from: constructor-impl, reason: not valid java name */
    public static kotlinx.coroutines.Job m154constructorimpl(kotlinx.coroutines.Job job) {
        return job;
    }

    /* renamed from: equals-impl, reason: not valid java name */
    public static boolean m156equalsimpl(kotlinx.coroutines.Job job, java.lang.Object obj) {
        return (obj instanceof coil3.request.BaseRequestDelegate) && kotlin.jvm.internal.Intrinsics.areEqual(job, ((coil3.request.BaseRequestDelegate) obj).getJob());
    }

    /* renamed from: equals-impl0, reason: not valid java name */
    public static final boolean m157equalsimpl0(kotlinx.coroutines.Job job, kotlinx.coroutines.Job job2) {
        return kotlin.jvm.internal.Intrinsics.areEqual(job, job2);
    }

    /* renamed from: hashCode-impl, reason: not valid java name */
    public static int m158hashCodeimpl(kotlinx.coroutines.Job job) {
        return job.hashCode();
    }

    /* renamed from: toString-impl, reason: not valid java name */
    public static java.lang.String m159toStringimpl(kotlinx.coroutines.Job job) {
        return "BaseRequestDelegate(job=" + job + ')';
    }

    public boolean equals(java.lang.Object other) {
        return m156equalsimpl(this.job, other);
    }

    public int hashCode() {
        return m158hashCodeimpl(this.job);
    }

    public java.lang.String toString() {
        return m159toStringimpl(this.job);
    }

    /* renamed from: unbox-impl, reason: not valid java name and from getter */
    public final /* synthetic */ kotlinx.coroutines.Job getJob() {
        return this.job;
    }

    private /* synthetic */ BaseRequestDelegate(kotlinx.coroutines.Job job) {
        this.job = job;
    }

    @Override // coil3.request.RequestDelegate
    public void dispose() {
        m155disposeimpl(this.job);
    }

    /* renamed from: dispose-impl, reason: not valid java name */
    public static void m155disposeimpl(kotlinx.coroutines.Job job) {
        kotlinx.coroutines.Job.DefaultImpls.cancel$default(job, (java.util.concurrent.CancellationException) null, 1, (java.lang.Object) null);
    }
}
