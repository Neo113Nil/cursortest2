package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class AndroidIdCollector {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f2942a;

    public AndroidIdCollector(android.content.Context context) {
        this.f2942a = context;
    }

    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        return kotlinx.coroutines.BuildersKt.e(kotlinx.coroutines.Dispatchers.b, new com.jorden.karto.setrisokegl.data.device.AndroidIdCollector$collect$2(this, null), continuation);
    }
}
