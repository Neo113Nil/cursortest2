package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository", f = "SplashRepository.kt", l = {28}, m = "getCachedPayload")
/* loaded from: classes.dex */
final class SplashRepository$getCachedPayload$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public /* synthetic */ java.lang.Object e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3014f;

    /* renamed from: g, reason: collision with root package name */
    public int f3015g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashRepository$getCachedPayload$1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.f3014f = splashRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) {
        this.e = obj;
        this.f3015g |= Integer.MIN_VALUE;
        return this.f3014f.b(this);
    }
}
