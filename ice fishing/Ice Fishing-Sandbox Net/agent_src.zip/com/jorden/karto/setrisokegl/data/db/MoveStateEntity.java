package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Entity
@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveStateEntity {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f2933a;
    public final boolean b;
    public final boolean c;
    public final java.lang.Long d;
    public final java.lang.String e;

    public MoveStateEntity(java.lang.String moveId, boolean z, boolean z2, java.lang.Long l, java.lang.String impression) {
        kotlin.jvm.internal.Intrinsics.e(moveId, "moveId");
        kotlin.jvm.internal.Intrinsics.e(impression, "impression");
        this.f2933a = moveId;
        this.b = z;
        this.c = z2;
        this.d = l;
        this.e = impression;
    }

    public static com.jorden.karto.setrisokegl.data.db.MoveStateEntity a(com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity, boolean z, boolean z2, java.lang.Long l, java.lang.String str, int i) {
        java.lang.String moveId = moveStateEntity.f2933a;
        if ((i & 2) != 0) {
            z = moveStateEntity.b;
        }
        boolean z3 = z;
        if ((i & 4) != 0) {
            z2 = moveStateEntity.c;
        }
        boolean z4 = z2;
        if ((i & 8) != 0) {
            l = moveStateEntity.d;
        }
        java.lang.Long l2 = l;
        if ((i & 16) != 0) {
            str = moveStateEntity.e;
        }
        java.lang.String impression = str;
        moveStateEntity.getClass();
        kotlin.jvm.internal.Intrinsics.e(moveId, "moveId");
        kotlin.jvm.internal.Intrinsics.e(impression, "impression");
        return new com.jorden.karto.setrisokegl.data.db.MoveStateEntity(moveId, z3, z4, l2, impression);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.db.MoveStateEntity)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2933a, moveStateEntity.f2933a) && this.b == moveStateEntity.b && this.c == moveStateEntity.c && kotlin.jvm.internal.Intrinsics.a(this.d, moveStateEntity.d) && kotlin.jvm.internal.Intrinsics.a(this.e, moveStateEntity.e);
    }

    public final int hashCode() {
        int iHashCode = (java.lang.Boolean.hashCode(this.c) + ((java.lang.Boolean.hashCode(this.b) + (this.f2933a.hashCode() * 31)) * 31)) * 31;
        java.lang.Long l = this.d;
        return this.e.hashCode() + ((iHashCode + (l == null ? 0 : l.hashCode())) * 31);
    }

    public final java.lang.String toString() {
        java.lang.StringBuilder sb = new java.lang.StringBuilder("MoveStateEntity(moveId=");
        sb.append(this.f2933a);
        sb.append(", kept=");
        sb.append(this.b);
        sb.append(", completed=");
        sb.append(this.c);
        sb.append(", lastGoEpochDay=");
        sb.append(this.d);
        sb.append(", impression=");
        return androidx.activity.h.j(sb, this.e, ")");
    }
}
