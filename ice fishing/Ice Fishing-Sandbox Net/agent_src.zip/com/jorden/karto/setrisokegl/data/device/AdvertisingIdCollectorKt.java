package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class AdvertisingIdCollectorKt {
}
