package com.jorden.karto.setrisokegl.data.remote;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class PayloadBuilderKt {
}
