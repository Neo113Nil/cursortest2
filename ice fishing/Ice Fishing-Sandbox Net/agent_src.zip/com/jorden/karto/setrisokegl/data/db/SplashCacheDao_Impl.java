package com.jorden.karto.setrisokegl.data.db;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashCacheDao_Impl implements com.jorden.karto.setrisokegl.data.db.SplashCacheDao {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.room.RoomDatabase f2936a;
    public final com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl.AnonymousClass1 b;

    @kotlin.Metadata
    /* renamed from: com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends androidx.room.EntityInsertAdapter<com.jorden.karto.setrisokegl.data.db.SplashCacheEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final void a(androidx.sqlite.SQLiteStatement statement, java.lang.Object obj) {
            com.jorden.karto.setrisokegl.data.db.SplashCacheEntity entity = (com.jorden.karto.setrisokegl.data.db.SplashCacheEntity) obj;
            kotlin.jvm.internal.Intrinsics.e(statement, "statement");
            kotlin.jvm.internal.Intrinsics.e(entity, "entity");
            statement.a(1, entity.f2937a);
            statement.q(entity.b, 2);
            statement.C(entity.c);
            statement.a(4, entity.d);
            statement.a(5, entity.e);
            statement.a(6, entity.f2938f ? 1L : 0L);
            statement.q(entity.f2939g, 7);
            statement.q(entity.f2940h, 8);
            statement.a(9, entity.i ? 1L : 0L);
            statement.a(10, entity.f2941j);
            statement.a(11, entity.k);
        }

        @Override // androidx.room.EntityInsertAdapter
        public final java.lang.String b() {
            return "INSERT OR REPLACE INTO `splash_cache` (`id`,`activityName`,`metabolicValue`,`durationMinutes`,`kilocaloriesBurned`,`isPrescribed`,`muscleGroup`,`effortLevel`,`isCompleted`,`badgeCount`,`userWeightKg`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public SplashCacheDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.e(__db, "__db");
        this.f2936a = __db;
        this.b = new com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl.AnonymousClass1();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.SplashCacheDao
    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        return androidx.room.util.DBUtil.b(this.f2936a, continuation, new androidx.room.c(12), true, false);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.SplashCacheDao
    public final java.lang.Object b(com.jorden.karto.setrisokegl.data.db.SplashCacheEntity splashCacheEntity, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2936a, continuation, new f.a(3, this, splashCacheEntity), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }
}
