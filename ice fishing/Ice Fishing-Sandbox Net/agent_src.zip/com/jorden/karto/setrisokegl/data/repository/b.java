package com.jorden.karto.setrisokegl.data.repository;

/* loaded from: classes.dex */
public final /* synthetic */ class b implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ int b;
    public final /* synthetic */ java.lang.String c;

    public /* synthetic */ b(java.lang.String str, int i) {
        this.b = i;
        this.c = str;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) throws java.lang.Exception {
        androidx.sqlite.SQLiteStatement sQLiteStatementL0;
        switch (this.b) {
            case 0:
                com.jorden.karto.setrisokegl.data.db.MoveStateEntity it = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
                kotlin.jvm.internal.Intrinsics.e(it, "it");
                return com.jorden.karto.setrisokegl.data.db.MoveStateEntity.a(it, false, false, null, kotlin.text.StringsKt.C(this.c).toString(), 15);
            case 1:
                java.lang.String str = this.c;
                androidx.sqlite.SQLiteConnection _connection = (androidx.sqlite.SQLiteConnection) obj;
                kotlin.jvm.internal.Intrinsics.e(_connection, "_connection");
                sQLiteStatementL0 = _connection.l0("SELECT * FROM move_state WHERE moveId = ?");
                try {
                    sQLiteStatementL0.q(str, 1);
                    int iC = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "moveId");
                    int iC2 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "kept");
                    int iC3 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "completed");
                    int iC4 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "lastGoEpochDay");
                    int iC5 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "impression");
                    if (sQLiteStatementL0.U()) {
                        moveStateEntity = new com.jorden.karto.setrisokegl.data.db.MoveStateEntity(sQLiteStatementL0.r(iC), ((int) sQLiteStatementL0.getLong(iC2)) != 0, ((int) sQLiteStatementL0.getLong(iC3)) != 0, sQLiteStatementL0.isNull(iC4) ? null : java.lang.Long.valueOf(sQLiteStatementL0.getLong(iC4)), sQLiteStatementL0.r(iC5));
                    }
                    return moveStateEntity;
                } finally {
                }
            case 2:
                java.lang.String str2 = this.c;
                androidx.sqlite.SQLiteConnection _connection2 = (androidx.sqlite.SQLiteConnection) obj;
                kotlin.jvm.internal.Intrinsics.e(_connection2, "_connection");
                sQLiteStatementL0 = _connection2.l0("SELECT * FROM move_state WHERE moveId = ?");
                try {
                    sQLiteStatementL0.q(str2, 1);
                    int iC6 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "moveId");
                    int iC7 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "kept");
                    int iC8 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "completed");
                    int iC9 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "lastGoEpochDay");
                    int iC10 = androidx.room.util.SQLiteStatementUtil.c(sQLiteStatementL0, "impression");
                    if (sQLiteStatementL0.U()) {
                        moveStateEntity = new com.jorden.karto.setrisokegl.data.db.MoveStateEntity(sQLiteStatementL0.r(iC6), ((int) sQLiteStatementL0.getLong(iC7)) != 0, ((int) sQLiteStatementL0.getLong(iC8)) != 0, sQLiteStatementL0.isNull(iC9) ? null : java.lang.Long.valueOf(sQLiteStatementL0.getLong(iC9)), sQLiteStatementL0.r(iC10));
                    }
                    return moveStateEntity;
                } finally {
                }
            default:
                java.lang.String it2 = (java.lang.String) obj;
                kotlin.jvm.internal.Intrinsics.e(it2, "it");
                boolean zM = kotlin.text.StringsKt.m(it2);
                java.lang.String str3 = this.c;
                return zM ? it2.length() < str3.length() ? str3 : it2 : androidx.activity.h.h(str3, it2);
        }
    }
}
