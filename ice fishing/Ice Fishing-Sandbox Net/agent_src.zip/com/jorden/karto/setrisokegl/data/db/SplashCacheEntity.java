package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Entity
@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashCacheEntity {

    /* renamed from: a, reason: collision with root package name */
    public final int f2937a;
    public final java.lang.String b;
    public final double c;
    public final int d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f2938f;

    /* renamed from: g, reason: collision with root package name */
    public final java.lang.String f2939g;

    /* renamed from: h, reason: collision with root package name */
    public final java.lang.String f2940h;
    public final boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final int f2941j;
    public final int k;

    @kotlin.Metadata
    public static final class Companion {
    }

    public SplashCacheEntity(int i, java.lang.String activityName, double d, int i2, int i3, boolean z, java.lang.String muscleGroup, java.lang.String effortLevel, boolean z2, int i4, int i5) {
        kotlin.jvm.internal.Intrinsics.e(activityName, "activityName");
        kotlin.jvm.internal.Intrinsics.e(muscleGroup, "muscleGroup");
        kotlin.jvm.internal.Intrinsics.e(effortLevel, "effortLevel");
        this.f2937a = i;
        this.b = activityName;
        this.c = d;
        this.d = i2;
        this.e = i3;
        this.f2938f = z;
        this.f2939g = muscleGroup;
        this.f2940h = effortLevel;
        this.i = z2;
        this.f2941j = i4;
        this.k = i5;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.db.SplashCacheEntity)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.db.SplashCacheEntity splashCacheEntity = (com.jorden.karto.setrisokegl.data.db.SplashCacheEntity) obj;
        return this.f2937a == splashCacheEntity.f2937a && kotlin.jvm.internal.Intrinsics.a(this.b, splashCacheEntity.b) && java.lang.Double.compare(this.c, splashCacheEntity.c) == 0 && this.d == splashCacheEntity.d && this.e == splashCacheEntity.e && this.f2938f == splashCacheEntity.f2938f && kotlin.jvm.internal.Intrinsics.a(this.f2939g, splashCacheEntity.f2939g) && kotlin.jvm.internal.Intrinsics.a(this.f2940h, splashCacheEntity.f2940h) && this.i == splashCacheEntity.i && this.f2941j == splashCacheEntity.f2941j && this.k == splashCacheEntity.k;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.k) + ((java.lang.Integer.hashCode(this.f2941j) + ((java.lang.Boolean.hashCode(this.i) + ((this.f2940h.hashCode() + ((this.f2939g.hashCode() + ((java.lang.Boolean.hashCode(this.f2938f) + ((java.lang.Integer.hashCode(this.e) + ((java.lang.Integer.hashCode(this.d) + ((java.lang.Double.hashCode(this.c) + ((this.b.hashCode() + (java.lang.Integer.hashCode(this.f2937a) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "SplashCacheEntity(id=" + this.f2937a + ", activityName=" + this.b + ", metabolicValue=" + this.c + ", durationMinutes=" + this.d + ", kilocaloriesBurned=" + this.e + ", isPrescribed=" + this.f2938f + ", muscleGroup=" + this.f2939g + ", effortLevel=" + this.f2940h + ", isCompleted=" + this.i + ", badgeCount=" + this.f2941j + ", userWeightKg=" + this.k + ")";
    }
}
