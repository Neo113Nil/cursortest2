package com.jorden.karto.setrisokegl.data.remote;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$2", f = "SplashSocketClient.kt", l = {59}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashSocketClient$exchange$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f2970f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ kotlinx.coroutines.CompletableDeferred f2971g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashSocketClient$exchange$2(kotlinx.coroutines.CompletableDeferred completableDeferred, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f2971g = completableDeferred;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$2(this.f2971g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f2970f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            this.f2970f = 1;
            obj = this.f2971g.F(this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return obj;
    }
}
