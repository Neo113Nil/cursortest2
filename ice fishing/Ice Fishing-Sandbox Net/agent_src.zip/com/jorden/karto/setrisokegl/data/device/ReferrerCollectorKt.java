package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class ReferrerCollectorKt {
    public static final java.lang.Object a(android.content.Context context, kotlin.coroutines.Continuation continuation) {
        return kotlinx.coroutines.CoroutineScopeKt.b(new com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2(context, null), continuation);
    }
}
