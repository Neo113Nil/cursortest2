package com.jorden.karto.setrisokegl.data.db;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveStateDao_Impl implements com.jorden.karto.setrisokegl.data.db.MoveStateDao {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.room.RoomDatabase f2932a;
    public final com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl.AnonymousClass1 b;

    @kotlin.Metadata
    /* renamed from: com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends androidx.room.EntityInsertAdapter<com.jorden.karto.setrisokegl.data.db.MoveStateEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final void a(androidx.sqlite.SQLiteStatement statement, java.lang.Object obj) {
            com.jorden.karto.setrisokegl.data.db.MoveStateEntity entity = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
            kotlin.jvm.internal.Intrinsics.e(statement, "statement");
            kotlin.jvm.internal.Intrinsics.e(entity, "entity");
            statement.q(entity.f2933a, 1);
            statement.a(2, entity.b ? 1L : 0L);
            statement.a(3, entity.c ? 1L : 0L);
            java.lang.Long l = entity.d;
            if (l == null) {
                statement.c0();
            } else {
                statement.a(4, l.longValue());
            }
            statement.q(entity.e, 5);
        }

        @Override // androidx.room.EntityInsertAdapter
        public final java.lang.String b() {
            return "INSERT OR REPLACE INTO `move_state` (`moveId`,`kept`,`completed`,`lastGoEpochDay`,`impression`) VALUES (?,?,?,?,?)";
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public MoveStateDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.e(__db, "__db");
        this.f2932a = __db;
        this.b = new com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl.AnonymousClass1();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.MoveStateDao
    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2932a, continuation, new androidx.room.c(8), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }

    @Override // com.jorden.karto.setrisokegl.data.db.MoveStateDao
    public final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b() {
        androidx.room.c cVar = new androidx.room.c(9);
        return androidx.room.coroutines.FlowUtil.a(this.f2932a, new java.lang.String[]{"move_state"}, cVar);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.MoveStateDao
    public final java.lang.Object c(com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2932a, continuation, new f.a(1, this, moveStateEntity), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }

    @Override // com.jorden.karto.setrisokegl.data.db.MoveStateDao
    public final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 d(java.lang.String str) {
        com.jorden.karto.setrisokegl.data.repository.b bVar = new com.jorden.karto.setrisokegl.data.repository.b(str, 1);
        return androidx.room.coroutines.FlowUtil.a(this.f2932a, new java.lang.String[]{"move_state"}, bVar);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.MoveStateDao
    public final java.lang.Object e(java.lang.String str, kotlin.coroutines.Continuation continuation) {
        return androidx.room.util.DBUtil.b(this.f2932a, continuation, new com.jorden.karto.setrisokegl.data.repository.b(str, 2), true, false);
    }
}
