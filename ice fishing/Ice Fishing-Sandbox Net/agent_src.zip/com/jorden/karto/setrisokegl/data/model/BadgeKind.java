package com.jorden.karto.setrisokegl.data.model;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@kotlin.Metadata
/* loaded from: classes.dex */
public final class BadgeKind {
    public static final /* synthetic */ com.jorden.karto.setrisokegl.data.model.BadgeKind[] e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ kotlin.enums.EnumEntries f2952f;
    public final int b;
    public final int c;
    public final int d;

    static {
        com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr = {new com.jorden.karto.setrisokegl.data.model.BadgeKind("FIRST_SPARK", 0, com.jorden.karto.setrisokegl.R.string.badge_first_spark, com.jorden.karto.setrisokegl.R.string.badge_first_spark_req, 1), new com.jorden.karto.setrisokegl.data.model.BadgeKind("STEADY_DRAUGHT", 1, com.jorden.karto.setrisokegl.R.string.badge_steady_draught, com.jorden.karto.setrisokegl.R.string.badge_steady_draught_req, 5), new com.jorden.karto.setrisokegl.data.model.BadgeKind("FULL_BLAZE_MARK", 2, com.jorden.karto.setrisokegl.R.string.badge_full_blaze, com.jorden.karto.setrisokegl.R.string.badge_full_blaze_req, 15), new com.jorden.karto.setrisokegl.data.model.BadgeKind("KINDLING_KEEPER", 3, com.jorden.karto.setrisokegl.R.string.badge_kindling_keeper, com.jorden.karto.setrisokegl.R.string.badge_kindling_keeper_req, 5), new com.jorden.karto.setrisokegl.data.model.BadgeKind("BEAM_READER", 4, com.jorden.karto.setrisokegl.R.string.badge_beam_reader, com.jorden.karto.setrisokegl.R.string.badge_beam_reader_req, 10), new com.jorden.karto.setrisokegl.data.model.BadgeKind("RECAP_KEEPER", 5, com.jorden.karto.setrisokegl.R.string.badge_recap_keeper, com.jorden.karto.setrisokegl.R.string.badge_recap_keeper_req, 5)};
        e = badgeKindArr;
        f2952f = kotlin.enums.EnumEntriesKt.a(badgeKindArr);
    }

    public BadgeKind(java.lang.String str, int i, int i2, int i3, int i4) {
        this.b = i2;
        this.c = i3;
        this.d = i4;
    }

    public static com.jorden.karto.setrisokegl.data.model.BadgeKind valueOf(java.lang.String str) {
        return (com.jorden.karto.setrisokegl.data.model.BadgeKind) java.lang.Enum.valueOf(com.jorden.karto.setrisokegl.data.model.BadgeKind.class, str);
    }

    public static com.jorden.karto.setrisokegl.data.model.BadgeKind[] values() {
        return (com.jorden.karto.setrisokegl.data.model.BadgeKind[]) e.clone();
    }
}
