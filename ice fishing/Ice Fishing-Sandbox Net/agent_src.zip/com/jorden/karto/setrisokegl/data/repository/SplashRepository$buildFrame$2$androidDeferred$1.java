package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1", f = "SplashRepository.kt", l = {50}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashRepository$buildFrame$2$androidDeferred$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3003f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3004g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1$1", f = "SplashRepository.kt", l = {51}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3005f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3006g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3006g = splashRepository;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1.AnonymousClass1(this.f3006g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3005f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                com.jorden.karto.setrisokegl.data.device.AndroidIdCollector androidIdCollector = this.f3006g.c;
                this.f3005f = 1;
                obj = androidIdCollector.a(this);
                if (obj == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            return obj;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashRepository$buildFrame$2$androidDeferred$1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3004g = splashRepository;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1(this.f3004g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3003f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            int i2 = kotlin.time.Duration.d;
            long jC = kotlin.time.DurationKt.c(5000, kotlin.time.DurationUnit.e);
            com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1.AnonymousClass1(this.f3004g, null);
            this.f3003f = 1;
            obj = kotlinx.coroutines.TimeoutKt.c(kotlinx.coroutines.DelayKt.c(jC), anonymousClass1, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return obj;
    }
}
