package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
final class ReferrerSession {

    /* renamed from: a, reason: collision with root package name */
    public final com.android.installreferrer.api.InstallReferrerClient f2949a;

    public ReferrerSession(android.content.Context context) {
        this.f2949a = new com.android.installreferrer.api.InstallReferrerClient.Builder(context).a();
    }

    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        kotlinx.coroutines.CancellableContinuationImpl cancellableContinuationImpl = new kotlinx.coroutines.CancellableContinuationImpl(1, kotlin.coroutines.intrinsics.IntrinsicsKt.a(continuation));
        cancellableContinuationImpl.s();
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean = new java.util.concurrent.atomic.AtomicBoolean(false);
        cancellableContinuationImpl.w(new kotlin.jvm.functions.Function1<java.lang.Throwable, kotlin.Unit>() { // from class: com.jorden.karto.setrisokegl.data.device.ReferrerSession$awaitReferrer$2$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object m(java.lang.Object obj) {
                try {
                    this.b.f2949a.a();
                } catch (java.lang.Throwable th) {
                    kotlin.ResultKt.a(th);
                }
                return kotlin.Unit.f3201a;
            }
        });
        this.f2949a.c(new com.jorden.karto.setrisokegl.data.device.ReferrerSession$awaitReferrer$2$2(atomicBoolean, cancellableContinuationImpl, this));
        java.lang.Object objR = cancellableContinuationImpl.r();
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        return objR;
    }
}
