package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class EmberRepository$observeWeighIns$$inlined$map$1 implements kotlinx.coroutines.flow.Flow<java.lang.Integer> {
    public final /* synthetic */ kotlinx.coroutines.flow.Flow b;

    @kotlin.Metadata
    @kotlin.jvm.internal.SourceDebugExtension
    /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1$2, reason: invalid class name */
    public final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
        public final /* synthetic */ kotlinx.coroutines.flow.FlowCollector b;

        @kotlin.Metadata
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1$2", f = "EmberRepository.kt", l = {219}, m = "emit")
        /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1$2$1, reason: invalid class name */
        public final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
            public /* synthetic */ java.lang.Object e;

            /* renamed from: f, reason: collision with root package name */
            public int f2980f;

            public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                super(continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object p(java.lang.Object obj) {
                this.e = obj;
                this.f2980f |= Integer.MIN_VALUE;
                return com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2.this.c(null, this);
            }
        }

        public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
            this.b = flowCollector;
        }

        /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
        @Override // kotlinx.coroutines.flow.FlowCollector
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object c(java.lang.Object obj, kotlin.coroutines.Continuation continuation) throws java.lang.Throwable {
            com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
            if (continuation instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                anonymousClass1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                int i = anonymousClass1.f2980f;
                if ((i & Integer.MIN_VALUE) != 0) {
                    anonymousClass1.f2980f = i - Integer.MIN_VALUE;
                } else {
                    anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                }
            }
            java.lang.Object obj2 = anonymousClass1.e;
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i2 = anonymousClass1.f2980f;
            if (i2 == 0) {
                kotlin.ResultKt.b(obj2);
                com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity = (com.jorden.karto.setrisokegl.data.db.CounterEntity) obj;
                java.lang.Integer num = new java.lang.Integer(counterEntity != null ? counterEntity.b : 0);
                anonymousClass1.f2980f = 1;
                if (this.b.c(num, anonymousClass1) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i2 != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj2);
            }
            return kotlin.Unit.f3201a;
        }
    }

    public EmberRepository$observeWeighIns$$inlined$map$1(kotlinx.coroutines.flow.Flow flow) {
        this.b = flow;
    }

    @Override // kotlinx.coroutines.flow.Flow
    public final java.lang.Object a(kotlinx.coroutines.flow.FlowCollector flowCollector, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objA = this.b.a(new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
        return objA == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objA : kotlin.Unit.f3201a;
    }
}
