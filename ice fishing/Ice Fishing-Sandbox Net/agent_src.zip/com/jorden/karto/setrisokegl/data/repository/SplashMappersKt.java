package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashMappersKt {
}
