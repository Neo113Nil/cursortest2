package com.jorden.karto.setrisokegl.data.remote;

import okhttp3.internal.connection.RealCall.AsyncCall;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class SplashSocketClient {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f2965a;
    public final okhttp3.OkHttpClient b;

    public SplashSocketClient(android.content.Context context) {
        this.f2965a = context;
        okhttp3.OkHttpClient.Builder builder = new okhttp3.OkHttpClient.Builder();
        java.util.concurrent.TimeUnit unit = java.util.concurrent.TimeUnit.SECONDS;
        kotlin.jvm.internal.Intrinsics.e(unit, "unit");
        builder.v = okhttp3.internal.Util.b("timeout", 80L, unit);
        builder.w = okhttp3.internal.Util.b("timeout", 75L, unit);
        builder.x = okhttp3.internal.Util.b("timeout", 75L, unit);
        builder.y = okhttp3.internal.Util.b("interval", 20L, unit);
        builder.c.add(new okhttp3.Interceptor() { // from class: com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$special$$inlined$-addInterceptor$1
            @Override // okhttp3.Interceptor
            public final okhttp3.Response a(okhttp3.internal.http.RealInterceptorChain realInterceptorChain) {
                okhttp3.Request.Builder builderA = realInterceptorChain.e.a();
                java.lang.String value = android.webkit.WebSettings.getDefaultUserAgent(this.f2966a.f2965a);
                kotlin.jvm.internal.Intrinsics.d(value, "getDefaultUserAgent(...)");
                okhttp3.Headers.Builder builder2 = builderA.c;
                builder2.getClass();
                kotlin.jvm.internal.Intrinsics.e("User-Agent", "name");
                kotlin.jvm.internal.Intrinsics.e(value, "value");
                okhttp3.Headers.Companion.a("User-Agent");
                okhttp3.Headers.Companion.b(value, "User-Agent");
                builder2.a("User-Agent", value);
                return realInterceptorChain.b(builderA.a());
            }
        });
        this.b = new okhttp3.OkHttpClient(builder);
    }

    /* JADX WARN: Removed duplicated region for block: B:77:0x0270  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(java.lang.String str, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$1 splashSocketClient$exchange$1;
        kotlinx.coroutines.CompletableDeferred completableDeferred;
        kotlinx.coroutines.CompletableDeferred completableDeferred2;
        okhttp3.internal.ws.RealWebSocket realWebSocket;
        if (continuationImpl instanceof com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$1) {
            splashSocketClient$exchange$1 = (com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$1) continuationImpl;
            int i = splashSocketClient$exchange$1.i;
            if ((i & Integer.MIN_VALUE) != 0) {
                splashSocketClient$exchange$1.i = i - Integer.MIN_VALUE;
            } else {
                splashSocketClient$exchange$1 = new com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$1(this, continuationImpl);
            }
        }
        java.lang.Object objC = splashSocketClient$exchange$1.f2968g;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = splashSocketClient$exchange$1.i;
        if (i2 == 0) {
            kotlin.ResultKt.b(objC);
            kotlinx.coroutines.CompletableDeferred completableDeferredA = kotlinx.coroutines.CompletableDeferredKt.a();
            okhttp3.Request.Builder builder = new okhttp3.Request.Builder();
            java.lang.String strConcat = "https://embergauge.space/api/metabolic/scale/activity";
            if (kotlin.text.StringsKt.x("https://embergauge.space/api/metabolic/scale/activity", "ws:", true)) {
                strConcat = "http:".concat("ps://embergauge.space/api/metabolic/scale/activity");
            } else if (kotlin.text.StringsKt.x("https://embergauge.space/api/metabolic/scale/activity", "wss:", true)) {
                strConcat = "https:".concat("s://embergauge.space/api/metabolic/scale/activity");
            }
            kotlin.jvm.internal.Intrinsics.e(strConcat, "<this>");
            okhttp3.HttpUrl.Builder builder2 = new okhttp3.HttpUrl.Builder();
            builder2.b(null, strConcat);
            builder.f4048a = builder2.a();
            okhttp3.Request requestA = builder.a();
            com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$socket$1 splashSocketClient$exchange$socket$1 = new com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$socket$1(str, completableDeferredA);
            okhttp3.OkHttpClient okHttpClient = this.b;
            okHttpClient.getClass();
            okhttp3.internal.concurrent.TaskRunner taskRunner = okhttp3.internal.concurrent.TaskRunner.f4071h;
            java.util.Random random = new java.util.Random();
            int i3 = okHttpClient.z;
            com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$1 splashSocketClient$exchange$12 = splashSocketClient$exchange$1;
            okhttp3.internal.ws.RealWebSocket realWebSocket2 = new okhttp3.internal.ws.RealWebSocket(taskRunner, requestA, splashSocketClient$exchange$socket$1, random, i3, okHttpClient.A);
            if (requestA.c.a("Sec-WebSocket-Extensions") != null) {
                realWebSocket2.c(new java.net.ProtocolException("Request header not permitted: 'Sec-WebSocket-Extensions'"), null);
            } else {
                okhttp3.OkHttpClient.Builder builder3 = new okhttp3.OkHttpClient.Builder();
                builder3.f4037a = okHttpClient.b;
                builder3.b = okHttpClient.c;
                kotlin.collections.CollectionsKt.g(builder3.c, okHttpClient.d);
                kotlin.collections.CollectionsKt.g(builder3.d, okHttpClient.e);
                builder3.f4038f = okHttpClient.f4033g;
                builder3.f4039g = okHttpClient.f4034h;
                builder3.f4040h = okHttpClient.i;
                builder3.i = okHttpClient.f4035j;
                builder3.f4041j = okHttpClient.k;
                builder3.k = okHttpClient.l;
                builder3.l = okHttpClient.f4036m;
                builder3.f4042m = okHttpClient.n;
                builder3.n = okHttpClient.o;
                builder3.o = okHttpClient.p;
                builder3.p = okHttpClient.q;
                builder3.q = okHttpClient.r;
                builder3.r = okHttpClient.s;
                builder3.s = okHttpClient.t;
                builder3.t = okHttpClient.u;
                builder3.u = okHttpClient.v;
                builder3.v = okHttpClient.w;
                builder3.w = okHttpClient.x;
                builder3.x = okHttpClient.y;
                builder3.y = i3;
                builder3.z = okHttpClient.A;
                builder3.A = okHttpClient.B;
                builder3.e = new com.google.android.material.carousel.b();
                java.util.List protocols = okhttp3.internal.ws.RealWebSocket.w;
                kotlin.jvm.internal.Intrinsics.e(protocols, "protocols");
                java.util.ArrayList arrayListO = kotlin.collections.CollectionsKt.O(protocols);
                okhttp3.Protocol protocol = okhttp3.Protocol.f4044g;
                if (!arrayListO.contains(protocol) && !arrayListO.contains(okhttp3.Protocol.d)) {
                    throw new java.lang.IllegalArgumentException(("protocols must contain h2_prior_knowledge or http/1.1: " + arrayListO).toString());
                }
                if (arrayListO.contains(protocol) && arrayListO.size() > 1) {
                    throw new java.lang.IllegalArgumentException(("protocols containing h2_prior_knowledge cannot use other protocols: " + arrayListO).toString());
                }
                if (arrayListO.contains(okhttp3.Protocol.c)) {
                    throw new java.lang.IllegalArgumentException(("protocols must not contain http/1.0: " + arrayListO).toString());
                }
                if (arrayListO.contains(null)) {
                    throw new java.lang.IllegalArgumentException("protocols must not contain null");
                }
                arrayListO.remove(okhttp3.Protocol.e);
                if (!arrayListO.equals(builder3.r)) {
                    builder3.A = null;
                }
                java.util.List listUnmodifiableList = java.util.Collections.unmodifiableList(arrayListO);
                kotlin.jvm.internal.Intrinsics.d(listUnmodifiableList, "unmodifiableList(protocolsCopy)");
                builder3.r = listUnmodifiableList;
                okhttp3.OkHttpClient okHttpClient2 = new okhttp3.OkHttpClient(builder3);
                okhttp3.Request.Builder builderA = requestA.a();
                builderA.b("Upgrade", "websocket");
                builderA.b("Connection", "Upgrade");
                builderA.b("Sec-WebSocket-Key", realWebSocket2.f4216f);
                builderA.b("Sec-WebSocket-Version", "13");
                builderA.b("Sec-WebSocket-Extensions", "permessage-deflate");
                okhttp3.Request requestA2 = builderA.a();
                okhttp3.internal.connection.RealCall realCall = new okhttp3.internal.connection.RealCall(okHttpClient2, requestA2);
                realWebSocket2.f4217g = realCall;
                okhttp3.internal.ws.RealWebSocket$connect$1 realWebSocket$connect$1 = new okhttp3.internal.ws.RealWebSocket$connect$1(realWebSocket2, requestA2);
                if (!realCall.f4091g.compareAndSet(false, true)) {
                    throw new java.lang.IllegalStateException("Already Executed");
                }
                okhttp3.internal.platform.Platform platform = okhttp3.internal.platform.Platform.f4197a;
                realCall.f4092h = okhttp3.internal.platform.Platform.f4197a.g();
                realCall.e.getClass();
                okhttp3.Dispatcher dispatcher = okHttpClient2.b;
                okhttp3.internal.connection.RealCall.AsyncCall asyncCall = realCall.new AsyncCall(realWebSocket$connect$1);
                dispatcher.getClass();
                synchronized (dispatcher) {
                    dispatcher.b.add(asyncCall);
                }
                dispatcher.b();
            }
            try {
                int i4 = kotlin.time.Duration.d;
                long jD = kotlin.time.DurationKt.d(15000L, kotlin.time.DurationUnit.e);
                completableDeferred = completableDeferredA;
                try {
                    com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$2 splashSocketClient$exchange$2 = new com.jorden.karto.setrisokegl.data.remote.SplashSocketClient$exchange$2(completableDeferred, null);
                    splashSocketClient$exchange$12.e = completableDeferred;
                    splashSocketClient$exchange$12.f2967f = realWebSocket2;
                    splashSocketClient$exchange$12.i = 1;
                    objC = kotlinx.coroutines.TimeoutKt.c(kotlinx.coroutines.DelayKt.c(jD), splashSocketClient$exchange$2, splashSocketClient$exchange$12);
                    if (objC == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                    completableDeferred2 = completableDeferred;
                    realWebSocket = realWebSocket2;
                } catch (java.lang.Throwable th) {
                    th = th;
                    completableDeferred2 = completableDeferred;
                    realWebSocket = realWebSocket2;
                    if (!completableDeferred2.B()) {
                    }
                    throw th;
                }
            } catch (java.lang.Throwable th2) {
                th = th2;
                completableDeferred = completableDeferredA;
            }
        } else {
            if (i2 != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            realWebSocket = splashSocketClient$exchange$1.f2967f;
            completableDeferred2 = (kotlinx.coroutines.CompletableDeferred) splashSocketClient$exchange$1.e;
            try {
                kotlin.ResultKt.b(objC);
            } catch (java.lang.Throwable th3) {
                th = th3;
                if (!completableDeferred2.B()) {
                    realWebSocket.cancel();
                }
                throw th;
            }
        }
        java.lang.String str2 = (java.lang.String) objC;
        if (str2 == null) {
            throw new java.io.IOException("WebSocket response timed out");
        }
        if (!completableDeferred2.B()) {
            realWebSocket.cancel();
        }
        return str2;
    }
}
