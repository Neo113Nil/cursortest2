package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Entity
@kotlin.Metadata
/* loaded from: classes.dex */
public final class CounterEntity {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f2929a;
    public final int b;

    public CounterEntity(java.lang.String counterKey, int i) {
        kotlin.jvm.internal.Intrinsics.e(counterKey, "counterKey");
        this.f2929a = counterKey;
        this.b = i;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.db.CounterEntity)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity = (com.jorden.karto.setrisokegl.data.db.CounterEntity) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2929a, counterEntity.f2929a) && this.b == counterEntity.b;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.b) + (this.f2929a.hashCode() * 31);
    }

    public final java.lang.String toString() {
        return "CounterEntity(counterKey=" + this.f2929a + ", amount=" + this.b + ")";
    }
}
