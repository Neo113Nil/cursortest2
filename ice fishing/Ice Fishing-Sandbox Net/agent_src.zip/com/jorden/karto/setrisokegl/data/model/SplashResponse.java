package com.jorden.karto.setrisokegl.data.model;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashResponse {

    @com.google.gson.annotations.SerializedName("activityName")
    @org.jetbrains.annotations.NotNull
    private final java.lang.String activityName;

    @com.google.gson.annotations.SerializedName("badgeCount")
    private final int badgeCount;

    @com.google.gson.annotations.SerializedName("durationMinutes")
    private final int durationMinutes;

    @com.google.gson.annotations.SerializedName("effortLevel")
    @org.jetbrains.annotations.NotNull
    private final java.lang.String effortLevel;

    @com.google.gson.annotations.SerializedName("isCompleted")
    private final boolean isCompleted;

    @com.google.gson.annotations.SerializedName("isPrescribed")
    private final boolean isPrescribed;

    @com.google.gson.annotations.SerializedName("kilocaloriesBurned")
    private final int kilocaloriesBurned;

    @com.google.gson.annotations.SerializedName("metabolicValue")
    private final double metabolicValue;

    @com.google.gson.annotations.SerializedName("muscleGroup")
    @org.jetbrains.annotations.NotNull
    private final java.lang.String muscleGroup;

    @com.google.gson.annotations.SerializedName("userWeightKg")
    private final int userWeightKg;

    public SplashResponse(java.lang.String activityName, double d, int i, int i2, boolean z, java.lang.String muscleGroup, java.lang.String effortLevel, boolean z2, int i3, int i4) {
        kotlin.jvm.internal.Intrinsics.e(activityName, "activityName");
        kotlin.jvm.internal.Intrinsics.e(muscleGroup, "muscleGroup");
        kotlin.jvm.internal.Intrinsics.e(effortLevel, "effortLevel");
        this.activityName = activityName;
        this.metabolicValue = d;
        this.durationMinutes = i;
        this.kilocaloriesBurned = i2;
        this.isPrescribed = z;
        this.muscleGroup = muscleGroup;
        this.effortLevel = effortLevel;
        this.isCompleted = z2;
        this.badgeCount = i3;
        this.userWeightKg = i4;
    }

    public final java.lang.String a() {
        return this.activityName;
    }

    public final int b() {
        return this.badgeCount;
    }

    public final int c() {
        return this.durationMinutes;
    }

    public final java.lang.String d() {
        return this.effortLevel;
    }

    public final int e() {
        return this.kilocaloriesBurned;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.model.SplashResponse)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.model.SplashResponse splashResponse = (com.jorden.karto.setrisokegl.data.model.SplashResponse) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.activityName, splashResponse.activityName) && java.lang.Double.compare(this.metabolicValue, splashResponse.metabolicValue) == 0 && this.durationMinutes == splashResponse.durationMinutes && this.kilocaloriesBurned == splashResponse.kilocaloriesBurned && this.isPrescribed == splashResponse.isPrescribed && kotlin.jvm.internal.Intrinsics.a(this.muscleGroup, splashResponse.muscleGroup) && kotlin.jvm.internal.Intrinsics.a(this.effortLevel, splashResponse.effortLevel) && this.isCompleted == splashResponse.isCompleted && this.badgeCount == splashResponse.badgeCount && this.userWeightKg == splashResponse.userWeightKg;
    }

    public final double f() {
        return this.metabolicValue;
    }

    public final java.lang.String g() {
        return this.muscleGroup;
    }

    public final int h() {
        return this.userWeightKg;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.userWeightKg) + ((java.lang.Integer.hashCode(this.badgeCount) + ((java.lang.Boolean.hashCode(this.isCompleted) + ((this.effortLevel.hashCode() + ((this.muscleGroup.hashCode() + ((java.lang.Boolean.hashCode(this.isPrescribed) + ((java.lang.Integer.hashCode(this.kilocaloriesBurned) + ((java.lang.Integer.hashCode(this.durationMinutes) + ((java.lang.Double.hashCode(this.metabolicValue) + (this.activityName.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final boolean i() {
        return this.isCompleted;
    }

    public final boolean j() {
        return this.isPrescribed;
    }

    public final java.lang.String toString() {
        return "SplashResponse(activityName=" + this.activityName + ", metabolicValue=" + this.metabolicValue + ", durationMinutes=" + this.durationMinutes + ", kilocaloriesBurned=" + this.kilocaloriesBurned + ", isPrescribed=" + this.isPrescribed + ", muscleGroup=" + this.muscleGroup + ", effortLevel=" + this.effortLevel + ", isCompleted=" + this.isCompleted + ", badgeCount=" + this.badgeCount + ", userWeightKg=" + this.userWeightKg + ")";
    }
}
