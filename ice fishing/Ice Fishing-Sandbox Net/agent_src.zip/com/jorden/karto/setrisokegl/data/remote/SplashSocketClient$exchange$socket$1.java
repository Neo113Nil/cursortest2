package com.jorden.karto.setrisokegl.data.remote;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashSocketClient$exchange$socket$1 extends okhttp3.WebSocketListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ java.lang.String f2972a;
    public final /* synthetic */ kotlinx.coroutines.CompletableDeferred b;

    public SplashSocketClient$exchange$socket$1(java.lang.String str, kotlinx.coroutines.CompletableDeferred completableDeferred) {
        this.f2972a = str;
        this.b = completableDeferred;
    }
}
