package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Dao
@kotlin.Metadata
/* loaded from: classes.dex */
public interface SplashCacheDao {
    java.lang.Object a(kotlin.coroutines.Continuation continuation);

    java.lang.Object b(com.jorden.karto.setrisokegl.data.db.SplashCacheEntity splashCacheEntity, kotlin.coroutines.Continuation continuation);
}
