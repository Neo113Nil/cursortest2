package com.jorden.karto.setrisokegl.data.remote;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class RemoteConfig {
}
