package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2", f = "SplashRepository.kt", l = {55, 56, 57}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashRepository$buildFrame$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public java.lang.Object f2997f;

    /* renamed from: g, reason: collision with root package name */
    public int f2998g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f2999h;
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashRepository$buildFrame$2(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.i = splashRepository;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2 splashRepository$buildFrame$2 = new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2(this.i, continuation);
        splashRepository$buildFrame$2.f2999h = obj;
        return splashRepository$buildFrame$2;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x009c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00dd A[LOOP:0: B:30:0x00d7->B:32:0x00dd, LOOP_END] */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlinx.coroutines.Deferred deferred;
        kotlinx.coroutines.Deferred deferred2;
        java.lang.String advertisingId;
        kotlinx.coroutines.Deferred deferred3;
        java.lang.String referrer;
        java.lang.String str;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f2998g;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) this.f2999h;
            kotlinx.coroutines.scheduling.DefaultIoScheduler defaultIoScheduler = kotlinx.coroutines.Dispatchers.b;
            com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository = this.i;
            kotlinx.coroutines.Deferred deferredA = kotlinx.coroutines.BuildersKt.a(coroutineScope, defaultIoScheduler, new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1(splashRepository, null), 2);
            kotlinx.coroutines.Deferred deferredA2 = kotlinx.coroutines.BuildersKt.a(coroutineScope, null, new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$referrerDeferred$1(splashRepository, null), 3);
            kotlinx.coroutines.Deferred deferredA3 = kotlinx.coroutines.BuildersKt.a(coroutineScope, null, new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$androidDeferred$1(splashRepository, null), 3);
            this.f2999h = deferredA2;
            this.f2997f = deferredA3;
            this.f2998g = 1;
            java.lang.Object objF = deferredA.F(this);
            if (objF == coroutineSingletons) {
                return coroutineSingletons;
            }
            deferred = deferredA2;
            deferred2 = deferredA3;
            obj = objF;
        } else {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    referrer = (java.lang.String) this.f2997f;
                    advertisingId = (java.lang.String) this.f2999h;
                    kotlin.ResultKt.b(obj);
                    java.lang.String str2 = (java.lang.String) obj;
                    str = str2 != null ? str2 : null;
                    if (str == null) {
                        str = "";
                    }
                    kotlin.jvm.internal.Intrinsics.e(advertisingId, "advertisingId");
                    kotlin.jvm.internal.Intrinsics.e(referrer, "referrer");
                    java.util.List<kotlin.Pair> listX = kotlin.collections.CollectionsKt.x(new kotlin.Pair("stairwell", advertisingId), new kotlin.Pair("laundry", referrer), new kotlin.Pair("firewood", str));
                    org.json.JSONObject jSONObject = new org.json.JSONObject();
                    for (kotlin.Pair pair : listX) {
                        jSONObject.put((java.lang.String) pair.b, (java.lang.String) pair.c);
                    }
                    java.lang.String string = jSONObject.toString();
                    kotlin.jvm.internal.Intrinsics.d(string, "toString(...)");
                    return string;
                }
                advertisingId = (java.lang.String) this.f2997f;
                deferred3 = (kotlinx.coroutines.Deferred) this.f2999h;
                kotlin.ResultKt.b(obj);
                java.lang.String str3 = new java.lang.String((byte[]) obj, kotlin.text.Charsets.f3239a);
                this.f2999h = advertisingId;
                this.f2997f = str3;
                this.f2998g = 3;
                obj = deferred3.F(this);
                if (obj != coroutineSingletons) {
                    return coroutineSingletons;
                }
                referrer = str3;
                java.lang.String str22 = (java.lang.String) obj;
                if (str22 != null) {
                }
                if (str == null) {
                }
                kotlin.jvm.internal.Intrinsics.e(advertisingId, "advertisingId");
                kotlin.jvm.internal.Intrinsics.e(referrer, "referrer");
                java.util.List<kotlin.Pair> listX2 = kotlin.collections.CollectionsKt.x(new kotlin.Pair("stairwell", advertisingId), new kotlin.Pair("laundry", referrer), new kotlin.Pair("firewood", str));
                org.json.JSONObject jSONObject2 = new org.json.JSONObject();
                while (r11.hasNext()) {
                }
                java.lang.String string2 = jSONObject2.toString();
                kotlin.jvm.internal.Intrinsics.d(string2, "toString(...)");
                return string2;
            }
            deferred2 = (kotlinx.coroutines.Deferred) this.f2997f;
            deferred = (kotlinx.coroutines.Deferred) this.f2999h;
            kotlin.ResultKt.b(obj);
        }
        java.lang.String str4 = (java.lang.String) obj;
        this.f2999h = deferred2;
        this.f2997f = str4;
        this.f2998g = 2;
        java.lang.Object objF2 = deferred.F(this);
        if (objF2 == coroutineSingletons) {
            return coroutineSingletons;
        }
        kotlinx.coroutines.Deferred deferred4 = deferred2;
        advertisingId = str4;
        obj = objF2;
        deferred3 = deferred4;
        java.lang.String str32 = new java.lang.String((byte[]) obj, kotlin.text.Charsets.f3239a);
        this.f2999h = advertisingId;
        this.f2997f = str32;
        this.f2998g = 3;
        obj = deferred3.F(this);
        if (obj != coroutineSingletons) {
        }
    }
}
