package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.device.AndroidIdCollector$collect$2", f = "AndroidIdCollector.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class AndroidIdCollector$collect$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.device.AndroidIdCollector f2943f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AndroidIdCollector$collect$2(com.jorden.karto.setrisokegl.data.device.AndroidIdCollector androidIdCollector, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f2943f = androidIdCollector;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.device.AndroidIdCollector$collect$2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.data.device.AndroidIdCollector$collect$2(this.f2943f, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Exception {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        kotlin.ResultKt.b(obj);
        try {
            java.lang.String string = android.provider.Settings.Secure.getString(this.f2943f.f2942a.getContentResolver(), "android_id");
            if (string != null) {
                return string;
            }
            return null;
        } catch (java.lang.Exception e) {
            if (e instanceof java.util.concurrent.CancellationException) {
                throw e;
            }
            return null;
        }
    }
}
