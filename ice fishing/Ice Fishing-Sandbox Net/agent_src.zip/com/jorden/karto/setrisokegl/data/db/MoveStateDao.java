package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Dao
@kotlin.Metadata
/* loaded from: classes.dex */
public interface MoveStateDao {
    java.lang.Object a(kotlin.coroutines.Continuation continuation);

    androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b();

    java.lang.Object c(com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity, kotlin.coroutines.Continuation continuation);

    androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 d(java.lang.String str);

    java.lang.Object e(java.lang.String str, kotlin.coroutines.Continuation continuation);
}
