package com.jorden.karto.setrisokegl.data.db;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class RecentViewDao_Impl implements com.jorden.karto.setrisokegl.data.db.RecentViewDao {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.room.RoomDatabase f2934a;
    public final com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl.AnonymousClass1 b;

    @kotlin.Metadata
    /* renamed from: com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends androidx.room.EntityInsertAdapter<com.jorden.karto.setrisokegl.data.db.RecentViewEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final void a(androidx.sqlite.SQLiteStatement statement, java.lang.Object obj) {
            com.jorden.karto.setrisokegl.data.db.RecentViewEntity entity = (com.jorden.karto.setrisokegl.data.db.RecentViewEntity) obj;
            kotlin.jvm.internal.Intrinsics.e(statement, "statement");
            kotlin.jvm.internal.Intrinsics.e(entity, "entity");
            statement.q(entity.f2935a, 1);
            statement.a(2, entity.b);
        }

        @Override // androidx.room.EntityInsertAdapter
        public final java.lang.String b() {
            return "INSERT OR REPLACE INTO `recent_view` (`moveId`,`lastViewed`) VALUES (?,?)";
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public RecentViewDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.e(__db, "__db");
        this.f2934a = __db;
        this.b = new com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl.AnonymousClass1();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.RecentViewDao
    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2934a, continuation, new androidx.room.c(10), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }

    @Override // com.jorden.karto.setrisokegl.data.db.RecentViewDao
    public final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b() {
        androidx.room.c cVar = new androidx.room.c(11);
        return androidx.room.coroutines.FlowUtil.a(this.f2934a, new java.lang.String[]{"recent_view"}, cVar);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.RecentViewDao
    public final java.lang.Object c(com.jorden.karto.setrisokegl.data.db.RecentViewEntity recentViewEntity, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2934a, continuation, new f.a(2, this, recentViewEntity), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }
}
