package com.jorden.karto.setrisokegl.data.remote;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.remote.SplashSocketClient", f = "SplashSocketClient.kt", l = {58}, m = "exchange")
/* loaded from: classes.dex */
final class SplashSocketClient$exchange$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public java.lang.Object e;

    /* renamed from: f, reason: collision with root package name */
    public okhttp3.internal.ws.RealWebSocket f2967f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f2968g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.remote.SplashSocketClient f2969h;
    public int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashSocketClient$exchange$1(com.jorden.karto.setrisokegl.data.remote.SplashSocketClient splashSocketClient, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.f2969h = splashSocketClient;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) {
        this.f2968g = obj;
        this.i |= Integer.MIN_VALUE;
        return this.f2969h.a(null, this);
    }
}
