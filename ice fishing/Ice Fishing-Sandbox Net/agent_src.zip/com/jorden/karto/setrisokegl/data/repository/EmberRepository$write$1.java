package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository", f = "EmberRepository.kt", l = {94, 95}, m = "write")
/* loaded from: classes.dex */
final class EmberRepository$write$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public com.jorden.karto.setrisokegl.data.repository.EmberRepository e;

    /* renamed from: f, reason: collision with root package name */
    public java.lang.String f2991f;

    /* renamed from: g, reason: collision with root package name */
    public kotlin.jvm.functions.Function1 f2992g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f2993h;
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository i;

    /* renamed from: j, reason: collision with root package name */
    public int f2994j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EmberRepository$write$1(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository, kotlin.coroutines.Continuation continuation) {
        super(continuation);
        this.i = emberRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) {
        this.f2993h = obj;
        this.f2994j |= Integer.MIN_VALUE;
        return this.i.f(null, null, this);
    }
}
