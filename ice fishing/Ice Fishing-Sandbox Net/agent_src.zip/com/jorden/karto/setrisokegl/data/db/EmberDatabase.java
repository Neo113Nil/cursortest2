package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Database
@kotlin.Metadata
/* loaded from: classes.dex */
public abstract class EmberDatabase extends androidx.room.RoomDatabase {

    @kotlin.Metadata
    public static final class Companion {
    }

    public abstract com.jorden.karto.setrisokegl.data.db.CounterDao j();

    public abstract com.jorden.karto.setrisokegl.data.db.MoveStateDao k();

    public abstract com.jorden.karto.setrisokegl.data.db.RecentViewDao l();

    public abstract com.jorden.karto.setrisokegl.data.db.SplashCacheDao m();
}
