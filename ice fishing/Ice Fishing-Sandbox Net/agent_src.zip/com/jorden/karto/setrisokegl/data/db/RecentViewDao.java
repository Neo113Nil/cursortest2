package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Dao
@kotlin.Metadata
/* loaded from: classes.dex */
public interface RecentViewDao {
    java.lang.Object a(kotlin.coroutines.Continuation continuation);

    androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b();

    java.lang.Object c(com.jorden.karto.setrisokegl.data.db.RecentViewEntity recentViewEntity, kotlin.coroutines.Continuation continuation);
}
