package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1", f = "SplashRepository.kt", l = {40}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashRepository$buildFrame$2$advertisingDeferred$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3000f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3001g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1$1", f = "SplashRepository.kt", l = {}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.String>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3002f;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3002f = splashRepository;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1.AnonymousClass1(this.f3002f, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            java.lang.Object objA;
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            kotlin.ResultKt.b(obj);
            java.lang.Object obj2 = "00000000-0000-0000-0000-000000000000";
            try {
                objA = com.google.android.gms.ads.identifier.AdvertisingIdClient.a(this.f3002f.f2996a).f2009a;
                if (objA == null) {
                    objA = "00000000-0000-0000-0000-000000000000";
                }
            } catch (java.lang.Throwable th) {
                objA = kotlin.ResultKt.a(th);
            }
            java.lang.Throwable thA = kotlin.Result.a(objA);
            if (thA == null) {
                obj2 = objA;
            } else if (thA instanceof java.util.concurrent.CancellationException) {
                throw thA;
            }
            return (java.lang.String) obj2;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashRepository$buildFrame$2$advertisingDeferred$1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3001g = splashRepository;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1(this.f3001g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3000f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            int i2 = kotlin.time.Duration.d;
            long jC = kotlin.time.DurationKt.c(5000, kotlin.time.DurationUnit.e);
            com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2$advertisingDeferred$1.AnonymousClass1(this.f3001g, null);
            this.f3000f = 1;
            obj = kotlinx.coroutines.TimeoutKt.c(kotlinx.coroutines.DelayKt.c(jC), anonymousClass1, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        java.lang.String str = (java.lang.String) obj;
        return str == null ? "00000000-0000-0000-0000-000000000000" : str;
    }
}
