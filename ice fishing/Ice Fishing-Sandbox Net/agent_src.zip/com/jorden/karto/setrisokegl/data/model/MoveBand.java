package com.jorden.karto.setrisokegl.data.model;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveBand {
    public static final com.jorden.karto.setrisokegl.data.model.MoveBand c;
    public static final com.jorden.karto.setrisokegl.data.model.MoveBand d;
    public static final com.jorden.karto.setrisokegl.data.model.MoveBand e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ com.jorden.karto.setrisokegl.data.model.MoveBand[] f2957f;

    /* renamed from: g, reason: collision with root package name */
    public static final /* synthetic */ kotlin.enums.EnumEntries f2958g;
    public final int b;

    static {
        com.jorden.karto.setrisokegl.data.model.MoveBand moveBand = new com.jorden.karto.setrisokegl.data.model.MoveBand("EASY_GLOW", 0, com.jorden.karto.setrisokegl.R.string.band_easy_glow);
        c = moveBand;
        com.jorden.karto.setrisokegl.data.model.MoveBand moveBand2 = new com.jorden.karto.setrisokegl.data.model.MoveBand("STEADY_BURN", 1, com.jorden.karto.setrisokegl.R.string.band_steady_burn);
        d = moveBand2;
        com.jorden.karto.setrisokegl.data.model.MoveBand moveBand3 = new com.jorden.karto.setrisokegl.data.model.MoveBand("FULL_BLAZE", 2, com.jorden.karto.setrisokegl.R.string.band_full_blaze);
        e = moveBand3;
        com.jorden.karto.setrisokegl.data.model.MoveBand[] moveBandArr = {moveBand, moveBand2, moveBand3};
        f2957f = moveBandArr;
        f2958g = kotlin.enums.EnumEntriesKt.a(moveBandArr);
    }

    public MoveBand(java.lang.String str, int i, int i2) {
        this.b = i2;
    }

    public static com.jorden.karto.setrisokegl.data.model.MoveBand valueOf(java.lang.String str) {
        return (com.jorden.karto.setrisokegl.data.model.MoveBand) java.lang.Enum.valueOf(com.jorden.karto.setrisokegl.data.model.MoveBand.class, str);
    }

    public static com.jorden.karto.setrisokegl.data.model.MoveBand[] values() {
        return (com.jorden.karto.setrisokegl.data.model.MoveBand[]) f2957f.clone();
    }
}
