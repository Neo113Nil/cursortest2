package com.jorden.karto.setrisokegl.data.model;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class Badge {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.model.BadgeKind f2951a;
    public final int b;

    public Badge(com.jorden.karto.setrisokegl.data.model.BadgeKind badgeKind, int i) {
        this.f2951a = badgeKind;
        this.b = i;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.model.Badge)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.model.Badge badge = (com.jorden.karto.setrisokegl.data.model.Badge) obj;
        return this.f2951a == badge.f2951a && this.b == badge.b;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.b) + (this.f2951a.hashCode() * 31);
    }

    public final java.lang.String toString() {
        return "Badge(kind=" + this.f2951a + ", progress=" + this.b + ")";
    }
}
