package com.jorden.karto.setrisokegl.data.model;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveState {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f2960a;
    public final boolean b;
    public final boolean c;
    public final java.lang.Long d;
    public final java.lang.String e;

    public MoveState(java.lang.String str, boolean z, boolean z2, java.lang.Long l, java.lang.String str2) {
        this.f2960a = str;
        this.b = z;
        this.c = z2;
        this.d = l;
        this.e = str2;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.model.MoveState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.model.MoveState moveState = (com.jorden.karto.setrisokegl.data.model.MoveState) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2960a, moveState.f2960a) && this.b == moveState.b && this.c == moveState.c && kotlin.jvm.internal.Intrinsics.a(this.d, moveState.d) && kotlin.jvm.internal.Intrinsics.a(this.e, moveState.e);
    }

    public final int hashCode() {
        int iHashCode = (java.lang.Boolean.hashCode(this.c) + ((java.lang.Boolean.hashCode(this.b) + (this.f2960a.hashCode() * 31)) * 31)) * 31;
        java.lang.Long l = this.d;
        return this.e.hashCode() + ((iHashCode + (l == null ? 0 : l.hashCode())) * 31);
    }

    public final java.lang.String toString() {
        java.lang.StringBuilder sb = new java.lang.StringBuilder("MoveState(moveId=");
        sb.append(this.f2960a);
        sb.append(", kept=");
        sb.append(this.b);
        sb.append(", tried=");
        sb.append(this.c);
        sb.append(", lastGoEpochDay=");
        sb.append(this.d);
        sb.append(", recap=");
        return androidx.activity.h.j(sb, this.e, ")");
    }
}
