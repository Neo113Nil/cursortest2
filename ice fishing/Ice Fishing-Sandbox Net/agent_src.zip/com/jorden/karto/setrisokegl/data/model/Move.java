package com.jorden.karto.setrisokegl.data.model;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class Move {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f2953a;
    public final int b;
    public final java.lang.String c;
    public final com.jorden.karto.setrisokegl.data.model.MoveTag d;
    public final float e;

    /* renamed from: f, reason: collision with root package name */
    public final int f2954f;

    /* renamed from: g, reason: collision with root package name */
    public final int f2955g;

    /* renamed from: h, reason: collision with root package name */
    public final int f2956h;
    public final int i;

    @kotlin.Metadata
    public static final class Companion {
    }

    public Move(java.lang.String str, int i, java.lang.String str2, com.jorden.karto.setrisokegl.data.model.MoveTag moveTag, float f2, int i2, int i3, int i4, int i5) {
        this.f2953a = str;
        this.b = i;
        this.c = str2;
        this.d = moveTag;
        this.e = f2;
        this.f2954f = i2;
        this.f2955g = i3;
        this.f2956h = i4;
        this.i = i5;
    }

    public final com.jorden.karto.setrisokegl.data.model.MoveBand a() {
        float f2 = this.e;
        return f2 < 3.0f ? com.jorden.karto.setrisokegl.data.model.MoveBand.c : f2 < 6.0f ? com.jorden.karto.setrisokegl.data.model.MoveBand.d : com.jorden.karto.setrisokegl.data.model.MoveBand.e;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.model.Move)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
        return this.f2953a.equals(move.f2953a) && this.b == move.b && this.c.equals(move.c) && this.d == move.d && java.lang.Float.compare(this.e, move.e) == 0 && this.f2954f == move.f2954f && this.f2955g == move.f2955g && this.f2956h == move.f2956h && this.i == move.i;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.i) + ((java.lang.Integer.hashCode(this.f2956h) + ((java.lang.Integer.hashCode(this.f2955g) + ((java.lang.Integer.hashCode(this.f2954f) + ((java.lang.Float.hashCode(this.e) + ((this.d.hashCode() + ((this.c.hashCode() + ((java.lang.Integer.hashCode(this.b) + (this.f2953a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "Move(id=" + this.f2953a + ", nameRes=" + this.b + ", emoji=" + this.c + ", tag=" + this.d + ", met=" + this.e + ", kcalPerHalfHour=" + this.f2954f + ", primeMoverRes=" + this.f2955g + ", kitRes=" + this.f2956h + ", paceRes=" + this.i + ")";
    }
}
