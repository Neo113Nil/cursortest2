package com.jorden.karto.setrisokegl.data.model;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveEntry {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.model.Move f2959a;
    public final com.jorden.karto.setrisokegl.data.model.MoveState b;

    public MoveEntry(com.jorden.karto.setrisokegl.data.model.Move move, com.jorden.karto.setrisokegl.data.model.MoveState moveState) {
        this.f2959a = move;
        this.b = moveState;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.model.MoveEntry)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = (com.jorden.karto.setrisokegl.data.model.MoveEntry) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2959a, moveEntry.f2959a) && kotlin.jvm.internal.Intrinsics.a(this.b, moveEntry.b);
    }

    public final int hashCode() {
        return this.b.hashCode() + (this.f2959a.hashCode() * 31);
    }

    public final java.lang.String toString() {
        return "MoveEntry(move=" + this.f2959a + ", state=" + this.b + ")";
    }
}
