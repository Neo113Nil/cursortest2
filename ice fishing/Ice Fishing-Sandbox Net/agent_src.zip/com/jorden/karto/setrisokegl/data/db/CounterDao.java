package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Dao
@kotlin.Metadata
/* loaded from: classes.dex */
public interface CounterDao {
    java.lang.Object a(kotlin.coroutines.Continuation continuation);

    androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b();

    java.lang.Object c(kotlin.coroutines.Continuation continuation);

    java.lang.Object d(com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity, kotlin.coroutines.Continuation continuation);
}
