package com.jorden.karto.setrisokegl.data.model;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveTag {
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag.Companion d;
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag e;

    /* renamed from: f, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag f2961f;

    /* renamed from: g, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag f2962g;

    /* renamed from: h, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag f2963h;
    public static final com.jorden.karto.setrisokegl.data.model.MoveTag i;

    /* renamed from: j, reason: collision with root package name */
    public static final /* synthetic */ com.jorden.karto.setrisokegl.data.model.MoveTag[] f2964j;
    public static final /* synthetic */ kotlin.enums.EnumEntries k;
    public final java.lang.String b;
    public final int c;

    @kotlin.Metadata
    @kotlin.jvm.internal.SourceDebugExtension
    public static final class Companion {
    }

    static {
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag = new com.jorden.karto.setrisokegl.data.model.MoveTag(0, com.jorden.karto.setrisokegl.R.string.tag_household, "HOUSEHOLD", "household");
        e = moveTag;
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag2 = new com.jorden.karto.setrisokegl.data.model.MoveTag(1, com.jorden.karto.setrisokegl.R.string.tag_roadwork, "ROADWORK", "roadwork");
        f2961f = moveTag2;
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag3 = new com.jorden.karto.setrisokegl.data.model.MoveTag(2, com.jorden.karto.setrisokegl.R.string.tag_water, "WATER", "water");
        f2962g = moveTag3;
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag4 = new com.jorden.karto.setrisokegl.data.model.MoveTag(3, com.jorden.karto.setrisokegl.R.string.tag_studio, "STUDIO", "studio");
        f2963h = moveTag4;
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag5 = new com.jorden.karto.setrisokegl.data.model.MoveTag(4, com.jorden.karto.setrisokegl.R.string.tag_yard, "YARD", "yard");
        i = moveTag5;
        com.jorden.karto.setrisokegl.data.model.MoveTag[] moveTagArr = {moveTag, moveTag2, moveTag3, moveTag4, moveTag5};
        f2964j = moveTagArr;
        k = kotlin.enums.EnumEntriesKt.a(moveTagArr);
        d = new com.jorden.karto.setrisokegl.data.model.MoveTag.Companion();
    }

    public MoveTag(int i2, int i3, java.lang.String str, java.lang.String str2) {
        this.b = str2;
        this.c = i3;
    }

    public static com.jorden.karto.setrisokegl.data.model.MoveTag valueOf(java.lang.String str) {
        return (com.jorden.karto.setrisokegl.data.model.MoveTag) java.lang.Enum.valueOf(com.jorden.karto.setrisokegl.data.model.MoveTag.class, str);
    }

    public static com.jorden.karto.setrisokegl.data.model.MoveTag[] values() {
        return (com.jorden.karto.setrisokegl.data.model.MoveTag[]) f2964j.clone();
    }
}
