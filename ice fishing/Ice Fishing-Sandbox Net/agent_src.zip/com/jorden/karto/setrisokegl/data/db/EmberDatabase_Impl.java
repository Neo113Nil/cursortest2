package com.jorden.karto.setrisokegl.data.db;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EmberDatabase_Impl extends com.jorden.karto.setrisokegl.data.db.EmberDatabase {

    /* renamed from: j, reason: collision with root package name */
    public final kotlin.Lazy f2930j;
    public final kotlin.Lazy k;
    public final kotlin.Lazy l;

    /* renamed from: m, reason: collision with root package name */
    public final kotlin.Lazy f2931m;

    public EmberDatabase_Impl() {
        final int i = 0;
        this.f2930j = kotlin.LazyKt.b(new kotlin.jvm.functions.Function0(this) { // from class: f.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl c;

            {
                this.c = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                switch (i) {
                    case 0:
                        return new com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl(this.c);
                    case 1:
                        return new com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl(this.c);
                    case 2:
                        return new com.jorden.karto.setrisokegl.data.db.CounterDao_Impl(this.c);
                    default:
                        return new com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl(this.c);
                }
            }
        });
        final int i2 = 1;
        this.k = kotlin.LazyKt.b(new kotlin.jvm.functions.Function0(this) { // from class: f.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl c;

            {
                this.c = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                switch (i2) {
                    case 0:
                        return new com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl(this.c);
                    case 1:
                        return new com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl(this.c);
                    case 2:
                        return new com.jorden.karto.setrisokegl.data.db.CounterDao_Impl(this.c);
                    default:
                        return new com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl(this.c);
                }
            }
        });
        final int i3 = 2;
        this.l = kotlin.LazyKt.b(new kotlin.jvm.functions.Function0(this) { // from class: f.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl c;

            {
                this.c = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                switch (i3) {
                    case 0:
                        return new com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl(this.c);
                    case 1:
                        return new com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl(this.c);
                    case 2:
                        return new com.jorden.karto.setrisokegl.data.db.CounterDao_Impl(this.c);
                    default:
                        return new com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl(this.c);
                }
            }
        });
        final int i4 = 3;
        this.f2931m = kotlin.LazyKt.b(new kotlin.jvm.functions.Function0(this) { // from class: f.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl c;

            {
                this.c = this;
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                switch (i4) {
                    case 0:
                        return new com.jorden.karto.setrisokegl.data.db.MoveStateDao_Impl(this.c);
                    case 1:
                        return new com.jorden.karto.setrisokegl.data.db.RecentViewDao_Impl(this.c);
                    case 2:
                        return new com.jorden.karto.setrisokegl.data.db.CounterDao_Impl(this.c);
                    default:
                        return new com.jorden.karto.setrisokegl.data.db.SplashCacheDao_Impl(this.c);
                }
            }
        });
    }

    @Override // androidx.room.RoomDatabase
    public final java.util.List a(java.util.LinkedHashMap linkedHashMap) {
        return new java.util.ArrayList();
    }

    @Override // androidx.room.RoomDatabase
    public final androidx.room.InvalidationTracker b() {
        return new androidx.room.InvalidationTracker(this, new java.util.LinkedHashMap(), new java.util.LinkedHashMap(), "move_state", "recent_view", "counter", "splash_cache");
    }

    @Override // androidx.room.RoomDatabase
    public final androidx.room.RoomOpenDelegateMarker c() {
        return new androidx.room.RoomOpenDelegate() { // from class: com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl$createOpenDelegate$_openDelegate$1
            {
                super(1, "e2015695f18715856d101ddd0aa4d62a", "8130a5d2face6525eb7d5ce5f798efd3");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void a(androidx.sqlite.SQLiteConnection connection) throws java.lang.Exception {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
                androidx.sqlite.SQLite.a(connection, "CREATE TABLE IF NOT EXISTS `move_state` (`moveId` TEXT NOT NULL, `kept` INTEGER NOT NULL, `completed` INTEGER NOT NULL, `lastGoEpochDay` INTEGER, `impression` TEXT NOT NULL, PRIMARY KEY(`moveId`))");
                androidx.sqlite.SQLite.a(connection, "CREATE TABLE IF NOT EXISTS `recent_view` (`moveId` TEXT NOT NULL, `lastViewed` INTEGER NOT NULL, PRIMARY KEY(`moveId`))");
                androidx.sqlite.SQLite.a(connection, "CREATE TABLE IF NOT EXISTS `counter` (`counterKey` TEXT NOT NULL, `amount` INTEGER NOT NULL, PRIMARY KEY(`counterKey`))");
                androidx.sqlite.SQLite.a(connection, "CREATE TABLE IF NOT EXISTS `splash_cache` (`id` INTEGER NOT NULL, `activityName` TEXT NOT NULL, `metabolicValue` REAL NOT NULL, `durationMinutes` INTEGER NOT NULL, `kilocaloriesBurned` INTEGER NOT NULL, `isPrescribed` INTEGER NOT NULL, `muscleGroup` TEXT NOT NULL, `effortLevel` TEXT NOT NULL, `isCompleted` INTEGER NOT NULL, `badgeCount` INTEGER NOT NULL, `userWeightKg` INTEGER NOT NULL, PRIMARY KEY(`id`))");
                androidx.sqlite.SQLite.a(connection, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
                androidx.sqlite.SQLite.a(connection, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'e2015695f18715856d101ddd0aa4d62a')");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void b(androidx.sqlite.SQLiteConnection connection) throws java.lang.Exception {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
                androidx.sqlite.SQLite.a(connection, "DROP TABLE IF EXISTS `move_state`");
                androidx.sqlite.SQLite.a(connection, "DROP TABLE IF EXISTS `recent_view`");
                androidx.sqlite.SQLite.a(connection, "DROP TABLE IF EXISTS `counter`");
                androidx.sqlite.SQLite.a(connection, "DROP TABLE IF EXISTS `splash_cache`");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void c(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void d(androidx.sqlite.SQLiteConnection connection) throws java.lang.Exception {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
                com.jorden.karto.setrisokegl.data.db.EmberDatabase_Impl emberDatabase_Impl = this.d;
                emberDatabase_Impl.getClass();
                androidx.room.InvalidationTracker invalidationTrackerD = emberDatabase_Impl.d();
                androidx.room.TriggerBasedInvalidationTracker triggerBasedInvalidationTracker = invalidationTrackerD.c;
                triggerBasedInvalidationTracker.getClass();
                androidx.sqlite.SQLiteStatement sQLiteStatementL0 = connection.l0("PRAGMA query_only");
                try {
                    sQLiteStatementL0.U();
                    boolean zY = sQLiteStatementL0.y();
                    kotlin.jdk7.AutoCloseableKt.a(sQLiteStatementL0, null);
                    if (!zY) {
                        androidx.sqlite.SQLite.a(connection, "PRAGMA temp_store = MEMORY");
                        androidx.sqlite.SQLite.a(connection, "PRAGMA recursive_triggers = 1");
                        androidx.sqlite.SQLite.a(connection, "DROP TABLE IF EXISTS room_table_modification_log");
                        if (triggerBasedInvalidationTracker.d) {
                            androidx.sqlite.SQLite.a(connection, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
                        } else {
                            androidx.sqlite.SQLite.a(connection, kotlin.text.StringsKt.u("CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)", "TEMP", ""));
                        }
                        androidx.room.ObservedTableStates observedTableStates = triggerBasedInvalidationTracker.f1620h;
                        java.util.concurrent.locks.ReentrantLock reentrantLock = observedTableStates.f1584a;
                        reentrantLock.lock();
                        try {
                            observedTableStates.d = true;
                        } finally {
                            reentrantLock.unlock();
                        }
                    }
                    synchronized (invalidationTrackerD.f1565j) {
                        androidx.room.MultiInstanceInvalidationClient multiInstanceInvalidationClient = invalidationTrackerD.i;
                        if (multiInstanceInvalidationClient != null) {
                            android.content.Intent intent = invalidationTrackerD.f1564h;
                            if (intent == null) {
                                throw new java.lang.IllegalStateException("Required value was null.");
                            }
                            if (multiInstanceInvalidationClient.e.compareAndSet(true, false)) {
                                multiInstanceInvalidationClient.c.bindService(intent, multiInstanceInvalidationClient.k, 1);
                                androidx.room.InvalidationTracker invalidationTracker = multiInstanceInvalidationClient.b;
                                androidx.room.MultiInstanceInvalidationClient$observer$1 observer = multiInstanceInvalidationClient.i;
                                kotlin.jvm.internal.Intrinsics.e(observer, "observer");
                                invalidationTracker.a(observer);
                            }
                        }
                    }
                } finally {
                }
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void e(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
            }

            @Override // androidx.room.RoomOpenDelegate
            public final void f(androidx.sqlite.SQLiteConnection connection) throws java.lang.Exception {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
                kotlin.collections.builders.ListBuilder listBuilder = new kotlin.collections.builders.ListBuilder(10);
                androidx.sqlite.SQLiteStatement sQLiteStatementL0 = connection.l0("SELECT name FROM sqlite_master WHERE type = 'trigger'");
                while (sQLiteStatementL0.U()) {
                    try {
                        listBuilder.add(sQLiteStatementL0.r(0));
                    } finally {
                    }
                }
                kotlin.jdk7.AutoCloseableKt.a(sQLiteStatementL0, null);
                java.util.ListIterator listIterator = kotlin.collections.CollectionsKt.l(listBuilder).listIterator(0);
                while (listIterator.hasNext()) {
                    java.lang.String str = (java.lang.String) listIterator.next();
                    if (kotlin.text.StringsKt.x(str, "room_fts_content_sync_", false)) {
                        androidx.sqlite.SQLite.a(connection, "DROP TRIGGER IF EXISTS ".concat(str));
                    }
                }
            }

            @Override // androidx.room.RoomOpenDelegate
            public final androidx.room.RoomOpenDelegate.ValidationResult g(androidx.sqlite.SQLiteConnection connection) throws java.lang.Exception {
                kotlin.jvm.internal.Intrinsics.e(connection, "connection");
                java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
                linkedHashMap.put("moveId", new androidx.room.util.TableInfo.Column("moveId", "TEXT", true, 1, null, 1));
                linkedHashMap.put("kept", new androidx.room.util.TableInfo.Column("kept", "INTEGER", true, 0, null, 1));
                linkedHashMap.put("completed", new androidx.room.util.TableInfo.Column("completed", "INTEGER", true, 0, null, 1));
                linkedHashMap.put("lastGoEpochDay", new androidx.room.util.TableInfo.Column("lastGoEpochDay", "INTEGER", false, 0, null, 1));
                linkedHashMap.put("impression", new androidx.room.util.TableInfo.Column("impression", "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo = new androidx.room.util.TableInfo("move_state", linkedHashMap, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfoA = androidx.room.util.TableInfo.Companion.a(connection, "move_state");
                if (!tableInfo.equals(tableInfoA)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult("move_state(com.jorden.karto.setrisokegl.data.db.MoveStateEntity).\n Expected:\n" + tableInfo + "\n Found:\n" + tableInfoA, false);
                }
                java.util.LinkedHashMap linkedHashMap2 = new java.util.LinkedHashMap();
                linkedHashMap2.put("moveId", new androidx.room.util.TableInfo.Column("moveId", "TEXT", true, 1, null, 1));
                linkedHashMap2.put("lastViewed", new androidx.room.util.TableInfo.Column("lastViewed", "INTEGER", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo2 = new androidx.room.util.TableInfo("recent_view", linkedHashMap2, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfoA2 = androidx.room.util.TableInfo.Companion.a(connection, "recent_view");
                if (!tableInfo2.equals(tableInfoA2)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult("recent_view(com.jorden.karto.setrisokegl.data.db.RecentViewEntity).\n Expected:\n" + tableInfo2 + "\n Found:\n" + tableInfoA2, false);
                }
                java.util.LinkedHashMap linkedHashMap3 = new java.util.LinkedHashMap();
                linkedHashMap3.put("counterKey", new androidx.room.util.TableInfo.Column("counterKey", "TEXT", true, 1, null, 1));
                linkedHashMap3.put("amount", new androidx.room.util.TableInfo.Column("amount", "INTEGER", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo3 = new androidx.room.util.TableInfo("counter", linkedHashMap3, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfoA3 = androidx.room.util.TableInfo.Companion.a(connection, "counter");
                if (!tableInfo3.equals(tableInfoA3)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult("counter(com.jorden.karto.setrisokegl.data.db.CounterEntity).\n Expected:\n" + tableInfo3 + "\n Found:\n" + tableInfoA3, false);
                }
                java.util.LinkedHashMap linkedHashMap4 = new java.util.LinkedHashMap();
                linkedHashMap4.put("id", new androidx.room.util.TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap4.put("activityName", new androidx.room.util.TableInfo.Column("activityName", "TEXT", true, 0, null, 1));
                linkedHashMap4.put("metabolicValue", new androidx.room.util.TableInfo.Column("metabolicValue", "REAL", true, 0, null, 1));
                linkedHashMap4.put("durationMinutes", new androidx.room.util.TableInfo.Column("durationMinutes", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("kilocaloriesBurned", new androidx.room.util.TableInfo.Column("kilocaloriesBurned", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("isPrescribed", new androidx.room.util.TableInfo.Column("isPrescribed", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("muscleGroup", new androidx.room.util.TableInfo.Column("muscleGroup", "TEXT", true, 0, null, 1));
                linkedHashMap4.put("effortLevel", new androidx.room.util.TableInfo.Column("effortLevel", "TEXT", true, 0, null, 1));
                linkedHashMap4.put("isCompleted", new androidx.room.util.TableInfo.Column("isCompleted", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("badgeCount", new androidx.room.util.TableInfo.Column("badgeCount", "INTEGER", true, 0, null, 1));
                linkedHashMap4.put("userWeightKg", new androidx.room.util.TableInfo.Column("userWeightKg", "INTEGER", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo4 = new androidx.room.util.TableInfo("splash_cache", linkedHashMap4, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfoA4 = androidx.room.util.TableInfo.Companion.a(connection, "splash_cache");
                if (tableInfo4.equals(tableInfoA4)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult(null, true);
                }
                return new androidx.room.RoomOpenDelegate.ValidationResult("splash_cache(com.jorden.karto.setrisokegl.data.db.SplashCacheEntity).\n Expected:\n" + tableInfo4 + "\n Found:\n" + tableInfoA4, false);
            }
        };
    }

    @Override // androidx.room.RoomDatabase
    public final java.util.Set e() {
        return new java.util.LinkedHashSet();
    }

    @Override // androidx.room.RoomDatabase
    public final java.util.LinkedHashMap f() {
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
        kotlin.jvm.internal.ClassReference classReferenceA = kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.data.db.MoveStateDao.class);
        kotlin.collections.EmptyList emptyList = kotlin.collections.EmptyList.b;
        linkedHashMap.put(classReferenceA, emptyList);
        linkedHashMap.put(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.data.db.RecentViewDao.class), emptyList);
        linkedHashMap.put(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.data.db.CounterDao.class), emptyList);
        linkedHashMap.put(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.data.db.SplashCacheDao.class), emptyList);
        return linkedHashMap;
    }

    @Override // com.jorden.karto.setrisokegl.data.db.EmberDatabase
    public final com.jorden.karto.setrisokegl.data.db.CounterDao j() {
        return (com.jorden.karto.setrisokegl.data.db.CounterDao) this.l.getValue();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.EmberDatabase
    public final com.jorden.karto.setrisokegl.data.db.MoveStateDao k() {
        return (com.jorden.karto.setrisokegl.data.db.MoveStateDao) this.f2930j.getValue();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.EmberDatabase
    public final com.jorden.karto.setrisokegl.data.db.RecentViewDao l() {
        return (com.jorden.karto.setrisokegl.data.db.RecentViewDao) this.k.getValue();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.EmberDatabase
    public final com.jorden.karto.setrisokegl.data.db.SplashCacheDao m() {
        return (com.jorden.karto.setrisokegl.data.db.SplashCacheDao) this.f2931m.getValue();
    }
}
