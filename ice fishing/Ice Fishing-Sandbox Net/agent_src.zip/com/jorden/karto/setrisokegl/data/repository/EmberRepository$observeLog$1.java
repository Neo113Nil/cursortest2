package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeLog$1", f = "EmberRepository.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EmberRepository$observeLog$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function4<java.util.List<? extends com.jorden.karto.setrisokegl.data.model.MoveEntry>, java.util.List<? extends com.jorden.karto.setrisokegl.data.model.Move>, java.lang.Integer, kotlin.coroutines.Continuation<? super com.jorden.karto.setrisokegl.data.repository.LogSnapshot>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ java.util.List f2988f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ java.util.List f2989g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ int f2990h;

    @Override // kotlin.jvm.functions.Function4
    public final java.lang.Object i(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
        int iIntValue = ((java.lang.Number) obj3).intValue();
        com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeLog$1 emberRepository$observeLog$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeLog$1(4, (kotlin.coroutines.Continuation) obj4);
        emberRepository$observeLog$1.f2988f = (java.util.List) obj;
        emberRepository$observeLog$1.f2989g = (java.util.List) obj2;
        emberRepository$observeLog$1.f2990h = iIntValue;
        return emberRepository$observeLog$1.p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        kotlin.ResultKt.b(obj);
        return new com.jorden.karto.setrisokegl.data.repository.LogSnapshot(this.f2988f, this.f2989g, this.f2990h);
    }
}
