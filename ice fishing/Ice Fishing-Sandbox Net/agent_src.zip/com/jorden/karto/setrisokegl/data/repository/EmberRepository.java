package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class EmberRepository {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.db.MoveStateDao f2973a;
    public final com.jorden.karto.setrisokegl.data.db.RecentViewDao b;
    public final com.jorden.karto.setrisokegl.data.db.CounterDao c;
    public final java.util.List d = com.jorden.karto.setrisokegl.data.seed.MoveSeed.f3016a;

    public EmberRepository(com.jorden.karto.setrisokegl.data.db.MoveStateDao moveStateDao, com.jorden.karto.setrisokegl.data.db.RecentViewDao recentViewDao, com.jorden.karto.setrisokegl.data.db.CounterDao counterDao) {
        this.f2973a = moveStateDao;
        this.b = recentViewDao;
        this.c = counterDao;
    }

    public static final com.jorden.karto.setrisokegl.data.model.MoveState a(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository, com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity, java.lang.String str) {
        emberRepository.getClass();
        boolean z = moveStateEntity != null ? moveStateEntity.b : false;
        boolean z2 = moveStateEntity != null ? moveStateEntity.c : false;
        java.lang.Long l = moveStateEntity != null ? moveStateEntity.d : null;
        java.lang.String str2 = moveStateEntity != null ? moveStateEntity.e : null;
        return new com.jorden.karto.setrisokegl.data.model.MoveState(str, z, z2, l, str2 == null ? "" : str2);
    }

    public static com.jorden.karto.setrisokegl.data.model.Move d(java.lang.String id) {
        java.lang.Object next;
        kotlin.jvm.internal.Intrinsics.e(id, "id");
        java.util.Iterator it = com.jorden.karto.setrisokegl.data.seed.MoveSeed.f3016a.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((com.jorden.karto.setrisokegl.data.model.Move) next).f2953a.equals(id)) {
                break;
            }
        }
        return (com.jorden.karto.setrisokegl.data.model.Move) next;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object b(kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.repository.EmberRepository$addWeighIn$1 emberRepository$addWeighIn$1;
        com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository;
        if (continuationImpl instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$addWeighIn$1) {
            emberRepository$addWeighIn$1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$addWeighIn$1) continuationImpl;
            int i = emberRepository$addWeighIn$1.f2984h;
            if ((i & Integer.MIN_VALUE) != 0) {
                emberRepository$addWeighIn$1.f2984h = i - Integer.MIN_VALUE;
            } else {
                emberRepository$addWeighIn$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$addWeighIn$1(this, continuationImpl);
            }
        }
        java.lang.Object objC = emberRepository$addWeighIn$1.f2982f;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = emberRepository$addWeighIn$1.f2984h;
        if (i2 == 0) {
            kotlin.ResultKt.b(objC);
            emberRepository$addWeighIn$1.e = this;
            emberRepository$addWeighIn$1.f2984h = 1;
            objC = this.c.c(emberRepository$addWeighIn$1);
            if (objC == coroutineSingletons) {
                return coroutineSingletons;
            }
            emberRepository = this;
        } else {
            if (i2 != 1) {
                if (i2 != 2) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(objC);
                return kotlin.Unit.f3201a;
            }
            emberRepository = emberRepository$addWeighIn$1.e;
            kotlin.ResultKt.b(objC);
        }
        com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity = (com.jorden.karto.setrisokegl.data.db.CounterEntity) objC;
        int i3 = counterEntity != null ? counterEntity.b : 0;
        com.jorden.karto.setrisokegl.data.db.CounterDao counterDao = emberRepository.c;
        com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity2 = new com.jorden.karto.setrisokegl.data.db.CounterEntity("weigh_ins", i3 + 1);
        emberRepository$addWeighIn$1.e = null;
        emberRepository$addWeighIn$1.f2984h = 2;
        if (counterDao.d(counterEntity2, emberRepository$addWeighIn$1) == coroutineSingletons) {
            return coroutineSingletons;
        }
        return kotlin.Unit.f3201a;
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x006c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object c(kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.repository.EmberRepository$clearEverything$1 emberRepository$clearEverything$1;
        com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository;
        com.jorden.karto.setrisokegl.data.db.CounterDao counterDao;
        if (continuationImpl instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$clearEverything$1) {
            emberRepository$clearEverything$1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$clearEverything$1) continuationImpl;
            int i = emberRepository$clearEverything$1.f2987h;
            if ((i & Integer.MIN_VALUE) != 0) {
                emberRepository$clearEverything$1.f2987h = i - Integer.MIN_VALUE;
            } else {
                emberRepository$clearEverything$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$clearEverything$1(this, continuationImpl);
            }
        }
        java.lang.Object obj = emberRepository$clearEverything$1.f2985f;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = emberRepository$clearEverything$1.f2987h;
        if (i2 == 0) {
            kotlin.ResultKt.b(obj);
            emberRepository$clearEverything$1.e = this;
            emberRepository$clearEverything$1.f2987h = 1;
            if (this.f2973a.a(emberRepository$clearEverything$1) == coroutineSingletons) {
                return coroutineSingletons;
            }
            emberRepository = this;
        } else {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.b(obj);
                    return kotlin.Unit.f3201a;
                }
                emberRepository = emberRepository$clearEverything$1.e;
                kotlin.ResultKt.b(obj);
                counterDao = emberRepository.c;
                emberRepository$clearEverything$1.e = null;
                emberRepository$clearEverything$1.f2987h = 3;
                if (counterDao.a(emberRepository$clearEverything$1) == coroutineSingletons) {
                    return coroutineSingletons;
                }
                return kotlin.Unit.f3201a;
            }
            emberRepository = emberRepository$clearEverything$1.e;
            kotlin.ResultKt.b(obj);
        }
        com.jorden.karto.setrisokegl.data.db.RecentViewDao recentViewDao = emberRepository.b;
        emberRepository$clearEverything$1.e = emberRepository;
        emberRepository$clearEverything$1.f2987h = 2;
        if (recentViewDao.a(emberRepository$clearEverything$1) == coroutineSingletons) {
            return coroutineSingletons;
        }
        counterDao = emberRepository.c;
        emberRepository$clearEverything$1.e = null;
        emberRepository$clearEverything$1.f2987h = 3;
        if (counterDao.a(emberRepository$clearEverything$1) == coroutineSingletons) {
        }
        return kotlin.Unit.f3201a;
    }

    public final kotlinx.coroutines.flow.FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1 e() {
        com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1 emberRepository$observeEntries$$inlined$map$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1(this.f2973a.b(), this);
        final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1B = this.b.b();
        return new kotlinx.coroutines.flow.FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1(new kotlinx.coroutines.flow.Flow[]{emberRepository$observeEntries$$inlined$map$1, new kotlinx.coroutines.flow.Flow<java.util.List<? extends com.jorden.karto.setrisokegl.data.model.Move>>() { // from class: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1

            @kotlin.Metadata
            @kotlin.jvm.internal.SourceDebugExtension
            /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1$2, reason: invalid class name */
            public final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                public final /* synthetic */ kotlinx.coroutines.flow.FlowCollector b;
                public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository c;

                @kotlin.Metadata
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1$2", f = "EmberRepository.kt", l = {219}, m = "emit")
                /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1$2$1, reason: invalid class name */
                public final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    public /* synthetic */ java.lang.Object e;

                    /* renamed from: f, reason: collision with root package name */
                    public int f2978f;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object p(java.lang.Object obj) {
                        this.e = obj;
                        this.f2978f |= Integer.MIN_VALUE;
                        return com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2.this.c(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector, com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
                    this.b = flowCollector;
                    this.c = emberRepository;
                }

                /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object c(java.lang.Object obj, kotlin.coroutines.Continuation continuation) throws java.lang.Throwable {
                    com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    if (continuation instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        int i = anonymousClass1.f2978f;
                        if ((i & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.f2978f = i - Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                        }
                    }
                    java.lang.Object obj2 = anonymousClass1.e;
                    kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
                    int i2 = anonymousClass1.f2978f;
                    if (i2 == 0) {
                        kotlin.ResultKt.b(obj2);
                        java.util.ArrayList arrayList = new java.util.ArrayList();
                        java.util.Iterator<T> it = ((java.util.List) obj).iterator();
                        while (it.hasNext()) {
                            java.lang.String str = ((com.jorden.karto.setrisokegl.data.db.RecentViewEntity) it.next()).f2935a;
                            this.c.getClass();
                            com.jorden.karto.setrisokegl.data.model.Move moveD = com.jorden.karto.setrisokegl.data.repository.EmberRepository.d(str);
                            if (moveD != null) {
                                arrayList.add(moveD);
                            }
                        }
                        anonymousClass1.f2978f = 1;
                        if (this.b.c(arrayList, anonymousClass1) == coroutineSingletons) {
                            return coroutineSingletons;
                        }
                    } else {
                        if (i2 != 1) {
                            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        kotlin.ResultKt.b(obj2);
                    }
                    return kotlin.Unit.f3201a;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public final java.lang.Object a(kotlinx.coroutines.flow.FlowCollector flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object objA = flowUtil$createFlow$$inlined$map$1B.a(new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeRecentLinks$$inlined$map$1.AnonymousClass2(flowCollector, this), continuation);
                return objA == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objA : kotlin.Unit.f3201a;
            }
        }, new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1(this.c.b())}, new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeLog$1(4, null));
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object f(java.lang.String str, kotlin.jvm.functions.Function1 function1, kotlin.coroutines.Continuation continuation) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.repository.EmberRepository$write$1 emberRepository$write$1;
        com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository;
        if (continuation instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$write$1) {
            emberRepository$write$1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$write$1) continuation;
            int i = emberRepository$write$1.f2994j;
            if ((i & Integer.MIN_VALUE) != 0) {
                emberRepository$write$1.f2994j = i - Integer.MIN_VALUE;
            } else {
                emberRepository$write$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$write$1(this, continuation);
            }
        }
        java.lang.Object objE = emberRepository$write$1.f2993h;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = emberRepository$write$1.f2994j;
        if (i2 == 0) {
            kotlin.ResultKt.b(objE);
            emberRepository$write$1.e = this;
            emberRepository$write$1.f2991f = str;
            emberRepository$write$1.f2992g = function1;
            emberRepository$write$1.f2994j = 1;
            objE = this.f2973a.e(str, emberRepository$write$1);
            if (objE == coroutineSingletons) {
                return coroutineSingletons;
            }
            emberRepository = this;
        } else {
            if (i2 != 1) {
                if (i2 != 2) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(objE);
                return kotlin.Unit.f3201a;
            }
            function1 = emberRepository$write$1.f2992g;
            str = emberRepository$write$1.f2991f;
            emberRepository = emberRepository$write$1.e;
            kotlin.ResultKt.b(objE);
        }
        java.lang.String str2 = str;
        com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) objE;
        if (moveStateEntity == null) {
            moveStateEntity = new com.jorden.karto.setrisokegl.data.db.MoveStateEntity(str2, false, false, null, "");
        }
        com.jorden.karto.setrisokegl.data.db.MoveStateDao moveStateDao = emberRepository.f2973a;
        com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity2 = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) function1.m(moveStateEntity);
        emberRepository$write$1.e = null;
        emberRepository$write$1.f2991f = null;
        emberRepository$write$1.f2992g = null;
        emberRepository$write$1.f2994j = 2;
        if (moveStateDao.c(moveStateEntity2, emberRepository$write$1) == coroutineSingletons) {
            return coroutineSingletons;
        }
        return kotlin.Unit.f3201a;
    }
}
