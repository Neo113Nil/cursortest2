package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class ReferrerSession$awaitReferrer$2$2 implements com.android.installreferrer.api.InstallReferrerStateListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ java.util.concurrent.atomic.AtomicBoolean f2950a;
    public final /* synthetic */ kotlinx.coroutines.CancellableContinuationImpl b;
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.device.ReferrerSession c;

    public ReferrerSession$awaitReferrer$2$2(java.util.concurrent.atomic.AtomicBoolean atomicBoolean, kotlinx.coroutines.CancellableContinuationImpl cancellableContinuationImpl, com.jorden.karto.setrisokegl.data.device.ReferrerSession referrerSession) {
        this.f2950a = atomicBoolean;
        this.b = cancellableContinuationImpl;
        this.c = referrerSession;
    }

    public final void a(int i) {
        java.lang.Object objA;
        if (this.f2950a.compareAndSet(false, true)) {
            com.jorden.karto.setrisokegl.data.device.ReferrerSession referrerSession = this.c;
            if (i == 0) {
                try {
                    objA = referrerSession.f2949a.b().f2003a.getString("install_referrer");
                } catch (java.lang.Throwable th) {
                    objA = kotlin.ResultKt.a(th);
                }
                obj = (java.lang.String) (objA instanceof kotlin.Result.Failure ? null : objA);
            }
            try {
                referrerSession.f2949a.a();
            } catch (java.lang.Throwable th2) {
                kotlin.ResultKt.a(th2);
            }
            this.b.j(obj);
        }
    }
}
