package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.SplashRepository", f = "SplashRepository.kt", l = {31, 32, 34}, m = "fetchAndCache")
/* loaded from: classes.dex */
final class SplashRepository$fetchAndCache$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public java.lang.Object e;

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f3011f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.SplashRepository f3012g;

    /* renamed from: h, reason: collision with root package name */
    public int f3013h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashRepository$fetchAndCache$1(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.f3012g = splashRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) {
        this.f3011f = obj;
        this.f3013h |= Integer.MIN_VALUE;
        return this.f3012g.a(this);
    }
}
