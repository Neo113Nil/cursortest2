package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class LogSnapshot {

    /* renamed from: a, reason: collision with root package name */
    public final java.util.List f2995a;
    public final java.util.List b;
    public final int c;

    public LogSnapshot(java.util.List entries, java.util.List recentLinks, int i) {
        kotlin.jvm.internal.Intrinsics.e(entries, "entries");
        kotlin.jvm.internal.Intrinsics.e(recentLinks, "recentLinks");
        this.f2995a = entries;
        this.b = recentLinks;
        this.c = i;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.repository.LogSnapshot)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.repository.LogSnapshot logSnapshot = (com.jorden.karto.setrisokegl.data.repository.LogSnapshot) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2995a, logSnapshot.f2995a) && kotlin.jvm.internal.Intrinsics.a(this.b, logSnapshot.b) && this.c == logSnapshot.c;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.c) + ((this.b.hashCode() + (this.f2995a.hashCode() * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "LogSnapshot(entries=" + this.f2995a + ", recentLinks=" + this.b + ", weighIns=" + this.c + ")";
    }
}
