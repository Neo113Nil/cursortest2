package com.jorden.karto.setrisokegl.data.repository;

/* loaded from: classes.dex */
public final /* synthetic */ class c implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ int b;
    public final /* synthetic */ boolean c;

    public /* synthetic */ c(int i, boolean z) {
        this.b = i;
        this.c = z;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) {
        switch (this.b) {
            case 0:
                com.jorden.karto.setrisokegl.data.db.MoveStateEntity it = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
                kotlin.jvm.internal.Intrinsics.e(it, "it");
                return com.jorden.karto.setrisokegl.data.db.MoveStateEntity.a(it, this.c, false, null, null, 29);
            default:
                com.jorden.karto.setrisokegl.data.db.MoveStateEntity it2 = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
                kotlin.jvm.internal.Intrinsics.e(it2, "it");
                return com.jorden.karto.setrisokegl.data.db.MoveStateEntity.a(it2, false, this.c, null, null, 27);
        }
    }
}
