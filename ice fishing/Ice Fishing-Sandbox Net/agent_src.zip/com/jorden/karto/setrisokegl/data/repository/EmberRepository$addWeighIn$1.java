package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository", f = "EmberRepository.kt", l = {82, 83}, m = "addWeighIn")
/* loaded from: classes.dex */
final class EmberRepository$addWeighIn$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public com.jorden.karto.setrisokegl.data.repository.EmberRepository e;

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f2982f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository f2983g;

    /* renamed from: h, reason: collision with root package name */
    public int f2984h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EmberRepository$addWeighIn$1(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.f2983g = emberRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) {
        this.f2982f = obj;
        this.f2984h |= Integer.MIN_VALUE;
        return this.f2983g.b(this);
    }
}
