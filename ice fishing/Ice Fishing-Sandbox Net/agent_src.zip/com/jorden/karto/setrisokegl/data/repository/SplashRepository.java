package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashRepository {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f2996a;
    public final com.jorden.karto.setrisokegl.data.remote.SplashSocketClient b;
    public final com.jorden.karto.setrisokegl.data.device.AndroidIdCollector c;
    public final com.jorden.karto.setrisokegl.data.db.SplashCacheDao d;
    public final com.google.gson.Gson e;

    public SplashRepository(android.content.Context context, com.jorden.karto.setrisokegl.data.remote.SplashSocketClient splashSocketClient, com.jorden.karto.setrisokegl.data.device.AndroidIdCollector androidIdCollector, com.jorden.karto.setrisokegl.data.db.SplashCacheDao splashCacheDao) {
        com.google.gson.TypeAdapterFactory typeAdapterFactoryA;
        com.google.gson.TypeAdapterFactory typeAdapterFactoryA2;
        this.f2996a = context;
        this.b = splashSocketClient;
        this.c = androidIdCollector;
        this.d = splashCacheDao;
        com.google.gson.GsonBuilder gsonBuilder = new com.google.gson.GsonBuilder();
        java.util.ArrayList arrayList = gsonBuilder.e;
        int size = arrayList.size();
        java.util.ArrayList arrayList2 = gsonBuilder.f2840f;
        java.util.ArrayList arrayList3 = new java.util.ArrayList(arrayList2.size() + size + 3);
        arrayList3.addAll(arrayList);
        java.util.Collections.reverse(arrayList3);
        java.util.ArrayList arrayList4 = new java.util.ArrayList(arrayList2);
        java.util.Collections.reverse(arrayList4);
        arrayList3.addAll(arrayList4);
        boolean z = com.google.gson.internal.sql.SqlTypesSupport.f2910a;
        com.google.gson.internal.bind.DefaultDateTypeAdapter.DateType dateType = com.google.gson.internal.bind.DefaultDateTypeAdapter.DateType.b;
        int i = gsonBuilder.f2841g;
        int i2 = gsonBuilder.f2842h;
        if (i != 2 || i2 != 2) {
            com.google.gson.TypeAdapterFactory typeAdapterFactoryA3 = dateType.a(i, i2);
            if (z) {
                typeAdapterFactoryA = com.google.gson.internal.sql.SqlTypesSupport.c.a(i, i2);
                typeAdapterFactoryA2 = com.google.gson.internal.sql.SqlTypesSupport.b.a(i, i2);
            } else {
                typeAdapterFactoryA = null;
                typeAdapterFactoryA2 = null;
            }
            arrayList3.add(typeAdapterFactoryA3);
            if (z) {
                arrayList3.add(typeAdapterFactoryA);
                arrayList3.add(typeAdapterFactoryA2);
            }
        }
        this.e = new com.google.gson.Gson(gsonBuilder.f2839a, gsonBuilder.c, new java.util.HashMap(gsonBuilder.d), gsonBuilder.i, gsonBuilder.b, new java.util.ArrayList(arrayList), new java.util.ArrayList(arrayList2), arrayList3, gsonBuilder.f2843j, gsonBuilder.k, new java.util.ArrayList(gsonBuilder.l));
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0182 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0183  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.repository.SplashRepository$fetchAndCache$1 splashRepository$fetchAndCache$1;
        com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository;
        java.lang.String str;
        java.lang.Class cls;
        com.jorden.karto.setrisokegl.data.db.SplashCacheEntity splashCacheEntity;
        com.jorden.karto.setrisokegl.data.model.SplashResponse splashResponse;
        if (continuationImpl instanceof com.jorden.karto.setrisokegl.data.repository.SplashRepository$fetchAndCache$1) {
            splashRepository$fetchAndCache$1 = (com.jorden.karto.setrisokegl.data.repository.SplashRepository$fetchAndCache$1) continuationImpl;
            int i = splashRepository$fetchAndCache$1.f3013h;
            if ((i & Integer.MIN_VALUE) != 0) {
                splashRepository$fetchAndCache$1.f3013h = i - Integer.MIN_VALUE;
            } else {
                splashRepository$fetchAndCache$1 = new com.jorden.karto.setrisokegl.data.repository.SplashRepository$fetchAndCache$1(this, continuationImpl);
            }
        }
        java.lang.Object objB = splashRepository$fetchAndCache$1.f3011f;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = splashRepository$fetchAndCache$1.f3013h;
        java.lang.Object objB2 = null;
        boolean z = true;
        if (i2 == 0) {
            kotlin.ResultKt.b(objB);
            splashRepository$fetchAndCache$1.e = this;
            splashRepository$fetchAndCache$1.f3013h = 1;
            objB = kotlinx.coroutines.CoroutineScopeKt.b(new com.jorden.karto.setrisokegl.data.repository.SplashRepository$buildFrame$2(this, null), splashRepository$fetchAndCache$1);
            if (objB == coroutineSingletons) {
                return coroutineSingletons;
            }
            splashRepository = this;
        } else {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    splashResponse = (com.jorden.karto.setrisokegl.data.model.SplashResponse) splashRepository$fetchAndCache$1.e;
                    kotlin.ResultKt.b(objB);
                    kotlin.jvm.internal.Intrinsics.b(splashResponse);
                    return splashResponse;
                }
                splashRepository = (com.jorden.karto.setrisokegl.data.repository.SplashRepository) splashRepository$fetchAndCache$1.e;
                kotlin.ResultKt.b(objB);
                str = (java.lang.String) objB;
                com.google.gson.Gson gson = splashRepository.e;
                gson.getClass();
                cls = com.jorden.karto.setrisokegl.data.model.SplashResponse.class;
                com.google.gson.reflect.TypeToken typeToken = new com.google.gson.reflect.TypeToken(cls);
                if (str != null) {
                    com.google.gson.stream.JsonReader jsonReader = new com.google.gson.stream.JsonReader(new java.io.StringReader(str));
                    com.google.gson.Strictness strictness = com.google.gson.Strictness.c;
                    java.util.Objects.requireNonNull(strictness);
                    jsonReader.c = strictness;
                    jsonReader.c = com.google.gson.Strictness.b;
                    try {
                        try {
                            try {
                                jsonReader.W();
                                z = false;
                                objB2 = gson.b(typeToken).b(jsonReader);
                            } catch (java.io.IOException e) {
                                throw new com.google.gson.JsonSyntaxException(e);
                            } catch (java.lang.IllegalStateException e2) {
                                throw new com.google.gson.JsonSyntaxException(e2);
                            }
                        } catch (java.io.EOFException e3) {
                            if (!z) {
                                throw new com.google.gson.JsonSyntaxException(e3);
                            }
                        } catch (java.lang.AssertionError e4) {
                            throw new java.lang.AssertionError("AssertionError (GSON 2.11.0): " + e4.getMessage(), e4);
                        }
                        java.util.Objects.requireNonNull(strictness);
                        jsonReader.c = strictness;
                        if (objB2 != null) {
                            try {
                                if (jsonReader.W() != com.google.gson.stream.JsonToken.k) {
                                    throw new com.google.gson.JsonSyntaxException("JSON document was not fully consumed.");
                                }
                            } catch (com.google.gson.stream.MalformedJsonException e5) {
                                throw new com.google.gson.JsonSyntaxException(e5);
                            } catch (java.io.IOException e6) {
                                throw new com.google.gson.JsonIOException(e6);
                            }
                        }
                    } catch (java.lang.Throwable th) {
                        java.util.Objects.requireNonNull(strictness);
                        jsonReader.c = strictness;
                        throw th;
                    }
                }
                if (cls != java.lang.Integer.TYPE) {
                    cls = java.lang.Integer.class;
                } else if (cls == java.lang.Float.TYPE) {
                    cls = java.lang.Float.class;
                } else if (cls == java.lang.Byte.TYPE) {
                    cls = java.lang.Byte.class;
                } else if (cls == java.lang.Double.TYPE) {
                    cls = java.lang.Double.class;
                } else if (cls == java.lang.Long.TYPE) {
                    cls = java.lang.Long.class;
                } else if (cls == java.lang.Character.TYPE) {
                    cls = java.lang.Character.class;
                } else if (cls == java.lang.Boolean.TYPE) {
                    cls = java.lang.Boolean.class;
                } else if (cls == java.lang.Short.TYPE) {
                    cls = java.lang.Short.class;
                } else if (cls == java.lang.Void.TYPE) {
                    cls = java.lang.Void.class;
                }
                com.jorden.karto.setrisokegl.data.model.SplashResponse splashResponse2 = (com.jorden.karto.setrisokegl.data.model.SplashResponse) cls.cast(objB2);
                kotlin.jvm.internal.Intrinsics.b(splashResponse2);
                splashCacheEntity = new com.jorden.karto.setrisokegl.data.db.SplashCacheEntity(0, splashResponse2.a(), splashResponse2.f(), splashResponse2.c(), splashResponse2.e(), splashResponse2.j(), splashResponse2.g(), splashResponse2.d(), splashResponse2.i(), splashResponse2.b(), splashResponse2.h());
                splashRepository$fetchAndCache$1.e = splashResponse2;
                splashRepository$fetchAndCache$1.f3013h = 3;
                if (splashRepository.d.b(splashCacheEntity, splashRepository$fetchAndCache$1) != coroutineSingletons) {
                    return coroutineSingletons;
                }
                splashResponse = splashResponse2;
                kotlin.jvm.internal.Intrinsics.b(splashResponse);
                return splashResponse;
            }
            splashRepository = (com.jorden.karto.setrisokegl.data.repository.SplashRepository) splashRepository$fetchAndCache$1.e;
            kotlin.ResultKt.b(objB);
        }
        com.jorden.karto.setrisokegl.data.remote.SplashSocketClient splashSocketClient = splashRepository.b;
        splashRepository$fetchAndCache$1.e = splashRepository;
        splashRepository$fetchAndCache$1.f3013h = 2;
        objB = splashSocketClient.a((java.lang.String) objB, splashRepository$fetchAndCache$1);
        if (objB == coroutineSingletons) {
            return coroutineSingletons;
        }
        str = (java.lang.String) objB;
        com.google.gson.Gson gson2 = splashRepository.e;
        gson2.getClass();
        cls = com.jorden.karto.setrisokegl.data.model.SplashResponse.class;
        com.google.gson.reflect.TypeToken typeToken2 = new com.google.gson.reflect.TypeToken(cls);
        if (str != null) {
        }
        if (cls != java.lang.Integer.TYPE) {
        }
        com.jorden.karto.setrisokegl.data.model.SplashResponse splashResponse22 = (com.jorden.karto.setrisokegl.data.model.SplashResponse) cls.cast(objB2);
        kotlin.jvm.internal.Intrinsics.b(splashResponse22);
        splashCacheEntity = new com.jorden.karto.setrisokegl.data.db.SplashCacheEntity(0, splashResponse22.a(), splashResponse22.f(), splashResponse22.c(), splashResponse22.e(), splashResponse22.j(), splashResponse22.g(), splashResponse22.d(), splashResponse22.i(), splashResponse22.b(), splashResponse22.h());
        splashRepository$fetchAndCache$1.e = splashResponse22;
        splashRepository$fetchAndCache$1.f3013h = 3;
        if (splashRepository.d.b(splashCacheEntity, splashRepository$fetchAndCache$1) != coroutineSingletons) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object b(kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.repository.SplashRepository$getCachedPayload$1 splashRepository$getCachedPayload$1;
        if (continuationImpl instanceof com.jorden.karto.setrisokegl.data.repository.SplashRepository$getCachedPayload$1) {
            splashRepository$getCachedPayload$1 = (com.jorden.karto.setrisokegl.data.repository.SplashRepository$getCachedPayload$1) continuationImpl;
            int i = splashRepository$getCachedPayload$1.f3015g;
            if ((i & Integer.MIN_VALUE) != 0) {
                splashRepository$getCachedPayload$1.f3015g = i - Integer.MIN_VALUE;
            } else {
                splashRepository$getCachedPayload$1 = new com.jorden.karto.setrisokegl.data.repository.SplashRepository$getCachedPayload$1(this, continuationImpl);
            }
        }
        java.lang.Object objA = splashRepository$getCachedPayload$1.e;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i2 = splashRepository$getCachedPayload$1.f3015g;
        if (i2 == 0) {
            kotlin.ResultKt.b(objA);
            splashRepository$getCachedPayload$1.f3015g = 1;
            objA = this.d.a(splashRepository$getCachedPayload$1);
            if (objA == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i2 != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(objA);
        }
        com.jorden.karto.setrisokegl.data.db.SplashCacheEntity splashCacheEntity = (com.jorden.karto.setrisokegl.data.db.SplashCacheEntity) objA;
        if (splashCacheEntity == null) {
            return null;
        }
        return new com.jorden.karto.setrisokegl.data.model.SplashResponse(splashCacheEntity.b, splashCacheEntity.c, splashCacheEntity.d, splashCacheEntity.e, splashCacheEntity.f2938f, splashCacheEntity.f2939g, splashCacheEntity.f2940h, splashCacheEntity.i, splashCacheEntity.f2941j, splashCacheEntity.k);
    }
}
