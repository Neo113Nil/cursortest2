package com.jorden.karto.setrisokegl.data.repository;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class EmberRepository$observeEntries$$inlined$map$1 implements kotlinx.coroutines.flow.Flow<java.util.List<? extends com.jorden.karto.setrisokegl.data.model.MoveEntry>> {
    public final /* synthetic */ kotlinx.coroutines.flow.Flow b;
    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository c;

    @kotlin.Metadata
    @kotlin.jvm.internal.SourceDebugExtension
    /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1$2, reason: invalid class name */
    public final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
        public final /* synthetic */ kotlinx.coroutines.flow.FlowCollector b;
        public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository c;

        @kotlin.Metadata
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1$2", f = "EmberRepository.kt", l = {219}, m = "emit")
        /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1$2$1, reason: invalid class name */
        public final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
            public /* synthetic */ java.lang.Object e;

            /* renamed from: f, reason: collision with root package name */
            public int f2974f;

            public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                super(continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object p(java.lang.Object obj) {
                this.e = obj;
                this.f2974f |= Integer.MIN_VALUE;
                return com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2.this.c(null, this);
            }
        }

        public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector, com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
            this.b = flowCollector;
            this.c = emberRepository;
        }

        /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
        @Override // kotlinx.coroutines.flow.FlowCollector
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object c(java.lang.Object obj, kotlin.coroutines.Continuation continuation) throws java.lang.Throwable {
            com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
            if (continuation instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                anonymousClass1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                int i = anonymousClass1.f2974f;
                if ((i & Integer.MIN_VALUE) != 0) {
                    anonymousClass1.f2974f = i - Integer.MIN_VALUE;
                } else {
                    anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                }
            }
            java.lang.Object obj2 = anonymousClass1.e;
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i2 = anonymousClass1.f2974f;
            if (i2 == 0) {
                kotlin.ResultKt.b(obj2);
                java.util.List list = (java.util.List) obj;
                int iC = kotlin.collections.MapsKt.c(kotlin.collections.CollectionsKt.m(list, 10));
                if (iC < 16) {
                    iC = 16;
                }
                java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap(iC);
                for (T t : list) {
                    linkedHashMap.put(((com.jorden.karto.setrisokegl.data.db.MoveStateEntity) t).f2933a, t);
                }
                com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = this.c;
                java.util.List<com.jorden.karto.setrisokegl.data.model.Move> list2 = emberRepository.d;
                java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.m(list2, 10));
                for (com.jorden.karto.setrisokegl.data.model.Move move : list2) {
                    arrayList.add(new com.jorden.karto.setrisokegl.data.model.MoveEntry(move, com.jorden.karto.setrisokegl.data.repository.EmberRepository.a(emberRepository, (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) linkedHashMap.get(move.f2953a), move.f2953a)));
                }
                anonymousClass1.f2974f = 1;
                if (this.b.c(arrayList, anonymousClass1) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i2 != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj2);
            }
            return kotlin.Unit.f3201a;
        }
    }

    public EmberRepository$observeEntries$$inlined$map$1(kotlinx.coroutines.flow.Flow flow, com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.b = flow;
        this.c = emberRepository;
    }

    @Override // kotlinx.coroutines.flow.Flow
    public final java.lang.Object a(kotlinx.coroutines.flow.FlowCollector flowCollector, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objA = this.b.a(new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1.AnonymousClass2(flowCollector, this.c), continuation);
        return objA == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objA : kotlin.Unit.f3201a;
    }
}
