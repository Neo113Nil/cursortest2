package com.jorden.karto.setrisokegl.data.db;

@androidx.room.Entity
@kotlin.Metadata
/* loaded from: classes.dex */
public final class RecentViewEntity {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f2935a;
    public final long b;

    public RecentViewEntity(java.lang.String moveId, long j2) {
        kotlin.jvm.internal.Intrinsics.e(moveId, "moveId");
        this.f2935a = moveId;
        this.b = j2;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.data.db.RecentViewEntity)) {
            return false;
        }
        com.jorden.karto.setrisokegl.data.db.RecentViewEntity recentViewEntity = (com.jorden.karto.setrisokegl.data.db.RecentViewEntity) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f2935a, recentViewEntity.f2935a) && this.b == recentViewEntity.b;
    }

    public final int hashCode() {
        return java.lang.Long.hashCode(this.b) + (this.f2935a.hashCode() * 31);
    }

    public final java.lang.String toString() {
        return "RecentViewEntity(moveId=" + this.f2935a + ", lastViewed=" + this.b + ")";
    }
}
