package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class AndroidIdCollectorKt {
}
