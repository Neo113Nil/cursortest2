package com.jorden.karto.setrisokegl.data.db;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class CounterDao_Impl implements com.jorden.karto.setrisokegl.data.db.CounterDao {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.room.RoomDatabase f2928a;
    public final com.jorden.karto.setrisokegl.data.db.CounterDao_Impl.AnonymousClass1 b;

    @kotlin.Metadata
    /* renamed from: com.jorden.karto.setrisokegl.data.db.CounterDao_Impl$1, reason: invalid class name */
    public final class AnonymousClass1 extends androidx.room.EntityInsertAdapter<com.jorden.karto.setrisokegl.data.db.CounterEntity> {
        @Override // androidx.room.EntityInsertAdapter
        public final void a(androidx.sqlite.SQLiteStatement statement, java.lang.Object obj) {
            com.jorden.karto.setrisokegl.data.db.CounterEntity entity = (com.jorden.karto.setrisokegl.data.db.CounterEntity) obj;
            kotlin.jvm.internal.Intrinsics.e(statement, "statement");
            kotlin.jvm.internal.Intrinsics.e(entity, "entity");
            statement.q(entity.f2929a, 1);
            statement.a(2, entity.b);
        }

        @Override // androidx.room.EntityInsertAdapter
        public final java.lang.String b() {
            return "INSERT OR REPLACE INTO `counter` (`counterKey`,`amount`) VALUES (?,?)";
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public CounterDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.e(__db, "__db");
        this.f2928a = __db;
        this.b = new com.jorden.karto.setrisokegl.data.db.CounterDao_Impl.AnonymousClass1();
    }

    @Override // com.jorden.karto.setrisokegl.data.db.CounterDao
    public final java.lang.Object a(kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2928a, continuation, new androidx.room.c(5), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }

    @Override // com.jorden.karto.setrisokegl.data.db.CounterDao
    public final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 b() {
        androidx.room.c cVar = new androidx.room.c(7);
        return androidx.room.coroutines.FlowUtil.a(this.f2928a, new java.lang.String[]{"counter"}, cVar);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.CounterDao
    public final java.lang.Object c(kotlin.coroutines.Continuation continuation) {
        return androidx.room.util.DBUtil.b(this.f2928a, continuation, new androidx.room.c(6), true, false);
    }

    @Override // com.jorden.karto.setrisokegl.data.db.CounterDao
    public final java.lang.Object d(com.jorden.karto.setrisokegl.data.db.CounterEntity counterEntity, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objB = androidx.room.util.DBUtil.b(this.f2928a, continuation, new f.a(0, this, counterEntity), false, true);
        return objB == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objB : kotlin.Unit.f3201a;
    }
}
