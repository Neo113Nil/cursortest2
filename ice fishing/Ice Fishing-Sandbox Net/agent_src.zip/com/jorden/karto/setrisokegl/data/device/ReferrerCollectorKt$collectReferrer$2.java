package com.jorden.karto.setrisokegl.data.device;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2", f = "ReferrerCollector.kt", l = {28}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class ReferrerCollectorKt$collectReferrer$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super byte[]>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f2944f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f2945g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ android.content.Context f2946h;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2$1", f = "ReferrerCollector.kt", l = {19}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super byte[]>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f2947f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ android.content.Context f2948g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(android.content.Context context, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f2948g = context;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2.AnonymousClass1(this.f2948g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Exception {
            java.lang.String str;
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f2947f;
            boolean z = true;
            try {
                if (i == 0) {
                    kotlin.ResultKt.b(obj);
                    com.jorden.karto.setrisokegl.data.device.ReferrerSession referrerSession = new com.jorden.karto.setrisokegl.data.device.ReferrerSession(this.f2948g);
                    this.f2947f = 1;
                    obj = referrerSession.a(this);
                    if (obj == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.b(obj);
                }
                str = (java.lang.String) obj;
                z = false;
            } catch (java.lang.Exception e) {
                if (e instanceof java.util.concurrent.CancellationException) {
                    throw e;
                }
                str = null;
            }
            if (z || str == null) {
                return new byte[0];
            }
            char[] cArr = new char[str.length()];
            char[] charArray = str.toCharArray();
            kotlin.jvm.internal.Intrinsics.d(charArray, "toCharArray(...)");
            java.lang.System.arraycopy(charArray, 0, cArr, 0, charArray.length);
            byte[] bytes = new java.lang.String(cArr).getBytes(kotlin.text.Charsets.f3239a);
            kotlin.jvm.internal.Intrinsics.d(bytes, "getBytes(...)");
            return bytes;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ReferrerCollectorKt$collectReferrer$2(android.content.Context context, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f2946h = context;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2 referrerCollectorKt$collectReferrer$2 = new com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2(this.f2946h, continuation);
        referrerCollectorKt$collectReferrer$2.f2945g = obj;
        return referrerCollectorKt$collectReferrer$2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f2944f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            kotlinx.coroutines.Deferred deferredA = kotlinx.coroutines.BuildersKt.a((kotlinx.coroutines.CoroutineScope) this.f2945g, kotlinx.coroutines.Dispatchers.b, new com.jorden.karto.setrisokegl.data.device.ReferrerCollectorKt$collectReferrer$2.AnonymousClass1(this.f2946h, null), 2);
            this.f2944f = 1;
            obj = deferredA.F(this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return obj;
    }
}
