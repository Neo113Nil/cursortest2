package com.jorden.karto.setrisokegl;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EmberGauge extends android.app.Application {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f2927a = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        androidx.room.b bVar = new androidx.room.b(1, this);
        synchronized (org.koin.core.context.GlobalContext.f4281a) {
            org.koin.core.KoinApplication koinApplication = new org.koin.core.KoinApplication();
            if (org.koin.core.context.GlobalContext.b != null) {
                throw new org.koin.core.error.KoinApplicationAlreadyStartedException("A Koin Application has already been started");
            }
            org.koin.core.context.GlobalContext.b = koinApplication.f4280a;
            bVar.m(koinApplication);
            koinApplication.f4280a.a();
        }
    }
}
