package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SetCompletedUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3065a;

    public SetCompletedUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3065a = emberRepository;
    }
}
