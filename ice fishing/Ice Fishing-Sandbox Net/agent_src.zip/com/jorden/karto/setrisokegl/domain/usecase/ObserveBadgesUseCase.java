package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class ObserveBadgesUseCase {

    @kotlin.Metadata
    public /* synthetic */ class WhenMappings {
        static {
            int[] iArr = new int[com.jorden.karto.setrisokegl.data.model.BadgeKind.values().length];
            try {
                iArr[0] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr = com.jorden.karto.setrisokegl.data.model.BadgeKind.e;
                iArr[1] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr2 = com.jorden.karto.setrisokegl.data.model.BadgeKind.e;
                iArr[2] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            try {
                com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr3 = com.jorden.karto.setrisokegl.data.model.BadgeKind.e;
                iArr[3] = 4;
            } catch (java.lang.NoSuchFieldError unused4) {
            }
            try {
                com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr4 = com.jorden.karto.setrisokegl.data.model.BadgeKind.e;
                iArr[4] = 5;
            } catch (java.lang.NoSuchFieldError unused5) {
            }
            try {
                com.jorden.karto.setrisokegl.data.model.BadgeKind[] badgeKindArr5 = com.jorden.karto.setrisokegl.data.model.BadgeKind.e;
                iArr[5] = 6;
            } catch (java.lang.NoSuchFieldError unused6) {
            }
        }
    }
}
