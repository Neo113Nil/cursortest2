package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class GetCachedSplashUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.SplashRepository f3056a;

    public GetCachedSplashUseCase(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository) {
        this.f3056a = splashRepository;
    }
}
