package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class LoadSplashUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.SplashRepository f3057a;

    public LoadSplashUseCase(com.jorden.karto.setrisokegl.data.repository.SplashRepository splashRepository) {
        this.f3057a = splashRepository;
    }
}
