package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class ObserveEntryUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3059a;

    public ObserveEntryUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3059a = emberRepository;
    }
}
