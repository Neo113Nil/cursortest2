package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class ObserveLogUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3061a;

    public ObserveLogUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3061a = emberRepository;
    }
}
