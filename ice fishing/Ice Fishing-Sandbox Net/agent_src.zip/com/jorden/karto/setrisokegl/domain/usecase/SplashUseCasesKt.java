package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashUseCasesKt {
}
