package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class WeighPairUseCase {

    @kotlin.Metadata
    public interface Verdict {

        @kotlin.Metadata
        public static final class Level implements com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict {

            /* renamed from: a, reason: collision with root package name */
            public static final com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Level f3068a = new com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Level();

            public final boolean equals(java.lang.Object obj) {
                return this == obj || (obj instanceof com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Level);
            }

            public final int hashCode() {
                return 676865873;
            }

            public final java.lang.String toString() {
                return "Level";
            }
        }

        @kotlin.Metadata
        public static final class Tipped implements com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict {

            /* renamed from: a, reason: collision with root package name */
            public final com.jorden.karto.setrisokegl.data.model.Move f3069a;
            public final com.jorden.karto.setrisokegl.data.model.Move b;
            public final float c;

            public Tipped(com.jorden.karto.setrisokegl.data.model.Move move, com.jorden.karto.setrisokegl.data.model.Move move2, float f2) {
                this.f3069a = move;
                this.b = move2;
                this.c = f2;
            }

            public final boolean equals(java.lang.Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped)) {
                    return false;
                }
                com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped tipped = (com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped) obj;
                return kotlin.jvm.internal.Intrinsics.a(this.f3069a, tipped.f3069a) && kotlin.jvm.internal.Intrinsics.a(this.b, tipped.b) && java.lang.Float.compare(this.c, tipped.c) == 0;
            }

            public final int hashCode() {
                return java.lang.Float.hashCode(this.c) + ((this.b.hashCode() + (this.f3069a.hashCode() * 31)) * 31);
            }

            public final java.lang.String toString() {
                return "Tipped(heavier=" + this.f3069a + ", lighter=" + this.b + ", ratio=" + this.c + ")";
            }
        }

        @kotlin.Metadata
        public static final class Waiting implements com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict {

            /* renamed from: a, reason: collision with root package name */
            public static final com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting f3070a = new com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting();

            public final boolean equals(java.lang.Object obj) {
                return this == obj || (obj instanceof com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting);
            }

            public final int hashCode() {
                return -1320394022;
            }

            public final java.lang.String toString() {
                return "Waiting";
            }
        }
    }

    public static com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict a(com.jorden.karto.setrisokegl.data.model.Move move, com.jorden.karto.setrisokegl.data.model.Move move2) {
        if (move == null || move2 == null) {
            return com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting.f3070a;
        }
        float f2 = move.e;
        float f3 = move2.e;
        com.jorden.karto.setrisokegl.data.model.Move move3 = f2 >= f3 ? move : move2;
        if (f2 >= f3) {
            move = move2;
        }
        float f4 = move.e;
        if (f4 > 0.0f) {
            float f5 = move3.e;
            if (f5 != f4) {
                return new com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped(move3, move, f5 / f4);
            }
        }
        return com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Level.f3068a;
    }
}
