package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class FilterIndexUseCase {
}
