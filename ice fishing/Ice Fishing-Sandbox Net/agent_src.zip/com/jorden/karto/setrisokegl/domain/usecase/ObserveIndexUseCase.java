package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class ObserveIndexUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3060a;

    public ObserveIndexUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3060a = emberRepository;
    }
}
