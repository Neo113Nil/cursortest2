package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class PickHeroUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3062a;

    public PickHeroUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3062a = emberRepository;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Iterable, java.util.List] */
    public final com.jorden.karto.setrisokegl.data.model.Move a(java.lang.String str) {
        com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = this.f3062a;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        ?? r0 = emberRepository.d;
        for (java.lang.Object obj : r0) {
            if (!((com.jorden.karto.setrisokegl.data.model.Move) obj).f2953a.equals(str)) {
                arrayList.add(obj);
            }
        }
        if (arrayList.isEmpty()) {
            arrayList = r0;
        }
        kotlin.random.Random.Default random = kotlin.random.Random.b;
        kotlin.jvm.internal.Intrinsics.e(arrayList, "<this>");
        kotlin.jvm.internal.Intrinsics.e(random, "random");
        if (arrayList.isEmpty()) {
            throw new java.util.NoSuchElementException("Collection is empty.");
        }
        return (com.jorden.karto.setrisokegl.data.model.Move) arrayList.get(kotlin.random.Random.c.b(arrayList.size()));
    }
}
