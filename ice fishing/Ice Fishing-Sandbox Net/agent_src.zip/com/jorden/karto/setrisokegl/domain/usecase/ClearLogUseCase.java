package com.jorden.karto.setrisokegl.domain.usecase;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class ClearLogUseCase {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository f3055a;

    public ClearLogUseCase(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository) {
        this.f3055a = emberRepository;
    }
}
