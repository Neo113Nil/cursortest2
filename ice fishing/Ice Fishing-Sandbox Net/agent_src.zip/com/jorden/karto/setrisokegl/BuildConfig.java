package com.jorden.karto.setrisokegl;

/* loaded from: classes.dex */
public final class BuildConfig {
}
