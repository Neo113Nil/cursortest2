package com.jorden.karto.setrisokegl;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    public com.jorden.karto.setrisokegl.databinding.ActivityMainBinding A;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        super.onCreate(bundle);
        android.view.View viewInflate = getLayoutInflater().inflate(com.jorden.karto.setrisokegl.R.layout.activity_main, (android.view.ViewGroup) null, false);
        int i = com.jorden.karto.setrisokegl.R.id.appBarLayout;
        if (((com.google.android.material.appbar.AppBarLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.appBarLayout)) != null) {
            i = com.jorden.karto.setrisokegl.R.id.bottomNav;
            com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView = (com.google.android.material.bottomnavigation.BottomNavigationView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bottomNav);
            if (bottomNavigationView != null) {
                i = com.jorden.karto.setrisokegl.R.id.navHostFragment;
                if (((androidx.fragment.app.FragmentContainerView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.navHostFragment)) != null) {
                    com.google.android.material.appbar.MaterialToolbar materialToolbar = (com.google.android.material.appbar.MaterialToolbar) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.toolbar);
                    if (materialToolbar != null) {
                        android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) viewInflate;
                        this.A = new com.jorden.karto.setrisokegl.databinding.ActivityMainBinding(linearLayout, bottomNavigationView, materialToolbar);
                        setContentView(linearLayout);
                        com.jorden.karto.setrisokegl.databinding.ActivityMainBinding activityMainBinding = this.A;
                        if (activityMainBinding == null) {
                            kotlin.jvm.internal.Intrinsics.k("binding");
                            throw null;
                        }
                        x().A(activityMainBinding.b);
                        androidx.fragment.app.Fragment fragmentF = this.t.f1138a.d.F(com.jorden.karto.setrisokegl.R.id.navHostFragment);
                        kotlin.jvm.internal.Intrinsics.c(fragmentF, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
                        final androidx.navigation.NavHostController navController = ((androidx.navigation.fragment.NavHostFragment) fragmentF).X();
                        androidx.navigation.ui.AppBarConfiguration.Builder builder = new androidx.navigation.ui.AppBarConfiguration.Builder(kotlin.collections.ArraysKt.y(new java.lang.Integer[]{java.lang.Integer.valueOf(com.jorden.karto.setrisokegl.R.id.furnaceFloorFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisokegl.R.id.motionIndexFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisokegl.R.id.twinWeighFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisokegl.R.id.stokerLogFragment)}));
                        androidx.navigation.ui.AppBarConfiguration appBarConfiguration = new androidx.navigation.ui.AppBarConfiguration(builder.f1382a, new com.jorden.karto.setrisokegl.MainActivity$inlined$sam$i$androidx_navigation_ui_AppBarConfiguration_OnNavigateUpListener$0());
                        kotlin.jvm.internal.Intrinsics.e(navController, "navController");
                        navController.b(new androidx.navigation.ui.ActionBarOnDestinationChangedListener(this, appBarConfiguration));
                        com.jorden.karto.setrisokegl.databinding.ActivityMainBinding activityMainBinding2 = this.A;
                        if (activityMainBinding2 == null) {
                            kotlin.jvm.internal.Intrinsics.k("binding");
                            throw null;
                        }
                        com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView2 = activityMainBinding2.f3017a;
                        bottomNavigationView2.setOnItemSelectedListener(new androidx.core.view.inputmethod.a(navController));
                        final java.lang.ref.WeakReference weakReference = new java.lang.ref.WeakReference(bottomNavigationView2);
                        navController.b(new androidx.navigation.NavController.OnDestinationChangedListener() { // from class: androidx.navigation.ui.NavigationUI$setupWithNavController$9
                            @Override // androidx.navigation.NavController.OnDestinationChangedListener
                            public final void a(androidx.navigation.NavController controller, androidx.navigation.NavDestination destination, android.os.Bundle bundle2) {
                                kotlin.jvm.internal.Intrinsics.e(controller, "controller");
                                kotlin.jvm.internal.Intrinsics.e(destination, "destination");
                                com.google.android.material.navigation.NavigationBarView navigationBarView = (com.google.android.material.navigation.NavigationBarView) weakReference.get();
                                if (navigationBarView == null) {
                                    navController.r.remove(this);
                                    return;
                                }
                                if (destination instanceof androidx.navigation.FloatingWindow) {
                                    return;
                                }
                                android.view.Menu menu = navigationBarView.getMenu();
                                kotlin.jvm.internal.Intrinsics.d(menu, "view.menu");
                                int size = menu.size();
                                for (int i2 = 0; i2 < size; i2++) {
                                    android.view.MenuItem item = menu.getItem(i2);
                                    if (item == null) {
                                        java.lang.IllegalStateException illegalStateException = new java.lang.IllegalStateException("getItem(index)".concat(" must not be null"));
                                        kotlin.jvm.internal.Intrinsics.h(illegalStateException, kotlin.jvm.internal.Intrinsics.class.getName());
                                        throw illegalStateException;
                                    }
                                    if (androidx.navigation.ui.NavigationUI.a(item.getItemId(), destination)) {
                                        item.setChecked(true);
                                    }
                                }
                            }
                        });
                        return;
                    }
                    i = com.jorden.karto.setrisokegl.R.id.toolbar;
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.appcompat.app.AppCompatActivity
    public final boolean z() {
        androidx.fragment.app.Fragment fragmentF = this.t.f1138a.d.F(com.jorden.karto.setrisokegl.R.id.navHostFragment);
        kotlin.jvm.internal.Intrinsics.c(fragmentF, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        return ((androidx.navigation.fragment.NavHostFragment) fragmentF).X().o() || super.z();
    }
}
