package com.jorden.karto.setrisokegl;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MainActivity$inlined$sam$i$androidx_navigation_ui_AppBarConfiguration_OnNavigateUpListener$0 implements androidx.navigation.ui.AppBarConfiguration.OnNavigateUpListener, kotlin.jvm.internal.FunctionAdapter {
    @Override // kotlin.jvm.internal.FunctionAdapter
    public final kotlin.Function a() {
        return com.jorden.karto.setrisokegl.MainActivity$onCreate$$inlined$AppBarConfiguration$default$1.c;
    }

    public final boolean equals(java.lang.Object obj) {
        if ((obj instanceof androidx.navigation.ui.AppBarConfiguration.OnNavigateUpListener) && (obj instanceof kotlin.jvm.internal.FunctionAdapter)) {
            return com.jorden.karto.setrisokegl.MainActivity$onCreate$$inlined$AppBarConfiguration$default$1.c.equals(((kotlin.jvm.internal.FunctionAdapter) obj).a());
        }
        return false;
    }

    public final int hashCode() {
        return com.jorden.karto.setrisokegl.MainActivity$onCreate$$inlined$AppBarConfiguration$default$1.c.hashCode();
    }
}
