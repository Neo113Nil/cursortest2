package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ItemMoveBandBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.LinearLayout f3047a;
    public final android.view.View b;
    public final android.widget.TextView c;
    public final android.widget.TextView d;
    public final android.widget.LinearLayout e;

    /* renamed from: f, reason: collision with root package name */
    public final android.widget.TextView f3048f;

    /* renamed from: g, reason: collision with root package name */
    public final android.widget.TextView f3049g;

    public ItemMoveBandBinding(android.widget.LinearLayout linearLayout, android.view.View view, android.widget.TextView textView, android.widget.TextView textView2, android.widget.LinearLayout linearLayout2, android.widget.TextView textView3, android.widget.TextView textView4) {
        this.f3047a = linearLayout;
        this.b = view;
        this.c = textView;
        this.d = textView2;
        this.e = linearLayout2;
        this.f3048f = textView3;
        this.f3049g = textView4;
    }
}
