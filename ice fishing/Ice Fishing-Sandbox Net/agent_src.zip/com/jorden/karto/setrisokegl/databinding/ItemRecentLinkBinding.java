package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ItemRecentLinkBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.LinearLayout f3051a;
    public final android.widget.TextView b;
    public final android.widget.TextView c;

    public ItemRecentLinkBinding(android.widget.LinearLayout linearLayout, android.widget.TextView textView, android.widget.TextView textView2) {
        this.f3051a = linearLayout;
        this.b = textView;
        this.c = textView2;
    }
}
