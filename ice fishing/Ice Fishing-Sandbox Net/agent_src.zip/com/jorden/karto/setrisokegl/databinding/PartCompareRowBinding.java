package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class PartCompareRowBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.TextView f3052a;
    public final android.widget.TextView b;
    public final android.widget.TextView c;

    public PartCompareRowBinding(android.widget.TextView textView, android.widget.TextView textView2, android.widget.TextView textView3) {
        this.f3052a = textView;
        this.b = textView2;
        this.c = textView3;
    }

    public static com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding a(android.view.View view) {
        int i = com.jorden.karto.setrisokegl.R.id.compareLabel;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(view, com.jorden.karto.setrisokegl.R.id.compareLabel);
        if (textView != null) {
            i = com.jorden.karto.setrisokegl.R.id.compareLeft;
            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(view, com.jorden.karto.setrisokegl.R.id.compareLeft);
            if (textView2 != null) {
                i = com.jorden.karto.setrisokegl.R.id.compareRight;
                android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(view, com.jorden.karto.setrisokegl.R.id.compareRight);
                if (textView3 != null) {
                    return new com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding(textView, textView2, textView3);
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
