package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class FragmentDetailBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.core.widget.NestedScrollView f3024a;
    public final com.google.android.material.checkbox.MaterialCheckBox b;
    public final com.google.android.material.button.MaterialButton c;
    public final com.google.android.material.materialswitch.MaterialSwitch d;
    public final com.google.android.material.button.MaterialButton e;

    /* renamed from: f, reason: collision with root package name */
    public final com.google.android.material.textfield.TextInputEditText f3025f;

    /* renamed from: g, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding f3026g;

    /* renamed from: h, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding f3027h;
    public final com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding i;

    /* renamed from: j, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding f3028j;
    public final com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding k;
    public final com.google.android.material.button.MaterialButton l;

    /* renamed from: m, reason: collision with root package name */
    public final android.widget.LinearLayout f3029m;
    public final com.jorden.karto.setrisokegl.ui.common.EmberDialView n;
    public final android.widget.TextView o;
    public final android.widget.TextView p;
    public final android.widget.TextView q;
    public final android.widget.TextView r;

    public FragmentDetailBinding(androidx.core.widget.NestedScrollView nestedScrollView, com.google.android.material.checkbox.MaterialCheckBox materialCheckBox, com.google.android.material.button.MaterialButton materialButton, com.google.android.material.materialswitch.MaterialSwitch materialSwitch, com.google.android.material.button.MaterialButton materialButton2, com.google.android.material.textfield.TextInputEditText textInputEditText, com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBinding, com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBinding2, com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBinding3, com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBinding4, com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBinding5, com.google.android.material.button.MaterialButton materialButton3, android.widget.LinearLayout linearLayout, com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView, android.widget.TextView textView, android.widget.TextView textView2, android.widget.TextView textView3, android.widget.TextView textView4) {
        this.f3024a = nestedScrollView;
        this.b = materialCheckBox;
        this.c = materialButton;
        this.d = materialSwitch;
        this.e = materialButton2;
        this.f3025f = textInputEditText;
        this.f3026g = partSpecRowBinding;
        this.f3027h = partSpecRowBinding2;
        this.i = partSpecRowBinding3;
        this.f3028j = partSpecRowBinding4;
        this.k = partSpecRowBinding5;
        this.l = materialButton3;
        this.f3029m = linearLayout;
        this.n = emberDialView;
        this.o = textView;
        this.p = textView2;
        this.q = textView3;
        this.r = textView4;
    }
}
