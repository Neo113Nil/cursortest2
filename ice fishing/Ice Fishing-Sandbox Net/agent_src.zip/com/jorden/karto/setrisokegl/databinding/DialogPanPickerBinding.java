package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class DialogPanPickerBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.TextView f3019a;

    public DialogPanPickerBinding(android.widget.LinearLayout linearLayout, android.widget.TextView textView, com.google.android.material.textfield.TextInputEditText textInputEditText, androidx.recyclerview.widget.RecyclerView recyclerView) {
        this.f3019a = textView;
    }
}
