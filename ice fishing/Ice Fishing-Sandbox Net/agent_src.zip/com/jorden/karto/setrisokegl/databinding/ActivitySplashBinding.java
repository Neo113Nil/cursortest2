package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ActivitySplashBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.constraintlayout.widget.ConstraintLayout f3018a;
    public final com.google.android.material.button.MaterialButton b;
    public final androidx.constraintlayout.widget.ConstraintLayout c;
    public final android.widget.TextView d;
    public final com.google.android.material.progressindicator.CircularProgressIndicator e;

    public ActivitySplashBinding(androidx.constraintlayout.widget.ConstraintLayout constraintLayout, com.google.android.material.button.MaterialButton materialButton, androidx.constraintlayout.widget.ConstraintLayout constraintLayout2, android.widget.TextView textView, com.google.android.material.progressindicator.CircularProgressIndicator circularProgressIndicator) {
        this.f3018a = constraintLayout;
        this.b = materialButton;
        this.c = constraintLayout2;
        this.d = textView;
        this.e = circularProgressIndicator;
    }
}
