package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class PartSpecRowBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.TextView f3053a;
    public final android.widget.TextView b;

    public PartSpecRowBinding(android.widget.TextView textView, android.widget.TextView textView2) {
        this.f3053a = textView;
        this.b = textView2;
    }

    public static com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding a(android.view.View view) {
        int i = com.jorden.karto.setrisokegl.R.id.specLabel;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(view, com.jorden.karto.setrisokegl.R.id.specLabel);
        if (textView != null) {
            i = com.jorden.karto.setrisokegl.R.id.specValue;
            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(view, com.jorden.karto.setrisokegl.R.id.specValue);
            if (textView2 != null) {
                return new com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding(textView, textView2);
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
    }
}
