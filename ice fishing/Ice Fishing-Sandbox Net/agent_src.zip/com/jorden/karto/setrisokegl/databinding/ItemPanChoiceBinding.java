package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ItemPanChoiceBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.LinearLayout f3050a;
    public final android.widget.TextView b;
    public final android.widget.TextView c;
    public final android.widget.TextView d;

    public ItemPanChoiceBinding(android.widget.LinearLayout linearLayout, android.widget.TextView textView, android.widget.TextView textView2, android.widget.TextView textView3) {
        this.f3050a = linearLayout;
        this.b = textView;
        this.c = textView2;
        this.d = textView3;
    }
}
