package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class FragmentCatalogBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.LinearLayout f3020a;
    public final com.jorden.karto.setrisokegl.ui.common.EmberDialView b;
    public final android.widget.LinearLayout c;
    public final android.widget.TextView d;
    public final androidx.recyclerview.widget.RecyclerView e;

    /* renamed from: f, reason: collision with root package name */
    public final com.google.android.material.materialswitch.MaterialSwitch f3021f;

    /* renamed from: g, reason: collision with root package name */
    public final com.google.android.material.button.MaterialButton f3022g;

    /* renamed from: h, reason: collision with root package name */
    public final com.google.android.material.textfield.TextInputEditText f3023h;
    public final com.google.android.material.chip.ChipGroup i;

    public FragmentCatalogBinding(android.widget.LinearLayout linearLayout, com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView, android.widget.LinearLayout linearLayout2, android.widget.TextView textView, androidx.recyclerview.widget.RecyclerView recyclerView, com.google.android.material.materialswitch.MaterialSwitch materialSwitch, com.google.android.material.button.MaterialButton materialButton, com.google.android.material.textfield.TextInputEditText textInputEditText, com.google.android.material.chip.ChipGroup chipGroup) {
        this.f3020a = linearLayout;
        this.b = emberDialView;
        this.c = linearLayout2;
        this.d = textView;
        this.e = recyclerView;
        this.f3021f = materialSwitch;
        this.f3022g = materialButton;
        this.f3023h = textInputEditText;
        this.i = chipGroup;
    }
}
