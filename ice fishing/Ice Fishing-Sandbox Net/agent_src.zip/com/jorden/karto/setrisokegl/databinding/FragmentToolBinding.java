package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class FragmentToolBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.core.widget.NestedScrollView f3039a;
    public final com.jorden.karto.setrisokegl.ui.common.TwinBeamView b;
    public final com.google.android.material.button.MaterialButton c;
    public final com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding d;
    public final com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding e;

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding f3040f;

    /* renamed from: g, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding f3041g;

    /* renamed from: h, reason: collision with root package name */
    public final com.google.android.material.card.MaterialCardView f3042h;
    public final android.widget.TextView i;

    /* renamed from: j, reason: collision with root package name */
    public final android.widget.TextView f3043j;
    public final com.google.android.material.card.MaterialCardView k;
    public final android.widget.TextView l;

    /* renamed from: m, reason: collision with root package name */
    public final android.widget.TextView f3044m;
    public final com.google.android.material.button.MaterialButton n;
    public final android.widget.TextView o;
    public final android.widget.TextView p;

    public FragmentToolBinding(androidx.core.widget.NestedScrollView nestedScrollView, com.jorden.karto.setrisokegl.ui.common.TwinBeamView twinBeamView, com.google.android.material.button.MaterialButton materialButton, com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBinding, com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBinding2, com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBinding3, com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBinding4, com.google.android.material.card.MaterialCardView materialCardView, android.widget.TextView textView, android.widget.TextView textView2, com.google.android.material.card.MaterialCardView materialCardView2, android.widget.TextView textView3, android.widget.TextView textView4, com.google.android.material.button.MaterialButton materialButton2, android.widget.TextView textView5, android.widget.TextView textView6) {
        this.f3039a = nestedScrollView;
        this.b = twinBeamView;
        this.c = materialButton;
        this.d = partCompareRowBinding;
        this.e = partCompareRowBinding2;
        this.f3040f = partCompareRowBinding3;
        this.f3041g = partCompareRowBinding4;
        this.f3042h = materialCardView;
        this.i = textView;
        this.f3043j = textView2;
        this.k = materialCardView2;
        this.l = textView3;
        this.f3044m = textView4;
        this.n = materialButton2;
        this.o = textView5;
        this.p = textView6;
    }
}
