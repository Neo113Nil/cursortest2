package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class FragmentProfileBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.core.widget.NestedScrollView f3036a;
    public final androidx.recyclerview.widget.RecyclerView b;
    public final android.widget.LinearLayout c;
    public final androidx.recyclerview.widget.RecyclerView d;
    public final com.google.android.material.button.MaterialButton e;

    /* renamed from: f, reason: collision with root package name */
    public final android.widget.TextView f3037f;

    /* renamed from: g, reason: collision with root package name */
    public final android.widget.TextView f3038g;

    public FragmentProfileBinding(androidx.core.widget.NestedScrollView nestedScrollView, androidx.recyclerview.widget.RecyclerView recyclerView, android.widget.LinearLayout linearLayout, androidx.recyclerview.widget.RecyclerView recyclerView2, com.google.android.material.button.MaterialButton materialButton, android.widget.TextView textView, android.widget.TextView textView2) {
        this.f3036a = nestedScrollView;
        this.b = recyclerView;
        this.c = linearLayout;
        this.d = recyclerView2;
        this.e = materialButton;
        this.f3037f = textView;
        this.f3038g = textView2;
    }
}
