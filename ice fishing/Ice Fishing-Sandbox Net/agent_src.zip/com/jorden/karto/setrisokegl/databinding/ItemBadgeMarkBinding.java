package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ItemBadgeMarkBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final android.widget.LinearLayout f3045a;
    public final android.widget.TextView b;
    public final android.widget.TextView c;
    public final com.jorden.karto.setrisokegl.ui.common.BadgeRingView d;
    public final android.widget.LinearLayout e;

    /* renamed from: f, reason: collision with root package name */
    public final android.widget.TextView f3046f;

    public ItemBadgeMarkBinding(android.widget.LinearLayout linearLayout, android.widget.TextView textView, android.widget.TextView textView2, com.jorden.karto.setrisokegl.ui.common.BadgeRingView badgeRingView, android.widget.LinearLayout linearLayout2, android.widget.TextView textView3) {
        this.f3045a = linearLayout;
        this.b = textView;
        this.c = textView2;
        this.d = badgeRingView;
        this.e = linearLayout2;
        this.f3046f = textView3;
    }
}
