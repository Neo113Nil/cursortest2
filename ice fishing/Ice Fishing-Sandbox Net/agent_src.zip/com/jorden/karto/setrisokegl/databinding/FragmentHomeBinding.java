package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class FragmentHomeBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final androidx.core.widget.NestedScrollView f3030a;
    public final com.google.android.material.button.MaterialButton b;
    public final android.widget.LinearLayout c;
    public final android.widget.TextView d;
    public final android.widget.TextView e;

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.ui.common.EmberDialView f3031f;

    /* renamed from: g, reason: collision with root package name */
    public final android.widget.TextView f3032g;

    /* renamed from: h, reason: collision with root package name */
    public final android.widget.TextView f3033h;
    public final android.widget.TextView i;

    /* renamed from: j, reason: collision with root package name */
    public final android.widget.TextView f3034j;
    public final android.widget.LinearLayout k;
    public final com.google.android.material.button.MaterialButton l;

    /* renamed from: m, reason: collision with root package name */
    public final com.google.android.material.chip.ChipGroup f3035m;
    public final com.google.android.material.button.MaterialButton n;

    public FragmentHomeBinding(androidx.core.widget.NestedScrollView nestedScrollView, com.google.android.material.button.MaterialButton materialButton, android.widget.LinearLayout linearLayout, android.widget.TextView textView, android.widget.TextView textView2, com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView, android.widget.TextView textView3, android.widget.TextView textView4, android.widget.TextView textView5, android.widget.TextView textView6, android.widget.LinearLayout linearLayout2, com.google.android.material.button.MaterialButton materialButton2, com.google.android.material.chip.ChipGroup chipGroup, com.google.android.material.button.MaterialButton materialButton3) {
        this.f3030a = nestedScrollView;
        this.b = materialButton;
        this.c = linearLayout;
        this.d = textView;
        this.e = textView2;
        this.f3031f = emberDialView;
        this.f3032g = textView3;
        this.f3033h = textView4;
        this.i = textView5;
        this.f3034j = textView6;
        this.k = linearLayout2;
        this.l = materialButton2;
        this.f3035m = chipGroup;
        this.n = materialButton3;
    }
}
