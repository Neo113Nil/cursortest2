package com.jorden.karto.setrisokegl.databinding;

/* loaded from: classes.dex */
public final class ActivityMainBinding implements androidx.viewbinding.ViewBinding {

    /* renamed from: a, reason: collision with root package name */
    public final com.google.android.material.bottomnavigation.BottomNavigationView f3017a;
    public final com.google.android.material.appbar.MaterialToolbar b;

    public ActivityMainBinding(android.widget.LinearLayout linearLayout, com.google.android.material.bottomnavigation.BottomNavigationView bottomNavigationView, com.google.android.material.appbar.MaterialToolbar materialToolbar) {
        this.f3017a = bottomNavigationView;
        this.b = materialToolbar;
    }
}
