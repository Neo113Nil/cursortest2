package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$2", f = "EffortSheetViewModel.kt", l = {42}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EffortSheetViewModel$open$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3126f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel f3127g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ java.lang.String f3128h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EffortSheetViewModel$open$2(com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel, java.lang.String str, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3127g = effortSheetViewModel;
        this.f3128h = str;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$2(this.f3127g, this.f3128h, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3126f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel = this.f3127g;
            this.f3126f = 1;
            com.jorden.karto.setrisokegl.domain.usecase.MarkOpenedUseCase markOpenedUseCase = effortSheetViewModel.f3111g;
            markOpenedUseCase.getClass();
            long jCurrentTimeMillis = java.lang.System.currentTimeMillis();
            com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = markOpenedUseCase.f3058a;
            java.lang.Object objC = emberRepository.b.c(new com.jorden.karto.setrisokegl.data.db.RecentViewEntity(this.f3128h, jCurrentTimeMillis), this);
            if (objC != coroutineSingletons) {
                objC = unit;
            }
            if (objC != coroutineSingletons) {
                objC = unit;
            }
            if (objC == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return unit;
    }
}
