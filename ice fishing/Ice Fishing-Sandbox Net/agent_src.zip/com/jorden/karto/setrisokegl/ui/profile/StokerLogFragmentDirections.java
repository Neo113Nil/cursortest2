package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class StokerLogFragmentDirections {

    @kotlin.Metadata
    public static final class ActionLogToSheet implements androidx.navigation.NavDirections {

        /* renamed from: a, reason: collision with root package name */
        public final java.lang.String f3152a;

        public ActionLogToSheet(java.lang.String str) {
            this.f3152a = str;
        }

        @Override // androidx.navigation.NavDirections
        public final android.os.Bundle a() {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putString("moveId", this.f3152a);
            return bundle;
        }

        @Override // androidx.navigation.NavDirections
        public final int b() {
            return com.jorden.karto.setrisokegl.R.id.actionLogToSheet;
        }

        public final boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof com.jorden.karto.setrisokegl.ui.profile.StokerLogFragmentDirections.ActionLogToSheet) && kotlin.jvm.internal.Intrinsics.a(this.f3152a, ((com.jorden.karto.setrisokegl.ui.profile.StokerLogFragmentDirections.ActionLogToSheet) obj).f3152a);
        }

        public final int hashCode() {
            return this.f3152a.hashCode();
        }

        public final java.lang.String toString() {
            return androidx.activity.h.j(new java.lang.StringBuilder("ActionLogToSheet(moveId="), this.f3152a, ")");
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }
}
