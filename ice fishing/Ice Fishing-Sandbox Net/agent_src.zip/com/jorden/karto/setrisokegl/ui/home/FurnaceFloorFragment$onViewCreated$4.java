package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4", f = "FurnaceFloorFragment.kt", l = {65}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class FurnaceFloorFragment$onViewCreated$4 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3135f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment f3136g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4$1", f = "FurnaceFloorFragment.kt", l = {66}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3137f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment f3138g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3138g = furnaceFloorFragment;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4.AnonymousClass1(this.f3138g, continuation);
        }

        /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Object, kotlin.Lazy] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3137f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.f3138g;
                kotlinx.coroutines.flow.StateFlow stateFlow = ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment.d0.getValue()).d;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment.onViewCreated.4.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState furnaceFloorUiState = (com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) obj2;
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment2 = furnaceFloorFragment;
                        furnaceFloorFragment2.getClass();
                        com.jorden.karto.setrisokegl.data.model.Move move = furnaceFloorUiState.f3142a;
                        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX = furnaceFloorFragment2.X();
                        fragmentHomeBindingX.c.setBackgroundColor(furnaceFloorFragment2.R().getColor(com.jorden.karto.setrisokegl.ui.common.Tints.a(move.f2953a)));
                        furnaceFloorFragment2.X().f3033h.setText(move.c);
                        furnaceFloorFragment2.X().f3034j.setText(move.b);
                        furnaceFloorFragment2.X().d.setText(move.a().b);
                        furnaceFloorFragment2.X().f3031f.setCeiling(furnaceFloorUiState.b);
                        com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView = furnaceFloorFragment2.X().f3031f;
                        float f2 = move.e;
                        emberDialView.setValue(f2);
                        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX2 = furnaceFloorFragment2.X();
                        fragmentHomeBindingX2.f3032g.setText(furnaceFloorFragment2.r(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(f2)));
                        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX3 = furnaceFloorFragment2.X();
                        fragmentHomeBindingX3.e.setText(furnaceFloorFragment2.r(com.jorden.karto.setrisokegl.R.string.kcal_value, java.lang.Integer.valueOf(move.f2954f)));
                        furnaceFloorFragment2.X().i.setText(move.f2955g);
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3137f = 1;
                if (stateFlow.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FurnaceFloorFragment$onViewCreated$4(com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3136g = furnaceFloorFragment;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4(this.f3136g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3135f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.f3136g;
            androidx.lifecycle.LifecycleOwner lifecycleOwnerT = furnaceFloorFragment.t();
            kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4.AnonymousClass1(furnaceFloorFragment, null);
            this.f3135f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(lifecycleOwnerT, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
