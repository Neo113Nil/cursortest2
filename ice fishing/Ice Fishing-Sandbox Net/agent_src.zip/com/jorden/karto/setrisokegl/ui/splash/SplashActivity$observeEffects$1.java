package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1", f = "SplashActivity.kt", l = {84}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashActivity$observeEffects$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3162f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3163g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1", f = "SplashActivity.kt", l = {}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public /* synthetic */ java.lang.Object f3164f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3165g;

        @kotlin.Metadata
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1$1", f = "SplashActivity.kt", l = {85}, m = "invokeSuspend")
        /* renamed from: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1$1, reason: invalid class name and collision with other inner class name */
        final class C00131 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

            /* renamed from: f, reason: collision with root package name */
            public int f3166f;

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3167g;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C00131(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
                super(2, continuation);
                this.f3167g = splashActivity;
            }

            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
                ((com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.C00131) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
                return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                return new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.C00131(this.f3167g, continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
                kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
                int i = this.f3166f;
                if (i == 0) {
                    kotlin.ResultKt.b(obj);
                    int i2 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                    final com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3167g;
                    kotlinx.coroutines.flow.SharedFlow sharedFlow = splashActivity.A().f3177g;
                    kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.splash.SplashActivity.observeEffects.1.1.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                            int i3 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity2 = splashActivity;
                            splashActivity2.getClass();
                            splashActivity2.startActivity(new android.content.Intent(splashActivity2, (java.lang.Class<?>) com.jorden.karto.setrisokegl.MainActivity.class), androidx.core.app.ActivityOptionsCompat.a(splashActivity2).b());
                            splashActivity2.finish();
                            return kotlin.Unit.f3201a;
                        }
                    };
                    this.f3166f = 1;
                    if (sharedFlow.a(flowCollector, this) == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.b(obj);
                }
                throw new kotlin.KotlinNothingValueException();
            }
        }

        @kotlin.Metadata
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1$2", f = "SplashActivity.kt", l = {86}, m = "invokeSuspend")
        /* renamed from: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1$1$2, reason: invalid class name */
        final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

            /* renamed from: f, reason: collision with root package name */
            public int f3168f;

            /* renamed from: g, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3169g;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public AnonymousClass2(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
                super(2, continuation);
                this.f3169g = splashActivity;
            }

            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
                ((com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.AnonymousClass2) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
                return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                return new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.AnonymousClass2(this.f3169g, continuation);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
                kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
                int i = this.f3168f;
                if (i == 0) {
                    kotlin.ResultKt.b(obj);
                    int i2 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                    final com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3169g;
                    kotlinx.coroutines.flow.SharedFlow sharedFlow = splashActivity.A().i;
                    kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.splash.SplashActivity.observeEffects.1.1.2.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                            java.lang.String url = (java.lang.String) obj2;
                            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity2 = splashActivity;
                            kotlin.jvm.internal.Intrinsics.e(splashActivity2, "<this>");
                            kotlin.jvm.internal.Intrinsics.e(url, "url");
                            try {
                                androidx.browser.customtabs.CustomTabsIntent customTabsIntentA = new androidx.browser.customtabs.CustomTabsIntent.Builder().a();
                                android.net.Uri uri = android.net.Uri.parse(url);
                                android.content.Intent intent = customTabsIntentA.f462a;
                                intent.setData(uri);
                                splashActivity2.startActivity(intent, customTabsIntentA.b);
                            } catch (java.lang.Exception unused) {
                            }
                            return kotlin.Unit.f3201a;
                        }
                    };
                    this.f3168f = 1;
                    if (sharedFlow.a(flowCollector, this) == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                } else {
                    if (i != 1) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.b(obj);
                }
                throw new kotlin.KotlinNothingValueException();
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3165g = splashActivity;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1 anonymousClass1 = (com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2);
            kotlin.Unit unit = kotlin.Unit.f3201a;
            anonymousClass1.p(unit);
            return unit;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1(this.f3165g, continuation);
            anonymousClass1.f3164f = obj;
            return anonymousClass1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            kotlin.ResultKt.b(obj);
            kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) this.f3164f;
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3165g;
            kotlinx.coroutines.BuildersKt.c(coroutineScope, null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.C00131(splashActivity, null), 3);
            kotlinx.coroutines.BuildersKt.c(coroutineScope, null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1.AnonymousClass2(splashActivity, null), 3);
            return kotlin.Unit.f3201a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashActivity$observeEffects$1(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3163g = splashActivity;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1(this.f3163g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3162f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.f1224f;
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3163g;
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1.AnonymousClass1(splashActivity, null);
            this.f3162f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(splashActivity, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
