package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class SplashCustomTabKt {
}
