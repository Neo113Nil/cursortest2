package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EffortSheetFragmentArgs implements androidx.navigation.NavArgs {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f3108a;

    @kotlin.Metadata
    public static final class Companion {
    }

    public EffortSheetFragmentArgs(java.lang.String str) {
        this.f3108a = str;
    }

    @kotlin.jvm.JvmStatic
    @org.jetbrains.annotations.NotNull
    public static final com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs fromBundle(@org.jetbrains.annotations.NotNull android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(bundle, "bundle");
        bundle.setClassLoader(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs.class.getClassLoader());
        if (!bundle.containsKey("moveId")) {
            throw new java.lang.IllegalArgumentException("Required argument \"moveId\" is missing and does not have an android:defaultValue");
        }
        java.lang.String string = bundle.getString("moveId");
        if (string != null) {
            return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs(string);
        }
        throw new java.lang.IllegalArgumentException("Argument \"moveId\" is marked as non-null but was passed a null value.");
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs) && kotlin.jvm.internal.Intrinsics.a(this.f3108a, ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs) obj).f3108a);
    }

    public final int hashCode() {
        return this.f3108a.hashCode();
    }

    public final java.lang.String toString() {
        return androidx.activity.h.j(new java.lang.StringBuilder("EffortSheetFragmentArgs(moveId="), this.f3108a, ")");
    }
}
