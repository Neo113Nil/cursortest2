package com.jorden.karto.setrisokegl.ui.tool;

/* loaded from: classes.dex */
public final /* synthetic */ class b implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment b;
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.Pan c;
    public final /* synthetic */ androidx.appcompat.app.AlertDialog d;

    public /* synthetic */ b(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment, com.jorden.karto.setrisokegl.ui.tool.Pan pan, androidx.appcompat.app.AlertDialog alertDialog) {
        this.b = twinWeighFragment;
        this.c = pan;
        this.d = alertDialog;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) {
        com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
        kotlin.jvm.internal.Intrinsics.e(move, "move");
        this.b.a0().i(this.c, move);
        this.d.dismiss();
        return kotlin.Unit.f3201a;
    }
}
