package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class FurnaceFloorFragment$special$$inlined$viewModel$default$1 implements kotlin.jvm.functions.Function0<androidx.fragment.app.Fragment> {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment b;

    public FurnaceFloorFragment$special$$inlined$viewModel$default$1(com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment) {
        this.b = furnaceFloorFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        return this.b;
    }
}
