package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveBandAdapter extends androidx.recyclerview.widget.ListAdapter<com.jorden.karto.setrisokegl.data.model.MoveEntry, com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.BandHolder> {

    /* renamed from: g, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter$Companion$DIFF$1 f3083g = new com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter$Companion$DIFF$1();

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.ui.catalog.a f3084f;

    @kotlin.Metadata
    public final class BandHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public static final /* synthetic */ int w = 0;
        public final com.jorden.karto.setrisokegl.databinding.ItemMoveBandBinding u;

        public BandHolder(com.jorden.karto.setrisokegl.databinding.ItemMoveBandBinding itemMoveBandBinding) {
            super(itemMoveBandBinding.f3047a);
            this.u = itemMoveBandBinding;
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public MoveBandAdapter(com.jorden.karto.setrisokegl.ui.catalog.a aVar) {
        super(f3083g);
        this.f3084f = aVar;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final void g(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int i) {
        com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.BandHolder bandHolder = (com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.BandHolder) viewHolder;
        java.lang.Object obj = this.d.f1415f.get(i);
        kotlin.jvm.internal.Intrinsics.d(obj, "getItem(...)");
        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = (com.jorden.karto.setrisokegl.data.model.MoveEntry) obj;
        com.jorden.karto.setrisokegl.databinding.ItemMoveBandBinding itemMoveBandBinding = bandHolder.u;
        android.content.Context context = itemMoveBandBinding.f3047a.getContext();
        com.jorden.karto.setrisokegl.data.model.Move move = moveEntry.f2959a;
        itemMoveBandBinding.e.setBackgroundColor(context.getColor(com.jorden.karto.setrisokegl.ui.common.Tints.a(move.f2953a)));
        itemMoveBandBinding.c.setText(move.c);
        itemMoveBandBinding.d.setText(move.b);
        itemMoveBandBinding.f3048f.setText(move.d.c);
        itemMoveBandBinding.f3049g.setText(context.getString(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(move.e)));
        itemMoveBandBinding.b.setVisibility(moveEntry.b.b ? 0 : 4);
        itemMoveBandBinding.f3047a.setOnClickListener(new com.jorden.karto.setrisokegl.ui.catalog.e(com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.this, moveEntry, 0));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final androidx.recyclerview.widget.RecyclerView.ViewHolder h(android.view.ViewGroup parent, int i) {
        kotlin.jvm.internal.Intrinsics.e(parent, "parent");
        android.view.View viewInflate = android.view.LayoutInflater.from(parent.getContext()).inflate(com.jorden.karto.setrisokegl.R.layout.item_move_band, parent, false);
        int i2 = com.jorden.karto.setrisokegl.R.id.bandKeptMarker;
        android.view.View viewA = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bandKeptMarker);
        if (viewA != null) {
            i2 = com.jorden.karto.setrisokegl.R.id.bandMark;
            android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bandMark);
            if (textView != null) {
                i2 = com.jorden.karto.setrisokegl.R.id.bandName;
                android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bandName);
                if (textView2 != null) {
                    android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) viewInflate;
                    i2 = com.jorden.karto.setrisokegl.R.id.bandTag;
                    android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bandTag);
                    if (textView3 != null) {
                        i2 = com.jorden.karto.setrisokegl.R.id.bandValue;
                        android.widget.TextView textView4 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.bandValue);
                        if (textView4 != null) {
                            return new com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.BandHolder(new com.jorden.karto.setrisokegl.databinding.ItemMoveBandBinding(linearLayout, viewA, textView, textView2, linearLayout, textView3, textView4));
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
