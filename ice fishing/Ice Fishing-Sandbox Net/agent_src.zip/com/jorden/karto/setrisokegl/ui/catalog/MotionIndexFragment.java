package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class MotionIndexFragment extends androidx.fragment.app.Fragment {
    public com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding c0;
    public final java.lang.Object d0;
    public final androidx.navigation.NavArgsLazy e0;
    public com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter f0;

    public MotionIndexFragment() {
        final com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$special$$inlined$viewModel$default$1 motionIndexFragment$special$$inlined$viewModel$default$1 = new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$special$$inlined$viewModel$default$1(this);
        this.d0 = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$special$$inlined$viewModel$default$2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                androidx.lifecycle.ViewModelStore viewModelStoreP = motionIndexFragment$special$$inlined$viewModel$default$1.b.p();
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment = this.b;
                return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel.class), viewModelStoreP, motionIndexFragment.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(motionIndexFragment), null);
            }
        });
        this.e0 = new androidx.navigation.NavArgsLazy(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs.class), new kotlin.jvm.functions.Function0<android.os.Bundle>() { // from class: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$special$$inlined$navArgs$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment = this.c;
                android.os.Bundle bundle = motionIndexFragment.f1124g;
                if (bundle != null) {
                    return bundle;
                }
                throw new java.lang.IllegalStateException("Fragment " + motionIndexFragment + " has null arguments");
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    public final android.view.View D(android.view.LayoutInflater inflater, android.view.ViewGroup viewGroup, android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(inflater, "inflater");
        android.view.View viewInflate = inflater.inflate(com.jorden.karto.setrisokegl.R.layout.fragment_catalog, viewGroup, false);
        int i = com.jorden.karto.setrisokegl.R.id.emptyDial;
        com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView = (com.jorden.karto.setrisokegl.ui.common.EmberDialView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.emptyDial);
        if (emberDialView != null) {
            i = com.jorden.karto.setrisokegl.R.id.emptyGroup;
            android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.emptyGroup);
            if (linearLayout != null) {
                i = com.jorden.karto.setrisokegl.R.id.indexCount;
                android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.indexCount);
                if (textView != null) {
                    i = com.jorden.karto.setrisokegl.R.id.indexList;
                    androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.indexList);
                    if (recyclerView != null) {
                        i = com.jorden.karto.setrisokegl.R.id.keptOnlySwitch;
                        com.google.android.material.materialswitch.MaterialSwitch materialSwitch = (com.google.android.material.materialswitch.MaterialSwitch) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.keptOnlySwitch);
                        if (materialSwitch != null) {
                            i = com.jorden.karto.setrisokegl.R.id.loosenButton;
                            com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.loosenButton);
                            if (materialButton != null) {
                                i = com.jorden.karto.setrisokegl.R.id.searchInput;
                                com.google.android.material.textfield.TextInputEditText textInputEditText = (com.google.android.material.textfield.TextInputEditText) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.searchInput);
                                if (textInputEditText != null) {
                                    i = com.jorden.karto.setrisokegl.R.id.searchLayout;
                                    if (((com.google.android.material.textfield.TextInputLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.searchLayout)) != null) {
                                        i = com.jorden.karto.setrisokegl.R.id.tagChips;
                                        com.google.android.material.chip.ChipGroup chipGroup = (com.google.android.material.chip.ChipGroup) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.tagChips);
                                        if (chipGroup != null) {
                                            this.c0 = new com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding((android.widget.LinearLayout) viewInflate, emberDialView, linearLayout, textView, recyclerView, materialSwitch, materialButton, textInputEditText, chipGroup);
                                            android.widget.LinearLayout linearLayout2 = X().f3020a;
                                            kotlin.jvm.internal.Intrinsics.d(linearLayout2, "getRoot(...)");
                                            return linearLayout2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.fragment.app.Fragment
    public final void F() {
        this.I = true;
        this.c0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public final void N(android.view.View view) {
        java.lang.Object next;
        kotlin.jvm.internal.Intrinsics.e(view, "view");
        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModelY = Y();
        com.jorden.karto.setrisokegl.ui.catalog.a aVar = new com.jorden.karto.setrisokegl.ui.catalog.a(this, 1);
        motionIndexViewModelY.getClass();
        motionIndexViewModelY.f3079f = aVar;
        this.f0 = new com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter(new com.jorden.karto.setrisokegl.ui.catalog.a(this, 0));
        com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding fragmentCatalogBindingX = X();
        R();
        fragmentCatalogBindingX.e.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(1));
        com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding fragmentCatalogBindingX2 = X();
        com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter moveBandAdapter = this.f0;
        if (moveBandAdapter == null) {
            kotlin.jvm.internal.Intrinsics.k("adapter");
            throw null;
        }
        fragmentCatalogBindingX2.e.setAdapter(moveBandAdapter);
        X().e.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
        X().e.setLayoutAnimation(new android.view.animation.LayoutAnimationController(android.view.animation.AnimationUtils.loadAnimation(R(), com.jorden.karto.setrisokegl.R.anim.band_enter)));
        X().b.setResting(true);
        com.google.android.material.chip.ChipGroup chipGroup = X().i;
        chipGroup.removeAllViews();
        java.util.Iterator it = ((kotlin.collections.AbstractList) com.jorden.karto.setrisokegl.data.model.MoveTag.k).iterator();
        while (it.hasNext()) {
            com.jorden.karto.setrisokegl.data.model.MoveTag moveTag = (com.jorden.karto.setrisokegl.data.model.MoveTag) it.next();
            com.google.android.material.chip.Chip chip = new com.google.android.material.chip.Chip(R(), null);
            chip.setId(android.view.View.generateViewId());
            chip.setText(moveTag.c);
            chip.setCheckable(true);
            chip.setTag(moveTag);
            chipGroup.addView(chip);
        }
        chipGroup.setOnCheckedStateChangeListener(new com.google.android.material.chip.ChipGroup.OnCheckedStateChangeListener() { // from class: com.jorden.karto.setrisokegl.ui.catalog.d
            @Override // com.google.android.material.chip.ChipGroup.OnCheckedStateChangeListener
            public final void a(com.google.android.material.chip.ChipGroup chipGroup2, java.util.ArrayList arrayList) {
                java.lang.Object value;
                com.google.android.material.chip.Chip chip2;
                kotlin.jvm.internal.Intrinsics.e(chipGroup2, "chipGroup");
                java.lang.Integer num = (java.lang.Integer) kotlin.collections.CollectionsKt.p(arrayList);
                java.lang.Object tag = (num == null || (chip2 = (com.google.android.material.chip.Chip) chipGroup2.findViewById(num.intValue())) == null) ? null : chip2.getTag();
                com.jorden.karto.setrisokegl.data.model.MoveTag moveTag2 = tag instanceof com.jorden.karto.setrisokegl.data.model.MoveTag ? (com.jorden.karto.setrisokegl.data.model.MoveTag) tag : null;
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModelY2 = this.f3087a.Y();
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = motionIndexViewModelY2.c;
                do {
                    value = mutableStateFlow.getValue();
                } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState.a((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) value, null, null, moveTag2, false, 11)));
                motionIndexViewModelY2.i();
            }
        });
        X().f3023h.addTextChangedListener(new android.text.TextWatcher() { // from class: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$$inlined$doAfterTextChanged$1
            @Override // android.text.TextWatcher
            public final void afterTextChanged(android.text.Editable editable) {
                java.lang.Object value;
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModelY2 = this.f3071a.Y();
                java.lang.String string = editable != null ? editable.toString() : null;
                if (string == null) {
                    string = "";
                }
                motionIndexViewModelY2.getClass();
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = motionIndexViewModelY2.c;
                do {
                    value = mutableStateFlow.getValue();
                } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState.a((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) value, null, string, null, false, 13)));
                motionIndexViewModelY2.i();
            }

            @Override // android.text.TextWatcher
            public final void beforeTextChanged(java.lang.CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public final void onTextChanged(java.lang.CharSequence charSequence, int i, int i2, int i3) {
            }
        });
        X().f3021f.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() { // from class: com.jorden.karto.setrisokegl.ui.catalog.b
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(android.widget.CompoundButton compoundButton, boolean z) {
                java.lang.Object value;
                kotlin.jvm.internal.Intrinsics.e(compoundButton, "<unused var>");
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModelY2 = this.f3085a.Y();
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = motionIndexViewModelY2.c;
                do {
                    value = mutableStateFlow.getValue();
                } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState.a((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) value, null, null, null, z, 7)));
                motionIndexViewModelY2.i();
            }
        });
        X().f3022g.setOnClickListener(new android.view.View.OnClickListener() { // from class: com.jorden.karto.setrisokegl.ui.catalog.c
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) throws android.content.res.Resources.NotFoundException {
                java.lang.Object value;
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment = this.f3086a;
                motionIndexFragment.X().f3023h.setText("");
                motionIndexFragment.X().f3021f.setChecked(false);
                motionIndexFragment.X().i.f2351h.c();
                com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModelY2 = motionIndexFragment.Y();
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = motionIndexViewModelY2.c;
                do {
                    value = mutableStateFlow.getValue();
                } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState.a((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) value, null, "", null, false, 1)));
                motionIndexViewModelY2.i();
            }
        });
        com.jorden.karto.setrisokegl.data.model.MoveTag.Companion companion = com.jorden.karto.setrisokegl.data.model.MoveTag.d;
        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs motionIndexFragmentArgs = (com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs) this.e0.getValue();
        companion.getClass();
        java.lang.String str = motionIndexFragmentArgs.f3076a;
        java.util.Iterator it2 = ((kotlin.collections.AbstractList) com.jorden.karto.setrisokegl.data.model.MoveTag.k).iterator();
        while (true) {
            if (!it2.hasNext()) {
                next = null;
                break;
            } else {
                next = it2.next();
                if (((com.jorden.karto.setrisokegl.data.model.MoveTag) next).b.equals(str)) {
                    break;
                }
            }
        }
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag2 = (com.jorden.karto.setrisokegl.data.model.MoveTag) next;
        if (moveTag2 != null) {
            com.google.android.material.chip.ChipGroup chipGroup2 = X().i;
            int childCount = chipGroup2.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                android.view.View childAt = chipGroup2.getChildAt(i);
                com.google.android.material.chip.Chip chip2 = childAt instanceof com.google.android.material.chip.Chip ? (com.google.android.material.chip.Chip) childAt : null;
                if (chip2 != null && chip2.getTag() == moveTag2) {
                    chip2.setChecked(true);
                    break;
                }
                i++;
            }
        }
        androidx.lifecycle.LifecycleOwner lifecycleOwnerT = t();
        kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(lifecycleOwnerT), null, null, new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7(this, null), 3);
    }

    public final com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding X() {
        com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding fragmentCatalogBinding = this.c0;
        if (fragmentCatalogBinding != null) {
            return fragmentCatalogBinding;
        }
        throw new java.lang.IllegalArgumentException("Required value was null.");
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
    public final com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel Y() {
        return (com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel) this.d0.getValue();
    }
}
