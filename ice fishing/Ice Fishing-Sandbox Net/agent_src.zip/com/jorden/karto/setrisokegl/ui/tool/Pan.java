package com.jorden.karto.setrisokegl.ui.tool;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@kotlin.Metadata
/* loaded from: classes.dex */
public final class Pan {
    public static final com.jorden.karto.setrisokegl.ui.tool.Pan b;
    public static final com.jorden.karto.setrisokegl.ui.tool.Pan c;
    public static final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.Pan[] d;
    public static final /* synthetic */ kotlin.enums.EnumEntries e;

    static {
        com.jorden.karto.setrisokegl.ui.tool.Pan pan = new com.jorden.karto.setrisokegl.ui.tool.Pan("LEFT", 0);
        b = pan;
        com.jorden.karto.setrisokegl.ui.tool.Pan pan2 = new com.jorden.karto.setrisokegl.ui.tool.Pan("RIGHT", 1);
        c = pan2;
        com.jorden.karto.setrisokegl.ui.tool.Pan[] panArr = {pan, pan2};
        d = panArr;
        e = kotlin.enums.EnumEntriesKt.a(panArr);
    }

    public static com.jorden.karto.setrisokegl.ui.tool.Pan valueOf(java.lang.String str) {
        return (com.jorden.karto.setrisokegl.ui.tool.Pan) java.lang.Enum.valueOf(com.jorden.karto.setrisokegl.ui.tool.Pan.class, str);
    }

    public static com.jorden.karto.setrisokegl.ui.tool.Pan[] values() {
        return (com.jorden.karto.setrisokegl.ui.tool.Pan[]) d.clone();
    }
}
