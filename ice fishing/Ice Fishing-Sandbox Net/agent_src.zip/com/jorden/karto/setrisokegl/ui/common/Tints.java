package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class Tints {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f3098a = {com.jorden.karto.setrisokegl.R.color.tint_0, com.jorden.karto.setrisokegl.R.color.tint_1, com.jorden.karto.setrisokegl.R.color.tint_2, com.jorden.karto.setrisokegl.R.color.tint_3, com.jorden.karto.setrisokegl.R.color.tint_4, com.jorden.karto.setrisokegl.R.color.tint_5};

    public static int a(java.lang.String id) {
        kotlin.jvm.internal.Intrinsics.e(id, "id");
        return f3098a[java.lang.Math.abs(id.hashCode()) % 6];
    }
}
