package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onCompletedChanged$1", f = "EffortSheetViewModel.kt", l = {53}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EffortSheetViewModel$onCompletedChanged$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3114f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel f3115g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ boolean f3116h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EffortSheetViewModel$onCompletedChanged$1(com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel, boolean z, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3115g = effortSheetViewModel;
        this.f3116h = z;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onCompletedChanged$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onCompletedChanged$1(this.f3115g, this.f3116h, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3114f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel = this.f3115g;
            java.lang.String str = effortSheetViewModel.f3113j;
            this.f3114f = 1;
            java.lang.Object objF = effortSheetViewModel.d.f3065a.f(str, new com.jorden.karto.setrisokegl.data.repository.c(1, this.f3116h), this);
            if (objF != coroutineSingletons) {
                objF = unit;
            }
            if (objF != coroutineSingletons) {
                objF = unit;
            }
            if (objF == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return unit;
    }
}
