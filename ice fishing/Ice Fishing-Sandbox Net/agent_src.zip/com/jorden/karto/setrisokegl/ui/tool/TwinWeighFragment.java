package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class TwinWeighFragment extends androidx.fragment.app.Fragment {
    public com.jorden.karto.setrisokegl.databinding.FragmentToolBinding c0;
    public final java.lang.Object d0;
    public final androidx.navigation.NavArgsLazy e0;

    @kotlin.Metadata
    public static final class Companion {
    }

    public TwinWeighFragment() {
        final com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$special$$inlined$viewModel$default$1 twinWeighFragment$special$$inlined$viewModel$default$1 = new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$special$$inlined$viewModel$default$1(this);
        this.d0 = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$special$$inlined$viewModel$default$2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                androidx.lifecycle.ViewModelStore viewModelStoreP = twinWeighFragment$special$$inlined$viewModel$default$1.b.p();
                com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment = this.b;
                return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.class), viewModelStoreP, twinWeighFragment.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(twinWeighFragment), null);
            }
        });
        this.e0 = new androidx.navigation.NavArgsLazy(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs.class), new kotlin.jvm.functions.Function0<android.os.Bundle>() { // from class: com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$special$$inlined$navArgs$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment = this.c;
                android.os.Bundle bundle = twinWeighFragment.f1124g;
                if (bundle != null) {
                    return bundle;
                }
                throw new java.lang.IllegalStateException("Fragment " + twinWeighFragment + " has null arguments");
            }
        });
    }

    public static int X(java.lang.Float f2, java.lang.Float f3) {
        if (f2 == null || f3 == null || f2.floatValue() == f3.floatValue()) {
            return 0;
        }
        return f2.floatValue() > f3.floatValue() ? 1 : 2;
    }

    public static final void c0(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment, com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter panPickerAdapter, com.jorden.karto.setrisokegl.databinding.DialogPanPickerBinding dialogPanPickerBinding, java.lang.String str) {
        java.lang.String string = kotlin.text.StringsKt.C(str).toString();
        java.util.Locale locale = java.util.Locale.getDefault();
        kotlin.jvm.internal.Intrinsics.d(locale, "getDefault(...)");
        java.lang.String lowerCase = string.toLowerCase(locale);
        kotlin.jvm.internal.Intrinsics.d(lowerCase, "toLowerCase(...)");
        java.util.List list = twinWeighFragment.a0().f3192g;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (java.lang.Object obj : list) {
            com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
            if (lowerCase.length() != 0) {
                java.lang.String strQ = twinWeighFragment.q(move.b);
                kotlin.jvm.internal.Intrinsics.d(strQ, "getString(...)");
                java.util.Locale locale2 = java.util.Locale.getDefault();
                kotlin.jvm.internal.Intrinsics.d(locale2, "getDefault(...)");
                java.lang.String lowerCase2 = strQ.toLowerCase(locale2);
                kotlin.jvm.internal.Intrinsics.d(lowerCase2, "toLowerCase(...)");
                if (kotlin.text.StringsKt.h(lowerCase2, lowerCase)) {
                }
            }
            arrayList.add(obj);
        }
        panPickerAdapter.o(arrayList);
        dialogPanPickerBinding.f3019a.setVisibility(arrayList.isEmpty() ? 0 : 8);
    }

    @Override // androidx.fragment.app.Fragment
    public final android.view.View D(android.view.LayoutInflater inflater, android.view.ViewGroup viewGroup, android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(inflater, "inflater");
        android.view.View viewInflate = inflater.inflate(com.jorden.karto.setrisokegl.R.layout.fragment_tool, viewGroup, false);
        int i = com.jorden.karto.setrisokegl.R.id.beamView;
        com.jorden.karto.setrisokegl.ui.common.TwinBeamView twinBeamView = (com.jorden.karto.setrisokegl.ui.common.TwinBeamView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.beamView);
        if (twinBeamView != null) {
            i = com.jorden.karto.setrisokegl.R.id.clearPansButton;
            com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.clearPansButton);
            if (materialButton != null) {
                i = com.jorden.karto.setrisokegl.R.id.compareBand;
                android.view.View viewA = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.compareBand);
                if (viewA != null) {
                    com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBindingA = com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding.a(viewA);
                    i = com.jorden.karto.setrisokegl.R.id.compareHalfHour;
                    android.view.View viewA2 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.compareHalfHour);
                    if (viewA2 != null) {
                        com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBindingA2 = com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding.a(viewA2);
                        i = com.jorden.karto.setrisokegl.R.id.compareMover;
                        android.view.View viewA3 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.compareMover);
                        if (viewA3 != null) {
                            com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBindingA3 = com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding.a(viewA3);
                            i = com.jorden.karto.setrisokegl.R.id.compareScale;
                            android.view.View viewA4 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.compareScale);
                            if (viewA4 != null) {
                                com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBindingA4 = com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding.a(viewA4);
                                i = com.jorden.karto.setrisokegl.R.id.leftPanCard;
                                com.google.android.material.card.MaterialCardView materialCardView = (com.google.android.material.card.MaterialCardView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.leftPanCard);
                                if (materialCardView != null) {
                                    i = com.jorden.karto.setrisokegl.R.id.leftPanMark;
                                    android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.leftPanMark);
                                    if (textView != null) {
                                        i = com.jorden.karto.setrisokegl.R.id.leftPanName;
                                        android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.leftPanName);
                                        if (textView2 != null) {
                                            i = com.jorden.karto.setrisokegl.R.id.rightPanCard;
                                            com.google.android.material.card.MaterialCardView materialCardView2 = (com.google.android.material.card.MaterialCardView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rightPanCard);
                                            if (materialCardView2 != null) {
                                                i = com.jorden.karto.setrisokegl.R.id.rightPanMark;
                                                android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rightPanMark);
                                                if (textView3 != null) {
                                                    i = com.jorden.karto.setrisokegl.R.id.rightPanName;
                                                    android.widget.TextView textView4 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rightPanName);
                                                    if (textView4 != null) {
                                                        i = com.jorden.karto.setrisokegl.R.id.swapButton;
                                                        com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.swapButton);
                                                        if (materialButton2 != null) {
                                                            i = com.jorden.karto.setrisokegl.R.id.verdictLine;
                                                            android.widget.TextView textView5 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.verdictLine);
                                                            if (textView5 != null) {
                                                                i = com.jorden.karto.setrisokegl.R.id.weighCount;
                                                                android.widget.TextView textView6 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.weighCount);
                                                                if (textView6 != null) {
                                                                    this.c0 = new com.jorden.karto.setrisokegl.databinding.FragmentToolBinding((androidx.core.widget.NestedScrollView) viewInflate, twinBeamView, materialButton, partCompareRowBindingA, partCompareRowBindingA2, partCompareRowBindingA3, partCompareRowBindingA4, materialCardView, textView, textView2, materialCardView2, textView3, textView4, materialButton2, textView5, textView6);
                                                                    androidx.core.widget.NestedScrollView nestedScrollView = Z().f3039a;
                                                                    kotlin.jvm.internal.Intrinsics.d(nestedScrollView, "getRoot(...)");
                                                                    return nestedScrollView;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.fragment.app.Fragment
    public final void F() {
        this.I = true;
        this.c0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public final void N(android.view.View view) {
        kotlin.jvm.internal.Intrinsics.e(view, "view");
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel twinWeighViewModelA0 = a0();
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs twinWeighFragmentArgs = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs) this.e0.getValue();
        twinWeighViewModelA0.getClass();
        java.lang.String str = twinWeighFragmentArgs.f3189a;
        if (!kotlin.text.StringsKt.m(str) && ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) twinWeighViewModelA0.e.getValue()).f3190a == null) {
            twinWeighViewModelA0.b.getClass();
            com.jorden.karto.setrisokegl.data.model.Move moveD = com.jorden.karto.setrisokegl.data.repository.EmberRepository.d(str);
            if (moveD != null) {
                twinWeighViewModelA0.i(com.jorden.karto.setrisokegl.ui.tool.Pan.b, moveD);
            }
        }
        Z().f3041g.f3052a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_scale);
        Z().e.f3052a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_half_hour);
        Z().d.f3052a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_band);
        Z().f3040f.f3052a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_mover);
        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ = Z();
        fragmentToolBindingZ.f3042h.setOnClickListener(new com.jorden.karto.setrisokegl.ui.tool.a(0, this));
        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ2 = Z();
        fragmentToolBindingZ2.k.setOnClickListener(new com.jorden.karto.setrisokegl.ui.tool.a(1, this));
        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ3 = Z();
        fragmentToolBindingZ3.n.setOnClickListener(new com.jorden.karto.setrisokegl.ui.tool.a(2, this));
        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ4 = Z();
        fragmentToolBindingZ4.c.setOnClickListener(new com.jorden.karto.setrisokegl.ui.tool.a(3, this));
        androidx.lifecycle.LifecycleOwner lifecycleOwnerT = t();
        kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(lifecycleOwnerT), null, null, new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5(this, null), 3);
    }

    public final void Y(com.jorden.karto.setrisokegl.databinding.PartCompareRowBinding partCompareRowBinding, java.lang.String str, java.lang.String str2, int i) {
        android.content.Context contextR = R();
        int color = contextR.getColor(com.jorden.karto.setrisokegl.R.color.brand_primary);
        int color2 = contextR.getColor(com.jorden.karto.setrisokegl.R.color.brand_on_background);
        android.widget.TextView textView = partCompareRowBinding.b;
        if (str == null) {
            str = q(com.jorden.karto.setrisokegl.R.string.weigh_empty_pan);
            kotlin.jvm.internal.Intrinsics.d(str, "getString(...)");
        }
        textView.setText(str);
        if (str2 == null) {
            str2 = q(com.jorden.karto.setrisokegl.R.string.weigh_empty_pan);
            kotlin.jvm.internal.Intrinsics.d(str2, "getString(...)");
        }
        android.widget.TextView textView2 = partCompareRowBinding.c;
        textView2.setText(str2);
        textView.setTextColor(i == 1 ? color : color2);
        if (i != 2) {
            color = color2;
        }
        textView2.setTextColor(color);
    }

    public final com.jorden.karto.setrisokegl.databinding.FragmentToolBinding Z() {
        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBinding = this.c0;
        if (fragmentToolBinding != null) {
            return fragmentToolBinding;
        }
        throw new java.lang.IllegalArgumentException("Required value was null.");
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
    public final com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel a0() {
        return (com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel) this.d0.getValue();
    }

    public final void b0(com.jorden.karto.setrisokegl.ui.tool.Pan pan) {
        android.view.LayoutInflater layoutInflaterH = this.Q;
        if (layoutInflaterH == null) {
            layoutInflaterH = H(null);
            this.Q = layoutInflaterH;
        }
        android.view.View viewInflate = layoutInflaterH.inflate(com.jorden.karto.setrisokegl.R.layout.dialog_pan_picker, (android.view.ViewGroup) null, false);
        int i = com.jorden.karto.setrisokegl.R.id.pickerEmptyView;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.pickerEmptyView);
        if (textView != null) {
            i = com.jorden.karto.setrisokegl.R.id.pickerFilter;
            com.google.android.material.textfield.TextInputEditText textInputEditText = (com.google.android.material.textfield.TextInputEditText) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.pickerFilter);
            if (textInputEditText != null) {
                i = com.jorden.karto.setrisokegl.R.id.pickerList;
                androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.pickerList);
                if (recyclerView != null) {
                    android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) viewInflate;
                    final com.jorden.karto.setrisokegl.databinding.DialogPanPickerBinding dialogPanPickerBinding = new com.jorden.karto.setrisokegl.databinding.DialogPanPickerBinding(linearLayout, textView, textInputEditText, recyclerView);
                    com.google.android.material.dialog.MaterialAlertDialogBuilder materialAlertDialogBuilder = new com.google.android.material.dialog.MaterialAlertDialogBuilder(R());
                    androidx.appcompat.app.AlertController.AlertParams alertParams = materialAlertDialogBuilder.f56a;
                    alertParams.d = alertParams.f46a.getText(com.jorden.karto.setrisokegl.R.string.weigh_picker_title);
                    alertParams.f51m = linearLayout;
                    androidx.appcompat.app.AlertDialog alertDialogA = materialAlertDialogBuilder.a();
                    final com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter panPickerAdapter = new com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter(new com.jorden.karto.setrisokegl.ui.tool.b(this, pan, alertDialogA));
                    R();
                    recyclerView.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(1));
                    recyclerView.setAdapter(panPickerAdapter);
                    textInputEditText.addTextChangedListener(new android.text.TextWatcher() { // from class: com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$openPicker$$inlined$doAfterTextChanged$1
                        @Override // android.text.TextWatcher
                        public final void afterTextChanged(android.text.Editable editable) {
                            java.lang.String string = editable != null ? editable.toString() : null;
                            if (string == null) {
                                string = "";
                            }
                            com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment.c0(this.f3184a, panPickerAdapter, dialogPanPickerBinding, string);
                        }

                        @Override // android.text.TextWatcher
                        public final void beforeTextChanged(java.lang.CharSequence charSequence, int i2, int i3, int i4) {
                        }

                        @Override // android.text.TextWatcher
                        public final void onTextChanged(java.lang.CharSequence charSequence, int i2, int i3, int i4) {
                        }
                    });
                    c0(this, panPickerAdapter, dialogPanPickerBinding, "");
                    alertDialogA.show();
                    return;
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
