package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MotionIndexFragmentArgs implements androidx.navigation.NavArgs {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f3076a;

    @kotlin.Metadata
    public static final class Companion {
    }

    public MotionIndexFragmentArgs(java.lang.String str) {
        this.f3076a = str;
    }

    @kotlin.jvm.JvmStatic
    @org.jetbrains.annotations.NotNull
    public static final com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs fromBundle(@org.jetbrains.annotations.NotNull android.os.Bundle bundle) {
        java.lang.String string;
        kotlin.jvm.internal.Intrinsics.e(bundle, "bundle");
        bundle.setClassLoader(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs.class.getClassLoader());
        if (bundle.containsKey("tagKey")) {
            string = bundle.getString("tagKey");
            if (string == null) {
                throw new java.lang.IllegalArgumentException("Argument \"tagKey\" is marked as non-null but was passed a null value.");
            }
        } else {
            string = "";
        }
        return new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs(string);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs) && kotlin.jvm.internal.Intrinsics.a(this.f3076a, ((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentArgs) obj).f3076a);
    }

    public final int hashCode() {
        return this.f3076a.hashCode();
    }

    public final java.lang.String toString() {
        return androidx.activity.h.j(new java.lang.StringBuilder("MotionIndexFragmentArgs(tagKey="), this.f3076a, ")");
    }
}
