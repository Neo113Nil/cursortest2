package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class StokerLogUiState {

    /* renamed from: a, reason: collision with root package name */
    public final int f3153a;
    public final int b;
    public final java.util.List c;
    public final java.util.List d;

    public StokerLogUiState(int i, int i2, java.util.List badges, java.util.List recentLinks) {
        kotlin.jvm.internal.Intrinsics.e(badges, "badges");
        kotlin.jvm.internal.Intrinsics.e(recentLinks, "recentLinks");
        this.f3153a = i;
        this.b = i2;
        this.c = badges;
        this.d = recentLinks;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState stokerLogUiState = (com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState) obj;
        return this.f3153a == stokerLogUiState.f3153a && this.b == stokerLogUiState.b && kotlin.jvm.internal.Intrinsics.a(this.c, stokerLogUiState.c) && kotlin.jvm.internal.Intrinsics.a(this.d, stokerLogUiState.d);
    }

    public final int hashCode() {
        return this.d.hashCode() + ((this.c.hashCode() + ((java.lang.Integer.hashCode(this.b) + (java.lang.Integer.hashCode(this.f3153a) * 31)) * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "StokerLogUiState(totalScore=" + this.f3153a + ", triedTotal=" + this.b + ", badges=" + this.c + ", recentLinks=" + this.d + ")";
    }
}
