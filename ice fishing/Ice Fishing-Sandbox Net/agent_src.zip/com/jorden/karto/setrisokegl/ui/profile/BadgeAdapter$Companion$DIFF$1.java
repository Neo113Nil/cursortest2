package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class BadgeAdapter$Companion$DIFF$1 extends androidx.recyclerview.widget.DiffUtil.ItemCallback<com.jorden.karto.setrisokegl.data.model.Badge> {
    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean a(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.Badge) obj).equals((com.jorden.karto.setrisokegl.data.model.Badge) obj2);
    }

    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean b(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.Badge) obj).f2951a == ((com.jorden.karto.setrisokegl.data.model.Badge) obj2).f2951a;
    }
}
