package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class SplashActivity extends androidx.appcompat.app.AppCompatActivity {
    public static final /* synthetic */ int C = 0;
    public final java.lang.Object A = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.splash.SplashViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$special$$inlined$viewModel$default$1
        @Override // kotlin.jvm.functions.Function0
        public final java.lang.Object d() {
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.b;
            return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.splash.SplashViewModel.class), splashActivity.p(), splashActivity.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(splashActivity), null);
        }
    });
    public com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding B;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
    public final com.jorden.karto.setrisokegl.ui.splash.SplashViewModel A() {
        return (com.jorden.karto.setrisokegl.ui.splash.SplashViewModel) this.A.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        if (androidx.appcompat.app.AppCompatDelegate.b != 1) {
            androidx.appcompat.app.AppCompatDelegate.b = 1;
            synchronized (androidx.appcompat.app.AppCompatDelegate.f62h) {
                try {
                    java.util.Iterator it = androidx.appcompat.app.AppCompatDelegate.f61g.iterator();
                    while (true) {
                        androidx.collection.IndexBasedArrayIterator indexBasedArrayIterator = (androidx.collection.IndexBasedArrayIterator) it;
                        if (!indexBasedArrayIterator.hasNext()) {
                            break;
                        }
                        androidx.appcompat.app.AppCompatDelegate appCompatDelegate = (androidx.appcompat.app.AppCompatDelegate) ((java.lang.ref.WeakReference) indexBasedArrayIterator.next()).get();
                        if (appCompatDelegate != null) {
                            appCompatDelegate.d();
                        }
                    }
                } finally {
                }
            }
        }
        androidx.activity.EdgeToEdge.a(this, new androidx.activity.SystemBarStyle(), new androidx.activity.SystemBarStyle());
        super.onCreate(bundle);
        android.view.View viewInflate = getLayoutInflater().inflate(com.jorden.karto.setrisokegl.R.layout.activity_splash, (android.view.ViewGroup) null, false);
        int i = com.jorden.karto.setrisokegl.R.id.btn_retry;
        com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.btn_retry);
        if (materialButton != null) {
            i = com.jorden.karto.setrisokegl.R.id.error_container;
            androidx.constraintlayout.widget.ConstraintLayout constraintLayout = (androidx.constraintlayout.widget.ConstraintLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.error_container);
            if (constraintLayout != null) {
                i = com.jorden.karto.setrisokegl.R.id.error_message;
                if (((android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.error_message)) != null) {
                    i = com.jorden.karto.setrisokegl.R.id.error_title;
                    if (((android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.error_title)) != null) {
                        i = com.jorden.karto.setrisokegl.R.id.loading_label;
                        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.loading_label);
                        if (textView != null) {
                            i = com.jorden.karto.setrisokegl.R.id.progress_indicator;
                            com.google.android.material.progressindicator.CircularProgressIndicator circularProgressIndicator = (com.google.android.material.progressindicator.CircularProgressIndicator) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.progress_indicator);
                            if (circularProgressIndicator != null) {
                                androidx.constraintlayout.widget.ConstraintLayout constraintLayout2 = (androidx.constraintlayout.widget.ConstraintLayout) viewInflate;
                                this.B = new com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding(constraintLayout2, materialButton, constraintLayout, textView, circularProgressIndicator);
                                setContentView(constraintLayout2);
                                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding = this.B;
                                if (activitySplashBinding == null) {
                                    kotlin.jvm.internal.Intrinsics.k("binding");
                                    throw null;
                                }
                                androidx.core.view.ViewCompat.G(activitySplashBinding.f3018a, new com.google.android.material.carousel.b());
                                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding2 = this.B;
                                if (activitySplashBinding2 == null) {
                                    kotlin.jvm.internal.Intrinsics.k("binding");
                                    throw null;
                                }
                                final int i2 = 0;
                                activitySplashBinding2.c.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.splash.a
                                    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity b;

                                    {
                                        this.b = this;
                                    }

                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(android.view.View view) {
                                        com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading loading = com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading.f3175a;
                                        com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.b;
                                        switch (i2) {
                                            case 0:
                                                int i3 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                                                com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModelA = splashActivity.A();
                                                splashViewModelA.d.setValue(loading);
                                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(splashViewModelA), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(splashViewModelA, null), 3);
                                                break;
                                            default:
                                                int i4 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                                                com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModelA2 = splashActivity.A();
                                                splashViewModelA2.d.setValue(loading);
                                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(splashViewModelA2), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(splashViewModelA2, null), 3);
                                                break;
                                        }
                                    }
                                });
                                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding3 = this.B;
                                if (activitySplashBinding3 == null) {
                                    kotlin.jvm.internal.Intrinsics.k("binding");
                                    throw null;
                                }
                                final int i3 = 1;
                                activitySplashBinding3.b.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.splash.a
                                    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity b;

                                    {
                                        this.b = this;
                                    }

                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(android.view.View view) {
                                        com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading loading = com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading.f3175a;
                                        com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.b;
                                        switch (i3) {
                                            case 0:
                                                int i32 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                                                com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModelA = splashActivity.A();
                                                splashViewModelA.d.setValue(loading);
                                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(splashViewModelA), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(splashViewModelA, null), 3);
                                                break;
                                            default:
                                                int i4 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                                                com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModelA2 = splashActivity.A();
                                                splashViewModelA2.d.setValue(loading);
                                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(splashViewModelA2), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(splashViewModelA2, null), 3);
                                                break;
                                        }
                                    }
                                });
                                d().a(this, new androidx.activity.OnBackPressedCallback() { // from class: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$registerBackHandling$1
                                    {
                                        super(true);
                                    }

                                    @Override // androidx.activity.OnBackPressedCallback
                                    public final void e() {
                                        int i4 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                                        com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.d;
                                        if (splashActivity.A().e.getValue() instanceof com.jorden.karto.setrisokegl.ui.splash.SplashState.Error) {
                                            com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModelA = splashActivity.A();
                                            splashViewModelA.d.setValue(com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading.f3175a);
                                            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(splashViewModelA), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(splashViewModelA, null), 3);
                                        }
                                    }
                                });
                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1(this, null), 3);
                                kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeEffects$1(this, null), 3);
                                return;
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
