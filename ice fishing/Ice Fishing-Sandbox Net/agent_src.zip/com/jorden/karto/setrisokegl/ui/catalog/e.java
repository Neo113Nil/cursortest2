package com.jorden.karto.setrisokegl.ui.catalog;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements android.view.View.OnClickListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f3088a;
    public final /* synthetic */ androidx.recyclerview.widget.ListAdapter b;
    public final /* synthetic */ java.lang.Object c;

    public /* synthetic */ e(androidx.recyclerview.widget.ListAdapter listAdapter, java.lang.Object obj, int i) {
        this.f3088a = i;
        this.b = listAdapter;
        this.c = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(android.view.View view) throws android.content.res.Resources.NotFoundException {
        java.lang.Object obj = this.c;
        androidx.recyclerview.widget.ListAdapter listAdapter = this.b;
        switch (this.f3088a) {
            case 0:
                int i = com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter.BandHolder.w;
                ((com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter) listAdapter).f3084f.m((com.jorden.karto.setrisokegl.data.model.MoveEntry) obj);
                break;
            case 1:
                int i2 = com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.LinkHolder.w;
                ((com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter) listAdapter).f3147f.m((com.jorden.karto.setrisokegl.data.model.Move) obj);
                break;
            default:
                int i3 = com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.ChoiceHolder.w;
                ((com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter) listAdapter).f3183f.m((com.jorden.karto.setrisokegl.data.model.Move) obj);
                break;
        }
    }
}
