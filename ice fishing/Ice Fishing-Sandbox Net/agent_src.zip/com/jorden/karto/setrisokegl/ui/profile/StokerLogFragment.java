package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class StokerLogFragment extends androidx.fragment.app.Fragment {
    public com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding c0;
    public final java.lang.Object d0;
    public com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter e0;
    public com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter f0;

    @kotlin.Metadata
    public static final class Companion {
    }

    public StokerLogFragment() {
        final com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$special$$inlined$viewModel$default$1 stokerLogFragment$special$$inlined$viewModel$default$1 = new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$special$$inlined$viewModel$default$1(this);
        this.d0 = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$special$$inlined$viewModel$default$2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                androidx.lifecycle.ViewModelStore viewModelStoreP = stokerLogFragment$special$$inlined$viewModel$default$1.b.p();
                com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment = this.b;
                return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel.class), viewModelStoreP, stokerLogFragment.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(stokerLogFragment), null);
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    public final android.view.View D(android.view.LayoutInflater inflater, android.view.ViewGroup viewGroup, android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(inflater, "inflater");
        android.view.View viewInflate = inflater.inflate(com.jorden.karto.setrisokegl.R.layout.fragment_profile, viewGroup, false);
        int i = com.jorden.karto.setrisokegl.R.id.badgeGrid;
        androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.badgeGrid);
        if (recyclerView != null) {
            i = com.jorden.karto.setrisokegl.R.id.recentEmptyGroup;
            android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.recentEmptyGroup);
            if (linearLayout != null) {
                i = com.jorden.karto.setrisokegl.R.id.recentLinkList;
                androidx.recyclerview.widget.RecyclerView recyclerView2 = (androidx.recyclerview.widget.RecyclerView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.recentLinkList);
                if (recyclerView2 != null) {
                    i = com.jorden.karto.setrisokegl.R.id.resetButton;
                    com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.resetButton);
                    if (materialButton != null) {
                        i = com.jorden.karto.setrisokegl.R.id.totalScoreCaption;
                        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.totalScoreCaption);
                        if (textView != null) {
                            i = com.jorden.karto.setrisokegl.R.id.totalScoreView;
                            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.totalScoreView);
                            if (textView2 != null) {
                                this.c0 = new com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding((androidx.core.widget.NestedScrollView) viewInflate, recyclerView, linearLayout, recyclerView2, materialButton, textView, textView2);
                                androidx.core.widget.NestedScrollView nestedScrollView = X().f3036a;
                                kotlin.jvm.internal.Intrinsics.d(nestedScrollView, "getRoot(...)");
                                return nestedScrollView;
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.fragment.app.Fragment
    public final void F() {
        this.I = true;
        this.c0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public final void N(android.view.View view) {
        kotlin.jvm.internal.Intrinsics.e(view, "view");
        this.e0 = new com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter(com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter.f3145f);
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBindingX = X();
        R();
        fragmentProfileBindingX.b.setLayoutManager(new androidx.recyclerview.widget.GridLayoutManager());
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBindingX2 = X();
        com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter badgeAdapter = this.e0;
        if (badgeAdapter == null) {
            kotlin.jvm.internal.Intrinsics.k("badgeAdapter");
            throw null;
        }
        fragmentProfileBindingX2.b.setAdapter(badgeAdapter);
        this.f0 = new com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter(new com.jorden.karto.setrisokegl.ui.profile.a(this));
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBindingX3 = X();
        R();
        fragmentProfileBindingX3.d.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(1));
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBindingX4 = X();
        com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter recentLinkAdapter = this.f0;
        if (recentLinkAdapter == null) {
            kotlin.jvm.internal.Intrinsics.k("recentLinkAdapter");
            throw null;
        }
        fragmentProfileBindingX4.d.setAdapter(recentLinkAdapter);
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBindingX5 = X();
        fragmentProfileBindingX5.e.setOnClickListener(new android.view.View.OnClickListener() { // from class: com.jorden.karto.setrisokegl.ui.profile.b
            /* JADX WARN: Type inference failed for: r2v4, types: [com.jorden.karto.setrisokegl.ui.profile.c] */
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                final com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment = this.f3160a;
                com.google.android.material.dialog.MaterialAlertDialogBuilder materialAlertDialogBuilder = new com.google.android.material.dialog.MaterialAlertDialogBuilder(stokerLogFragment.R());
                androidx.appcompat.app.AlertController.AlertParams alertParams = materialAlertDialogBuilder.f56a;
                alertParams.d = alertParams.f46a.getText(com.jorden.karto.setrisokegl.R.string.log_reset_title);
                alertParams.f47f = alertParams.f46a.getText(com.jorden.karto.setrisokegl.R.string.log_reset_body);
                ?? r2 = new android.content.DialogInterface.OnClickListener() { // from class: com.jorden.karto.setrisokegl.ui.profile.c
                    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object, kotlin.Lazy] */
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(android.content.DialogInterface dialogInterface, int i) {
                        com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment2 = stokerLogFragment;
                        com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel = (com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel) stokerLogFragment2.d0.getValue();
                        stokerLogViewModel.getClass();
                        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(stokerLogViewModel), null, null, new com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$onResetConfirmed$1(stokerLogViewModel, null), 3);
                        com.google.android.material.snackbar.Snackbar.g(stokerLogFragment2.X().f3036a, com.jorden.karto.setrisokegl.R.string.log_reset_done).h();
                    }
                };
                android.view.ContextThemeWrapper contextThemeWrapper = alertParams.f46a;
                alertParams.f48g = contextThemeWrapper.getText(com.jorden.karto.setrisokegl.R.string.log_reset_confirm);
                alertParams.f49h = r2;
                alertParams.i = contextThemeWrapper.getText(com.jorden.karto.setrisokegl.R.string.log_reset_cancel);
                materialAlertDialogBuilder.a().show();
            }
        });
        androidx.lifecycle.LifecycleOwner lifecycleOwnerT = t();
        kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(lifecycleOwnerT), null, null, new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3(this, null), 3);
    }

    public final com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding X() {
        com.jorden.karto.setrisokegl.databinding.FragmentProfileBinding fragmentProfileBinding = this.c0;
        if (fragmentProfileBinding != null) {
            return fragmentProfileBinding;
        }
        throw new java.lang.IllegalArgumentException("Required value was null.");
    }
}
