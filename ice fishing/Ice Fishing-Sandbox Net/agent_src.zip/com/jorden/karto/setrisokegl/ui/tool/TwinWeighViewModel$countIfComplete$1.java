package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$countIfComplete$1", f = "TwinWeighViewModel.kt", l = {92}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class TwinWeighViewModel$countIfComplete$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3196f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel f3197g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TwinWeighViewModel$countIfComplete$1(com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel twinWeighViewModel, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3197g = twinWeighViewModel;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$countIfComplete$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$countIfComplete$1(this.f3197g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3196f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.domain.usecase.RecordWeighInUseCase recordWeighInUseCase = this.f3197g.d;
            this.f3196f = 1;
            java.lang.Object objB = recordWeighInUseCase.f3063a.b(this);
            if (objB != coroutineSingletons) {
                objB = unit;
            }
            if (objB == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return unit;
    }
}
