package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EffortSheetFragment$special$$inlined$viewModel$default$1 implements kotlin.jvm.functions.Function0<androidx.fragment.app.Fragment> {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

    public EffortSheetFragment$special$$inlined$viewModel$default$1(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment) {
        this.b = effortSheetFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        return this.b;
    }
}
