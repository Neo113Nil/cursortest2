package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class Motion {
}
