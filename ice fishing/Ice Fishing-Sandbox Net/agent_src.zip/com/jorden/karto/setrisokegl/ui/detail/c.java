package com.jorden.karto.setrisokegl.ui.detail;

/* loaded from: classes.dex */
public final /* synthetic */ class c implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

    public /* synthetic */ c(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment) {
        this.b = effortSheetFragment;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) {
        java.lang.Long l = (java.lang.Long) obj;
        kotlin.jvm.internal.Intrinsics.b(l);
        long epochDay = java.time.Instant.ofEpochMilli(l.longValue()).atZone(java.time.ZoneOffset.UTC).toLocalDate().toEpochDay();
        com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY = this.b.Y();
        effortSheetViewModelY.getClass();
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onLastGoPicked$1(effortSheetViewModelY, epochDay, null), 3);
        return kotlin.Unit.f3201a;
    }
}
