package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class FurnaceFloorFragment extends androidx.fragment.app.Fragment {
    public com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding c0;
    public final java.lang.Object d0;

    public FurnaceFloorFragment() {
        final com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$special$$inlined$viewModel$default$1 furnaceFloorFragment$special$$inlined$viewModel$default$1 = new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$special$$inlined$viewModel$default$1(this);
        this.d0 = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$special$$inlined$viewModel$default$2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                androidx.lifecycle.ViewModelStore viewModelStoreP = furnaceFloorFragment$special$$inlined$viewModel$default$1.b.p();
                com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.b;
                return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel.class), viewModelStoreP, furnaceFloorFragment.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(furnaceFloorFragment), null);
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    public final android.view.View D(android.view.LayoutInflater inflater, android.view.ViewGroup viewGroup, android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(inflater, "inflater");
        android.view.View viewInflate = inflater.inflate(com.jorden.karto.setrisokegl.R.layout.fragment_home, viewGroup, false);
        int i = com.jorden.karto.setrisokegl.R.id.fanAnotherButton;
        com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.fanAnotherButton);
        if (materialButton != null) {
            i = com.jorden.karto.setrisokegl.R.id.heroBand;
            android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroBand);
            if (linearLayout != null) {
                i = com.jorden.karto.setrisokegl.R.id.heroBandLabel;
                android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroBandLabel);
                if (textView != null) {
                    i = com.jorden.karto.setrisokegl.R.id.heroCost;
                    android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroCost);
                    if (textView2 != null) {
                        i = com.jorden.karto.setrisokegl.R.id.heroDial;
                        com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView = (com.jorden.karto.setrisokegl.ui.common.EmberDialView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroDial);
                        if (emberDialView != null) {
                            i = com.jorden.karto.setrisokegl.R.id.heroFigure;
                            android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroFigure);
                            if (textView3 != null) {
                                i = com.jorden.karto.setrisokegl.R.id.heroMark;
                                android.widget.TextView textView4 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroMark);
                                if (textView4 != null) {
                                    i = com.jorden.karto.setrisokegl.R.id.heroMover;
                                    android.widget.TextView textView5 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroMover);
                                    if (textView5 != null) {
                                        i = com.jorden.karto.setrisokegl.R.id.heroName;
                                        android.widget.TextView textView6 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroName);
                                        if (textView6 != null) {
                                            i = com.jorden.karto.setrisokegl.R.id.heroPanel;
                                            android.widget.LinearLayout linearLayout2 = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.heroPanel);
                                            if (linearLayout2 != null) {
                                                i = com.jorden.karto.setrisokegl.R.id.openSheetButton;
                                                com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.openSheetButton);
                                                if (materialButton2 != null) {
                                                    i = com.jorden.karto.setrisokegl.R.id.shortcutChips;
                                                    com.google.android.material.chip.ChipGroup chipGroup = (com.google.android.material.chip.ChipGroup) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.shortcutChips);
                                                    if (chipGroup != null) {
                                                        i = com.jorden.karto.setrisokegl.R.id.toScalesButton;
                                                        com.google.android.material.button.MaterialButton materialButton3 = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.toScalesButton);
                                                        if (materialButton3 != null) {
                                                            this.c0 = new com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding((androidx.core.widget.NestedScrollView) viewInflate, materialButton, linearLayout, textView, textView2, emberDialView, textView3, textView4, textView5, textView6, linearLayout2, materialButton2, chipGroup, materialButton3);
                                                            androidx.core.widget.NestedScrollView nestedScrollView = X().f3030a;
                                                            kotlin.jvm.internal.Intrinsics.d(nestedScrollView, "getRoot(...)");
                                                            return nestedScrollView;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.fragment.app.Fragment
    public final void F() {
        this.I = true;
        this.c0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public final void N(android.view.View view) {
        kotlin.jvm.internal.Intrinsics.e(view, "view");
        com.google.android.material.chip.ChipGroup chipGroup = X().f3035m;
        chipGroup.removeAllViews();
        java.util.Iterator it = ((kotlin.collections.AbstractList) com.jorden.karto.setrisokegl.data.model.MoveTag.k).iterator();
        while (it.hasNext()) {
            final com.jorden.karto.setrisokegl.data.model.MoveTag moveTag = (com.jorden.karto.setrisokegl.data.model.MoveTag) it.next();
            com.google.android.material.chip.Chip chip = new com.google.android.material.chip.Chip(R(), null);
            chip.setText(moveTag.c);
            chip.setCheckable(false);
            chip.setOnClickListener(new android.view.View.OnClickListener() { // from class: com.jorden.karto.setrisokegl.ui.home.c
                @Override // android.view.View.OnClickListener
                public final void onClick(android.view.View view2) throws android.content.res.Resources.NotFoundException {
                    com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(this.f3144a), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToIndex(moveTag.b));
                }
            });
            chipGroup.addView(chip);
        }
        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX = X();
        final int i = 2;
        fragmentHomeBindingX.b.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.home.a
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment b;

            {
                this.b = this;
            }

            /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
            /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object, kotlin.Lazy] */
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) throws android.content.res.Resources.NotFoundException {
                switch (i) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToSheet(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment2 = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment2), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToWeigh(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment2.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment3 = this.b;
                        final android.widget.LinearLayout linearLayout = furnaceFloorFragment3.X().k;
                        final com.jorden.karto.setrisokegl.ui.home.b bVar = new com.jorden.karto.setrisokegl.ui.home.b(furnaceFloorFragment3);
                        kotlin.jvm.internal.Intrinsics.d(linearLayout.getContext(), "getContext(...)");
                        final long integer = r7.getResources().getInteger(com.jorden.karto.setrisokegl.R.integer.motion_normal) / 2;
                        linearLayout.animate().cancel();
                        linearLayout.animate().alpha(0.0f).setDuration(integer).withEndAction(new java.lang.Runnable() { // from class: com.jorden.karto.setrisokegl.ui.common.a
                            @Override // java.lang.Runnable
                            public final void run() {
                                bVar.d();
                                linearLayout.animate().alpha(1.0f).setDuration(integer).start();
                            }
                        }).start();
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX2 = X();
        final int i2 = 0;
        fragmentHomeBindingX2.l.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.home.a
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment b;

            {
                this.b = this;
            }

            /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
            /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object, kotlin.Lazy] */
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) throws android.content.res.Resources.NotFoundException {
                switch (i2) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToSheet(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment2 = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment2), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToWeigh(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment2.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment3 = this.b;
                        final android.widget.LinearLayout linearLayout = furnaceFloorFragment3.X().k;
                        final com.jorden.karto.setrisokegl.ui.home.b bVar = new com.jorden.karto.setrisokegl.ui.home.b(furnaceFloorFragment3);
                        kotlin.jvm.internal.Intrinsics.d(linearLayout.getContext(), "getContext(...)");
                        final long integer = r7.getResources().getInteger(com.jorden.karto.setrisokegl.R.integer.motion_normal) / 2;
                        linearLayout.animate().cancel();
                        linearLayout.animate().alpha(0.0f).setDuration(integer).withEndAction(new java.lang.Runnable() { // from class: com.jorden.karto.setrisokegl.ui.common.a
                            @Override // java.lang.Runnable
                            public final void run() {
                                bVar.d();
                                linearLayout.animate().alpha(1.0f).setDuration(integer).start();
                            }
                        }).start();
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBindingX3 = X();
        final int i3 = 1;
        fragmentHomeBindingX3.n.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.home.a
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment b;

            {
                this.b = this;
            }

            /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
            /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object, kotlin.Lazy] */
            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) throws android.content.res.Resources.NotFoundException {
                switch (i3) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToSheet(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment2 = this.b;
                        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(furnaceFloorFragment2), new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToWeigh(((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) furnaceFloorFragment2.d0.getValue()).d.getValue()).f3142a.f2953a));
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment3 = this.b;
                        final android.widget.LinearLayout linearLayout = furnaceFloorFragment3.X().k;
                        final com.jorden.karto.setrisokegl.ui.home.b bVar = new com.jorden.karto.setrisokegl.ui.home.b(furnaceFloorFragment3);
                        kotlin.jvm.internal.Intrinsics.d(linearLayout.getContext(), "getContext(...)");
                        final long integer = r7.getResources().getInteger(com.jorden.karto.setrisokegl.R.integer.motion_normal) / 2;
                        linearLayout.animate().cancel();
                        linearLayout.animate().alpha(0.0f).setDuration(integer).withEndAction(new java.lang.Runnable() { // from class: com.jorden.karto.setrisokegl.ui.common.a
                            @Override // java.lang.Runnable
                            public final void run() {
                                bVar.d();
                                linearLayout.animate().alpha(1.0f).setDuration(integer).start();
                            }
                        }).start();
                        break;
                }
            }
        });
        androidx.lifecycle.LifecycleOwner lifecycleOwnerT = t();
        kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(lifecycleOwnerT), null, null, new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment$onViewCreated$4(this, null), 3);
    }

    public final com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding X() {
        com.jorden.karto.setrisokegl.databinding.FragmentHomeBinding fragmentHomeBinding = this.c0;
        if (fragmentHomeBinding != null) {
            return fragmentHomeBinding;
        }
        throw new java.lang.IllegalArgumentException("Required value was null.");
    }
}
