package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class BadgeAdapter extends androidx.recyclerview.widget.ListAdapter<com.jorden.karto.setrisokegl.data.model.Badge, com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter.BadgeHolder> {

    /* renamed from: f, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter$Companion$DIFF$1 f3145f = new com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter$Companion$DIFF$1();

    @kotlin.Metadata
    public static final class BadgeHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public final com.jorden.karto.setrisokegl.databinding.ItemBadgeMarkBinding u;

        @kotlin.Metadata
        public static final class Companion {
        }

        public BadgeHolder(com.jorden.karto.setrisokegl.databinding.ItemBadgeMarkBinding itemBadgeMarkBinding) {
            super(itemBadgeMarkBinding.f3045a);
            this.u = itemBadgeMarkBinding;
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final void g(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int i) {
        java.lang.Object obj = this.d.f1415f.get(i);
        kotlin.jvm.internal.Intrinsics.d(obj, "getItem(...)");
        com.jorden.karto.setrisokegl.data.model.Badge badge = (com.jorden.karto.setrisokegl.data.model.Badge) obj;
        com.jorden.karto.setrisokegl.databinding.ItemBadgeMarkBinding itemBadgeMarkBinding = ((com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter.BadgeHolder) viewHolder).u;
        android.content.Context context = itemBadgeMarkBinding.f3045a.getContext();
        com.jorden.karto.setrisokegl.data.model.BadgeKind badgeKind = badge.f2951a;
        int i2 = badge.b;
        int i3 = badgeKind.d;
        boolean z = i2 >= i3;
        com.jorden.karto.setrisokegl.ui.common.BadgeRingView badgeRingView = itemBadgeMarkBinding.d;
        badgeRingView.f3089a = i2 >= 0 ? i2 : 0;
        badgeRingView.b = i3 >= 1 ? i3 : 1;
        badgeRingView.c = z;
        badgeRingView.invalidate();
        itemBadgeMarkBinding.b.setText(badgeKind.b);
        itemBadgeMarkBinding.c.setText(badgeKind.c);
        itemBadgeMarkBinding.f3046f.setText(context.getString(com.jorden.karto.setrisokegl.R.string.badge_progress, java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(i3)));
        itemBadgeMarkBinding.e.setAlpha(i2 >= badgeKind.d ? 1.0f : 0.4f);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final androidx.recyclerview.widget.RecyclerView.ViewHolder h(android.view.ViewGroup parent, int i) {
        kotlin.jvm.internal.Intrinsics.e(parent, "parent");
        android.view.View viewInflate = android.view.LayoutInflater.from(parent.getContext()).inflate(com.jorden.karto.setrisokegl.R.layout.item_badge_mark, parent, false);
        int i2 = com.jorden.karto.setrisokegl.R.id.badgeName;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.badgeName);
        if (textView != null) {
            i2 = com.jorden.karto.setrisokegl.R.id.badgeRequirement;
            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.badgeRequirement);
            if (textView2 != null) {
                i2 = com.jorden.karto.setrisokegl.R.id.badgeRing;
                com.jorden.karto.setrisokegl.ui.common.BadgeRingView badgeRingView = (com.jorden.karto.setrisokegl.ui.common.BadgeRingView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.badgeRing);
                if (badgeRingView != null) {
                    android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) viewInflate;
                    i2 = com.jorden.karto.setrisokegl.R.id.badgeTally;
                    android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.badgeTally);
                    if (textView3 != null) {
                        return new com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter.BadgeHolder(new com.jorden.karto.setrisokegl.databinding.ItemBadgeMarkBinding(linearLayout, textView, textView2, badgeRingView, linearLayout, textView3));
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
