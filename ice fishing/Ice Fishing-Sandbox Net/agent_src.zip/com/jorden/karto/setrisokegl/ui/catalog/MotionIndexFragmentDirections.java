package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MotionIndexFragmentDirections {

    @kotlin.Metadata
    public static final class ActionIndexToSheet implements androidx.navigation.NavDirections {

        /* renamed from: a, reason: collision with root package name */
        public final java.lang.String f3077a;

        public ActionIndexToSheet(java.lang.String str) {
            this.f3077a = str;
        }

        @Override // androidx.navigation.NavDirections
        public final android.os.Bundle a() {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putString("moveId", this.f3077a);
            return bundle;
        }

        @Override // androidx.navigation.NavDirections
        public final int b() {
            return com.jorden.karto.setrisokegl.R.id.actionIndexToSheet;
        }

        public final boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentDirections.ActionIndexToSheet) && kotlin.jvm.internal.Intrinsics.a(this.f3077a, ((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentDirections.ActionIndexToSheet) obj).f3077a);
        }

        public final int hashCode() {
            return this.f3077a.hashCode();
        }

        public final java.lang.String toString() {
            return androidx.activity.h.j(new java.lang.StringBuilder("ActionIndexToSheet(moveId="), this.f3077a, ")");
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }
}
