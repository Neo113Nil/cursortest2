package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class StokerLogViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.domain.usecase.TotalScoreUseCase b;
    public final com.jorden.karto.setrisokegl.domain.usecase.ObserveBadgesUseCase c;
    public final com.jorden.karto.setrisokegl.domain.usecase.ClearLogUseCase d;
    public final kotlinx.coroutines.flow.MutableStateFlow e;

    /* renamed from: f, reason: collision with root package name */
    public final kotlinx.coroutines.flow.StateFlow f3154f;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$1", f = "StokerLogViewModel.kt", l = {36}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3155f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.domain.usecase.ObserveLogUseCase f3156g;

        /* renamed from: h, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel f3157h;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.domain.usecase.ObserveLogUseCase observeLogUseCase, com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3156g = observeLogUseCase;
            this.f3157h = stokerLogViewModel;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel.AnonymousClass1(this.f3156g, this.f3157h, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3155f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                kotlinx.coroutines.flow.FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1 flowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1E = this.f3156g.f3061a.e();
                final com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel = this.f3157h;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        java.lang.Object value;
                        int i2;
                        int i3;
                        int i4;
                        int i5;
                        java.util.ArrayList arrayList;
                        java.util.List recentLinks;
                        int i6;
                        com.jorden.karto.setrisokegl.data.repository.LogSnapshot logSnapshot = (com.jorden.karto.setrisokegl.data.repository.LogSnapshot) obj2;
                        com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel2 = stokerLogViewModel;
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = stokerLogViewModel2.e;
                        do {
                            value = mutableStateFlow.getValue();
                            com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState stokerLogUiState = (com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState) value;
                            java.util.List entries = logSnapshot.f2995a;
                            stokerLogViewModel2.b.getClass();
                            kotlin.jvm.internal.Intrinsics.e(entries, "entries");
                            java.util.ArrayList arrayList2 = new java.util.ArrayList();
                            for (T t : entries) {
                                if (((com.jorden.karto.setrisokegl.data.model.MoveEntry) t).b.c) {
                                    arrayList2.add(t);
                                }
                            }
                            java.util.Iterator it = arrayList2.iterator();
                            int i7 = 0;
                            i2 = 0;
                            while (it.hasNext()) {
                                i2 += ((com.jorden.karto.setrisokegl.data.model.MoveEntry) it.next()).f2959a.f2954f;
                            }
                            java.util.List list = logSnapshot.f2995a;
                            if (list == null || !list.isEmpty()) {
                                java.util.Iterator<T> it2 = list.iterator();
                                i3 = 0;
                                while (it2.hasNext()) {
                                    if (((com.jorden.karto.setrisokegl.data.model.MoveEntry) it2.next()).b.c && (i3 = i3 + 1) < 0) {
                                        kotlin.collections.CollectionsKt.I();
                                        throw null;
                                    }
                                }
                            } else {
                                i3 = 0;
                            }
                            stokerLogViewModel2.c.getClass();
                            if (list == null || !list.isEmpty()) {
                                java.util.Iterator<T> it3 = list.iterator();
                                i4 = 0;
                                while (it3.hasNext()) {
                                    if (((com.jorden.karto.setrisokegl.data.model.MoveEntry) it3.next()).b.c && (i4 = i4 + 1) < 0) {
                                        kotlin.collections.CollectionsKt.I();
                                        throw null;
                                    }
                                }
                            } else {
                                i4 = 0;
                            }
                            if (list == null || !list.isEmpty()) {
                                java.util.Iterator<T> it4 = list.iterator();
                                i5 = 0;
                                while (it4.hasNext()) {
                                    if (((com.jorden.karto.setrisokegl.data.model.MoveEntry) it4.next()).b.b && (i5 = i5 + 1) < 0) {
                                        kotlin.collections.CollectionsKt.I();
                                        throw null;
                                    }
                                }
                            } else {
                                i5 = 0;
                            }
                            if (list == null || !list.isEmpty()) {
                                java.util.Iterator<T> it5 = list.iterator();
                                while (it5.hasNext()) {
                                    if (!kotlin.text.StringsKt.m(((com.jorden.karto.setrisokegl.data.model.MoveEntry) it5.next()).b.e) && (i7 = i7 + 1) < 0) {
                                        kotlin.collections.CollectionsKt.I();
                                        throw null;
                                    }
                                }
                            }
                            java.util.List list2 = com.jorden.karto.setrisokegl.data.model.BadgeKind.f2952f;
                            arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.m(list2, 10));
                            java.util.Iterator it6 = ((kotlin.collections.AbstractList) list2).iterator();
                            while (it6.hasNext()) {
                                com.jorden.karto.setrisokegl.data.model.BadgeKind badgeKind = (com.jorden.karto.setrisokegl.data.model.BadgeKind) it6.next();
                                int iOrdinal = badgeKind.ordinal();
                                if (iOrdinal == 0 || iOrdinal == 1 || iOrdinal == 2) {
                                    i6 = i4;
                                } else if (iOrdinal == 3) {
                                    i6 = i5;
                                } else if (iOrdinal == 4) {
                                    i6 = logSnapshot.c;
                                } else {
                                    if (iOrdinal != 5) {
                                        throw new kotlin.NoWhenBranchMatchedException();
                                    }
                                    i6 = i7;
                                }
                                int i8 = badgeKind.d;
                                if (i6 > i8) {
                                    i6 = i8;
                                }
                                arrayList.add(new com.jorden.karto.setrisokegl.data.model.Badge(badgeKind, i6));
                            }
                            stokerLogUiState.getClass();
                            recentLinks = logSnapshot.b;
                            kotlin.jvm.internal.Intrinsics.e(recentLinks, "recentLinks");
                        } while (!mutableStateFlow.h(value, new com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState(i2, i3, arrayList, recentLinks)));
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3155f = 1;
                if (flowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1E.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            return kotlin.Unit.f3201a;
        }
    }

    public StokerLogViewModel(com.jorden.karto.setrisokegl.domain.usecase.ObserveLogUseCase observeLogUseCase, com.jorden.karto.setrisokegl.domain.usecase.TotalScoreUseCase totalScoreUseCase, com.jorden.karto.setrisokegl.domain.usecase.ObserveBadgesUseCase observeBadgesUseCase, com.jorden.karto.setrisokegl.domain.usecase.ClearLogUseCase clearLogUseCase) {
        this.b = totalScoreUseCase;
        this.c = observeBadgesUseCase;
        this.d = clearLogUseCase;
        kotlin.collections.EmptyList emptyList = kotlin.collections.EmptyList.b;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(new com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState(0, 0, emptyList, emptyList));
        this.e = mutableStateFlowA;
        this.f3154f = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel.AnonymousClass1(observeLogUseCase, this, null), 3);
    }
}
