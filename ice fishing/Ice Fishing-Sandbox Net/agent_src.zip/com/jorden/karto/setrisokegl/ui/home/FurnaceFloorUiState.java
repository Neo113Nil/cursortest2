package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class FurnaceFloorUiState {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.model.Move f3142a;
    public final float b;

    public FurnaceFloorUiState(com.jorden.karto.setrisokegl.data.model.Move hero, float f2) {
        kotlin.jvm.internal.Intrinsics.e(hero, "hero");
        this.f3142a = hero;
        this.b = f2;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState furnaceFloorUiState = (com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f3142a, furnaceFloorUiState.f3142a) && java.lang.Float.compare(this.b, furnaceFloorUiState.b) == 0;
    }

    public final int hashCode() {
        return java.lang.Float.hashCode(this.b) + (this.f3142a.hashCode() * 31);
    }

    public final java.lang.String toString() {
        return "FurnaceFloorUiState(hero=" + this.f3142a + ", ceiling=" + this.b + ")";
    }
}
