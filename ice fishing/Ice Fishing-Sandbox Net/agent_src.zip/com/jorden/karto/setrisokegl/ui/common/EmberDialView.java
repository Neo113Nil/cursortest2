package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EmberDialView extends android.view.View {

    /* renamed from: a, reason: collision with root package name */
    public float f3093a;
    public float b;
    public boolean c;
    public final android.graphics.Paint d;
    public final android.graphics.Paint e;

    /* renamed from: f, reason: collision with root package name */
    public final android.graphics.Paint f3094f;

    /* renamed from: g, reason: collision with root package name */
    public final android.graphics.Paint f3095g;

    /* renamed from: h, reason: collision with root package name */
    public final android.graphics.RectF f3096h;

    @kotlin.Metadata
    public static final class Companion {
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    @kotlin.jvm.JvmOverloads
    public EmberDialView(@org.jetbrains.annotations.NotNull android.content.Context context, @org.jetbrains.annotations.Nullable android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        kotlin.jvm.internal.Intrinsics.e(context, "context");
        this.b = 10.0f;
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.STROKE;
        paint.setStyle(style);
        android.graphics.Paint.Cap cap = android.graphics.Paint.Cap.ROUND;
        paint.setStrokeCap(cap);
        paint.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.mark_track));
        this.d = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_primary));
        this.e = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setStyle(style);
        paint3.setStrokeCap(android.graphics.Paint.Cap.BUTT);
        paint3.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_secondary));
        this.f3094f = paint3;
        android.graphics.Paint paint4 = new android.graphics.Paint(1);
        paint4.setStyle(android.graphics.Paint.Style.FILL);
        paint4.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_secondary));
        this.f3095g = paint4;
        this.f3096h = new android.graphics.RectF();
    }

    public final float getCeiling() {
        return this.b;
    }

    public final boolean getResting() {
        return this.c;
    }

    public final float getValue() {
        return this.f3093a;
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        float f2;
        kotlin.jvm.internal.Intrinsics.e(canvas, "canvas");
        float fMin = java.lang.Math.min(getWidth(), getHeight());
        if (fMin <= 0.0f) {
            return;
        }
        float f3 = fMin * 0.11f;
        android.graphics.Paint paint = this.d;
        paint.setStrokeWidth(f3);
        android.graphics.Paint paint2 = this.e;
        paint2.setStrokeWidth(f3);
        android.graphics.Paint paint3 = this.f3094f;
        paint3.setStrokeWidth(0.3f * f3);
        float width = getWidth() / 2.0f;
        float height = getHeight() / 2.0f;
        float f4 = (fMin - f3) / 2.0f;
        android.graphics.RectF rectF = this.f3096h;
        rectF.set(width - f4, height - f4, width + f4, height + f4);
        canvas.drawArc(rectF, 135.0f, 270.0f, false, paint);
        int i = (int) this.b;
        int i2 = i < 1 ? 1 : i;
        float f5 = f4 - (0.85f * f3);
        if (i2 >= 0) {
            int i3 = 0;
            while (true) {
                double radians = java.lang.Math.toRadians(((i3 * 270.0f) / i2) + 135.0f);
                f2 = f3;
                int i4 = i3;
                int i5 = i2;
                canvas.drawLine((((float) java.lang.Math.cos(radians)) * f5) + width, (((float) java.lang.Math.sin(radians)) * f5) + height, (((float) java.lang.Math.cos(radians)) * f4) + width, (((float) java.lang.Math.sin(radians)) * f4) + height, paint3);
                if (i4 == i5) {
                    break;
                }
                i3 = i4 + 1;
                i2 = i5;
                f3 = f2;
            }
        } else {
            f2 = f3;
        }
        if (this.c) {
            return;
        }
        float f6 = this.f3093a;
        if (f6 > 0.0f) {
            canvas.drawArc(rectF, 135.0f, (f6 / this.b) * 270.0f, false, paint2);
            double radians2 = java.lang.Math.toRadians(((this.f3093a / this.b) * 270.0f) + 135.0f);
            canvas.drawCircle((((float) java.lang.Math.cos(radians2)) * f4) + width, (f4 * ((float) java.lang.Math.sin(radians2))) + height, f2 * 0.62f, this.f3095g);
        }
    }

    public final void setCeiling(float f2) {
        if (f2 <= 0.0f) {
            f2 = 1.0f;
        }
        this.b = f2;
        invalidate();
    }

    public final void setResting(boolean z) {
        this.c = z;
        invalidate();
    }

    public final void setValue(float f2) {
        this.f3093a = kotlin.ranges.RangesKt.a(f2, 0.0f, this.b);
        invalidate();
    }
}
