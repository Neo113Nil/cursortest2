package com.jorden.karto.setrisokegl.ui.tool;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements android.view.View.OnClickListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f3198a;
    public final /* synthetic */ androidx.fragment.app.Fragment b;

    public /* synthetic */ a(int i, androidx.fragment.app.Fragment fragment) {
        this.f3198a = i;
        this.b = fragment;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(android.view.View view) {
        java.lang.Object value;
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiStateA;
        java.lang.Object value2;
        switch (this.f3198a) {
            case 0:
                ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment) this.b).b0(com.jorden.karto.setrisokegl.ui.tool.Pan.b);
                break;
            case 1:
                ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment) this.b).b0(com.jorden.karto.setrisokegl.ui.tool.Pan.c);
                break;
            case 2:
                com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel twinWeighViewModelA0 = ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment) this.b).a0();
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = twinWeighViewModelA0.e;
                do {
                    value = mutableStateFlow.getValue();
                    com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) value;
                    twinWeighUiStateA = com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a(twinWeighUiState, twinWeighUiState.b, twinWeighUiState.f3190a, 0, null, 28);
                    twinWeighViewModelA0.c.getClass();
                } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a(twinWeighUiStateA, null, null, 0, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.a(twinWeighUiStateA.f3190a, twinWeighUiStateA.b), 15)));
            case 3:
                com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel twinWeighViewModelA02 = ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment) this.b).a0();
                twinWeighViewModelA02.f3193h = null;
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow2 = twinWeighViewModelA02.e;
                do {
                    value2 = mutableStateFlow2.getValue();
                } while (!mutableStateFlow2.h(value2, com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a((com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) value2, null, null, 0, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting.f3070a, 12)));
            default:
                com.google.android.material.datepicker.MaterialDatePicker materialDatePicker = (com.google.android.material.datepicker.MaterialDatePicker) this.b;
                materialDatePicker.S0.setEnabled(materialDatePicker.d0().s());
                materialDatePicker.Q0.toggle();
                materialDatePicker.F0 = materialDatePicker.F0 == 1 ? 0 : 1;
                materialDatePicker.h0(materialDatePicker.Q0);
                materialDatePicker.g0();
                break;
        }
    }
}
