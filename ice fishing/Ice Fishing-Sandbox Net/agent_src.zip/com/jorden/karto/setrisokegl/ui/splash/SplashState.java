package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
/* loaded from: classes.dex */
public interface SplashState {

    @kotlin.Metadata
    public static final class Error implements com.jorden.karto.setrisokegl.ui.splash.SplashState {

        /* renamed from: a, reason: collision with root package name */
        public static final com.jorden.karto.setrisokegl.ui.splash.SplashState.Error f3174a = new com.jorden.karto.setrisokegl.ui.splash.SplashState.Error();

        public final boolean equals(java.lang.Object obj) {
            return this == obj || (obj instanceof com.jorden.karto.setrisokegl.ui.splash.SplashState.Error);
        }

        public final int hashCode() {
            return 1263991941;
        }

        public final java.lang.String toString() {
            return "Error";
        }
    }

    @kotlin.Metadata
    public static final class Loading implements com.jorden.karto.setrisokegl.ui.splash.SplashState {

        /* renamed from: a, reason: collision with root package name */
        public static final com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading f3175a = new com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading();

        public final boolean equals(java.lang.Object obj) {
            return this == obj || (obj instanceof com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading);
        }

        public final int hashCode() {
            return 1036148857;
        }

        public final java.lang.String toString() {
            return "Loading";
        }
    }
}
