package com.jorden.karto.setrisokegl.ui.profile;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment b;

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) throws android.content.res.Resources.NotFoundException {
        com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
        kotlin.jvm.internal.Intrinsics.e(move, "move");
        com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(this.b), new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragmentDirections.ActionLogToSheet(move.f2953a));
        return kotlin.Unit.f3201a;
    }
}
