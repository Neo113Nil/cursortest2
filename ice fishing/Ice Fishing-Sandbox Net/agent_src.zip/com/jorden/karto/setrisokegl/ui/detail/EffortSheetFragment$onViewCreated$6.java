package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6", f = "EffortSheetFragment.kt", l = {78}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EffortSheetFragment$onViewCreated$6 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3104f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment f3105g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6$1", f = "EffortSheetFragment.kt", l = {79}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3106f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment f3107g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3107g = effortSheetFragment;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6.AnonymousClass1(this.f3107g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3106f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.f3107g;
                kotlinx.coroutines.flow.StateFlow stateFlow = effortSheetFragment.Y().i;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment.onViewCreated.6.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) throws android.content.res.Resources.NotFoundException {
                        java.lang.String strQ;
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState effortSheetUiState = (com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) obj2;
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment2 = effortSheetFragment;
                        effortSheetFragment2.getClass();
                        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = effortSheetUiState.f3109a;
                        if (moveEntry != null) {
                            android.content.Context contextR = effortSheetFragment2.R();
                            com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX = effortSheetFragment2.X();
                            com.jorden.karto.setrisokegl.data.model.Move move = moveEntry.f2959a;
                            fragmentDetailBindingX.f3029m.setBackgroundColor(contextR.getColor(com.jorden.karto.setrisokegl.ui.common.Tints.a(move.f2953a)));
                            effortSheetFragment2.X().o.setText(move.c);
                            effortSheetFragment2.X().p.setText(move.b);
                            effortSheetFragment2.X().r.setText(move.d.c);
                            effortSheetFragment2.X().n.setCeiling(effortSheetUiState.b);
                            com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView = effortSheetFragment2.X().n;
                            float f2 = move.e;
                            emberDialView.setValue(f2);
                            effortSheetFragment2.X().k.b.setText(effortSheetFragment2.r(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(f2)));
                            effortSheetFragment2.X().f3027h.b.setText(effortSheetFragment2.r(com.jorden.karto.setrisokegl.R.string.kcal_value, java.lang.Integer.valueOf(move.f2954f)));
                            effortSheetFragment2.X().f3026g.b.setText(move.a().b);
                            effortSheetFragment2.X().f3028j.b.setText(move.f2955g);
                            effortSheetFragment2.X().i.b.setText(move.f2956h);
                            effortSheetFragment2.X().q.setText(move.i);
                            com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX2 = effortSheetFragment2.X();
                            com.jorden.karto.setrisokegl.data.model.MoveState moveState = moveEntry.b;
                            fragmentDetailBindingX2.d.setChecked(moveState.b);
                            effortSheetFragment2.X().b.setChecked(moveState.c);
                            com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX3 = effortSheetFragment2.X();
                            java.lang.Long l = moveState.d;
                            if (l != null) {
                                strQ = java.time.LocalDate.ofEpochDay(l.longValue()).format(java.time.format.DateTimeFormatter.ofLocalizedDate(java.time.format.FormatStyle.MEDIUM));
                                kotlin.jvm.internal.Intrinsics.d(strQ, "format(...)");
                            } else {
                                strQ = effortSheetFragment2.q(com.jorden.karto.setrisokegl.R.string.sheet_last_go_unset);
                                kotlin.jvm.internal.Intrinsics.d(strQ, "getString(...)");
                            }
                            fragmentDetailBindingX3.e.setText(strQ);
                            if (!effortSheetFragment2.f0) {
                                effortSheetFragment2.X().f3025f.setText(moveState.e);
                                effortSheetFragment2.f0 = true;
                            }
                        }
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3106f = 1;
                if (stateFlow.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EffortSheetFragment$onViewCreated$6(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3105g = effortSheetFragment;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6(this.f3105g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3104f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.f3105g;
            androidx.lifecycle.LifecycleOwner lifecycleOwnerT = effortSheetFragment.t();
            kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6.AnonymousClass1(effortSheetFragment, null);
            this.f3104f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(lifecycleOwnerT, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
