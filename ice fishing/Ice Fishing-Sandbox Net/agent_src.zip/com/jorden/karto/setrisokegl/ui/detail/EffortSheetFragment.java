package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class EffortSheetFragment extends androidx.fragment.app.Fragment {
    public com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding c0;
    public final java.lang.Object d0;
    public final androidx.navigation.NavArgsLazy e0;
    public boolean f0;

    @kotlin.Metadata
    public static final class Companion {
    }

    public EffortSheetFragment() {
        final com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$special$$inlined$viewModel$default$1 effortSheetFragment$special$$inlined$viewModel$default$1 = new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$special$$inlined$viewModel$default$1(this);
        this.d0 = kotlin.LazyKt.a(kotlin.LazyThreadSafetyMode.c, new kotlin.jvm.functions.Function0<com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel>() { // from class: com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$special$$inlined$viewModel$default$2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                androidx.lifecycle.ViewModelStore viewModelStoreP = effortSheetFragment$special$$inlined$viewModel$default$1.b.p();
                com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.b;
                return org.koin.viewmodel.GetViewModelKt.a(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel.class), viewModelStoreP, effortSheetFragment.c(), null, org.koin.android.ext.android.AndroidKoinScopeExtKt.a(effortSheetFragment), null);
            }
        });
        this.e0 = new androidx.navigation.NavArgsLazy(kotlin.jvm.internal.Reflection.a(com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs.class), new kotlin.jvm.functions.Function0<android.os.Bundle>() { // from class: com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$special$$inlined$navArgs$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object d() {
                com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.c;
                android.os.Bundle bundle = effortSheetFragment.f1124g;
                if (bundle != null) {
                    return bundle;
                }
                throw new java.lang.IllegalStateException("Fragment " + effortSheetFragment + " has null arguments");
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    public final android.view.View D(android.view.LayoutInflater inflater, android.view.ViewGroup viewGroup, android.os.Bundle bundle) {
        kotlin.jvm.internal.Intrinsics.e(inflater, "inflater");
        android.view.View viewInflate = inflater.inflate(com.jorden.karto.setrisokegl.R.layout.fragment_detail, viewGroup, false);
        int i = com.jorden.karto.setrisokegl.R.id.completedCheck;
        com.google.android.material.checkbox.MaterialCheckBox materialCheckBox = (com.google.android.material.checkbox.MaterialCheckBox) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.completedCheck);
        if (materialCheckBox != null) {
            i = com.jorden.karto.setrisokegl.R.id.copyLineButton;
            com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.copyLineButton);
            if (materialButton != null) {
                i = com.jorden.karto.setrisokegl.R.id.keepSwitch;
                com.google.android.material.materialswitch.MaterialSwitch materialSwitch = (com.google.android.material.materialswitch.MaterialSwitch) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.keepSwitch);
                if (materialSwitch != null) {
                    i = com.jorden.karto.setrisokegl.R.id.lastGoButton;
                    com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.lastGoButton);
                    if (materialButton2 != null) {
                        i = com.jorden.karto.setrisokegl.R.id.reportInput;
                        com.google.android.material.textfield.TextInputEditText textInputEditText = (com.google.android.material.textfield.TextInputEditText) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.reportInput);
                        if (textInputEditText != null) {
                            i = com.jorden.karto.setrisokegl.R.id.rowBand;
                            android.view.View viewA = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rowBand);
                            if (viewA != null) {
                                com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBindingA = com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding.a(viewA);
                                i = com.jorden.karto.setrisokegl.R.id.rowHalfHour;
                                android.view.View viewA2 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rowHalfHour);
                                if (viewA2 != null) {
                                    com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBindingA2 = com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding.a(viewA2);
                                    i = com.jorden.karto.setrisokegl.R.id.rowKit;
                                    android.view.View viewA3 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rowKit);
                                    if (viewA3 != null) {
                                        com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBindingA3 = com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding.a(viewA3);
                                        i = com.jorden.karto.setrisokegl.R.id.rowMover;
                                        android.view.View viewA4 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rowMover);
                                        if (viewA4 != null) {
                                            com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBindingA4 = com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding.a(viewA4);
                                            i = com.jorden.karto.setrisokegl.R.id.rowScale;
                                            android.view.View viewA5 = androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.rowScale);
                                            if (viewA5 != null) {
                                                com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding partSpecRowBindingA5 = com.jorden.karto.setrisokegl.databinding.PartSpecRowBinding.a(viewA5);
                                                i = com.jorden.karto.setrisokegl.R.id.saveReportButton;
                                                com.google.android.material.button.MaterialButton materialButton3 = (com.google.android.material.button.MaterialButton) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.saveReportButton);
                                                if (materialButton3 != null) {
                                                    i = com.jorden.karto.setrisokegl.R.id.sheetBand;
                                                    android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetBand);
                                                    if (linearLayout != null) {
                                                        i = com.jorden.karto.setrisokegl.R.id.sheetDial;
                                                        com.jorden.karto.setrisokegl.ui.common.EmberDialView emberDialView = (com.jorden.karto.setrisokegl.ui.common.EmberDialView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetDial);
                                                        if (emberDialView != null) {
                                                            i = com.jorden.karto.setrisokegl.R.id.sheetMark;
                                                            android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetMark);
                                                            if (textView != null) {
                                                                i = com.jorden.karto.setrisokegl.R.id.sheetName;
                                                                android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetName);
                                                                if (textView2 != null) {
                                                                    i = com.jorden.karto.setrisokegl.R.id.sheetPace;
                                                                    android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetPace);
                                                                    if (textView3 != null) {
                                                                        i = com.jorden.karto.setrisokegl.R.id.sheetTag;
                                                                        android.widget.TextView textView4 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.sheetTag);
                                                                        if (textView4 != null) {
                                                                            this.c0 = new com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding((androidx.core.widget.NestedScrollView) viewInflate, materialCheckBox, materialButton, materialSwitch, materialButton2, textInputEditText, partSpecRowBindingA, partSpecRowBindingA2, partSpecRowBindingA3, partSpecRowBindingA4, partSpecRowBindingA5, materialButton3, linearLayout, emberDialView, textView, textView2, textView3, textView4);
                                                                            androidx.core.widget.NestedScrollView nestedScrollView = X().f3024a;
                                                                            kotlin.jvm.internal.Intrinsics.d(nestedScrollView, "getRoot(...)");
                                                                            return nestedScrollView;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // androidx.fragment.app.Fragment
    public final void F() {
        this.I = true;
        this.c0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public final void N(android.view.View view) {
        java.lang.Object value;
        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry;
        kotlin.jvm.internal.Intrinsics.e(view, "view");
        com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY = Y();
        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs effortSheetFragmentArgs = (com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragmentArgs) this.e0.getValue();
        effortSheetViewModelY.getClass();
        java.lang.String str = effortSheetFragmentArgs.f3108a;
        if (!kotlin.jvm.internal.Intrinsics.a(effortSheetViewModelY.f3113j, str)) {
            effortSheetViewModelY.f3113j = str;
            kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = effortSheetViewModelY.f3112h;
            do {
                value = mutableStateFlow.getValue();
                com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState effortSheetUiState = (com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) value;
                moveEntry = effortSheetUiState.f3109a;
                effortSheetUiState.getClass();
            } while (!mutableStateFlow.h(value, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState(moveEntry, 10.0f)));
            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$2(effortSheetViewModelY, str, null), 3);
            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$3(effortSheetViewModelY, str, null), 3);
        }
        X().k.f3053a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_scale);
        X().f3027h.f3053a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_half_hour);
        X().f3026g.f3053a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_band);
        X().f3028j.f3053a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_mover);
        X().i.f3053a.setText(com.jorden.karto.setrisokegl.R.string.sheet_row_kit);
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX = X();
        final int i = 0;
        fragmentDetailBindingX.d.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener(this) { // from class: com.jorden.karto.setrisokegl.ui.detail.a
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

            {
                this.b = this;
            }

            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(android.widget.CompoundButton button, boolean z) {
                switch (i) {
                    case 0:
                        kotlin.jvm.internal.Intrinsics.e(button, "button");
                        if (button.isPressed()) {
                            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY2 = this.b.Y();
                            effortSheetViewModelY2.getClass();
                            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY2), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onKeepChanged$1(effortSheetViewModelY2, z, null), 3);
                            break;
                        }
                        break;
                    default:
                        kotlin.jvm.internal.Intrinsics.e(button, "button");
                        if (button.isPressed()) {
                            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY3 = this.b.Y();
                            effortSheetViewModelY3.getClass();
                            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY3), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onCompletedChanged$1(effortSheetViewModelY3, z, null), 3);
                            break;
                        }
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX2 = X();
        final int i2 = 1;
        fragmentDetailBindingX2.b.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener(this) { // from class: com.jorden.karto.setrisokegl.ui.detail.a
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

            {
                this.b = this;
            }

            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(android.widget.CompoundButton button, boolean z) {
                switch (i2) {
                    case 0:
                        kotlin.jvm.internal.Intrinsics.e(button, "button");
                        if (button.isPressed()) {
                            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY2 = this.b.Y();
                            effortSheetViewModelY2.getClass();
                            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY2), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onKeepChanged$1(effortSheetViewModelY2, z, null), 3);
                            break;
                        }
                        break;
                    default:
                        kotlin.jvm.internal.Intrinsics.e(button, "button");
                        if (button.isPressed()) {
                            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY3 = this.b.Y();
                            effortSheetViewModelY3.getClass();
                            kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY3), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onCompletedChanged$1(effortSheetViewModelY3, z, null), 3);
                            break;
                        }
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX3 = X();
        fragmentDetailBindingX3.e.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.detail.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i2) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.b;
                        android.text.Editable text = effortSheetFragment.X().f3025f.getText();
                        java.lang.String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY2 = effortSheetFragment.Y();
                        effortSheetViewModelY2.getClass();
                        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY2), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onImpressionSaved$1(effortSheetViewModelY2, string, null), 3);
                        com.google.android.material.snackbar.Snackbar.g(effortSheetFragment.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_recap_saved).h();
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment2 = this.b;
                        effortSheetFragment2.getClass();
                        com.google.android.material.datepicker.MaterialDatePicker.Builder builder = new com.google.android.material.datepicker.MaterialDatePicker.Builder(new com.google.android.material.datepicker.SingleDateSelector());
                        builder.c = com.jorden.karto.setrisokegl.R.string.sheet_last_go_label;
                        com.google.android.material.datepicker.MaterialDatePicker materialDatePickerA = builder.a();
                        final com.jorden.karto.setrisokegl.ui.detail.c cVar = new com.jorden.karto.setrisokegl.ui.detail.c(effortSheetFragment2);
                        materialDatePickerA.s0.add(new com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener() { // from class: com.jorden.karto.setrisokegl.ui.detail.d
                            @Override // com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener
                            public final void a(java.lang.Object obj) {
                                cVar.m(obj);
                            }
                        });
                        materialDatePickerA.c0(effortSheetFragment2.n(), "last-go-picker");
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment3 = this.b;
                        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry2 = ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) effortSheetFragment3.Y().i.getValue()).f3109a;
                        if (moveEntry2 != null) {
                            com.jorden.karto.setrisokegl.data.model.Move move = moveEntry2.f2959a;
                            java.lang.String strR = effortSheetFragment3.r(com.jorden.karto.setrisokegl.R.string.sheet_burn_line, effortSheetFragment3.q(move.b), java.lang.Float.valueOf(move.e), java.lang.Integer.valueOf(move.f2954f));
                            kotlin.jvm.internal.Intrinsics.d(strR, "getString(...)");
                            java.lang.Object systemService = effortSheetFragment3.R().getSystemService("clipboard");
                            kotlin.jvm.internal.Intrinsics.c(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                            ((android.content.ClipboardManager) systemService).setPrimaryClip(android.content.ClipData.newPlainText(effortSheetFragment3.q(com.jorden.karto.setrisokegl.R.string.app_name), strR));
                            com.google.android.material.snackbar.Snackbar.g(effortSheetFragment3.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_copy_done).h();
                            break;
                        }
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX4 = X();
        final int i3 = 0;
        fragmentDetailBindingX4.l.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.detail.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i3) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.b;
                        android.text.Editable text = effortSheetFragment.X().f3025f.getText();
                        java.lang.String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY2 = effortSheetFragment.Y();
                        effortSheetViewModelY2.getClass();
                        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY2), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onImpressionSaved$1(effortSheetViewModelY2, string, null), 3);
                        com.google.android.material.snackbar.Snackbar.g(effortSheetFragment.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_recap_saved).h();
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment2 = this.b;
                        effortSheetFragment2.getClass();
                        com.google.android.material.datepicker.MaterialDatePicker.Builder builder = new com.google.android.material.datepicker.MaterialDatePicker.Builder(new com.google.android.material.datepicker.SingleDateSelector());
                        builder.c = com.jorden.karto.setrisokegl.R.string.sheet_last_go_label;
                        com.google.android.material.datepicker.MaterialDatePicker materialDatePickerA = builder.a();
                        final com.jorden.karto.setrisokegl.ui.detail.c cVar = new com.jorden.karto.setrisokegl.ui.detail.c(effortSheetFragment2);
                        materialDatePickerA.s0.add(new com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener() { // from class: com.jorden.karto.setrisokegl.ui.detail.d
                            @Override // com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener
                            public final void a(java.lang.Object obj) {
                                cVar.m(obj);
                            }
                        });
                        materialDatePickerA.c0(effortSheetFragment2.n(), "last-go-picker");
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment3 = this.b;
                        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry2 = ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) effortSheetFragment3.Y().i.getValue()).f3109a;
                        if (moveEntry2 != null) {
                            com.jorden.karto.setrisokegl.data.model.Move move = moveEntry2.f2959a;
                            java.lang.String strR = effortSheetFragment3.r(com.jorden.karto.setrisokegl.R.string.sheet_burn_line, effortSheetFragment3.q(move.b), java.lang.Float.valueOf(move.e), java.lang.Integer.valueOf(move.f2954f));
                            kotlin.jvm.internal.Intrinsics.d(strR, "getString(...)");
                            java.lang.Object systemService = effortSheetFragment3.R().getSystemService("clipboard");
                            kotlin.jvm.internal.Intrinsics.c(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                            ((android.content.ClipboardManager) systemService).setPrimaryClip(android.content.ClipData.newPlainText(effortSheetFragment3.q(com.jorden.karto.setrisokegl.R.string.app_name), strR));
                            com.google.android.material.snackbar.Snackbar.g(effortSheetFragment3.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_copy_done).h();
                            break;
                        }
                        break;
                }
            }
        });
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBindingX5 = X();
        final int i4 = 2;
        fragmentDetailBindingX5.c.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: com.jorden.karto.setrisokegl.ui.detail.b
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment b;

            {
                this.b = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i4) {
                    case 0:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment = this.b;
                        android.text.Editable text = effortSheetFragment.X().f3025f.getText();
                        java.lang.String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModelY2 = effortSheetFragment.Y();
                        effortSheetViewModelY2.getClass();
                        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(effortSheetViewModelY2), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onImpressionSaved$1(effortSheetViewModelY2, string, null), 3);
                        com.google.android.material.snackbar.Snackbar.g(effortSheetFragment.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_recap_saved).h();
                        break;
                    case 1:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment2 = this.b;
                        effortSheetFragment2.getClass();
                        com.google.android.material.datepicker.MaterialDatePicker.Builder builder = new com.google.android.material.datepicker.MaterialDatePicker.Builder(new com.google.android.material.datepicker.SingleDateSelector());
                        builder.c = com.jorden.karto.setrisokegl.R.string.sheet_last_go_label;
                        com.google.android.material.datepicker.MaterialDatePicker materialDatePickerA = builder.a();
                        final com.jorden.karto.setrisokegl.ui.detail.c cVar = new com.jorden.karto.setrisokegl.ui.detail.c(effortSheetFragment2);
                        materialDatePickerA.s0.add(new com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener() { // from class: com.jorden.karto.setrisokegl.ui.detail.d
                            @Override // com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener
                            public final void a(java.lang.Object obj) {
                                cVar.m(obj);
                            }
                        });
                        materialDatePickerA.c0(effortSheetFragment2.n(), "last-go-picker");
                        break;
                    default:
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment effortSheetFragment3 = this.b;
                        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry2 = ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) effortSheetFragment3.Y().i.getValue()).f3109a;
                        if (moveEntry2 != null) {
                            com.jorden.karto.setrisokegl.data.model.Move move = moveEntry2.f2959a;
                            java.lang.String strR = effortSheetFragment3.r(com.jorden.karto.setrisokegl.R.string.sheet_burn_line, effortSheetFragment3.q(move.b), java.lang.Float.valueOf(move.e), java.lang.Integer.valueOf(move.f2954f));
                            kotlin.jvm.internal.Intrinsics.d(strR, "getString(...)");
                            java.lang.Object systemService = effortSheetFragment3.R().getSystemService("clipboard");
                            kotlin.jvm.internal.Intrinsics.c(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                            ((android.content.ClipboardManager) systemService).setPrimaryClip(android.content.ClipData.newPlainText(effortSheetFragment3.q(com.jorden.karto.setrisokegl.R.string.app_name), strR));
                            com.google.android.material.snackbar.Snackbar.g(effortSheetFragment3.X().f3024a, com.jorden.karto.setrisokegl.R.string.sheet_copy_done).h();
                            break;
                        }
                        break;
                }
            }
        });
        androidx.lifecycle.LifecycleOwner lifecycleOwnerT = t();
        kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.LifecycleOwnerKt.a(lifecycleOwnerT), null, null, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetFragment$onViewCreated$6(this, null), 3);
    }

    public final com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding X() {
        com.jorden.karto.setrisokegl.databinding.FragmentDetailBinding fragmentDetailBinding = this.c0;
        if (fragmentDetailBinding != null) {
            return fragmentDetailBinding;
        }
        throw new java.lang.IllegalArgumentException("Required value was null.");
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.Lazy] */
    public final com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel Y() {
        return (com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel) this.d0.getValue();
    }
}
