package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class PanPickerAdapter extends androidx.recyclerview.widget.ListAdapter<com.jorden.karto.setrisokegl.data.model.Move, com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.ChoiceHolder> {

    /* renamed from: g, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter$Companion$DIFF$1 f3182g = new com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter$Companion$DIFF$1();

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.ui.tool.b f3183f;

    @kotlin.Metadata
    public final class ChoiceHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public static final /* synthetic */ int w = 0;
        public final com.jorden.karto.setrisokegl.databinding.ItemPanChoiceBinding u;

        public ChoiceHolder(com.jorden.karto.setrisokegl.databinding.ItemPanChoiceBinding itemPanChoiceBinding) {
            super(itemPanChoiceBinding.f3050a);
            this.u = itemPanChoiceBinding;
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }

    public PanPickerAdapter(com.jorden.karto.setrisokegl.ui.tool.b bVar) {
        super(f3182g);
        this.f3183f = bVar;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final void g(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int i) {
        com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.ChoiceHolder choiceHolder = (com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.ChoiceHolder) viewHolder;
        java.lang.Object obj = this.d.f1415f.get(i);
        kotlin.jvm.internal.Intrinsics.d(obj, "getItem(...)");
        com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
        com.jorden.karto.setrisokegl.databinding.ItemPanChoiceBinding itemPanChoiceBinding = choiceHolder.u;
        android.content.Context context = itemPanChoiceBinding.f3050a.getContext();
        itemPanChoiceBinding.b.setText(move.c);
        itemPanChoiceBinding.c.setText(move.b);
        itemPanChoiceBinding.d.setText(context.getString(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(move.e)));
        itemPanChoiceBinding.f3050a.setOnClickListener(new com.jorden.karto.setrisokegl.ui.catalog.e(com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.this, move, 2));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final androidx.recyclerview.widget.RecyclerView.ViewHolder h(android.view.ViewGroup parent, int i) {
        kotlin.jvm.internal.Intrinsics.e(parent, "parent");
        android.view.View viewInflate = android.view.LayoutInflater.from(parent.getContext()).inflate(com.jorden.karto.setrisokegl.R.layout.item_pan_choice, parent, false);
        int i2 = com.jorden.karto.setrisokegl.R.id.choiceMark;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.choiceMark);
        if (textView != null) {
            i2 = com.jorden.karto.setrisokegl.R.id.choiceName;
            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.choiceName);
            if (textView2 != null) {
                android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) viewInflate;
                android.widget.TextView textView3 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.choiceValue);
                if (textView3 != null) {
                    return new com.jorden.karto.setrisokegl.ui.tool.PanPickerAdapter.ChoiceHolder(new com.jorden.karto.setrisokegl.databinding.ItemPanChoiceBinding(linearLayout, textView, textView2, textView3));
                }
                i2 = com.jorden.karto.setrisokegl.R.id.choiceValue;
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
