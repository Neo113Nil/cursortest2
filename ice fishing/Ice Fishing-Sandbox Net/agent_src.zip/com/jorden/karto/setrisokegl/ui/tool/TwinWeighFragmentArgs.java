package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class TwinWeighFragmentArgs implements androidx.navigation.NavArgs {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f3189a;

    @kotlin.Metadata
    public static final class Companion {
    }

    public TwinWeighFragmentArgs(java.lang.String str) {
        this.f3189a = str;
    }

    @kotlin.jvm.JvmStatic
    @org.jetbrains.annotations.NotNull
    public static final com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs fromBundle(@org.jetbrains.annotations.NotNull android.os.Bundle bundle) {
        java.lang.String string;
        kotlin.jvm.internal.Intrinsics.e(bundle, "bundle");
        bundle.setClassLoader(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs.class.getClassLoader());
        if (bundle.containsKey("leftMoveId")) {
            string = bundle.getString("leftMoveId");
            if (string == null) {
                throw new java.lang.IllegalArgumentException("Argument \"leftMoveId\" is marked as non-null but was passed a null value.");
            }
        } else {
            string = "";
        }
        return new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs(string);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs) && kotlin.jvm.internal.Intrinsics.a(this.f3189a, ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragmentArgs) obj).f3189a);
    }

    public final int hashCode() {
        return this.f3189a.hashCode();
    }

    public final java.lang.String toString() {
        return androidx.activity.h.j(new java.lang.StringBuilder("TwinWeighFragmentArgs(leftMoveId="), this.f3189a, ")");
    }
}
