package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class TwinBeamView extends android.view.View {

    /* renamed from: a, reason: collision with root package name */
    public float f3099a;
    public float b;
    public float c;
    public boolean d;
    public final android.graphics.Paint e;

    /* renamed from: f, reason: collision with root package name */
    public final android.graphics.Paint f3100f;

    /* renamed from: g, reason: collision with root package name */
    public final android.graphics.Paint f3101g;

    /* renamed from: h, reason: collision with root package name */
    public final android.graphics.Paint f3102h;
    public final android.graphics.Paint i;

    /* renamed from: j, reason: collision with root package name */
    public final android.graphics.Path f3103j;

    @kotlin.Metadata
    public static final class Companion {
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    @kotlin.jvm.JvmOverloads
    public TwinBeamView(@org.jetbrains.annotations.NotNull android.content.Context context, @org.jetbrains.annotations.Nullable android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        kotlin.jvm.internal.Intrinsics.e(context, "context");
        this.c = 10.0f;
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.STROKE;
        paint.setStyle(style);
        android.graphics.Paint.Cap cap = android.graphics.Paint.Cap.ROUND;
        paint.setStrokeCap(cap);
        paint.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.mark_ink));
        this.e = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.mark_track));
        this.f3100f = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        android.graphics.Paint.Style style2 = android.graphics.Paint.Style.FILL;
        paint3.setStyle(style2);
        paint3.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_primary));
        this.f3101g = paint3;
        android.graphics.Paint paint4 = new android.graphics.Paint(1);
        paint4.setStyle(style2);
        paint4.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_secondary));
        this.f3102h = paint4;
        android.graphics.Paint paint5 = new android.graphics.Paint(1);
        paint5.setStyle(style2);
        paint5.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.mark_ink));
        this.i = paint5;
        this.f3103j = new android.graphics.Path();
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        kotlin.jvm.internal.Intrinsics.e(canvas, "canvas");
        float width = getWidth();
        float height = getHeight();
        float fA = 0.0f;
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        float f2 = width / 2.0f;
        float f3 = height * 0.42f;
        float f4 = 0.34f * width;
        float f5 = 0.045f * height;
        android.graphics.Paint paint = this.e;
        paint.setStrokeWidth(f5);
        android.graphics.Paint paint2 = this.f3100f;
        paint2.setStrokeWidth(f5);
        if (this.d) {
            float f6 = this.f3099a;
            float f7 = this.b;
            if (f6 + f7 > 0.0f) {
                fA = kotlin.ranges.RangesKt.a((f7 - f6) / this.c, -1.0f, 1.0f);
            }
        }
        float f8 = 0.3f * height * fA;
        float f9 = f3 - f8;
        float f10 = f3 + f8;
        float f11 = f2 - f4;
        float f12 = f2 + f4;
        canvas.drawLine(f11, f9, f12, f10, this.d ? paint : paint2);
        float f13 = 0.05f * height;
        if (this.d) {
            float f14 = this.f3099a;
            boolean z = f14 >= this.b;
            float f15 = 0.13f * height;
            float f16 = ((f14 / this.c) * f15) + f13;
            android.graphics.Paint paint3 = this.f3102h;
            android.graphics.Paint paint4 = this.f3101g;
            canvas.drawCircle(f11, f9, f16, z ? paint4 : paint3);
            float f17 = ((this.b / this.c) * f15) + f13;
            if (!z) {
                paint3 = paint4;
            }
            canvas.drawCircle(f12, f10, f17, paint3);
        } else {
            android.graphics.Paint paint5 = new android.graphics.Paint(paint2);
            android.graphics.Paint.Style style = android.graphics.Paint.Style.FILL;
            paint5.setStyle(style);
            canvas.drawCircle(f11, f9, f13, paint5);
            android.graphics.Paint paint6 = new android.graphics.Paint(paint2);
            paint6.setStyle(style);
            canvas.drawCircle(f12, f10, f13, paint6);
        }
        android.graphics.Path path = this.f3103j;
        path.reset();
        path.moveTo(f2, f3);
        float f18 = width * 0.08f;
        path.lineTo(f2 + f18, height);
        path.lineTo(f2 - f18, height);
        path.close();
        canvas.drawPath(path, this.i);
    }
}
