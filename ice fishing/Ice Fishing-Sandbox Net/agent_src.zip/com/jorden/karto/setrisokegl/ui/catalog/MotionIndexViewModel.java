package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class MotionIndexViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.domain.usecase.FilterIndexUseCase b;
    public final kotlinx.coroutines.flow.MutableStateFlow c;
    public final kotlinx.coroutines.flow.StateFlow d;
    public java.util.List e;

    /* renamed from: f, reason: collision with root package name */
    public kotlin.jvm.functions.Function1 f3079f;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel$1", f = "MotionIndexViewModel.kt", l = {41}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3080f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.domain.usecase.ObserveIndexUseCase f3081g;

        /* renamed from: h, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel f3082h;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.domain.usecase.ObserveIndexUseCase observeIndexUseCase, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModel, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3081g = observeIndexUseCase;
            this.f3082h = motionIndexViewModel;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel.AnonymousClass1(this.f3081g, this.f3082h, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3080f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = this.f3081g.f3060a;
                com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1 emberRepository$observeEntries$$inlined$map$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntries$$inlined$map$1(emberRepository.f2973a.b(), emberRepository);
                final com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModel = this.f3082h;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel motionIndexViewModel2 = motionIndexViewModel;
                        motionIndexViewModel2.e = (java.util.List) obj2;
                        motionIndexViewModel2.i();
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3080f = 1;
                if (emberRepository$observeEntries$$inlined$map$1.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            return kotlin.Unit.f3201a;
        }
    }

    public MotionIndexViewModel(com.jorden.karto.setrisokegl.domain.usecase.ObserveIndexUseCase observeIndexUseCase, com.jorden.karto.setrisokegl.domain.usecase.FilterIndexUseCase filterIndexUseCase) {
        this.b = filterIndexUseCase;
        kotlin.collections.EmptyList emptyList = kotlin.collections.EmptyList.b;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState(emptyList, "", null, false));
        this.c = mutableStateFlowA;
        this.d = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
        this.e = emptyList;
        this.f3079f = new androidx.room.c(4);
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexViewModel.AnonymousClass1(observeIndexUseCase, this, null), 3);
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0079  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void i() {
        java.lang.Object value;
        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState motionIndexUiState;
        java.util.ArrayList arrayList;
        boolean z;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = this.c;
        do {
            value = mutableStateFlow.getValue();
            motionIndexUiState = (com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) value;
            java.util.List entries = this.e;
            java.lang.String query = motionIndexUiState.b;
            kotlin.jvm.functions.Function1 nameOf = this.f3079f;
            this.b.getClass();
            kotlin.jvm.internal.Intrinsics.e(entries, "entries");
            kotlin.jvm.internal.Intrinsics.e(query, "query");
            kotlin.jvm.internal.Intrinsics.e(nameOf, "nameOf");
            java.lang.String string = kotlin.text.StringsKt.C(query).toString();
            java.util.Locale locale = java.util.Locale.getDefault();
            kotlin.jvm.internal.Intrinsics.d(locale, "getDefault(...)");
            java.lang.String lowerCase = string.toLowerCase(locale);
            kotlin.jvm.internal.Intrinsics.d(lowerCase, "toLowerCase(...)");
            arrayList = new java.util.ArrayList();
            for (java.lang.Object obj : entries) {
                com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = (com.jorden.karto.setrisokegl.data.model.MoveEntry) obj;
                if (lowerCase.length() == 0) {
                    z = true;
                } else {
                    java.lang.String str = (java.lang.String) nameOf.m(moveEntry.f2959a);
                    java.util.Locale locale2 = java.util.Locale.getDefault();
                    kotlin.jvm.internal.Intrinsics.d(locale2, "getDefault(...)");
                    java.lang.String lowerCase2 = str.toLowerCase(locale2);
                    kotlin.jvm.internal.Intrinsics.d(lowerCase2, "toLowerCase(...)");
                    if (!kotlin.text.StringsKt.h(lowerCase2, lowerCase)) {
                        z = false;
                    }
                }
                com.jorden.karto.setrisokegl.data.model.MoveTag moveTag = motionIndexUiState.c;
                boolean z2 = moveTag == null || moveEntry.f2959a.d == moveTag;
                boolean z3 = !motionIndexUiState.d || moveEntry.b.b;
                if (z && z2 && z3) {
                    arrayList.add(obj);
                }
            }
        } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState.a(motionIndexUiState, arrayList, null, null, false, 14)));
    }
}
