package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3", f = "StokerLogFragment.kt", l = {60}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class StokerLogFragment$onViewCreated$3 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3148f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment f3149g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3$1", f = "StokerLogFragment.kt", l = {61}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3150f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment f3151g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3151g = stokerLogFragment;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3.AnonymousClass1(this.f3151g, continuation);
        }

        /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Object, kotlin.Lazy] */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3150f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment = this.f3151g;
                kotlinx.coroutines.flow.StateFlow stateFlow = ((com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel) stokerLogFragment.d0.getValue()).f3154f;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment.onViewCreated.3.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState stokerLogUiState = (com.jorden.karto.setrisokegl.ui.profile.StokerLogUiState) obj2;
                        com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment2 = stokerLogFragment;
                        stokerLogFragment2.X().f3038g.setText(stokerLogFragment2.r(com.jorden.karto.setrisokegl.R.string.kcal_value, java.lang.Integer.valueOf(stokerLogUiState.f3153a)));
                        stokerLogFragment2.X().f3037f.setText(stokerLogFragment2.r(com.jorden.karto.setrisokegl.R.string.log_total_sub, java.lang.Integer.valueOf(stokerLogUiState.b)));
                        com.jorden.karto.setrisokegl.ui.profile.BadgeAdapter badgeAdapter = stokerLogFragment2.e0;
                        if (badgeAdapter == null) {
                            kotlin.jvm.internal.Intrinsics.k("badgeAdapter");
                            throw null;
                        }
                        badgeAdapter.o(stokerLogUiState.c);
                        com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter recentLinkAdapter = stokerLogFragment2.f0;
                        if (recentLinkAdapter == null) {
                            kotlin.jvm.internal.Intrinsics.k("recentLinkAdapter");
                            throw null;
                        }
                        java.util.List list = stokerLogUiState.d;
                        recentLinkAdapter.o(list);
                        boolean zIsEmpty = list.isEmpty();
                        stokerLogFragment2.X().d.setVisibility(zIsEmpty ? 8 : 0);
                        stokerLogFragment2.X().c.setVisibility(zIsEmpty ? 0 : 8);
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3150f = 1;
                if (stateFlow.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StokerLogFragment$onViewCreated$3(com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3149g = stokerLogFragment;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3(this.f3149g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3148f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment = this.f3149g;
            androidx.lifecycle.LifecycleOwner lifecycleOwnerT = stokerLogFragment.t();
            kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment$onViewCreated$3.AnonymousClass1(stokerLogFragment, null);
            this.f3148f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(lifecycleOwnerT, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
