package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class EffortSheetViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.domain.usecase.ObserveEntryUseCase b;
    public final com.jorden.karto.setrisokegl.domain.usecase.ToggleKeptUseCase c;
    public final com.jorden.karto.setrisokegl.domain.usecase.SetCompletedUseCase d;
    public final com.jorden.karto.setrisokegl.domain.usecase.SetLastGoUseCase e;

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.domain.usecase.SaveImpressionUseCase f3110f;

    /* renamed from: g, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.domain.usecase.MarkOpenedUseCase f3111g;

    /* renamed from: h, reason: collision with root package name */
    public final kotlinx.coroutines.flow.MutableStateFlow f3112h;
    public final kotlinx.coroutines.flow.StateFlow i;

    /* renamed from: j, reason: collision with root package name */
    public java.lang.String f3113j;

    public EffortSheetViewModel(com.jorden.karto.setrisokegl.domain.usecase.ObserveEntryUseCase observeEntryUseCase, com.jorden.karto.setrisokegl.domain.usecase.ToggleKeptUseCase toggleKeptUseCase, com.jorden.karto.setrisokegl.domain.usecase.SetCompletedUseCase setCompletedUseCase, com.jorden.karto.setrisokegl.domain.usecase.SetLastGoUseCase setLastGoUseCase, com.jorden.karto.setrisokegl.domain.usecase.SaveImpressionUseCase saveImpressionUseCase, com.jorden.karto.setrisokegl.domain.usecase.MarkOpenedUseCase markOpenedUseCase) {
        this.b = observeEntryUseCase;
        this.c = toggleKeptUseCase;
        this.d = setCompletedUseCase;
        this.e = setLastGoUseCase;
        this.f3110f = saveImpressionUseCase;
        this.f3111g = markOpenedUseCase;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(new com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState(null, 10.0f));
        this.f3112h = mutableStateFlowA;
        this.i = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
        this.f3113j = "";
    }
}
