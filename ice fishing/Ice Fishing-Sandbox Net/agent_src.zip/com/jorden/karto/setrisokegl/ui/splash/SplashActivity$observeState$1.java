package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1", f = "SplashActivity.kt", l = {69}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashActivity$observeState$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3170f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3171g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1$1", f = "SplashActivity.kt", l = {70}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3172f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity f3173g;

        @kotlin.Metadata
        /* renamed from: com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1$1$1, reason: invalid class name and collision with other inner class name */
        final /* synthetic */ class C00161 implements kotlinx.coroutines.flow.FlowCollector, kotlin.jvm.internal.FunctionAdapter {
            public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashActivity b;

            public C00161(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity) {
                this.b = splashActivity;
            }

            @Override // kotlin.jvm.internal.FunctionAdapter
            public final kotlin.Function a() {
                return new kotlin.jvm.internal.AdaptedFunctionReference(this.b);
            }

            @Override // kotlinx.coroutines.flow.FlowCollector
            public final java.lang.Object c(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                int i = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.b;
                splashActivity.getClass();
                boolean z = ((com.jorden.karto.setrisokegl.ui.splash.SplashState) obj) instanceof com.jorden.karto.setrisokegl.ui.splash.SplashState.Error;
                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding = splashActivity.B;
                if (activitySplashBinding == null) {
                    kotlin.jvm.internal.Intrinsics.k("binding");
                    throw null;
                }
                activitySplashBinding.c.setVisibility(z ? 0 : 8);
                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding2 = splashActivity.B;
                if (activitySplashBinding2 == null) {
                    kotlin.jvm.internal.Intrinsics.k("binding");
                    throw null;
                }
                activitySplashBinding2.e.setVisibility(z ? 8 : 0);
                com.jorden.karto.setrisokegl.databinding.ActivitySplashBinding activitySplashBinding3 = splashActivity.B;
                if (activitySplashBinding3 == null) {
                    kotlin.jvm.internal.Intrinsics.k("binding");
                    throw null;
                }
                activitySplashBinding3.d.setVisibility(z ? 8 : 0);
                kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
                return kotlin.Unit.f3201a;
            }

            public final boolean equals(java.lang.Object obj) {
                if ((obj instanceof kotlinx.coroutines.flow.FlowCollector) && (obj instanceof kotlin.jvm.internal.FunctionAdapter)) {
                    return a().equals(((kotlin.jvm.internal.FunctionAdapter) obj).a());
                }
                return false;
            }

            public final int hashCode() {
                return a().hashCode();
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3173g = splashActivity;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1(this.f3173g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3172f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                int i2 = com.jorden.karto.setrisokegl.ui.splash.SplashActivity.C;
                com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3173g;
                kotlinx.coroutines.flow.StateFlow stateFlow = splashActivity.A().e;
                com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1.C00161 c00161 = new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1.C00161(splashActivity);
                this.f3172f = 1;
                if (stateFlow.a(c00161, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashActivity$observeState$1(com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3171g = splashActivity;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1(this.f3171g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3170f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity splashActivity = this.f3171g;
            com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.splash.SplashActivity$observeState$1.AnonymousClass1(splashActivity, null);
            this.f3170f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(splashActivity, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
