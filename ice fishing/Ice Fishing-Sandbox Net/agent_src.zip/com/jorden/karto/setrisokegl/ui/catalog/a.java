package com.jorden.karto.setrisokegl.ui.catalog;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements kotlin.jvm.functions.Function1 {
    public final /* synthetic */ int b;
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment c;

    public /* synthetic */ a(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment, int i) {
        this.b = i;
        this.c = motionIndexFragment;
    }

    @Override // kotlin.jvm.functions.Function1
    public final java.lang.Object m(java.lang.Object obj) throws android.content.res.Resources.NotFoundException {
        switch (this.b) {
            case 0:
                com.jorden.karto.setrisokegl.data.model.MoveEntry entry = (com.jorden.karto.setrisokegl.data.model.MoveEntry) obj;
                kotlin.jvm.internal.Intrinsics.e(entry, "entry");
                com.jorden.karto.setrisokegl.ui.common.NavGuard.a(androidx.navigation.fragment.FragmentKt.a(this.c), new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragmentDirections.ActionIndexToSheet(entry.f2959a.f2953a));
                return kotlin.Unit.f3201a;
            default:
                com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
                kotlin.jvm.internal.Intrinsics.e(move, "move");
                return this.c.q(move.b);
        }
    }
}
