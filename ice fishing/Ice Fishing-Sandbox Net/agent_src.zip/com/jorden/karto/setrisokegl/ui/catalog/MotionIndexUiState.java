package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MotionIndexUiState {

    /* renamed from: a, reason: collision with root package name */
    public final java.util.List f3078a;
    public final java.lang.String b;
    public final com.jorden.karto.setrisokegl.data.model.MoveTag c;
    public final boolean d;

    public MotionIndexUiState(java.util.List visible, java.lang.String query, com.jorden.karto.setrisokegl.data.model.MoveTag moveTag, boolean z) {
        kotlin.jvm.internal.Intrinsics.e(visible, "visible");
        kotlin.jvm.internal.Intrinsics.e(query, "query");
        this.f3078a = visible;
        this.b = query;
        this.c = moveTag;
        this.d = z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.util.List] */
    public static com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState a(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState motionIndexUiState, java.util.ArrayList arrayList, java.lang.String query, com.jorden.karto.setrisokegl.data.model.MoveTag moveTag, boolean z, int i) {
        java.util.ArrayList visible = arrayList;
        if ((i & 1) != 0) {
            visible = motionIndexUiState.f3078a;
        }
        if ((i & 2) != 0) {
            query = motionIndexUiState.b;
        }
        if ((i & 4) != 0) {
            moveTag = motionIndexUiState.c;
        }
        if ((i & 8) != 0) {
            z = motionIndexUiState.d;
        }
        motionIndexUiState.getClass();
        kotlin.jvm.internal.Intrinsics.e(visible, "visible");
        kotlin.jvm.internal.Intrinsics.e(query, "query");
        return new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState(visible, query, moveTag, z);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState motionIndexUiState = (com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f3078a, motionIndexUiState.f3078a) && kotlin.jvm.internal.Intrinsics.a(this.b, motionIndexUiState.b) && this.c == motionIndexUiState.c && this.d == motionIndexUiState.d;
    }

    public final int hashCode() {
        int iHashCode = (this.b.hashCode() + (this.f3078a.hashCode() * 31)) * 31;
        com.jorden.karto.setrisokegl.data.model.MoveTag moveTag = this.c;
        return java.lang.Boolean.hashCode(this.d) + ((iHashCode + (moveTag == null ? 0 : moveTag.hashCode())) * 31);
    }

    public final java.lang.String toString() {
        return "MotionIndexUiState(visible=" + this.f3078a + ", query=" + this.b + ", activeTag=" + this.c + ", keptOnly=" + this.d + ")";
    }
}
