package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class EffortSheetUiState {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.model.MoveEntry f3109a;
    public final float b;

    public EffortSheetUiState(com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry, float f2) {
        this.f3109a = moveEntry;
        this.b = f2;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState effortSheetUiState = (com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f3109a, effortSheetUiState.f3109a) && java.lang.Float.compare(this.b, effortSheetUiState.b) == 0;
    }

    public final int hashCode() {
        com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = this.f3109a;
        return java.lang.Float.hashCode(this.b) + ((moveEntry == null ? 0 : moveEntry.hashCode()) * 31);
    }

    public final java.lang.String toString() {
        return "EffortSheetUiState(entry=" + this.f3109a + ", ceiling=" + this.b + ")";
    }
}
