package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class TwinWeighFragment$special$$inlined$viewModel$default$1 implements kotlin.jvm.functions.Function0<androidx.fragment.app.Fragment> {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment b;

    public TwinWeighFragment$special$$inlined$viewModel$default$1(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment) {
        this.b = twinWeighFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        return this.b;
    }
}
