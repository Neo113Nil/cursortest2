package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MoveBandAdapter$Companion$DIFF$1 extends androidx.recyclerview.widget.DiffUtil.ItemCallback<com.jorden.karto.setrisokegl.data.model.MoveEntry> {
    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean a(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.MoveEntry) obj).equals((com.jorden.karto.setrisokegl.data.model.MoveEntry) obj2);
    }

    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean b(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.MoveEntry) obj).f2959a.f2953a.equals(((com.jorden.karto.setrisokegl.data.model.MoveEntry) obj2).f2959a.f2953a);
    }
}
