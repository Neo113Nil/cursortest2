package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MotionIndexFragment$special$$inlined$viewModel$default$1 implements kotlin.jvm.functions.Function0<androidx.fragment.app.Fragment> {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment b;

    public MotionIndexFragment$special$$inlined$viewModel$default$1(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment) {
        this.b = motionIndexFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        return this.b;
    }
}
