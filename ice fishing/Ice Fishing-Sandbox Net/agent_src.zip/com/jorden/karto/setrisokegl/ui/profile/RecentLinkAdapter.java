package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class RecentLinkAdapter extends androidx.recyclerview.widget.ListAdapter<com.jorden.karto.setrisokegl.data.model.Move, com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.LinkHolder> {

    /* renamed from: g, reason: collision with root package name */
    public static final com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter$Companion$DIFF$1 f3146g = new com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter$Companion$DIFF$1();

    /* renamed from: f, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.ui.profile.a f3147f;

    @kotlin.Metadata
    public static final class Companion {
    }

    @kotlin.Metadata
    public final class LinkHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public static final /* synthetic */ int w = 0;
        public final com.jorden.karto.setrisokegl.databinding.ItemRecentLinkBinding u;

        public LinkHolder(com.jorden.karto.setrisokegl.databinding.ItemRecentLinkBinding itemRecentLinkBinding) {
            super(itemRecentLinkBinding.f3051a);
            this.u = itemRecentLinkBinding;
        }
    }

    public RecentLinkAdapter(com.jorden.karto.setrisokegl.ui.profile.a aVar) {
        super(f3146g);
        this.f3147f = aVar;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final void g(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int i) {
        com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.LinkHolder linkHolder = (com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.LinkHolder) viewHolder;
        java.lang.Object obj = this.d.f1415f.get(i);
        kotlin.jvm.internal.Intrinsics.d(obj, "getItem(...)");
        com.jorden.karto.setrisokegl.data.model.Move move = (com.jorden.karto.setrisokegl.data.model.Move) obj;
        com.jorden.karto.setrisokegl.databinding.ItemRecentLinkBinding itemRecentLinkBinding = linkHolder.u;
        itemRecentLinkBinding.b.setText(move.c);
        itemRecentLinkBinding.c.setText(move.b);
        itemRecentLinkBinding.f3051a.setOnClickListener(new com.jorden.karto.setrisokegl.ui.catalog.e(com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.this, move, 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public final androidx.recyclerview.widget.RecyclerView.ViewHolder h(android.view.ViewGroup parent, int i) {
        kotlin.jvm.internal.Intrinsics.e(parent, "parent");
        android.view.View viewInflate = android.view.LayoutInflater.from(parent.getContext()).inflate(com.jorden.karto.setrisokegl.R.layout.item_recent_link, parent, false);
        int i2 = com.jorden.karto.setrisokegl.R.id.linkMark;
        android.widget.TextView textView = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.linkMark);
        if (textView != null) {
            i2 = com.jorden.karto.setrisokegl.R.id.linkName;
            android.widget.TextView textView2 = (android.widget.TextView) androidx.viewbinding.ViewBindings.a(viewInflate, com.jorden.karto.setrisokegl.R.id.linkName);
            if (textView2 != null) {
                return new com.jorden.karto.setrisokegl.ui.profile.RecentLinkAdapter.LinkHolder(new com.jorden.karto.setrisokegl.databinding.ItemRecentLinkBinding((android.widget.LinearLayout) viewInflate, textView, textView2));
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i2)));
    }
}
