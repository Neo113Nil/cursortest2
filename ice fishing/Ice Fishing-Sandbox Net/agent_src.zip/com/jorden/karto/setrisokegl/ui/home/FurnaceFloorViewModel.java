package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class FurnaceFloorViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.domain.usecase.PickHeroUseCase b;
    public final kotlinx.coroutines.flow.MutableStateFlow c;
    public final kotlinx.coroutines.flow.StateFlow d;

    public FurnaceFloorViewModel(com.jorden.karto.setrisokegl.domain.usecase.PickHeroUseCase pickHeroUseCase, com.jorden.karto.setrisokegl.domain.usecase.ScaleCeilingUseCase scaleCeilingUseCase) {
        this.b = pickHeroUseCase;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState(pickHeroUseCase.a(null), 10.0f));
        this.c = mutableStateFlowA;
        this.d = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
    }
}
