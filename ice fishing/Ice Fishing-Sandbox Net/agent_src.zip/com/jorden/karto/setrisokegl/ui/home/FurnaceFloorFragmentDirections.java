package com.jorden.karto.setrisokegl.ui.home;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class FurnaceFloorFragmentDirections {

    @kotlin.Metadata
    public static final class ActionFurnaceToIndex implements androidx.navigation.NavDirections {

        /* renamed from: a, reason: collision with root package name */
        public final java.lang.String f3139a;

        public ActionFurnaceToIndex(java.lang.String str) {
            this.f3139a = str;
        }

        @Override // androidx.navigation.NavDirections
        public final android.os.Bundle a() {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putString("tagKey", this.f3139a);
            return bundle;
        }

        @Override // androidx.navigation.NavDirections
        public final int b() {
            return com.jorden.karto.setrisokegl.R.id.actionFurnaceToIndex;
        }

        public final boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToIndex) && kotlin.jvm.internal.Intrinsics.a(this.f3139a, ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToIndex) obj).f3139a);
        }

        public final int hashCode() {
            return this.f3139a.hashCode();
        }

        public final java.lang.String toString() {
            return androidx.activity.h.j(new java.lang.StringBuilder("ActionFurnaceToIndex(tagKey="), this.f3139a, ")");
        }
    }

    @kotlin.Metadata
    public static final class ActionFurnaceToSheet implements androidx.navigation.NavDirections {

        /* renamed from: a, reason: collision with root package name */
        public final java.lang.String f3140a;

        public ActionFurnaceToSheet(java.lang.String str) {
            this.f3140a = str;
        }

        @Override // androidx.navigation.NavDirections
        public final android.os.Bundle a() {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putString("moveId", this.f3140a);
            return bundle;
        }

        @Override // androidx.navigation.NavDirections
        public final int b() {
            return com.jorden.karto.setrisokegl.R.id.actionFurnaceToSheet;
        }

        public final boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToSheet) && kotlin.jvm.internal.Intrinsics.a(this.f3140a, ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToSheet) obj).f3140a);
        }

        public final int hashCode() {
            return this.f3140a.hashCode();
        }

        public final java.lang.String toString() {
            return androidx.activity.h.j(new java.lang.StringBuilder("ActionFurnaceToSheet(moveId="), this.f3140a, ")");
        }
    }

    @kotlin.Metadata
    public static final class ActionFurnaceToWeigh implements androidx.navigation.NavDirections {

        /* renamed from: a, reason: collision with root package name */
        public final java.lang.String f3141a;

        public ActionFurnaceToWeigh(java.lang.String str) {
            this.f3141a = str;
        }

        @Override // androidx.navigation.NavDirections
        public final android.os.Bundle a() {
            android.os.Bundle bundle = new android.os.Bundle();
            bundle.putString("leftMoveId", this.f3141a);
            return bundle;
        }

        @Override // androidx.navigation.NavDirections
        public final int b() {
            return com.jorden.karto.setrisokegl.R.id.actionFurnaceToWeigh;
        }

        public final boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToWeigh) && kotlin.jvm.internal.Intrinsics.a(this.f3141a, ((com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragmentDirections.ActionFurnaceToWeigh) obj).f3141a);
        }

        public final int hashCode() {
            return this.f3141a.hashCode();
        }

        public final java.lang.String toString() {
            return androidx.activity.h.j(new java.lang.StringBuilder("ActionFurnaceToWeigh(leftMoveId="), this.f3141a, ")");
        }
    }

    @kotlin.Metadata
    public static final class Companion {
    }
}
