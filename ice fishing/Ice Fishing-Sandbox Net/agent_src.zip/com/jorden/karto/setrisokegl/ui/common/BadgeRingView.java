package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class BadgeRingView extends android.view.View {

    /* renamed from: a, reason: collision with root package name */
    public int f3089a;
    public int b;
    public boolean c;
    public final android.graphics.Paint d;
    public final android.graphics.Paint e;

    /* renamed from: f, reason: collision with root package name */
    public final android.graphics.Paint f3090f;

    /* renamed from: g, reason: collision with root package name */
    public final android.graphics.RectF f3091g;

    /* renamed from: h, reason: collision with root package name */
    public final android.graphics.Path f3092h;

    @kotlin.Metadata
    public static final class Companion {
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    @kotlin.jvm.JvmOverloads
    public BadgeRingView(@org.jetbrains.annotations.NotNull android.content.Context context, @org.jetbrains.annotations.Nullable android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        kotlin.jvm.internal.Intrinsics.e(context, "context");
        this.b = 1;
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.STROKE;
        paint.setStyle(style);
        paint.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.mark_track));
        this.d = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(android.graphics.Paint.Cap.BUTT);
        paint2.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_primary));
        this.e = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setStyle(android.graphics.Paint.Style.FILL);
        paint3.setColor(context.getColor(com.jorden.karto.setrisokegl.R.color.brand_secondary));
        this.f3090f = paint3;
        this.f3091g = new android.graphics.RectF();
        this.f3092h = new android.graphics.Path();
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        kotlin.jvm.internal.Intrinsics.e(canvas, "canvas");
        float fMin = java.lang.Math.min(getWidth(), getHeight());
        if (fMin <= 0.0f) {
            return;
        }
        float f2 = 0.13f * fMin;
        android.graphics.Paint paint = this.d;
        paint.setStrokeWidth(f2);
        android.graphics.Paint paint2 = this.e;
        paint2.setStrokeWidth(f2);
        float width = getWidth() / 2.0f;
        float height = getHeight() / 2.0f;
        float f3 = (fMin - f2) / 2.0f;
        android.graphics.RectF rectF = this.f3091g;
        rectF.set(width - f3, height - f3, width + f3, height + f3);
        canvas.drawArc(rectF, 0.0f, 360.0f, false, paint);
        if (kotlin.ranges.RangesKt.a(this.f3089a / this.b, 0.0f, 1.0f) > 0.0f) {
            int i = this.b;
            float f4 = i > 1 ? 8.0f : 0.0f;
            float f5 = 360.0f / i;
            int i2 = this.f3089a;
            int i3 = 0;
            for (int i4 = i2 > i ? i : i2; i3 < i4; i4 = i4) {
                canvas.drawArc(rectF, (f4 / 2.0f) + ((i3 * f5) - 90.0f), f5 - f4, false, paint2);
                i3++;
            }
        }
        if (this.c) {
            android.graphics.Path path = this.f3092h;
            path.reset();
            float f6 = f3 * 0.46f;
            path.moveTo(width, height - f6);
            float f7 = (0.72f * f6) + height;
            path.lineTo(width + f6, f7);
            path.lineTo(width - f6, f7);
            path.close();
            canvas.drawPath(path, this.f3090f);
        }
    }
}
