package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5", f = "TwinWeighFragment.kt", l = {59}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class TwinWeighFragment$onViewCreated$5 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3185f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment f3186g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5$1", f = "TwinWeighFragment.kt", l = {60}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3187f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment f3188g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3188g = twinWeighFragment;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5.AnonymousClass1(this.f3188g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3187f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment = this.f3188g;
                kotlinx.coroutines.flow.StateFlow stateFlow = twinWeighFragment.a0().f3191f;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment.onViewCreated.5.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        java.lang.String strR;
                        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) obj2;
                        com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment2 = twinWeighFragment;
                        twinWeighFragment2.getClass();
                        com.jorden.karto.setrisokegl.data.model.Move move = twinWeighUiState.f3190a;
                        android.widget.TextView textView = twinWeighFragment2.Z().i;
                        android.widget.TextView textView2 = twinWeighFragment2.Z().f3043j;
                        if (move == null) {
                            textView.setText("");
                            textView2.setText(com.jorden.karto.setrisokegl.R.string.weigh_empty_pan);
                        } else {
                            textView.setText(move.c);
                            textView2.setText(move.b);
                        }
                        android.widget.TextView textView3 = twinWeighFragment2.Z().l;
                        android.widget.TextView textView4 = twinWeighFragment2.Z().f3044m;
                        com.jorden.karto.setrisokegl.data.model.Move move2 = twinWeighUiState.b;
                        if (move2 == null) {
                            textView3.setText("");
                            textView4.setText(com.jorden.karto.setrisokegl.R.string.weigh_empty_pan);
                        } else {
                            textView3.setText(move2.c);
                            textView4.setText(move2.b);
                        }
                        com.jorden.karto.setrisokegl.data.model.Move move3 = twinWeighUiState.f3190a;
                        if (move3 == null || move2 == null) {
                            com.jorden.karto.setrisokegl.ui.common.TwinBeamView twinBeamView = twinWeighFragment2.Z().b;
                            twinBeamView.f3099a = 0.0f;
                            twinBeamView.b = 0.0f;
                            twinBeamView.d = false;
                            twinBeamView.invalidate();
                        } else {
                            com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ = twinWeighFragment2.Z();
                            float f2 = move3.e;
                            if (f2 < 0.0f) {
                                f2 = 0.0f;
                            }
                            com.jorden.karto.setrisokegl.ui.common.TwinBeamView twinBeamView2 = fragmentToolBindingZ.b;
                            twinBeamView2.f3099a = f2;
                            float f3 = move2.e;
                            if (f3 < 0.0f) {
                                f3 = 0.0f;
                            }
                            twinBeamView2.b = f3;
                            float f4 = twinWeighUiState.c;
                            if (f4 <= 0.0f) {
                                f4 = 1.0f;
                            }
                            twinBeamView2.c = f4;
                            twinBeamView2.d = true;
                            twinBeamView2.invalidate();
                        }
                        com.jorden.karto.setrisokegl.databinding.FragmentToolBinding fragmentToolBindingZ2 = twinWeighFragment2.Z();
                        com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting waiting = com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting.f3070a;
                        com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict verdict = twinWeighUiState.e;
                        if (kotlin.jvm.internal.Intrinsics.a(verdict, waiting)) {
                            strR = twinWeighFragment2.q(com.jorden.karto.setrisokegl.R.string.weigh_verdict_waiting);
                        } else if (kotlin.jvm.internal.Intrinsics.a(verdict, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Level.f3068a)) {
                            strR = twinWeighFragment2.q(com.jorden.karto.setrisokegl.R.string.weigh_verdict_level);
                        } else {
                            if (!(verdict instanceof com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped)) {
                                throw new kotlin.NoWhenBranchMatchedException();
                            }
                            com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped tipped = (com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Tipped) verdict;
                            strR = twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.weigh_verdict, twinWeighFragment2.q(tipped.f3069a.b), java.lang.Float.valueOf(tipped.c), twinWeighFragment2.q(tipped.b.b));
                        }
                        fragmentToolBindingZ2.o.setText(strR);
                        twinWeighFragment2.Y(twinWeighFragment2.Z().f3041g, move3 != null ? twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(move3.e)) : null, move2 != null ? twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.met_value, java.lang.Float.valueOf(move2.e)) : null, com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment.X(move3 != null ? java.lang.Float.valueOf(move3.e) : null, move2 != null ? java.lang.Float.valueOf(move2.e) : null));
                        twinWeighFragment2.Y(twinWeighFragment2.Z().e, move3 != null ? twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.kcal_value, java.lang.Integer.valueOf(move3.f2954f)) : null, move2 != null ? twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.kcal_value, java.lang.Integer.valueOf(move2.f2954f)) : null, com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment.X(move3 != null ? java.lang.Float.valueOf(move3.f2954f) : null, move2 != null ? java.lang.Float.valueOf(move2.f2954f) : null));
                        twinWeighFragment2.Y(twinWeighFragment2.Z().d, move3 != null ? twinWeighFragment2.q(move3.a().b) : null, move2 != null ? twinWeighFragment2.q(move2.a().b) : null, com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment.X(move3 != null ? java.lang.Float.valueOf(move3.e) : null, move2 != null ? java.lang.Float.valueOf(move2.e) : null));
                        twinWeighFragment2.Y(twinWeighFragment2.Z().f3040f, move3 != null ? twinWeighFragment2.q(move3.f2955g) : null, move2 != null ? twinWeighFragment2.q(move2.f2955g) : null, 0);
                        twinWeighFragment2.Z().p.setText(twinWeighFragment2.r(com.jorden.karto.setrisokegl.R.string.weigh_count, java.lang.Integer.valueOf(twinWeighUiState.d)));
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3187f = 1;
                if (stateFlow.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TwinWeighFragment$onViewCreated$5(com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3186g = twinWeighFragment;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5(this.f3186g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3185f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment twinWeighFragment = this.f3186g;
            androidx.lifecycle.LifecycleOwner lifecycleOwnerT = twinWeighFragment.t();
            kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.tool.TwinWeighFragment$onViewCreated$5.AnonymousClass1(twinWeighFragment, null);
            this.f3185f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(lifecycleOwnerT, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
