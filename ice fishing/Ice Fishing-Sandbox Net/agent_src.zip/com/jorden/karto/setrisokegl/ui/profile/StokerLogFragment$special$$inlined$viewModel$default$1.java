package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class StokerLogFragment$special$$inlined$viewModel$default$1 implements kotlin.jvm.functions.Function0<androidx.fragment.app.Fragment> {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment b;

    public StokerLogFragment$special$$inlined$viewModel$default$1(com.jorden.karto.setrisokegl.ui.profile.StokerLogFragment stokerLogFragment) {
        this.b = stokerLogFragment;
    }

    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        return this.b;
    }
}
