package com.jorden.karto.setrisokegl.ui.common;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class NavGuard {

    /* renamed from: a, reason: collision with root package name */
    public static long f3097a;

    public static void a(androidx.navigation.NavController controller, androidx.navigation.NavDirections navDirections) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.e(controller, "controller");
        long jElapsedRealtime = android.os.SystemClock.elapsedRealtime();
        if (jElapsedRealtime - f3097a < 600) {
            return;
        }
        f3097a = jElapsedRealtime;
        androidx.navigation.NavDestination navDestinationG = controller.g();
        if (navDestinationG == null || navDestinationG.d(navDirections.b()) == null) {
            return;
        }
        controller.m(navDirections.b(), navDirections.a(), null);
    }
}
