package com.jorden.karto.setrisokegl.ui.catalog;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7", f = "MotionIndexFragment.kt", l = {82}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class MotionIndexFragment$onViewCreated$7 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3072f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment f3073g;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7$1", f = "MotionIndexFragment.kt", l = {83}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3074f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment f3075g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment, kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
            this.f3075g = motionIndexFragment;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) throws java.lang.Throwable {
            ((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
            return kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7.AnonymousClass1(this.f3075g, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3074f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment = this.f3075g;
                kotlinx.coroutines.flow.StateFlow stateFlow = motionIndexFragment.Y().d;
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment.onViewCreated.7.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState motionIndexUiState = (com.jorden.karto.setrisokegl.ui.catalog.MotionIndexUiState) obj2;
                        com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment2 = motionIndexFragment;
                        com.jorden.karto.setrisokegl.ui.catalog.MoveBandAdapter moveBandAdapter = motionIndexFragment2.f0;
                        if (moveBandAdapter == null) {
                            kotlin.jvm.internal.Intrinsics.k("adapter");
                            throw null;
                        }
                        moveBandAdapter.o(motionIndexUiState.f3078a);
                        java.util.List list = motionIndexUiState.f3078a;
                        boolean zIsEmpty = list.isEmpty();
                        int i2 = 0;
                        motionIndexFragment2.X().e.setVisibility(zIsEmpty ? 8 : 0);
                        motionIndexFragment2.X().c.setVisibility(zIsEmpty ? 0 : 8);
                        com.jorden.karto.setrisokegl.databinding.FragmentCatalogBinding fragmentCatalogBindingX = motionIndexFragment2.X();
                        if (kotlin.text.StringsKt.m(motionIndexUiState.b) && motionIndexUiState.c == null && !motionIndexUiState.d) {
                            i2 = 8;
                        }
                        fragmentCatalogBindingX.f3022g.setVisibility(i2);
                        motionIndexFragment2.X().d.setText(motionIndexFragment2.r(com.jorden.karto.setrisokegl.R.string.index_count, java.lang.Integer.valueOf(list.size())));
                        if (!zIsEmpty) {
                            motionIndexFragment2.X().e.scheduleLayoutAnimation();
                        }
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3074f = 1;
                if (stateFlow.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            throw new kotlin.KotlinNothingValueException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MotionIndexFragment$onViewCreated$7(com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3073g = motionIndexFragment;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7(this.f3073g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3072f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment motionIndexFragment = this.f3073g;
            androidx.lifecycle.LifecycleOwner lifecycleOwnerT = motionIndexFragment.t();
            kotlin.jvm.internal.Intrinsics.d(lifecycleOwnerT, "getViewLifecycleOwner(...)");
            androidx.lifecycle.Lifecycle.State state = androidx.lifecycle.Lifecycle.State.e;
            com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7.AnonymousClass1 anonymousClass1 = new com.jorden.karto.setrisokegl.ui.catalog.MotionIndexFragment$onViewCreated$7.AnonymousClass1(motionIndexFragment, null);
            this.f3072f = 1;
            if (androidx.lifecycle.RepeatOnLifecycleKt.a(lifecycleOwnerT, state, anonymousClass1, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
