package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class TwinWeighViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.data.repository.EmberRepository b;
    public final com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase c;
    public final com.jorden.karto.setrisokegl.domain.usecase.RecordWeighInUseCase d;
    public final kotlinx.coroutines.flow.MutableStateFlow e;

    /* renamed from: f, reason: collision with root package name */
    public final kotlinx.coroutines.flow.StateFlow f3191f;

    /* renamed from: g, reason: collision with root package name */
    public final java.util.List f3192g;

    /* renamed from: h, reason: collision with root package name */
    public kotlin.Pair f3193h;

    @kotlin.Metadata
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$1", f = "TwinWeighViewModel.kt", l = {44}, m = "invokeSuspend")
    /* renamed from: com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$1, reason: invalid class name */
    final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

        /* renamed from: f, reason: collision with root package name */
        public int f3194f;

        public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
            super(2, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
            return ((com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.AnonymousClass1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
            return com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
            kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
            int i = this.f3194f;
            if (i == 0) {
                kotlin.ResultKt.b(obj);
                final com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel twinWeighViewModel = com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.this;
                com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1 emberRepository$observeWeighIns$$inlined$map$1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeWeighIns$$inlined$map$1(twinWeighViewModel.b.c.b());
                kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        java.lang.Object value;
                        int iIntValue = ((java.lang.Number) obj2).intValue();
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = twinWeighViewModel.e;
                        do {
                            value = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a((com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) value, null, null, iIntValue, null, 23)));
                        return kotlin.Unit.f3201a;
                    }
                };
                this.f3194f = 1;
                if (emberRepository$observeWeighIns$$inlined$map$1.a(flowCollector, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.b(obj);
            }
            return kotlin.Unit.f3201a;
        }
    }

    @kotlin.Metadata
    public /* synthetic */ class WhenMappings {
        static {
            int[] iArr = new int[com.jorden.karto.setrisokegl.ui.tool.Pan.values().length];
            try {
                iArr[0] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                com.jorden.karto.setrisokegl.ui.tool.Pan pan = com.jorden.karto.setrisokegl.ui.tool.Pan.b;
                iArr[1] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
        }
    }

    public TwinWeighViewModel(com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase weighPairUseCase, com.jorden.karto.setrisokegl.domain.usecase.RecordWeighInUseCase recordWeighInUseCase, com.jorden.karto.setrisokegl.domain.usecase.ScaleCeilingUseCase scaleCeilingUseCase) {
        this.b = emberRepository;
        this.c = weighPairUseCase;
        this.d = recordWeighInUseCase;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(new com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState(null, null, 10.0f, 0, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict.Waiting.f3070a));
        this.e = mutableStateFlowA;
        this.f3191f = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
        this.f3192g = emberRepository.d;
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel.AnonymousClass1(null), 3);
    }

    public final void i(com.jorden.karto.setrisokegl.ui.tool.Pan pan, com.jorden.karto.setrisokegl.data.model.Move move) {
        java.lang.Object value;
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiStateA;
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState;
        com.jorden.karto.setrisokegl.data.model.Move move2;
        kotlin.jvm.internal.Intrinsics.e(move, "move");
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = this.e;
        do {
            value = mutableStateFlow.getValue();
            com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState2 = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) value;
            int iOrdinal = pan.ordinal();
            if (iOrdinal == 0) {
                twinWeighUiStateA = com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a(twinWeighUiState2, move, null, 0, null, 30);
            } else {
                if (iOrdinal != 1) {
                    throw new kotlin.NoWhenBranchMatchedException();
                }
                twinWeighUiStateA = com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a(twinWeighUiState2, null, move, 0, null, 29);
            }
            twinWeighUiState = twinWeighUiStateA;
            this.c.getClass();
        } while (!mutableStateFlow.h(value, com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState.a(twinWeighUiState, null, null, 0, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.a(twinWeighUiState.f3190a, twinWeighUiState.b), 15)));
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState3 = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) mutableStateFlow.getValue();
        com.jorden.karto.setrisokegl.data.model.Move move3 = twinWeighUiState3.f3190a;
        if (move3 == null || (move2 = twinWeighUiState3.b) == null) {
            return;
        }
        java.lang.String str = move3.f2953a;
        java.lang.String str2 = move2.f2953a;
        kotlin.Pair pair = str.compareTo(str2) <= 0 ? new kotlin.Pair(str, str2) : new kotlin.Pair(str2, str);
        if (pair.equals(this.f3193h)) {
            return;
        }
        this.f3193h = pair;
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.tool.TwinWeighViewModel$countIfComplete$1(this, null), 3);
    }
}
