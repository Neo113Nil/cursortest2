package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onLastGoPicked$1", f = "EffortSheetViewModel.kt", l = {57}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EffortSheetViewModel$onLastGoPicked$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3123f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel f3124g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ long f3125h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EffortSheetViewModel$onLastGoPicked$1(com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel, long j2, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3124g = effortSheetViewModel;
        this.f3125h = j2;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onLastGoPicked$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$onLastGoPicked$1(this.f3124g, this.f3125h, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3123f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel = this.f3124g;
            java.lang.String str = effortSheetViewModel.f3113j;
            this.f3123f = 1;
            com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = effortSheetViewModel.e.f3066a;
            final long j2 = this.f3125h;
            java.lang.Object objF = emberRepository.f(str, new kotlin.jvm.functions.Function1() { // from class: com.jorden.karto.setrisokegl.data.repository.a
                @Override // kotlin.jvm.functions.Function1
                public final java.lang.Object m(java.lang.Object obj2) {
                    com.jorden.karto.setrisokegl.data.db.MoveStateEntity it = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj2;
                    kotlin.jvm.internal.Intrinsics.e(it, "it");
                    return com.jorden.karto.setrisokegl.data.db.MoveStateEntity.a(it, false, false, java.lang.Long.valueOf(j2), null, 23);
                }
            }, this);
            if (objF != coroutineSingletons) {
                objF = unit;
            }
            if (objF != coroutineSingletons) {
                objF = unit;
            }
            if (objF == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return unit;
    }
}
