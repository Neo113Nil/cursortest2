package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class RecentLinkAdapter$Companion$DIFF$1 extends androidx.recyclerview.widget.DiffUtil.ItemCallback<com.jorden.karto.setrisokegl.data.model.Move> {
    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean a(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.Move) obj).equals((com.jorden.karto.setrisokegl.data.model.Move) obj2);
    }

    @Override // androidx.recyclerview.widget.DiffUtil.ItemCallback
    public final boolean b(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.data.model.Move) obj).f2953a.equals(((com.jorden.karto.setrisokegl.data.model.Move) obj2).f2953a);
    }
}
