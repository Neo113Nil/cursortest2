package com.jorden.karto.setrisokegl.ui.profile;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$onResetConfirmed$1", f = "StokerLogViewModel.kt", l = {51}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class StokerLogViewModel$onResetConfirmed$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3158f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel f3159g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StokerLogViewModel$onResetConfirmed$1(com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3159g = stokerLogViewModel;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$onResetConfirmed$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel$onResetConfirmed$1(this.f3159g, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3158f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.ui.profile.StokerLogViewModel stokerLogViewModel = this.f3159g;
            this.f3158f = 1;
            java.lang.Object objC = stokerLogViewModel.d.f3055a.c(this);
            if (objC != coroutineSingletons) {
                objC = unit;
            }
            if (objC == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return unit;
    }
}
