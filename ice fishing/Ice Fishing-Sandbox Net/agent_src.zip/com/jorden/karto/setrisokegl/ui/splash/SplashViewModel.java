package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class SplashViewModel extends androidx.lifecycle.ViewModel {
    public final com.jorden.karto.setrisokegl.domain.usecase.GetCachedSplashUseCase b;
    public final com.jorden.karto.setrisokegl.domain.usecase.LoadSplashUseCase c;
    public final kotlinx.coroutines.flow.MutableStateFlow d;
    public final kotlinx.coroutines.flow.StateFlow e;

    /* renamed from: f, reason: collision with root package name */
    public final kotlinx.coroutines.flow.SharedFlowImpl f3176f;

    /* renamed from: g, reason: collision with root package name */
    public final kotlinx.coroutines.flow.SharedFlow f3177g;

    /* renamed from: h, reason: collision with root package name */
    public final kotlinx.coroutines.flow.SharedFlowImpl f3178h;
    public final kotlinx.coroutines.flow.SharedFlow i;

    public SplashViewModel(com.jorden.karto.setrisokegl.domain.usecase.GetCachedSplashUseCase getCachedSplashUseCase, com.jorden.karto.setrisokegl.domain.usecase.LoadSplashUseCase loadSplashUseCase) {
        this.b = getCachedSplashUseCase;
        this.c = loadSplashUseCase;
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlowA = kotlinx.coroutines.flow.StateFlowKt.a(com.jorden.karto.setrisokegl.ui.splash.SplashState.Loading.f3175a);
        this.d = mutableStateFlowA;
        this.e = kotlinx.coroutines.flow.FlowKt.b(mutableStateFlowA);
        kotlinx.coroutines.flow.SharedFlowImpl sharedFlowImplB = kotlinx.coroutines.flow.SharedFlowKt.b(null, 6);
        this.f3176f = sharedFlowImplB;
        this.f3177g = kotlinx.coroutines.flow.FlowKt.a(sharedFlowImplB);
        kotlinx.coroutines.flow.SharedFlowImpl sharedFlowImplB2 = kotlinx.coroutines.flow.SharedFlowKt.b(null, 6);
        this.f3178h = sharedFlowImplB2;
        this.i = kotlinx.coroutines.flow.FlowKt.a(sharedFlowImplB2);
        kotlinx.coroutines.BuildersKt.c(androidx.lifecycle.ViewModelKt.a(this), null, null, new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(this, null), 3);
    }
}
