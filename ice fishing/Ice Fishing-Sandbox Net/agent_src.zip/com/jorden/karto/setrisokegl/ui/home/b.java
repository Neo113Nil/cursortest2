package com.jorden.karto.setrisokegl.ui.home;

/* loaded from: classes.dex */
public final /* synthetic */ class b implements kotlin.jvm.functions.Function0 {
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment b;

    public /* synthetic */ b(com.jorden.karto.setrisokegl.ui.home.FurnaceFloorFragment furnaceFloorFragment) {
        this.b = furnaceFloorFragment;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, kotlin.Lazy] */
    @Override // kotlin.jvm.functions.Function0
    public final java.lang.Object d() {
        java.lang.Object value;
        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState furnaceFloorUiState;
        com.jorden.karto.setrisokegl.data.model.Move hero;
        com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel furnaceFloorViewModel = (com.jorden.karto.setrisokegl.ui.home.FurnaceFloorViewModel) this.b.d0.getValue();
        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = furnaceFloorViewModel.c;
        do {
            value = mutableStateFlow.getValue();
            furnaceFloorUiState = (com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState) value;
            hero = furnaceFloorViewModel.b.a(furnaceFloorUiState.f3142a.f2953a);
            kotlin.jvm.internal.Intrinsics.e(hero, "hero");
        } while (!mutableStateFlow.h(value, new com.jorden.karto.setrisokegl.ui.home.FurnaceFloorUiState(hero, furnaceFloorUiState.b)));
        return kotlin.Unit.f3201a;
    }
}
