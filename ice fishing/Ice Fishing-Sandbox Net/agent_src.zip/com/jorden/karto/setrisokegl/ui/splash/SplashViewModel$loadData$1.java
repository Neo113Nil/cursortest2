package com.jorden.karto.setrisokegl.ui.splash;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1", f = "SplashViewModel.kt", l = {44, 44, 46, 48}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class SplashViewModel$loadData$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3179f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.splash.SplashViewModel f3180g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SplashViewModel$loadData$1(com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModel, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3180g = splashViewModel;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.splash.SplashViewModel$loadData$1(this.f3180g, continuation);
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0060 A[Catch: CancellationException -> 0x001a, Exception -> 0x007a, TryCatch #2 {CancellationException -> 0x001a, Exception -> 0x007a, blocks: (B:8:0x0016, B:14:0x0024, B:26:0x004d, B:27:0x004f, B:29:0x0060, B:32:0x006f, B:15:0x0028, B:21:0x003c, B:23:0x0040, B:18:0x002f), top: B:38:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x006f A[Catch: CancellationException -> 0x001a, Exception -> 0x007a, TRY_LEAVE, TryCatch #2 {CancellationException -> 0x001a, Exception -> 0x007a, blocks: (B:8:0x0016, B:14:0x0024, B:26:0x004d, B:27:0x004f, B:29:0x0060, B:32:0x006f, B:15:0x0028, B:21:0x003c, B:23:0x0040, B:18:0x002f), top: B:38:0x000c }] */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        com.jorden.karto.setrisokegl.data.model.SplashResponse splashResponse;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3179f;
        kotlin.Unit unit = kotlin.Unit.f3201a;
        com.jorden.karto.setrisokegl.ui.splash.SplashViewModel splashViewModel = this.f3180g;
        try {
        } catch (java.util.concurrent.CancellationException e) {
            throw e;
        } catch (java.lang.Exception unused) {
            splashViewModel.d.setValue(com.jorden.karto.setrisokegl.ui.splash.SplashState.Error.f3174a);
        }
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            com.jorden.karto.setrisokegl.domain.usecase.GetCachedSplashUseCase getCachedSplashUseCase = splashViewModel.b;
            this.f3179f = 1;
            obj = getCachedSplashUseCase.f3056a.b(this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3 && i != 4) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    kotlin.ResultKt.b(obj);
                    return unit;
                }
                kotlin.ResultKt.b(obj);
                splashResponse = (com.jorden.karto.setrisokegl.data.model.SplashResponse) obj;
                kotlin.jvm.internal.Intrinsics.e(splashResponse, "<this>");
                if (kotlin.jvm.internal.Intrinsics.a(splashResponse.d(), "Moderate")) {
                    kotlinx.coroutines.flow.SharedFlowImpl sharedFlowImpl = splashViewModel.f3176f;
                    this.f3179f = 4;
                    if (sharedFlowImpl.c(unit, this) == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                } else {
                    kotlinx.coroutines.flow.SharedFlowImpl sharedFlowImpl2 = splashViewModel.f3178h;
                    java.lang.String strA = splashResponse.a();
                    this.f3179f = 3;
                    if (sharedFlowImpl2.c(strA, this) == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                }
                return unit;
            }
            kotlin.ResultKt.b(obj);
        }
        splashResponse = (com.jorden.karto.setrisokegl.data.model.SplashResponse) obj;
        if (splashResponse == null) {
            com.jorden.karto.setrisokegl.domain.usecase.LoadSplashUseCase loadSplashUseCase = splashViewModel.c;
            this.f3179f = 2;
            obj = loadSplashUseCase.f3057a.a(this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
            splashResponse = (com.jorden.karto.setrisokegl.data.model.SplashResponse) obj;
        }
        kotlin.jvm.internal.Intrinsics.e(splashResponse, "<this>");
        if (kotlin.jvm.internal.Intrinsics.a(splashResponse.d(), "Moderate")) {
        }
        return unit;
    }
}
