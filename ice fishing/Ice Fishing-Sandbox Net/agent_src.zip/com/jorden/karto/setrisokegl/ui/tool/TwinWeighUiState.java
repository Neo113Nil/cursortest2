package com.jorden.karto.setrisokegl.ui.tool;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class TwinWeighUiState {

    /* renamed from: a, reason: collision with root package name */
    public final com.jorden.karto.setrisokegl.data.model.Move f3190a;
    public final com.jorden.karto.setrisokegl.data.model.Move b;
    public final float c;
    public final int d;
    public final com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict e;

    public TwinWeighUiState(com.jorden.karto.setrisokegl.data.model.Move move, com.jorden.karto.setrisokegl.data.model.Move move2, float f2, int i, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict verdict) {
        kotlin.jvm.internal.Intrinsics.e(verdict, "verdict");
        this.f3190a = move;
        this.b = move2;
        this.c = f2;
        this.d = i;
        this.e = verdict;
    }

    public static com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState a(com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState, com.jorden.karto.setrisokegl.data.model.Move move, com.jorden.karto.setrisokegl.data.model.Move move2, int i, com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict verdict, int i2) {
        if ((i2 & 1) != 0) {
            move = twinWeighUiState.f3190a;
        }
        com.jorden.karto.setrisokegl.data.model.Move move3 = move;
        if ((i2 & 2) != 0) {
            move2 = twinWeighUiState.b;
        }
        com.jorden.karto.setrisokegl.data.model.Move move4 = move2;
        float f2 = twinWeighUiState.c;
        if ((i2 & 8) != 0) {
            i = twinWeighUiState.d;
        }
        int i3 = i;
        if ((i2 & 16) != 0) {
            verdict = twinWeighUiState.e;
        }
        com.jorden.karto.setrisokegl.domain.usecase.WeighPairUseCase.Verdict verdict2 = verdict;
        twinWeighUiState.getClass();
        kotlin.jvm.internal.Intrinsics.e(verdict2, "verdict");
        return new com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState(move3, move4, f2, i3, verdict2);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState)) {
            return false;
        }
        com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState twinWeighUiState = (com.jorden.karto.setrisokegl.ui.tool.TwinWeighUiState) obj;
        return kotlin.jvm.internal.Intrinsics.a(this.f3190a, twinWeighUiState.f3190a) && kotlin.jvm.internal.Intrinsics.a(this.b, twinWeighUiState.b) && java.lang.Float.compare(this.c, twinWeighUiState.c) == 0 && this.d == twinWeighUiState.d && kotlin.jvm.internal.Intrinsics.a(this.e, twinWeighUiState.e);
    }

    public final int hashCode() {
        com.jorden.karto.setrisokegl.data.model.Move move = this.f3190a;
        int iHashCode = (move == null ? 0 : move.hashCode()) * 31;
        com.jorden.karto.setrisokegl.data.model.Move move2 = this.b;
        return this.e.hashCode() + ((java.lang.Integer.hashCode(this.d) + ((java.lang.Float.hashCode(this.c) + ((iHashCode + (move2 != null ? move2.hashCode() : 0)) * 31)) * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "TwinWeighUiState(left=" + this.f3190a + ", right=" + this.b + ", ceiling=" + this.c + ", weighIns=" + this.d + ", verdict=" + this.e + ")";
    }
}
