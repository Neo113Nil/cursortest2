package com.jorden.karto.setrisokegl.ui.detail;

@kotlin.Metadata
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$3", f = "EffortSheetViewModel.kt", l = {44}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class EffortSheetViewModel$open$3 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {

    /* renamed from: f, reason: collision with root package name */
    public int f3129f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel f3130g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ java.lang.String f3131h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EffortSheetViewModel$open$3(com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel, java.lang.String str, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.f3130g = effortSheetViewModel;
        this.f3131h = str;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object l(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$3) n((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).p(kotlin.Unit.f3201a);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation n(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$3(this.f3130g, this.f3131h, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object p(java.lang.Object obj) throws java.lang.Throwable {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
        int i = this.f3129f;
        if (i == 0) {
            kotlin.ResultKt.b(obj);
            final com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel effortSheetViewModel = this.f3130g;
            com.jorden.karto.setrisokegl.domain.usecase.ObserveEntryUseCase observeEntryUseCase = effortSheetViewModel.b;
            observeEntryUseCase.getClass();
            final java.lang.String str = this.f3131h;
            final com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = observeEntryUseCase.f3059a;
            final androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1 flowUtil$createFlow$$inlined$map$1D = emberRepository.f2973a.d(str);
            kotlinx.coroutines.flow.Flow<com.jorden.karto.setrisokegl.data.model.MoveEntry> flow = new kotlinx.coroutines.flow.Flow<com.jorden.karto.setrisokegl.data.model.MoveEntry>() { // from class: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1

                @kotlin.Metadata
                @kotlin.jvm.internal.SourceDebugExtension
                /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1$2, reason: invalid class name */
                public final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                    public final /* synthetic */ kotlinx.coroutines.flow.FlowCollector b;
                    public final /* synthetic */ com.jorden.karto.setrisokegl.data.repository.EmberRepository c;
                    public final /* synthetic */ java.lang.String d;

                    @kotlin.Metadata
                    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1$2", f = "EmberRepository.kt", l = {219}, m = "emit")
                    /* renamed from: com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1$2$1, reason: invalid class name */
                    public final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                        public /* synthetic */ java.lang.Object e;

                        /* renamed from: f, reason: collision with root package name */
                        public int f2976f;

                        public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                            super(continuation);
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final java.lang.Object p(java.lang.Object obj) {
                            this.e = obj;
                            this.f2976f |= Integer.MIN_VALUE;
                            return com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2.this.c(null, this);
                        }
                    }

                    public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector, com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository, java.lang.String str) {
                        this.b = flowCollector;
                        this.c = emberRepository;
                        this.d = str;
                    }

                    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                    */
                    public final java.lang.Object c(java.lang.Object obj, kotlin.coroutines.Continuation continuation) throws java.lang.Throwable {
                        com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                        if (continuation instanceof com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                            anonymousClass1 = (com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                            int i = anonymousClass1.f2976f;
                            if ((i & Integer.MIN_VALUE) != 0) {
                                anonymousClass1.f2976f = i - Integer.MIN_VALUE;
                            } else {
                                anonymousClass1 = new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                            }
                        }
                        java.lang.Object obj2 = anonymousClass1.e;
                        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.b;
                        int i2 = anonymousClass1.f2976f;
                        if (i2 == 0) {
                            kotlin.ResultKt.b(obj2);
                            com.jorden.karto.setrisokegl.data.db.MoveStateEntity moveStateEntity = (com.jorden.karto.setrisokegl.data.db.MoveStateEntity) obj;
                            com.jorden.karto.setrisokegl.data.repository.EmberRepository emberRepository = this.c;
                            java.lang.String str = this.d;
                            com.jorden.karto.setrisokegl.data.model.Move moveD = com.jorden.karto.setrisokegl.data.repository.EmberRepository.d(str);
                            com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = moveD != null ? new com.jorden.karto.setrisokegl.data.model.MoveEntry(moveD, com.jorden.karto.setrisokegl.data.repository.EmberRepository.a(emberRepository, moveStateEntity, str)) : null;
                            anonymousClass1.f2976f = 1;
                            if (this.b.c(moveEntry, anonymousClass1) == coroutineSingletons) {
                                return coroutineSingletons;
                            }
                        } else {
                            if (i2 != 1) {
                                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            kotlin.ResultKt.b(obj2);
                        }
                        return kotlin.Unit.f3201a;
                    }
                }

                @Override // kotlinx.coroutines.flow.Flow
                public final java.lang.Object a(kotlinx.coroutines.flow.FlowCollector flowCollector, kotlin.coroutines.Continuation continuation) {
                    java.lang.Object objA = flowUtil$createFlow$$inlined$map$1D.a(new com.jorden.karto.setrisokegl.data.repository.EmberRepository$observeEntry$$inlined$map$1.AnonymousClass2(flowCollector, emberRepository, str), continuation);
                    return objA == kotlin.coroutines.intrinsics.CoroutineSingletons.b ? objA : kotlin.Unit.f3201a;
                }
            };
            kotlinx.coroutines.flow.FlowCollector flowCollector = new kotlinx.coroutines.flow.FlowCollector() { // from class: com.jorden.karto.setrisokegl.ui.detail.EffortSheetViewModel$open$3.1
                @Override // kotlinx.coroutines.flow.FlowCollector
                public final java.lang.Object c(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                    java.lang.Object value;
                    float f2;
                    com.jorden.karto.setrisokegl.data.model.MoveEntry moveEntry = (com.jorden.karto.setrisokegl.data.model.MoveEntry) obj2;
                    kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = effortSheetViewModel.f3112h;
                    do {
                        value = mutableStateFlow.getValue();
                        com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState effortSheetUiState = (com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState) value;
                        f2 = effortSheetUiState.b;
                        effortSheetUiState.getClass();
                    } while (!mutableStateFlow.h(value, new com.jorden.karto.setrisokegl.ui.detail.EffortSheetUiState(moveEntry, f2)));
                    return kotlin.Unit.f3201a;
                }
            };
            this.f3129f = 1;
            if (flow.a(flowCollector, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.b(obj);
        }
        return kotlin.Unit.f3201a;
    }
}
