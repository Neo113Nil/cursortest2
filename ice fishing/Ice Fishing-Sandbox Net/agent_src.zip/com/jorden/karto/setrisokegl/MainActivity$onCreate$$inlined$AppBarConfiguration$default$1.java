package com.jorden.karto.setrisokegl;

@kotlin.Metadata
/* loaded from: classes.dex */
public final class MainActivity$onCreate$$inlined$AppBarConfiguration$default$1 extends kotlin.jvm.internal.Lambda implements kotlin.jvm.functions.Function0<java.lang.Boolean> {
    public static final com.jorden.karto.setrisokegl.MainActivity$onCreate$$inlined$AppBarConfiguration$default$1 c = new com.jorden.karto.setrisokegl.MainActivity$onCreate$$inlined$AppBarConfiguration$default$1(0);

    @Override // kotlin.jvm.functions.Function0
    public final /* bridge */ /* synthetic */ java.lang.Object d() {
        return java.lang.Boolean.FALSE;
    }
}
