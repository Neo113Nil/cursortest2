package com.jorden.karto.setrisokegl;

/* loaded from: classes.dex */
public final class R {

    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 0x7f010002;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_enter = 0x7f010003;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_exit = 0x7f010004;

        /* JADX INFO: Added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 0x7f010005;

        /* JADX INFO: Added by JADX */
        public static final int band_enter = 0x7f01000c;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 0x7f01000d;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 0x7f01000e;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 0x7f01000f;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 0x7f010010;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 0x7f010011;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 0x7f010012;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 0x7f010013;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 0x7f010014;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 0x7f010015;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 0x7f010016;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 0x7f010017;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 0x7f010018;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_slide_in = 0x7f010019;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_slide_out = 0x7f01001a;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 0x7f01001d;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line1_head_interpolator = 0x7f01001e;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line1_tail_interpolator = 0x7f01001f;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line2_head_interpolator = 0x7f010020;

        /* JADX INFO: Added by JADX */
        public static final int linear_indeterminate_line2_tail_interpolator = 0x7f010021;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_slide_in = 0x7f010022;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_slide_out = 0x7f010023;

        /* JADX INFO: Added by JADX */
        public static final int m3_motion_fade_enter = 0x7f010024;

        /* JADX INFO: Added by JADX */
        public static final int m3_motion_fade_exit = 0x7f010025;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_enter_from_left = 0x7f010026;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_enter_from_right = 0x7f010027;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_exit_to_left = 0x7f010028;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_exit_to_right = 0x7f010029;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottom_sheet_slide_in = 0x7f01002a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottom_sheet_slide_out = 0x7f01002b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_lowers_interpolator = 0x7f01002c;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_enter_anim = 0x7f01002d;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_exit_anim = 0x7f01002e;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_pop_enter_anim = 0x7f01002f;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_pop_exit_anim = 0x7f010030;
    }

    /* JADX INFO: Added by JADX */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int design_appbar_state_list_animator = 0x7f020000;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_hide_motion_spec = 0x7f020001;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_show_motion_spec = 0x7f020002;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 0x7f020003;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 0x7f020005;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 0x7f020006;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 0x7f020007;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 0x7f020008;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_state_list_animator = 0x7f020009;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_state_list_anim = 0x7f02000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_state_list_anim = 0x7f02000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_state_list_anim = 0x7f02000d;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_state_list_anim = 0x7f02000e;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_change_size_collapse_motion_spec = 0x7f020010;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_change_size_expand_motion_spec = 0x7f020011;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_hide_motion_spec = 0x7f020012;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_show_motion_spec = 0x7f020013;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_state_list_animator = 0x7f020014;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_state_list_anim = 0x7f020015;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_unelevated_state_list_anim = 0x7f020016;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_state_list_anim = 0x7f020017;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_state_list_anim = 0x7f020018;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_state_list_animator = 0x7f02001d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_hide_motion_spec = 0x7f02001e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_show_motion_spec = 0x7f02001f;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_enter_anim = 0x7f020022;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_exit_anim = 0x7f020023;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_pop_enter_anim = 0x7f020024;

        /* JADX INFO: Added by JADX */
        public static final int nav_default_pop_exit_anim = 0x7f020025;
    }

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int SharedValue = 0x7f030000;

        /* JADX INFO: Added by JADX */
        public static final int SharedValueId = 0x7f030001;

        /* JADX INFO: Added by JADX */
        public static final int action = 0x7f030002;

        /* JADX INFO: Added by JADX */
        public static final int actionBarDivider = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int actionBarItemBackground = 0x7f030004;

        /* JADX INFO: Added by JADX */
        public static final int actionBarPopupTheme = 0x7f030005;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSize = 0x7f030006;

        /* JADX INFO: Added by JADX */
        public static final int actionBarSplitStyle = 0x7f030007;

        /* JADX INFO: Added by JADX */
        public static final int actionBarStyle = 0x7f030008;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabBarStyle = 0x7f030009;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabStyle = 0x7f03000a;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTabTextStyle = 0x7f03000b;

        /* JADX INFO: Added by JADX */
        public static final int actionBarTheme = 0x7f03000c;

        /* JADX INFO: Added by JADX */
        public static final int actionBarWidgetTheme = 0x7f03000d;

        /* JADX INFO: Added by JADX */
        public static final int actionButtonStyle = 0x7f03000e;

        /* JADX INFO: Added by JADX */
        public static final int actionDropDownStyle = 0x7f03000f;

        /* JADX INFO: Added by JADX */
        public static final int actionLayout = 0x7f030010;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextAppearance = 0x7f030011;

        /* JADX INFO: Added by JADX */
        public static final int actionMenuTextColor = 0x7f030012;

        /* JADX INFO: Added by JADX */
        public static final int actionModeBackground = 0x7f030013;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseButtonStyle = 0x7f030014;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseContentDescription = 0x7f030015;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCloseDrawable = 0x7f030016;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCopyDrawable = 0x7f030017;

        /* JADX INFO: Added by JADX */
        public static final int actionModeCutDrawable = 0x7f030018;

        /* JADX INFO: Added by JADX */
        public static final int actionModeFindDrawable = 0x7f030019;

        /* JADX INFO: Added by JADX */
        public static final int actionModePasteDrawable = 0x7f03001a;

        /* JADX INFO: Added by JADX */
        public static final int actionModePopupWindowStyle = 0x7f03001b;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSelectAllDrawable = 0x7f03001c;

        /* JADX INFO: Added by JADX */
        public static final int actionModeShareDrawable = 0x7f03001d;

        /* JADX INFO: Added by JADX */
        public static final int actionModeSplitBackground = 0x7f03001e;

        /* JADX INFO: Added by JADX */
        public static final int actionModeStyle = 0x7f03001f;

        /* JADX INFO: Added by JADX */
        public static final int actionModeTheme = 0x7f030020;

        /* JADX INFO: Added by JADX */
        public static final int actionModeWebSearchDrawable = 0x7f030021;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowButtonStyle = 0x7f030022;

        /* JADX INFO: Added by JADX */
        public static final int actionOverflowMenuStyle = 0x7f030023;

        /* JADX INFO: Added by JADX */
        public static final int actionProviderClass = 0x7f030024;

        /* JADX INFO: Added by JADX */
        public static final int actionTextColorAlpha = 0x7f030025;

        /* JADX INFO: Added by JADX */
        public static final int actionViewClass = 0x7f030026;

        /* JADX INFO: Added by JADX */
        public static final int activeIndicatorLabelPadding = 0x7f030027;

        /* JADX INFO: Added by JADX */
        public static final int activityAction = 0x7f030028;

        /* JADX INFO: Added by JADX */
        public static final int activityChooserViewStyle = 0x7f030029;

        /* JADX INFO: Added by JADX */
        public static final int activityName = 0x7f03002a;

        /* JADX INFO: Added by JADX */
        public static final int addElevationShadow = 0x7f03002b;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogButtonGroupStyle = 0x7f03002c;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogCenterButtons = 0x7f03002d;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogStyle = 0x7f03002e;

        /* JADX INFO: Added by JADX */
        public static final int alertDialogTheme = 0x7f03002f;

        /* JADX INFO: Added by JADX */
        public static final int allowStacking = 0x7f030030;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f030031;

        /* JADX INFO: Added by JADX */
        public static final int alphabeticModifiers = 0x7f030032;

        /* JADX INFO: Added by JADX */
        public static final int altSrc = 0x7f030033;

        /* JADX INFO: Added by JADX */
        public static final int alwaysExpand = 0x7f030034;

        /* JADX INFO: Added by JADX */
        public static final int animateCircleAngleTo = 0x7f030035;

        /* JADX INFO: Added by JADX */
        public static final int animateMenuItems = 0x7f030036;

        /* JADX INFO: Added by JADX */
        public static final int animateNavigationIcon = 0x7f030037;

        /* JADX INFO: Added by JADX */
        public static final int animateRelativeTo = 0x7f030038;

        /* JADX INFO: Added by JADX */
        public static final int animationMode = 0x7f030039;

        /* JADX INFO: Added by JADX */
        public static final int appBarLayoutStyle = 0x7f03003a;

        /* JADX INFO: Added by JADX */
        public static final int applyMotionScene = 0x7f03003b;

        /* JADX INFO: Added by JADX */
        public static final int arcMode = 0x7f03003c;

        /* JADX INFO: Added by JADX */
        public static final int argType = 0x7f03003d;

        /* JADX INFO: Added by JADX */
        public static final int arrowHeadLength = 0x7f03003e;

        /* JADX INFO: Added by JADX */
        public static final int arrowShaftLength = 0x7f03003f;

        /* JADX INFO: Added by JADX */
        public static final int attributeName = 0x7f030040;

        /* JADX INFO: Added by JADX */
        public static final int autoAdjustToWithinGrandparentBounds = 0x7f030041;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteMode = 0x7f030042;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteTextViewStyle = 0x7f030043;

        /* JADX INFO: Added by JADX */
        public static final int autoShowKeyboard = 0x7f030044;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMaxTextSize = 0x7f030045;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeMinTextSize = 0x7f030046;

        /* JADX INFO: Added by JADX */
        public static final int autoSizePresetSizes = 0x7f030047;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeStepGranularity = 0x7f030048;

        /* JADX INFO: Added by JADX */
        public static final int autoSizeTextType = 0x7f030049;

        /* JADX INFO: Added by JADX */
        public static final int autoTransition = 0x7f03004a;

        /* JADX INFO: Added by JADX */
        public static final int backHandlingEnabled = 0x7f03004b;

        /* JADX INFO: Added by JADX */
        public static final int background = 0x7f03004c;

        /* JADX INFO: Added by JADX */
        public static final int backgroundColor = 0x7f03004d;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetBottom = 0x7f03004e;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetEnd = 0x7f03004f;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetStart = 0x7f030050;

        /* JADX INFO: Added by JADX */
        public static final int backgroundInsetTop = 0x7f030051;

        /* JADX INFO: Added by JADX */
        public static final int backgroundOverlayColorAlpha = 0x7f030052;

        /* JADX INFO: Added by JADX */
        public static final int backgroundSplit = 0x7f030053;

        /* JADX INFO: Added by JADX */
        public static final int backgroundStacked = 0x7f030054;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTint = 0x7f030055;

        /* JADX INFO: Added by JADX */
        public static final int backgroundTintMode = 0x7f030056;

        /* JADX INFO: Added by JADX */
        public static final int badgeGravity = 0x7f030057;

        /* JADX INFO: Added by JADX */
        public static final int badgeHeight = 0x7f030058;

        /* JADX INFO: Added by JADX */
        public static final int badgeRadius = 0x7f030059;

        /* JADX INFO: Added by JADX */
        public static final int badgeShapeAppearance = 0x7f03005a;

        /* JADX INFO: Added by JADX */
        public static final int badgeShapeAppearanceOverlay = 0x7f03005b;

        /* JADX INFO: Added by JADX */
        public static final int badgeStyle = 0x7f03005c;

        /* JADX INFO: Added by JADX */
        public static final int badgeText = 0x7f03005d;

        /* JADX INFO: Added by JADX */
        public static final int badgeTextAppearance = 0x7f03005e;

        /* JADX INFO: Added by JADX */
        public static final int badgeTextColor = 0x7f03005f;

        /* JADX INFO: Added by JADX */
        public static final int badgeVerticalPadding = 0x7f030060;

        /* JADX INFO: Added by JADX */
        public static final int badgeWidePadding = 0x7f030061;

        /* JADX INFO: Added by JADX */
        public static final int badgeWidth = 0x7f030062;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextHeight = 0x7f030063;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextRadius = 0x7f030064;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextShapeAppearance = 0x7f030065;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextShapeAppearanceOverlay = 0x7f030066;

        /* JADX INFO: Added by JADX */
        public static final int badgeWithTextWidth = 0x7f030067;

        /* JADX INFO: Added by JADX */
        public static final int barLength = 0x7f030068;

        /* JADX INFO: Added by JADX */
        public static final int barrierAllowsGoneWidgets = 0x7f030069;

        /* JADX INFO: Added by JADX */
        public static final int barrierDirection = 0x7f03006a;

        /* JADX INFO: Added by JADX */
        public static final int barrierMargin = 0x7f03006b;

        /* JADX INFO: Added by JADX */
        public static final int behavior_autoHide = 0x7f03006c;

        /* JADX INFO: Added by JADX */
        public static final int behavior_autoShrink = 0x7f03006d;

        /* JADX INFO: Added by JADX */
        public static final int behavior_draggable = 0x7f03006e;

        /* JADX INFO: Added by JADX */
        public static final int behavior_expandedOffset = 0x7f03006f;

        /* JADX INFO: Added by JADX */
        public static final int behavior_fitToContents = 0x7f030070;

        /* JADX INFO: Added by JADX */
        public static final int behavior_halfExpandedRatio = 0x7f030071;

        /* JADX INFO: Added by JADX */
        public static final int behavior_hideable = 0x7f030072;

        /* JADX INFO: Added by JADX */
        public static final int behavior_overlapTop = 0x7f030073;

        /* JADX INFO: Added by JADX */
        public static final int behavior_peekHeight = 0x7f030074;

        /* JADX INFO: Added by JADX */
        public static final int behavior_saveFlags = 0x7f030075;

        /* JADX INFO: Added by JADX */
        public static final int behavior_significantVelocityThreshold = 0x7f030076;

        /* JADX INFO: Added by JADX */
        public static final int behavior_skipCollapsed = 0x7f030077;

        /* JADX INFO: Added by JADX */
        public static final int blendSrc = 0x7f030078;

        /* JADX INFO: Added by JADX */
        public static final int borderRound = 0x7f030079;

        /* JADX INFO: Added by JADX */
        public static final int borderRoundPercent = 0x7f03007a;

        /* JADX INFO: Added by JADX */
        public static final int borderWidth = 0x7f03007b;

        /* JADX INFO: Added by JADX */
        public static final int borderlessButtonStyle = 0x7f03007c;

        /* JADX INFO: Added by JADX */
        public static final int bottomAppBarStyle = 0x7f03007d;

        /* JADX INFO: Added by JADX */
        public static final int bottomInsetScrimEnabled = 0x7f03007e;

        /* JADX INFO: Added by JADX */
        public static final int bottomNavigationStyle = 0x7f03007f;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetDialogTheme = 0x7f030080;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetDragHandleStyle = 0x7f030081;

        /* JADX INFO: Added by JADX */
        public static final int bottomSheetStyle = 0x7f030082;

        /* JADX INFO: Added by JADX */
        public static final int boxBackgroundColor = 0x7f030083;

        /* JADX INFO: Added by JADX */
        public static final int boxBackgroundMode = 0x7f030084;

        /* JADX INFO: Added by JADX */
        public static final int boxCollapsedPaddingTop = 0x7f030085;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusBottomEnd = 0x7f030086;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusBottomStart = 0x7f030087;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusTopEnd = 0x7f030088;

        /* JADX INFO: Added by JADX */
        public static final int boxCornerRadiusTopStart = 0x7f030089;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeColor = 0x7f03008a;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeErrorColor = 0x7f03008b;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeWidth = 0x7f03008c;

        /* JADX INFO: Added by JADX */
        public static final int boxStrokeWidthFocused = 0x7f03008d;

        /* JADX INFO: Added by JADX */
        public static final int brightness = 0x7f03008e;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarButtonStyle = 0x7f03008f;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNegativeButtonStyle = 0x7f030090;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarNeutralButtonStyle = 0x7f030091;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarPositiveButtonStyle = 0x7f030092;

        /* JADX INFO: Added by JADX */
        public static final int buttonBarStyle = 0x7f030093;

        /* JADX INFO: Added by JADX */
        public static final int buttonCompat = 0x7f030094;

        /* JADX INFO: Added by JADX */
        public static final int buttonGravity = 0x7f030095;

        /* JADX INFO: Added by JADX */
        public static final int buttonIcon = 0x7f030096;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconDimen = 0x7f030097;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconTint = 0x7f030098;

        /* JADX INFO: Added by JADX */
        public static final int buttonIconTintMode = 0x7f030099;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanelSideLayout = 0x7f03009a;

        /* JADX INFO: Added by JADX */
        public static final int buttonSize = 0x7f03009b;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyle = 0x7f03009c;

        /* JADX INFO: Added by JADX */
        public static final int buttonStyleSmall = 0x7f03009d;

        /* JADX INFO: Added by JADX */
        public static final int buttonTint = 0x7f03009e;

        /* JADX INFO: Added by JADX */
        public static final int buttonTintMode = 0x7f03009f;

        /* JADX INFO: Added by JADX */
        public static final int cardBackgroundColor = 0x7f0300a0;

        /* JADX INFO: Added by JADX */
        public static final int cardCornerRadius = 0x7f0300a1;

        /* JADX INFO: Added by JADX */
        public static final int cardElevation = 0x7f0300a2;

        /* JADX INFO: Added by JADX */
        public static final int cardForegroundColor = 0x7f0300a3;

        /* JADX INFO: Added by JADX */
        public static final int cardMaxElevation = 0x7f0300a4;

        /* JADX INFO: Added by JADX */
        public static final int cardPreventCornerOverlap = 0x7f0300a5;

        /* JADX INFO: Added by JADX */
        public static final int cardUseCompatPadding = 0x7f0300a6;

        /* JADX INFO: Added by JADX */
        public static final int cardViewStyle = 0x7f0300a7;

        /* JADX INFO: Added by JADX */
        public static final int carousel_alignment = 0x7f0300a8;

        /* JADX INFO: Added by JADX */
        public static final int carousel_backwardTransition = 0x7f0300a9;

        /* JADX INFO: Added by JADX */
        public static final int carousel_emptyViewsBehavior = 0x7f0300aa;

        /* JADX INFO: Added by JADX */
        public static final int carousel_firstView = 0x7f0300ab;

        /* JADX INFO: Added by JADX */
        public static final int carousel_forwardTransition = 0x7f0300ac;

        /* JADX INFO: Added by JADX */
        public static final int carousel_infinite = 0x7f0300ad;

        /* JADX INFO: Added by JADX */
        public static final int carousel_nextState = 0x7f0300ae;

        /* JADX INFO: Added by JADX */
        public static final int carousel_previousState = 0x7f0300af;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUpMode = 0x7f0300b0;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_dampeningFactor = 0x7f0300b1;

        /* JADX INFO: Added by JADX */
        public static final int carousel_touchUp_velocityThreshold = 0x7f0300b2;

        /* JADX INFO: Added by JADX */
        public static final int centerIfNoTextEnabled = 0x7f0300b3;

        /* JADX INFO: Added by JADX */
        public static final int chainUseRtl = 0x7f0300b4;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkCompat = 0x7f0300b5;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTint = 0x7f0300b6;

        /* JADX INFO: Added by JADX */
        public static final int checkMarkTintMode = 0x7f0300b7;

        /* JADX INFO: Added by JADX */
        public static final int checkboxStyle = 0x7f0300b8;

        /* JADX INFO: Added by JADX */
        public static final int checkedButton = 0x7f0300b9;

        /* JADX INFO: Added by JADX */
        public static final int checkedChip = 0x7f0300ba;

        /* JADX INFO: Added by JADX */
        public static final int checkedIcon = 0x7f0300bb;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconEnabled = 0x7f0300bc;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconGravity = 0x7f0300bd;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconMargin = 0x7f0300be;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconSize = 0x7f0300bf;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconTint = 0x7f0300c0;

        /* JADX INFO: Added by JADX */
        public static final int checkedIconVisible = 0x7f0300c1;

        /* JADX INFO: Added by JADX */
        public static final int checkedState = 0x7f0300c2;

        /* JADX INFO: Added by JADX */
        public static final int checkedTextViewStyle = 0x7f0300c3;

        /* JADX INFO: Added by JADX */
        public static final int chipBackgroundColor = 0x7f0300c4;

        /* JADX INFO: Added by JADX */
        public static final int chipCornerRadius = 0x7f0300c5;

        /* JADX INFO: Added by JADX */
        public static final int chipEndPadding = 0x7f0300c6;

        /* JADX INFO: Added by JADX */
        public static final int chipGroupStyle = 0x7f0300c7;

        /* JADX INFO: Added by JADX */
        public static final int chipIcon = 0x7f0300c8;

        /* JADX INFO: Added by JADX */
        public static final int chipIconEnabled = 0x7f0300c9;

        /* JADX INFO: Added by JADX */
        public static final int chipIconSize = 0x7f0300ca;

        /* JADX INFO: Added by JADX */
        public static final int chipIconTint = 0x7f0300cb;

        /* JADX INFO: Added by JADX */
        public static final int chipIconVisible = 0x7f0300cc;

        /* JADX INFO: Added by JADX */
        public static final int chipMinHeight = 0x7f0300cd;

        /* JADX INFO: Added by JADX */
        public static final int chipMinTouchTargetSize = 0x7f0300ce;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacing = 0x7f0300cf;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacingHorizontal = 0x7f0300d0;

        /* JADX INFO: Added by JADX */
        public static final int chipSpacingVertical = 0x7f0300d1;

        /* JADX INFO: Added by JADX */
        public static final int chipStandaloneStyle = 0x7f0300d2;

        /* JADX INFO: Added by JADX */
        public static final int chipStartPadding = 0x7f0300d3;

        /* JADX INFO: Added by JADX */
        public static final int chipStrokeColor = 0x7f0300d4;

        /* JADX INFO: Added by JADX */
        public static final int chipStrokeWidth = 0x7f0300d5;

        /* JADX INFO: Added by JADX */
        public static final int chipStyle = 0x7f0300d6;

        /* JADX INFO: Added by JADX */
        public static final int chipSurfaceColor = 0x7f0300d7;

        /* JADX INFO: Added by JADX */
        public static final int circleCrop = 0x7f0300d8;

        /* JADX INFO: Added by JADX */
        public static final int circleRadius = 0x7f0300d9;

        /* JADX INFO: Added by JADX */
        public static final int circularProgressIndicatorStyle = 0x7f0300da;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_angles = 0x7f0300db;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultAngle = 0x7f0300dc;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_defaultRadius = 0x7f0300dd;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_radiusInDP = 0x7f0300de;

        /* JADX INFO: Added by JADX */
        public static final int circularflow_viewCenter = 0x7f0300df;

        /* JADX INFO: Added by JADX */
        public static final int clearTop = 0x7f0300e0;

        /* JADX INFO: Added by JADX */
        public static final int clearsTag = 0x7f0300e1;

        /* JADX INFO: Added by JADX */
        public static final int clickAction = 0x7f0300e2;

        /* JADX INFO: Added by JADX */
        public static final int clockFaceBackgroundColor = 0x7f0300e3;

        /* JADX INFO: Added by JADX */
        public static final int clockHandColor = 0x7f0300e4;

        /* JADX INFO: Added by JADX */
        public static final int clockIcon = 0x7f0300e5;

        /* JADX INFO: Added by JADX */
        public static final int clockNumberTextColor = 0x7f0300e6;

        /* JADX INFO: Added by JADX */
        public static final int closeIcon = 0x7f0300e7;

        /* JADX INFO: Added by JADX */
        public static final int closeIconEnabled = 0x7f0300e8;

        /* JADX INFO: Added by JADX */
        public static final int closeIconEndPadding = 0x7f0300e9;

        /* JADX INFO: Added by JADX */
        public static final int closeIconSize = 0x7f0300ea;

        /* JADX INFO: Added by JADX */
        public static final int closeIconStartPadding = 0x7f0300eb;

        /* JADX INFO: Added by JADX */
        public static final int closeIconTint = 0x7f0300ec;

        /* JADX INFO: Added by JADX */
        public static final int closeIconVisible = 0x7f0300ed;

        /* JADX INFO: Added by JADX */
        public static final int closeItemLayout = 0x7f0300ee;

        /* JADX INFO: Added by JADX */
        public static final int collapseContentDescription = 0x7f0300ef;

        /* JADX INFO: Added by JADX */
        public static final int collapseIcon = 0x7f0300f0;

        /* JADX INFO: Added by JADX */
        public static final int collapsedSize = 0x7f0300f1;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleGravity = 0x7f0300f2;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleTextAppearance = 0x7f0300f3;

        /* JADX INFO: Added by JADX */
        public static final int collapsedTitleTextColor = 0x7f0300f4;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutLargeSize = 0x7f0300f5;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutLargeStyle = 0x7f0300f6;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutMediumSize = 0x7f0300f7;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutMediumStyle = 0x7f0300f8;

        /* JADX INFO: Added by JADX */
        public static final int collapsingToolbarLayoutStyle = 0x7f0300f9;

        /* JADX INFO: Added by JADX */
        public static final int color = 0x7f0300fa;

        /* JADX INFO: Added by JADX */
        public static final int colorAccent = 0x7f0300fb;

        /* JADX INFO: Added by JADX */
        public static final int colorBackgroundFloating = 0x7f0300fc;

        /* JADX INFO: Added by JADX */
        public static final int colorButtonNormal = 0x7f0300fd;

        /* JADX INFO: Added by JADX */
        public static final int colorContainer = 0x7f0300fe;

        /* JADX INFO: Added by JADX */
        public static final int colorControlActivated = 0x7f0300ff;

        /* JADX INFO: Added by JADX */
        public static final int colorControlHighlight = 0x7f030100;

        /* JADX INFO: Added by JADX */
        public static final int colorControlNormal = 0x7f030101;

        /* JADX INFO: Added by JADX */
        public static final int colorError = 0x7f030102;

        /* JADX INFO: Added by JADX */
        public static final int colorErrorContainer = 0x7f030103;

        /* JADX INFO: Added by JADX */
        public static final int colorOnBackground = 0x7f030104;

        /* JADX INFO: Added by JADX */
        public static final int colorOnContainer = 0x7f030105;

        /* JADX INFO: Added by JADX */
        public static final int colorOnContainerUnchecked = 0x7f030106;

        /* JADX INFO: Added by JADX */
        public static final int colorOnError = 0x7f030107;

        /* JADX INFO: Added by JADX */
        public static final int colorOnErrorContainer = 0x7f030108;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimary = 0x7f030109;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryContainer = 0x7f03010a;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryFixed = 0x7f03010b;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimaryFixedVariant = 0x7f03010c;

        /* JADX INFO: Added by JADX */
        public static final int colorOnPrimarySurface = 0x7f03010d;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondary = 0x7f03010e;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryContainer = 0x7f03010f;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryFixed = 0x7f030110;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSecondaryFixedVariant = 0x7f030111;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurface = 0x7f030112;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurfaceInverse = 0x7f030113;

        /* JADX INFO: Added by JADX */
        public static final int colorOnSurfaceVariant = 0x7f030114;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiary = 0x7f030115;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryContainer = 0x7f030116;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryFixed = 0x7f030117;

        /* JADX INFO: Added by JADX */
        public static final int colorOnTertiaryFixedVariant = 0x7f030118;

        /* JADX INFO: Added by JADX */
        public static final int colorOutline = 0x7f030119;

        /* JADX INFO: Added by JADX */
        public static final int colorOutlineVariant = 0x7f03011a;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimary = 0x7f03011b;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryContainer = 0x7f03011c;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryDark = 0x7f03011d;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryFixed = 0x7f03011e;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryFixedDim = 0x7f03011f;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryInverse = 0x7f030120;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimarySurface = 0x7f030121;

        /* JADX INFO: Added by JADX */
        public static final int colorPrimaryVariant = 0x7f030122;

        /* JADX INFO: Added by JADX */
        public static final int colorScheme = 0x7f030123;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondary = 0x7f030124;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryContainer = 0x7f030125;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryFixed = 0x7f030126;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryFixedDim = 0x7f030127;

        /* JADX INFO: Added by JADX */
        public static final int colorSecondaryVariant = 0x7f030128;

        /* JADX INFO: Added by JADX */
        public static final int colorSurface = 0x7f030129;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceBright = 0x7f03012a;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainer = 0x7f03012b;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerHigh = 0x7f03012c;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerHighest = 0x7f03012d;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerLow = 0x7f03012e;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceContainerLowest = 0x7f03012f;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceDim = 0x7f030130;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceInverse = 0x7f030131;

        /* JADX INFO: Added by JADX */
        public static final int colorSurfaceVariant = 0x7f030132;

        /* JADX INFO: Added by JADX */
        public static final int colorSwitchThumbNormal = 0x7f030133;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiary = 0x7f030134;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryContainer = 0x7f030135;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryFixed = 0x7f030136;

        /* JADX INFO: Added by JADX */
        public static final int colorTertiaryFixedDim = 0x7f030137;

        /* JADX INFO: Added by JADX */
        public static final int commitIcon = 0x7f030138;

        /* JADX INFO: Added by JADX */
        public static final int compatShadowEnabled = 0x7f030139;

        /* JADX INFO: Added by JADX */
        public static final int constraintRotate = 0x7f03013a;

        /* JADX INFO: Added by JADX */
        public static final int constraintSet = 0x7f03013b;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetEnd = 0x7f03013c;

        /* JADX INFO: Added by JADX */
        public static final int constraintSetStart = 0x7f03013d;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_ids = 0x7f03013e;

        /* JADX INFO: Added by JADX */
        public static final int constraint_referenced_tags = 0x7f03013f;

        /* JADX INFO: Added by JADX */
        public static final int constraints = 0x7f030140;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f030141;

        /* JADX INFO: Added by JADX */
        public static final int contentDescription = 0x7f030142;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEnd = 0x7f030143;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetEndWithActions = 0x7f030144;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetLeft = 0x7f030145;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetRight = 0x7f030146;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStart = 0x7f030147;

        /* JADX INFO: Added by JADX */
        public static final int contentInsetStartWithNavigation = 0x7f030148;

        /* JADX INFO: Added by JADX */
        public static final int contentPadding = 0x7f030149;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingBottom = 0x7f03014a;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingEnd = 0x7f03014b;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingLeft = 0x7f03014c;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingRight = 0x7f03014d;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingStart = 0x7f03014e;

        /* JADX INFO: Added by JADX */
        public static final int contentPaddingTop = 0x7f03014f;

        /* JADX INFO: Added by JADX */
        public static final int contentScrim = 0x7f030150;

        /* JADX INFO: Added by JADX */
        public static final int contrast = 0x7f030151;

        /* JADX INFO: Added by JADX */
        public static final int controlBackground = 0x7f030152;

        /* JADX INFO: Added by JADX */
        public static final int coordinatorLayoutStyle = 0x7f030153;

        /* JADX INFO: Added by JADX */
        public static final int coplanarSiblingViewId = 0x7f030154;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamily = 0x7f030155;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyBottomLeft = 0x7f030156;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyBottomRight = 0x7f030157;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyTopLeft = 0x7f030158;

        /* JADX INFO: Added by JADX */
        public static final int cornerFamilyTopRight = 0x7f030159;

        /* JADX INFO: Added by JADX */
        public static final int cornerRadius = 0x7f03015a;

        /* JADX INFO: Added by JADX */
        public static final int cornerSize = 0x7f03015b;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeBottomLeft = 0x7f03015c;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeBottomRight = 0x7f03015d;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeTopLeft = 0x7f03015e;

        /* JADX INFO: Added by JADX */
        public static final int cornerSizeTopRight = 0x7f03015f;

        /* JADX INFO: Added by JADX */
        public static final int counterEnabled = 0x7f030160;

        /* JADX INFO: Added by JADX */
        public static final int counterMaxLength = 0x7f030161;

        /* JADX INFO: Added by JADX */
        public static final int counterOverflowTextAppearance = 0x7f030162;

        /* JADX INFO: Added by JADX */
        public static final int counterOverflowTextColor = 0x7f030163;

        /* JADX INFO: Added by JADX */
        public static final int counterTextAppearance = 0x7f030164;

        /* JADX INFO: Added by JADX */
        public static final int counterTextColor = 0x7f030165;

        /* JADX INFO: Added by JADX */
        public static final int crossfade = 0x7f030166;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f030167;

        /* JADX INFO: Added by JADX */
        public static final int cursorColor = 0x7f030168;

        /* JADX INFO: Added by JADX */
        public static final int cursorErrorColor = 0x7f030169;

        /* JADX INFO: Added by JADX */
        public static final int curveFit = 0x7f03016a;

        /* JADX INFO: Added by JADX */
        public static final int customBoolean = 0x7f03016b;

        /* JADX INFO: Added by JADX */
        public static final int customColorDrawableValue = 0x7f03016c;

        /* JADX INFO: Added by JADX */
        public static final int customColorValue = 0x7f03016d;

        /* JADX INFO: Added by JADX */
        public static final int customDimension = 0x7f03016e;

        /* JADX INFO: Added by JADX */
        public static final int customFloatValue = 0x7f03016f;

        /* JADX INFO: Added by JADX */
        public static final int customIntegerValue = 0x7f030170;

        /* JADX INFO: Added by JADX */
        public static final int customNavigationLayout = 0x7f030171;

        /* JADX INFO: Added by JADX */
        public static final int customPixelDimension = 0x7f030172;

        /* JADX INFO: Added by JADX */
        public static final int customReference = 0x7f030173;

        /* JADX INFO: Added by JADX */
        public static final int customStringValue = 0x7f030174;

        /* JADX INFO: Added by JADX */
        public static final int data = 0x7f030175;

        /* JADX INFO: Added by JADX */
        public static final int dataPattern = 0x7f030176;

        /* JADX INFO: Added by JADX */
        public static final int dayInvalidStyle = 0x7f030177;

        /* JADX INFO: Added by JADX */
        public static final int daySelectedStyle = 0x7f030178;

        /* JADX INFO: Added by JADX */
        public static final int dayStyle = 0x7f030179;

        /* JADX INFO: Added by JADX */
        public static final int dayTodayStyle = 0x7f03017a;

        /* JADX INFO: Added by JADX */
        public static final int defaultDuration = 0x7f03017b;

        /* JADX INFO: Added by JADX */
        public static final int defaultMarginsEnabled = 0x7f03017c;

        /* JADX INFO: Added by JADX */
        public static final int defaultNavHost = 0x7f03017d;

        /* JADX INFO: Added by JADX */
        public static final int defaultQueryHint = 0x7f03017e;

        /* JADX INFO: Added by JADX */
        public static final int defaultScrollFlagsEnabled = 0x7f03017f;

        /* JADX INFO: Added by JADX */
        public static final int defaultState = 0x7f030180;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarAngle = 0x7f030181;

        /* JADX INFO: Added by JADX */
        public static final int deltaPolarRadius = 0x7f030182;

        /* JADX INFO: Added by JADX */
        public static final int deriveConstraintsFrom = 0x7f030183;

        /* JADX INFO: Added by JADX */
        public static final int destination = 0x7f030184;

        /* JADX INFO: Added by JADX */
        public static final int dialogCornerRadius = 0x7f030185;

        /* JADX INFO: Added by JADX */
        public static final int dialogPreferredPadding = 0x7f030186;

        /* JADX INFO: Added by JADX */
        public static final int dialogTheme = 0x7f030187;

        /* JADX INFO: Added by JADX */
        public static final int displayOptions = 0x7f030188;

        /* JADX INFO: Added by JADX */
        public static final int divider = 0x7f030189;

        /* JADX INFO: Added by JADX */
        public static final int dividerColor = 0x7f03018a;

        /* JADX INFO: Added by JADX */
        public static final int dividerHorizontal = 0x7f03018b;

        /* JADX INFO: Added by JADX */
        public static final int dividerInsetEnd = 0x7f03018c;

        /* JADX INFO: Added by JADX */
        public static final int dividerInsetStart = 0x7f03018d;

        /* JADX INFO: Added by JADX */
        public static final int dividerPadding = 0x7f03018e;

        /* JADX INFO: Added by JADX */
        public static final int dividerThickness = 0x7f03018f;

        /* JADX INFO: Added by JADX */
        public static final int dividerVertical = 0x7f030190;

        /* JADX INFO: Added by JADX */
        public static final int dragDirection = 0x7f030191;

        /* JADX INFO: Added by JADX */
        public static final int dragScale = 0x7f030192;

        /* JADX INFO: Added by JADX */
        public static final int dragThreshold = 0x7f030193;

        /* JADX INFO: Added by JADX */
        public static final int drawPath = 0x7f030194;

        /* JADX INFO: Added by JADX */
        public static final int drawableBottomCompat = 0x7f030195;

        /* JADX INFO: Added by JADX */
        public static final int drawableEndCompat = 0x7f030196;

        /* JADX INFO: Added by JADX */
        public static final int drawableLeftCompat = 0x7f030197;

        /* JADX INFO: Added by JADX */
        public static final int drawableRightCompat = 0x7f030198;

        /* JADX INFO: Added by JADX */
        public static final int drawableSize = 0x7f030199;

        /* JADX INFO: Added by JADX */
        public static final int drawableStartCompat = 0x7f03019a;

        /* JADX INFO: Added by JADX */
        public static final int drawableTint = 0x7f03019b;

        /* JADX INFO: Added by JADX */
        public static final int drawableTintMode = 0x7f03019c;

        /* JADX INFO: Added by JADX */
        public static final int drawableTopCompat = 0x7f03019d;

        /* JADX INFO: Added by JADX */
        public static final int drawerArrowStyle = 0x7f03019e;

        /* JADX INFO: Added by JADX */
        public static final int drawerLayoutCornerSize = 0x7f03019f;

        /* JADX INFO: Added by JADX */
        public static final int drawerLayoutStyle = 0x7f0301a0;

        /* JADX INFO: Added by JADX */
        public static final int dropDownBackgroundTint = 0x7f0301a1;

        /* JADX INFO: Added by JADX */
        public static final int dropDownListViewStyle = 0x7f0301a2;

        /* JADX INFO: Added by JADX */
        public static final int dropdownListPreferredItemHeight = 0x7f0301a3;

        /* JADX INFO: Added by JADX */
        public static final int duration = 0x7f0301a4;

        /* JADX INFO: Added by JADX */
        public static final int dynamicColorThemeOverlay = 0x7f0301a5;

        /* JADX INFO: Added by JADX */
        public static final int editTextBackground = 0x7f0301a6;

        /* JADX INFO: Added by JADX */
        public static final int editTextColor = 0x7f0301a7;

        /* JADX INFO: Added by JADX */
        public static final int editTextStyle = 0x7f0301a8;

        /* JADX INFO: Added by JADX */
        public static final int elevation = 0x7f0301a9;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayAccentColor = 0x7f0301aa;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayColor = 0x7f0301ab;

        /* JADX INFO: Added by JADX */
        public static final int elevationOverlayEnabled = 0x7f0301ac;

        /* JADX INFO: Added by JADX */
        public static final int emojiCompatEnabled = 0x7f0301ad;

        /* JADX INFO: Added by JADX */
        public static final int enableEdgeToEdge = 0x7f0301ae;

        /* JADX INFO: Added by JADX */
        public static final int endIconCheckable = 0x7f0301af;

        /* JADX INFO: Added by JADX */
        public static final int endIconContentDescription = 0x7f0301b0;

        /* JADX INFO: Added by JADX */
        public static final int endIconDrawable = 0x7f0301b1;

        /* JADX INFO: Added by JADX */
        public static final int endIconMinSize = 0x7f0301b2;

        /* JADX INFO: Added by JADX */
        public static final int endIconMode = 0x7f0301b3;

        /* JADX INFO: Added by JADX */
        public static final int endIconScaleType = 0x7f0301b4;

        /* JADX INFO: Added by JADX */
        public static final int endIconTint = 0x7f0301b5;

        /* JADX INFO: Added by JADX */
        public static final int endIconTintMode = 0x7f0301b6;

        /* JADX INFO: Added by JADX */
        public static final int enforceMaterialTheme = 0x7f0301b7;

        /* JADX INFO: Added by JADX */
        public static final int enforceTextAppearance = 0x7f0301b8;

        /* JADX INFO: Added by JADX */
        public static final int ensureMinTouchTargetSize = 0x7f0301b9;

        /* JADX INFO: Added by JADX */
        public static final int enterAnim = 0x7f0301ba;

        /* JADX INFO: Added by JADX */
        public static final int errorAccessibilityLabel = 0x7f0301bb;

        /* JADX INFO: Added by JADX */
        public static final int errorAccessibilityLiveRegion = 0x7f0301bc;

        /* JADX INFO: Added by JADX */
        public static final int errorContentDescription = 0x7f0301bd;

        /* JADX INFO: Added by JADX */
        public static final int errorEnabled = 0x7f0301be;

        /* JADX INFO: Added by JADX */
        public static final int errorIconDrawable = 0x7f0301bf;

        /* JADX INFO: Added by JADX */
        public static final int errorIconTint = 0x7f0301c0;

        /* JADX INFO: Added by JADX */
        public static final int errorIconTintMode = 0x7f0301c1;

        /* JADX INFO: Added by JADX */
        public static final int errorShown = 0x7f0301c2;

        /* JADX INFO: Added by JADX */
        public static final int errorTextAppearance = 0x7f0301c3;

        /* JADX INFO: Added by JADX */
        public static final int errorTextColor = 0x7f0301c4;

        /* JADX INFO: Added by JADX */
        public static final int exitAnim = 0x7f0301c5;

        /* JADX INFO: Added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 0x7f0301c6;

        /* JADX INFO: Added by JADX */
        public static final int expanded = 0x7f0301c7;

        /* JADX INFO: Added by JADX */
        public static final int expandedHintEnabled = 0x7f0301c8;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleGravity = 0x7f0301c9;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMargin = 0x7f0301ca;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginBottom = 0x7f0301cb;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginEnd = 0x7f0301cc;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginStart = 0x7f0301cd;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleMarginTop = 0x7f0301ce;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleTextAppearance = 0x7f0301cf;

        /* JADX INFO: Added by JADX */
        public static final int expandedTitleTextColor = 0x7f0301d0;

        /* JADX INFO: Added by JADX */
        public static final int extendMotionSpec = 0x7f0301d1;

        /* JADX INFO: Added by JADX */
        public static final int extendStrategy = 0x7f0301d2;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonPrimaryStyle = 0x7f0301d3;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonSecondaryStyle = 0x7f0301d4;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonStyle = 0x7f0301d5;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonSurfaceStyle = 0x7f0301d6;

        /* JADX INFO: Added by JADX */
        public static final int extendedFloatingActionButtonTertiaryStyle = 0x7f0301d7;

        /* JADX INFO: Added by JADX */
        public static final int extraMultilineHeightEnabled = 0x7f0301d8;

        /* JADX INFO: Added by JADX */
        public static final int fabAlignmentMode = 0x7f0301d9;

        /* JADX INFO: Added by JADX */
        public static final int fabAlignmentModeEndMargin = 0x7f0301da;

        /* JADX INFO: Added by JADX */
        public static final int fabAnchorMode = 0x7f0301db;

        /* JADX INFO: Added by JADX */
        public static final int fabAnimationMode = 0x7f0301dc;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleMargin = 0x7f0301dd;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleRoundedCornerRadius = 0x7f0301de;

        /* JADX INFO: Added by JADX */
        public static final int fabCradleVerticalOffset = 0x7f0301df;

        /* JADX INFO: Added by JADX */
        public static final int fabCustomSize = 0x7f0301e0;

        /* JADX INFO: Added by JADX */
        public static final int fabSize = 0x7f0301e1;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollEnabled = 0x7f0301e2;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalThumbDrawable = 0x7f0301e3;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalTrackDrawable = 0x7f0301e4;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalThumbDrawable = 0x7f0301e5;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalTrackDrawable = 0x7f0301e6;

        /* JADX INFO: Added by JADX */
        public static final int finishPrimaryWithSecondary = 0x7f0301e7;

        /* JADX INFO: Added by JADX */
        public static final int finishSecondaryWithPrimary = 0x7f0301e8;

        /* JADX INFO: Added by JADX */
        public static final int firstBaselineToTopHeight = 0x7f0301e9;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargePrimaryStyle = 0x7f0301ea;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeSecondaryStyle = 0x7f0301eb;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeStyle = 0x7f0301ec;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeSurfaceStyle = 0x7f0301ed;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonLargeTertiaryStyle = 0x7f0301ee;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonPrimaryStyle = 0x7f0301ef;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSecondaryStyle = 0x7f0301f0;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallPrimaryStyle = 0x7f0301f1;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallSecondaryStyle = 0x7f0301f2;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallStyle = 0x7f0301f3;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallSurfaceStyle = 0x7f0301f4;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSmallTertiaryStyle = 0x7f0301f5;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonStyle = 0x7f0301f6;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonSurfaceStyle = 0x7f0301f7;

        /* JADX INFO: Added by JADX */
        public static final int floatingActionButtonTertiaryStyle = 0x7f0301f8;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalBias = 0x7f0301f9;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstHorizontalStyle = 0x7f0301fa;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalBias = 0x7f0301fb;

        /* JADX INFO: Added by JADX */
        public static final int flow_firstVerticalStyle = 0x7f0301fc;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalAlign = 0x7f0301fd;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalBias = 0x7f0301fe;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalGap = 0x7f0301ff;

        /* JADX INFO: Added by JADX */
        public static final int flow_horizontalStyle = 0x7f030200;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalBias = 0x7f030201;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastHorizontalStyle = 0x7f030202;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalBias = 0x7f030203;

        /* JADX INFO: Added by JADX */
        public static final int flow_lastVerticalStyle = 0x7f030204;

        /* JADX INFO: Added by JADX */
        public static final int flow_maxElementsWrap = 0x7f030205;

        /* JADX INFO: Added by JADX */
        public static final int flow_padding = 0x7f030206;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalAlign = 0x7f030207;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalBias = 0x7f030208;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalGap = 0x7f030209;

        /* JADX INFO: Added by JADX */
        public static final int flow_verticalStyle = 0x7f03020a;

        /* JADX INFO: Added by JADX */
        public static final int flow_wrapMode = 0x7f03020b;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f03020c;

        /* JADX INFO: Added by JADX */
        public static final int fontFamily = 0x7f03020d;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f03020e;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f03020f;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f030210;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f030211;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f030212;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f030213;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f030214;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f030215;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f030216;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f030217;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f030218;

        /* JADX INFO: Added by JADX */
        public static final int forceApplySystemWindowInsetTop = 0x7f030219;

        /* JADX INFO: Added by JADX */
        public static final int forceDefaultNavigationOnClickListener = 0x7f03021a;

        /* JADX INFO: Added by JADX */
        public static final int foregroundInsidePadding = 0x7f03021b;

        /* JADX INFO: Added by JADX */
        public static final int framePosition = 0x7f03021c;

        /* JADX INFO: Added by JADX */
        public static final int gapBetweenBars = 0x7f03021d;

        /* JADX INFO: Added by JADX */
        public static final int gestureInsetBottomIgnored = 0x7f03021e;

        /* JADX INFO: Added by JADX */
        public static final int goIcon = 0x7f03021f;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f030220;

        /* JADX INFO: Added by JADX */
        public static final int grid_columnWeights = 0x7f030221;

        /* JADX INFO: Added by JADX */
        public static final int grid_columns = 0x7f030222;

        /* JADX INFO: Added by JADX */
        public static final int grid_horizontalGaps = 0x7f030223;

        /* JADX INFO: Added by JADX */
        public static final int grid_orientation = 0x7f030224;

        /* JADX INFO: Added by JADX */
        public static final int grid_rowWeights = 0x7f030225;

        /* JADX INFO: Added by JADX */
        public static final int grid_rows = 0x7f030226;

        /* JADX INFO: Added by JADX */
        public static final int grid_skips = 0x7f030227;

        /* JADX INFO: Added by JADX */
        public static final int grid_spans = 0x7f030228;

        /* JADX INFO: Added by JADX */
        public static final int grid_useRtl = 0x7f030229;

        /* JADX INFO: Added by JADX */
        public static final int grid_validateInputs = 0x7f03022a;

        /* JADX INFO: Added by JADX */
        public static final int grid_verticalGaps = 0x7f03022b;

        /* JADX INFO: Added by JADX */
        public static final int guidelineUseRtl = 0x7f03022c;

        /* JADX INFO: Added by JADX */
        public static final int haloColor = 0x7f03022d;

        /* JADX INFO: Added by JADX */
        public static final int haloRadius = 0x7f03022e;

        /* JADX INFO: Added by JADX */
        public static final int headerLayout = 0x7f03022f;

        /* JADX INFO: Added by JADX */
        public static final int height = 0x7f030230;

        /* JADX INFO: Added by JADX */
        public static final int helperText = 0x7f030231;

        /* JADX INFO: Added by JADX */
        public static final int helperTextEnabled = 0x7f030232;

        /* JADX INFO: Added by JADX */
        public static final int helperTextTextAppearance = 0x7f030233;

        /* JADX INFO: Added by JADX */
        public static final int helperTextTextColor = 0x7f030234;

        /* JADX INFO: Added by JADX */
        public static final int hideAnimationBehavior = 0x7f030235;

        /* JADX INFO: Added by JADX */
        public static final int hideMotionSpec = 0x7f030236;

        /* JADX INFO: Added by JADX */
        public static final int hideNavigationIcon = 0x7f030237;

        /* JADX INFO: Added by JADX */
        public static final int hideOnContentScroll = 0x7f030238;

        /* JADX INFO: Added by JADX */
        public static final int hideOnScroll = 0x7f030239;

        /* JADX INFO: Added by JADX */
        public static final int hintAnimationEnabled = 0x7f03023a;

        /* JADX INFO: Added by JADX */
        public static final int hintEnabled = 0x7f03023b;

        /* JADX INFO: Added by JADX */
        public static final int hintTextAppearance = 0x7f03023c;

        /* JADX INFO: Added by JADX */
        public static final int hintTextColor = 0x7f03023d;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUpIndicator = 0x7f03023e;

        /* JADX INFO: Added by JADX */
        public static final int homeLayout = 0x7f03023f;

        /* JADX INFO: Added by JADX */
        public static final int horizontalOffset = 0x7f030240;

        /* JADX INFO: Added by JADX */
        public static final int horizontalOffsetWithText = 0x7f030241;

        /* JADX INFO: Added by JADX */
        public static final int hoveredFocusedTranslationZ = 0x7f030242;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f030243;

        /* JADX INFO: Added by JADX */
        public static final int iconEndPadding = 0x7f030244;

        /* JADX INFO: Added by JADX */
        public static final int iconGravity = 0x7f030245;

        /* JADX INFO: Added by JADX */
        public static final int iconPadding = 0x7f030246;

        /* JADX INFO: Added by JADX */
        public static final int iconSize = 0x7f030247;

        /* JADX INFO: Added by JADX */
        public static final int iconStartPadding = 0x7f030248;

        /* JADX INFO: Added by JADX */
        public static final int iconTint = 0x7f030249;

        /* JADX INFO: Added by JADX */
        public static final int iconTintMode = 0x7f03024a;

        /* JADX INFO: Added by JADX */
        public static final int iconifiedByDefault = 0x7f03024b;

        /* JADX INFO: Added by JADX */
        public static final int ifTagNotSet = 0x7f03024c;

        /* JADX INFO: Added by JADX */
        public static final int ifTagSet = 0x7f03024d;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatio = 0x7f03024e;

        /* JADX INFO: Added by JADX */
        public static final int imageAspectRatioAdjust = 0x7f03024f;

        /* JADX INFO: Added by JADX */
        public static final int imageButtonStyle = 0x7f030250;

        /* JADX INFO: Added by JADX */
        public static final int imagePanX = 0x7f030251;

        /* JADX INFO: Added by JADX */
        public static final int imagePanY = 0x7f030252;

        /* JADX INFO: Added by JADX */
        public static final int imageRotate = 0x7f030253;

        /* JADX INFO: Added by JADX */
        public static final int imageZoom = 0x7f030254;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateAnimationType = 0x7f030255;

        /* JADX INFO: Added by JADX */
        public static final int indeterminateProgressStyle = 0x7f030256;

        /* JADX INFO: Added by JADX */
        public static final int indicatorColor = 0x7f030257;

        /* JADX INFO: Added by JADX */
        public static final int indicatorDirectionCircular = 0x7f030258;

        /* JADX INFO: Added by JADX */
        public static final int indicatorDirectionLinear = 0x7f030259;

        /* JADX INFO: Added by JADX */
        public static final int indicatorInset = 0x7f03025a;

        /* JADX INFO: Added by JADX */
        public static final int indicatorSize = 0x7f03025b;

        /* JADX INFO: Added by JADX */
        public static final int indicatorTrackGapSize = 0x7f03025c;

        /* JADX INFO: Added by JADX */
        public static final int initialActivityCount = 0x7f03025d;

        /* JADX INFO: Added by JADX */
        public static final int insetForeground = 0x7f03025e;

        /* JADX INFO: Added by JADX */
        public static final int isLightTheme = 0x7f03025f;

        /* JADX INFO: Added by JADX */
        public static final int isMaterial3DynamicColorApplied = 0x7f030260;

        /* JADX INFO: Added by JADX */
        public static final int isMaterial3Theme = 0x7f030261;

        /* JADX INFO: Added by JADX */
        public static final int isMaterialTheme = 0x7f030262;

        /* JADX INFO: Added by JADX */
        public static final int itemActiveIndicatorStyle = 0x7f030263;

        /* JADX INFO: Added by JADX */
        public static final int itemBackground = 0x7f030264;

        /* JADX INFO: Added by JADX */
        public static final int itemFillColor = 0x7f030265;

        /* JADX INFO: Added by JADX */
        public static final int itemHorizontalPadding = 0x7f030266;

        /* JADX INFO: Added by JADX */
        public static final int itemHorizontalTranslationEnabled = 0x7f030267;

        /* JADX INFO: Added by JADX */
        public static final int itemIconPadding = 0x7f030268;

        /* JADX INFO: Added by JADX */
        public static final int itemIconSize = 0x7f030269;

        /* JADX INFO: Added by JADX */
        public static final int itemIconTint = 0x7f03026a;

        /* JADX INFO: Added by JADX */
        public static final int itemMaxLines = 0x7f03026b;

        /* JADX INFO: Added by JADX */
        public static final int itemMinHeight = 0x7f03026c;

        /* JADX INFO: Added by JADX */
        public static final int itemPadding = 0x7f03026d;

        /* JADX INFO: Added by JADX */
        public static final int itemPaddingBottom = 0x7f03026e;

        /* JADX INFO: Added by JADX */
        public static final int itemPaddingTop = 0x7f03026f;

        /* JADX INFO: Added by JADX */
        public static final int itemRippleColor = 0x7f030270;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeAppearance = 0x7f030271;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeAppearanceOverlay = 0x7f030272;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeFillColor = 0x7f030273;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetBottom = 0x7f030274;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetEnd = 0x7f030275;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetStart = 0x7f030276;

        /* JADX INFO: Added by JADX */
        public static final int itemShapeInsetTop = 0x7f030277;

        /* JADX INFO: Added by JADX */
        public static final int itemSpacing = 0x7f030278;

        /* JADX INFO: Added by JADX */
        public static final int itemStrokeColor = 0x7f030279;

        /* JADX INFO: Added by JADX */
        public static final int itemStrokeWidth = 0x7f03027a;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearance = 0x7f03027b;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceActive = 0x7f03027c;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceActiveBoldEnabled = 0x7f03027d;

        /* JADX INFO: Added by JADX */
        public static final int itemTextAppearanceInactive = 0x7f03027e;

        /* JADX INFO: Added by JADX */
        public static final int itemTextColor = 0x7f03027f;

        /* JADX INFO: Added by JADX */
        public static final int itemVerticalPadding = 0x7f030280;

        /* JADX INFO: Added by JADX */
        public static final int keyPositionType = 0x7f030281;

        /* JADX INFO: Added by JADX */
        public static final int keyboardIcon = 0x7f030282;

        /* JADX INFO: Added by JADX */
        public static final int keylines = 0x7f030283;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f030284;

        /* JADX INFO: Added by JADX */
        public static final int labelBehavior = 0x7f030285;

        /* JADX INFO: Added by JADX */
        public static final int labelStyle = 0x7f030286;

        /* JADX INFO: Added by JADX */
        public static final int labelVisibilityMode = 0x7f030287;

        /* JADX INFO: Added by JADX */
        public static final int largeFontVerticalOffsetAdjustment = 0x7f030288;

        /* JADX INFO: Added by JADX */
        public static final int lastBaselineToBottomHeight = 0x7f030289;

        /* JADX INFO: Added by JADX */
        public static final int lastItemDecorated = 0x7f03028a;

        /* JADX INFO: Added by JADX */
        public static final int launchSingleTop = 0x7f03028b;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f03028c;

        /* JADX INFO: Added by JADX */
        public static final int layoutDescription = 0x7f03028d;

        /* JADX INFO: Added by JADX */
        public static final int layoutDuringTransition = 0x7f03028e;

        /* JADX INFO: Added by JADX */
        public static final int layoutManager = 0x7f03028f;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchor = 0x7f030290;

        /* JADX INFO: Added by JADX */
        public static final int layout_anchorGravity = 0x7f030291;

        /* JADX INFO: Added by JADX */
        public static final int layout_behavior = 0x7f030292;

        /* JADX INFO: Added by JADX */
        public static final int layout_collapseMode = 0x7f030293;

        /* JADX INFO: Added by JADX */
        public static final int layout_collapseParallaxMultiplier = 0x7f030294;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedHeight = 0x7f030295;

        /* JADX INFO: Added by JADX */
        public static final int layout_constrainedWidth = 0x7f030296;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_creator = 0x7f030297;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBaselineOf = 0x7f030298;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toBottomOf = 0x7f030299;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBaseline_toTopOf = 0x7f03029a;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_creator = 0x7f03029b;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toBottomOf = 0x7f03029c;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintBottom_toTopOf = 0x7f03029d;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircle = 0x7f03029e;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleAngle = 0x7f03029f;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintCircleRadius = 0x7f0302a0;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintDimensionRatio = 0x7f0302a1;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toEndOf = 0x7f0302a2;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintEnd_toStartOf = 0x7f0302a3;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_begin = 0x7f0302a4;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_end = 0x7f0302a5;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintGuide_percent = 0x7f0302a6;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight = 0x7f0302a7;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_default = 0x7f0302a8;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_max = 0x7f0302a9;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_min = 0x7f0302aa;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHeight_percent = 0x7f0302ab;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_bias = 0x7f0302ac;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_chainStyle = 0x7f0302ad;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintHorizontal_weight = 0x7f0302ae;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_creator = 0x7f0302af;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toLeftOf = 0x7f0302b0;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintLeft_toRightOf = 0x7f0302b1;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_creator = 0x7f0302b2;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toLeftOf = 0x7f0302b3;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintRight_toRightOf = 0x7f0302b4;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toEndOf = 0x7f0302b5;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintStart_toStartOf = 0x7f0302b6;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTag = 0x7f0302b7;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_creator = 0x7f0302b8;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toBottomOf = 0x7f0302b9;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintTop_toTopOf = 0x7f0302ba;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_bias = 0x7f0302bb;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_chainStyle = 0x7f0302bc;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintVertical_weight = 0x7f0302bd;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth = 0x7f0302be;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_default = 0x7f0302bf;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_max = 0x7f0302c0;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_min = 0x7f0302c1;

        /* JADX INFO: Added by JADX */
        public static final int layout_constraintWidth_percent = 0x7f0302c2;

        /* JADX INFO: Added by JADX */
        public static final int layout_dodgeInsetEdges = 0x7f0302c3;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteX = 0x7f0302c4;

        /* JADX INFO: Added by JADX */
        public static final int layout_editor_absoluteY = 0x7f0302c5;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBaseline = 0x7f0302c6;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginBottom = 0x7f0302c7;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginEnd = 0x7f0302c8;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginLeft = 0x7f0302c9;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginRight = 0x7f0302ca;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginStart = 0x7f0302cb;

        /* JADX INFO: Added by JADX */
        public static final int layout_goneMarginTop = 0x7f0302cc;

        /* JADX INFO: Added by JADX */
        public static final int layout_insetEdge = 0x7f0302cd;

        /* JADX INFO: Added by JADX */
        public static final int layout_keyline = 0x7f0302ce;

        /* JADX INFO: Added by JADX */
        public static final int layout_marginBaseline = 0x7f0302cf;

        /* JADX INFO: Added by JADX */
        public static final int layout_optimizationLevel = 0x7f0302d0;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollEffect = 0x7f0302d1;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollFlags = 0x7f0302d2;

        /* JADX INFO: Added by JADX */
        public static final int layout_scrollInterpolator = 0x7f0302d3;

        /* JADX INFO: Added by JADX */
        public static final int layout_wrapBehaviorInParent = 0x7f0302d4;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScroll = 0x7f0302d5;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScrollColor = 0x7f0302d6;

        /* JADX INFO: Added by JADX */
        public static final int liftOnScrollTargetViewId = 0x7f0302d7;

        /* JADX INFO: Added by JADX */
        public static final int limitBoundsTo = 0x7f0302d8;

        /* JADX INFO: Added by JADX */
        public static final int lineHeight = 0x7f0302d9;

        /* JADX INFO: Added by JADX */
        public static final int lineSpacing = 0x7f0302da;

        /* JADX INFO: Added by JADX */
        public static final int linearProgressIndicatorStyle = 0x7f0302db;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceBackgroundIndicator = 0x7f0302dc;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 0x7f0302dd;

        /* JADX INFO: Added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 0x7f0302de;

        /* JADX INFO: Added by JADX */
        public static final int listDividerAlertDialog = 0x7f0302df;

        /* JADX INFO: Added by JADX */
        public static final int listItemLayout = 0x7f0302e0;

        /* JADX INFO: Added by JADX */
        public static final int listLayout = 0x7f0302e1;

        /* JADX INFO: Added by JADX */
        public static final int listMenuViewStyle = 0x7f0302e2;

        /* JADX INFO: Added by JADX */
        public static final int listPopupWindowStyle = 0x7f0302e3;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeight = 0x7f0302e4;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightLarge = 0x7f0302e5;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemHeightSmall = 0x7f0302e6;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingEnd = 0x7f0302e7;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingLeft = 0x7f0302e8;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingRight = 0x7f0302e9;

        /* JADX INFO: Added by JADX */
        public static final int listPreferredItemPaddingStart = 0x7f0302ea;

        /* JADX INFO: Added by JADX */
        public static final int logo = 0x7f0302eb;

        /* JADX INFO: Added by JADX */
        public static final int logoAdjustViewBounds = 0x7f0302ec;

        /* JADX INFO: Added by JADX */
        public static final int logoDescription = 0x7f0302ed;

        /* JADX INFO: Added by JADX */
        public static final int logoScaleType = 0x7f0302ee;

        /* JADX INFO: Added by JADX */
        public static final int marginHorizontal = 0x7f0302ef;

        /* JADX INFO: Added by JADX */
        public static final int marginLeftSystemWindowInsets = 0x7f0302f0;

        /* JADX INFO: Added by JADX */
        public static final int marginRightSystemWindowInsets = 0x7f0302f1;

        /* JADX INFO: Added by JADX */
        public static final int marginTopSystemWindowInsets = 0x7f0302f2;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogBodyTextStyle = 0x7f0302f3;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogButtonSpacerVisibility = 0x7f0302f4;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTheme = 0x7f0302f5;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitleIconStyle = 0x7f0302f6;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitlePanelStyle = 0x7f0302f7;

        /* JADX INFO: Added by JADX */
        public static final int materialAlertDialogTitleTextStyle = 0x7f0302f8;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonOutlinedStyle = 0x7f0302f9;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonStyle = 0x7f0302fa;

        /* JADX INFO: Added by JADX */
        public static final int materialButtonToggleGroupStyle = 0x7f0302fb;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarDay = 0x7f0302fc;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarDayOfWeekLabel = 0x7f0302fd;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarFullscreenTheme = 0x7f0302fe;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderCancelButton = 0x7f0302ff;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderConfirmButton = 0x7f030300;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderDivider = 0x7f030301;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderLayout = 0x7f030302;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderSelection = 0x7f030303;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderTitle = 0x7f030304;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarHeaderToggleButton = 0x7f030305;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarMonth = 0x7f030306;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarMonthNavigationButton = 0x7f030307;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarStyle = 0x7f030308;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarTheme = 0x7f030309;

        /* JADX INFO: Added by JADX */
        public static final int materialCalendarYearNavigationButton = 0x7f03030a;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewElevatedStyle = 0x7f03030b;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewFilledStyle = 0x7f03030c;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewOutlinedStyle = 0x7f03030d;

        /* JADX INFO: Added by JADX */
        public static final int materialCardViewStyle = 0x7f03030e;

        /* JADX INFO: Added by JADX */
        public static final int materialCircleRadius = 0x7f03030f;

        /* JADX INFO: Added by JADX */
        public static final int materialClockStyle = 0x7f030310;

        /* JADX INFO: Added by JADX */
        public static final int materialDisplayDividerStyle = 0x7f030311;

        /* JADX INFO: Added by JADX */
        public static final int materialDividerHeavyStyle = 0x7f030312;

        /* JADX INFO: Added by JADX */
        public static final int materialDividerStyle = 0x7f030313;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonFilledStyle = 0x7f030314;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonFilledTonalStyle = 0x7f030315;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonOutlinedStyle = 0x7f030316;

        /* JADX INFO: Added by JADX */
        public static final int materialIconButtonStyle = 0x7f030317;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchBarStyle = 0x7f030318;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewPrefixStyle = 0x7f030319;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewStyle = 0x7f03031a;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewToolbarHeight = 0x7f03031b;

        /* JADX INFO: Added by JADX */
        public static final int materialSearchViewToolbarStyle = 0x7f03031c;

        /* JADX INFO: Added by JADX */
        public static final int materialSwitchStyle = 0x7f03031d;

        /* JADX INFO: Added by JADX */
        public static final int materialThemeOverlay = 0x7f03031e;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerStyle = 0x7f03031f;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerTheme = 0x7f030320;

        /* JADX INFO: Added by JADX */
        public static final int materialTimePickerTitleStyle = 0x7f030321;

        /* JADX INFO: Added by JADX */
        public static final int maxAcceleration = 0x7f030322;

        /* JADX INFO: Added by JADX */
        public static final int maxActionInlineWidth = 0x7f030323;

        /* JADX INFO: Added by JADX */
        public static final int maxButtonHeight = 0x7f030324;

        /* JADX INFO: Added by JADX */
        public static final int maxCharacterCount = 0x7f030325;

        /* JADX INFO: Added by JADX */
        public static final int maxHeight = 0x7f030326;

        /* JADX INFO: Added by JADX */
        public static final int maxImageSize = 0x7f030327;

        /* JADX INFO: Added by JADX */
        public static final int maxLines = 0x7f030328;

        /* JADX INFO: Added by JADX */
        public static final int maxNumber = 0x7f030329;

        /* JADX INFO: Added by JADX */
        public static final int maxVelocity = 0x7f03032a;

        /* JADX INFO: Added by JADX */
        public static final int maxWidth = 0x7f03032b;

        /* JADX INFO: Added by JADX */
        public static final int measureWithLargestChild = 0x7f03032c;

        /* JADX INFO: Added by JADX */
        public static final int menu = 0x7f03032d;

        /* JADX INFO: Added by JADX */
        public static final int menuAlignmentMode = 0x7f03032e;

        /* JADX INFO: Added by JADX */
        public static final int menuGravity = 0x7f03032f;

        /* JADX INFO: Added by JADX */
        public static final int methodName = 0x7f030330;

        /* JADX INFO: Added by JADX */
        public static final int mimeType = 0x7f030331;

        /* JADX INFO: Added by JADX */
        public static final int minHeight = 0x7f030332;

        /* JADX INFO: Added by JADX */
        public static final int minHideDelay = 0x7f030333;

        /* JADX INFO: Added by JADX */
        public static final int minSeparation = 0x7f030334;

        /* JADX INFO: Added by JADX */
        public static final int minTouchTargetSize = 0x7f030335;

        /* JADX INFO: Added by JADX */
        public static final int minWidth = 0x7f030336;

        /* JADX INFO: Added by JADX */
        public static final int mock_diagonalsColor = 0x7f030337;

        /* JADX INFO: Added by JADX */
        public static final int mock_label = 0x7f030338;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelBackgroundColor = 0x7f030339;

        /* JADX INFO: Added by JADX */
        public static final int mock_labelColor = 0x7f03033a;

        /* JADX INFO: Added by JADX */
        public static final int mock_showDiagonals = 0x7f03033b;

        /* JADX INFO: Added by JADX */
        public static final int mock_showLabel = 0x7f03033c;

        /* JADX INFO: Added by JADX */
        public static final int motionDebug = 0x7f03033d;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong1 = 0x7f03033e;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong2 = 0x7f03033f;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong3 = 0x7f030340;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationExtraLong4 = 0x7f030341;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong1 = 0x7f030342;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong2 = 0x7f030343;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong3 = 0x7f030344;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationLong4 = 0x7f030345;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium1 = 0x7f030346;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium2 = 0x7f030347;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium3 = 0x7f030348;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationMedium4 = 0x7f030349;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort1 = 0x7f03034a;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort2 = 0x7f03034b;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort3 = 0x7f03034c;

        /* JADX INFO: Added by JADX */
        public static final int motionDurationShort4 = 0x7f03034d;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingAccelerated = 0x7f03034e;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingDecelerated = 0x7f03034f;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasized = 0x7f030350;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedAccelerateInterpolator = 0x7f030351;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedDecelerateInterpolator = 0x7f030352;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingEmphasizedInterpolator = 0x7f030353;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingLinear = 0x7f030354;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingLinearInterpolator = 0x7f030355;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandard = 0x7f030356;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardAccelerateInterpolator = 0x7f030357;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardDecelerateInterpolator = 0x7f030358;

        /* JADX INFO: Added by JADX */
        public static final int motionEasingStandardInterpolator = 0x7f030359;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_alpha = 0x7f03035a;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_end = 0x7f03035b;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_move = 0x7f03035c;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_start = 0x7f03035d;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_strict = 0x7f03035e;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationX = 0x7f03035f;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_translationY = 0x7f030360;

        /* JADX INFO: Added by JADX */
        public static final int motionEffect_viewTransition = 0x7f030361;

        /* JADX INFO: Added by JADX */
        public static final int motionInterpolator = 0x7f030362;

        /* JADX INFO: Added by JADX */
        public static final int motionPath = 0x7f030363;

        /* JADX INFO: Added by JADX */
        public static final int motionPathRotate = 0x7f030364;

        /* JADX INFO: Added by JADX */
        public static final int motionProgress = 0x7f030365;

        /* JADX INFO: Added by JADX */
        public static final int motionStagger = 0x7f030366;

        /* JADX INFO: Added by JADX */
        public static final int motionTarget = 0x7f030367;

        /* JADX INFO: Added by JADX */
        public static final int motion_postLayoutCollision = 0x7f030368;

        /* JADX INFO: Added by JADX */
        public static final int motion_triggerOnCollision = 0x7f030369;

        /* JADX INFO: Added by JADX */
        public static final int moveWhenScrollAtTop = 0x7f03036a;

        /* JADX INFO: Added by JADX */
        public static final int multiChoiceItemLayout = 0x7f03036b;

        /* JADX INFO: Added by JADX */
        public static final int navGraph = 0x7f03036c;

        /* JADX INFO: Added by JADX */
        public static final int navigationContentDescription = 0x7f03036d;

        /* JADX INFO: Added by JADX */
        public static final int navigationIcon = 0x7f03036e;

        /* JADX INFO: Added by JADX */
        public static final int navigationIconTint = 0x7f03036f;

        /* JADX INFO: Added by JADX */
        public static final int navigationMode = 0x7f030370;

        /* JADX INFO: Added by JADX */
        public static final int navigationRailStyle = 0x7f030371;

        /* JADX INFO: Added by JADX */
        public static final int navigationViewStyle = 0x7f030372;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollFlags = 0x7f030373;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 0x7f030374;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollable = 0x7f030375;

        /* JADX INFO: Added by JADX */
        public static final int nullable = 0x7f030376;

        /* JADX INFO: Added by JADX */
        public static final int number = 0x7f030377;

        /* JADX INFO: Added by JADX */
        public static final int numericModifiers = 0x7f030378;

        /* JADX INFO: Added by JADX */
        public static final int offsetAlignmentMode = 0x7f030379;

        /* JADX INFO: Added by JADX */
        public static final int onCross = 0x7f03037a;

        /* JADX INFO: Added by JADX */
        public static final int onHide = 0x7f03037b;

        /* JADX INFO: Added by JADX */
        public static final int onNegativeCross = 0x7f03037c;

        /* JADX INFO: Added by JADX */
        public static final int onPositiveCross = 0x7f03037d;

        /* JADX INFO: Added by JADX */
        public static final int onShow = 0x7f03037e;

        /* JADX INFO: Added by JADX */
        public static final int onStateTransition = 0x7f03037f;

        /* JADX INFO: Added by JADX */
        public static final int onTouchUp = 0x7f030380;

        /* JADX INFO: Added by JADX */
        public static final int overlapAnchor = 0x7f030381;

        /* JADX INFO: Added by JADX */
        public static final int overlay = 0x7f030382;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomNoButtons = 0x7f030383;

        /* JADX INFO: Added by JADX */
        public static final int paddingBottomSystemWindowInsets = 0x7f030384;

        /* JADX INFO: Added by JADX */
        public static final int paddingEnd = 0x7f030385;

        /* JADX INFO: Added by JADX */
        public static final int paddingLeftSystemWindowInsets = 0x7f030386;

        /* JADX INFO: Added by JADX */
        public static final int paddingRightSystemWindowInsets = 0x7f030387;

        /* JADX INFO: Added by JADX */
        public static final int paddingStart = 0x7f030388;

        /* JADX INFO: Added by JADX */
        public static final int paddingStartSystemWindowInsets = 0x7f030389;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopNoTitle = 0x7f03038a;

        /* JADX INFO: Added by JADX */
        public static final int paddingTopSystemWindowInsets = 0x7f03038b;

        /* JADX INFO: Added by JADX */
        public static final int panelBackground = 0x7f03038c;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListTheme = 0x7f03038d;

        /* JADX INFO: Added by JADX */
        public static final int panelMenuListWidth = 0x7f03038e;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleContentDescription = 0x7f03038f;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleDrawable = 0x7f030390;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleEnabled = 0x7f030391;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleTint = 0x7f030392;

        /* JADX INFO: Added by JADX */
        public static final int passwordToggleTintMode = 0x7f030393;

        /* JADX INFO: Added by JADX */
        public static final int pathMotionArc = 0x7f030394;

        /* JADX INFO: Added by JADX */
        public static final int path_percent = 0x7f030395;

        /* JADX INFO: Added by JADX */
        public static final int percentHeight = 0x7f030396;

        /* JADX INFO: Added by JADX */
        public static final int percentWidth = 0x7f030397;

        /* JADX INFO: Added by JADX */
        public static final int percentX = 0x7f030398;

        /* JADX INFO: Added by JADX */
        public static final int percentY = 0x7f030399;

        /* JADX INFO: Added by JADX */
        public static final int perpendicularPath_percent = 0x7f03039a;

        /* JADX INFO: Added by JADX */
        public static final int pivotAnchor = 0x7f03039b;

        /* JADX INFO: Added by JADX */
        public static final int placeholderActivityName = 0x7f03039c;

        /* JADX INFO: Added by JADX */
        public static final int placeholderText = 0x7f03039d;

        /* JADX INFO: Added by JADX */
        public static final int placeholderTextAppearance = 0x7f03039e;

        /* JADX INFO: Added by JADX */
        public static final int placeholderTextColor = 0x7f03039f;

        /* JADX INFO: Added by JADX */
        public static final int placeholder_emptyVisibility = 0x7f0303a0;

        /* JADX INFO: Added by JADX */
        public static final int polarRelativeTo = 0x7f0303a1;

        /* JADX INFO: Added by JADX */
        public static final int popEnterAnim = 0x7f0303a2;

        /* JADX INFO: Added by JADX */
        public static final int popExitAnim = 0x7f0303a3;

        /* JADX INFO: Added by JADX */
        public static final int popUpTo = 0x7f0303a4;

        /* JADX INFO: Added by JADX */
        public static final int popUpToInclusive = 0x7f0303a5;

        /* JADX INFO: Added by JADX */
        public static final int popUpToSaveState = 0x7f0303a6;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuBackground = 0x7f0303a7;

        /* JADX INFO: Added by JADX */
        public static final int popupMenuStyle = 0x7f0303a8;

        /* JADX INFO: Added by JADX */
        public static final int popupTheme = 0x7f0303a9;

        /* JADX INFO: Added by JADX */
        public static final int popupWindowStyle = 0x7f0303aa;

        /* JADX INFO: Added by JADX */
        public static final int prefixText = 0x7f0303ab;

        /* JADX INFO: Added by JADX */
        public static final int prefixTextAppearance = 0x7f0303ac;

        /* JADX INFO: Added by JADX */
        public static final int prefixTextColor = 0x7f0303ad;

        /* JADX INFO: Added by JADX */
        public static final int preserveIconSpacing = 0x7f0303ae;

        /* JADX INFO: Added by JADX */
        public static final int pressedTranslationZ = 0x7f0303af;

        /* JADX INFO: Added by JADX */
        public static final int primaryActivityName = 0x7f0303b0;

        /* JADX INFO: Added by JADX */
        public static final int progressBarPadding = 0x7f0303b1;

        /* JADX INFO: Added by JADX */
        public static final int progressBarStyle = 0x7f0303b2;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionInterpolator = 0x7f0303b3;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionPhase = 0x7f0303b4;

        /* JADX INFO: Added by JADX */
        public static final int quantizeMotionSteps = 0x7f0303b5;

        /* JADX INFO: Added by JADX */
        public static final int queryBackground = 0x7f0303b6;

        /* JADX INFO: Added by JADX */
        public static final int queryHint = 0x7f0303b7;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 0x7f0303b8;

        /* JADX INFO: Added by JADX */
        public static final int radioButtonStyle = 0x7f0303b9;

        /* JADX INFO: Added by JADX */
        public static final int rangeFillColor = 0x7f0303ba;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyle = 0x7f0303bb;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleIndicator = 0x7f0303bc;

        /* JADX INFO: Added by JADX */
        public static final int ratingBarStyleSmall = 0x7f0303bd;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_animateChange = 0x7f0303be;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToAllConstraintSets = 0x7f0303bf;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_applyToConstraintSet = 0x7f0303c0;

        /* JADX INFO: Added by JADX */
        public static final int reactiveGuide_valueId = 0x7f0303c1;

        /* JADX INFO: Added by JADX */
        public static final int recyclerViewStyle = 0x7f0303c2;

        /* JADX INFO: Added by JADX */
        public static final int region_heightLessThan = 0x7f0303c3;

        /* JADX INFO: Added by JADX */
        public static final int region_heightMoreThan = 0x7f0303c4;

        /* JADX INFO: Added by JADX */
        public static final int region_widthLessThan = 0x7f0303c5;

        /* JADX INFO: Added by JADX */
        public static final int region_widthMoreThan = 0x7f0303c6;

        /* JADX INFO: Added by JADX */
        public static final int removeEmbeddedFabElevation = 0x7f0303c7;

        /* JADX INFO: Added by JADX */
        public static final int restoreState = 0x7f0303c8;

        /* JADX INFO: Added by JADX */
        public static final int reverseLayout = 0x7f0303c9;

        /* JADX INFO: Added by JADX */
        public static final int rippleColor = 0x7f0303ca;

        /* JADX INFO: Added by JADX */
        public static final int rotationCenterId = 0x7f0303cb;

        /* JADX INFO: Added by JADX */
        public static final int round = 0x7f0303cc;

        /* JADX INFO: Added by JADX */
        public static final int roundPercent = 0x7f0303cd;

        /* JADX INFO: Added by JADX */
        public static final int route = 0x7f0303ce;

        /* JADX INFO: Added by JADX */
        public static final int saturation = 0x7f0303cf;

        /* JADX INFO: Added by JADX */
        public static final int scaleFromTextSize = 0x7f0303d0;

        /* JADX INFO: Added by JADX */
        public static final int scopeUris = 0x7f0303d1;

        /* JADX INFO: Added by JADX */
        public static final int scrimAnimationDuration = 0x7f0303d2;

        /* JADX INFO: Added by JADX */
        public static final int scrimBackground = 0x7f0303d3;

        /* JADX INFO: Added by JADX */
        public static final int scrimVisibleHeightTrigger = 0x7f0303d4;

        /* JADX INFO: Added by JADX */
        public static final int searchHintIcon = 0x7f0303d5;

        /* JADX INFO: Added by JADX */
        public static final int searchIcon = 0x7f0303d6;

        /* JADX INFO: Added by JADX */
        public static final int searchPrefixText = 0x7f0303d7;

        /* JADX INFO: Added by JADX */
        public static final int searchViewStyle = 0x7f0303d8;

        /* JADX INFO: Added by JADX */
        public static final int secondaryActivityAction = 0x7f0303d9;

        /* JADX INFO: Added by JADX */
        public static final int secondaryActivityName = 0x7f0303da;

        /* JADX INFO: Added by JADX */
        public static final int seekBarStyle = 0x7f0303db;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackground = 0x7f0303dc;

        /* JADX INFO: Added by JADX */
        public static final int selectableItemBackgroundBorderless = 0x7f0303dd;

        /* JADX INFO: Added by JADX */
        public static final int selectionRequired = 0x7f0303de;

        /* JADX INFO: Added by JADX */
        public static final int selectorSize = 0x7f0303df;

        /* JADX INFO: Added by JADX */
        public static final int setsTag = 0x7f0303e0;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearance = 0x7f0303e1;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraLarge = 0x7f0303e2;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerExtraSmall = 0x7f0303e3;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerLarge = 0x7f0303e4;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerMedium = 0x7f0303e5;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceCornerSmall = 0x7f0303e6;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceLargeComponent = 0x7f0303e7;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceMediumComponent = 0x7f0303e8;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceOverlay = 0x7f0303e9;

        /* JADX INFO: Added by JADX */
        public static final int shapeAppearanceSmallComponent = 0x7f0303ea;

        /* JADX INFO: Added by JADX */
        public static final int shapeCornerFamily = 0x7f0303eb;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 0x7f0303ec;

        /* JADX INFO: Added by JADX */
        public static final int shouldRemoveExpandedCorners = 0x7f0303ed;

        /* JADX INFO: Added by JADX */
        public static final int showAnimationBehavior = 0x7f0303ee;

        /* JADX INFO: Added by JADX */
        public static final int showAsAction = 0x7f0303ef;

        /* JADX INFO: Added by JADX */
        public static final int showDelay = 0x7f0303f0;

        /* JADX INFO: Added by JADX */
        public static final int showDividers = 0x7f0303f1;

        /* JADX INFO: Added by JADX */
        public static final int showMarker = 0x7f0303f2;

        /* JADX INFO: Added by JADX */
        public static final int showMotionSpec = 0x7f0303f3;

        /* JADX INFO: Added by JADX */
        public static final int showPaths = 0x7f0303f4;

        /* JADX INFO: Added by JADX */
        public static final int showText = 0x7f0303f5;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f0303f6;

        /* JADX INFO: Added by JADX */
        public static final int shrinkMotionSpec = 0x7f0303f7;

        /* JADX INFO: Added by JADX */
        public static final int sideSheetDialogTheme = 0x7f0303f8;

        /* JADX INFO: Added by JADX */
        public static final int sideSheetModalStyle = 0x7f0303f9;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemLayout = 0x7f0303fa;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemSelectedColor = 0x7f0303fb;

        /* JADX INFO: Added by JADX */
        public static final int simpleItemSelectedRippleColor = 0x7f0303fc;

        /* JADX INFO: Added by JADX */
        public static final int simpleItems = 0x7f0303fd;

        /* JADX INFO: Added by JADX */
        public static final int singleChoiceItemLayout = 0x7f0303fe;

        /* JADX INFO: Added by JADX */
        public static final int singleLine = 0x7f0303ff;

        /* JADX INFO: Added by JADX */
        public static final int singleSelection = 0x7f030400;

        /* JADX INFO: Added by JADX */
        public static final int sizePercent = 0x7f030401;

        /* JADX INFO: Added by JADX */
        public static final int sliderStyle = 0x7f030402;

        /* JADX INFO: Added by JADX */
        public static final int snackbarButtonStyle = 0x7f030403;

        /* JADX INFO: Added by JADX */
        public static final int snackbarStyle = 0x7f030404;

        /* JADX INFO: Added by JADX */
        public static final int snackbarTextViewStyle = 0x7f030405;

        /* JADX INFO: Added by JADX */
        public static final int spanCount = 0x7f030406;

        /* JADX INFO: Added by JADX */
        public static final int spinBars = 0x7f030407;

        /* JADX INFO: Added by JADX */
        public static final int spinnerDropDownItemStyle = 0x7f030408;

        /* JADX INFO: Added by JADX */
        public static final int spinnerStyle = 0x7f030409;

        /* JADX INFO: Added by JADX */
        public static final int splitLayoutDirection = 0x7f03040a;

        /* JADX INFO: Added by JADX */
        public static final int splitMinSmallestWidth = 0x7f03040b;

        /* JADX INFO: Added by JADX */
        public static final int splitMinWidth = 0x7f03040c;

        /* JADX INFO: Added by JADX */
        public static final int splitRatio = 0x7f03040d;

        /* JADX INFO: Added by JADX */
        public static final int splitTrack = 0x7f03040e;

        /* JADX INFO: Added by JADX */
        public static final int springBoundary = 0x7f03040f;

        /* JADX INFO: Added by JADX */
        public static final int springDamping = 0x7f030410;

        /* JADX INFO: Added by JADX */
        public static final int springMass = 0x7f030411;

        /* JADX INFO: Added by JADX */
        public static final int springStiffness = 0x7f030412;

        /* JADX INFO: Added by JADX */
        public static final int springStopThreshold = 0x7f030413;

        /* JADX INFO: Added by JADX */
        public static final int srcCompat = 0x7f030414;

        /* JADX INFO: Added by JADX */
        public static final int stackFromEnd = 0x7f030415;

        /* JADX INFO: Added by JADX */
        public static final int staggered = 0x7f030416;

        /* JADX INFO: Added by JADX */
        public static final int startDestination = 0x7f030417;

        /* JADX INFO: Added by JADX */
        public static final int startIconCheckable = 0x7f030418;

        /* JADX INFO: Added by JADX */
        public static final int startIconContentDescription = 0x7f030419;

        /* JADX INFO: Added by JADX */
        public static final int startIconDrawable = 0x7f03041a;

        /* JADX INFO: Added by JADX */
        public static final int startIconMinSize = 0x7f03041b;

        /* JADX INFO: Added by JADX */
        public static final int startIconScaleType = 0x7f03041c;

        /* JADX INFO: Added by JADX */
        public static final int startIconTint = 0x7f03041d;

        /* JADX INFO: Added by JADX */
        public static final int startIconTintMode = 0x7f03041e;

        /* JADX INFO: Added by JADX */
        public static final int stateLabels = 0x7f03041f;

        /* JADX INFO: Added by JADX */
        public static final int state_above_anchor = 0x7f030420;

        /* JADX INFO: Added by JADX */
        public static final int state_collapsed = 0x7f030421;

        /* JADX INFO: Added by JADX */
        public static final int state_collapsible = 0x7f030422;

        /* JADX INFO: Added by JADX */
        public static final int state_dragged = 0x7f030423;

        /* JADX INFO: Added by JADX */
        public static final int state_error = 0x7f030424;

        /* JADX INFO: Added by JADX */
        public static final int state_indeterminate = 0x7f030425;

        /* JADX INFO: Added by JADX */
        public static final int state_liftable = 0x7f030426;

        /* JADX INFO: Added by JADX */
        public static final int state_lifted = 0x7f030427;

        /* JADX INFO: Added by JADX */
        public static final int state_with_icon = 0x7f030428;

        /* JADX INFO: Added by JADX */
        public static final int statusBarBackground = 0x7f030429;

        /* JADX INFO: Added by JADX */
        public static final int statusBarForeground = 0x7f03042a;

        /* JADX INFO: Added by JADX */
        public static final int statusBarScrim = 0x7f03042b;

        /* JADX INFO: Added by JADX */
        public static final int strokeColor = 0x7f03042c;

        /* JADX INFO: Added by JADX */
        public static final int strokeWidth = 0x7f03042d;

        /* JADX INFO: Added by JADX */
        public static final int subMenuArrow = 0x7f03042e;

        /* JADX INFO: Added by JADX */
        public static final int subheaderColor = 0x7f03042f;

        /* JADX INFO: Added by JADX */
        public static final int subheaderInsetEnd = 0x7f030430;

        /* JADX INFO: Added by JADX */
        public static final int subheaderInsetStart = 0x7f030431;

        /* JADX INFO: Added by JADX */
        public static final int subheaderTextAppearance = 0x7f030432;

        /* JADX INFO: Added by JADX */
        public static final int submitBackground = 0x7f030433;

        /* JADX INFO: Added by JADX */
        public static final int subtitle = 0x7f030434;

        /* JADX INFO: Added by JADX */
        public static final int subtitleCentered = 0x7f030435;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextAppearance = 0x7f030436;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextColor = 0x7f030437;

        /* JADX INFO: Added by JADX */
        public static final int subtitleTextStyle = 0x7f030438;

        /* JADX INFO: Added by JADX */
        public static final int suffixText = 0x7f030439;

        /* JADX INFO: Added by JADX */
        public static final int suffixTextAppearance = 0x7f03043a;

        /* JADX INFO: Added by JADX */
        public static final int suffixTextColor = 0x7f03043b;

        /* JADX INFO: Added by JADX */
        public static final int suggestionRowLayout = 0x7f03043c;

        /* JADX INFO: Added by JADX */
        public static final int switchMinWidth = 0x7f03043d;

        /* JADX INFO: Added by JADX */
        public static final int switchPadding = 0x7f03043e;

        /* JADX INFO: Added by JADX */
        public static final int switchStyle = 0x7f03043f;

        /* JADX INFO: Added by JADX */
        public static final int switchTextAppearance = 0x7f030440;

        /* JADX INFO: Added by JADX */
        public static final int tabBackground = 0x7f030441;

        /* JADX INFO: Added by JADX */
        public static final int tabContentStart = 0x7f030442;

        /* JADX INFO: Added by JADX */
        public static final int tabGravity = 0x7f030443;

        /* JADX INFO: Added by JADX */
        public static final int tabIconTint = 0x7f030444;

        /* JADX INFO: Added by JADX */
        public static final int tabIconTintMode = 0x7f030445;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicator = 0x7f030446;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorAnimationDuration = 0x7f030447;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorAnimationMode = 0x7f030448;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorColor = 0x7f030449;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorFullWidth = 0x7f03044a;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorGravity = 0x7f03044b;

        /* JADX INFO: Added by JADX */
        public static final int tabIndicatorHeight = 0x7f03044c;

        /* JADX INFO: Added by JADX */
        public static final int tabInlineLabel = 0x7f03044d;

        /* JADX INFO: Added by JADX */
        public static final int tabMaxWidth = 0x7f03044e;

        /* JADX INFO: Added by JADX */
        public static final int tabMinWidth = 0x7f03044f;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 0x7f030450;

        /* JADX INFO: Added by JADX */
        public static final int tabPadding = 0x7f030451;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingBottom = 0x7f030452;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingEnd = 0x7f030453;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingStart = 0x7f030454;

        /* JADX INFO: Added by JADX */
        public static final int tabPaddingTop = 0x7f030455;

        /* JADX INFO: Added by JADX */
        public static final int tabRippleColor = 0x7f030456;

        /* JADX INFO: Added by JADX */
        public static final int tabSecondaryStyle = 0x7f030457;

        /* JADX INFO: Added by JADX */
        public static final int tabSelectedTextAppearance = 0x7f030458;

        /* JADX INFO: Added by JADX */
        public static final int tabSelectedTextColor = 0x7f030459;

        /* JADX INFO: Added by JADX */
        public static final int tabStyle = 0x7f03045a;

        /* JADX INFO: Added by JADX */
        public static final int tabTextAppearance = 0x7f03045b;

        /* JADX INFO: Added by JADX */
        public static final int tabTextColor = 0x7f03045c;

        /* JADX INFO: Added by JADX */
        public static final int tabUnboundedRipple = 0x7f03045d;

        /* JADX INFO: Added by JADX */
        public static final int targetId = 0x7f03045e;

        /* JADX INFO: Added by JADX */
        public static final int targetPackage = 0x7f03045f;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailColor = 0x7f030460;

        /* JADX INFO: Added by JADX */
        public static final int telltales_tailScale = 0x7f030461;

        /* JADX INFO: Added by JADX */
        public static final int telltales_velocityMode = 0x7f030462;

        /* JADX INFO: Added by JADX */
        public static final int textAllCaps = 0x7f030463;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBody1 = 0x7f030464;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBody2 = 0x7f030465;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyLarge = 0x7f030466;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodyMedium = 0x7f030467;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceBodySmall = 0x7f030468;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceButton = 0x7f030469;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceCaption = 0x7f03046a;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayLarge = 0x7f03046b;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplayMedium = 0x7f03046c;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceDisplaySmall = 0x7f03046d;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline1 = 0x7f03046e;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline2 = 0x7f03046f;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline3 = 0x7f030470;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline4 = 0x7f030471;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline5 = 0x7f030472;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadline6 = 0x7f030473;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineLarge = 0x7f030474;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineMedium = 0x7f030475;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceHeadlineSmall = 0x7f030476;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelLarge = 0x7f030477;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelMedium = 0x7f030478;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLabelSmall = 0x7f030479;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLargePopupMenu = 0x7f03047a;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceLineHeightEnabled = 0x7f03047b;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItem = 0x7f03047c;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSecondary = 0x7f03047d;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceListItemSmall = 0x7f03047e;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceOverline = 0x7f03047f;

        /* JADX INFO: Added by JADX */
        public static final int textAppearancePopupMenuHeader = 0x7f030480;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 0x7f030481;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSearchResultTitle = 0x7f030482;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSmallPopupMenu = 0x7f030483;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSubtitle1 = 0x7f030484;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceSubtitle2 = 0x7f030485;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleLarge = 0x7f030486;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleMedium = 0x7f030487;

        /* JADX INFO: Added by JADX */
        public static final int textAppearanceTitleSmall = 0x7f030488;

        /* JADX INFO: Added by JADX */
        public static final int textBackground = 0x7f030489;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanX = 0x7f03048a;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundPanY = 0x7f03048b;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundRotate = 0x7f03048c;

        /* JADX INFO: Added by JADX */
        public static final int textBackgroundZoom = 0x7f03048d;

        /* JADX INFO: Added by JADX */
        public static final int textColorAlertDialogListItem = 0x7f03048e;

        /* JADX INFO: Added by JADX */
        public static final int textColorSearchUrl = 0x7f03048f;

        /* JADX INFO: Added by JADX */
        public static final int textEndPadding = 0x7f030490;

        /* JADX INFO: Added by JADX */
        public static final int textFillColor = 0x7f030491;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledDenseStyle = 0x7f030492;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledExposedDropdownMenuStyle = 0x7f030493;

        /* JADX INFO: Added by JADX */
        public static final int textInputFilledStyle = 0x7f030494;

        /* JADX INFO: Added by JADX */
        public static final int textInputLayoutFocusedRectEnabled = 0x7f030495;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedDenseStyle = 0x7f030496;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedExposedDropdownMenuStyle = 0x7f030497;

        /* JADX INFO: Added by JADX */
        public static final int textInputOutlinedStyle = 0x7f030498;

        /* JADX INFO: Added by JADX */
        public static final int textInputStyle = 0x7f030499;

        /* JADX INFO: Added by JADX */
        public static final int textLocale = 0x7f03049a;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineColor = 0x7f03049b;

        /* JADX INFO: Added by JADX */
        public static final int textOutlineThickness = 0x7f03049c;

        /* JADX INFO: Added by JADX */
        public static final int textPanX = 0x7f03049d;

        /* JADX INFO: Added by JADX */
        public static final int textPanY = 0x7f03049e;

        /* JADX INFO: Added by JADX */
        public static final int textStartPadding = 0x7f03049f;

        /* JADX INFO: Added by JADX */
        public static final int textureBlurFactor = 0x7f0304a0;

        /* JADX INFO: Added by JADX */
        public static final int textureEffect = 0x7f0304a1;

        /* JADX INFO: Added by JADX */
        public static final int textureHeight = 0x7f0304a2;

        /* JADX INFO: Added by JADX */
        public static final int textureWidth = 0x7f0304a3;

        /* JADX INFO: Added by JADX */
        public static final int theme = 0x7f0304a4;

        /* JADX INFO: Added by JADX */
        public static final int thickness = 0x7f0304a5;

        /* JADX INFO: Added by JADX */
        public static final int thumbColor = 0x7f0304a6;

        /* JADX INFO: Added by JADX */
        public static final int thumbElevation = 0x7f0304a7;

        /* JADX INFO: Added by JADX */
        public static final int thumbHeight = 0x7f0304a8;

        /* JADX INFO: Added by JADX */
        public static final int thumbIcon = 0x7f0304a9;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconSize = 0x7f0304aa;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconTint = 0x7f0304ab;

        /* JADX INFO: Added by JADX */
        public static final int thumbIconTintMode = 0x7f0304ac;

        /* JADX INFO: Added by JADX */
        public static final int thumbRadius = 0x7f0304ad;

        /* JADX INFO: Added by JADX */
        public static final int thumbStrokeColor = 0x7f0304ae;

        /* JADX INFO: Added by JADX */
        public static final int thumbStrokeWidth = 0x7f0304af;

        /* JADX INFO: Added by JADX */
        public static final int thumbTextPadding = 0x7f0304b0;

        /* JADX INFO: Added by JADX */
        public static final int thumbTint = 0x7f0304b1;

        /* JADX INFO: Added by JADX */
        public static final int thumbTintMode = 0x7f0304b2;

        /* JADX INFO: Added by JADX */
        public static final int thumbTrackGapSize = 0x7f0304b3;

        /* JADX INFO: Added by JADX */
        public static final int thumbWidth = 0x7f0304b4;

        /* JADX INFO: Added by JADX */
        public static final int tickColor = 0x7f0304b5;

        /* JADX INFO: Added by JADX */
        public static final int tickColorActive = 0x7f0304b6;

        /* JADX INFO: Added by JADX */
        public static final int tickColorInactive = 0x7f0304b7;

        /* JADX INFO: Added by JADX */
        public static final int tickMark = 0x7f0304b8;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTint = 0x7f0304b9;

        /* JADX INFO: Added by JADX */
        public static final int tickMarkTintMode = 0x7f0304ba;

        /* JADX INFO: Added by JADX */
        public static final int tickRadiusActive = 0x7f0304bb;

        /* JADX INFO: Added by JADX */
        public static final int tickRadiusInactive = 0x7f0304bc;

        /* JADX INFO: Added by JADX */
        public static final int tickVisible = 0x7f0304bd;

        /* JADX INFO: Added by JADX */
        public static final int tint = 0x7f0304be;

        /* JADX INFO: Added by JADX */
        public static final int tintMode = 0x7f0304bf;

        /* JADX INFO: Added by JADX */
        public static final int tintNavigationIcon = 0x7f0304c0;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f0304c1;

        /* JADX INFO: Added by JADX */
        public static final int titleCentered = 0x7f0304c2;

        /* JADX INFO: Added by JADX */
        public static final int titleCollapseMode = 0x7f0304c3;

        /* JADX INFO: Added by JADX */
        public static final int titleEnabled = 0x7f0304c4;

        /* JADX INFO: Added by JADX */
        public static final int titleMargin = 0x7f0304c5;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginBottom = 0x7f0304c6;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginEnd = 0x7f0304c7;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginStart = 0x7f0304c8;

        /* JADX INFO: Added by JADX */
        public static final int titleMarginTop = 0x7f0304c9;

        /* JADX INFO: Added by JADX */
        public static final int titleMargins = 0x7f0304ca;

        /* JADX INFO: Added by JADX */
        public static final int titlePositionInterpolator = 0x7f0304cb;

        /* JADX INFO: Added by JADX */
        public static final int titleTextAppearance = 0x7f0304cc;

        /* JADX INFO: Added by JADX */
        public static final int titleTextColor = 0x7f0304cd;

        /* JADX INFO: Added by JADX */
        public static final int titleTextEllipsize = 0x7f0304ce;

        /* JADX INFO: Added by JADX */
        public static final int titleTextStyle = 0x7f0304cf;

        /* JADX INFO: Added by JADX */
        public static final int toggleCheckedStateOnClick = 0x7f0304d0;

        /* JADX INFO: Added by JADX */
        public static final int toolbarId = 0x7f0304d1;

        /* JADX INFO: Added by JADX */
        public static final int toolbarNavigationButtonStyle = 0x7f0304d2;

        /* JADX INFO: Added by JADX */
        public static final int toolbarStyle = 0x7f0304d3;

        /* JADX INFO: Added by JADX */
        public static final int toolbarSurfaceStyle = 0x7f0304d4;

        /* JADX INFO: Added by JADX */
        public static final int tooltipForegroundColor = 0x7f0304d5;

        /* JADX INFO: Added by JADX */
        public static final int tooltipFrameBackground = 0x7f0304d6;

        /* JADX INFO: Added by JADX */
        public static final int tooltipStyle = 0x7f0304d7;

        /* JADX INFO: Added by JADX */
        public static final int tooltipText = 0x7f0304d8;

        /* JADX INFO: Added by JADX */
        public static final int topInsetScrimEnabled = 0x7f0304d9;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorId = 0x7f0304da;

        /* JADX INFO: Added by JADX */
        public static final int touchAnchorSide = 0x7f0304db;

        /* JADX INFO: Added by JADX */
        public static final int touchRegionId = 0x7f0304dc;

        /* JADX INFO: Added by JADX */
        public static final int track = 0x7f0304dd;

        /* JADX INFO: Added by JADX */
        public static final int trackColor = 0x7f0304de;

        /* JADX INFO: Added by JADX */
        public static final int trackColorActive = 0x7f0304df;

        /* JADX INFO: Added by JADX */
        public static final int trackColorInactive = 0x7f0304e0;

        /* JADX INFO: Added by JADX */
        public static final int trackCornerRadius = 0x7f0304e1;

        /* JADX INFO: Added by JADX */
        public static final int trackDecoration = 0x7f0304e2;

        /* JADX INFO: Added by JADX */
        public static final int trackDecorationTint = 0x7f0304e3;

        /* JADX INFO: Added by JADX */
        public static final int trackDecorationTintMode = 0x7f0304e4;

        /* JADX INFO: Added by JADX */
        public static final int trackHeight = 0x7f0304e5;

        /* JADX INFO: Added by JADX */
        public static final int trackInsideCornerSize = 0x7f0304e6;

        /* JADX INFO: Added by JADX */
        public static final int trackStopIndicatorSize = 0x7f0304e7;

        /* JADX INFO: Added by JADX */
        public static final int trackThickness = 0x7f0304e8;

        /* JADX INFO: Added by JADX */
        public static final int trackTint = 0x7f0304e9;

        /* JADX INFO: Added by JADX */
        public static final int trackTintMode = 0x7f0304ea;

        /* JADX INFO: Added by JADX */
        public static final int transformPivotTarget = 0x7f0304eb;

        /* JADX INFO: Added by JADX */
        public static final int transitionDisable = 0x7f0304ec;

        /* JADX INFO: Added by JADX */
        public static final int transitionEasing = 0x7f0304ed;

        /* JADX INFO: Added by JADX */
        public static final int transitionFlags = 0x7f0304ee;

        /* JADX INFO: Added by JADX */
        public static final int transitionPathRotate = 0x7f0304ef;

        /* JADX INFO: Added by JADX */
        public static final int transitionShapeAppearance = 0x7f0304f0;

        /* JADX INFO: Added by JADX */
        public static final int triggerId = 0x7f0304f1;

        /* JADX INFO: Added by JADX */
        public static final int triggerReceiver = 0x7f0304f2;

        /* JADX INFO: Added by JADX */
        public static final int triggerSlack = 0x7f0304f3;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f0304f4;

        /* JADX INFO: Added by JADX */
        public static final int upDuration = 0x7f0304f5;

        /* JADX INFO: Added by JADX */
        public static final int uri = 0x7f0304f6;

        /* JADX INFO: Added by JADX */
        public static final int useCompatPadding = 0x7f0304f7;

        /* JADX INFO: Added by JADX */
        public static final int useDrawerArrowDrawable = 0x7f0304f8;

        /* JADX INFO: Added by JADX */
        public static final int useMaterialThemeColors = 0x7f0304f9;

        /* JADX INFO: Added by JADX */
        public static final int values = 0x7f0304fa;

        /* JADX INFO: Added by JADX */
        public static final int verticalOffset = 0x7f0304fb;

        /* JADX INFO: Added by JADX */
        public static final int verticalOffsetWithText = 0x7f0304fc;

        /* JADX INFO: Added by JADX */
        public static final int viewInflaterClass = 0x7f0304fd;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionMode = 0x7f0304fe;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnCross = 0x7f0304ff;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnNegativeCross = 0x7f030500;

        /* JADX INFO: Added by JADX */
        public static final int viewTransitionOnPositiveCross = 0x7f030501;

        /* JADX INFO: Added by JADX */
        public static final int visibilityMode = 0x7f030502;

        /* JADX INFO: Added by JADX */
        public static final int voiceIcon = 0x7f030503;

        /* JADX INFO: Added by JADX */
        public static final int warmth = 0x7f030504;

        /* JADX INFO: Added by JADX */
        public static final int waveDecay = 0x7f030505;

        /* JADX INFO: Added by JADX */
        public static final int waveOffset = 0x7f030506;

        /* JADX INFO: Added by JADX */
        public static final int wavePeriod = 0x7f030507;

        /* JADX INFO: Added by JADX */
        public static final int wavePhase = 0x7f030508;

        /* JADX INFO: Added by JADX */
        public static final int waveShape = 0x7f030509;

        /* JADX INFO: Added by JADX */
        public static final int waveVariesBy = 0x7f03050a;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBar = 0x7f03050b;

        /* JADX INFO: Added by JADX */
        public static final int windowActionBarOverlay = 0x7f03050c;

        /* JADX INFO: Added by JADX */
        public static final int windowActionModeOverlay = 0x7f03050d;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMajor = 0x7f03050e;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedHeightMinor = 0x7f03050f;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMajor = 0x7f030510;

        /* JADX INFO: Added by JADX */
        public static final int windowFixedWidthMinor = 0x7f030511;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMajor = 0x7f030512;

        /* JADX INFO: Added by JADX */
        public static final int windowMinWidthMinor = 0x7f030513;

        /* JADX INFO: Added by JADX */
        public static final int windowNoTitle = 0x7f030514;

        /* JADX INFO: Added by JADX */
        public static final int yearSelectedStyle = 0x7f030515;

        /* JADX INFO: Added by JADX */
        public static final int yearStyle = 0x7f030516;

        /* JADX INFO: Added by JADX */
        public static final int yearTodayStyle = 0x7f030517;
    }

    /* JADX INFO: Added by JADX */
    public static final class bool {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_embed_tabs = 0x7f040000;
    }

    public static final class color {

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int abc_color_highlight_material = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int abc_decor_view_status_guard_light = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_dark = 0x7f050007;

        /* JADX INFO: Added by JADX */
        public static final int abc_hint_foreground_material_light = 0x7f050008;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 0x7f050009;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 0x7f05000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_dark = 0x7f05000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_primary_text_material_light = 0x7f05000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text = 0x7f05000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_normal = 0x7f05000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_pressed = 0x7f05000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_url_text_selected = 0x7f050010;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_dark = 0x7f050011;

        /* JADX INFO: Added by JADX */
        public static final int abc_secondary_text_material_light = 0x7f050012;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_btn_checkable = 0x7f050013;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_default = 0x7f050014;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_edittext = 0x7f050015;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_seek_thumb = 0x7f050016;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_spinner = 0x7f050017;

        /* JADX INFO: Added by JADX */
        public static final int abc_tint_switch_track = 0x7f050018;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_dark = 0x7f050019;

        /* JADX INFO: Added by JADX */
        public static final int accent_material_light = 0x7f05001a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 0x7f05001b;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 0x7f05001c;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_dark = 0x7f05001d;

        /* JADX INFO: Added by JADX */
        public static final int background_floating_material_light = 0x7f05001e;

        /* JADX INFO: Added by JADX */
        public static final int background_material_dark = 0x7f05001f;

        /* JADX INFO: Added by JADX */
        public static final int background_material_light = 0x7f050020;

        /* JADX INFO: Added by JADX */
        public static final int brand_background = 0x7f050021;

        /* JADX INFO: Added by JADX */
        public static final int brand_card = 0x7f050022;

        /* JADX INFO: Added by JADX */
        public static final int brand_card_stroke = 0x7f050023;

        /* JADX INFO: Added by JADX */
        public static final int brand_muted = 0x7f050024;

        /* JADX INFO: Added by JADX */
        public static final int brand_on_background = 0x7f050025;

        /* JADX INFO: Added by JADX */
        public static final int brand_on_primary = 0x7f050026;

        /* JADX INFO: Added by JADX */
        public static final int brand_primary = 0x7f050027;

        /* JADX INFO: Added by JADX */
        public static final int brand_secondary = 0x7f050028;

        /* JADX INFO: Added by JADX */
        public static final int brand_surface = 0x7f050029;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_dark = 0x7f05002a;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_disabled_material_light = 0x7f05002b;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_dark = 0x7f05002e;

        /* JADX INFO: Added by JADX */
        public static final int bright_foreground_material_light = 0x7f05002f;

        /* JADX INFO: Added by JADX */
        public static final int button_material_dark = 0x7f050034;

        /* JADX INFO: Added by JADX */
        public static final int button_material_light = 0x7f050035;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 0x7f050036;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 0x7f050037;

        /* JADX INFO: Added by JADX */
        public static final int cardview_dark_background = 0x7f050038;

        /* JADX INFO: Added by JADX */
        public static final int cardview_light_background = 0x7f050039;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f05003c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_default = 0x7f05003d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_disabled = 0x7f05003e;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f05003f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_pressed = 0x7f050040;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f050041;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_default = 0x7f050042;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_disabled = 0x7f050043;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f050044;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_pressed = 0x7f050045;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_tint = 0x7f050046;

        /* JADX INFO: Added by JADX */
        public static final int design_box_stroke_color = 0x7f050048;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_background = 0x7f050049;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_error = 0x7f05004a;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_background = 0x7f05004b;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_error = 0x7f05004c;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_primary = 0x7f05004d;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_secondary = 0x7f05004e;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_on_surface = 0x7f05004f;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary = 0x7f050050;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary_dark = 0x7f050051;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_primary_variant = 0x7f050052;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_secondary = 0x7f050053;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_secondary_variant = 0x7f050054;

        /* JADX INFO: Added by JADX */
        public static final int design_dark_default_color_surface = 0x7f050055;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_background = 0x7f050056;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_error = 0x7f050057;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_background = 0x7f050058;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_error = 0x7f050059;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_primary = 0x7f05005a;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_secondary = 0x7f05005b;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_on_surface = 0x7f05005c;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary = 0x7f05005d;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary_dark = 0x7f05005e;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_primary_variant = 0x7f05005f;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_secondary = 0x7f050060;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_secondary_variant = 0x7f050061;

        /* JADX INFO: Added by JADX */
        public static final int design_default_color_surface = 0x7f050062;

        /* JADX INFO: Added by JADX */
        public static final int design_error = 0x7f050063;

        /* JADX INFO: Added by JADX */
        public static final int design_icon_tint = 0x7f05006b;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background_color = 0x7f05006c;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_dark = 0x7f050071;

        /* JADX INFO: Added by JADX */
        public static final int error_color_material_light = 0x7f050072;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_dark = 0x7f050073;

        /* JADX INFO: Added by JADX */
        public static final int foreground_material_light = 0x7f050074;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_dark = 0x7f050075;

        /* JADX INFO: Added by JADX */
        public static final int highlighted_text_material_light = 0x7f050076;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_background = 0x7f050077;

        /* JADX INFO: Added by JADX */
        public static final int m3_assist_chip_icon_tint_color = 0x7f050079;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle_color = 0x7f05007b;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_background_color_selector = 0x7f05007c;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_foreground_color_selector = 0x7f05007d;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_outline_color_selector = 0x7f05007e;

        /* JADX INFO: Added by JADX */
        public static final int m3_button_ripple_color_selector = 0x7f050080;

        /* JADX INFO: Added by JADX */
        public static final int m3_calendar_item_disabled_text = 0x7f050081;

        /* JADX INFO: Added by JADX */
        public static final int m3_calendar_item_stroke_color = 0x7f050082;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_foreground_color = 0x7f050083;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_ripple_color = 0x7f050084;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_stroke_color = 0x7f050085;

        /* JADX INFO: Added by JADX */
        public static final int m3_checkbox_button_icon_tint = 0x7f050086;

        /* JADX INFO: Added by JADX */
        public static final int m3_checkbox_button_tint = 0x7f050087;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_assist_text_color = 0x7f050088;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_background_color = 0x7f050089;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_ripple_color = 0x7f05008a;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_stroke_color = 0x7f05008b;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_text_color = 0x7f05008c;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_default_color_primary_text = 0x7f05008d;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_default_color_secondary_text = 0x7f05008e;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_highlighted_text = 0x7f05008f;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_hint_foreground = 0x7f050090;

        /* JADX INFO: Added by JADX */
        public static final int m3_dark_primary_text_disable_only = 0x7f050091;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_color_primary_text = 0x7f050092;

        /* JADX INFO: Added by JADX */
        public static final int m3_default_color_secondary_text = 0x7f050093;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_default_color_primary_text = 0x7f050094;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_default_color_secondary_text = 0x7f050095;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_highlighted_text = 0x7f050096;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_hint_foreground = 0x7f050097;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_dark_primary_text_disable_only = 0x7f050098;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_default_color_primary_text = 0x7f050099;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_default_color_secondary_text = 0x7f05009a;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_highlighted_text = 0x7f05009b;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_hint_foreground = 0x7f05009c;

        /* JADX INFO: Added by JADX */
        public static final int m3_dynamic_primary_text_disable_only = 0x7f05009d;

        /* JADX INFO: Added by JADX */
        public static final int m3_efab_ripple_color_selector = 0x7f05009e;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_efab_background_color_selector = 0x7f0500a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_efab_foreground_color_selector = 0x7f0500a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_ripple_color_selector = 0x7f0500a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_filled_icon_button_container_color_selector = 0x7f0500a3;

        /* JADX INFO: Added by JADX */
        public static final int m3_highlighted_text = 0x7f0500a4;

        /* JADX INFO: Added by JADX */
        public static final int m3_hint_foreground = 0x7f0500a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_icon_button_icon_color_selector = 0x7f0500a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_item_with_indicator_icon_tint = 0x7f0500a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_item_with_indicator_label_tint = 0x7f0500a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_bar_ripple_color_selector = 0x7f0500a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_background_color = 0x7f0500aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_icon_tint = 0x7f0500ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_ripple_color = 0x7f0500ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_text_color = 0x7f0500ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_with_indicator_icon_tint = 0x7f0500ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_with_indicator_label_tint = 0x7f0500af;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_ripple_color_selector = 0x7f0500b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_primary_text_disable_only = 0x7f0500b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_button_tint = 0x7f0500b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_ripple_tint = 0x7f0500b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral10 = 0x7f0500b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral20 = 0x7f0500bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral90 = 0x7f0500c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral95 = 0x7f0500ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant100 = 0x7f0500d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant30 = 0x7f0500d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant50 = 0x7f0500d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant80 = 0x7f0500dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant87 = 0x7f0500de;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant90 = 0x7f0500df;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant92 = 0x7f0500e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant94 = 0x7f0500e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant96 = 0x7f0500e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_neutral_variant98 = 0x7f0500e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary10 = 0x7f0500e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary100 = 0x7f0500e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary30 = 0x7f0500ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary40 = 0x7f0500eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary80 = 0x7f0500ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_primary90 = 0x7f0500f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary10 = 0x7f0500f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary100 = 0x7f0500f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary30 = 0x7f0500f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary40 = 0x7f0500f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary80 = 0x7f0500fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_secondary90 = 0x7f0500fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary10 = 0x7f050101;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary100 = 0x7f050102;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary30 = 0x7f050104;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary40 = 0x7f050105;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary80 = 0x7f050109;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_dynamic_tertiary90 = 0x7f05010a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error10 = 0x7f05010e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error100 = 0x7f05010f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error40 = 0x7f050112;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_error90 = 0x7f050117;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral10 = 0x7f05011b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral100 = 0x7f05011c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral20 = 0x7f05011f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral87 = 0x7f05012a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral90 = 0x7f05012b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral92 = 0x7f05012c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral94 = 0x7f05012d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral95 = 0x7f05012e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral96 = 0x7f05012f;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral98 = 0x7f050130;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant30 = 0x7f050136;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant50 = 0x7f050138;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant80 = 0x7f05013b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_neutral_variant90 = 0x7f05013c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary10 = 0x7f050140;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary100 = 0x7f050141;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary30 = 0x7f050143;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary40 = 0x7f050144;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary80 = 0x7f050148;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_primary90 = 0x7f050149;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary10 = 0x7f05014d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary100 = 0x7f05014e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary30 = 0x7f050150;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary40 = 0x7f050151;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary80 = 0x7f050155;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_secondary90 = 0x7f050156;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary10 = 0x7f05015a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary100 = 0x7f05015b;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary30 = 0x7f05015d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary40 = 0x7f05015e;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary80 = 0x7f050162;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_palette_tertiary90 = 0x7f050163;

        /* JADX INFO: Added by JADX */
        public static final int m3_selection_control_ripple_color_selector = 0x7f050167;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_ripple_color = 0x7f050168;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_active_track_color = 0x7f050169;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_inactive_track_color = 0x7f05016c;

        /* JADX INFO: Added by JADX */
        public static final int m3_slider_thumb_color = 0x7f05016e;

        /* JADX INFO: Added by JADX */
        public static final int m3_switch_thumb_tint = 0x7f050170;

        /* JADX INFO: Added by JADX */
        public static final int m3_switch_track_tint = 0x7f050171;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_background = 0x7f050178;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_surface = 0x7f05017f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_on_surface_variant = 0x7f050180;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dark_primary = 0x7f050185;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_background = 0x7f05019a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_surface = 0x7f0501a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_on_surface_variant = 0x7f0501a2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_dark_primary = 0x7f0501a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_background = 0x7f0501b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_error = 0x7f0501b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_error_container = 0x7f0501b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_on_surface = 0x7f0501b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_primary = 0x7f0501ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_inverse_surface = 0x7f0501bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_background = 0x7f0501bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_error = 0x7f0501bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_error_container = 0x7f0501be;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_primary = 0x7f0501bf;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_primary_container = 0x7f0501c0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_secondary = 0x7f0501c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_secondary_container = 0x7f0501c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_surface = 0x7f0501c3;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_surface_variant = 0x7f0501c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_tertiary = 0x7f0501c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_on_tertiary_container = 0x7f0501c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_outline = 0x7f0501c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_outline_variant = 0x7f0501c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_primary = 0x7f0501c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_primary_container = 0x7f0501ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_secondary = 0x7f0501cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_secondary_container = 0x7f0501cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface = 0x7f0501cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_bright = 0x7f0501ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container = 0x7f0501cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_high = 0x7f0501d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_highest = 0x7f0501d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_low = 0x7f0501d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_container_lowest = 0x7f0501d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_dim = 0x7f0501d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_surface_variant = 0x7f0501d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_tertiary = 0x7f0501d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_light_tertiary_container = 0x7f0501d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_primary_fixed = 0x7f0501d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_primary_fixed_variant = 0x7f0501d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_secondary_fixed = 0x7f0501da;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_secondary_fixed_variant = 0x7f0501db;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed = 0x7f0501dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed_variant = 0x7f0501dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_primary_fixed = 0x7f0501de;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_primary_fixed_dim = 0x7f0501df;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_secondary_fixed = 0x7f0501e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_secondary_fixed_dim = 0x7f0501e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_tertiary_fixed = 0x7f0501e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_dynamic_tertiary_fixed_dim = 0x7f0501e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_background = 0x7f0501e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_error = 0x7f0501e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_error_container = 0x7f0501e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_on_surface = 0x7f0501e7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_primary = 0x7f0501e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_inverse_surface = 0x7f0501e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_background = 0x7f0501ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_error = 0x7f0501eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_error_container = 0x7f0501ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_primary = 0x7f0501ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_primary_container = 0x7f0501ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_secondary = 0x7f0501ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_secondary_container = 0x7f0501f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_surface = 0x7f0501f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_surface_variant = 0x7f0501f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_tertiary = 0x7f0501f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_on_tertiary_container = 0x7f0501f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_outline = 0x7f0501f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_outline_variant = 0x7f0501f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_primary = 0x7f0501f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_primary_container = 0x7f0501f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_secondary = 0x7f0501f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_secondary_container = 0x7f0501fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface = 0x7f0501fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_bright = 0x7f0501fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container = 0x7f0501fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_high = 0x7f0501fe;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_highest = 0x7f0501ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_low = 0x7f050200;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_container_lowest = 0x7f050201;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_dim = 0x7f050202;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_surface_variant = 0x7f050203;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_tertiary = 0x7f050204;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_light_tertiary_container = 0x7f050205;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_primary_fixed = 0x7f050206;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_primary_fixed_variant = 0x7f050207;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_secondary_fixed = 0x7f050208;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_secondary_fixed_variant = 0x7f050209;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_tertiary_fixed = 0x7f05020a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_on_tertiary_fixed_variant = 0x7f05020b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_primary_fixed = 0x7f05020c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_primary_fixed_dim = 0x7f05020d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_secondary_fixed = 0x7f05020e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_secondary_fixed_dim = 0x7f05020f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_tertiary_fixed = 0x7f050210;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_color_tertiary_fixed_dim = 0x7f050211;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_icon_color = 0x7f050212;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_icon_color_secondary = 0x7f050213;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_ripple_color = 0x7f050214;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_ripple_color_secondary = 0x7f050215;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_text_color = 0x7f050216;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_text_color_secondary = 0x7f050217;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_background_color_selector = 0x7f050218;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_foreground_color_selector = 0x7f050219;

        /* JADX INFO: Added by JADX */
        public static final int m3_text_button_ripple_color_selector = 0x7f05021a;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_filled_background_color = 0x7f05021b;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_indicator_text_color = 0x7f05021c;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_input_text_color = 0x7f05021d;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_label_color = 0x7f05021e;

        /* JADX INFO: Added by JADX */
        public static final int m3_textfield_stroke_color = 0x7f05021f;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_background_color = 0x7f050220;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_ripple_color = 0x7f050221;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_button_text_color = 0x7f050222;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_clock_text_color = 0x7f050223;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_background_color = 0x7f050224;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_ripple_color = 0x7f050225;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_display_text_color = 0x7f050226;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_secondary_text_button_ripple_color = 0x7f050227;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_secondary_text_button_text_color = 0x7f050228;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_time_input_stroke_color = 0x7f050229;

        /* JADX INFO: Added by JADX */
        public static final int m3_tonal_button_ripple_color_selector = 0x7f05022a;

        /* JADX INFO: Added by JADX */
        public static final int mark_ink = 0x7f05022b;

        /* JADX INFO: Added by JADX */
        public static final int mark_track = 0x7f05022c;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_200 = 0x7f050231;

        /* JADX INFO: Added by JADX */
        public static final int material_deep_teal_500 = 0x7f050232;

        /* JADX INFO: Added by JADX */
        public static final int material_divider_color = 0x7f050233;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_error = 0x7f050238;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_error_container = 0x7f050239;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_on_error = 0x7f05023a;

        /* JADX INFO: Added by JADX */
        public static final int material_dynamic_color_light_on_error_container = 0x7f05023b;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_100 = 0x7f05027d;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_50 = 0x7f05027f;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_600 = 0x7f050280;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_800 = 0x7f050281;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_850 = 0x7f050282;

        /* JADX INFO: Added by JADX */
        public static final int material_grey_900 = 0x7f050283;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_disabled = 0x7f05028e;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_emphasis_high_type = 0x7f05028f;

        /* JADX INFO: Added by JADX */
        public static final int material_on_surface_emphasis_medium = 0x7f050290;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_background = 0x7f050294;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_activated = 0x7f050295;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_highlight = 0x7f050296;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_control_normal = 0x7f050297;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_error = 0x7f050298;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_error_container = 0x7f050299;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_background = 0x7f05029a;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_error = 0x7f05029b;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_error_container = 0x7f05029c;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_primary = 0x7f05029d;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_primary_container = 0x7f05029e;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_secondary = 0x7f05029f;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_secondary_container = 0x7f0502a0;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface = 0x7f0502a1;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface_inverse = 0x7f0502a2;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_surface_variant = 0x7f0502a3;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_tertiary = 0x7f0502a4;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_on_tertiary_container = 0x7f0502a5;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_outline = 0x7f0502a6;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_outline_variant = 0x7f0502a7;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary = 0x7f0502a8;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_container = 0x7f0502a9;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_primary_inverse = 0x7f0502aa;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary = 0x7f0502ad;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_secondary_container = 0x7f0502ae;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface = 0x7f0502b1;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_bright = 0x7f0502b2;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container = 0x7f0502b3;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_high = 0x7f0502b4;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_highest = 0x7f0502b5;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_low = 0x7f0502b6;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_container_lowest = 0x7f0502b7;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_dim = 0x7f0502b8;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_inverse = 0x7f0502b9;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_surface_variant = 0x7f0502ba;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_tertiary = 0x7f0502bb;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_tertiary_container = 0x7f0502bc;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_hint_foreground_inverse = 0x7f0502bd;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_primary_inverse = 0x7f0502be;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_primary_inverse_disable_only = 0x7f0502bf;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse = 0x7f0502c0;

        /* JADX INFO: Added by JADX */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse_disabled = 0x7f0502c1;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_active_tick_marks_color = 0x7f0502c6;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_active_track_color = 0x7f0502c7;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_halo_color = 0x7f0502c8;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_inactive_tick_marks_color = 0x7f0502c9;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_inactive_track_color = 0x7f0502ca;

        /* JADX INFO: Added by JADX */
        public static final int material_slider_thumb_color = 0x7f0502cb;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_button_background = 0x7f0502cc;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_button_stroke = 0x7f0502cd;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clock_text_color = 0x7f0502ce;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clockface = 0x7f0502cf;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_modebutton_tint = 0x7f0502d0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_bg_color_selector = 0x7f0502d1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_ripple_color = 0x7f0502d2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_stroke_color_selector = 0x7f0502d3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_bg_color_selector = 0x7f0502d4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_ripple_color = 0x7f0502d5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_color_selector = 0x7f0502d7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_item_stroke_color = 0x7f0502d9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selected_range = 0x7f0502da;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_view_foreground = 0x7f0502db;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_view_ripple = 0x7f0502dc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_background_color = 0x7f0502dd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_close_icon_tint = 0x7f0502de;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_surface_color = 0x7f0502df;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_text_color = 0x7f0502e0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_background_color = 0x7f0502e1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_ripple_color = 0x7f0502e2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_choice_chip_text_color = 0x7f0502e3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_error = 0x7f0502e4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_bg_color_selector = 0x7f0502e5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_icon_text_color_selector = 0x7f0502e6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_ripple_color = 0x7f0502e7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_background_color = 0x7f0502e8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_icon_tint = 0x7f0502e9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_filled_stroke_color = 0x7f0502ea;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_indicator_text_color = 0x7f0502eb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_tint = 0x7f0502ee;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_ripple_color = 0x7f0502ef;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_background_color = 0x7f0502f0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_tint = 0x7f0502f1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_text_color = 0x7f0502f2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_on_primary_text_btn_text_color_selector = 0x7f0502f3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_on_surface_ripple_color = 0x7f0502f4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_outlined_icon_tint = 0x7f0502f5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_outlined_stroke_color = 0x7f0502f6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_overlay_color = 0x7f0502f7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_scrim_color = 0x7f0502f8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_icon_tint = 0x7f0502f9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_tint = 0x7f0502fa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration_tint = 0x7f0502fb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_tint = 0x7f0502fc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_icon_color_selector = 0x7f0502fe;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_legacy_text_color_selector = 0x7f050300;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_ripple_color = 0x7f050301;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_text_btn_text_color_selector = 0x7f050302;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_default_box_stroke_color = 0x7f050303;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_disabled_color = 0x7f050304;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_focused_box_stroke_color = 0x7f050306;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_hovered_box_stroke_color = 0x7f050307;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 0x7f050308;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 0x7f050309;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_dark = 0x7f05030a;

        /* JADX INFO: Added by JADX */
        public static final int primary_dark_material_light = 0x7f05030b;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_dark = 0x7f05030c;

        /* JADX INFO: Added by JADX */
        public static final int primary_material_light = 0x7f05030d;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_dark = 0x7f05030e;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_default_material_light = 0x7f05030f;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_dark = 0x7f050310;

        /* JADX INFO: Added by JADX */
        public static final int primary_text_disabled_material_light = 0x7f050311;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_dark = 0x7f050312;

        /* JADX INFO: Added by JADX */
        public static final int ripple_material_light = 0x7f050313;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_dark = 0x7f050314;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_default_material_light = 0x7f050315;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_dark = 0x7f050316;

        /* JADX INFO: Added by JADX */
        public static final int secondary_text_disabled_material_light = 0x7f050317;

        /* JADX INFO: Added by JADX */
        public static final int splash_bg = 0x7f050318;

        /* JADX INFO: Added by JADX */
        public static final int splash_ink = 0x7f050319;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_dark = 0x7f05031a;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_disabled_material_light = 0x7f05031b;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_dark = 0x7f05031c;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_material_light = 0x7f05031d;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_dark = 0x7f05031e;

        /* JADX INFO: Added by JADX */
        public static final int switch_thumb_normal_material_light = 0x7f05031f;

        /* JADX INFO: Added by JADX */
        public static final int tint_0 = 0x7f050320;

        /* JADX INFO: Added by JADX */
        public static final int tint_1 = 0x7f050321;

        /* JADX INFO: Added by JADX */
        public static final int tint_2 = 0x7f050322;

        /* JADX INFO: Added by JADX */
        public static final int tint_3 = 0x7f050323;

        /* JADX INFO: Added by JADX */
        public static final int tint_4 = 0x7f050324;

        /* JADX INFO: Added by JADX */
        public static final int tint_5 = 0x7f050325;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_dark = 0x7f050326;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_background_light = 0x7f050327;
    }

    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_material = 0x7f060000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 0x7f060001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_height_material = 0x7f060002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 0x7f060003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 0x7f060004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_elevation_material = 0x7f060005;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_max_height = 0x7f060009;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f06000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f06000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 0x7f060010;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_dimen = 0x7f060011;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_horizontal_material = 0x7f060012;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_inset_vertical_material = 0x7f060013;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_horizontal_material = 0x7f060014;

        /* JADX INFO: Added by JADX */
        public static final int abc_button_padding_vertical_material = 0x7f060015;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 0x7f060016;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_prefDialogWidth = 0x7f060017;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_corner_material = 0x7f060018;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_inset_material = 0x7f060019;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_padding_material = 0x7f06001a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_corner_radius_material = 0x7f06001b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_major = 0x7f06001c;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_height_minor = 0x7f06001d;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_major = 0x7f06001e;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_fixed_width_minor = 0x7f06001f;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 0x7f060020;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 0x7f060021;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_major = 0x7f060022;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_min_width_minor = 0x7f060023;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_material = 0x7f060024;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_padding_top_material = 0x7f060025;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_divider_material = 0x7f060026;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_icon_width = 0x7f060029;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 0x7f06002a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 0x7f06002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 0x7f06002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 0x7f06002d;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_inset_top_material = 0x7f06002e;

        /* JADX INFO: Added by JADX */
        public static final int abc_floating_window_z = 0x7f06002f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_large_material = 0x7f060030;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_material = 0x7f060031;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_height_small_material = 0x7f060032;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 0x7f060033;

        /* JADX INFO: Added by JADX */
        public static final int abc_panel_menu_list_width = 0x7f060034;

        /* JADX INFO: Added by JADX */
        public static final int abc_progress_bar_height_material = 0x7f060035;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_height = 0x7f060036;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view_preferred_width = 0x7f060037;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_padding_start_material = 0x7f06003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_big = 0x7f06003b;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_medium = 0x7f06003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_small = 0x7f06003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_padding = 0x7f06003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_size_menu_header_material = 0x7f06004a;

        /* JADX INFO: Added by JADX */
        public static final int appcompat_dialog_background_inset = 0x7f060051;

        /* JADX INFO: Added by JADX */
        public static final int band_row_height = 0x7f060052;

        /* JADX INFO: Added by JADX */
        public static final int beam_height = 0x7f060053;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_max_width = 0x7f060054;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_context_menu_min_padding = 0x7f060055;

        /* JADX INFO: Added by JADX */
        public static final int cardview_default_elevation = 0x7f060057;

        /* JADX INFO: Added by JADX */
        public static final int cardview_default_radius = 0x7f060058;

        /* JADX INFO: Added by JADX */
        public static final int clock_face_margin_start = 0x7f060059;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 0x7f06005a;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 0x7f06005b;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 0x7f06005c;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 0x7f06005d;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 0x7f06005e;

        /* JADX INFO: Added by JADX */
        public static final int corner_card = 0x7f060061;

        /* JADX INFO: Added by JADX */
        public static final int design_appbar_elevation = 0x7f060063;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_item_max_width = 0x7f060064;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_item_min_width = 0x7f060065;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_active_text_size = 0x7f060066;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_elevation = 0x7f060067;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_height = 0x7f060068;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_icon_size = 0x7f060069;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item_max_width = 0x7f06006a;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item_min_width = 0x7f06006b;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_label_padding = 0x7f06006c;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_margin = 0x7f06006d;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_text_size = 0x7f06006f;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_elevation = 0x7f060070;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_modal_elevation = 0x7f060071;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_peek_height_min = 0x7f060072;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_border_width = 0x7f060073;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_elevation = 0x7f060074;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_image_size = 0x7f060075;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_size_mini = 0x7f060076;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_size_normal = 0x7f060077;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_translation_z_hovered_focused = 0x7f060078;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_translation_z_pressed = 0x7f060079;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_elevation = 0x7f06007a;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_icon_padding = 0x7f06007b;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_icon_size = 0x7f06007c;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_horizontal_padding = 0x7f06007d;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_item_icon_padding = 0x7f06007e;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_max_width = 0x7f060080;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_separator_vertical_padding = 0x7f060082;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_action_inline_max_width = 0x7f060083;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_action_text_color_alpha = 0x7f060084;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background_corner_radius = 0x7f060085;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_elevation = 0x7f060086;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_extra_spacing_horizontal = 0x7f060087;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_max_width = 0x7f060088;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_min_width = 0x7f060089;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_horizontal = 0x7f06008a;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_vertical = 0x7f06008b;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_padding_vertical_2lines = 0x7f06008c;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_text_size = 0x7f06008d;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_max_width = 0x7f06008e;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_text_size = 0x7f060090;

        /* JADX INFO: Added by JADX */
        public static final int design_textinput_caption_translate_y = 0x7f060092;

        /* JADX INFO: Added by JADX */
        public static final int dial_hero = 0x7f060093;

        /* JADX INFO: Added by JADX */
        public static final int dial_resting = 0x7f060094;

        /* JADX INFO: Added by JADX */
        public static final int dial_sheet = 0x7f060095;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_default_thickness = 0x7f060098;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_margin = 0x7f060099;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_minimum_range = 0x7f06009a;

        /* JADX INFO: Added by JADX */
        public static final int highlight_alpha_material_colored = 0x7f06009b;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_dark = 0x7f06009e;

        /* JADX INFO: Added by JADX */
        public static final int hint_alpha_material_light = 0x7f06009f;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_dark = 0x7f0600a0;

        /* JADX INFO: Added by JADX */
        public static final int hint_pressed_alpha_material_light = 0x7f0600a1;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f0600a2;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_max_velocity = 0x7f0600a3;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_velocity = 0x7f0600a4;

        /* JADX INFO: Added by JADX */
        public static final int keep_marker = 0x7f0600a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_action_bottom_padding = 0x7f0600a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_action_top_padding = 0x7f0600a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_elevation = 0x7f0600a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_icon_margin = 0x7f0600aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_icon_size = 0x7f0600ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_title_bottom_margin = 0x7f0600ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_expanded_title_margin_bottom = 0x7f0600ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_expanded_title_margin_horizontal = 0x7f0600ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger = 0x7f0600af;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger_large = 0x7f0600b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_scrim_height_trigger_medium = 0x7f0600b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_compact = 0x7f0600b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_large = 0x7f0600b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_appbar_size_medium = 0x7f0600b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_bottom_container_max_scale_x_distance = 0x7f0600b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_bottom_container_max_scale_y_distance = 0x7f0600b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_x_distance_grow = 0x7f0600b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_x_distance_shrink = 0x7f0600ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_back_progress_side_container_max_scale_y_distance = 0x7f0600bb;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_offset = 0x7f0600bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_size = 0x7f0600be;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_offset = 0x7f0600c1;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_size = 0x7f0600c2;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_with_text_vertical_padding = 0x7f0600c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_height = 0x7f0600c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_margin_horizontal = 0x7f0600c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_active_indicator_width = 0x7f0600c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_padding_bottom = 0x7f0600c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_item_padding_top = 0x7f0600c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_nav_min_height = 0x7f0600ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle_bottom_padding = 0x7f0600cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_elevation = 0x7f0600cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_modal_elevation = 0x7f0600cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_margin = 0x7f0600ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f0600cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_cradle_vertical_offset = 0x7f0600d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_fab_end_margin = 0x7f0600d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_height = 0x7f0600d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottomappbar_horizontal_padding = 0x7f0600d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_dialog_btn_min_width = 0x7f0600d4;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_dialog_btn_spacing = 0x7f0600d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_disabled_elevation = 0x7f0600d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_disabled_translation_z = 0x7f0600d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_elevation = 0x7f0600d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_default_padding = 0x7f0600dc;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_default_size = 0x7f0600dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_icon_padding = 0x7f0600de;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_icon_only_min_width = 0x7f0600df;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_inset = 0x7f0600e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_max_width = 0x7f0600e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_bottom = 0x7f0600e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_left = 0x7f0600e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_right = 0x7f0600e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_padding_top = 0x7f0600e5;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_padding_left = 0x7f0600e9;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_text_btn_padding_right = 0x7f0600ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_translation_z_base = 0x7f0600eb;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_translation_z_hovered = 0x7f0600ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_dragged_z = 0x7f0600ee;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_dragged_z = 0x7f0600f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_elevation = 0x7f0600f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevated_hovered_z = 0x7f0600f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_elevation = 0x7f0600f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_hovered_z = 0x7f0600f4;

        /* JADX INFO: Added by JADX */
        public static final int m3_card_stroke_width = 0x7f0600f5;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_debug_keyline_width = 0x7f0600f6;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_gone_size = 0x7f0600f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_small_item_size_max = 0x7f0600fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_carousel_small_item_size_min = 0x7f0600fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_checked_hovered_translation_z = 0x7f0600fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_icon_size = 0x7f060102;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_container_height = 0x7f060103;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_flat_container_elevation = 0x7f060105;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_flat_outline_width = 0x7f060106;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_assist_chip_with_icon_icon_size = 0x7f060107;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_badge_large_size = 0x7f060108;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_badge_size = 0x7f060109;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_bottom_app_bar_container_elevation = 0x7f06010a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_bottom_app_bar_container_height = 0x7f06010b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_checkbox_selected_disabled_container_opacity = 0x7f06010c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_date_today_container_outline_width = 0x7f06010d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_header_container_height = 0x7f06010e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_date_picker_modal_range_selection_header_container_height = 0x7f06010f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_divider_thickness = 0x7f060110;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_elevated_card_container_elevation = 0x7f060113;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_elevated_card_icon_size = 0x7f060114;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_elevation = 0x7f060115;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_container_height = 0x7f060116;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_focus_container_elevation = 0x7f060117;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_focus_state_layer_opacity = 0x7f060118;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_hover_container_elevation = 0x7f060119;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_hover_state_layer_opacity = 0x7f06011a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_icon_size = 0x7f06011b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_pressed_container_elevation = 0x7f06011c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_extended_fab_primary_pressed_state_layer_opacity = 0x7f06011d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_elevation = 0x7f06011e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_container_height = 0x7f06011f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_focus_state_layer_opacity = 0x7f060120;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_hover_container_elevation = 0x7f060121;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_hover_state_layer_opacity = 0x7f060122;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_icon_size = 0x7f060123;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_large_container_height = 0x7f060124;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_large_icon_size = 0x7f060125;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_pressed_container_elevation = 0x7f060126;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_pressed_state_layer_opacity = 0x7f060127;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_small_container_height = 0x7f060128;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_fab_primary_small_icon_size = 0x7f060129;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_autocomplete_menu_container_elevation = 0x7f06012a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_button_container_elevation = 0x7f06012b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_button_with_icon_icon_size = 0x7f06012c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_container_elevation = 0x7f06012d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_dragged_state_layer_opacity = 0x7f06012e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_focus_state_layer_opacity = 0x7f06012f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_hover_state_layer_opacity = 0x7f060130;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_icon_size = 0x7f060131;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_card_pressed_state_layer_opacity = 0x7f060132;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_filled_text_field_disabled_active_indicator_opacity = 0x7f060133;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_container_elevation = 0x7f060139;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_container_height = 0x7f06013a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_unselected_outline_width = 0x7f06013b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_input_chip_with_avatar_avatar_size = 0x7f06013c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_menu_container_elevation = 0x7f06013e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_active_indicator_height = 0x7f06013f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_active_indicator_width = 0x7f060140;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_container_elevation = 0x7f060141;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_container_height = 0x7f060142;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_focus_state_layer_opacity = 0x7f060143;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_hover_state_layer_opacity = 0x7f060144;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_icon_size = 0x7f060145;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_bar_pressed_state_layer_opacity = 0x7f060146;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_container_width = 0x7f060147;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_focus_state_layer_opacity = 0x7f060148;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_hover_state_layer_opacity = 0x7f060149;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_icon_size = 0x7f06014a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_modal_container_elevation = 0x7f06014b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_pressed_state_layer_opacity = 0x7f06014c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_drawer_standard_container_elevation = 0x7f06014d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_active_indicator_height = 0x7f06014e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_active_indicator_width = 0x7f06014f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_container_elevation = 0x7f060150;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_container_width = 0x7f060151;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_focus_state_layer_opacity = 0x7f060152;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_hover_state_layer_opacity = 0x7f060153;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_icon_size = 0x7f060154;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_navigation_rail_pressed_state_layer_opacity = 0x7f060155;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_autocomplete_menu_container_elevation = 0x7f060156;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_button_outline_width = 0x7f060158;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_container_elevation = 0x7f060159;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_disabled_outline_opacity = 0x7f06015a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_icon_size = 0x7f06015b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_card_outline_width = 0x7f06015c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_icon_button_unselected_outline_width = 0x7f06015d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_input_text_opacity = 0x7f06015e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_label_text_opacity = 0x7f06015f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_disabled_supporting_text_opacity = 0x7f060160;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_focus_outline_width = 0x7f060161;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_outlined_text_field_outline_width = 0x7f060162;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_focus_state_layer_opacity = 0x7f060163;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_hover_state_layer_opacity = 0x7f060164;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_indicator_height = 0x7f060165;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_active_pressed_state_layer_opacity = 0x7f060166;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_focus_state_layer_opacity = 0x7f060167;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_hover_state_layer_opacity = 0x7f060168;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_inactive_pressed_state_layer_opacity = 0x7f060169;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_primary_navigation_tab_with_icon_icon_size = 0x7f06016a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_active_indicator_track_space = 0x7f06016b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_stop_indicator_size = 0x7f06016c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_progress_indicator_track_thickness = 0x7f06016d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_disabled_selected_icon_opacity = 0x7f06016e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_disabled_unselected_icon_opacity = 0x7f06016f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_focus_state_layer_opacity = 0x7f060170;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_hover_state_layer_opacity = 0x7f060171;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_selected_pressed_state_layer_opacity = 0x7f060172;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_focus_state_layer_opacity = 0x7f060173;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_hover_state_layer_opacity = 0x7f060174;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_radio_button_unselected_pressed_state_layer_opacity = 0x7f060175;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_scrim_container_opacity = 0x7f060176;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_container_elevation = 0x7f060178;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_bar_container_height = 0x7f060179;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_container_elevation = 0x7f06017c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_search_view_full_screen_header_container_height = 0x7f06017e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_active_indicator_height = 0x7f06017f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_focus_state_layer_opacity = 0x7f060180;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_hover_state_layer_opacity = 0x7f060181;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_secondary_navigation_tab_pressed_state_layer_opacity = 0x7f060182;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_height = 0x7f060183;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_width = 0x7f060184;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_container_width = 0x7f060187;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_modal_container_elevation = 0x7f060188;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_sheet_side_docked_standard_container_elevation = 0x7f060189;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_height = 0x7f06018a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_leading_space = 0x7f06018b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_active_handle_width = 0x7f06018c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_active_track_opacity = 0x7f06018d;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_handle_opacity = 0x7f06018e;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_disabled_inactive_track_opacity = 0x7f06018f;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_inactive_track_height = 0x7f060190;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_slider_stop_indicator_size = 0x7f060191;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_snackbar_container_elevation = 0x7f060192;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_selected_handle_opacity = 0x7f060198;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_selected_icon_opacity = 0x7f060199;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_track_opacity = 0x7f06019a;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_unselected_handle_opacity = 0x7f06019b;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_disabled_unselected_icon_opacity = 0x7f06019c;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_track_height = 0x7f0601a0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_switch_track_width = 0x7f0601a1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_text_button_focus_state_layer_opacity = 0x7f0601a5;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_text_button_hover_state_layer_opacity = 0x7f0601a6;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_text_button_pressed_state_layer_opacity = 0x7f0601a7;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_input_time_input_field_focus_outline_width = 0x7f0601a8;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_container_elevation = 0x7f0601a9;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_focus_state_layer_opacity = 0x7f0601aa;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_hover_state_layer_opacity = 0x7f0601ab;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_outline_width = 0x7f0601ac;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_period_selector_pressed_state_layer_opacity = 0x7f0601ad;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_focus_state_layer_opacity = 0x7f0601ae;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_hover_state_layer_opacity = 0x7f0601af;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_time_picker_time_selector_pressed_state_layer_opacity = 0x7f0601b0;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_top_app_bar_large_container_height = 0x7f0601b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_top_app_bar_medium_container_height = 0x7f0601b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_top_app_bar_small_container_elevation = 0x7f0601b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_top_app_bar_small_container_height = 0x7f0601b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_comp_top_app_bar_small_on_scroll_container_elevation = 0x7f0601b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_datepicker_elevation = 0x7f0601b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_divider_heavy_thickness = 0x7f0601b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_bottom_padding = 0x7f0601b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_end_padding = 0x7f0601b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_icon_padding = 0x7f0601ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_start_padding = 0x7f0601bc;

        /* JADX INFO: Added by JADX */
        public static final int m3_extended_fab_top_padding = 0x7f0601bd;

        /* JADX INFO: Added by JADX */
        public static final int m3_fab_border_width = 0x7f0601be;

        /* JADX INFO: Added by JADX */
        public static final int m3_large_text_vertical_offset_adjustment = 0x7f0601c4;

        /* JADX INFO: Added by JADX */
        public static final int m3_menu_elevation = 0x7f0601c5;

        /* JADX INFO: Added by JADX */
        public static final int m3_nav_badge_with_text_vertical_offset = 0x7f0601c6;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_drawer_layout_corner_size = 0x7f0601c7;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_active_indicator_label_padding = 0x7f0601c8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_horizontal_padding = 0x7f0601c9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_icon_padding = 0x7f0601ca;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_bottom = 0x7f0601cb;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_end = 0x7f0601cc;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_start = 0x7f0601cd;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_shape_inset_top = 0x7f0601ce;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_item_vertical_padding = 0x7f0601cf;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_divider_horizontal_padding = 0x7f0601d0;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_menu_headline_horizontal_padding = 0x7f0601d1;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_default_width = 0x7f0601d2;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_elevation = 0x7f0601d3;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_height = 0x7f0601d5;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_margin_horizontal = 0x7f0601d6;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_active_indicator_width = 0x7f0601d7;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_min_height = 0x7f0601d8;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_bottom = 0x7f0601d9;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_item_padding_top = 0x7f0601db;

        /* JADX INFO: Added by JADX */
        public static final int m3_navigation_rail_label_padding_horizontal = 0x7f0601dd;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_default_alpha = 0x7f0601de;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_focused_alpha = 0x7f0601df;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_hovered_alpha = 0x7f0601e0;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_pressed_alpha = 0x7f0601e1;

        /* JADX INFO: Added by JADX */
        public static final int m3_ripple_selectable_pressed_alpha = 0x7f0601e2;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_elevation = 0x7f0601e3;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_height = 0x7f0601e4;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_margin_vertical = 0x7f0601e6;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_padding_start = 0x7f0601e8;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchbar_text_size = 0x7f0601ea;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchview_elevation = 0x7f0601ec;

        /* JADX INFO: Added by JADX */
        public static final int m3_searchview_height = 0x7f0601ed;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_modal_elevation = 0x7f0601ef;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_standard_elevation = 0x7f0601f0;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_width = 0x7f0601f1;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_color_hovered_alpha = 0x7f0601f2;

        /* JADX INFO: Added by JADX */
        public static final int m3_simple_item_color_selected_alpha = 0x7f0601f3;

        /* JADX INFO: Added by JADX */
        public static final int m3_snackbar_action_text_color_alpha = 0x7f0601f7;

        /* JADX INFO: Added by JADX */
        public static final int m3_snackbar_margin = 0x7f0601f8;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level0 = 0x7f0601f9;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level1 = 0x7f0601fa;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level2 = 0x7f0601fb;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level3 = 0x7f0601fc;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_elevation_level4 = 0x7f0601fd;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x1 = 0x7f0601ff;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x2 = 0x7f060200;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y1 = 0x7f060201;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y2 = 0x7f060202;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x1 = 0x7f060203;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x2 = 0x7f060204;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y1 = 0x7f060205;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y2 = 0x7f060206;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_x1 = 0x7f060213;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_x2 = 0x7f060214;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_y1 = 0x7f060215;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear_control_y2 = 0x7f060216;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x1 = 0x7f060217;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x2 = 0x7f060218;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y1 = 0x7f060219;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y2 = 0x7f06021a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_x1 = 0x7f06021b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_x2 = 0x7f06021c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_y1 = 0x7f06021d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_control_y2 = 0x7f06021e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x1 = 0x7f06021f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x2 = 0x7f060220;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y1 = 0x7f060221;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y2 = 0x7f060222;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_dragged_state_layer_opacity = 0x7f060223;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_focus_state_layer_opacity = 0x7f060224;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_hover_state_layer_opacity = 0x7f060225;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_state_pressed_state_layer_opacity = 0x7f060226;

        /* JADX INFO: Added by JADX */
        public static final int m3_timepicker_window_elevation = 0x7f060228;

        /* JADX INFO: Added by JADX */
        public static final int material_bottom_sheet_max_width = 0x7f06022a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_height = 0x7f06022b;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_padding = 0x7f06022c;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_width = 0x7f06022d;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face_margin_bottom = 0x7f06022e;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face_margin_top = 0x7f06022f;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_center_dot_radius = 0x7f060230;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_padding = 0x7f060231;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand_stroke_width = 0x7f060232;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_number_text_size = 0x7f060233;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_height = 0x7f060234;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_horizontal_gap = 0x7f060235;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_vertical_gap = 0x7f060236;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_width = 0x7f060237;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_size = 0x7f060238;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_inset = 0x7f060239;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_width = 0x7f06023a;

        /* JADX INFO: Added by JADX */
        public static final int material_divider_thickness = 0x7f06023b;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_disabled = 0x7f06023c;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_disabled_background = 0x7f06023d;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_high_type = 0x7f06023e;

        /* JADX INFO: Added by JADX */
        public static final int material_emphasis_medium = 0x7f06023f;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_1_3_padding_bottom = 0x7f060240;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_1_3_padding_top = 0x7f060241;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_2_0_padding_bottom = 0x7f060242;

        /* JADX INFO: Added by JADX */
        public static final int material_filled_edittext_font_2_0_padding_top = 0x7f060243;

        /* JADX INFO: Added by JADX */
        public static final int material_font_1_3_box_collapsed_padding_top = 0x7f060244;

        /* JADX INFO: Added by JADX */
        public static final int material_font_2_0_box_collapsed_padding_top = 0x7f060245;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_default_padding_top = 0x7f060246;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_font_1_3_padding_horizontal = 0x7f060247;

        /* JADX INFO: Added by JADX */
        public static final int material_helper_text_font_1_3_padding_top = 0x7f060248;

        /* JADX INFO: Added by JADX */
        public static final int material_input_text_to_prefix_suffix_padding = 0x7f060249;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_max_width = 0x7f06024b;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_min_width = 0x7f06024c;

        /* JADX INFO: Added by JADX */
        public static final int material_time_picker_minimum_screen_height = 0x7f06024d;

        /* JADX INFO: Added by JADX */
        public static final int material_time_picker_minimum_screen_width = 0x7f06024e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_bottom = 0x7f06024f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_end = 0x7f060250;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_start = 0x7f060251;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_background_inset_top = 0x7f060252;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_horizontal_edge_offset = 0x7f060254;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_long_text_horizontal_padding = 0x7f060255;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_size = 0x7f060256;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_text_horizontal_edge_offset = 0x7f060257;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_text_size = 0x7f060258;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_with_text_size = 0x7f06025b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_bottom_margin = 0x7f06025d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_margin = 0x7f06025e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f06025f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_fab_cradle_vertical_offset = 0x7f060260;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_bottomappbar_height = 0x7f060261;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_dialog_btn_min_width = 0x7f060263;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_disabled_elevation = 0x7f060264;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_disabled_z = 0x7f060265;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_elevation = 0x7f060266;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_focused_z = 0x7f060267;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_hovered_z = 0x7f060268;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_icon_padding = 0x7f06026a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_inset = 0x7f06026b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_max_width = 0x7f06026d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_bottom = 0x7f06026e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_left = 0x7f06026f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_right = 0x7f060270;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_padding_top = 0x7f060271;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_pressed_z = 0x7f060272;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_stroke_size = 0x7f060274;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_icon_padding = 0x7f060275;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_padding_left = 0x7f060276;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_text_btn_padding_right = 0x7f060277;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_z = 0x7f060279;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_confirm_button_min_width = 0x7f06027a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_height = 0x7f06027b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_action_padding = 0x7f06027c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_bottom_padding = 0x7f06027d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_content_padding = 0x7f06027e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_corner = 0x7f06027f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_height = 0x7f060280;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_horizontal_padding = 0x7f060281;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_today_stroke = 0x7f060282;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_vertical_padding = 0x7f060283;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_width = 0x7f060284;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week_height = 0x7f060285;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_dialog_background_inset = 0x7f060286;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_content_padding = 0x7f060287;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_content_padding_fullscreen = 0x7f060288;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_divider_thickness = 0x7f060289;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_height = 0x7f06028a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_height_fullscreen = 0x7f06028b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_selection_line_height = 0x7f06028c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_text_padding = 0x7f06028d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_toggle_margin_bottom = 0x7f06028e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_toggle_margin_top = 0x7f06028f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_landscape_header_width = 0x7f060290;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_maximum_default_fullscreen_minor_axis = 0x7f060291;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_horizontal_padding = 0x7f060292;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_vertical_padding = 0x7f060293;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_bottom_padding = 0x7f060294;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_height = 0x7f060295;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_navigation_top_padding = 0x7f060296;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_pre_l_text_clip_padding = 0x7f060297;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_baseline_to_top_fullscreen = 0x7f060298;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_baseline_to_top = 0x7f06029b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_text_input_padding_top = 0x7f06029c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_title_baseline_to_top = 0x7f06029d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_title_baseline_to_top_fullscreen = 0x7f06029e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_corner = 0x7f06029f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_height = 0x7f0602a0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_horizontal_padding = 0x7f0602a1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_vertical_padding = 0x7f0602a2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_width = 0x7f0602a3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_icon_margin = 0x7f0602a4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_icon_size = 0x7f0602a5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_dragged_z = 0x7f0602a7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_elevation = 0x7f0602a8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_pressed_translation_z = 0x7f0602aa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_text_size = 0x7f0602ab;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_elevation = 0x7f0602ac;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_offset = 0x7f0602ad;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_padding = 0x7f0602ae;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_bottom_padding = 0x7f0602af;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_disabled_elevation = 0x7f0602b0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_disabled_translation_z = 0x7f0602b1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_elevation = 0x7f0602b2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_end_padding = 0x7f0602b3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_end_padding_icon = 0x7f0602b4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_icon_size = 0x7f0602b5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_icon_text_spacing = 0x7f0602b6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_min_height = 0x7f0602b7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_min_width = 0x7f0602b8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_start_padding = 0x7f0602b9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_start_padding_icon = 0x7f0602ba;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_top_padding = 0x7f0602bb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_base = 0x7f0602bc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_hovered_focused = 0x7f0602bd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_extended_fab_translation_z_pressed = 0x7f0602be;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_elevation = 0x7f0602bf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_translation_z_hovered_focused = 0x7f0602c1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fab_translation_z_pressed = 0x7f0602c2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_default_alpha = 0x7f0602c3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_focused_alpha = 0x7f0602c4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_hovered_alpha = 0x7f0602c5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_high_ripple_pressed_alpha = 0x7f0602c6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_default_alpha = 0x7f0602c7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_focused_alpha = 0x7f0602c8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_hovered_alpha = 0x7f0602c9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_low_ripple_pressed_alpha = 0x7f0602ca;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_min_touch_target_size = 0x7f0602cb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_default_icon_size = 0x7f0602cc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_default_margin = 0x7f0602cd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_horizontal_padding = 0x7f0602cf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_padding = 0x7f0602d0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_icon_size = 0x7f0602d1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_shape_horizontal_margin = 0x7f0602d2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_item_shape_vertical_margin = 0x7f0602d3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_active_text_size = 0x7f0602d4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_default_width = 0x7f0602d6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_elevation = 0x7f0602d7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_icon_margin = 0x7f0602d8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_icon_size = 0x7f0602d9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_margin = 0x7f0602da;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_text_bottom_margin = 0x7f0602db;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_text_size = 0x7f0602dc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_inset_medium = 0x7f0602df;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_size_medium = 0x7f0602e4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_circular_track_thickness_medium = 0x7f0602e7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_progress_track_thickness = 0x7f0602ea;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_large_component = 0x7f0602eb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_medium_component = 0x7f0602ec;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_shape_corner_size_small_component = 0x7f0602ed;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_halo_radius = 0x7f0602ee;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_thumb_elevation = 0x7f0602f2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_thumb_radius = 0x7f0602f3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_tick_radius = 0x7f0602f5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_slider_track_height = 0x7f0602f6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_action_text_color_alpha = 0x7f0602f9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_background_corner_radius = 0x7f0602fa;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_background_overlay_color_alpha = 0x7f0602fb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_margin = 0x7f0602fc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_message_margin_horizontal = 0x7f0602fd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_snackbar_padding_horizontal = 0x7f0602fe;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_text_padding = 0x7f0602ff;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_icon_size = 0x7f060301;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_size = 0x7f060302;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_height = 0x7f060303;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_width = 0x7f060304;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_corner_radius_small = 0x7f060306;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_label_cutout_padding = 0x7f060307;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_stroke_width_default = 0x7f060308;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_box_stroke_width_focused = 0x7f060309;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_counter_margin_start = 0x7f06030a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_end_icon_margin_start = 0x7f06030b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_textinput_start_icon_margin_end = 0x7f06030d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_toolbar_default_height = 0x7f06030e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_minHeight = 0x7f060311;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_minWidth = 0x7f060312;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tooltip_padding = 0x7f060313;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 0x7f060315;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 0x7f060316;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 0x7f060317;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 0x7f060318;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 0x7f060319;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 0x7f06031a;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 0x7f06031b;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 0x7f06031c;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 0x7f06031d;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 0x7f06031e;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 0x7f06031f;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 0x7f060320;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 0x7f060321;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 0x7f060322;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 0x7f060323;

        /* JADX INFO: Added by JADX */
        public static final int sliding_pane_detail_pane_width = 0x7f060324;

        /* JADX INFO: Added by JADX */
        public static final int space_l = 0x7f060325;

        /* JADX INFO: Added by JADX */
        public static final int space_m = 0x7f060326;

        /* JADX INFO: Added by JADX */
        public static final int space_s = 0x7f060327;

        /* JADX INFO: Added by JADX */
        public static final int space_xl = 0x7f060328;

        /* JADX INFO: Added by JADX */
        public static final int space_xs = 0x7f060329;

        /* JADX INFO: Added by JADX */
        public static final int space_xxl = 0x7f06032a;

        /* JADX INFO: Added by JADX */
        public static final int stroke_card = 0x7f06032b;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_corner_radius = 0x7f06032c;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_horizontal_padding = 0x7f06032d;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_margin = 0x7f06032e;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 0x7f06032f;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_precise_anchor_threshold = 0x7f060330;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_vertical_padding = 0x7f060331;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_non_touch = 0x7f060332;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_y_offset_touch = 0x7f060333;

        /* JADX INFO: Added by JADX */
        public static final int touch_floor = 0x7f060334;
    }

    public static final class drawable {

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__0_res_0x7f070000 = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__1_res_0x7f070001 = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int _avd_hide_password__2_res_0x7f070002 = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__0_res_0x7f070003 = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__1_res_0x7f070004 = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int _avd_show_password__2_res_0x7f070005 = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__0_res_0x7f070006 = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__1_res_0x7f070007 = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_hide_password__2_res_0x7f070008 = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__0_res_0x7f070009 = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__1_res_0x7f07000a = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int _m3_avd_show_password__2_res_0x7f07000b = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__0_res_0x7f07000c = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__1_res_0x7f07000d = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_checked_unchecked__2_res_0x7f07000e = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_indeterminate__0_res_0x7f07000f = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__0_res_0x7f070010 = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__1_res_0x7f070011 = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_checked_unchecked__2_res_0x7f070012 = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_checked__0_res_0x7f070013 = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__0_res_0x7f070014 = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__1_res_0x7f070015 = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_indeterminate_unchecked__2_res_0x7f070016 = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__0_res_0x7f070017 = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__1_res_0x7f070018 = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_checked__2_res_0x7f070019 = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__0_res_0x7f07001a = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__1_res_0x7f07001b = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_icon_unchecked_indeterminate__2_res_0x7f07001c = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__0_res_0x7f07001d = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__1_res_0x7f07001e = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_checkbox_button_unchecked_checked__2_res_0x7f07001f = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_pressed__0_res_0x7f070020 = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_unchecked__0_res_0x7f070021 = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_checked_unchecked__1_res_0x7f070022 = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_pressed_checked__0_res_0x7f070023 = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_pressed_unchecked__0_res_0x7f070024 = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_checked__0_res_0x7f070025 = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_checked__1_res_0x7f070026 = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int _mtrl_switch_thumb_unchecked_pressed__0_res_0x7f070027 = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_item_background_material = 0x7f070029;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_borderless_material = 0x7f07002a;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_check_material_anim = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_colored_material = 0x7f07002f;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_default_mtrl_shape = 0x7f070030;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int abc_btn_radio_material_anim = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_internal_bg = 0x7f070037;

        /* JADX INFO: Added by JADX */
        public static final int abc_cab_background_top_material = 0x7f070038;

        /* JADX INFO: Added by JADX */
        public static final int abc_control_background_material = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_material_background = 0x7f07003b;

        /* JADX INFO: Added by JADX */
        public static final int abc_edit_text_material = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_ab_back_material = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_clear_material = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_go_search_api_material = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f070042;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_search_api_material = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int abc_ic_voice_search_api_material = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_dark = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int abc_item_background_holo_light = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_divider_material = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f070052;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 0x7f070053;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_dark = 0x7f070056;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_selector_holo_light = 0x7f070057;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_indicator_material = 0x7f07005a;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_material = 0x7f07005b;

        /* JADX INFO: Added by JADX */
        public static final int abc_ratingbar_small_material = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_thumb_material = 0x7f070062;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_tick_mark_material = 0x7f070063;

        /* JADX INFO: Added by JADX */
        public static final int abc_seekbar_track_material = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int abc_spinner_textfield_background_material = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_black_48dp = 0x7f070067;

        /* JADX INFO: Added by JADX */
        public static final int abc_star_half_black_48dp = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int abc_switch_thumb_material = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int abc_tab_indicator_material = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int abc_text_cursor_material = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int abc_textfield_search_material = 0x7f070075;

        /* JADX INFO: Added by JADX */
        public static final int abc_vector_test = 0x7f070076;

        /* JADX INFO: Added by JADX */
        public static final int avd_hide_password = 0x7f070077;

        /* JADX INFO: Added by JADX */
        public static final int avd_show_password = 0x7f070078;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl = 0x7f070079;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 0x7f07007a;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 0x7f07007b;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 0x7f07007c;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_mtrl = 0x7f07007d;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 0x7f07007e;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_mtrl = 0x7f07007f;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 0x7f070080;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark = 0x7f070082;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_focused = 0x7f070083;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_dark_normal = 0x7f070084;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_disabled = 0x7f070086;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light = 0x7f070087;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_focused = 0x7f070088;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_icon_light_normal = 0x7f070089;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark = 0x7f07008b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_focused = 0x7f07008c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_dark_normal = 0x7f07008d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_disabled = 0x7f07008f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light = 0x7f070090;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_focused = 0x7f070091;

        /* JADX INFO: Added by JADX */
        public static final int common_google_signin_btn_text_light_normal = 0x7f070092;

        /* JADX INFO: Added by JADX */
        public static final int design_fab_background = 0x7f070094;

        /* JADX INFO: Added by JADX */
        public static final int design_ic_visibility = 0x7f070095;

        /* JADX INFO: Added by JADX */
        public static final int design_ic_visibility_off = 0x7f070096;

        /* JADX INFO: Added by JADX */
        public static final int design_password_eye = 0x7f070097;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_background = 0x7f070098;

        /* JADX INFO: Added by JADX */
        public static final int ic_arrow_back_black_24 = 0x7f07009b;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 0x7f0700a0;

        /* JADX INFO: Added by JADX */
        public static final int ic_clock_black_24dp = 0x7f0700a3;

        /* JADX INFO: Added by JADX */
        public static final int ic_keyboard_black_24dp = 0x7f0700a4;

        /* JADX INFO: Added by JADX */
        public static final int ic_m3_chip_checked_circle = 0x7f0700a6;

        /* JADX INFO: Added by JADX */
        public static final int ic_m3_chip_close = 0x7f0700a7;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_checked_circle = 0x7f0700a8;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_checked_black = 0x7f0700a9;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_checked_circle = 0x7f0700aa;

        /* JADX INFO: Added by JADX */
        public static final int ic_mtrl_chip_close_circle = 0x7f0700ab;

        /* JADX INFO: Added by JADX */
        public static final int ic_nav_furnace = 0x7f0700ac;

        /* JADX INFO: Added by JADX */
        public static final int ic_nav_index = 0x7f0700ad;

        /* JADX INFO: Added by JADX */
        public static final int ic_nav_log = 0x7f0700ae;

        /* JADX INFO: Added by JADX */
        public static final int ic_nav_weigh = 0x7f0700af;

        /* JADX INFO: Added by JADX */
        public static final int ic_search_black_24 = 0x7f0700b0;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate_static = 0x7f0700b1;

        /* JADX INFO: Added by JADX */
        public static final int m3_avd_hide_password = 0x7f0700b2;

        /* JADX INFO: Added by JADX */
        public static final int m3_avd_show_password = 0x7f0700b3;

        /* JADX INFO: Added by JADX */
        public static final int m3_bottom_sheet_drag_handle = 0x7f0700b4;

        /* JADX INFO: Added by JADX */
        public static final int m3_password_eye = 0x7f0700b5;

        /* JADX INFO: Added by JADX */
        public static final int m3_popupmenu_background_overlay = 0x7f0700b6;

        /* JADX INFO: Added by JADX */
        public static final int m3_radiobutton_ripple = 0x7f0700b7;

        /* JADX INFO: Added by JADX */
        public static final int m3_selection_control_ripple = 0x7f0700b8;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_background = 0x7f0700b9;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_line_indicator = 0x7f0700ba;

        /* JADX INFO: Added by JADX */
        public static final int m3_tabs_rounded_line_indicator = 0x7f0700bb;

        /* JADX INFO: Added by JADX */
        public static final int material_cursor_drawable = 0x7f0700bd;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_calendar_black_24dp = 0x7f0700be;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_clear_black_24dp = 0x7f0700bf;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_edit_black_24dp = 0x7f0700c0;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_left_black_24dp = 0x7f0700c1;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_next_black_24dp = 0x7f0700c2;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_previous_black_24dp = 0x7f0700c3;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_keyboard_arrow_right_black_24dp = 0x7f0700c4;

        /* JADX INFO: Added by JADX */
        public static final int material_ic_menu_arrow_down_black_24dp = 0x7f0700c5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button = 0x7f0700c8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_checked_unchecked = 0x7f0700c9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon = 0x7f0700ca;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_checked_indeterminate = 0x7f0700cb;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_checked_unchecked = 0x7f0700cc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_indeterminate_checked = 0x7f0700cd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_indeterminate_unchecked = 0x7f0700ce;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_unchecked_checked = 0x7f0700cf;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_unchecked_indeterminate = 0x7f0700d0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_unchecked_checked = 0x7f0700d1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_dialog_background = 0x7f0700d2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_dropdown_arrow = 0x7f0700d3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_arrow_drop_down = 0x7f0700d4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_arrow_drop_up = 0x7f0700d5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_cancel = 0x7f0700d6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_check_mark = 0x7f0700d7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_checkbox_checked = 0x7f0700d8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_checkbox_unchecked = 0x7f0700d9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_error = 0x7f0700da;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_ic_indeterminate = 0x7f0700db;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_bar_item_background = 0x7f0700dc;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_background = 0x7f0700dd;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_popupmenu_background_overlay = 0x7f0700de;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb = 0x7f0700df;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked = 0x7f0700e0;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked_pressed = 0x7f0700e1;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_checked_unchecked = 0x7f0700e2;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed = 0x7f0700e3;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_checked = 0x7f0700e4;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_unchecked = 0x7f0700e5;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked = 0x7f0700e6;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked_checked = 0x7f0700e7;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_unchecked_pressed = 0x7f0700e8;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track = 0x7f0700e9;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration = 0x7f0700ea;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tabs_default_indicator = 0x7f0700eb;

        /* JADX INFO: Added by JADX */
        public static final int navigation_empty_icon = 0x7f0700ec;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 0x7f0700ed;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 0x7f0700ee;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 0x7f0700ef;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 0x7f0700f4;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 0x7f0700f5;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 0x7f0700f6;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 0x7f0700f7;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 0x7f0700f8;

        /* JADX INFO: Added by JADX */
        public static final int shape_kept_marker = 0x7f0700fa;

        /* JADX INFO: Added by JADX */
        public static final int test_level_drawable = 0x7f0700fb;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_dark = 0x7f0700fc;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_frame_light = 0x7f0700fd;
    }

    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int ALT = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int BOTTOM_END = 0x7f080001;

        /* JADX INFO: Added by JADX */
        public static final int BOTTOM_START = 0x7f080002;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 0x7f080003;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 0x7f080004;

        /* JADX INFO: Added by JADX */
        public static final int META = 0x7f080005;

        /* JADX INFO: Added by JADX */
        public static final int NO_DEBUG = 0x7f080006;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 0x7f080007;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_ALL = 0x7f080008;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PATH = 0x7f080009;

        /* JADX INFO: Added by JADX */
        public static final int SHOW_PROGRESS = 0x7f08000a;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 0x7f08000b;

        /* JADX INFO: Added by JADX */
        public static final int TOP_END = 0x7f08000c;

        /* JADX INFO: Added by JADX */
        public static final int TOP_START = 0x7f08000d;

        /* JADX INFO: Added by JADX */
        public static final int above = 0x7f08000e;

        /* JADX INFO: Added by JADX */
        public static final int accelerate = 0x7f08000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f080010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f080011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f080012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f080013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f080014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f080015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f080016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f080017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f080018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f080019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f08001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f08001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f08001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f08001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f08001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f08001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f080020;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f080021;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f080022;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f080023;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f080024;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f080025;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f080026;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f080027;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f080028;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f080029;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f08002a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f08002b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f08002c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f08002d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f08002e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f08002f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f080030;

        /* JADX INFO: Added by JADX */
        public static final int actionDown = 0x7f080031;

        /* JADX INFO: Added by JADX */
        public static final int actionDownUp = 0x7f080032;

        /* JADX INFO: Added by JADX */
        public static final int actionFurnaceToIndex = 0x7f080033;

        /* JADX INFO: Added by JADX */
        public static final int actionFurnaceToSheet = 0x7f080034;

        /* JADX INFO: Added by JADX */
        public static final int actionFurnaceToWeigh = 0x7f080035;

        /* JADX INFO: Added by JADX */
        public static final int actionIndexToSheet = 0x7f080036;

        /* JADX INFO: Added by JADX */
        public static final int actionLogToSheet = 0x7f080037;

        /* JADX INFO: Added by JADX */
        public static final int actionUp = 0x7f080038;

        /* JADX INFO: Added by JADX */
        public static final int action_bar = 0x7f080039;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_activity_content = 0x7f08003a;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_container = 0x7f08003b;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_root = 0x7f08003c;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_spinner = 0x7f08003d;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_subtitle = 0x7f08003e;

        /* JADX INFO: Added by JADX */
        public static final int action_bar_title = 0x7f08003f;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f080040;

        /* JADX INFO: Added by JADX */
        public static final int action_context_bar = 0x7f080041;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f080042;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f080043;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_divider = 0x7f080044;

        /* JADX INFO: Added by JADX */
        public static final int action_menu_presenter = 0x7f080045;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar = 0x7f080046;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_bar_stub = 0x7f080047;

        /* JADX INFO: Added by JADX */
        public static final int action_mode_close_button = 0x7f080048;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f080049;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f08004a;

        /* JADX INFO: Added by JADX */
        public static final int activity_chooser_view_content = 0x7f08004b;

        /* JADX INFO: Added by JADX */
        public static final int add = 0x7f08004c;

        /* JADX INFO: Added by JADX */
        public static final int adjust_height = 0x7f08004d;

        /* JADX INFO: Added by JADX */
        public static final int adjust_width = 0x7f08004e;

        /* JADX INFO: Added by JADX */
        public static final int alertTitle = 0x7f08004f;

        /* JADX INFO: Added by JADX */
        public static final int aligned = 0x7f080050;

        /* JADX INFO: Added by JADX */
        public static final int all = 0x7f080051;

        /* JADX INFO: Added by JADX */
        public static final int allStates = 0x7f080052;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f080053;

        /* JADX INFO: Added by JADX */
        public static final int androidx_window_activity_scope = 0x7f080054;

        /* JADX INFO: Added by JADX */
        public static final int animateToEnd = 0x7f080055;

        /* JADX INFO: Added by JADX */
        public static final int animateToStart = 0x7f080056;

        /* JADX INFO: Added by JADX */
        public static final int antiClockwise = 0x7f080057;

        /* JADX INFO: Added by JADX */
        public static final int anticipate = 0x7f080058;

        /* JADX INFO: Added by JADX */
        public static final int appBarLayout = 0x7f080059;

        /* JADX INFO: Added by JADX */
        public static final int arc = 0x7f08005a;

        /* JADX INFO: Added by JADX */
        public static final int asConfigured = 0x7f08005b;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f08005c;

        /* JADX INFO: Added by JADX */
        public static final int auto = 0x7f08005d;

        /* JADX INFO: Added by JADX */
        public static final int autoComplete = 0x7f08005e;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToEnd = 0x7f08005f;

        /* JADX INFO: Added by JADX */
        public static final int autoCompleteToStart = 0x7f080060;

        /* JADX INFO: Added by JADX */
        public static final int axisRelative = 0x7f080061;

        /* JADX INFO: Added by JADX */
        public static final int badgeGrid = 0x7f080062;

        /* JADX INFO: Added by JADX */
        public static final int badgeName = 0x7f080063;

        /* JADX INFO: Added by JADX */
        public static final int badgeRequirement = 0x7f080064;

        /* JADX INFO: Added by JADX */
        public static final int badgeRing = 0x7f080065;

        /* JADX INFO: Added by JADX */
        public static final int badgeRoot = 0x7f080066;

        /* JADX INFO: Added by JADX */
        public static final int badgeTally = 0x7f080067;

        /* JADX INFO: Added by JADX */
        public static final int bandKeptMarker = 0x7f080068;

        /* JADX INFO: Added by JADX */
        public static final int bandMark = 0x7f080069;

        /* JADX INFO: Added by JADX */
        public static final int bandName = 0x7f08006a;

        /* JADX INFO: Added by JADX */
        public static final int bandRoot = 0x7f08006b;

        /* JADX INFO: Added by JADX */
        public static final int bandTag = 0x7f08006c;

        /* JADX INFO: Added by JADX */
        public static final int bandValue = 0x7f08006d;

        /* JADX INFO: Added by JADX */
        public static final int barrier = 0x7f08006e;

        /* JADX INFO: Added by JADX */
        public static final int baseline = 0x7f08006f;

        /* JADX INFO: Added by JADX */
        public static final int beamView = 0x7f080070;

        /* JADX INFO: Added by JADX */
        public static final int beginOnFirstDraw = 0x7f080071;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 0x7f080072;

        /* JADX INFO: Added by JADX */
        public static final int below = 0x7f080073;

        /* JADX INFO: Added by JADX */
        public static final int bestChoice = 0x7f080074;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f080075;

        /* JADX INFO: Added by JADX */
        public static final int bottom = 0x7f080076;

        /* JADX INFO: Added by JADX */
        public static final int bottomNav = 0x7f080077;

        /* JADX INFO: Added by JADX */
        public static final int bounce = 0x7f080078;

        /* JADX INFO: Added by JADX */
        public static final int bounceBoth = 0x7f080079;

        /* JADX INFO: Added by JADX */
        public static final int bounceEnd = 0x7f08007a;

        /* JADX INFO: Added by JADX */
        public static final int bounceStart = 0x7f08007b;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_header_text = 0x7f08007c;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_icon = 0x7f08007d;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_item_text = 0x7f08007e;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_items = 0x7f08007f;

        /* JADX INFO: Added by JADX */
        public static final int browser_actions_menu_view = 0x7f080080;

        /* JADX INFO: Added by JADX */
        public static final int btn_retry = 0x7f080081;

        /* JADX INFO: Added by JADX */
        public static final int buttonPanel = 0x7f080082;

        /* JADX INFO: Added by JADX */
        public static final int cache_measures = 0x7f080083;

        /* JADX INFO: Added by JADX */
        public static final int callMeasure = 0x7f080084;

        /* JADX INFO: Added by JADX */
        public static final int cancel_button = 0x7f080085;

        /* JADX INFO: Added by JADX */
        public static final int carryVelocity = 0x7f080086;

        /* JADX INFO: Added by JADX */
        public static final int center = 0x7f080087;

        /* JADX INFO: Added by JADX */
        public static final int centerCrop = 0x7f080088;

        /* JADX INFO: Added by JADX */
        public static final int centerInside = 0x7f080089;

        /* JADX INFO: Added by JADX */
        public static final int center_horizontal = 0x7f08008a;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 0x7f08008b;

        /* JADX INFO: Added by JADX */
        public static final int chain = 0x7f08008c;

        /* JADX INFO: Added by JADX */
        public static final int chain2 = 0x7f08008d;

        /* JADX INFO: Added by JADX */
        public static final int chains = 0x7f08008e;

        /* JADX INFO: Added by JADX */
        public static final int checkbox = 0x7f08008f;

        /* JADX INFO: Added by JADX */
        public static final int checked = 0x7f080090;

        /* JADX INFO: Added by JADX */
        public static final int choiceMark = 0x7f080091;

        /* JADX INFO: Added by JADX */
        public static final int choiceName = 0x7f080092;

        /* JADX INFO: Added by JADX */
        public static final int choiceRoot = 0x7f080093;

        /* JADX INFO: Added by JADX */
        public static final int choiceValue = 0x7f080094;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f080095;

        /* JADX INFO: Added by JADX */
        public static final int circle_center = 0x7f080096;

        /* JADX INFO: Added by JADX */
        public static final int clearPansButton = 0x7f080097;

        /* JADX INFO: Added by JADX */
        public static final int clear_text = 0x7f080098;

        /* JADX INFO: Added by JADX */
        public static final int clip_horizontal = 0x7f080099;

        /* JADX INFO: Added by JADX */
        public static final int clip_vertical = 0x7f08009a;

        /* JADX INFO: Added by JADX */
        public static final int clockwise = 0x7f08009b;

        /* JADX INFO: Added by JADX */
        public static final int closest = 0x7f08009c;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 0x7f08009d;

        /* JADX INFO: Added by JADX */
        public static final int compareBand = 0x7f08009e;

        /* JADX INFO: Added by JADX */
        public static final int compareHalfHour = 0x7f08009f;

        /* JADX INFO: Added by JADX */
        public static final int compareLabel = 0x7f0800a0;

        /* JADX INFO: Added by JADX */
        public static final int compareLeft = 0x7f0800a1;

        /* JADX INFO: Added by JADX */
        public static final int compareMover = 0x7f0800a2;

        /* JADX INFO: Added by JADX */
        public static final int compareRight = 0x7f0800a3;

        /* JADX INFO: Added by JADX */
        public static final int compareScale = 0x7f0800a4;

        /* JADX INFO: Added by JADX */
        public static final int completedCheck = 0x7f0800a5;

        /* JADX INFO: Added by JADX */
        public static final int compress = 0x7f0800a6;

        /* JADX INFO: Added by JADX */
        public static final int confirm_button = 0x7f0800a7;

        /* JADX INFO: Added by JADX */
        public static final int constraint = 0x7f0800a8;

        /* JADX INFO: Added by JADX */
        public static final int container = 0x7f0800a9;

        /* JADX INFO: Added by JADX */
        public static final int content = 0x7f0800aa;

        /* JADX INFO: Added by JADX */
        public static final int contentPanel = 0x7f0800ab;

        /* JADX INFO: Added by JADX */
        public static final int contiguous = 0x7f0800ac;

        /* JADX INFO: Added by JADX */
        public static final int continuousVelocity = 0x7f0800ad;

        /* JADX INFO: Added by JADX */
        public static final int coordinator = 0x7f0800ae;

        /* JADX INFO: Added by JADX */
        public static final int copyLineButton = 0x7f0800af;

        /* JADX INFO: Added by JADX */
        public static final int cos = 0x7f0800b0;

        /* JADX INFO: Added by JADX */
        public static final int counterclockwise = 0x7f0800b1;

        /* JADX INFO: Added by JADX */
        public static final int cradle = 0x7f0800b2;

        /* JADX INFO: Added by JADX */
        public static final int currentState = 0x7f0800b3;

        /* JADX INFO: Added by JADX */
        public static final int custom = 0x7f0800b4;

        /* JADX INFO: Added by JADX */
        public static final int customPanel = 0x7f0800b5;

        /* JADX INFO: Added by JADX */
        public static final int cut = 0x7f0800b6;

        /* JADX INFO: Added by JADX */
        public static final int dark = 0x7f0800b7;

        /* JADX INFO: Added by JADX */
        public static final int date_picker_actions = 0x7f0800b8;

        /* JADX INFO: Added by JADX */
        public static final int decelerate = 0x7f0800b9;

        /* JADX INFO: Added by JADX */
        public static final int decelerateAndComplete = 0x7f0800ba;

        /* JADX INFO: Added by JADX */
        public static final int decor_content_parent = 0x7f0800bb;

        /* JADX INFO: Added by JADX */
        public static final int default_activity_button = 0x7f0800bc;

        /* JADX INFO: Added by JADX */
        public static final int deltaRelative = 0x7f0800bd;

        /* JADX INFO: Added by JADX */
        public static final int dependency_ordering = 0x7f0800be;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet = 0x7f0800bf;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area = 0x7f0800c0;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area_stub = 0x7f0800c1;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_text = 0x7f0800c2;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_view = 0x7f0800c3;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f0800c4;

        /* JADX INFO: Added by JADX */
        public static final int dimensions = 0x7f0800c5;

        /* JADX INFO: Added by JADX */
        public static final int direct = 0x7f0800c6;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 0x7f0800c7;

        /* JADX INFO: Added by JADX */
        public static final int disableIntraAutoTransition = 0x7f0800c8;

        /* JADX INFO: Added by JADX */
        public static final int disablePostScroll = 0x7f0800c9;

        /* JADX INFO: Added by JADX */
        public static final int disableScroll = 0x7f0800ca;

        /* JADX INFO: Added by JADX */
        public static final int disjoint = 0x7f0800cb;

        /* JADX INFO: Added by JADX */
        public static final int dragAnticlockwise = 0x7f0800cc;

        /* JADX INFO: Added by JADX */
        public static final int dragClockwise = 0x7f0800cd;

        /* JADX INFO: Added by JADX */
        public static final int dragDown = 0x7f0800ce;

        /* JADX INFO: Added by JADX */
        public static final int dragEnd = 0x7f0800cf;

        /* JADX INFO: Added by JADX */
        public static final int dragLeft = 0x7f0800d0;

        /* JADX INFO: Added by JADX */
        public static final int dragRight = 0x7f0800d1;

        /* JADX INFO: Added by JADX */
        public static final int dragStart = 0x7f0800d2;

        /* JADX INFO: Added by JADX */
        public static final int dragUp = 0x7f0800d3;

        /* JADX INFO: Added by JADX */
        public static final int dropdown_menu = 0x7f0800d4;

        /* JADX INFO: Added by JADX */
        public static final int easeIn = 0x7f0800d5;

        /* JADX INFO: Added by JADX */
        public static final int easeInOut = 0x7f0800d6;

        /* JADX INFO: Added by JADX */
        public static final int easeOut = 0x7f0800d7;

        /* JADX INFO: Added by JADX */
        public static final int east = 0x7f0800d8;

        /* JADX INFO: Added by JADX */
        public static final int edge = 0x7f0800d9;

        /* JADX INFO: Added by JADX */
        public static final int edit_query = 0x7f0800da;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f0800db;

        /* JADX INFO: Added by JADX */
        public static final int effortSheetFragment = 0x7f0800dc;

        /* JADX INFO: Added by JADX */
        public static final int elastic = 0x7f0800dd;

        /* JADX INFO: Added by JADX */
        public static final int embed = 0x7f0800de;

        /* JADX INFO: Added by JADX */
        public static final int emptyDial = 0x7f0800df;

        /* JADX INFO: Added by JADX */
        public static final int emptyGroup = 0x7f0800e0;

        /* JADX INFO: Added by JADX */
        public static final int end = 0x7f0800e1;

        /* JADX INFO: Added by JADX */
        public static final int endToStart = 0x7f0800e2;

        /* JADX INFO: Added by JADX */
        public static final int enterAlways = 0x7f0800e3;

        /* JADX INFO: Added by JADX */
        public static final int enterAlwaysCollapsed = 0x7f0800e4;

        /* JADX INFO: Added by JADX */
        public static final int error_container = 0x7f0800e5;

        /* JADX INFO: Added by JADX */
        public static final int error_message = 0x7f0800e6;

        /* JADX INFO: Added by JADX */
        public static final int error_title = 0x7f0800e7;

        /* JADX INFO: Added by JADX */
        public static final int escape = 0x7f0800e8;

        /* JADX INFO: Added by JADX */
        public static final int exitUntilCollapsed = 0x7f0800e9;

        /* JADX INFO: Added by JADX */
        public static final int expand_activities_button = 0x7f0800ea;

        /* JADX INFO: Added by JADX */
        public static final int expanded_menu = 0x7f0800eb;

        /* JADX INFO: Added by JADX */
        public static final int fade = 0x7f0800ec;

        /* JADX INFO: Added by JADX */
        public static final int fanAnotherButton = 0x7f0800ed;

        /* JADX INFO: Added by JADX */
        public static final int fill = 0x7f0800ee;

        /* JADX INFO: Added by JADX */
        public static final int fill_horizontal = 0x7f0800ef;

        /* JADX INFO: Added by JADX */
        public static final int fill_vertical = 0x7f0800f0;

        /* JADX INFO: Added by JADX */
        public static final int filled = 0x7f0800f1;

        /* JADX INFO: Added by JADX */
        public static final int fitCenter = 0x7f0800f2;

        /* JADX INFO: Added by JADX */
        public static final int fitEnd = 0x7f0800f3;

        /* JADX INFO: Added by JADX */
        public static final int fitStart = 0x7f0800f4;

        /* JADX INFO: Added by JADX */
        public static final int fitToContents = 0x7f0800f5;

        /* JADX INFO: Added by JADX */
        public static final int fitXY = 0x7f0800f6;

        /* JADX INFO: Added by JADX */
        public static final int fixed = 0x7f0800f7;

        /* JADX INFO: Added by JADX */
        public static final int flip = 0x7f0800f8;

        /* JADX INFO: Added by JADX */
        public static final int floating = 0x7f0800f9;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f0800fa;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 0x7f0800fb;

        /* JADX INFO: Added by JADX */
        public static final int frost = 0x7f0800fc;

        /* JADX INFO: Added by JADX */
        public static final int fullscreen_header = 0x7f0800fd;

        /* JADX INFO: Added by JADX */
        public static final int furnaceFloorFragment = 0x7f0800fe;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view = 0x7f0800ff;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view_holder = 0x7f080100;

        /* JADX INFO: Added by JADX */
        public static final int gone = 0x7f080101;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f080102;

        /* JADX INFO: Added by JADX */
        public static final int graph_wrap = 0x7f080103;

        /* JADX INFO: Added by JADX */
        public static final int group_divider = 0x7f080104;

        /* JADX INFO: Added by JADX */
        public static final int grouping = 0x7f080105;

        /* JADX INFO: Added by JADX */
        public static final int groups = 0x7f080106;

        /* JADX INFO: Added by JADX */
        public static final int header_title = 0x7f080107;

        /* JADX INFO: Added by JADX */
        public static final int heroBand = 0x7f080108;

        /* JADX INFO: Added by JADX */
        public static final int heroBandLabel = 0x7f080109;

        /* JADX INFO: Added by JADX */
        public static final int heroCost = 0x7f08010a;

        /* JADX INFO: Added by JADX */
        public static final int heroDial = 0x7f08010b;

        /* JADX INFO: Added by JADX */
        public static final int heroFigure = 0x7f08010c;

        /* JADX INFO: Added by JADX */
        public static final int heroMark = 0x7f08010d;

        /* JADX INFO: Added by JADX */
        public static final int heroMover = 0x7f08010e;

        /* JADX INFO: Added by JADX */
        public static final int heroName = 0x7f08010f;

        /* JADX INFO: Added by JADX */
        public static final int heroPanel = 0x7f080110;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f080111;

        /* JADX INFO: Added by JADX */
        public static final int hideable = 0x7f080112;

        /* JADX INFO: Added by JADX */
        public static final int home = 0x7f080113;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 0x7f080114;

        /* JADX INFO: Added by JADX */
        public static final int honorRequest = 0x7f080115;

        /* JADX INFO: Added by JADX */
        public static final int horizontal = 0x7f080116;

        /* JADX INFO: Added by JADX */
        public static final int horizontal_only = 0x7f080117;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f080118;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f080119;

        /* JADX INFO: Added by JADX */
        public static final int icon_only = 0x7f08011a;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 0x7f08011b;

        /* JADX INFO: Added by JADX */
        public static final int ignore = 0x7f08011c;

        /* JADX INFO: Added by JADX */
        public static final int ignoreRequest = 0x7f08011d;

        /* JADX INFO: Added by JADX */
        public static final int image = 0x7f08011e;

        /* JADX INFO: Added by JADX */
        public static final int immediateStop = 0x7f08011f;

        /* JADX INFO: Added by JADX */
        public static final int included = 0x7f080120;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f080121;

        /* JADX INFO: Added by JADX */
        public static final int indexCount = 0x7f080122;

        /* JADX INFO: Added by JADX */
        public static final int indexList = 0x7f080123;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f080124;

        /* JADX INFO: Added by JADX */
        public static final int invisible = 0x7f080125;

        /* JADX INFO: Added by JADX */
        public static final int inward = 0x7f080126;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f080127;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f080128;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_previous_elevation = 0x7f080129;

        /* JADX INFO: Added by JADX */
        public static final int jumpToEnd = 0x7f08012a;

        /* JADX INFO: Added by JADX */
        public static final int jumpToStart = 0x7f08012b;

        /* JADX INFO: Added by JADX */
        public static final int keepSwitch = 0x7f08012c;

        /* JADX INFO: Added by JADX */
        public static final int keptOnlySwitch = 0x7f08012d;

        /* JADX INFO: Added by JADX */
        public static final int labeled = 0x7f08012e;

        /* JADX INFO: Added by JADX */
        public static final int lastGoButton = 0x7f08012f;

        /* JADX INFO: Added by JADX */
        public static final int layout = 0x7f080130;

        /* JADX INFO: Added by JADX */
        public static final int left = 0x7f080131;

        /* JADX INFO: Added by JADX */
        public static final int leftPanCard = 0x7f080132;

        /* JADX INFO: Added by JADX */
        public static final int leftPanMark = 0x7f080133;

        /* JADX INFO: Added by JADX */
        public static final int leftPanName = 0x7f080134;

        /* JADX INFO: Added by JADX */
        public static final int leftToRight = 0x7f080135;

        /* JADX INFO: Added by JADX */
        public static final int legacy = 0x7f080136;

        /* JADX INFO: Added by JADX */
        public static final int light = 0x7f080137;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f080138;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f080139;

        /* JADX INFO: Added by JADX */
        public static final int linear = 0x7f08013a;

        /* JADX INFO: Added by JADX */
        public static final int linkMark = 0x7f08013b;

        /* JADX INFO: Added by JADX */
        public static final int linkName = 0x7f08013c;

        /* JADX INFO: Added by JADX */
        public static final int linkRoot = 0x7f08013d;

        /* JADX INFO: Added by JADX */
        public static final int listMode = 0x7f08013e;

        /* JADX INFO: Added by JADX */
        public static final int list_item = 0x7f08013f;

        /* JADX INFO: Added by JADX */
        public static final int loading_label = 0x7f080140;

        /* JADX INFO: Added by JADX */
        public static final int locale = 0x7f080141;

        /* JADX INFO: Added by JADX */
        public static final int loosenButton = 0x7f080142;

        /* JADX INFO: Added by JADX */
        public static final int ltr = 0x7f080143;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet = 0x7f080144;

        /* JADX INFO: Added by JADX */
        public static final int marquee = 0x7f080145;

        /* JADX INFO: Added by JADX */
        public static final int masked = 0x7f080146;

        /* JADX INFO: Added by JADX */
        public static final int match_constraint = 0x7f080147;

        /* JADX INFO: Added by JADX */
        public static final int match_parent = 0x7f080148;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display = 0x7f080149;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_and_toggle = 0x7f08014a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_face = 0x7f08014b;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_hand = 0x7f08014c;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_level = 0x7f08014d;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_am_button = 0x7f08014e;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_pm_button = 0x7f08014f;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle = 0x7f080150;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_text_input = 0x7f080151;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_tv = 0x7f080152;

        /* JADX INFO: Added by JADX */
        public static final int material_label = 0x7f080153;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_text_input = 0x7f080154;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_tv = 0x7f080155;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_timepicker = 0x7f080156;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_cancel_button = 0x7f080157;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_container = 0x7f080158;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_mode_button = 0x7f080159;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_ok_button = 0x7f08015a;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_view = 0x7f08015b;

        /* JADX INFO: Added by JADX */
        public static final int material_value_index = 0x7f08015c;

        /* JADX INFO: Added by JADX */
        public static final int matrix = 0x7f08015d;

        /* JADX INFO: Added by JADX */
        public static final int message = 0x7f08015e;

        /* JADX INFO: Added by JADX */
        public static final int middle = 0x7f08015f;

        /* JADX INFO: Added by JADX */
        public static final int mini = 0x7f080160;

        /* JADX INFO: Added by JADX */
        public static final int month_grid = 0x7f080161;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_bar = 0x7f080162;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_fragment_toggle = 0x7f080163;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_next = 0x7f080164;

        /* JADX INFO: Added by JADX */
        public static final int month_navigation_previous = 0x7f080165;

        /* JADX INFO: Added by JADX */
        public static final int month_title = 0x7f080166;

        /* JADX INFO: Added by JADX */
        public static final int motionIndexFragment = 0x7f080167;

        /* JADX INFO: Added by JADX */
        public static final int motion_base = 0x7f080168;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_anchor_parent = 0x7f080169;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_selector_frame = 0x7f08016a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week = 0x7f08016b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_frame = 0x7f08016c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_main_pane = 0x7f08016d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_months = 0x7f08016e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_frame = 0x7f08016f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_text_input_frame = 0x7f080170;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_selector_frame = 0x7f080171;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_checked_layer_id = 0x7f080172;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_child_content_container = 0x7f080173;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_internal_children_alpha_tag = 0x7f080174;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_motion_snapshot_view = 0x7f080175;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_fullscreen = 0x7f080176;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header = 0x7f080177;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_selection_text = 0x7f080178;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_title_and_selection = 0x7f080179;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_toggle = 0x7f08017a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date = 0x7f08017b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_range_end = 0x7f08017c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_range_start = 0x7f08017d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_title_text = 0x7f08017e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_tag_bottom_padding = 0x7f08017f;

        /* JADX INFO: Added by JADX */
        public static final int multiply = 0x7f080180;

        /* JADX INFO: Added by JADX */
        public static final int navHostFragment = 0x7f080181;

        /* JADX INFO: Added by JADX */
        public static final int nav_controller_view_tag = 0x7f080182;

        /* JADX INFO: Added by JADX */
        public static final int nav_graph = 0x7f080183;

        /* JADX INFO: Added by JADX */
        public static final int nav_host_fragment_container = 0x7f080184;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_active_indicator_view = 0x7f080185;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_icon_container = 0x7f080186;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_icon_view = 0x7f080187;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_labels_group = 0x7f080188;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_large_label_view = 0x7f080189;

        /* JADX INFO: Added by JADX */
        public static final int navigation_bar_item_small_label_view = 0x7f08018a;

        /* JADX INFO: Added by JADX */
        public static final int navigation_header_container = 0x7f08018b;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f08018c;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToEnd = 0x7f08018d;

        /* JADX INFO: Added by JADX */
        public static final int neverCompleteToStart = 0x7f08018e;

        /* JADX INFO: Added by JADX */
        public static final int noScroll = 0x7f08018f;

        /* JADX INFO: Added by JADX */
        public static final int noState = 0x7f080190;

        /* JADX INFO: Added by JADX */
        public static final int none = 0x7f080191;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f080192;

        /* JADX INFO: Added by JADX */
        public static final int north = 0x7f080193;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f080194;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f080195;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f080196;

        /* JADX INFO: Added by JADX */
        public static final int off = 0x7f080197;

        /* JADX INFO: Added by JADX */
        public static final int on = 0x7f080198;

        /* JADX INFO: Added by JADX */
        public static final int onInterceptTouchReturnSwipe = 0x7f080199;

        /* JADX INFO: Added by JADX */
        public static final int openSheetButton = 0x7f08019a;

        /* JADX INFO: Added by JADX */
        public static final int open_search_bar_text_view = 0x7f08019b;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_background = 0x7f08019c;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_clear_button = 0x7f08019d;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_content_container = 0x7f08019e;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_divider = 0x7f08019f;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_dummy_toolbar = 0x7f0801a0;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_edit_text = 0x7f0801a1;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_header_container = 0x7f0801a2;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_root = 0x7f0801a3;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_scrim = 0x7f0801a4;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_search_prefix = 0x7f0801a5;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_status_bar_spacer = 0x7f0801a6;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_toolbar = 0x7f0801a7;

        /* JADX INFO: Added by JADX */
        public static final int open_search_view_toolbar_container = 0x7f0801a8;

        /* JADX INFO: Added by JADX */
        public static final int outline = 0x7f0801a9;

        /* JADX INFO: Added by JADX */
        public static final int outward = 0x7f0801aa;

        /* JADX INFO: Added by JADX */
        public static final int overshoot = 0x7f0801ab;

        /* JADX INFO: Added by JADX */
        public static final int packed = 0x7f0801ac;

        /* JADX INFO: Added by JADX */
        public static final int parallax = 0x7f0801ad;

        /* JADX INFO: Added by JADX */
        public static final int parent = 0x7f0801ae;

        /* JADX INFO: Added by JADX */
        public static final int parentPanel = 0x7f0801af;

        /* JADX INFO: Added by JADX */
        public static final int parentRelative = 0x7f0801b0;

        /* JADX INFO: Added by JADX */
        public static final int parent_matrix = 0x7f0801b1;

        /* JADX INFO: Added by JADX */
        public static final int password_toggle = 0x7f0801b2;

        /* JADX INFO: Added by JADX */
        public static final int path = 0x7f0801b3;

        /* JADX INFO: Added by JADX */
        public static final int pathRelative = 0x7f0801b4;

        /* JADX INFO: Added by JADX */
        public static final int peekHeight = 0x7f0801b5;

        /* JADX INFO: Added by JADX */
        public static final int percent = 0x7f0801b6;

        /* JADX INFO: Added by JADX */
        public static final int pickerEmptyView = 0x7f0801b7;

        /* JADX INFO: Added by JADX */
        public static final int pickerFilter = 0x7f0801b8;

        /* JADX INFO: Added by JADX */
        public static final int pickerList = 0x7f0801b9;

        /* JADX INFO: Added by JADX */
        public static final int pin = 0x7f0801ba;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f0801bb;

        /* JADX INFO: Added by JADX */
        public static final int position = 0x7f0801bc;

        /* JADX INFO: Added by JADX */
        public static final int postLayout = 0x7f0801bd;

        /* JADX INFO: Added by JADX */
        public static final int pressed = 0x7f0801be;

        /* JADX INFO: Added by JADX */
        public static final int progress_circular = 0x7f0801bf;

        /* JADX INFO: Added by JADX */
        public static final int progress_horizontal = 0x7f0801c0;

        /* JADX INFO: Added by JADX */
        public static final int progress_indicator = 0x7f0801c1;

        /* JADX INFO: Added by JADX */
        public static final int radio = 0x7f0801c2;

        /* JADX INFO: Added by JADX */
        public static final int ratio = 0x7f0801c3;

        /* JADX INFO: Added by JADX */
        public static final int recentEmptyGroup = 0x7f0801c4;

        /* JADX INFO: Added by JADX */
        public static final int recentLinkList = 0x7f0801c5;

        /* JADX INFO: Added by JADX */
        public static final int rectangles = 0x7f0801c6;

        /* JADX INFO: Added by JADX */
        public static final int reportInput = 0x7f0801c7;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f0801c8;

        /* JADX INFO: Added by JADX */
        public static final int resetButton = 0x7f0801c9;

        /* JADX INFO: Added by JADX */
        public static final int reverseSawtooth = 0x7f0801ca;

        /* JADX INFO: Added by JADX */
        public static final int right = 0x7f0801cb;

        /* JADX INFO: Added by JADX */
        public static final int rightPanCard = 0x7f0801cc;

        /* JADX INFO: Added by JADX */
        public static final int rightPanMark = 0x7f0801cd;

        /* JADX INFO: Added by JADX */
        public static final int rightPanName = 0x7f0801ce;

        /* JADX INFO: Added by JADX */
        public static final int rightToLeft = 0x7f0801cf;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f0801d0;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f0801d1;

        /* JADX INFO: Added by JADX */
        public static final int rounded = 0x7f0801d2;

        /* JADX INFO: Added by JADX */
        public static final int rowBand = 0x7f0801d3;

        /* JADX INFO: Added by JADX */
        public static final int rowHalfHour = 0x7f0801d4;

        /* JADX INFO: Added by JADX */
        public static final int rowKit = 0x7f0801d5;

        /* JADX INFO: Added by JADX */
        public static final int rowMover = 0x7f0801d6;

        /* JADX INFO: Added by JADX */
        public static final int rowScale = 0x7f0801d7;

        /* JADX INFO: Added by JADX */
        public static final int row_index_key = 0x7f0801d8;

        /* JADX INFO: Added by JADX */
        public static final int rtl = 0x7f0801d9;

        /* JADX INFO: Added by JADX */
        public static final int saveReportButton = 0x7f0801da;

        /* JADX INFO: Added by JADX */
        public static final int save_non_transition_alpha = 0x7f0801db;

        /* JADX INFO: Added by JADX */
        public static final int save_overlay_view = 0x7f0801dc;

        /* JADX INFO: Added by JADX */
        public static final int sawtooth = 0x7f0801dd;

        /* JADX INFO: Added by JADX */
        public static final int scale = 0x7f0801de;

        /* JADX INFO: Added by JADX */
        public static final int screen = 0x7f0801df;

        /* JADX INFO: Added by JADX */
        public static final int scroll = 0x7f0801e0;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorDown = 0x7f0801e1;

        /* JADX INFO: Added by JADX */
        public static final int scrollIndicatorUp = 0x7f0801e2;

        /* JADX INFO: Added by JADX */
        public static final int scrollView = 0x7f0801e3;

        /* JADX INFO: Added by JADX */
        public static final int scrollable = 0x7f0801e4;

        /* JADX INFO: Added by JADX */
        public static final int searchInput = 0x7f0801e5;

        /* JADX INFO: Added by JADX */
        public static final int searchLayout = 0x7f0801e6;

        /* JADX INFO: Added by JADX */
        public static final int search_badge = 0x7f0801e7;

        /* JADX INFO: Added by JADX */
        public static final int search_bar = 0x7f0801e8;

        /* JADX INFO: Added by JADX */
        public static final int search_button = 0x7f0801e9;

        /* JADX INFO: Added by JADX */
        public static final int search_close_btn = 0x7f0801ea;

        /* JADX INFO: Added by JADX */
        public static final int search_edit_frame = 0x7f0801eb;

        /* JADX INFO: Added by JADX */
        public static final int search_go_btn = 0x7f0801ec;

        /* JADX INFO: Added by JADX */
        public static final int search_mag_icon = 0x7f0801ed;

        /* JADX INFO: Added by JADX */
        public static final int search_plate = 0x7f0801ee;

        /* JADX INFO: Added by JADX */
        public static final int search_src_text = 0x7f0801ef;

        /* JADX INFO: Added by JADX */
        public static final int search_voice_btn = 0x7f0801f0;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_listview = 0x7f0801f1;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f0801f2;

        /* JADX INFO: Added by JADX */
        public static final int selection_type = 0x7f0801f3;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueSet = 0x7f0801f4;

        /* JADX INFO: Added by JADX */
        public static final int sharedValueUnset = 0x7f0801f5;

        /* JADX INFO: Added by JADX */
        public static final int sheetBand = 0x7f0801f6;

        /* JADX INFO: Added by JADX */
        public static final int sheetDial = 0x7f0801f7;

        /* JADX INFO: Added by JADX */
        public static final int sheetMark = 0x7f0801f8;

        /* JADX INFO: Added by JADX */
        public static final int sheetName = 0x7f0801f9;

        /* JADX INFO: Added by JADX */
        public static final int sheetPace = 0x7f0801fa;

        /* JADX INFO: Added by JADX */
        public static final int sheetTag = 0x7f0801fb;

        /* JADX INFO: Added by JADX */
        public static final int shortcut = 0x7f0801fc;

        /* JADX INFO: Added by JADX */
        public static final int shortcutChips = 0x7f0801fd;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 0x7f0801fe;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 0x7f0801ff;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f080200;

        /* JADX INFO: Added by JADX */
        public static final int sin = 0x7f080201;

        /* JADX INFO: Added by JADX */
        public static final int skipCollapsed = 0x7f080202;

        /* JADX INFO: Added by JADX */
        public static final int skipped = 0x7f080203;

        /* JADX INFO: Added by JADX */
        public static final int slide = 0x7f080204;

        /* JADX INFO: Added by JADX */
        public static final int sliding_pane_detail_container = 0x7f080205;

        /* JADX INFO: Added by JADX */
        public static final int sliding_pane_layout = 0x7f080206;

        /* JADX INFO: Added by JADX */
        public static final int snackbar_action = 0x7f080207;

        /* JADX INFO: Added by JADX */
        public static final int snackbar_text = 0x7f080208;

        /* JADX INFO: Added by JADX */
        public static final int snap = 0x7f080209;

        /* JADX INFO: Added by JADX */
        public static final int snapMargins = 0x7f08020a;

        /* JADX INFO: Added by JADX */
        public static final int south = 0x7f08020b;

        /* JADX INFO: Added by JADX */
        public static final int spacer = 0x7f08020c;

        /* JADX INFO: Added by JADX */
        public static final int specLabel = 0x7f08020d;

        /* JADX INFO: Added by JADX */
        public static final int specValue = 0x7f08020e;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 0x7f08020f;

        /* JADX INFO: Added by JADX */
        public static final int splash_root = 0x7f080210;

        /* JADX INFO: Added by JADX */
        public static final int spline = 0x7f080211;

        /* JADX INFO: Added by JADX */
        public static final int split_action_bar = 0x7f080212;

        /* JADX INFO: Added by JADX */
        public static final int spread = 0x7f080213;

        /* JADX INFO: Added by JADX */
        public static final int spread_inside = 0x7f080214;

        /* JADX INFO: Added by JADX */
        public static final int spring = 0x7f080215;

        /* JADX INFO: Added by JADX */
        public static final int square = 0x7f080216;

        /* JADX INFO: Added by JADX */
        public static final int src_atop = 0x7f080217;

        /* JADX INFO: Added by JADX */
        public static final int src_in = 0x7f080218;

        /* JADX INFO: Added by JADX */
        public static final int src_over = 0x7f080219;

        /* JADX INFO: Added by JADX */
        public static final int standard = 0x7f08021a;

        /* JADX INFO: Added by JADX */
        public static final int start = 0x7f08021b;

        /* JADX INFO: Added by JADX */
        public static final int startHorizontal = 0x7f08021c;

        /* JADX INFO: Added by JADX */
        public static final int startToEnd = 0x7f08021d;

        /* JADX INFO: Added by JADX */
        public static final int startVertical = 0x7f08021e;

        /* JADX INFO: Added by JADX */
        public static final int staticLayout = 0x7f08021f;

        /* JADX INFO: Added by JADX */
        public static final int staticPostLayout = 0x7f080220;

        /* JADX INFO: Added by JADX */
        public static final int stokerLogFragment = 0x7f080221;

        /* JADX INFO: Added by JADX */
        public static final int stop = 0x7f080222;

        /* JADX INFO: Added by JADX */
        public static final int stretch = 0x7f080223;

        /* JADX INFO: Added by JADX */
        public static final int submenuarrow = 0x7f080224;

        /* JADX INFO: Added by JADX */
        public static final int submit_area = 0x7f080225;

        /* JADX INFO: Added by JADX */
        public static final int supportScrollUp = 0x7f080226;

        /* JADX INFO: Added by JADX */
        public static final int swapButton = 0x7f080227;

        /* JADX INFO: Added by JADX */
        public static final int tabMode = 0x7f080228;

        /* JADX INFO: Added by JADX */
        public static final int tagChips = 0x7f080229;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f08022a;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f08022b;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f08022c;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f08022d;

        /* JADX INFO: Added by JADX */
        public static final int tag_compat_insets_dispatch = 0x7f08022e;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f08022f;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f080230;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f080231;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f080232;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f080233;

        /* JADX INFO: Added by JADX */
        public static final int tag_system_bar_state_monitor = 0x7f080234;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f080235;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f080236;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f080237;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f080238;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f080239;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f08023a;

        /* JADX INFO: Added by JADX */
        public static final int textEnd = 0x7f08023b;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoButtons = 0x7f08023c;

        /* JADX INFO: Added by JADX */
        public static final int textSpacerNoTitle = 0x7f08023d;

        /* JADX INFO: Added by JADX */
        public static final int textStart = 0x7f08023e;

        /* JADX INFO: Added by JADX */
        public static final int textTop = 0x7f08023f;

        /* JADX INFO: Added by JADX */
        public static final int text_input_end_icon = 0x7f080240;

        /* JADX INFO: Added by JADX */
        public static final int text_input_error_icon = 0x7f080241;

        /* JADX INFO: Added by JADX */
        public static final int text_input_start_icon = 0x7f080242;

        /* JADX INFO: Added by JADX */
        public static final int textinput_counter = 0x7f080243;

        /* JADX INFO: Added by JADX */
        public static final int textinput_error = 0x7f080244;

        /* JADX INFO: Added by JADX */
        public static final int textinput_helper_text = 0x7f080245;

        /* JADX INFO: Added by JADX */
        public static final int textinput_placeholder = 0x7f080246;

        /* JADX INFO: Added by JADX */
        public static final int textinput_prefix_text = 0x7f080247;

        /* JADX INFO: Added by JADX */
        public static final int textinput_suffix_text = 0x7f080248;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f080249;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f08024a;

        /* JADX INFO: Added by JADX */
        public static final int titleDividerNoCustom = 0x7f08024b;

        /* JADX INFO: Added by JADX */
        public static final int title_template = 0x7f08024c;

        /* JADX INFO: Added by JADX */
        public static final int toScalesButton = 0x7f08024d;

        /* JADX INFO: Added by JADX */
        public static final int toggle = 0x7f08024e;

        /* JADX INFO: Added by JADX */
        public static final int toolbar = 0x7f08024f;

        /* JADX INFO: Added by JADX */
        public static final int top = 0x7f080250;

        /* JADX INFO: Added by JADX */
        public static final int topPanel = 0x7f080251;

        /* JADX INFO: Added by JADX */
        public static final int totalScoreCaption = 0x7f080252;

        /* JADX INFO: Added by JADX */
        public static final int totalScoreView = 0x7f080253;

        /* JADX INFO: Added by JADX */
        public static final int touch_outside = 0x7f080254;

        /* JADX INFO: Added by JADX */
        public static final int transitionToEnd = 0x7f080255;

        /* JADX INFO: Added by JADX */
        public static final int transitionToStart = 0x7f080256;

        /* JADX INFO: Added by JADX */
        public static final int transition_clip = 0x7f080257;

        /* JADX INFO: Added by JADX */
        public static final int transition_current_scene = 0x7f080258;

        /* JADX INFO: Added by JADX */
        public static final int transition_image_transform = 0x7f080259;

        /* JADX INFO: Added by JADX */
        public static final int transition_layout_save = 0x7f08025a;

        /* JADX INFO: Added by JADX */
        public static final int transition_pause_alpha = 0x7f08025b;

        /* JADX INFO: Added by JADX */
        public static final int transition_position = 0x7f08025c;

        /* JADX INFO: Added by JADX */
        public static final int transition_scene_layoutid_cache = 0x7f08025d;

        /* JADX INFO: Added by JADX */
        public static final int transition_transform = 0x7f08025e;

        /* JADX INFO: Added by JADX */
        public static final int triangle = 0x7f08025f;

        /* JADX INFO: Added by JADX */
        public static final int twinWeighFragment = 0x7f080260;

        /* JADX INFO: Added by JADX */
        public static final int unchecked = 0x7f080261;

        /* JADX INFO: Added by JADX */
        public static final int uniform = 0x7f080262;

        /* JADX INFO: Added by JADX */
        public static final int unlabeled = 0x7f080263;

        /* JADX INFO: Added by JADX */
        public static final int up = 0x7f080264;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 0x7f080265;

        /* JADX INFO: Added by JADX */
        public static final int verdictLine = 0x7f080266;

        /* JADX INFO: Added by JADX */
        public static final int vertical = 0x7f080267;

        /* JADX INFO: Added by JADX */
        public static final int vertical_only = 0x7f080268;

        /* JADX INFO: Added by JADX */
        public static final int view_offset_helper = 0x7f080269;

        /* JADX INFO: Added by JADX */
        public static final int view_transition = 0x7f08026a;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_disjoint_parent = 0x7f08026b;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f08026c;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f08026d;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f08026e;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f08026f;

        /* JADX INFO: Added by JADX */
        public static final int visible = 0x7f080270;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 0x7f080271;

        /* JADX INFO: Added by JADX */
        public static final int weighCount = 0x7f080272;

        /* JADX INFO: Added by JADX */
        public static final int west = 0x7f080273;

        /* JADX INFO: Added by JADX */
        public static final int wide = 0x7f080274;

        /* JADX INFO: Added by JADX */
        public static final int withText = 0x7f080275;

        /* JADX INFO: Added by JADX */
        public static final int with_icon = 0x7f080276;

        /* JADX INFO: Added by JADX */
        public static final int withinBounds = 0x7f080277;

        /* JADX INFO: Added by JADX */
        public static final int wrap = 0x7f080278;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content = 0x7f080279;

        /* JADX INFO: Added by JADX */
        public static final int wrap_content_constrained = 0x7f08027a;

        /* JADX INFO: Added by JADX */
        public static final int x_left = 0x7f08027b;

        /* JADX INFO: Added by JADX */
        public static final int x_right = 0x7f08027c;
    }

    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityDefaultDur = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int abc_config_activityShortDur = 0x7f090001;

        /* JADX INFO: Added by JADX */
        public static final int app_bar_elevation_anim_duration = 0x7f090002;

        /* JADX INFO: Added by JADX */
        public static final int bottom_sheet_slide_duration = 0x7f090003;

        /* JADX INFO: Added by JADX */
        public static final int config_navAnimTime = 0x7f090005;

        /* JADX INFO: Added by JADX */
        public static final int config_tooltipAnimTime = 0x7f090006;

        /* JADX INFO: Added by JADX */
        public static final int design_snackbar_text_max_lines = 0x7f090007;

        /* JADX INFO: Added by JADX */
        public static final int design_tab_indicator_anim_duration_ms = 0x7f090008;

        /* JADX INFO: Added by JADX */
        public static final int google_play_services_version = 0x7f090009;

        /* JADX INFO: Added by JADX */
        public static final int hide_password_duration = 0x7f09000a;

        /* JADX INFO: Added by JADX */
        public static final int m3_badge_max_number = 0x7f09000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_anim_delay_ms = 0x7f09000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_btn_anim_duration_ms = 0x7f09000d;

        /* JADX INFO: Added by JADX */
        public static final int m3_chip_anim_duration = 0x7f090010;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long1 = 0x7f090011;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long2 = 0x7f090012;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long3 = 0x7f090013;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_extra_long4 = 0x7f090014;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long1 = 0x7f090015;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long2 = 0x7f090016;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long3 = 0x7f090017;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_long4 = 0x7f090018;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium1 = 0x7f090019;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium2 = 0x7f09001a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium3 = 0x7f09001b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_medium4 = 0x7f09001c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short1 = 0x7f09001d;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short2 = 0x7f09001e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short3 = 0x7f09001f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_duration_short4 = 0x7f090020;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_path = 0x7f090021;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_shape_corner_full_corner_family = 0x7f090024;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_long_1 = 0x7f090028;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_long_2 = 0x7f090029;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_medium_1 = 0x7f09002a;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_medium_2 = 0x7f09002b;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_short_1 = 0x7f09002c;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_duration_short_2 = 0x7f09002d;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_path = 0x7f09002e;

        /* JADX INFO: Added by JADX */
        public static final int motion_normal = 0x7f090030;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_anim_delay_ms = 0x7f090032;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_btn_anim_duration_ms = 0x7f090033;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_header_orientation = 0x7f090034;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_selection_text_lines = 0x7f090035;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year_selector_span = 0x7f090036;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_anim_delay_ms = 0x7f090037;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_card_anim_duration_ms = 0x7f090038;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_anim_duration = 0x7f090039;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_post_morphing_duration = 0x7f09003b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pre_morphing_duration = 0x7f09003c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_pressed_duration = 0x7f09003d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_viewport_center_coordinate = 0x7f09003e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_viewport_size = 0x7f09003f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_viewport_height = 0x7f090040;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_viewport_width = 0x7f090041;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_tab_indicator_anim_duration_ms = 0x7f090042;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_view_invisible = 0x7f090044;

        /* JADX INFO: Added by JADX */
        public static final int show_password_duration = 0x7f090046;
    }

    /* JADX INFO: Added by JADX */
    public static final class interpolator {

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 0x7f0a0000;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 0x7f0a0001;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 0x7f0a0002;

        /* JADX INFO: Added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 0x7f0a0003;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 0x7f0a0004;

        /* JADX INFO: Added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 0x7f0a0005;

        /* JADX INFO: Added by JADX */
        public static final int fast_out_slow_in = 0x7f0a0006;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized = 0x7f0a0007;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_accelerate = 0x7f0a0008;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_decelerate = 0x7f0a0009;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear = 0x7f0a000a;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard = 0x7f0a000b;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_accelerate = 0x7f0a000c;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard_decelerate = 0x7f0a000d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fast_out_linear_in = 0x7f0a000e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_fast_out_slow_in = 0x7f0a000f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_linear = 0x7f0a0010;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_linear_out_slow_in = 0x7f0a0011;
    }

    public static final class layout {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_title_item = 0x7f0b0000;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_item_layout = 0x7f0b0002;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_menu_layout = 0x7f0b0003;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_bar = 0x7f0b0004;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_close_item_material = 0x7f0b0005;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 0x7f0b0008;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_material = 0x7f0b0009;

        /* JADX INFO: Added by JADX */
        public static final int abc_alert_dialog_title_material = 0x7f0b000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_cascading_menu_item_layout = 0x7f0b000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_dialog_title_material = 0x7f0b000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_expanded_menu_layout = 0x7f0b000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_checkbox = 0x7f0b000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_icon = 0x7f0b000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_layout = 0x7f0b0010;

        /* JADX INFO: Added by JADX */
        public static final int abc_list_menu_item_radio = 0x7f0b0011;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_header_item_layout = 0x7f0b0012;

        /* JADX INFO: Added by JADX */
        public static final int abc_popup_menu_item_layout = 0x7f0b0013;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_content_include = 0x7f0b0014;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple = 0x7f0b0015;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 0x7f0b0016;

        /* JADX INFO: Added by JADX */
        public static final int abc_screen_toolbar = 0x7f0b0017;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 0x7f0b0018;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_view = 0x7f0b0019;

        /* JADX INFO: Added by JADX */
        public static final int abc_select_dialog_material = 0x7f0b001a;

        /* JADX INFO: Added by JADX */
        public static final int activity_main = 0x7f0b001c;

        /* JADX INFO: Added by JADX */
        public static final int activity_splash = 0x7f0b001d;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_navigation_item = 0x7f0b0021;

        /* JADX INFO: Added by JADX */
        public static final int design_bottom_sheet_dialog = 0x7f0b0022;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_snackbar = 0x7f0b0023;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_snackbar_include = 0x7f0b0024;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_tab_icon = 0x7f0b0025;

        /* JADX INFO: Added by JADX */
        public static final int design_layout_tab_text = 0x7f0b0026;

        /* JADX INFO: Added by JADX */
        public static final int design_menu_item_action_area = 0x7f0b0027;

        /* JADX INFO: Added by JADX */
        public static final int design_navigation_menu_item = 0x7f0b002d;

        /* JADX INFO: Added by JADX */
        public static final int design_text_input_end_icon = 0x7f0b002e;

        /* JADX INFO: Added by JADX */
        public static final int design_text_input_start_icon = 0x7f0b002f;

        /* JADX INFO: Added by JADX */
        public static final int dialog_pan_picker = 0x7f0b0030;

        /* JADX INFO: Added by JADX */
        public static final int fragment_catalog = 0x7f0b0031;

        /* JADX INFO: Added by JADX */
        public static final int fragment_detail = 0x7f0b0032;

        /* JADX INFO: Added by JADX */
        public static final int fragment_home = 0x7f0b0033;

        /* JADX INFO: Added by JADX */
        public static final int fragment_profile = 0x7f0b0034;

        /* JADX INFO: Added by JADX */
        public static final int fragment_tool = 0x7f0b0035;

        /* JADX INFO: Added by JADX */
        public static final int item_badge_mark = 0x7f0b0038;

        /* JADX INFO: Added by JADX */
        public static final int item_move_band = 0x7f0b0039;

        /* JADX INFO: Added by JADX */
        public static final int item_pan_choice = 0x7f0b003a;

        /* JADX INFO: Added by JADX */
        public static final int item_recent_link = 0x7f0b003b;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog = 0x7f0b003c;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_actions = 0x7f0b003d;

        /* JADX INFO: Added by JADX */
        public static final int m3_alert_dialog_title = 0x7f0b003e;

        /* JADX INFO: Added by JADX */
        public static final int m3_auto_complete_simple_item = 0x7f0b003f;

        /* JADX INFO: Added by JADX */
        public static final int m3_side_sheet_dialog = 0x7f0b0040;

        /* JADX INFO: Added by JADX */
        public static final int material_chip_input_combo = 0x7f0b0041;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display = 0x7f0b0042;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_divider = 0x7f0b0043;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle = 0x7f0b0044;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_period_toggle_land = 0x7f0b0045;

        /* JADX INFO: Added by JADX */
        public static final int material_clockface_textview = 0x7f0b0046;

        /* JADX INFO: Added by JADX */
        public static final int material_clockface_view = 0x7f0b0047;

        /* JADX INFO: Added by JADX */
        public static final int material_radial_view_group = 0x7f0b0048;

        /* JADX INFO: Added by JADX */
        public static final int material_textinput_timepicker = 0x7f0b0049;

        /* JADX INFO: Added by JADX */
        public static final int material_time_chip = 0x7f0b004a;

        /* JADX INFO: Added by JADX */
        public static final int material_time_input = 0x7f0b004b;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker = 0x7f0b004c;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_dialog = 0x7f0b004d;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_textinput_display = 0x7f0b004e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog = 0x7f0b004f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_actions = 0x7f0b0050;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_dialog_title = 0x7f0b0051;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_item = 0x7f0b0052;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_multichoice = 0x7f0b0053;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_alert_select_dialog_singlechoice = 0x7f0b0054;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_auto_complete_simple_item = 0x7f0b0055;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day = 0x7f0b0056;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_day_of_week = 0x7f0b0057;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_days_of_week = 0x7f0b0058;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_horizontal = 0x7f0b0059;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month = 0x7f0b005a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_labeled = 0x7f0b005b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_month_navigation = 0x7f0b005c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_months = 0x7f0b005d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_vertical = 0x7f0b005e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_calendar_year = 0x7f0b005f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_layout_snackbar = 0x7f0b0060;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_layout_snackbar_include = 0x7f0b0061;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_navigation_rail_item = 0x7f0b0062;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_actions = 0x7f0b0063;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_dialog = 0x7f0b0064;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_fullscreen = 0x7f0b0065;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_dialog = 0x7f0b0066;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_fullscreen = 0x7f0b0067;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_selection_text = 0x7f0b0068;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_title_text = 0x7f0b0069;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_header_toggle = 0x7f0b006a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date = 0x7f0b006b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range = 0x7f0b006c;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 0x7f0b006f;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 0x7f0b0070;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 0x7f0b0071;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 0x7f0b0072;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 0x7f0b0073;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 0x7f0b0074;

        /* JADX INFO: Added by JADX */
        public static final int part_compare_row = 0x7f0b0075;

        /* JADX INFO: Added by JADX */
        public static final int part_spec_row = 0x7f0b0076;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_item_material = 0x7f0b0077;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_multichoice_material = 0x7f0b0078;

        /* JADX INFO: Added by JADX */
        public static final int select_dialog_singlechoice_material = 0x7f0b0079;

        /* JADX INFO: Added by JADX */
        public static final int support_simple_spinner_dropdown_item = 0x7f0b007a;
    }

    public static final class menu {

        /* JADX INFO: Added by JADX */
        public static final int bottom_nav = 0x7f0d0000;
    }

    public static final class mipmap {

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher = 0x7f0e0000;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_foreground = 0x7f0e0001;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_round = 0x7f0e0002;
    }

    public static final class navigation {

        /* JADX INFO: Added by JADX */
        public static final int nav_graph = 0x7f0f0000;
    }

    /* JADX INFO: Added by JADX */
    public static final class plurals {

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_content_description = 0x7f100000;
    }

    public static final class string {

        /* JADX INFO: Added by JADX */
        public static final int abc_action_bar_up_description = 0x7f110001;

        /* JADX INFO: Added by JADX */
        public static final int abc_action_mode_done = 0x7f110003;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_off = 0x7f110006;

        /* JADX INFO: Added by JADX */
        public static final int abc_capital_on = 0x7f110007;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_alt_shortcut_label = 0x7f110008;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 0x7f110009;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_delete_shortcut_label = 0x7f11000a;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_enter_shortcut_label = 0x7f11000b;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_function_shortcut_label = 0x7f11000c;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_meta_shortcut_label = 0x7f11000d;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_shift_shortcut_label = 0x7f11000e;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_space_shortcut_label = 0x7f11000f;

        /* JADX INFO: Added by JADX */
        public static final int abc_menu_sym_shortcut_label = 0x7f110010;

        /* JADX INFO: Added by JADX */
        public static final int abc_prepend_shortcut_label = 0x7f110011;

        /* JADX INFO: Added by JADX */
        public static final int abc_search_hint = 0x7f110012;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_clear = 0x7f110013;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_search = 0x7f110015;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_submit = 0x7f110016;

        /* JADX INFO: Added by JADX */
        public static final int abc_searchview_description_voice = 0x7f110017;

        /* JADX INFO: Added by JADX */
        public static final int abc_toolbar_collapse_description = 0x7f11001a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f11001b;

        /* JADX INFO: Added by JADX */
        public static final int app_name = 0x7f11001c;

        /* JADX INFO: Added by JADX */
        public static final int badge_beam_reader = 0x7f11001e;

        /* JADX INFO: Added by JADX */
        public static final int badge_beam_reader_req = 0x7f11001f;

        /* JADX INFO: Added by JADX */
        public static final int badge_first_spark = 0x7f110020;

        /* JADX INFO: Added by JADX */
        public static final int badge_first_spark_req = 0x7f110021;

        /* JADX INFO: Added by JADX */
        public static final int badge_full_blaze = 0x7f110022;

        /* JADX INFO: Added by JADX */
        public static final int badge_full_blaze_req = 0x7f110023;

        /* JADX INFO: Added by JADX */
        public static final int badge_kindling_keeper = 0x7f110024;

        /* JADX INFO: Added by JADX */
        public static final int badge_kindling_keeper_req = 0x7f110025;

        /* JADX INFO: Added by JADX */
        public static final int badge_progress = 0x7f110026;

        /* JADX INFO: Added by JADX */
        public static final int badge_recap_keeper = 0x7f110027;

        /* JADX INFO: Added by JADX */
        public static final int badge_recap_keeper_req = 0x7f110028;

        /* JADX INFO: Added by JADX */
        public static final int badge_steady_draught = 0x7f110029;

        /* JADX INFO: Added by JADX */
        public static final int badge_steady_draught_req = 0x7f11002a;

        /* JADX INFO: Added by JADX */
        public static final int band_easy_glow = 0x7f11002b;

        /* JADX INFO: Added by JADX */
        public static final int band_full_blaze = 0x7f11002c;

        /* JADX INFO: Added by JADX */
        public static final int band_steady_burn = 0x7f11002d;

        /* JADX INFO: Added by JADX */
        public static final int bottom_sheet_behavior = 0x7f11002e;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_collapse = 0x7f11002f;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_expand = 0x7f110030;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_action_expand_halfway = 0x7f110031;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_drag_handle_clicked = 0x7f110032;

        /* JADX INFO: Added by JADX */
        public static final int bottomsheet_drag_handle_content_description = 0x7f110033;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 0x7f110034;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 0x7f110035;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 0x7f110036;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 0x7f110037;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 0x7f110038;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 0x7f110039;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 0x7f11003a;

        /* JADX INFO: Added by JADX */
        public static final int cd_kept_marker = 0x7f11003b;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_content_description = 0x7f11003c;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_overflowed_content_description = 0x7f11003d;

        /* JADX INFO: Added by JADX */
        public static final int character_counter_pattern = 0x7f11003e;

        /* JADX INFO: Added by JADX */
        public static final int clear_text_end_icon_content_description = 0x7f11003f;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_button = 0x7f110040;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_text = 0x7f110041;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_enable_title = 0x7f110042;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_button = 0x7f110043;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_text = 0x7f110044;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_install_title = 0x7f110045;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_channel_name = 0x7f110046;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_notification_ticker = 0x7f110047;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unknown_issue = 0x7f110048;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_unsupported_text = 0x7f110049;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_button = 0x7f11004a;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_text = 0x7f11004b;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_update_title = 0x7f11004c;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_updating_text = 0x7f11004d;

        /* JADX INFO: Added by JADX */
        public static final int common_google_play_services_wear_update_text = 0x7f11004e;

        /* JADX INFO: Added by JADX */
        public static final int common_open_on_phone = 0x7f11004f;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text = 0x7f110050;

        /* JADX INFO: Added by JADX */
        public static final int common_signin_button_text_long = 0x7f110051;

        /* JADX INFO: Added by JADX */
        public static final int dest_title = 0x7f110053;

        /* JADX INFO: Added by JADX */
        public static final int error_a11y_label = 0x7f110054;

        /* JADX INFO: Added by JADX */
        public static final int error_icon_content_description = 0x7f110055;

        /* JADX INFO: Added by JADX */
        public static final int exposed_dropdown_menu_content_description = 0x7f110056;

        /* JADX INFO: Added by JADX */
        public static final int furnace_cost_heading = 0x7f11005c;

        /* JADX INFO: Added by JADX */
        public static final int furnace_cost_label = 0x7f11005d;

        /* JADX INFO: Added by JADX */
        public static final int furnace_dial_caption = 0x7f11005e;

        /* JADX INFO: Added by JADX */
        public static final int furnace_fan_another = 0x7f11005f;

        /* JADX INFO: Added by JADX */
        public static final int furnace_mover_label = 0x7f110060;

        /* JADX INFO: Added by JADX */
        public static final int furnace_open_sheet = 0x7f110061;

        /* JADX INFO: Added by JADX */
        public static final int furnace_shortcut_heading = 0x7f110062;

        /* JADX INFO: Added by JADX */
        public static final int furnace_to_scales = 0x7f110063;

        /* JADX INFO: Added by JADX */
        public static final int icon_content_description = 0x7f110065;

        /* JADX INFO: Added by JADX */
        public static final int index_count = 0x7f110066;

        /* JADX INFO: Added by JADX */
        public static final int index_empty_action = 0x7f110067;

        /* JADX INFO: Added by JADX */
        public static final int index_empty_body = 0x7f110068;

        /* JADX INFO: Added by JADX */
        public static final int index_empty_title = 0x7f110069;

        /* JADX INFO: Added by JADX */
        public static final int index_kept_only = 0x7f11006a;

        /* JADX INFO: Added by JADX */
        public static final int index_search_hint = 0x7f11006b;

        /* JADX INFO: Added by JADX */
        public static final int item_view_role_description = 0x7f11006c;

        /* JADX INFO: Added by JADX */
        public static final int kcal_value = 0x7f11006d;

        /* JADX INFO: Added by JADX */
        public static final int log_badges_heading = 0x7f11006e;

        /* JADX INFO: Added by JADX */
        public static final int log_quick_empty_body = 0x7f11006f;

        /* JADX INFO: Added by JADX */
        public static final int log_quick_empty_title = 0x7f110070;

        /* JADX INFO: Added by JADX */
        public static final int log_quick_heading = 0x7f110071;

        /* JADX INFO: Added by JADX */
        public static final int log_reset = 0x7f110072;

        /* JADX INFO: Added by JADX */
        public static final int log_reset_body = 0x7f110073;

        /* JADX INFO: Added by JADX */
        public static final int log_reset_cancel = 0x7f110074;

        /* JADX INFO: Added by JADX */
        public static final int log_reset_confirm = 0x7f110075;

        /* JADX INFO: Added by JADX */
        public static final int log_reset_done = 0x7f110076;

        /* JADX INFO: Added by JADX */
        public static final int log_reset_title = 0x7f110077;

        /* JADX INFO: Added by JADX */
        public static final int log_total_heading = 0x7f110078;

        /* JADX INFO: Added by JADX */
        public static final int log_total_sub = 0x7f110079;

        /* JADX INFO: Added by JADX */
        public static final int m3_exceed_max_badge_text_suffix = 0x7f11007a;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_brand_regular = 0x7f11007c;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_plain_medium = 0x7f11007d;

        /* JADX INFO: Added by JADX */
        public static final int m3_ref_typeface_plain_regular = 0x7f11007e;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized = 0x7f11007f;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_emphasized_path_data = 0x7f110082;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_accelerate = 0x7f110084;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_legacy_decelerate = 0x7f110085;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_linear = 0x7f110086;

        /* JADX INFO: Added by JADX */
        public static final int m3_sys_motion_easing_standard = 0x7f110087;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_display_divider = 0x7f11008a;

        /* JADX INFO: Added by JADX */
        public static final int material_clock_toggle_content_description = 0x7f11008b;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_24h_suffix = 0x7f11008c;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_selection = 0x7f11008d;

        /* JADX INFO: Added by JADX */
        public static final int material_hour_suffix = 0x7f11008e;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_selection = 0x7f11008f;

        /* JADX INFO: Added by JADX */
        public static final int material_minute_suffix = 0x7f110090;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_accelerated = 0x7f110091;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_decelerated = 0x7f110092;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_emphasized = 0x7f110093;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_linear = 0x7f110094;

        /* JADX INFO: Added by JADX */
        public static final int material_motion_easing_standard = 0x7f110095;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_am = 0x7f110099;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_clock_mode_description = 0x7f11009a;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_hour = 0x7f11009b;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_minute = 0x7f11009c;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_pm = 0x7f11009d;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_select_time = 0x7f11009e;

        /* JADX INFO: Added by JADX */
        public static final int material_timepicker_text_input_mode_description = 0x7f11009f;

        /* JADX INFO: Added by JADX */
        public static final int met_value = 0x7f1100a0;

        /* JADX INFO: Added by JADX */
        public static final int move_barre_work_kit = 0x7f1100a1;

        /* JADX INFO: Added by JADX */
        public static final int move_barre_work_mover = 0x7f1100a2;

        /* JADX INFO: Added by JADX */
        public static final int move_barre_work_name = 0x7f1100a3;

        /* JADX INFO: Added by JADX */
        public static final int move_barre_work_pace = 0x7f1100a4;

        /* JADX INFO: Added by JADX */
        public static final int move_chopping_firewood_kit = 0x7f1100a5;

        /* JADX INFO: Added by JADX */
        public static final int move_chopping_firewood_mover = 0x7f1100a6;

        /* JADX INFO: Added by JADX */
        public static final int move_chopping_firewood_name = 0x7f1100a7;

        /* JADX INFO: Added by JADX */
        public static final int move_chopping_firewood_pace = 0x7f1100a8;

        /* JADX INFO: Added by JADX */
        public static final int move_cooking_dinner_kit = 0x7f1100a9;

        /* JADX INFO: Added by JADX */
        public static final int move_cooking_dinner_mover = 0x7f1100aa;

        /* JADX INFO: Added by JADX */
        public static final int move_cooking_dinner_name = 0x7f1100ab;

        /* JADX INFO: Added by JADX */
        public static final int move_cooking_dinner_pace = 0x7f1100ac;

        /* JADX INFO: Added by JADX */
        public static final int move_corner_shop_stroll_kit = 0x7f1100ad;

        /* JADX INFO: Added by JADX */
        public static final int move_corner_shop_stroll_mover = 0x7f1100ae;

        /* JADX INFO: Added by JADX */
        public static final int move_corner_shop_stroll_name = 0x7f1100af;

        /* JADX INFO: Added by JADX */
        public static final int move_corner_shop_stroll_pace = 0x7f1100b0;

        /* JADX INFO: Added by JADX */
        public static final int move_cycle_commute_kit = 0x7f1100b1;

        /* JADX INFO: Added by JADX */
        public static final int move_cycle_commute_mover = 0x7f1100b2;

        /* JADX INFO: Added by JADX */
        public static final int move_cycle_commute_name = 0x7f1100b3;

        /* JADX INFO: Added by JADX */
        public static final int move_cycle_commute_pace = 0x7f1100b4;

        /* JADX INFO: Added by JADX */
        public static final int move_dog_walk_brisk_kit = 0x7f1100b5;

        /* JADX INFO: Added by JADX */
        public static final int move_dog_walk_brisk_mover = 0x7f1100b6;

        /* JADX INFO: Added by JADX */
        public static final int move_dog_walk_brisk_name = 0x7f1100b7;

        /* JADX INFO: Added by JADX */
        public static final int move_dog_walk_brisk_pace = 0x7f1100b8;

        /* JADX INFO: Added by JADX */
        public static final int move_folding_laundry_kit = 0x7f1100b9;

        /* JADX INFO: Added by JADX */
        public static final int move_folding_laundry_mover = 0x7f1100ba;

        /* JADX INFO: Added by JADX */
        public static final int move_folding_laundry_name = 0x7f1100bb;

        /* JADX INFO: Added by JADX */
        public static final int move_folding_laundry_pace = 0x7f1100bc;

        /* JADX INFO: Added by JADX */
        public static final int move_free_weights_kit = 0x7f1100bd;

        /* JADX INFO: Added by JADX */
        public static final int move_free_weights_mover = 0x7f1100be;

        /* JADX INFO: Added by JADX */
        public static final int move_free_weights_name = 0x7f1100bf;

        /* JADX INFO: Added by JADX */
        public static final int move_free_weights_pace = 0x7f1100c0;

        /* JADX INFO: Added by JADX */
        public static final int move_front_crawl_laps_kit = 0x7f1100c1;

        /* JADX INFO: Added by JADX */
        public static final int move_front_crawl_laps_mover = 0x7f1100c2;

        /* JADX INFO: Added by JADX */
        public static final int move_front_crawl_laps_name = 0x7f1100c3;

        /* JADX INFO: Added by JADX */
        public static final int move_front_crawl_laps_pace = 0x7f1100c4;

        /* JADX INFO: Added by JADX */
        public static final int move_groceries_upstairs_kit = 0x7f1100c5;

        /* JADX INFO: Added by JADX */
        public static final int move_groceries_upstairs_mover = 0x7f1100c6;

        /* JADX INFO: Added by JADX */
        public static final int move_groceries_upstairs_name = 0x7f1100c7;

        /* JADX INFO: Added by JADX */
        public static final int move_groceries_upstairs_pace = 0x7f1100c8;

        /* JADX INFO: Added by JADX */
        public static final int move_kayak_paddle_kit = 0x7f1100c9;

        /* JADX INFO: Added by JADX */
        public static final int move_kayak_paddle_mover = 0x7f1100ca;

        /* JADX INFO: Added by JADX */
        public static final int move_kayak_paddle_name = 0x7f1100cb;

        /* JADX INFO: Added by JADX */
        public static final int move_kayak_paddle_pace = 0x7f1100cc;

        /* JADX INFO: Added by JADX */
        public static final int move_lake_rowing_kit = 0x7f1100cd;

        /* JADX INFO: Added by JADX */
        public static final int move_lake_rowing_mover = 0x7f1100ce;

        /* JADX INFO: Added by JADX */
        public static final int move_lake_rowing_name = 0x7f1100cf;

        /* JADX INFO: Added by JADX */
        public static final int move_lake_rowing_pace = 0x7f1100d0;

        /* JADX INFO: Added by JADX */
        public static final int move_mat_tumbling_kit = 0x7f1100d1;

        /* JADX INFO: Added by JADX */
        public static final int move_mat_tumbling_mover = 0x7f1100d2;

        /* JADX INFO: Added by JADX */
        public static final int move_mat_tumbling_name = 0x7f1100d3;

        /* JADX INFO: Added by JADX */
        public static final int move_mat_tumbling_pace = 0x7f1100d4;

        /* JADX INFO: Added by JADX */
        public static final int move_ping_pong_rally_kit = 0x7f1100d5;

        /* JADX INFO: Added by JADX */
        public static final int move_ping_pong_rally_mover = 0x7f1100d6;

        /* JADX INFO: Added by JADX */
        public static final int move_ping_pong_rally_name = 0x7f1100d7;

        /* JADX INFO: Added by JADX */
        public static final int move_ping_pong_rally_pace = 0x7f1100d8;

        /* JADX INFO: Added by JADX */
        public static final int move_push_mowing_kit = 0x7f1100d9;

        /* JADX INFO: Added by JADX */
        public static final int move_push_mowing_mover = 0x7f1100da;

        /* JADX INFO: Added by JADX */
        public static final int move_push_mowing_name = 0x7f1100db;

        /* JADX INFO: Added by JADX */
        public static final int move_push_mowing_pace = 0x7f1100dc;

        /* JADX INFO: Added by JADX */
        public static final int move_raking_leaves_kit = 0x7f1100dd;

        /* JADX INFO: Added by JADX */
        public static final int move_raking_leaves_mover = 0x7f1100de;

        /* JADX INFO: Added by JADX */
        public static final int move_raking_leaves_name = 0x7f1100df;

        /* JADX INFO: Added by JADX */
        public static final int move_raking_leaves_pace = 0x7f1100e0;

        /* JADX INFO: Added by JADX */
        public static final int move_rough_trail_hike_kit = 0x7f1100e1;

        /* JADX INFO: Added by JADX */
        public static final int move_rough_trail_hike_mover = 0x7f1100e2;

        /* JADX INFO: Added by JADX */
        public static final int move_rough_trail_hike_name = 0x7f1100e3;

        /* JADX INFO: Added by JADX */
        public static final int move_rough_trail_hike_pace = 0x7f1100e4;

        /* JADX INFO: Added by JADX */
        public static final int move_scrubbing_bathtub_kit = 0x7f1100e5;

        /* JADX INFO: Added by JADX */
        public static final int move_scrubbing_bathtub_mover = 0x7f1100e6;

        /* JADX INFO: Added by JADX */
        public static final int move_scrubbing_bathtub_name = 0x7f1100e7;

        /* JADX INFO: Added by JADX */
        public static final int move_scrubbing_bathtub_pace = 0x7f1100e8;

        /* JADX INFO: Added by JADX */
        public static final int move_shadow_boxing_kit = 0x7f1100e9;

        /* JADX INFO: Added by JADX */
        public static final int move_shadow_boxing_mover = 0x7f1100ea;

        /* JADX INFO: Added by JADX */
        public static final int move_shadow_boxing_name = 0x7f1100eb;

        /* JADX INFO: Added by JADX */
        public static final int move_shadow_boxing_pace = 0x7f1100ec;

        /* JADX INFO: Added by JADX */
        public static final int move_shovelling_snow_kit = 0x7f1100ed;

        /* JADX INFO: Added by JADX */
        public static final int move_shovelling_snow_mover = 0x7f1100ee;

        /* JADX INFO: Added by JADX */
        public static final int move_shovelling_snow_name = 0x7f1100ef;

        /* JADX INFO: Added by JADX */
        public static final int move_shovelling_snow_pace = 0x7f1100f0;

        /* JADX INFO: Added by JADX */
        public static final int move_skateboard_flat_kit = 0x7f1100f1;

        /* JADX INFO: Added by JADX */
        public static final int move_skateboard_flat_mover = 0x7f1100f2;

        /* JADX INFO: Added by JADX */
        public static final int move_skateboard_flat_name = 0x7f1100f3;

        /* JADX INFO: Added by JADX */
        public static final int move_skateboard_flat_pace = 0x7f1100f4;

        /* JADX INFO: Added by JADX */
        public static final int move_small_wave_surf_kit = 0x7f1100f5;

        /* JADX INFO: Added by JADX */
        public static final int move_small_wave_surf_mover = 0x7f1100f6;

        /* JADX INFO: Added by JADX */
        public static final int move_small_wave_surf_name = 0x7f1100f7;

        /* JADX INFO: Added by JADX */
        public static final int move_small_wave_surf_pace = 0x7f1100f8;

        /* JADX INFO: Added by JADX */
        public static final int move_stairwell_climb_kit = 0x7f1100f9;

        /* JADX INFO: Added by JADX */
        public static final int move_stairwell_climb_mover = 0x7f1100fa;

        /* JADX INFO: Added by JADX */
        public static final int move_stairwell_climb_name = 0x7f1100fb;

        /* JADX INFO: Added by JADX */
        public static final int move_stairwell_climb_pace = 0x7f1100fc;

        /* JADX INFO: Added by JADX */
        public static final int move_steady_jog_kit = 0x7f1100fd;

        /* JADX INFO: Added by JADX */
        public static final int move_steady_jog_mover = 0x7f1100fe;

        /* JADX INFO: Added by JADX */
        public static final int move_steady_jog_name = 0x7f1100ff;

        /* JADX INFO: Added by JADX */
        public static final int move_steady_jog_pace = 0x7f110100;

        /* JADX INFO: Added by JADX */
        public static final int move_treading_water_kit = 0x7f110101;

        /* JADX INFO: Added by JADX */
        public static final int move_treading_water_mover = 0x7f110102;

        /* JADX INFO: Added by JADX */
        public static final int move_treading_water_name = 0x7f110103;

        /* JADX INFO: Added by JADX */
        public static final int move_treading_water_pace = 0x7f110104;

        /* JADX INFO: Added by JADX */
        public static final int move_vacuuming_hallway_kit = 0x7f110105;

        /* JADX INFO: Added by JADX */
        public static final int move_vacuuming_hallway_mover = 0x7f110106;

        /* JADX INFO: Added by JADX */
        public static final int move_vacuuming_hallway_name = 0x7f110107;

        /* JADX INFO: Added by JADX */
        public static final int move_vacuuming_hallway_pace = 0x7f110108;

        /* JADX INFO: Added by JADX */
        public static final int move_washing_dishes_kit = 0x7f110109;

        /* JADX INFO: Added by JADX */
        public static final int move_washing_dishes_mover = 0x7f11010a;

        /* JADX INFO: Added by JADX */
        public static final int move_washing_dishes_name = 0x7f11010b;

        /* JADX INFO: Added by JADX */
        public static final int move_washing_dishes_pace = 0x7f11010c;

        /* JADX INFO: Added by JADX */
        public static final int move_yoga_flow_kit = 0x7f11010d;

        /* JADX INFO: Added by JADX */
        public static final int move_yoga_flow_mover = 0x7f11010e;

        /* JADX INFO: Added by JADX */
        public static final int move_yoga_flow_name = 0x7f11010f;

        /* JADX INFO: Added by JADX */
        public static final int move_yoga_flow_pace = 0x7f110110;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_badge_numberless_content_description = 0x7f110111;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_checked = 0x7f110112;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_group_name = 0x7f110113;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_indeterminate = 0x7f110114;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_icon_path_name = 0x7f110115;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_checked = 0x7f110116;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_group_name = 0x7f110117;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_name = 0x7f110118;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_button_path_unchecked = 0x7f110119;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_checked = 0x7f11011a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_indeterminate = 0x7f11011b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_checkbox_state_description_unchecked = 0x7f11011c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_chip_close_icon_content_description = 0x7f11011d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exceed_max_badge_number_content_description = 0x7f11011e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_exceed_max_badge_number_suffix = 0x7f11011f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_a11y_next_month = 0x7f110120;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_a11y_prev_month = 0x7f110121;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_range_selection = 0x7f110122;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_selection = 0x7f110123;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_announce_current_selection_none = 0x7f110124;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_cancel = 0x7f110125;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_confirm = 0x7f110126;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_selected = 0x7f110127;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_title = 0x7f110128;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_date_header_unselected = 0x7f110129;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_day_of_week_column_header = 0x7f11012a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_end_date_description = 0x7f11012b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format = 0x7f11012c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format_example = 0x7f11012d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_format_use = 0x7f11012e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_invalid_range = 0x7f11012f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_navigate_to_current_year_description = 0x7f110130;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_navigate_to_year_description = 0x7f110131;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_out_of_range = 0x7f110132;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_only_end_selected = 0x7f110133;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_only_start_selected = 0x7f110134;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_selected = 0x7f110135;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_range_header_unselected = 0x7f110137;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_save = 0x7f110138;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_start_date_description = 0x7f110139;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_hint = 0x7f11013a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range_end_hint = 0x7f11013b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_date_range_start_hint = 0x7f11013c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_day_abbr = 0x7f11013d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_month_abbr = 0x7f11013e;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_text_input_year_abbr = 0x7f11013f;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_today_description = 0x7f110140;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_calendar_input_mode = 0x7f110141;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_day_selection = 0x7f110142;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_text_input_mode = 0x7f110143;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_picker_toggle_to_year_selection = 0x7f110144;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_group_name = 0x7f110145;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_checked = 0x7f110146;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_morphing = 0x7f110147;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_name = 0x7f110148;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_pressed = 0x7f110149;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_thumb_path_unchecked = 0x7f11014a;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_decoration_path = 0x7f11014b;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_switch_track_path = 0x7f11014c;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_timepicker_cancel = 0x7f11014d;

        /* JADX INFO: Added by JADX */
        public static final int mtrl_timepicker_confirm = 0x7f11014e;

        /* JADX INFO: Added by JADX */
        public static final int nav_app_bar_navigate_up_description = 0x7f11014f;

        /* JADX INFO: Added by JADX */
        public static final int nav_app_bar_open_drawer_description = 0x7f110150;

        /* JADX INFO: Added by JADX */
        public static final int nav_furnace = 0x7f110151;

        /* JADX INFO: Added by JADX */
        public static final int nav_index = 0x7f110152;

        /* JADX INFO: Added by JADX */
        public static final int nav_log = 0x7f110153;

        /* JADX INFO: Added by JADX */
        public static final int nav_weigh = 0x7f110154;

        /* JADX INFO: Added by JADX */
        public static final int password_toggle_content_description = 0x7f110155;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye = 0x7f110156;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye_mask_strike_through = 0x7f110157;

        /* JADX INFO: Added by JADX */
        public static final int path_password_eye_mask_visible = 0x7f110158;

        /* JADX INFO: Added by JADX */
        public static final int path_password_strike_through = 0x7f110159;

        /* JADX INFO: Added by JADX */
        public static final int screen_effort_sheet = 0x7f11015a;

        /* JADX INFO: Added by JADX */
        public static final int screen_furnace_floor = 0x7f11015b;

        /* JADX INFO: Added by JADX */
        public static final int screen_motion_index = 0x7f11015c;

        /* JADX INFO: Added by JADX */
        public static final int screen_stoker_log = 0x7f11015d;

        /* JADX INFO: Added by JADX */
        public static final int screen_twin_weigh = 0x7f11015e;

        /* JADX INFO: Added by JADX */
        public static final int search_menu_title = 0x7f11015f;

        /* JADX INFO: Added by JADX */
        public static final int searchbar_scrolling_view_behavior = 0x7f110160;

        /* JADX INFO: Added by JADX */
        public static final int searchview_clear_text_content_description = 0x7f110161;

        /* JADX INFO: Added by JADX */
        public static final int searchview_navigation_content_description = 0x7f110162;

        /* JADX INFO: Added by JADX */
        public static final int sheet_burn_line = 0x7f110163;

        /* JADX INFO: Added by JADX */
        public static final int sheet_copy_done = 0x7f110164;

        /* JADX INFO: Added by JADX */
        public static final int sheet_copy_line = 0x7f110165;

        /* JADX INFO: Added by JADX */
        public static final int sheet_keep = 0x7f110166;

        /* JADX INFO: Added by JADX */
        public static final int sheet_last_go_label = 0x7f110167;

        /* JADX INFO: Added by JADX */
        public static final int sheet_last_go_unset = 0x7f110168;

        /* JADX INFO: Added by JADX */
        public static final int sheet_measured_heading = 0x7f110169;

        /* JADX INFO: Added by JADX */
        public static final int sheet_pace_heading = 0x7f11016a;

        /* JADX INFO: Added by JADX */
        public static final int sheet_recap_hint = 0x7f11016b;

        /* JADX INFO: Added by JADX */
        public static final int sheet_recap_label = 0x7f11016c;

        /* JADX INFO: Added by JADX */
        public static final int sheet_recap_save = 0x7f11016d;

        /* JADX INFO: Added by JADX */
        public static final int sheet_recap_saved = 0x7f11016e;

        /* JADX INFO: Added by JADX */
        public static final int sheet_row_band = 0x7f11016f;

        /* JADX INFO: Added by JADX */
        public static final int sheet_row_half_hour = 0x7f110170;

        /* JADX INFO: Added by JADX */
        public static final int sheet_row_kit = 0x7f110171;

        /* JADX INFO: Added by JADX */
        public static final int sheet_row_mover = 0x7f110172;

        /* JADX INFO: Added by JADX */
        public static final int sheet_row_scale = 0x7f110173;

        /* JADX INFO: Added by JADX */
        public static final int sheet_tried = 0x7f110174;

        /* JADX INFO: Added by JADX */
        public static final int sheet_yours_heading = 0x7f110175;

        /* JADX INFO: Added by JADX */
        public static final int side_sheet_accessibility_pane_title = 0x7f110176;

        /* JADX INFO: Added by JADX */
        public static final int side_sheet_behavior = 0x7f110177;

        /* JADX INFO: Added by JADX */
        public static final int splash_error_message = 0x7f110178;

        /* JADX INFO: Added by JADX */
        public static final int splash_error_title = 0x7f110179;

        /* JADX INFO: Added by JADX */
        public static final int splash_loading = 0x7f11017a;

        /* JADX INFO: Added by JADX */
        public static final int splash_retry = 0x7f11017b;

        /* JADX INFO: Added by JADX */
        public static final int tag_household = 0x7f11017d;

        /* JADX INFO: Added by JADX */
        public static final int tag_roadwork = 0x7f11017e;

        /* JADX INFO: Added by JADX */
        public static final int tag_studio = 0x7f11017f;

        /* JADX INFO: Added by JADX */
        public static final int tag_water = 0x7f110180;

        /* JADX INFO: Added by JADX */
        public static final int tag_yard = 0x7f110181;

        /* JADX INFO: Added by JADX */
        public static final int unit_met = 0x7f110182;

        /* JADX INFO: Added by JADX */
        public static final int weigh_clear = 0x7f110183;

        /* JADX INFO: Added by JADX */
        public static final int weigh_count = 0x7f110184;

        /* JADX INFO: Added by JADX */
        public static final int weigh_empty_pan = 0x7f110185;

        /* JADX INFO: Added by JADX */
        public static final int weigh_left_pan = 0x7f110186;

        /* JADX INFO: Added by JADX */
        public static final int weigh_picker_title = 0x7f110187;

        /* JADX INFO: Added by JADX */
        public static final int weigh_right_pan = 0x7f110188;

        /* JADX INFO: Added by JADX */
        public static final int weigh_swap = 0x7f110189;

        /* JADX INFO: Added by JADX */
        public static final int weigh_table_heading = 0x7f11018a;

        /* JADX INFO: Added by JADX */
        public static final int weigh_verdict = 0x7f11018b;

        /* JADX INFO: Added by JADX */
        public static final int weigh_verdict_level = 0x7f11018c;

        /* JADX INFO: Added by JADX */
        public static final int weigh_verdict_waiting = 0x7f11018d;
    }

    public static final class style {

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat = 0x7f120000;

        /* JADX INFO: Added by JADX */
        public static final int AlertDialog_AppCompat_Light = 0x7f120001;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_Dialog = 0x7f120002;

        /* JADX INFO: Added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 0x7f120003;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Design_BottomSheetDialog = 0x7f120005;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_BottomSheetDialog = 0x7f120006;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog = 0x7f120007;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog_Left = 0x7f120008;

        /* JADX INFO: Added by JADX */
        public static final int Animation_Material3_SideSheetDialog_Right = 0x7f120009;

        /* JADX INFO: Added by JADX */
        public static final int Animation_MaterialComponents_BottomSheetDialog = 0x7f12000a;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat = 0x7f12000b;

        /* JADX INFO: Added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 0x7f12000c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 0x7f12000d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 0x7f12000e;

        /* JADX INFO: Added by JADX */
        public static final int Base_CardView = 0x7f120010;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 0x7f120011;

        /* JADX INFO: Added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 0x7f120012;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f120013;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f120014;

        /* JADX INFO: Added by JADX */
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f120015;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat = 0x7f120016;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f120017;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f120018;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f120019;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f12001a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f12001b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f12001c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f12001d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f12001e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f12001f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f120020;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f120021;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f120022;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f120025;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f120026;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f120027;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f120029;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f12002a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f12002b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f12002c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f12002d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f12002e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f12002f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f120030;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f120032;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f120033;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f120034;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f120035;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f120036;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f120037;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f120038;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 0x7f120039;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f12003a;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 0x7f12003b;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f12003c;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f12003d;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f12003e;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f12003f;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f120040;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f120041;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f120042;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Material3_Search = 0x7f120043;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Badge = 0x7f120044;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Button = 0x7f120045;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Headline6 = 0x7f120046;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_MaterialComponents_Subtitle2 = 0x7f120047;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f120048;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f120049;

        /* JADX INFO: Added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f12004a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat = 0x7f12004b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f12004c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 0x7f12004d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 0x7f12004e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f12004f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f120050;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f120051;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light = 0x7f120052;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f120053;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f120054;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f120055;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f120056;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f120057;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f120058;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_Material3_Light = 0x7f12005f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents = 0x7f120065;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Bridge = 0x7f120066;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_CompactMenu = 0x7f120067;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog = 0x7f120068;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_Alert = 0x7f120069;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_Bridge = 0x7f12006a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_FixedSize = 0x7f12006b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Dialog_MinWidth = 0x7f12006c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_DialogWhenLarge = 0x7f12006d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light = 0x7f12006e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Bridge = 0x7f12006f;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar = 0x7f120070;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f120071;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog = 0x7f120072;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Alert = 0x7f120073;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f120074;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f120075;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f120076;

        /* JADX INFO: Added by JADX */
        public static final int Base_Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f120077;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 0x7f120078;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f120079;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f12007a;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f12007b;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 0x7f12007c;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 0x7f12007d;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f12007e;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_AutoCompleteTextView = 0x7f12007f;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_BottomSheetDialog = 0x7f120080;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_Dialog = 0x7f120081;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_SideSheetDialog = 0x7f120082;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_Material3_TextInputEditText = 0x7f120083;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog = 0x7f120084;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f120085;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f120086;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f120087;

        /* JADX INFO: Added by JADX */
        public static final int Base_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f120088;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_Material3_Light = 0x7f12008d;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents = 0x7f120091;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Bridge = 0x7f120092;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Dialog = 0x7f120093;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Dialog_Bridge = 0x7f120094;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light = 0x7f120095;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Bridge = 0x7f120096;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f120097;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog = 0x7f120098;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f120099;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_Material3_BottomSheetDialog = 0x7f12009a;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_Material3_SideSheetDialog = 0x7f12009b;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f12009c;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog = 0x7f12009d;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f12009e;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f12009f;

        /* JADX INFO: Added by JADX */
        public static final int Base_V14_Widget_MaterialComponents_AutoCompleteTextView = 0x7f1200a0;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat = 0x7f1200a1;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f1200a2;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f1200a3;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f1200a4;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents = 0x7f1200a5;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Dialog = 0x7f1200a6;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Light = 0x7f1200a7;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_Theme_MaterialComponents_Light_Dialog = 0x7f1200a8;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 0x7f1200a9;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_Material3_BottomSheetDialog = 0x7f1200aa;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_Material3_SideSheetDialog = 0x7f1200ab;

        /* JADX INFO: Added by JADX */
        public static final int Base_V21_ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f1200ac;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat = 0x7f1200ad;

        /* JADX INFO: Added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 0x7f1200ae;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat = 0x7f1200af;

        /* JADX INFO: Added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 0x7f1200b0;

        /* JADX INFO: Added by JADX */
        public static final int Base_V24_Theme_Material3_Light = 0x7f1200b3;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat = 0x7f1200b5;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 0x7f1200b6;

        /* JADX INFO: Added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 0x7f1200b7;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat = 0x7f1200b8;

        /* JADX INFO: Added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 0x7f1200b9;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat = 0x7f1200ba;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f1200bb;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f1200bc;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f1200bd;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 0x7f1200be;

        /* JADX INFO: Added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 0x7f1200c1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f1200c2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f1200c3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f1200c4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f1200c5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f1200c6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f1200c7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f1200c8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f1200c9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f1200ca;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f1200cb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f1200cc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button = 0x7f1200cd;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 0x7f1200ce;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f1200cf;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f1200d0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 0x7f1200d2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 0x7f1200d3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f1200d4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f1200d5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f1200d6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f1200d7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f1200d8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f1200d9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f1200da;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 0x7f1200db;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 0x7f1200dc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f1200dd;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f1200de;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f1200df;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f1200e0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f1200e2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f1200e3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f1200e4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 0x7f1200e5;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f1200e6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 0x7f1200e7;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f1200e8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f1200e9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f1200ea;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f1200eb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 0x7f1200ef;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 0x7f1200f0;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 0x7f1200f1;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 0x7f1200f2;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f1200f3;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 0x7f1200f4;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 0x7f1200f6;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 0x7f1200f8;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f1200f9;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f1200fa;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f1200fb;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Design_TabLayout = 0x7f1200fc;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ActionMode = 0x7f1200fe;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_BottomNavigationView = 0x7f1200ff;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CardView = 0x7f120100;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Chip = 0x7f120101;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CollapsingToolbar = 0x7f120102;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_CheckBox = 0x7f120103;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_RadioButton = 0x7f120104;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_CompoundButton_Switch = 0x7f120105;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton = 0x7f120106;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_ExtendedFloatingActionButton_Icon = 0x7f120107;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton = 0x7f120108;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton_Large = 0x7f120109;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_FloatingActionButton_Small = 0x7f12010a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Light_ActionBar_Solid = 0x7f12010b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_MaterialCalendar_NavigationButton = 0x7f12010c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_Snackbar = 0x7f12010d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_TabLayout = 0x7f12010e;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_Material3_TabLayout_Secondary = 0x7f120110;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_AutoCompleteTextView = 0x7f120111;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_CheckedTextView = 0x7f120112;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Chip = 0x7f120113;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f120114;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_MaterialCalendar_NavigationButton = 0x7f120115;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu = 0x7f120116;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f120117;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f120118;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_PopupMenu_Overflow = 0x7f120119;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Slider = 0x7f12011a;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_Snackbar = 0x7f12011b;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextInputEditText = 0x7f12011c;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextInputLayout = 0x7f12011d;

        /* JADX INFO: Added by JADX */
        public static final int Base_Widget_MaterialComponents_TextView = 0x7f12011e;

        /* JADX INFO: Added by JADX */
        public static final int CardView = 0x7f12011f;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3 = 0x7f120122;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Animation = 0x7f120123;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Body_Text = 0x7f120124;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Icon = 0x7f120126;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Panel = 0x7f120128;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_Material3_Title_Text = 0x7f12012a;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents = 0x7f12012c;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Body_Text = 0x7f12012d;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f120130;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f120132;

        /* JADX INFO: Added by JADX */
        public static final int MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f120134;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat = 0x7f120136;

        /* JADX INFO: Added by JADX */
        public static final int Platform_AppCompat_Light = 0x7f120137;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents = 0x7f120138;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Dialog = 0x7f120139;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Light = 0x7f12013a;

        /* JADX INFO: Added by JADX */
        public static final int Platform_MaterialComponents_Light_Dialog = 0x7f12013b;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 0x7f12013c;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 0x7f12013d;

        /* JADX INFO: Added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 0x7f12013e;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat = 0x7f120141;

        /* JADX INFO: Added by JADX */
        public static final int Platform_V25_AppCompat_Light = 0x7f120142;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f120144;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f120145;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f120147;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f120148;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 0x7f120149;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 0x7f12014a;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f12014b;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 0x7f12014c;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f12014d;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f12014e;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f12014f;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f120150;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f120151;

        /* JADX INFO: Added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f120152;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Badge_Shape = 0x7f120156;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_DatePicker_Modal_Date_Container_Shape = 0x7f120158;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_FilledButton_Container_Shape = 0x7f120159;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavigationBar_ActiveIndicator_Shape = 0x7f12015a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavigationBar_Container_Shape = 0x7f12015b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavigationRail_ActiveIndicator_Shape = 0x7f12015d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_NavigationRail_Container_Shape = 0x7f12015e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchBar_Container_Shape = 0x7f120160;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_SearchView_FullScreen_Container_Shape = 0x7f120161;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_Sheet_Side_Docked_Container_Shape = 0x7f120162;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Comp_TextButton_Container_Shape = 0x7f120166;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraLarge = 0x7f120167;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_ExtraSmall = 0x7f120168;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Full = 0x7f120169;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Large = 0x7f12016a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Medium = 0x7f12016b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_None = 0x7f12016c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_M3_Sys_Shape_Corner_Small = 0x7f12016d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraLarge = 0x7f12016e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_ExtraSmall = 0x7f12016f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Full = 0x7f120170;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Large = 0x7f120171;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Medium = 0x7f120172;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_None = 0x7f120173;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Corner_Small = 0x7f120174;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_LargeComponent = 0x7f120175;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_MediumComponent = 0x7f120176;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_SmallComponent = 0x7f120178;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_Material3_Tooltip = 0x7f120179;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents = 0x7f12017a;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_Badge = 0x7f12017b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_LargeComponent = 0x7f12017c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_MediumComponent = 0x7f12017d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_SmallComponent = 0x7f12017e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearance_MaterialComponents_Tooltip = 0x7f12017f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_Corner_Top = 0x7f120185;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_SearchBar = 0x7f120188;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_Material3_SearchView = 0x7f120189;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_BottomSheet = 0x7f12018b;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_Chip = 0x7f12018c;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_ExtendedFloatingActionButton = 0x7f12018d;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_FloatingActionButton = 0x7f12018e;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day = 0x7f12018f;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Window_Fullscreen = 0x7f120190;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Year = 0x7f120191;

        /* JADX INFO: Added by JADX */
        public static final int ShapeAppearanceOverlay_MaterialComponents_TextInputLayout_FilledBox = 0x7f120192;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat = 0x7f120193;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 0x7f120194;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 0x7f120195;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Button = 0x7f120196;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 0x7f120197;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 0x7f120198;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 0x7f120199;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 0x7f12019a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 0x7f12019b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 0x7f12019c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 0x7f12019d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large = 0x7f12019e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f12019f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f1201a0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f1201a1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f1201a2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f1201a3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 0x7f1201a4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f1201a5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 0x7f1201a6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f1201a7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f1201a8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small = 0x7f1201a9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f1201aa;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 0x7f1201ab;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f1201ac;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title = 0x7f1201ad;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f1201ae;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 0x7f1201af;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f1201b0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f1201b1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f1201b2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f1201b3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f1201b4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f1201b5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f1201b6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f1201b7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f1201b8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 0x7f1201b9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f1201ba;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 0x7f1201bb;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f1201bc;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f1201bd;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f1201be;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f1201bf;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f1201c0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f1201c1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f1201c2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 0x7f1201c3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 0x7f1201c4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f1201c5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 0x7f1201c6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 0x7f1201c7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_CollapsingToolbar_Expanded = 0x7f1201c8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Counter = 0x7f1201c9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Counter_Overflow = 0x7f1201ca;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Error = 0x7f1201cb;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_HelperText = 0x7f1201cc;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Hint = 0x7f1201cd;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Placeholder = 0x7f1201ce;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Prefix = 0x7f1201cf;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Snackbar_Message = 0x7f1201d0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Suffix = 0x7f1201d1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Design_Tab = 0x7f1201d2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_BodyMedium = 0x7f1201d3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_BodySmall = 0x7f1201d4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_Figure = 0x7f1201d5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_HeadlineMedium = 0x7f1201d6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_LabelLarge = 0x7f1201d7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_LabelMedium = 0x7f1201d8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_LabelSmall = 0x7f1201d9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_Mark = 0x7f1201da;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_MarkHero = 0x7f1201db;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_TitleLarge = 0x7f1201dc;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_EmberGauge_TitleMedium = 0x7f1201dd;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyLarge = 0x7f1201de;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodyMedium = 0x7f1201df;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_BodySmall = 0x7f1201e0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayLarge = 0x7f1201e1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplayMedium = 0x7f1201e2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_DisplaySmall = 0x7f1201e3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineLarge = 0x7f1201e4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineMedium = 0x7f1201e5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_HeadlineSmall = 0x7f1201e6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelLarge = 0x7f1201e7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelMedium = 0x7f1201e8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_LabelSmall = 0x7f1201e9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleLarge = 0x7f1201ea;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleMedium = 0x7f1201eb;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_M3_Sys_Typescale_TitleSmall = 0x7f1201ec;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_ActionBar_Subtitle = 0x7f1201ed;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_ActionBar_Title = 0x7f1201ee;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyLarge = 0x7f1201ef;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodyMedium = 0x7f1201f0;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_BodySmall = 0x7f1201f1;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayLarge = 0x7f1201f2;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplayMedium = 0x7f1201f3;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_DisplaySmall = 0x7f1201f4;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineLarge = 0x7f1201f5;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineMedium = 0x7f1201f6;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_HeadlineSmall = 0x7f1201f7;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelLarge = 0x7f1201f8;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelMedium = 0x7f1201f9;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_LabelSmall = 0x7f1201fa;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_MaterialTimePicker_Title = 0x7f1201fb;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchBar = 0x7f1201fc;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchView = 0x7f1201fd;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_SearchView_Prefix = 0x7f1201fe;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleLarge = 0x7f1201ff;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleMedium = 0x7f120200;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Material3_TitleSmall = 0x7f120201;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Badge = 0x7f120202;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Body1 = 0x7f120203;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Body2 = 0x7f120204;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Button = 0x7f120205;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Caption = 0x7f120206;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Chip = 0x7f120207;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline1 = 0x7f120208;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline2 = 0x7f120209;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline3 = 0x7f12020a;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline4 = 0x7f12020b;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline5 = 0x7f12020c;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Headline6 = 0x7f12020d;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Overline = 0x7f12020e;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Subtitle1 = 0x7f12020f;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Subtitle2 = 0x7f120210;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_TimePicker_Title = 0x7f120211;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_MaterialComponents_Tooltip = 0x7f120212;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f120213;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f120214;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f120215;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat = 0x7f120216;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 0x7f120217;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight = 0x7f120218;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 0x7f120219;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 0x7f12021a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 0x7f12021b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 0x7f12021c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 0x7f12021d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 0x7f12021e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog = 0x7f12021f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 0x7f120220;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 0x7f120221;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f120222;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Empty = 0x7f120223;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light = 0x7f120224;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f120225;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 0x7f120226;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 0x7f120227;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f120228;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f120229;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f12022a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 0x7f12022b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Design_Light_BottomSheetDialog = 0x7f12022f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_EmberGauge = 0x7f120232;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light = 0x7f120249;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Material3_Light_NoActionBar = 0x7f12024f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents = 0x7f120251;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_BottomSheetDialog = 0x7f120252;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Bridge = 0x7f120253;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_CompactMenu = 0x7f120254;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight = 0x7f120255;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_BottomSheetDialog = 0x7f120256;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Bridge = 0x7f120257;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar = 0x7f120258;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar_Bridge = 0x7f120259;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog = 0x7f12025a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert = 0x7f12025b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge = 0x7f12025c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_Bridge = 0x7f12025d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize = 0x7f12025e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge = 0x7f12025f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth = 0x7f120260;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge = 0x7f120261;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_DialogWhenLarge = 0x7f120262;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_NoActionBar = 0x7f120263;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DayNight_NoActionBar_Bridge = 0x7f120264;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog = 0x7f120265;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Alert = 0x7f120266;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Alert_Bridge = 0x7f120267;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_Bridge = 0x7f120268;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FixedSize = 0x7f120269;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_FixedSize_Bridge = 0x7f12026a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_MinWidth = 0x7f12026b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Dialog_MinWidth_Bridge = 0x7f12026c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_DialogWhenLarge = 0x7f12026d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light = 0x7f12026e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_BottomSheetDialog = 0x7f12026f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Bridge = 0x7f120270;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DarkActionBar = 0x7f120271;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f120272;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog = 0x7f120273;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Alert = 0x7f120274;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Alert_Bridge = 0x7f120275;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f120276;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f120277;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge = 0x7f120278;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f120279;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge = 0x7f12027a;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f12027b;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_NoActionBar = 0x7f12027c;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_Light_NoActionBar_Bridge = 0x7f12027d;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_NoActionBar = 0x7f12027e;

        /* JADX INFO: Added by JADX */
        public static final int Theme_MaterialComponents_NoActionBar_Bridge = 0x7f12027f;

        /* JADX INFO: Added by JADX */
        public static final int Theme_Splash = 0x7f120280;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f120282;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f120283;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f120284;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 0x7f120287;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 0x7f120288;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 0x7f120289;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Design_TextInputEditText = 0x7f12028a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView = 0x7f12028d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_FilledBox = 0x7f12028e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_AutoCompleteTextView_OutlinedBox = 0x7f120290;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomAppBar = 0x7f120292;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomNavigationView = 0x7f120294;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_BottomSheetDialog = 0x7f120295;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button = 0x7f120296;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton = 0x7f120298;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton_Filled = 0x7f120299;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_IconButton_Filled_Tonal = 0x7f12029a;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TextButton = 0x7f12029b;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TextButton_Snackbar = 0x7f12029c;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Button_TonalButton = 0x7f12029d;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Chip = 0x7f12029e;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Chip_Assist = 0x7f12029f;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dialog = 0x7f1202a4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Dialog_Alert = 0x7f1202a5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_DynamicColors_Light = 0x7f1202a9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Primary = 0x7f1202aa;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Secondary = 0x7f1202ab;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Surface = 0x7f1202ac;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_ExtendedFloatingActionButton_Tertiary = 0x7f1202ad;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Primary = 0x7f1202ae;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Secondary = 0x7f1202af;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Surface = 0x7f1202b0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_FloatingActionButton_Tertiary = 0x7f1202b1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Light = 0x7f1202b4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialAlertDialog = 0x7f1202b6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar = 0x7f1202b8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar_Fullscreen = 0x7f1202b9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialCalendar_HeaderCancelButton = 0x7f1202ba;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialTimePicker = 0x7f1202bb;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f1202bc;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_NavigationRailView = 0x7f1202bd;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_NavigationView = 0x7f1202be;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Search = 0x7f1202c0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_SideSheetDialog = 0x7f1202c1;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Snackbar = 0x7f1202c2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TabLayout = 0x7f1202c3;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText = 0x7f1202c4;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_FilledBox = 0x7f1202c5;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_FilledBox_Dense = 0x7f1202c6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_OutlinedBox = 0x7f1202c7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f1202c8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_Material3_Toolbar_Surface = 0x7f1202c9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialAlertDialog_Material3_Title_Icon = 0x7f1202ca;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_ActionBar_Surface = 0x7f1202ce;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView = 0x7f1202cf;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f1202d0;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f1202d2;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f1202d6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dark = 0x7f1202d7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dark_ActionBar = 0x7f1202d8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog = 0x7f1202da;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f1202db;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f1202dc;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Light = 0x7f1202dd;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f1202de;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f1202df;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar = 0x7f1202e6;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f1202e7;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText = 0x7f1202e8;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox = 0x7f1202e9;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f1202ea;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f1202eb;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f1202ec;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker = 0x7f1202ed;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker_Display = 0x7f1202ee;

        /* JADX INFO: Added by JADX */
        public static final int ThemeOverlay_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f1202ef;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f1202f4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f1202f5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f1202f6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f1202f7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton = 0x7f1202f8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f1202f9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f1202fa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActionMode = 0x7f1202fb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f1202fc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f1202fd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button = 0x7f1202fe;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 0x7f1202ff;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 0x7f120300;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f120301;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Button_Small = 0x7f120303;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 0x7f120304;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f120305;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 0x7f120306;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 0x7f120307;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f120308;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f120309;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f12030a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_EditText = 0x7f12030b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ImageButton = 0x7f12030c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f12030e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f120310;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f120312;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f120314;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f120316;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f120318;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f12031f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f120320;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 0x7f120321;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f120322;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 0x7f120323;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f120324;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView = 0x7f120325;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f120326;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 0x7f120327;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 0x7f120328;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f120329;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar = 0x7f12032d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 0x7f12032e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 0x7f12032f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView = 0x7f120330;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 0x7f120331;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_SeekBar = 0x7f120332;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner = 0x7f120334;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f120335;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f120336;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView = 0x7f120338;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 0x7f120339;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar = 0x7f12033a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f12033b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 0x7f12033c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 0x7f12033d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_AppBarLayout = 0x7f12033e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_BottomNavigationView = 0x7f12033f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_BottomSheet_Modal = 0x7f120340;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_CollapsingToolbar = 0x7f120341;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_FloatingActionButton = 0x7f120342;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_NavigationView = 0x7f120343;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_ScrimInsetsFrameLayout = 0x7f120344;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_Snackbar = 0x7f120345;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TabLayout = 0x7f120346;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TextInputEditText = 0x7f120347;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Design_TextInputLayout = 0x7f120348;

        /* JADX INFO: Added by JADX */
        public static final int Widget_EmberGauge_SectionCard = 0x7f120349;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ActionMode = 0x7f12034b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AppBarLayout = 0x7f12034c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_FilledBox = 0x7f12034d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_AutoCompleteTextView_OutlinedBox = 0x7f12034f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Badge = 0x7f120351;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Badge_AdjustToBounds = 0x7f120352;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomAppBar = 0x7f120353;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomAppBar_Button_Navigation = 0x7f120354;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigation_Badge = 0x7f120356;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigationView = 0x7f120357;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomNavigationView_ActiveIndicator = 0x7f120358;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet = 0x7f120359;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet_DragHandle = 0x7f12035a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_BottomSheet_Modal = 0x7f12035b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button = 0x7f12035c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton = 0x7f120360;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled = 0x7f120361;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Filled_Tonal = 0x7f120362;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_IconButton_Outlined = 0x7f120363;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_OutlinedButton = 0x7f120364;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton = 0x7f120366;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Dialog = 0x7f120367;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Dialog_Flush = 0x7f120368;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Button_TextButton_Snackbar = 0x7f12036b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Elevated = 0x7f12036f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Filled = 0x7f120370;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CardView_Outlined = 0x7f120371;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CheckedTextView = 0x7f120372;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Assist = 0x7f120373;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Chip_Input = 0x7f120377;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ChipGroup = 0x7f12037d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CircularProgressIndicator = 0x7f12037e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar = 0x7f120386;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar_Large = 0x7f120387;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CollapsingToolbar_Medium = 0x7f120388;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_CheckBox = 0x7f120389;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_MaterialSwitch = 0x7f12038a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_RadioButton = 0x7f12038b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_CompoundButton_Switch = 0x7f12038c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_DrawerLayout = 0x7f12038d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Primary = 0x7f12038e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Secondary = 0x7f12038f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Surface = 0x7f120390;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_ExtendedFloatingActionButton_Icon_Tertiary = 0x7f120391;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Primary = 0x7f120396;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Secondary = 0x7f120397;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Surface = 0x7f120398;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Large_Tertiary = 0x7f120399;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Primary = 0x7f12039a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Secondary = 0x7f12039b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Primary = 0x7f12039c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Secondary = 0x7f12039d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Surface = 0x7f12039e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Small_Tertiary = 0x7f12039f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Surface = 0x7f1203a0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_FloatingActionButton_Tertiary = 0x7f1203a1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Light_ActionBar_Solid = 0x7f1203a2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_LinearProgressIndicator = 0x7f1203a3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialButtonToggleGroup = 0x7f1203a5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar = 0x7f1203a6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day = 0x7f1203a7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Invalid = 0x7f1203a8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Selected = 0x7f1203a9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Day_Today = 0x7f1203aa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_DayOfWeekLabel = 0x7f1203ab;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_DayTextView = 0x7f1203ac;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Fullscreen = 0x7f1203ad;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderCancelButton = 0x7f1203ae;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderDivider = 0x7f1203af;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderLayout = 0x7f1203b0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f1203b1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderSelection = 0x7f1203b2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f1203b3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderTitle = 0x7f1203b4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_HeaderToggleButton = 0x7f1203b5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Item = 0x7f1203b6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_MonthNavigationButton = 0x7f1203b7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_MonthTextView = 0x7f1203b8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year = 0x7f1203b9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year_Selected = 0x7f1203ba;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_Year_Today = 0x7f1203bb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialCalendar_YearNavigationButton = 0x7f1203bc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialDivider = 0x7f1203bd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialDivider_Heavy = 0x7f1203be;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker = 0x7f1203bf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Button = 0x7f1203c0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Clock = 0x7f1203c1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display = 0x7f1203c2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_Divider = 0x7f1203c3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_HelperText = 0x7f1203c4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f1203c5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_Display_TextInputLayout = 0x7f1203c6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_MaterialTimePicker_ImageButton = 0x7f1203c7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView = 0x7f1203c8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView_ActiveIndicator = 0x7f1203c9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationRailView_Badge = 0x7f1203ca;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_NavigationView = 0x7f1203cb;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu = 0x7f1203cc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_ContextMenu = 0x7f1203cd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_ListPopupWindow = 0x7f1203ce;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_PopupMenu_Overflow = 0x7f1203cf;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Search_ActionButton_Overflow = 0x7f1203d0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Search_Toolbar_Button_Navigation = 0x7f1203d1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchBar = 0x7f1203d2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView = 0x7f1203d4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView_Prefix = 0x7f1203d5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SearchView_Toolbar = 0x7f1203d6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet = 0x7f1203d7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_SideSheet_Modal = 0x7f1203d9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider = 0x7f1203db;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Slider_Label = 0x7f1203dc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Snackbar = 0x7f1203df;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Snackbar_TextView = 0x7f1203e1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TabLayout = 0x7f1203e2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TabLayout_Secondary = 0x7f1203e4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_FilledBox = 0x7f1203e5;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_FilledBox_Dense = 0x7f1203e6;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_OutlinedBox = 0x7f1203e7;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f1203e8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox = 0x7f1203e9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox_Dense = 0x7f1203ea;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f1203ec;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox = 0x7f1203ed;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox_Dense = 0x7f1203ee;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f1203f0;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar = 0x7f1203f1;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_OnSurface = 0x7f1203f2;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Toolbar_Surface = 0x7f1203f3;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Material3_Tooltip = 0x7f1203f4;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionBar_Surface = 0x7f1203f8;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ActionMode = 0x7f1203f9;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AppBarLayout_Primary = 0x7f1203fa;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AppBarLayout_Surface = 0x7f1203fc;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f1203fd;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f1203ff;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Badge = 0x7f120401;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomAppBar = 0x7f120402;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomNavigationView = 0x7f120405;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomSheet = 0x7f120408;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_BottomSheet_Modal = 0x7f120409;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button = 0x7f12040a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_OutlinedButton = 0x7f12040c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton = 0x7f12040e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog = 0x7f12040f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Flush = 0x7f120410;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_TextButton_Snackbar = 0x7f120413;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Button_UnelevatedButton = 0x7f120414;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CardView = 0x7f120416;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CheckedTextView = 0x7f120417;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Action = 0x7f120418;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Choice = 0x7f120419;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Chip_Entry = 0x7f12041a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ChipGroup = 0x7f12041c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CircularProgressIndicator = 0x7f12041d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CollapsingToolbar = 0x7f120421;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_CheckBox = 0x7f120422;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_RadioButton = 0x7f120423;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_CompoundButton_Switch = 0x7f120424;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton = 0x7f120425;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton_Icon = 0x7f120426;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_FloatingActionButton = 0x7f120427;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Light_ActionBar_Solid = 0x7f120428;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_LinearProgressIndicator = 0x7f120429;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialButtonToggleGroup = 0x7f12042a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar = 0x7f12042b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day = 0x7f12042c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Invalid = 0x7f12042d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Selected = 0x7f12042e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Today = 0x7f12042f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_DayOfWeekLabel = 0x7f120430;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_DayTextView = 0x7f120431;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f120432;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderCancelButton = 0x7f120433;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderConfirmButton = 0x7f120434;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderDivider = 0x7f120435;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderLayout = 0x7f120436;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f120437;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection = 0x7f120438;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f120439;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderTitle = 0x7f12043a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f12043b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Item = 0x7f12043c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_MonthNavigationButton = 0x7f12043d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_MonthTextView = 0x7f12043e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year = 0x7f12043f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Selected = 0x7f120440;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Today = 0x7f120441;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialCalendar_YearNavigationButton = 0x7f120442;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_MaterialDivider = 0x7f120443;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationRailView = 0x7f120444;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_NavigationView = 0x7f120449;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu = 0x7f12044a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f12044b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f12044c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_PopupMenu_Overflow = 0x7f12044d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_ProgressIndicator = 0x7f12044e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Slider = 0x7f120450;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Snackbar = 0x7f120451;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Snackbar_TextView = 0x7f120453;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TabLayout = 0x7f120454;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox = 0x7f120457;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f120458;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f120459;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f12045a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox = 0x7f12045b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense = 0x7f12045c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f12045e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox = 0x7f12045f;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense = 0x7f120460;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f120462;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TextView = 0x7f120463;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker = 0x7f120464;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Button = 0x7f120465;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Clock = 0x7f120466;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display = 0x7f120467;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_Divider = 0x7f120468;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_HelperText = 0x7f120469;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f12046a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_Display_TextInputLayout = 0x7f12046b;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_ImageButton = 0x7f12046c;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_TimePicker_ImageButton_ShapeAppearance = 0x7f12046d;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Toolbar = 0x7f12046e;

        /* JADX INFO: Added by JADX */
        public static final int Widget_MaterialComponents_Tooltip = 0x7f120472;
    }

    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int backup_rules = 0x7f140000;

        /* JADX INFO: Added by JADX */
        public static final int data_extraction_rules = 0x7f140001;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f140002;
    }
}
