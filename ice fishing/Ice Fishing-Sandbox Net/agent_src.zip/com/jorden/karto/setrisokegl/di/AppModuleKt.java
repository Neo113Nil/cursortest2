package com.jorden.karto.setrisokegl.di;

@kotlin.Metadata
@kotlin.jvm.internal.SourceDebugExtension
/* loaded from: classes.dex */
public final class AppModuleKt {

    /* renamed from: a, reason: collision with root package name */
    public static final org.koin.core.module.Module f3054a;

    static {
        androidx.room.c cVar = new androidx.room.c(13);
        org.koin.core.module.Module module = new org.koin.core.module.Module(false);
        cVar.m(module);
        f3054a = module;
    }
}
