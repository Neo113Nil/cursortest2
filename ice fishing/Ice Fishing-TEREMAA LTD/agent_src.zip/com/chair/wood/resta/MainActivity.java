package com.chair.wood.resta;

/* compiled from: r8-map-id-8830e4f931c147ea963aab9fad545643b29896d97abb91468dc02e4af9412256 */
/* loaded from: classes.dex */
public final class MainActivity extends defpackage.bj implements defpackage.c50 {
    public final java.lang.Object YrqkXmKZUcM5w = new java.lang.Object();
    public boolean ZyOzEyHGA5LX3V = false;
    public volatile defpackage.pL0a6OmlU0mX1 myHiWWW10qoihs7;

    public MainActivity() {
        defpackage.z60 z60Var = new defpackage.z60(this);
        defpackage.fn fnVar = this.zp8GhFeYiOiUNKF;
        fnVar.getClass();
        defpackage.bj bjVar = fnVar.C0Qr9jUmCjop5x;
        if (bjVar != null) {
            z60Var.MTx02WYCU4pkQ(bjVar);
        }
        fnVar.MTx02WYCU4pkQ.add(z60Var);
    }

    @Override // defpackage.c50
    public final java.lang.Object ErkfqQ5RKuFn() {
        return t4SA43ogpBKyJL().ErkfqQ5RKuFn();
    }

    public final void KXSG42UuQxFyR2(android.os.Bundle bundle) {
        super.onCreate(bundle);
        defpackage.pL0a6OmlU0mX1 pl0a6omlu0mx1T4SA43ogpBKyJL = t4SA43ogpBKyJL();
        defpackage.IRYEvpvdt1uN iRYEvpvdt1uN = pl0a6omlu0mx1T4SA43ogpBKyJL.urL9RI7CwH1B60;
        com.chair.wood.resta.MainActivity mainActivity = iRYEvpvdt1uN.gMSMGcGoUA1zHgP;
        defpackage.ZNSpc2IXDoyeyL3 zNSpc2IXDoyeyL3 = new defpackage.ZNSpc2IXDoyeyL3(0, iRYEvpvdt1uN.zp8GhFeYiOiUNKF);
        defpackage.dz1 dz1VarF268HSI0SUhnM = mainActivity.F268HSI0SUhnM();
        defpackage.ap apVarXYvFYLISecIOVxY = defpackage.bs0.xYvFYLISecIOVxY(mainActivity);
        apVarXYvFYLISecIOVxY.getClass();
        defpackage.k kVar = new defpackage.k(dz1VarF268HSI0SUhnM, zNSpc2IXDoyeyL3, apVarXYvFYLISecIOVxY);
        defpackage.qg qgVarMTx02WYCU4pkQ = defpackage.q71.MTx02WYCU4pkQ(defpackage.otY77vrdLS0XOh.class);
        java.lang.String strC0Qr9jUmCjop5x = qgVarMTx02WYCU4pkQ.C0Qr9jUmCjop5x();
        if (strC0Qr9jUmCjop5x == null) {
            defpackage.p8.cvi6tTOr7V77iB("Local and anonymous classes can not be ViewModels");
            return;
        }
        defpackage.v91 v91Var = ((defpackage.otY77vrdLS0XOh) kVar.sGHWrDCZ2mIE(qgVarMTx02WYCU4pkQ, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strC0Qr9jUmCjop5x))).Q3jZxx9zkJ4BVxw;
        pl0a6omlu0mx1T4SA43ogpBKyJL.xYvFYLISecIOVxY = v91Var;
        if (((defpackage.hp0) v91Var.C0Qr9jUmCjop5x) == null) {
            defpackage.hp0 hp0VarZp8GhFeYiOiUNKF = pl0a6omlu0mx1T4SA43ogpBKyJL.F268HSI0SUhnM.zp8GhFeYiOiUNKF();
            if (v91Var.MTx02WYCU4pkQ) {
                v91Var.C0Qr9jUmCjop5x = hp0VarZp8GhFeYiOiUNKF;
            } else {
                defpackage.p8.s1cCbqUOUlYWuKh("setExtras should only be called for an Activity that extends ComponentActivity");
            }
        }
    }

    @Override // defpackage.q60
    public final defpackage.bz1 gMSMGcGoUA1zHgP() {
        defpackage.bz1 bz1Var = (defpackage.bz1) this.cvi6tTOr7V77iB.getValue();
        defpackage.mp mpVar = (defpackage.mp) ((defpackage.jr) defpackage.jf.YrqkXmKZUcM5w(this, defpackage.jr.class));
        defpackage.ze0 ze0VarMTx02WYCU4pkQ = mpVar.MTx02WYCU4pkQ();
        defpackage.w90 w90Var = new defpackage.w90(mpVar.MTx02WYCU4pkQ, mpVar.C0Qr9jUmCjop5x);
        bz1Var.getClass();
        return new defpackage.x60(ze0VarMTx02WYCU4pkQ, bz1Var, w90Var);
    }

    @Override // defpackage.bj, defpackage.aj, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        KXSG42UuQxFyR2(bundle);
        int i = 20;
        defpackage.en1 en1Var = new defpackage.en1(0, 0, new defpackage.pb1(i));
        defpackage.en1 en1Var2 = new defpackage.en1(defpackage.uw.MTx02WYCU4pkQ, defpackage.uw.C0Qr9jUmCjop5x, new defpackage.pb1(i));
        android.view.View decorView = getWindow().getDecorView();
        decorView.getClass();
        defpackage.bx axVar = defpackage.uw.Q3jZxx9zkJ4BVxw;
        if (axVar == null) {
            int i2 = android.os.Build.VERSION.SDK_INT;
            axVar = i2 >= 35 ? new defpackage.ax() : i2 >= 30 ? new defpackage.zw() : i2 >= 29 ? new defpackage.yw() : i2 >= 28 ? new defpackage.xw() : i2 >= 26 ? new defpackage.ww() : new defpackage.vw();
            defpackage.uw.Q3jZxx9zkJ4BVxw = axVar;
        }
        defpackage.bx bxVar = axVar;
        defpackage.sa saVar = new defpackage.sa(bxVar, en1Var, en1Var2, this, decorView, 1);
        android.view.ViewGroup viewGroup = (android.view.ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                defpackage.tw twVar = new defpackage.tw(saVar, viewGroup.getContext());
                twVar.setTag(bxVar);
                twVar.setVisibility(8);
                twVar.setWillNotDraw(true);
                viewGroup.addView(twVar);
                break;
            }
            int i4 = i3 + 1;
            android.view.View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new java.lang.IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof defpackage.bx) {
                break;
            } else {
                i3 = i4;
            }
        }
        saVar.run();
        android.view.Window window = getWindow();
        window.getClass();
        bxVar.MTx02WYCU4pkQ(window);
        defpackage.ij ijVar = defpackage.kc.Q3jZxx9zkJ4BVxw;
        android.view.ViewGroup.LayoutParams layoutParams = defpackage.cj.MTx02WYCU4pkQ;
        android.view.View childAt2 = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        defpackage.wk wkVar = childAt2 instanceof defpackage.wk ? (defpackage.wk) childAt2 : null;
        if (wkVar != null) {
            wkVar.setParentCompositionContext(null);
            wkVar.setContent(ijVar);
            return;
        }
        defpackage.wk wkVar2 = new defpackage.wk(this);
        wkVar2.setParentCompositionContext(null);
        wkVar2.setContent(ijVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (defpackage.rs0.urL9RI7CwH1B60(decorView2) == null) {
            decorView2.setTag(com.chair.wood.resta.R.id.view_tree_lifecycle_owner, this);
        }
        if (defpackage.ct0.OjX43ddKVtAAt(decorView2) == null) {
            decorView2.setTag(com.chair.wood.resta.R.id.view_tree_view_model_store_owner, this);
        }
        if (defpackage.vs0.F268HSI0SUhnM(decorView2) == null) {
            decorView2.setTag(com.chair.wood.resta.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(wkVar2, defpackage.cj.MTx02WYCU4pkQ);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        defpackage.v91 v91Var = t4SA43ogpBKyJL().xYvFYLISecIOVxY;
        if (v91Var != null) {
            v91Var.C0Qr9jUmCjop5x = null;
        }
    }

    public final defpackage.pL0a6OmlU0mX1 t4SA43ogpBKyJL() {
        if (this.myHiWWW10qoihs7 == null) {
            synchronized (this.YrqkXmKZUcM5w) {
                try {
                    if (this.myHiWWW10qoihs7 == null) {
                        this.myHiWWW10qoihs7 = new defpackage.pL0a6OmlU0mX1(this);
                    }
                } finally {
                }
            }
        }
        return this.myHiWWW10qoihs7;
    }
}
