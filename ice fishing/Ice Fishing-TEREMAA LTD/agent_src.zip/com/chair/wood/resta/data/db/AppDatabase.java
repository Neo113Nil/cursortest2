package com.chair.wood.resta.data.db;

/* compiled from: r8-map-id-8830e4f931c147ea963aab9fad545643b29896d97abb91468dc02e4af9412256 */
/* loaded from: classes.dex */
public abstract class AppDatabase extends defpackage.s91 {
    public abstract defpackage.a61 KXSG42UuQxFyR2();

    public abstract defpackage.xo1 sGHWrDCZ2mIE();

    public abstract defpackage.xl0 t4SA43ogpBKyJL();
}
