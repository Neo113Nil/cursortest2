package com.chair.wood.resta.data.db;

/* compiled from: r8-map-id-8830e4f931c147ea963aab9fad545643b29896d97abb91468dc02e4af9412256 */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends com.chair.wood.resta.data.db.AppDatabase {
    public final defpackage.dn1 KXSG42UuQxFyR2;
    public final defpackage.dn1 sGHWrDCZ2mIE;
    public final defpackage.dn1 t4SA43ogpBKyJL;

    public AppDatabase_Impl() {
        final int i = 0;
        this.t4SA43ogpBKyJL = new defpackage.dn1(new defpackage.n30(this) { // from class: y7
            public final /* synthetic */ com.chair.wood.resta.data.db.AppDatabase_Impl zp8GhFeYiOiUNKF;

            {
                this.zp8GhFeYiOiUNKF = this;
            }

            @Override // defpackage.n30
            public final java.lang.Object MTx02WYCU4pkQ() {
                int i2 = i;
                com.chair.wood.resta.data.db.AppDatabase_Impl appDatabase_Impl = this.zp8GhFeYiOiUNKF;
                switch (i2) {
                    case defpackage.fr0.MTx02WYCU4pkQ /* 0 */:
                        return new defpackage.xl0(appDatabase_Impl);
                    case 1:
                        return new defpackage.a61(appDatabase_Impl);
                    default:
                        return new defpackage.xo1(appDatabase_Impl);
                }
            }
        });
        final int i2 = 1;
        this.KXSG42UuQxFyR2 = new defpackage.dn1(new defpackage.n30(this) { // from class: y7
            public final /* synthetic */ com.chair.wood.resta.data.db.AppDatabase_Impl zp8GhFeYiOiUNKF;

            {
                this.zp8GhFeYiOiUNKF = this;
            }

            @Override // defpackage.n30
            public final java.lang.Object MTx02WYCU4pkQ() {
                int i22 = i2;
                com.chair.wood.resta.data.db.AppDatabase_Impl appDatabase_Impl = this.zp8GhFeYiOiUNKF;
                switch (i22) {
                    case defpackage.fr0.MTx02WYCU4pkQ /* 0 */:
                        return new defpackage.xl0(appDatabase_Impl);
                    case 1:
                        return new defpackage.a61(appDatabase_Impl);
                    default:
                        return new defpackage.xo1(appDatabase_Impl);
                }
            }
        });
        final int i3 = 2;
        this.sGHWrDCZ2mIE = new defpackage.dn1(new defpackage.n30(this) { // from class: y7
            public final /* synthetic */ com.chair.wood.resta.data.db.AppDatabase_Impl zp8GhFeYiOiUNKF;

            {
                this.zp8GhFeYiOiUNKF = this;
            }

            @Override // defpackage.n30
            public final java.lang.Object MTx02WYCU4pkQ() {
                int i22 = i3;
                com.chair.wood.resta.data.db.AppDatabase_Impl appDatabase_Impl = this.zp8GhFeYiOiUNKF;
                switch (i22) {
                    case defpackage.fr0.MTx02WYCU4pkQ /* 0 */:
                        return new defpackage.xl0(appDatabase_Impl);
                    case 1:
                        return new defpackage.a61(appDatabase_Impl);
                    default:
                        return new defpackage.xo1(appDatabase_Impl);
                }
            }
        });
    }

    @Override // defpackage.s91
    public final defpackage.ec0 C0Qr9jUmCjop5x() {
        return new defpackage.ec0(this, new java.util.LinkedHashMap(), new java.util.LinkedHashMap(), "menu_items", "quiz_results", "taste_marks");
    }

    @Override // com.chair.wood.resta.data.db.AppDatabase
    public final defpackage.a61 KXSG42UuQxFyR2() {
        return (defpackage.a61) this.KXSG42UuQxFyR2.getValue();
    }

    @Override // defpackage.s91
    public final java.util.List MTx02WYCU4pkQ(java.util.LinkedHashMap linkedHashMap) {
        return new java.util.ArrayList();
    }

    @Override // defpackage.s91
    public final defpackage.ix Q3jZxx9zkJ4BVxw() {
        return new defpackage.z7(this);
    }

    @Override // defpackage.s91
    public final java.util.Set gMSMGcGoUA1zHgP() {
        return new java.util.LinkedHashSet();
    }

    @Override // com.chair.wood.resta.data.db.AppDatabase
    public final defpackage.xo1 sGHWrDCZ2mIE() {
        return (defpackage.xo1) this.sGHWrDCZ2mIE.getValue();
    }

    @Override // com.chair.wood.resta.data.db.AppDatabase
    public final defpackage.xl0 t4SA43ogpBKyJL() {
        return (defpackage.xl0) this.t4SA43ogpBKyJL.getValue();
    }

    @Override // defpackage.s91
    public final java.util.LinkedHashMap zp8GhFeYiOiUNKF() {
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
        defpackage.qg qgVarMTx02WYCU4pkQ = defpackage.q71.MTx02WYCU4pkQ(defpackage.xl0.class);
        defpackage.cy cyVar = defpackage.cy.gMSMGcGoUA1zHgP;
        linkedHashMap.put(qgVarMTx02WYCU4pkQ, cyVar);
        linkedHashMap.put(defpackage.q71.MTx02WYCU4pkQ(defpackage.a61.class), cyVar);
        linkedHashMap.put(defpackage.q71.MTx02WYCU4pkQ(defpackage.xo1.class), cyVar);
        return linkedHashMap;
    }
}
