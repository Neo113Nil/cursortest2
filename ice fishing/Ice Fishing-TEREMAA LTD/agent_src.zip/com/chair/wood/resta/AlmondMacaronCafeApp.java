package com.chair.wood.resta;

/* compiled from: r8-map-id-8830e4f931c147ea963aab9fad545643b29896d97abb91468dc02e4af9412256 */
/* loaded from: classes.dex */
public class AlmondMacaronCafeApp extends android.app.Application implements defpackage.c50 {
    public boolean gMSMGcGoUA1zHgP = false;
    public final defpackage.k8 zp8GhFeYiOiUNKF = new defpackage.k8(new defpackage.a1(9, this));

    @Override // defpackage.c50
    public final java.lang.Object ErkfqQ5RKuFn() {
        return this.zp8GhFeYiOiUNKF.ErkfqQ5RKuFn();
    }

    @Override // android.app.Application
    public final void onCreate() {
        if (!this.gMSMGcGoUA1zHgP) {
            this.gMSMGcGoUA1zHgP = true;
            ((defpackage.tQzDa6FTpHwbfs) this.zp8GhFeYiOiUNKF.ErkfqQ5RKuFn()).getClass();
        }
        super.onCreate();
    }
}
