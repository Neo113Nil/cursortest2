package u3;

/* renamed from: u3.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0875b {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f9317a;

    /* renamed from: b, reason: collision with root package name */
    public final x4.c f9318b;

    public C0875b(android.content.Context context, x4.c cVar) {
        f4.i.e(cVar, "dispatcher");
        this.f9317a = context;
        this.f9318b = cVar;
    }
}
