package u3;

/* renamed from: u3.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0881h implements e4.InterfaceC0295c {
    public final /* synthetic */ java.util.concurrent.atomic.AtomicBoolean i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ X.C0148e f9332j;

    public C0881h(java.util.concurrent.atomic.AtomicBoolean atomicBoolean, u3.C0883j c0883j, X.C0148e c0148e) {
        this.i = atomicBoolean;
        this.f9332j = c0148e;
    }

    @Override // e4.InterfaceC0295c
    public final java.lang.Object l(java.lang.Object obj) {
        if (this.i.compareAndSet(false, true)) {
            X.C0148e c0148e = this.f9332j;
            try {
                c0148e.f3991a = 3;
                if (((e2.ServiceConnectionC0286a) c0148e.f3994d) != null) {
                    f2.AbstractC0335a.v("Unbinding from service.");
                    ((android.content.Context) c0148e.f3992b).unbindService((e2.ServiceConnectionC0286a) c0148e.f3994d);
                    c0148e.f3994d = null;
                }
                c0148e.f3993c = null;
            } catch (java.lang.Throwable th) {
                b5.c.u(th);
            }
        }
        return Q3.o.f3335a;
    }
}
