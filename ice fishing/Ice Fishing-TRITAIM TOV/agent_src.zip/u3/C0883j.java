package u3;

/* renamed from: u3.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0883j {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f9335a;

    public C0883j(android.content.Context context) {
        this.f9335a = context;
    }
}
