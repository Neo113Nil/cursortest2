package u3;

/* renamed from: u3.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0882i implements e4.InterfaceC0295c {
    public final /* synthetic */ java.util.concurrent.atomic.AtomicBoolean i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ q4.C0766g f9333j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ X.C0148e f9334k;

    public C0882i(java.util.concurrent.atomic.AtomicBoolean atomicBoolean, u3.C0883j c0883j, q4.C0766g c0766g, X.C0148e c0148e) {
        this.i = atomicBoolean;
        this.f9333j = c0766g;
        this.f9334k = c0148e;
    }

    @Override // e4.InterfaceC0295c
    public final java.lang.Object l(java.lang.Object obj) {
        java.lang.String str = (java.lang.String) obj;
        f4.i.e(str, "value");
        if (this.i.compareAndSet(false, true)) {
            X.C0148e c0148e = this.f9334k;
            try {
                c0148e.f3991a = 3;
                if (((e2.ServiceConnectionC0286a) c0148e.f3994d) != null) {
                    f2.AbstractC0335a.v("Unbinding from service.");
                    ((android.content.Context) c0148e.f3992b).unbindService((e2.ServiceConnectionC0286a) c0148e.f3994d);
                    c0148e.f3994d = null;
                }
                c0148e.f3993c = null;
            } catch (java.lang.Throwable th) {
                b5.c.u(th);
            }
            this.f9333j.q(str);
        }
        return Q3.o.f3335a;
    }
}
