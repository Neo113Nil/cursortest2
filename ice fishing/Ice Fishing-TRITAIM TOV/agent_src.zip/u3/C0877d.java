package u3;

/* renamed from: u3.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0877d extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public int f9321m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ u3.C0880g f9322n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0877d(u3.C0880g c0880g, U3.d dVar) {
        super(2, dVar);
        this.f9322n = c0880g;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        return new u3.C0877d(this.f9322n, dVar);
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.C0877d) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        V3.a aVar = V3.a.i;
        int i = this.f9321m;
        if (i == 0) {
            b5.c.Z(obj);
            u3.l lVar = this.f9322n.f9331c;
            this.f9321m = 1;
            obj = q4.AbstractC0784y.A(lVar.f9339b, new u3.C0884k(lVar, null), this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            b5.c.Z(obj);
        }
        return obj;
    }
}
