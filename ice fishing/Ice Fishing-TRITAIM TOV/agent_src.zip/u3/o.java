package u3;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f9345a;

    /* renamed from: b, reason: collision with root package name */
    public final x4.c f9346b;

    public o(android.content.Context context, x4.c cVar) {
        f4.i.e(cVar, "dispatcher");
        this.f9345a = context;
        this.f9346b = cVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(W3.c cVar) {
        u3.m mVar;
        if (cVar instanceof u3.m) {
            mVar = (u3.m) cVar;
            int i = mVar.f9342n;
            if ((i & Integer.MIN_VALUE) != 0) {
                mVar.f9342n = i - Integer.MIN_VALUE;
            } else {
                mVar = new u3.m(this, cVar);
            }
        }
        java.lang.Object objA = mVar.f9340l;
        V3.a aVar = V3.a.i;
        int i6 = mVar.f9342n;
        if (i6 == 0) {
            b5.c.Z(objA);
            u3.n nVar = new u3.n(this, null);
            mVar.f9342n = 1;
            objA = q4.AbstractC0784y.A(this.f9346b, nVar, mVar);
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i6 != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            b5.c.Z(objA);
        }
        f4.i.d(objA, "withContext(...)");
        return objA;
    }
}
