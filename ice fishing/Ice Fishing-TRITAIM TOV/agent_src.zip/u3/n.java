package u3;

/* loaded from: classes.dex */
public final class n extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9343m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ u3.o f9344n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(u3.o oVar, U3.d dVar) {
        super(2, dVar);
        this.f9344n = oVar;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        u3.n nVar = new u3.n(this.f9344n, dVar);
        nVar.f9343m = obj;
        return nVar;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.n) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        java.lang.Object objU;
        b5.c.Z(obj);
        try {
            objU = android.webkit.WebSettings.getDefaultUserAgent(this.f9344n.f9345a);
        } catch (java.lang.Throwable th) {
            objU = b5.c.u(th);
        }
        if (Q3.k.a(objU) == null) {
            return objU;
        }
        java.lang.String property = java.lang.System.getProperty("http.agent");
        return property == null ? "" : property;
    }
}
