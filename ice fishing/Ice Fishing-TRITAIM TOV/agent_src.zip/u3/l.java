package u3;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public final android.content.Context f9338a;

    /* renamed from: b, reason: collision with root package name */
    public final x4.c f9339b;

    public l(android.content.Context context, x4.c cVar) {
        f4.i.e(cVar, "dispatcher");
        this.f9338a = context;
        this.f9339b = cVar;
    }
}
