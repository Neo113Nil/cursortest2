package u3;

/* renamed from: u3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0874a extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9315m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ u3.C0875b f9316n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0874a(u3.C0875b c0875b, U3.d dVar) {
        super(2, dVar);
        this.f9316n = c0875b;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        u3.C0874a c0874a = new u3.C0874a(this.f9316n, dVar);
        c0874a.f9315m = obj;
        return c0874a;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.C0874a) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        java.lang.Object objU;
        b5.c.Z(obj);
        try {
            objU = i2.C0418a.a(this.f9316n.f9317a).f2296b;
        } catch (java.lang.Throwable th) {
            objU = b5.c.u(th);
        }
        if (objU instanceof Q3.j) {
            objU = null;
        }
        java.lang.String str = (java.lang.String) objU;
        return str == null ? "" : str;
    }
}
