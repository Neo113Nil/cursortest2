package u3;

/* loaded from: classes.dex */
public final class m extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9340l;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ u3.o f9341m;

    /* renamed from: n, reason: collision with root package name */
    public int f9342n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(u3.o oVar, W3.c cVar) {
        super(cVar);
        this.f9341m = oVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f9340l = obj;
        this.f9342n |= Integer.MIN_VALUE;
        return this.f9341m.a(this);
    }
}
