package u3;

/* renamed from: u3.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0878e extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public int f9323m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ u3.C0880g f9324n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0878e(u3.C0880g c0880g, U3.d dVar) {
        super(2, dVar);
        this.f9324n = c0880g;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        return new u3.C0878e(this.f9324n, dVar);
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.C0878e) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        java.lang.Object objU;
        V3.a aVar = V3.a.i;
        int i = this.f9323m;
        if (i == 0) {
            b5.c.Z(obj);
            u3.C0883j c0883j = this.f9324n.f9330b;
            this.f9323m = 1;
            q4.C0766g c0766g = new q4.C0766g(1, b5.c.K(this));
            c0766g.t();
            java.util.concurrent.atomic.AtomicBoolean atomicBoolean = new java.util.concurrent.atomic.AtomicBoolean(false);
            X.C0148e c0148e = new X.C0148e(c0883j.f9335a);
            u3.C0882i c0882i = new u3.C0882i(atomicBoolean, c0883j, c0766g, c0148e);
            c0766g.w(new u3.C0881h(atomicBoolean, c0883j, c0148e));
            try {
                c0148e.h(new l0.C0488m(15, c0882i, c0148e));
                objU = Q3.o.f3335a;
            } catch (java.lang.Throwable th) {
                objU = b5.c.u(th);
            }
            if (Q3.k.a(objU) != null) {
                c0882i.l("");
            }
            obj = c0766g.s();
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            b5.c.Z(obj);
        }
        return obj;
    }
}
