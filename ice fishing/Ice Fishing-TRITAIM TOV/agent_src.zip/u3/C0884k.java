package u3;

/* renamed from: u3.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0884k extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9336m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ u3.l f9337n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0884k(u3.l lVar, U3.d dVar) {
        super(2, dVar);
        this.f9337n = lVar;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        u3.C0884k c0884k = new u3.C0884k(this.f9337n, dVar);
        c0884k.f9336m = obj;
        return c0884k;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.C0884k) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        java.lang.Object objU;
        b5.c.Z(obj);
        try {
            objU = android.provider.Settings.Secure.getString(this.f9337n.f9338a.getContentResolver(), "android_id");
        } catch (java.lang.Throwable th) {
            objU = b5.c.u(th);
        }
        if (objU instanceof Q3.j) {
            objU = null;
        }
        java.lang.String str = (java.lang.String) objU;
        return str == null ? "" : str;
    }
}
