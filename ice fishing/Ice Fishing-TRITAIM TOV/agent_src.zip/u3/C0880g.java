package u3;

/* renamed from: u3.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0880g {

    /* renamed from: a, reason: collision with root package name */
    public final u3.C0875b f9329a;

    /* renamed from: b, reason: collision with root package name */
    public final u3.C0883j f9330b;

    /* renamed from: c, reason: collision with root package name */
    public final u3.l f9331c;

    public C0880g(u3.C0875b c0875b, u3.C0883j c0883j, u3.l lVar) {
        this.f9329a = c0875b;
        this.f9330b = c0883j;
        this.f9331c = lVar;
    }
}
