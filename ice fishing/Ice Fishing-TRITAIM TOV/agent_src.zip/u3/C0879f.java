package u3;

/* renamed from: u3.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0879f extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public java.lang.Object f9325m;

    /* renamed from: n, reason: collision with root package name */
    public int f9326n;

    /* renamed from: o, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9327o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ u3.C0880g f9328p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0879f(u3.C0880g c0880g, U3.d dVar) {
        super(2, dVar);
        this.f9328p = c0880g;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        u3.C0879f c0879f = new u3.C0879f(this.f9328p, dVar);
        c0879f.f9327o = obj;
        return c0879f;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((u3.C0879f) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0093 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0094  */
    @Override // W3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object n(java.lang.Object obj) {
        q4.InterfaceC0738B interfaceC0738B;
        q4.InterfaceC0738B interfaceC0738B2;
        java.lang.String str;
        q4.InterfaceC0738B interfaceC0738B3;
        java.lang.Object objP;
        java.lang.String str2;
        V3.a aVar = V3.a.i;
        int i = this.f9326n;
        if (i == 0) {
            b5.c.Z(obj);
            q4.InterfaceC0783x interfaceC0783x = (q4.InterfaceC0783x) this.f9327o;
            u3.C0880g c0880g = this.f9328p;
            q4.C0739C c0739cD = q4.AbstractC0784y.d(interfaceC0783x, new u3.C0876c(c0880g, null));
            q4.C0739C c0739cD2 = q4.AbstractC0784y.d(interfaceC0783x, new u3.C0878e(c0880g, null));
            q4.C0739C c0739cD3 = q4.AbstractC0784y.d(interfaceC0783x, new u3.C0877d(c0880g, null));
            this.f9327o = c0739cD2;
            this.f9325m = c0739cD3;
            this.f9326n = 1;
            java.lang.Object objZ = c0739cD.z(this);
            if (objZ == aVar) {
                return aVar;
            }
            interfaceC0738B = c0739cD2;
            interfaceC0738B2 = c0739cD3;
            obj = objZ;
        } else {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    str2 = (java.lang.String) this.f9325m;
                    str = (java.lang.String) this.f9327o;
                    b5.c.Z(obj);
                    return new A3.a(str, str2, (java.lang.String) obj);
                }
                str = (java.lang.String) this.f9325m;
                interfaceC0738B3 = (q4.InterfaceC0738B) this.f9327o;
                b5.c.Z(obj);
                java.lang.String str3 = (java.lang.String) obj;
                this.f9327o = str;
                this.f9325m = str3;
                this.f9326n = 3;
                objP = interfaceC0738B3.p(this);
                if (objP != aVar) {
                    return aVar;
                }
                str2 = str3;
                obj = objP;
                return new A3.a(str, str2, (java.lang.String) obj);
            }
            interfaceC0738B2 = (q4.InterfaceC0738B) this.f9325m;
            interfaceC0738B = (q4.InterfaceC0738B) this.f9327o;
            b5.c.Z(obj);
        }
        java.lang.String str4 = (java.lang.String) obj;
        this.f9327o = interfaceC0738B2;
        this.f9325m = str4;
        this.f9326n = 2;
        java.lang.Object objP2 = interfaceC0738B.p(this);
        if (objP2 == aVar) {
            return aVar;
        }
        q4.InterfaceC0738B interfaceC0738B4 = interfaceC0738B2;
        str = str4;
        obj = objP2;
        interfaceC0738B3 = interfaceC0738B4;
        java.lang.String str32 = (java.lang.String) obj;
        this.f9327o = str;
        this.f9325m = str32;
        this.f9326n = 3;
        objP = interfaceC0738B3.p(this);
        if (objP != aVar) {
        }
    }
}
