package v3;

/* renamed from: v3.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0940c {

    /* renamed from: c, reason: collision with root package name */
    public static final p1.C0722e f9713c = new p1.C0722e("forager_tally_response");

    /* renamed from: a, reason: collision with root package name */
    public final m1.InterfaceC0653h f9714a;

    /* renamed from: b, reason: collision with root package name */
    public final c3.e f9715b;

    public C0940c(m1.InterfaceC0653h interfaceC0653h, c3.e eVar) {
        this.f9714a = interfaceC0653h;
        this.f9715b = eVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x007f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0080 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(W3.c cVar) {
        v3.C0938a c0938a;
        v3.C0940c c0940c;
        java.lang.Object objU;
        java.lang.String str;
        java.lang.Object objU2;
        if (cVar instanceof v3.C0938a) {
            c0938a = (v3.C0938a) cVar;
            int i = c0938a.f9709o;
            if ((i & Integer.MIN_VALUE) != 0) {
                c0938a.f9709o = i - Integer.MIN_VALUE;
            } else {
                c0938a = new v3.C0938a(this, cVar);
            }
        }
        java.lang.Object objH = c0938a.f9707m;
        V3.a aVar = V3.a.i;
        int i6 = c0938a.f9709o;
        if (i6 == 0) {
            b5.c.Z(objH);
            try {
                t4.InterfaceC0852d interfaceC0852dB = this.f9714a.b();
                c0938a.f9706l = this;
                c0938a.f9709o = 1;
                objH = t4.C.h(interfaceC0852dB, c0938a);
                if (objH == aVar) {
                    return aVar;
                }
                c0940c = this;
            } catch (java.lang.Throwable th) {
                th = th;
                c0940c = this;
                objU = b5.c.u(th);
                if (objU instanceof Q3.j) {
                }
                str = (java.lang.String) objU;
                if (str == null) {
                }
            }
        } else {
            if (i6 != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            c0940c = c0938a.f9706l;
            try {
                b5.c.Z(objH);
            } catch (java.lang.Throwable th2) {
                th = th2;
                objU = b5.c.u(th);
                if (objU instanceof Q3.j) {
                }
                str = (java.lang.String) objU;
                if (str == null) {
                }
            }
        }
        p1.C0719b c0719b = (p1.C0719b) objH;
        p1.C0722e c0722e = f9713c;
        c0719b.getClass();
        f4.i.e(c0722e, "key");
        java.lang.Object objCopyOf = c0719b.f8525a.get(c0722e);
        if (objCopyOf instanceof byte[]) {
            byte[] bArr = (byte[]) objCopyOf;
            objCopyOf = java.util.Arrays.copyOf(bArr, bArr.length);
            f4.i.d(objCopyOf, "copyOf(this, size)");
        }
        objU = (java.lang.String) objCopyOf;
        if (objU instanceof Q3.j) {
            objU = null;
        }
        str = (java.lang.String) objU;
        if (str == null) {
            return null;
        }
        try {
            objU2 = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) c0940c.f9715b.b(str);
        } catch (java.lang.Throwable th3) {
            objU2 = b5.c.u(th3);
        }
        if (objU2 instanceof Q3.j) {
            return null;
        }
        return objU2;
    }
}
