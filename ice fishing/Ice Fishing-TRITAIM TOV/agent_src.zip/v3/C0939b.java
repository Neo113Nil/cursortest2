package v3;

/* renamed from: v3.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0939b extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9710m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ v3.C0940c f9711n;

    /* renamed from: o, reason: collision with root package name */
    public final /* synthetic */ com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse f9712o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0939b(v3.C0940c c0940c, com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse, U3.d dVar) {
        super(2, dVar);
        this.f9711n = c0940c;
        this.f9712o = foragerTallyResponse;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        v3.C0939b c0939b = new v3.C0939b(this.f9711n, this.f9712o, dVar);
        c0939b.f9710m = obj;
        return c0939b;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        v3.C0939b c0939b = (v3.C0939b) a((U3.d) obj2, (p1.C0719b) obj);
        Q3.o oVar = Q3.o.f3335a;
        c0939b.n(oVar);
        return oVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        b5.c.Z(obj);
        p1.C0719b c0719b = (p1.C0719b) this.f9710m;
        java.lang.String strE = this.f9711n.f9715b.e(this.f9712o);
        c0719b.getClass();
        p1.C0722e c0722e = v3.C0940c.f9713c;
        f4.i.e(c0722e, "key");
        c0719b.c(c0722e, strE);
        return Q3.o.f3335a;
    }
}
