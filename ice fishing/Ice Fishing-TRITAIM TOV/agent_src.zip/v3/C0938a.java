package v3;

/* renamed from: v3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0938a extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public v3.C0940c f9706l;

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f9707m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ v3.C0940c f9708n;

    /* renamed from: o, reason: collision with root package name */
    public int f9709o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0938a(v3.C0940c c0940c, W3.c cVar) {
        super(cVar);
        this.f9708n = c0940c;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f9707m = obj;
        this.f9709o |= Integer.MIN_VALUE;
        return this.f9708n.a(this);
    }
}
