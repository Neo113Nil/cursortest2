package F3;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final v0.C0919E f1033a;

    /* renamed from: b, reason: collision with root package name */
    public final v0.C0919E f1034b;

    /* renamed from: c, reason: collision with root package name */
    public final v0.C0919E f1035c;

    public g(v0.C0919E c0919e, v0.C0919E c0919e2, v0.C0919E c0919e3) {
        this.f1033a = c0919e;
        this.f1034b = c0919e2;
        this.f1035c = c0919e3;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof F3.g)) {
            return false;
        }
        F3.g gVar = (F3.g) obj;
        return f4.i.a(this.f1033a, gVar.f1033a) && f4.i.a(this.f1034b, gVar.f1034b) && f4.i.a(this.f1035c, gVar.f1035c);
    }

    public final int hashCode() {
        return this.f1035c.hashCode() + ((this.f1034b.hashCode() + (this.f1033a.hashCode() * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "SplashTypography(title=" + this.f1033a + ", body=" + this.f1034b + ", button=" + this.f1035c + ")";
    }
}
