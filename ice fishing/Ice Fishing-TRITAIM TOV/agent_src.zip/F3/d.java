package F3;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final F3.c f1025a;

    static {
        float f6 = 48;
        float f7 = 24;
        f1025a = new F3.c(f6, 4, 32, 8, 28, f6, 160, f7, (float) 1.5d, f7);
    }
}
