package F3;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public static final F3.a f1015a;

    static {
        int i = X.m.f4009g;
        f1015a = new F3.a(X.y.b(4294967295L), X.y.b(4278190080L), 520093696 << 32);
    }
}
