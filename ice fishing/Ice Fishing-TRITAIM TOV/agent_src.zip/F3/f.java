package F3;

/* loaded from: classes.dex */
public abstract class f {

    /* renamed from: a, reason: collision with root package name */
    public static final F.N0 f1030a = new F.N0(new C1.a(1));

    /* renamed from: b, reason: collision with root package name */
    public static final F.N0 f1031b = new F.N0(new C1.a(2));

    /* renamed from: c, reason: collision with root package name */
    public static final F.N0 f1032c = new F.N0(new C1.a(3));

    public static final void a(F3.a aVar, F3.c cVar, F3.g gVar, final M.e eVar, F.C0027n c0027n, final int i) {
        c0027n.L(-67944680);
        int i6 = i | 438;
        if ((i & 3072) == 0) {
            i6 |= c0027n.e(eVar) ? 2048 : 1024;
        }
        if ((i6 & 1171) == 1170 && c0027n.s()) {
            c0027n.H();
        } else {
            aVar = F3.b.f1015a;
            cVar = F3.d.f1025a;
            gVar = F3.h.f1036a;
            F.C0003b.b(new F.C0026m0[]{f1030a.a(aVar), f1031b.a(cVar), f1032c.a(gVar)}, eVar, c0027n, ((i6 >> 6) & 112) | 8);
        }
        final F3.a aVar2 = aVar;
        final F3.c cVar2 = cVar;
        final F3.g gVar2 = gVar;
        F.C0030o0 c0030o0N = c0027n.n();
        if (c0030o0N != null) {
            c0030o0N.f636d = new e4.InterfaceC0297e() { // from class: F3.e
                @Override // e4.InterfaceC0297e
                public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iO = F.C0003b.o(i | 1);
                    M.e eVar2 = eVar;
                    F3.f.a(aVar2, cVar2, gVar2, eVar2, (F.C0027n) obj, iO);
                    return Q3.o.f3335a;
                }
            };
        }
    }
}
