package F3;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final float f1016a;

    /* renamed from: b, reason: collision with root package name */
    public final float f1017b;

    /* renamed from: c, reason: collision with root package name */
    public final float f1018c;

    /* renamed from: d, reason: collision with root package name */
    public final float f1019d;

    /* renamed from: e, reason: collision with root package name */
    public final float f1020e;

    /* renamed from: f, reason: collision with root package name */
    public final float f1021f;

    /* renamed from: g, reason: collision with root package name */
    public final float f1022g;

    /* renamed from: h, reason: collision with root package name */
    public final float f1023h;
    public final float i;

    /* renamed from: j, reason: collision with root package name */
    public final float f1024j;

    public c(float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13, float f14, float f15) {
        this.f1016a = f6;
        this.f1017b = f7;
        this.f1018c = f8;
        this.f1019d = f9;
        this.f1020e = f10;
        this.f1021f = f11;
        this.f1022g = f12;
        this.f1023h = f13;
        this.i = f14;
        this.f1024j = f15;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof F3.c)) {
            return false;
        }
        F3.c cVar = (F3.c) obj;
        return G0.f.b(this.f1016a, cVar.f1016a) && G0.f.b(this.f1017b, cVar.f1017b) && G0.f.b(this.f1018c, cVar.f1018c) && G0.f.b(this.f1019d, cVar.f1019d) && G0.f.b(this.f1020e, cVar.f1020e) && G0.f.b(this.f1021f, cVar.f1021f) && G0.f.b(this.f1022g, cVar.f1022g) && G0.f.b(this.f1023h, cVar.f1023h) && G0.f.b(this.i, cVar.i) && G0.f.b(this.f1024j, cVar.f1024j);
    }

    public final int hashCode() {
        return java.lang.Float.hashCode(this.f1024j) + D.e.a(this.i, D.e.a(this.f1023h, D.e.a(this.f1022g, D.e.a(this.f1021f, D.e.a(this.f1020e, D.e.a(this.f1019d, D.e.a(this.f1018c, D.e.a(this.f1017b, java.lang.Float.hashCode(this.f1016a) * 31, 31), 31), 31), 31), 31), 31), 31), 31);
    }

    public final java.lang.String toString() {
        return "SplashDimens(progressSize=" + G0.f.c(this.f1016a) + ", progressStroke=" + G0.f.c(this.f1017b) + ", screenPadding=" + G0.f.c(this.f1018c) + ", spacingSmall=" + G0.f.c(this.f1019d) + ", spacingLarge=" + G0.f.c(this.f1020e) + ", buttonHeight=" + G0.f.c(this.f1021f) + ", buttonMinWidth=" + G0.f.c(this.f1022g) + ", buttonHorizontalPadding=" + G0.f.c(this.f1023h) + ", buttonBorder=" + G0.f.c(this.i) + ", buttonCorner=" + G0.f.c(this.f1024j) + ")";
    }
}
