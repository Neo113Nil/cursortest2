package F3;

/* loaded from: classes.dex */
public abstract class h {

    /* renamed from: a, reason: collision with root package name */
    public static final F3.g f1036a;

    static {
        y0.m mVar = y0.r.f10227c;
        v0.C0919E c0919e = new v0.C0919E(h4.AbstractC0412a.A(22), y0.k.f10220m, mVar, 0L, 3, h4.AbstractC0412a.A(28), 16613337);
        y0.m mVar2 = y0.r.f10226b;
        v0.C0919E c0919e2 = new v0.C0919E(h4.AbstractC0412a.A(15), y0.k.f10218k, mVar2, 0L, 3, h4.AbstractC0412a.A(22), 16613337);
        y0.k kVar = y0.k.f10219l;
        f1036a = new F3.g(c0919e, c0919e2, new v0.C0919E(h4.AbstractC0412a.A(15), kVar, mVar2, h4.AbstractC0412a.J(4294967296L, (float) 0.4d), 3, h4.AbstractC0412a.A(20), 16613209));
    }
}
