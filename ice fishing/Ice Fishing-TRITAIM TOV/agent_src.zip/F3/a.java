package F3;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final long f1012a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1013b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1014c;

    public a(long j5, long j6, long j7) {
        this.f1012a = j5;
        this.f1013b = j6;
        this.f1014c = j7;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof F3.a)) {
            return false;
        }
        F3.a aVar = (F3.a) obj;
        return X.m.b(this.f1012a, aVar.f1012a) && X.m.b(this.f1013b, aVar.f1013b) && X.m.b(this.f1014c, aVar.f1014c);
    }

    public final int hashCode() {
        int i = X.m.f4009g;
        return java.lang.Long.hashCode(this.f1014c) + D.e.c(java.lang.Long.hashCode(this.f1012a) * 31, 31, this.f1013b);
    }

    public final java.lang.String toString() {
        java.lang.String strG = X.m.g(this.f1012a);
        java.lang.String strG2 = X.m.g(this.f1013b);
        java.lang.String strG3 = X.m.g(this.f1014c);
        java.lang.StringBuilder sb = new java.lang.StringBuilder("SplashColors(background=");
        sb.append(strG);
        sb.append(", content=");
        sb.append(strG2);
        sb.append(", track=");
        return D.e.q(sb, strG3, ")");
    }
}
