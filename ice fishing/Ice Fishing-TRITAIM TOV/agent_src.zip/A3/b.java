package A3;

/* loaded from: classes.dex */
public final class b implements A3.d {

    /* renamed from: a, reason: collision with root package name */
    public static final A3.b f47a = new A3.b();

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof A3.b);
    }

    public final int hashCode() {
        return 1668649513;
    }

    public final java.lang.String toString() {
        return "Main";
    }
}
