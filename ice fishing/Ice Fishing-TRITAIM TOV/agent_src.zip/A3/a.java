package A3;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f44a;

    /* renamed from: b, reason: collision with root package name */
    public final java.lang.String f45b;

    /* renamed from: c, reason: collision with root package name */
    public final java.lang.String f46c;

    public a(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        f4.i.e(str, "advertisingId");
        f4.i.e(str2, "installReferrer");
        f4.i.e(str3, "androidId");
        this.f44a = str;
        this.f45b = str2;
        this.f46c = str3;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof A3.a)) {
            return false;
        }
        A3.a aVar = (A3.a) obj;
        return f4.i.a(this.f44a, aVar.f44a) && f4.i.a(this.f45b, aVar.f45b) && f4.i.a(this.f46c, aVar.f46c);
    }

    public final int hashCode() {
        return this.f46c.hashCode() + D.e.d(this.f45b, this.f44a.hashCode() * 31, 31);
    }

    public final java.lang.String toString() {
        java.lang.StringBuilder sb = new java.lang.StringBuilder("DeviceIds(advertisingId=");
        sb.append(this.f44a);
        sb.append(", installReferrer=");
        sb.append(this.f45b);
        sb.append(", androidId=");
        return D.e.q(sb, this.f46c, ")");
    }
}
