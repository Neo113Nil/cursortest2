package A3;

/* loaded from: classes.dex */
public final class c implements A3.d {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f48a;

    public c(java.lang.String str) {
        f4.i.e(str, "url");
        this.f48a = str;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof A3.c) && f4.i.a(this.f48a, ((A3.c) obj).f48a);
    }

    public final int hashCode() {
        return this.f48a.hashCode();
    }

    public final java.lang.String toString() {
        return D.e.q(new java.lang.StringBuilder("Tab(url="), this.f48a, ")");
    }
}
