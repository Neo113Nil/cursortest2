package H3;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final android.app.Activity f1385a;

    public a(android.app.Activity activity) {
        f4.i.e(activity, "activity");
        this.f1385a = activity;
    }
}
