package x3;

/* renamed from: x3.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1010b implements e4.InterfaceC0295c {
    public final /* synthetic */ P4.e i;

    public C1010b(P4.e eVar) {
        this.i = eVar;
    }

    @Override // e4.InterfaceC0295c
    public final java.lang.Object l(java.lang.Object obj) {
        D4.p pVar = this.i.f3226h;
        f4.i.b(pVar);
        pVar.d();
        return Q3.o.f3335a;
    }
}
