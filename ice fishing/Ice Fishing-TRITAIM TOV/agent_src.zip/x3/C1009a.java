package x3;

/* renamed from: x3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1009a extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public x3.d f10153l;

    /* renamed from: m, reason: collision with root package name */
    public A3.a f10154m;

    /* renamed from: n, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f10155n;

    /* renamed from: o, reason: collision with root package name */
    public final /* synthetic */ x3.d f10156o;

    /* renamed from: p, reason: collision with root package name */
    public int f10157p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1009a(x3.d dVar, W3.c cVar) {
        super(cVar);
        this.f10156o = dVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f10155n = obj;
        this.f10157p |= Integer.MIN_VALUE;
        return this.f10156o.a(null, this);
    }
}
