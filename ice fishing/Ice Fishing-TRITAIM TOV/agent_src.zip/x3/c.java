package x3;

/* loaded from: classes.dex */
public final class c extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public int f10158m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ x3.d f10159n;

    /* renamed from: o, reason: collision with root package name */
    public final /* synthetic */ A1.b f10160o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ java.lang.String f10161p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(x3.d dVar, A1.b bVar, java.lang.String str, U3.d dVar2) {
        super(2, dVar2);
        this.f10159n = dVar;
        this.f10160o = bVar;
        this.f10161p = str;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        return new x3.c(this.f10159n, this.f10160o, this.f10161p, dVar);
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((x3.c) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        V3.a aVar = V3.a.i;
        int i = this.f10158m;
        if (i != 0) {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            b5.c.Z(obj);
            return obj;
        }
        b5.c.Z(obj);
        x3.d dVar = this.f10159n;
        A1.b bVar = this.f10160o;
        java.lang.String str = this.f10161p;
        this.f10158m = 1;
        q4.C0766g c0766g = new q4.C0766g(1, b5.c.K(this));
        c0766g.t();
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean = new java.util.concurrent.atomic.AtomicBoolean(false);
        z4.s sVar = dVar.f10162a;
        f4.i.b(str);
        P4.e eVar = new P4.e(sVar.f10530C, bVar, new B1.f(dVar, str, atomicBoolean, c0766g), new java.util.Random(), sVar.f10555y, sVar.f10528A, sVar.f10556z);
        if (((z4.m) bVar.f5d).b("Sec-WebSocket-Extensions") != null) {
            P4.e.c(eVar, new java.net.ProtocolException("Request header not permitted: 'Sec-WebSocket-Extensions'"), false, 6);
        } else {
            z4.r rVar = new z4.r();
            rVar.f10501a = sVar.f10532a;
            rVar.f10502b = sVar.f10531D;
            R3.s.e0(rVar.f10503c, sVar.f10533b);
            R3.s.e0(rVar.f10504d, sVar.f10534c);
            rVar.f10506f = sVar.f10536e;
            rVar.f10507g = sVar.f10537f;
            rVar.f10508h = sVar.f10538g;
            rVar.i = sVar.f10539h;
            rVar.f10509j = sVar.i;
            rVar.f10510k = sVar.f10540j;
            rVar.f10511l = sVar.f10541k;
            rVar.f10512m = sVar.f10542l;
            rVar.f10513n = sVar.f10543m;
            rVar.f10514o = sVar.f10544n;
            rVar.f10515p = sVar.f10545o;
            rVar.f10516q = sVar.f10546p;
            rVar.f10517r = sVar.f10547q;
            rVar.f10518s = sVar.f10548r;
            rVar.f10519t = sVar.f10549s;
            rVar.f10520u = sVar.f10550t;
            rVar.f10521v = sVar.f10551u;
            rVar.f10522w = sVar.f10552v;
            rVar.f10523x = sVar.f10553w;
            rVar.f10524y = sVar.f10554x;
            rVar.f10525z = sVar.f10555y;
            rVar.f10497A = sVar.f10556z;
            rVar.f10498B = sVar.f10528A;
            rVar.f10499C = sVar.f10529B;
            rVar.f10500D = sVar.f10530C;
            rVar.f10505e = new A4.e(0);
            java.util.List list = P4.e.f3218x;
            f4.i.e(list, "protocols");
            java.util.ArrayList arrayListA0 = R3.n.A0(list);
            z4.t tVar = z4.t.f10562o;
            if (!arrayListA0.contains(tVar) && !arrayListA0.contains(z4.t.f10559l)) {
                throw new java.lang.IllegalArgumentException(("protocols must contain h2_prior_knowledge or http/1.1: " + arrayListA0).toString());
            }
            if (arrayListA0.contains(tVar) && arrayListA0.size() > 1) {
                throw new java.lang.IllegalArgumentException(("protocols containing h2_prior_knowledge cannot use other protocols: " + arrayListA0).toString());
            }
            if (arrayListA0.contains(z4.t.f10558k)) {
                throw new java.lang.IllegalArgumentException(("protocols must not contain http/1.0: " + arrayListA0).toString());
            }
            if (arrayListA0.contains(null)) {
                throw new java.lang.IllegalArgumentException("protocols must not contain null");
            }
            arrayListA0.remove(z4.t.f10560m);
            if (!arrayListA0.equals(rVar.f10518s)) {
                rVar.f10499C = null;
            }
            java.util.List listUnmodifiableList = java.util.Collections.unmodifiableList(arrayListA0);
            f4.i.d(listUnmodifiableList, "unmodifiableList(...)");
            rVar.f10518s = listUnmodifiableList;
            z4.s sVar2 = new z4.s(rVar);
            B1.f fVarF = bVar.f();
            fVarF.v("Upgrade", "websocket");
            fVarF.v("Connection", "Upgrade");
            fVarF.v("Sec-WebSocket-Key", eVar.f3225g);
            fVarF.v("Sec-WebSocket-Version", "13");
            fVarF.v("Sec-WebSocket-Extensions", "permessage-deflate");
            A1.b bVar2 = new A1.b(fVarF);
            D4.p pVar = new D4.p(sVar2, bVar2);
            eVar.f3226h = pVar;
            B4.b bVar3 = new B4.b(18, (java.lang.Object) eVar, (java.lang.Object) bVar2, false);
            if (!pVar.f316n.compareAndSet(false, true)) {
                throw new java.lang.IllegalStateException("Already Executed");
            }
            J4.f fVar = J4.f.f1559a;
            pVar.f317o = J4.f.f1559a.h();
            pVar.f314l.getClass();
            B1.f fVar2 = sVar2.f10532a;
            D4.m mVar = new D4.m(pVar, bVar3);
            fVar2.getClass();
            B1.f.E(fVar2, mVar, null, 6);
        }
        c0766g.w(new x3.C1010b(eVar));
        java.lang.Object objS = c0766g.s();
        return objS == aVar ? aVar : objS;
    }
}
