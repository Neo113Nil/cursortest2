package x3;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final z4.s f10162a;

    /* renamed from: b, reason: collision with root package name */
    public final c3.e f10163b;

    /* renamed from: c, reason: collision with root package name */
    public final u3.o f10164c;

    /* renamed from: d, reason: collision with root package name */
    public final java.lang.String f10165d = "https://conkledgeregyster.space";

    /* renamed from: e, reason: collision with root package name */
    public final java.lang.String f10166e = "/api/bracketSpan/foragerTally";

    public d(z4.s sVar, c3.e eVar, u3.o oVar) {
        this.f10162a = sVar;
        this.f10163b = eVar;
        this.f10164c = oVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x00db A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00dc  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(A3.a aVar, W3.c cVar) {
        x3.C1009a c1009a;
        x3.d dVar;
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse;
        if (cVar instanceof x3.C1009a) {
            c1009a = (x3.C1009a) cVar;
            int i = c1009a.f10157p;
            if ((i & Integer.MIN_VALUE) != 0) {
                c1009a.f10157p = i - Integer.MIN_VALUE;
            } else {
                c1009a = new x3.C1009a(this, cVar);
            }
        }
        java.lang.Object objA = c1009a.f10155n;
        V3.a aVar2 = V3.a.i;
        int i6 = c1009a.f10157p;
        if (i6 == 0) {
            b5.c.Z(objA);
            c1009a.f10153l = this;
            c1009a.f10154m = aVar;
            c1009a.f10157p = 1;
            objA = this.f10164c.a(c1009a);
            if (objA == aVar2) {
                return aVar2;
            }
            dVar = this;
        } else {
            if (i6 != 1) {
                if (i6 != 2) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                b5.c.Z(objA);
                foragerTallyResponse = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) objA;
                if (foragerTallyResponse == null) {
                    return foragerTallyResponse;
                }
                throw new java.io.IOException("Response timed out");
            }
            aVar = c1009a.f10154m;
            dVar = c1009a.f10153l;
            b5.c.Z(objA);
        }
        java.lang.String str = (java.lang.String) objA;
        java.lang.String strE = dVar.f10163b.e(new com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload(aVar.f44a, aVar.f45b, aVar.f46c));
        B1.f fVar = new B1.f(16);
        java.lang.String strConcat = dVar.f10165d.concat(dVar.f10166e);
        f4.i.e(strConcat, "url");
        if (n4.o.z(strConcat, "ws:", true)) {
            java.lang.String strSubstring = strConcat.substring(3);
            f4.i.d(strSubstring, "substring(...)");
            strConcat = "http:".concat(strSubstring);
        } else if (n4.o.z(strConcat, "wss:", true)) {
            java.lang.String strSubstring2 = strConcat.substring(4);
            f4.i.d(strSubstring2, "substring(...)");
            strConcat = "https:".concat(strSubstring2);
        }
        f4.i.e(strConcat, "<this>");
        z4.n nVar = new z4.n();
        nVar.c(null, strConcat);
        fVar.f77j = nVar.a();
        fVar.v("User-Agent", str);
        x3.c cVar2 = new x3.c(dVar, new A1.b(fVar), strE, null);
        c1009a.f10153l = null;
        c1009a.f10154m = null;
        c1009a.f10157p = 2;
        objA = q4.AbstractC0784y.B(67000L, cVar2, c1009a);
        if (objA == aVar2) {
            return aVar2;
        }
        foragerTallyResponse = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) objA;
        if (foragerTallyResponse == null) {
        }
    }
}
