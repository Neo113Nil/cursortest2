package C3;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final y3.c f171a;

    public b(y3.c cVar) {
        this.f171a = cVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(W3.c cVar) {
        C3.a aVar;
        C3.b bVar;
        if (cVar instanceof C3.a) {
            aVar = (C3.a) cVar;
            int i = aVar.f170o;
            if ((i & Integer.MIN_VALUE) != 0) {
                aVar.f170o = i - Integer.MIN_VALUE;
            } else {
                aVar = new C3.a(this, cVar);
            }
        }
        java.lang.Object objA = aVar.f168m;
        V3.a aVar2 = V3.a.i;
        int i6 = aVar.f170o;
        if (i6 == 0) {
            b5.c.Z(objA);
            aVar.f167l = this;
            aVar.f170o = 1;
            objA = this.f171a.a(aVar);
            if (objA == aVar2) {
                return aVar2;
            }
            bVar = this;
        } else {
            if (i6 != 1) {
                if (i6 != 2) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                b5.c.Z(objA);
                return objA;
            }
            bVar = aVar.f167l;
            b5.c.Z(objA);
        }
        objA = (A3.d) objA;
        if (objA == null) {
            y3.c cVar2 = bVar.f171a;
            aVar.f167l = null;
            aVar.f170o = 2;
            objA = cVar2.b(aVar);
            if (objA == aVar2) {
                return aVar2;
            }
        }
        return objA;
    }
}
