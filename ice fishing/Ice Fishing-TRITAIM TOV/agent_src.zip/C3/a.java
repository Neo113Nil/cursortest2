package C3;

/* loaded from: classes.dex */
public final class a extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public C3.b f167l;

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f168m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ C3.b f169n;

    /* renamed from: o, reason: collision with root package name */
    public int f170o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(C3.b bVar, W3.c cVar) {
        super(cVar);
        this.f169n = bVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f168m = obj;
        this.f170o |= Integer.MIN_VALUE;
        return this.f169n.a(this);
    }
}
