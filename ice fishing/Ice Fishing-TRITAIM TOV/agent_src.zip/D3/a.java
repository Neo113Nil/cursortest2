package D3;

/* loaded from: classes.dex */
public final class a implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f255j;

    public /* synthetic */ a(int i, java.lang.Object obj) {
        this.i = i;
        this.f255j = obj;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        switch (this.i) {
            case 0:
                F.C0027n c0027n = (F.C0027n) obj;
                if ((((java.lang.Number) obj2).intValue() & 3) == 2 && c0027n.s()) {
                    c0027n.H();
                } else {
                    h4.AbstractC0412a.d(0, null, c0027n, (H3.a) this.f255j);
                }
                break;
            default:
                F.C0027n c0027n2 = (F.C0027n) obj;
                if ((((java.lang.Number) obj2).intValue() & 3) == 2 && c0027n2.s()) {
                    c0027n2.H();
                } else {
                    c0027n2.K(-1128986290);
                    java.lang.Object objC = c0027n2.C();
                    if (objC == F.C0019j.f572a) {
                        objC = new H3.a((com.jorden.karto.setrisopira.feature.splash.presentation.SplashActivity) this.f255j);
                        c0027n2.T(objC);
                    }
                    c0027n2.m(false);
                    F3.f.a(null, null, null, M.k.d(261450262, new D3.a(0, (H3.a) objC), c0027n2), c0027n2, 3072);
                }
                break;
        }
        return Q3.o.f3335a;
    }
}
