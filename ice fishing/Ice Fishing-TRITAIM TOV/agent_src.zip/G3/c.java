package G3;

/* loaded from: classes.dex */
public final /* synthetic */ class c implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Q.m f1162j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ int f1163k;

    public /* synthetic */ c(Q.m mVar, int i, int i6) {
        this.i = i6;
        this.f1162j = mVar;
        this.f1163k = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        int i = this.i;
        F.C0027n c0027n = (F.C0027n) obj;
        ((java.lang.Integer) obj2).getClass();
        switch (i) {
            case 0:
                K4.h.b(this.f1162j, c0027n, F.C0003b.o(this.f1163k | 1));
                break;
            default:
                r2.AbstractC0796a.f(this.f1162j, c0027n, F.C0003b.o(this.f1163k | 1));
                break;
        }
        return Q3.o.f3335a;
    }
}
