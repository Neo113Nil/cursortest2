package G3;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1155j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1156k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1157l;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1158m;

    public /* synthetic */ a(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, int i, int i6) {
        this.i = i6;
        this.f1156k = obj;
        this.f1157l = obj2;
        this.f1158m = obj3;
        this.f1155j = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        F.C0027n c0027n = (F.C0027n) obj;
        java.lang.Integer num = (java.lang.Integer) obj2;
        switch (this.i) {
            case 0:
                num.getClass();
                int iO = F.C0003b.o(this.f1155j | 1);
                r2.AbstractC0796a.g((java.lang.String) this.f1156k, (e4.InterfaceC0293a) this.f1157l, (Q.m) this.f1158m, c0027n, iO);
                break;
            case 1:
                num.intValue();
                h4.AbstractC0412a.e((E3.e) this.f1156k, (E3.f) this.f1157l, (H3.a) this.f1158m, c0027n, F.C0003b.o(this.f1155j | 1));
                break;
            default:
                num.getClass();
                int iO2 = F.C0003b.o(this.f1155j | 1);
                K4.h.d((java.lang.String) this.f1156k, (e4.InterfaceC0295c) this.f1157l, (Q.m) this.f1158m, c0027n, iO2);
                break;
        }
        return Q3.o.f3335a;
    }
}
