package G3;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1164j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ int f1165k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Q3.c f1166l;

    public /* synthetic */ d(e4.InterfaceC0293a interfaceC0293a, Q.m mVar, int i) {
        this.i = 1;
        this.f1166l = interfaceC0293a;
        this.f1164j = mVar;
        this.f1165k = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        F.C0027n c0027n = (F.C0027n) obj;
        java.lang.Integer num = (java.lang.Integer) obj2;
        switch (this.i) {
            case 0:
                num.getClass();
                int iO = F.C0003b.o(this.f1165k | 1);
                a.AbstractC0151a.c((Q.m) this.f1164j, (M.e) this.f1166l, c0027n, iO);
                break;
            case 1:
                num.getClass();
                b5.c.f((e4.InterfaceC0293a) this.f1166l, (Q.m) this.f1164j, c0027n, F.C0003b.o(this.f1165k | 1));
                break;
            default:
                num.intValue();
                K4.h.c((java.lang.String) this.f1164j, (e4.InterfaceC0295c) this.f1166l, c0027n, F.C0003b.o(this.f1165k | 1));
                break;
        }
        return Q3.o.f3335a;
    }

    public /* synthetic */ d(java.lang.Object obj, Q3.c cVar, int i, int i6) {
        this.i = i6;
        this.f1164j = obj;
        this.f1166l = cVar;
        this.f1165k = i;
    }
}
