package G3;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ java.lang.String f1167j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ Q.m f1168k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f1169l;

    public /* synthetic */ e(java.lang.String str, Q.m mVar, int i, int i6) {
        this.i = i6;
        this.f1167j = str;
        this.f1168k = mVar;
        this.f1169l = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        int i = this.i;
        F.C0027n c0027n = (F.C0027n) obj;
        ((java.lang.Integer) obj2).getClass();
        switch (i) {
            case 0:
                b5.c.g(this.f1167j, this.f1168k, c0027n, F.C0003b.o(this.f1169l | 1));
                break;
            default:
                b5.c.c(this.f1167j, this.f1168k, c0027n, F.C0003b.o(this.f1169l | 1));
                break;
        }
        return Q3.o.f3335a;
    }
}
