package I3;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public static final M.e f1416a = new M.e(-1490868346, false, I3.a.f1414j);
}
