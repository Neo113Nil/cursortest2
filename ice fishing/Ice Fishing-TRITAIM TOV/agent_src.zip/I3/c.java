package I3;

/* loaded from: classes.dex */
public abstract class c {

    /* renamed from: a, reason: collision with root package name */
    public static final M.e f1417a = new M.e(1575612170, false, I3.a.f1415k);
}
