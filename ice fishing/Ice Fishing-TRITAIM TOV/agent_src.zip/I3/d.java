package I3;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1418j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1419k;

    public /* synthetic */ d(int i, int i6, java.lang.Object obj) {
        this.i = i6;
        this.f1419k = obj;
        this.f1418j = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        int i = this.i;
        F.C0027n c0027n = (F.C0027n) obj;
        ((java.lang.Integer) obj2).intValue();
        switch (i) {
            case 0:
                b5.c.d((e4.InterfaceC0293a) this.f1419k, c0027n, F.C0003b.o(this.f1418j | 1));
                break;
            default:
                h4.AbstractC0412a.c((H3.a) this.f1419k, c0027n, F.C0003b.o(this.f1418j | 1));
                break;
        }
        return Q3.o.f3335a;
    }
}
