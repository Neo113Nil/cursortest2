package I3;

/* loaded from: classes.dex */
public final class a implements e4.InterfaceC0298f {

    /* renamed from: j, reason: collision with root package name */
    public static final I3.a f1414j = new I3.a(0);

    /* renamed from: k, reason: collision with root package name */
    public static final I3.a f1415k = new I3.a(1);
    public final /* synthetic */ int i;

    public /* synthetic */ a(int i) {
        this.i = i;
    }

    @Override // e4.InterfaceC0298f
    public final java.lang.Object j(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
        switch (this.i) {
            case 0:
                F.C0027n c0027n = (F.C0027n) obj2;
                int iIntValue = ((java.lang.Number) obj3).intValue();
                f4.i.e((z.i) obj, "$this$SplashSurface");
                if ((iIntValue & 17) == 16 && c0027n.s()) {
                    c0027n.H();
                } else {
                    r2.AbstractC0796a.e(0, c0027n);
                }
                break;
            default:
                F.C0027n c0027n2 = (F.C0027n) obj2;
                int iIntValue2 = ((java.lang.Number) obj3).intValue();
                f4.i.e((z.i) obj, "$this$SplashSurface");
                if ((iIntValue2 & 17) == 16 && c0027n2.s()) {
                    c0027n2.H();
                } else {
                    K4.h.b(null, c0027n2, 0);
                }
                break;
        }
        return Q3.o.f3335a;
    }
}
