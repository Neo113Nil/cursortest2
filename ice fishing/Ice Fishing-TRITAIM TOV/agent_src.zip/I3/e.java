package I3;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements e4.InterfaceC0297e {
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1420j;

    public /* synthetic */ e(int i, int i6) {
        this.i = i6;
        this.f1420j = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        int i = this.i;
        F.C0027n c0027n = (F.C0027n) obj;
        ((java.lang.Integer) obj2).intValue();
        switch (i) {
            case 0:
                b5.c.e(F.C0003b.o(this.f1420j | 1), c0027n);
                break;
            default:
                r2.AbstractC0796a.e(F.C0003b.o(this.f1420j | 1), c0027n);
                break;
        }
        return Q3.o.f3335a;
    }
}
