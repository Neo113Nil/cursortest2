package I3;

/* loaded from: classes.dex */
public final /* synthetic */ class g implements e4.InterfaceC0297e {
    public final /* synthetic */ int i = 1;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ E3.f f1421j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ H3.a f1422k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f1423l;

    public /* synthetic */ g(E3.f fVar, H3.a aVar, int i) {
        this.f1421j = fVar;
        this.f1422k = aVar;
        this.f1423l = i;
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        F.C0027n c0027n = (F.C0027n) obj;
        java.lang.Integer num = (java.lang.Integer) obj2;
        switch (this.i) {
            case 0:
                num.getClass();
                h4.AbstractC0412a.d(F.C0003b.o(this.f1423l | 1), this.f1421j, c0027n, this.f1422k);
                break;
            default:
                num.intValue();
                h4.AbstractC0412a.b(F.C0003b.o(this.f1423l | 1), this.f1421j, c0027n, this.f1422k);
                break;
        }
        return Q3.o.f3335a;
    }

    public /* synthetic */ g(H3.a aVar, E3.f fVar, int i) {
        this.f1422k = aVar;
        this.f1421j = fVar;
        this.f1423l = i;
    }
}
