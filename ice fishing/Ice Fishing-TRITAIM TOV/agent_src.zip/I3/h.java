package I3;

/* loaded from: classes.dex */
public final class h extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ H3.a f1424m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(H3.a aVar, U3.d dVar) {
        super(2, dVar);
        this.f1424m = aVar;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        return new I3.h(this.f1424m, dVar);
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        I3.h hVar = (I3.h) a((U3.d) obj2, (q4.InterfaceC0783x) obj);
        Q3.o oVar = Q3.o.f3335a;
        hVar.n(oVar);
        return oVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        b5.c.Z(obj);
        H3.a aVar = this.f1424m;
        aVar.getClass();
        android.app.Activity activity = aVar.f1385a;
        activity.startActivity(new android.content.Intent(activity, (java.lang.Class<?>) com.jorden.karto.setrisopira.MainActivity.class));
        activity.finish();
        return Q3.o.f3335a;
    }
}
