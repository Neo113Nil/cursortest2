package I3;

/* loaded from: classes.dex */
public final /* synthetic */ class j extends f4.h implements e4.InterfaceC0295c {

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f1426q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ j(int i, java.lang.Object obj, java.lang.Class cls, java.lang.String str, java.lang.String str2, int i6, int i7) {
        super(i, i6, cls, obj, str, str2);
        this.f1426q = i7;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x006c  */
    @Override // e4.InterfaceC0295c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object l(java.lang.Object obj) {
        switch (this.f1426q) {
            case 0:
                java.lang.String str = (java.lang.String) obj;
                f4.i.e(str, "p0");
                H3.a aVar = (H3.a) this.f6471j;
                aVar.getClass();
                try {
                    D4.h hVar = new D4.h(3, false);
                    ((android.content.Intent) hVar.f296b).putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 0);
                    l0.C0488m c0488mB = hVar.b();
                    android.app.Activity activity = aVar.f1385a;
                    android.net.Uri uri = android.net.Uri.parse(str);
                    android.content.Intent intent = (android.content.Intent) c0488mB.f7360b;
                    intent.setData(uri);
                    activity.startActivity(intent, (android.os.Bundle) c0488mB.f7361c);
                } catch (android.content.ActivityNotFoundException | java.lang.IllegalArgumentException unused) {
                }
                return Q3.o.f3335a;
            case 1:
                java.util.Set set = (java.util.Set) obj;
                f4.i.e(set, "p0");
                M1.C0116i c0116i = (M1.C0116i) this.f6471j;
                java.util.concurrent.locks.ReentrantLock reentrantLock = c0116i.f2417e;
                reentrantLock.lock();
                try {
                    java.util.List<M1.C0128v> listZ0 = R3.n.z0(c0116i.f2416d.values());
                    reentrantLock.unlock();
                    for (M1.C0128v c0128v : listZ0) {
                        c0128v.getClass();
                        int[] iArr = c0128v.f2456b;
                        int length = iArr.length;
                        java.util.Collection collectionJ = R3.x.i;
                        if (length != 0) {
                            if (length != 1) {
                                S3.i iVar = new S3.i();
                                int length2 = iArr.length;
                                int i = 0;
                                int i6 = 0;
                                while (i < length2) {
                                    int i7 = i6 + 1;
                                    if (set.contains(java.lang.Integer.valueOf(iArr[i]))) {
                                        iVar.add(c0128v.f2457c[i6]);
                                    }
                                    i++;
                                    i6 = i7;
                                }
                                collectionJ = r2.AbstractC0796a.j(iVar);
                            } else if (set.contains(java.lang.Integer.valueOf(iArr[0]))) {
                                collectionJ = c0128v.f2458d;
                            }
                        }
                        if (!collectionJ.isEmpty()) {
                            B4.b bVar = c0128v.f2455a;
                            bVar.getClass();
                            f4.i.e(collectionJ, "tables");
                            M1.C0123p c0123p = (M1.C0123p) bVar.f94k;
                            if (!c0123p.f2439e.get()) {
                                try {
                                    M1.InterfaceC0113f interfaceC0113f = c0123p.f2441g;
                                    if (interfaceC0113f != null) {
                                        interfaceC0113f.e(c0123p.f2440f, (java.lang.String[]) collectionJ.toArray(new java.lang.String[0]));
                                    }
                                } catch (android.os.RemoteException e6) {
                                    android.util.Log.w("ROOM", "Cannot broadcast invalidation", e6);
                                }
                            }
                        }
                    }
                    return Q3.o.f3335a;
                } catch (java.lang.Throwable th) {
                    reentrantLock.unlock();
                    throw th;
                }
            case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                e4.InterfaceC0293a interfaceC0293a = (e4.InterfaceC0293a) obj;
                s.C0807C c0807c = ((m0.C0613s) this.f6471j).f8039y0;
                if (c0807c.f(interfaceC0293a) < 0) {
                    c0807c.a(interfaceC0293a);
                }
                return Q3.o.f3335a;
            default:
                boolean zBooleanValue = ((java.lang.Boolean) obj).booleanValue();
                v.s sVar = (v.s) this.f6471j;
                if (zBooleanValue) {
                    sVar.f0();
                } else {
                    x.C0997f c0997f = sVar.f9505y;
                    s.y yVar = sVar.f9501J;
                    if (c0997f != null) {
                        java.lang.Object[] objArr = yVar.f8860c;
                        long[] jArr = yVar.f8858a;
                        int length3 = jArr.length - 2;
                        if (length3 >= 0) {
                            int i8 = 0;
                            while (true) {
                                long j5 = jArr[i8];
                                if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                                    int i9 = 8;
                                    int i10 = 8 - ((~(i8 - length3)) >>> 31);
                                    for (int i11 = 0; i11 < i10; i11++) {
                                        if ((255 & j5) < 128) {
                                            q4.AbstractC0784y.r(sVar.Q(), null, 0, new v.C0902e(sVar, (x.C0999h) objArr[(i8 << 3) + i11], null), 3);
                                            i9 = 8;
                                        }
                                        j5 >>= i9;
                                    }
                                    if (i10 == i9) {
                                        if (i8 != length3) {
                                            i8++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    yVar.a();
                }
                return Q3.o.f3335a;
        }
    }
}
