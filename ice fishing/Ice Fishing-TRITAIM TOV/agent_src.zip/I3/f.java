package I3;

/* loaded from: classes.dex */
public final class f implements e4.InterfaceC0298f {
    public final /* synthetic */ e4.InterfaceC0293a i;

    public f(e4.InterfaceC0293a interfaceC0293a) {
        this.i = interfaceC0293a;
    }

    @Override // e4.InterfaceC0298f
    public final java.lang.Object j(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
        F.C0027n c0027n = (F.C0027n) obj2;
        int iIntValue = ((java.lang.Number) obj3).intValue();
        f4.i.e((z.i) obj, "$this$SplashSurface");
        if ((iIntValue & 17) == 16 && c0027n.s()) {
            c0027n.H();
        } else {
            b5.c.d(this.i, c0027n, 0);
        }
        return Q3.o.f3335a;
    }
}
