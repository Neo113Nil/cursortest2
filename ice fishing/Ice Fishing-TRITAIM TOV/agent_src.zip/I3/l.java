package I3;

/* loaded from: classes.dex */
public final class l implements F.D {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1429a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1430b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1431c;

    public /* synthetic */ l(int i, java.lang.Object obj, java.lang.Object obj2) {
        this.f1429a = i;
        this.f1430b = obj;
        this.f1431c = obj2;
    }

    @Override // F.D
    public final void a() {
        java.lang.Object obj = this.f1431c;
        java.lang.Object obj2 = this.f1430b;
        switch (this.f1429a) {
            case 0:
                ((androidx.lifecycle.InterfaceC0211v) obj2).f().f((H1.j) obj);
                break;
            case 1:
                ((android.content.Context) obj2).getApplicationContext().unregisterComponentCallbacks((m0.ComponentCallbacks2C0582J) obj);
                break;
            case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                ((android.content.Context) obj2).getApplicationContext().unregisterComponentCallbacks((m0.K) obj);
                break;
            case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                ((u.l) obj2).f9263a.i((u.h) obj);
                break;
            default:
                z.C1019B c1019b = (z.C1019B) obj2;
                int i = c1019b.f10293t - 1;
                c1019b.f10293t = i;
                if (i == 0) {
                    java.util.WeakHashMap weakHashMap = e1.L.f6124a;
                    android.view.View view = (android.view.View) obj;
                    e1.D.l(view, null);
                    e1.L.o(view, null);
                    view.removeOnAttachStateChangeListener(c1019b.f10294u);
                    break;
                }
                break;
        }
    }
}
