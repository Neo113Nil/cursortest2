package I3;

/* loaded from: classes.dex */
public final /* synthetic */ class i extends f4.h implements e4.InterfaceC0293a {

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f1425q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ i(int i, java.lang.Object obj, java.lang.Class cls, java.lang.String str, java.lang.String str2, int i6, int i7) {
        super(i, i6, cls, obj, str, str2);
        this.f1425q = i7;
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x00d2  */
    @Override // e4.InterfaceC0293a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object b() throws java.lang.Exception {
        com.google.android.material.datepicker.C0245c c0245c;
        android.view.contentcapture.ContentCaptureSession contentCaptureSessionA;
        switch (this.f1425q) {
            case 0:
                J3.b bVar = (J3.b) ((E3.f) this.f6471j);
                q4.p0 p0Var = bVar.f1550e;
                if (p0Var == null || !p0Var.c()) {
                    bVar.e();
                }
                return Q3.o.f3335a;
            case 1:
                M1.D d2 = (M1.D) this.f6471j;
                v4.e eVar = d2.f2287a;
                if (eVar == null) {
                    f4.i.k("coroutineScope");
                    throw null;
                }
                q4.AbstractC0784y.e(eVar, null);
                M1.C0123p c0123p = d2.d().i;
                if (c0123p != null && c0123p.f2439e.compareAndSet(false, true)) {
                    M1.C0116i c0116i = c0123p.f2436b;
                    B4.b bVar2 = c0123p.i;
                    f4.i.e(bVar2, "observer");
                    java.util.concurrent.locks.ReentrantLock reentrantLock = c0116i.f2417e;
                    reentrantLock.lock();
                    try {
                        M1.C0128v c0128v = (M1.C0128v) c0116i.f2416d.remove(bVar2);
                        if (c0128v != null) {
                            M1.Z z5 = c0116i.f2415c;
                            z5.getClass();
                            int[] iArr = c0128v.f2456b;
                            f4.i.e(iArr, "tableIds");
                            if (z5.f2383h.e(iArr)) {
                                M1.C0115h c0115h = new M1.C0115h(c0116i, null);
                                java.lang.Thread.interrupted();
                                q4.AbstractC0784y.v(U3.j.i, new O1.z(c0115h, null));
                            }
                        }
                        try {
                            M1.InterfaceC0113f interfaceC0113f = c0123p.f2441g;
                            if (interfaceC0113f != null) {
                                interfaceC0113f.a(c0123p.f2443j, c0123p.f2440f);
                            }
                        } catch (android.os.RemoteException e6) {
                            android.util.Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", e6);
                        }
                        c0123p.f2437c.unbindService(c0123p.f2444k);
                    } finally {
                        reentrantLock.unlock();
                    }
                }
                M1.C0132z c0132z = d2.f2291e;
                if (c0132z != null) {
                    c0132z.f2465f.close();
                    return Q3.o.f3335a;
                }
                f4.i.k("connectionManager");
                throw null;
            case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                V.e eVar2 = (V.e) this.f6471j;
                V.o oVar = (V.o) eVar2.f3671c.d();
                s.C0809E c0809e = eVar2.f3672d;
                s.C0809E c0809e2 = eVar2.f3673e;
                if (oVar == null) {
                    java.lang.Object[] objArr = c0809e2.f8752b;
                    long[] jArr = c0809e2.f8751a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i = 0;
                        while (true) {
                            long j5 = jArr[i];
                            if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i6 = 8 - ((~(i - length)) >>> 31);
                                for (int i7 = 0; i7 < i6; i7++) {
                                    if ((j5 & 255) < 128) {
                                        ((l0.C0478c) objArr[(i << 3) + i7]).c0();
                                        throw null;
                                    }
                                    j5 >>= 8;
                                }
                                if (i6 == 8) {
                                    if (i != length) {
                                        i++;
                                    }
                                }
                            }
                        }
                    }
                } else if (oVar.f3305v) {
                    if (c0809e.c(oVar)) {
                        oVar.e0();
                    }
                    oVar.d0();
                    if (!oVar.i.f3305v) {
                        i0.AbstractC0413a.b("visitAncestors called on an unattached node");
                    }
                    Q.l lVar = oVar.i;
                    l0.F fR = l0.AbstractC0481f.r(oVar);
                    int i8 = 0;
                    while (fR != null) {
                        if ((((Q.l) fR.f7151K.f5778f).f3295l & 5120) != 0) {
                            while (lVar != null) {
                                int i9 = lVar.f3294k;
                                if ((i9 & 5120) != 0) {
                                    if ((i9 & 1024) != 0) {
                                        i8++;
                                    }
                                    if ((lVar instanceof l0.C0478c) && c0809e2.c(lVar)) {
                                        if (i8 <= 1) {
                                            ((l0.C0478c) lVar).c0();
                                            throw null;
                                        }
                                        ((l0.C0478c) lVar).c0();
                                        throw null;
                                    }
                                }
                                lVar = lVar.f3296m;
                            }
                        }
                        fR = fR.m();
                        lVar = (fR == null || (c0245c = fR.f7151K) == null) ? null : (l0.o0) c0245c.f5777e;
                    }
                    java.lang.Object[] objArr2 = c0809e2.f8752b;
                    long[] jArr2 = c0809e2.f8751a;
                    int length2 = jArr2.length - 2;
                    if (length2 >= 0) {
                        int i10 = 0;
                        while (true) {
                            long j6 = jArr2[i10];
                            if ((((~j6) << 7) & j6 & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i11 = 8 - ((~(i10 - length2)) >>> 31);
                                for (int i12 = 0; i12 < i11; i12++) {
                                    if ((j6 & 255) < 128) {
                                        ((l0.C0478c) objArr2[(i10 << 3) + i12]).c0();
                                        throw null;
                                    }
                                    j6 >>= 8;
                                }
                                if (i11 == 8) {
                                }
                            }
                            if (i10 != length2) {
                                i10++;
                            }
                        }
                    }
                }
                eVar2.f3670b.b();
                c0809e.b();
                c0809e2.b();
                eVar2.f3674f = false;
                return Q3.o.f3335a;
            case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                V.j jVar = (V.j) this.f6471j;
                if (jVar.f3686j == null || jVar.f3681d.d0() == V.n.f3706l) {
                    jVar.f3679b.b();
                }
                return Q3.o.f3335a;
            case o1.C0707g.LONG_FIELD_NUMBER /* 4 */:
                ((b.y) this.f6471j).e();
                return Q3.o.f3335a;
            case o1.C0707g.STRING_FIELD_NUMBER /* 5 */:
                ((b.y) this.f6471j).e();
                return Q3.o.f3335a;
            case o1.C0707g.STRING_SET_FIELD_NUMBER /* 6 */:
                android.view.View view = (android.view.View) this.f6471j;
                int i13 = android.os.Build.VERSION.SDK_INT;
                if (i13 >= 30) {
                    X0.b.f(view);
                }
                if (i13 < 29 || (contentCaptureSessionA = W0.b.a(view)) == null) {
                    return null;
                }
                return new o0.C0700a(contentCaptureSessionA, view);
            default:
                m0.C0613s c0613s = (m0.C0613s) this.f6471j;
                if (c0613s.isFocused() || c0613s.hasFocus()) {
                    c0613s.clearFocus();
                } else if (c0613s.hasFocus()) {
                    android.view.View viewFindFocus = c0613s.findFocus();
                    if (viewFindFocus != null) {
                        viewFindFocus.clearFocus();
                    }
                    c0613s.clearFocus();
                }
                return Q3.o.f3335a;
        }
    }
}
