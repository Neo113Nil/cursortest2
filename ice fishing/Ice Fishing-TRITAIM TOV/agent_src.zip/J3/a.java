package J3;

/* loaded from: classes.dex */
public final class a extends W3.i implements e4.InterfaceC0297e {

    /* renamed from: m, reason: collision with root package name */
    public t4.M f1543m;

    /* renamed from: n, reason: collision with root package name */
    public t4.M f1544n;

    /* renamed from: o, reason: collision with root package name */
    public int f1545o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ J3.b f1546p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(J3.b bVar, U3.d dVar) {
        super(2, dVar);
        this.f1546p = bVar;
    }

    @Override // W3.a
    public final U3.d a(U3.d dVar, java.lang.Object obj) {
        return new J3.a(this.f1546p, dVar);
    }

    @Override // e4.InterfaceC0297e
    public final java.lang.Object k(java.lang.Object obj, java.lang.Object obj2) {
        return ((J3.a) a((U3.d) obj2, (q4.InterfaceC0783x) obj)).n(Q3.o.f3335a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [int] */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        java.lang.Object objD0;
        t4.M m5;
        V3.a aVar = V3.a.i;
        ?? r12 = this.f1545o;
        try {
            if (r12 == 0) {
                b5.c.Z(obj);
                J3.b bVar = this.f1546p;
                t4.M m6 = bVar.f1548c;
                C3.b bVar2 = bVar.f1547b;
                this.f1543m = m6;
                this.f1544n = m6;
                this.f1545o = 1;
                obj = bVar2.a(this);
                if (obj == aVar) {
                    return aVar;
                }
                m5 = m6;
                r12 = m6;
            } else {
                if (r12 != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                m5 = this.f1544n;
                t4.M m7 = this.f1543m;
                b5.c.Z(obj);
                r12 = m7;
            }
            objD0 = K4.h.d0((A3.d) obj);
        } catch (java.util.concurrent.CancellationException e6) {
            throw e6;
        } catch (java.lang.Exception unused) {
            objD0 = E3.a.f389a;
            m5 = r12;
        }
        m5.getClass();
        m5.j(null, objD0);
        return Q3.o.f3335a;
    }
}
