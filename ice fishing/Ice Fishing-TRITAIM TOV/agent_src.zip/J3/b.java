package J3;

/* loaded from: classes.dex */
public final class b extends androidx.lifecycle.Z implements E3.f {

    /* renamed from: b, reason: collision with root package name */
    public final C3.b f1547b;

    /* renamed from: c, reason: collision with root package name */
    public final t4.M f1548c;

    /* renamed from: d, reason: collision with root package name */
    public final t4.x f1549d;

    /* renamed from: e, reason: collision with root package name */
    public q4.p0 f1550e;

    public b(C3.b bVar) {
        this.f1547b = bVar;
        t4.M mB = t4.C.b(E3.b.f390a);
        this.f1548c = mB;
        this.f1549d = new t4.x(mB);
        e();
    }

    public final void e() {
        E3.b bVar = E3.b.f390a;
        t4.M m5 = this.f1548c;
        m5.getClass();
        m5.j(null, bVar);
        this.f1550e = q4.AbstractC0784y.r(androidx.lifecycle.U.j(this), null, 0, new J3.a(this, null), 3);
    }
}
