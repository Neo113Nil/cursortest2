package com.jorden.karto.setrisopira.data.db;

/* loaded from: classes.dex */
public abstract class LedgerDatabase extends M1.D {
    public abstract m3.C0676c j();

    public abstract m3.C0680g k();
}
