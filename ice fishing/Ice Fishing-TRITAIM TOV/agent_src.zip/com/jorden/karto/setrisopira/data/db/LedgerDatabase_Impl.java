package com.jorden.karto.setrisopira.data.db;

/* loaded from: classes.dex */
public final class LedgerDatabase_Impl extends com.jorden.karto.setrisopira.data.db.LedgerDatabase {

    /* renamed from: j, reason: collision with root package name */
    public final Q3.m f6045j;

    /* renamed from: k, reason: collision with root package name */
    public final Q3.m f6046k;

    public LedgerDatabase_Impl() {
        final int i = 0;
        this.f6045j = a.AbstractC0151a.D(new e4.InterfaceC0293a(this) { // from class: m3.e

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.data.db.LedgerDatabase_Impl f8410j;

            {
                this.f8410j = this;
            }

            @Override // e4.InterfaceC0293a
            public final java.lang.Object b() {
                switch (i) {
                    case 0:
                        return new m3.C0680g(this.f8410j);
                    default:
                        return new m3.C0676c(this.f8410j);
                }
            }
        });
        final int i6 = 1;
        this.f6046k = a.AbstractC0151a.D(new e4.InterfaceC0293a(this) { // from class: m3.e

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.data.db.LedgerDatabase_Impl f8410j;

            {
                this.f8410j = this;
            }

            @Override // e4.InterfaceC0293a
            public final java.lang.Object b() {
                switch (i6) {
                    case 0:
                        return new m3.C0680g(this.f8410j);
                    default:
                        return new m3.C0676c(this.f8410j);
                }
            }
        });
    }

    @Override // M1.D
    public final java.util.List a(java.util.LinkedHashMap linkedHashMap) {
        return new java.util.ArrayList();
    }

    @Override // M1.D
    public final M1.C0116i b() {
        return new M1.C0116i(this, new java.util.LinkedHashMap(), new java.util.LinkedHashMap(), "visit_marks", "duel_record");
    }

    @Override // M1.D
    public final L1.J c() {
        return new m3.C0679f(this);
    }

    @Override // M1.D
    public final java.util.Set e() {
        return new java.util.LinkedHashSet();
    }

    @Override // M1.D
    public final java.util.LinkedHashMap f() {
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
        f4.C0372d c0372dA = f4.s.a(m3.C0680g.class);
        R3.v vVar = R3.v.i;
        linkedHashMap.put(c0372dA, vVar);
        linkedHashMap.put(f4.s.a(m3.C0676c.class), vVar);
        return linkedHashMap;
    }

    @Override // com.jorden.karto.setrisopira.data.db.LedgerDatabase
    public final m3.C0676c j() {
        return (m3.C0676c) this.f6046k.getValue();
    }

    @Override // com.jorden.karto.setrisopira.data.db.LedgerDatabase
    public final m3.C0680g k() {
        return (m3.C0680g) this.f6045j.getValue();
    }
}
