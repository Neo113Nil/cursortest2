package com.jorden.karto.setrisopira;

/* loaded from: classes.dex */
public final class MainActivity extends h.AbstractActivityC0402k {

    /* renamed from: H, reason: collision with root package name */
    public static final /* synthetic */ int f6043H = 0;

    /* renamed from: G, reason: collision with root package name */
    public A1.b f6044G;

    public MainActivity() {
        ((B4.b) this.f5329l.f94k).G("androidx:appcompat", new S1.a(this));
        i(new h.C0401j(this));
    }

    @Override // h.AbstractActivityC0402k, b.k, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        int i = 0;
        super.onCreate(bundle);
        android.view.View viewInflate = getLayoutInflater().inflate(com.jorden.karto.setrisopira.R.layout.activity_main, (android.view.ViewGroup) null, false);
        int i6 = com.jorden.karto.setrisopira.R.id.appBarLayout;
        if (((com.google.android.material.appbar.AppBarLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.appBarLayout)) != null) {
            i6 = com.jorden.karto.setrisopira.R.id.contentFrame;
            androidx.coordinatorlayout.widget.CoordinatorLayout coordinatorLayout = (androidx.coordinatorlayout.widget.CoordinatorLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.contentFrame);
            if (coordinatorLayout != null) {
                androidx.drawerlayout.widget.DrawerLayout drawerLayout = (androidx.drawerlayout.widget.DrawerLayout) viewInflate;
                i6 = com.jorden.karto.setrisopira.R.id.navHostFragment;
                if (((androidx.fragment.app.FragmentContainerView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.navHostFragment)) != null) {
                    int i7 = com.jorden.karto.setrisopira.R.id.navigationView;
                    com.google.android.material.navigation.NavigationView navigationView = (com.google.android.material.navigation.NavigationView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.navigationView);
                    if (navigationView != null) {
                        i7 = com.jorden.karto.setrisopira.R.id.toolbar;
                        com.google.android.material.appbar.MaterialToolbar materialToolbar = (com.google.android.material.appbar.MaterialToolbar) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.toolbar);
                        if (materialToolbar != null) {
                            this.f6044G = new A1.b(drawerLayout, coordinatorLayout, drawerLayout, navigationView, materialToolbar);
                            A4.e eVar = new A4.e(25);
                            java.util.WeakHashMap weakHashMap = e1.L.f6124a;
                            e1.D.l(coordinatorLayout, eVar);
                            A1.b bVar = this.f6044G;
                            if (bVar == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            setContentView((androidx.drawerlayout.widget.DrawerLayout) bVar.f3b);
                            A1.b bVar2 = this.f6044G;
                            if (bVar2 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            e1.AbstractC0260B.c((androidx.coordinatorlayout.widget.CoordinatorLayout) bVar2.f4c);
                            A1.b bVar3 = this.f6044G;
                            if (bVar3 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            h.LayoutInflaterFactory2C0386C layoutInflaterFactory2C0386C = (h.LayoutInflaterFactory2C0386C) m();
                            if (layoutInflaterFactory2C0386C.f6578r instanceof android.app.Activity) {
                                layoutInflaterFactory2C0386C.B();
                                h.AbstractC0392a abstractC0392a = layoutInflaterFactory2C0386C.f6583w;
                                if (abstractC0392a instanceof h.N) {
                                    throw new java.lang.IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
                                }
                                layoutInflaterFactory2C0386C.f6584x = null;
                                if (abstractC0392a != null) {
                                    abstractC0392a.r();
                                }
                                layoutInflaterFactory2C0386C.f6583w = null;
                                com.google.android.material.appbar.MaterialToolbar materialToolbar2 = (com.google.android.material.appbar.MaterialToolbar) bVar3.f7f;
                                java.lang.Object obj = layoutInflaterFactory2C0386C.f6578r;
                                h.J j5 = new h.J(materialToolbar2, obj instanceof android.app.Activity ? ((android.app.Activity) obj).getTitle() : layoutInflaterFactory2C0386C.f6585y, layoutInflaterFactory2C0386C.f6581u);
                                layoutInflaterFactory2C0386C.f6583w = j5;
                                layoutInflaterFactory2C0386C.f6581u.f6714j = j5.f6600c;
                                materialToolbar2.setBackInvokedCallbackEnabled(true);
                                layoutInflaterFactory2C0386C.b();
                            }
                            w1.AbstractComponentCallbacksC0987w abstractComponentCallbacksC0987wE = ((w1.C0989y) this.f6696A.f9857a).f10110l.E(com.jorden.karto.setrisopira.R.id.navHostFragment);
                            f4.i.c(abstractComponentCallbacksC0987wE, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
                            F1.H hM = ((androidx.navigation.fragment.NavHostFragment) abstractComponentCallbacksC0987wE).M();
                            java.util.Set setG0 = R3.l.g0(new java.lang.Integer[]{java.lang.Integer.valueOf(com.jorden.karto.setrisopira.R.id.homeFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisopira.R.id.catalogFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisopira.R.id.quizFragment), java.lang.Integer.valueOf(com.jorden.karto.setrisopira.R.id.profileFragment)});
                            A1.b bVar4 = this.f6044G;
                            if (bVar4 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            java.util.HashSet hashSet = new java.util.HashSet();
                            hashSet.addAll(setG0);
                            final B4.b bVar5 = new B4.b(hashSet, (androidx.drawerlayout.widget.DrawerLayout) bVar4.f5d, new l3.b(), 4);
                            A1.b bVar6 = this.f6044G;
                            if (bVar6 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            com.google.android.material.appbar.MaterialToolbar materialToolbar3 = (com.google.android.material.appbar.MaterialToolbar) bVar6.f7f;
                            f4.i.e(hM, "navController");
                            hM.b(new I1.d(materialToolbar3, bVar5));
                            materialToolbar3.setNavigationOnClickListener(new I1.a(i, hM, bVar5));
                            A1.b bVar7 = this.f6044G;
                            if (bVar7 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            com.google.android.material.navigation.NavigationView navigationView2 = (com.google.android.material.navigation.NavigationView) bVar7.f6e;
                            navigationView2.setNavigationItemSelectedListener(new I1.b(hM, navigationView2));
                            hM.b(new I1.c(new java.lang.ref.WeakReference(navigationView2), hM));
                            A1.b bVar8 = this.f6044G;
                            if (bVar8 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            final h.C0393b c0393b = new h.C0393b(this, (androidx.drawerlayout.widget.DrawerLayout) bVar8.f5d, (com.google.android.material.appbar.MaterialToolbar) bVar8.f7f);
                            A1.b bVar9 = this.f6044G;
                            if (bVar9 == null) {
                                f4.i.k("binding");
                                throw null;
                            }
                            ((androidx.drawerlayout.widget.DrawerLayout) bVar9.f5d).a(c0393b);
                            c0393b.f();
                            hM.b(new F1.InterfaceC0057p() { // from class: l3.a
                                @Override // F1.InterfaceC0057p
                                public final void a(F1.H h6, F1.D d2, android.os.Bundle bundle2) {
                                    int i8 = com.jorden.karto.setrisopira.MainActivity.f6043H;
                                    f4.i.e(h6, "<unused var>");
                                    f4.i.e(d2, "destination");
                                    boolean zContains = ((java.util.HashSet) bVar5.f93j).contains(java.lang.Integer.valueOf(d2.f796p));
                                    A1.b bVar10 = this.f6044G;
                                    if (bVar10 == null) {
                                        f4.i.k("binding");
                                        throw null;
                                    }
                                    ((androidx.drawerlayout.widget.DrawerLayout) bVar10.f5d).setDrawerLockMode(!zContains ? 1 : 0);
                                    h.C0393b c0393b2 = c0393b;
                                    if (zContains != c0393b2.f6644e) {
                                        if (zContains) {
                                            android.view.View viewF = c0393b2.f6641b.f(8388611);
                                            c0393b2.d(c0393b2.f6642c, viewF != null ? androidx.drawerlayout.widget.DrawerLayout.o(viewF) : false ? c0393b2.f6646g : c0393b2.f6645f);
                                        } else {
                                            c0393b2.d(c0393b2.f6643d, 0);
                                        }
                                        c0393b2.f6644e = zContains;
                                    }
                                    c0393b2.f();
                                }
                            });
                            return;
                        }
                    }
                    i6 = i7;
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i6)));
    }
}
