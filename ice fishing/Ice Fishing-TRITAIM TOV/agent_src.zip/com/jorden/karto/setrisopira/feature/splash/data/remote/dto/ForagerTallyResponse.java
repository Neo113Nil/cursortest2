package com.jorden.karto.setrisopira.feature.splash.data.remote.dto;

/* loaded from: classes.dex */
public final class ForagerTallyResponse {
    public static final int $stable = 0;

    @d3.b("bracketProfile")
    private final java.lang.String bracketProfile;

    @d3.b("discoveryDate")
    private final java.lang.String discoveryDate;

    @d3.b("duelScore")
    private final java.lang.Integer duelScore;

    @d3.b("fruitingMonth")
    private final java.lang.Integer fruitingMonth;

    @d3.b("hostTree")
    private final java.lang.String hostTree;

    @d3.b("isMature")
    private final java.lang.Boolean isMature;

    @d3.b("isOutlier")
    private final java.lang.Boolean isOutlier;

    @d3.b("maximumSpan")
    private final java.lang.Integer maximumSpan;

    @d3.b("speciesName")
    private final java.lang.String speciesName;

    @d3.b("visibleArc")
    private final java.lang.Double visibleArc;

    public ForagerTallyResponse(java.lang.String str, java.lang.Integer num, java.lang.String str2, java.lang.String str3, java.lang.Boolean bool, java.lang.Integer num2, java.lang.Double d2, java.lang.String str4, java.lang.Integer num3, java.lang.Boolean bool2) {
        f4.i.e(str, "speciesName");
        this.speciesName = str;
        this.maximumSpan = num;
        this.hostTree = str2;
        this.bracketProfile = str3;
        this.isMature = bool;
        this.fruitingMonth = num2;
        this.visibleArc = d2;
        this.discoveryDate = str4;
        this.duelScore = num3;
        this.isOutlier = bool2;
    }

    public final java.lang.String component1() {
        return this.speciesName;
    }

    public final java.lang.Boolean component10() {
        return this.isOutlier;
    }

    public final java.lang.Integer component2() {
        return this.maximumSpan;
    }

    public final java.lang.String component3() {
        return this.hostTree;
    }

    public final java.lang.String component4() {
        return this.bracketProfile;
    }

    public final java.lang.Boolean component5() {
        return this.isMature;
    }

    public final java.lang.Integer component6() {
        return this.fruitingMonth;
    }

    public final java.lang.Double component7() {
        return this.visibleArc;
    }

    public final java.lang.String component8() {
        return this.discoveryDate;
    }

    public final java.lang.Integer component9() {
        return this.duelScore;
    }

    public final com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse copy(java.lang.String str, java.lang.Integer num, java.lang.String str2, java.lang.String str3, java.lang.Boolean bool, java.lang.Integer num2, java.lang.Double d2, java.lang.String str4, java.lang.Integer num3, java.lang.Boolean bool2) {
        f4.i.e(str, "speciesName");
        return new com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse(str, num, str2, str3, bool, num2, d2, str4, num3, bool2);
    }

    public boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse)) {
            return false;
        }
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) obj;
        return f4.i.a(this.speciesName, foragerTallyResponse.speciesName) && f4.i.a(this.maximumSpan, foragerTallyResponse.maximumSpan) && f4.i.a(this.hostTree, foragerTallyResponse.hostTree) && f4.i.a(this.bracketProfile, foragerTallyResponse.bracketProfile) && f4.i.a(this.isMature, foragerTallyResponse.isMature) && f4.i.a(this.fruitingMonth, foragerTallyResponse.fruitingMonth) && f4.i.a(this.visibleArc, foragerTallyResponse.visibleArc) && f4.i.a(this.discoveryDate, foragerTallyResponse.discoveryDate) && f4.i.a(this.duelScore, foragerTallyResponse.duelScore) && f4.i.a(this.isOutlier, foragerTallyResponse.isOutlier);
    }

    public final java.lang.String getBracketProfile() {
        return this.bracketProfile;
    }

    public final java.lang.String getDiscoveryDate() {
        return this.discoveryDate;
    }

    public final java.lang.Integer getDuelScore() {
        return this.duelScore;
    }

    public final java.lang.Integer getFruitingMonth() {
        return this.fruitingMonth;
    }

    public final java.lang.String getHostTree() {
        return this.hostTree;
    }

    public final java.lang.Integer getMaximumSpan() {
        return this.maximumSpan;
    }

    public final java.lang.String getSpeciesName() {
        return this.speciesName;
    }

    public final java.lang.Double getVisibleArc() {
        return this.visibleArc;
    }

    public int hashCode() {
        int iHashCode = this.speciesName.hashCode() * 31;
        java.lang.Integer num = this.maximumSpan;
        int iHashCode2 = (iHashCode + (num == null ? 0 : num.hashCode())) * 31;
        java.lang.String str = this.hostTree;
        int iHashCode3 = (iHashCode2 + (str == null ? 0 : str.hashCode())) * 31;
        java.lang.String str2 = this.bracketProfile;
        int iHashCode4 = (iHashCode3 + (str2 == null ? 0 : str2.hashCode())) * 31;
        java.lang.Boolean bool = this.isMature;
        int iHashCode5 = (iHashCode4 + (bool == null ? 0 : bool.hashCode())) * 31;
        java.lang.Integer num2 = this.fruitingMonth;
        int iHashCode6 = (iHashCode5 + (num2 == null ? 0 : num2.hashCode())) * 31;
        java.lang.Double d2 = this.visibleArc;
        int iHashCode7 = (iHashCode6 + (d2 == null ? 0 : d2.hashCode())) * 31;
        java.lang.String str3 = this.discoveryDate;
        int iHashCode8 = (iHashCode7 + (str3 == null ? 0 : str3.hashCode())) * 31;
        java.lang.Integer num3 = this.duelScore;
        int iHashCode9 = (iHashCode8 + (num3 == null ? 0 : num3.hashCode())) * 31;
        java.lang.Boolean bool2 = this.isOutlier;
        return iHashCode9 + (bool2 != null ? bool2.hashCode() : 0);
    }

    public final java.lang.Boolean isMature() {
        return this.isMature;
    }

    public final java.lang.Boolean isOutlier() {
        return this.isOutlier;
    }

    public java.lang.String toString() {
        return "ForagerTallyResponse(speciesName=" + this.speciesName + ", maximumSpan=" + this.maximumSpan + ", hostTree=" + this.hostTree + ", bracketProfile=" + this.bracketProfile + ", isMature=" + this.isMature + ", fruitingMonth=" + this.fruitingMonth + ", visibleArc=" + this.visibleArc + ", discoveryDate=" + this.discoveryDate + ", duelScore=" + this.duelScore + ", isOutlier=" + this.isOutlier + ")";
    }

    public /* synthetic */ ForagerTallyResponse(java.lang.String str, java.lang.Integer num, java.lang.String str2, java.lang.String str3, java.lang.Boolean bool, java.lang.Integer num2, java.lang.Double d2, java.lang.String str4, java.lang.Integer num3, java.lang.Boolean bool2, int i, f4.AbstractC0373e abstractC0373e) {
        this(str, (i & 2) != 0 ? null : num, (i & 4) != 0 ? null : str2, (i & 8) != 0 ? null : str3, (i & 16) != 0 ? null : bool, (i & 32) != 0 ? null : num2, (i & 64) != 0 ? null : d2, (i & 128) != 0 ? null : str4, (i & 256) != 0 ? null : num3, (i & 512) == 0 ? bool2 : null);
    }
}
