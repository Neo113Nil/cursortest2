package com.jorden.karto.setrisopira.feature.splash.data.remote.dto;

/* loaded from: classes.dex */
public final class DeviceIdsPayload {
    public static final int $stable = 0;

    @d3.b("ruler")
    private final java.lang.String ruler;

    @d3.b("trunk")
    private final java.lang.String trunk;

    @d3.b("woodland")
    private final java.lang.String woodland;

    public DeviceIdsPayload(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        f4.i.e(str, "woodland");
        f4.i.e(str2, "trunk");
        f4.i.e(str3, "ruler");
        this.woodland = str;
        this.trunk = str2;
        this.ruler = str3;
    }

    public static /* synthetic */ com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload copy$default(com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload deviceIdsPayload, java.lang.String str, java.lang.String str2, java.lang.String str3, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            str = deviceIdsPayload.woodland;
        }
        if ((i & 2) != 0) {
            str2 = deviceIdsPayload.trunk;
        }
        if ((i & 4) != 0) {
            str3 = deviceIdsPayload.ruler;
        }
        return deviceIdsPayload.copy(str, str2, str3);
    }

    public final java.lang.String component1() {
        return this.woodland;
    }

    public final java.lang.String component2() {
        return this.trunk;
    }

    public final java.lang.String component3() {
        return this.ruler;
    }

    public final com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload copy(java.lang.String str, java.lang.String str2, java.lang.String str3) {
        f4.i.e(str, "woodland");
        f4.i.e(str2, "trunk");
        f4.i.e(str3, "ruler");
        return new com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload(str, str2, str3);
    }

    public boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload)) {
            return false;
        }
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload deviceIdsPayload = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.DeviceIdsPayload) obj;
        return f4.i.a(this.woodland, deviceIdsPayload.woodland) && f4.i.a(this.trunk, deviceIdsPayload.trunk) && f4.i.a(this.ruler, deviceIdsPayload.ruler);
    }

    public final java.lang.String getRuler() {
        return this.ruler;
    }

    public final java.lang.String getTrunk() {
        return this.trunk;
    }

    public final java.lang.String getWoodland() {
        return this.woodland;
    }

    public int hashCode() {
        return this.ruler.hashCode() + D.e.d(this.trunk, this.woodland.hashCode() * 31, 31);
    }

    public java.lang.String toString() {
        java.lang.String str = this.woodland;
        java.lang.String str2 = this.trunk;
        java.lang.String str3 = this.ruler;
        java.lang.StringBuilder sb = new java.lang.StringBuilder("DeviceIdsPayload(woodland=");
        sb.append(str);
        sb.append(", trunk=");
        sb.append(str2);
        sb.append(", ruler=");
        return D.e.q(sb, str3, ")");
    }
}
