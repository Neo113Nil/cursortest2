package com.jorden.karto.setrisopira.feature.splash.presentation;

/* loaded from: classes.dex */
public final class SplashActivity extends b.k {
    @Override // b.k, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        int i = 1;
        b.C0216A c0216a = new b.C0216A();
        b.C0216A c0216a2 = new b.C0216A();
        int i6 = b.m.f5345a;
        android.view.View decorView = getWindow().getDecorView();
        f4.i.d(decorView, "window.decorView");
        f4.i.d(decorView.getResources(), "view.resources");
        f4.i.d(decorView.getResources(), "view.resources");
        int i7 = android.os.Build.VERSION.SDK_INT;
        b.n qVar = i7 >= 30 ? new b.q() : i7 >= 29 ? new b.p() : i7 >= 28 ? new b.o() : new b.n();
        android.view.Window window = getWindow();
        f4.i.d(window, "window");
        qVar.b(c0216a, c0216a2, window, decorView, false, false);
        android.view.Window window2 = getWindow();
        f4.i.d(window2, "window");
        qVar.a(window2);
        super.onCreate(bundle);
        M.e eVar = new M.e(1670465602, true, new D3.a(i, this));
        android.view.ViewGroup.LayoutParams layoutParams = c.e.f5493a;
        android.view.View childAt = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        m0.Z z5 = childAt instanceof m0.Z ? (m0.Z) childAt : null;
        if (z5 != null) {
            z5.setParentCompositionContext(null);
            z5.setContent(eVar);
            return;
        }
        m0.Z z6 = new m0.Z(this);
        z6.setParentCompositionContext(null);
        z6.setContent(eVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (androidx.lifecycle.U.f(decorView2) == null) {
            androidx.lifecycle.U.m(decorView2, this);
        }
        if (androidx.lifecycle.U.g(decorView2) == null) {
            androidx.lifecycle.U.n(decorView2, this);
        }
        if (b5.c.A(decorView2) == null) {
            b5.c.U(decorView2, this);
        }
        setContentView(z6, c.e.f5493a);
    }
}
