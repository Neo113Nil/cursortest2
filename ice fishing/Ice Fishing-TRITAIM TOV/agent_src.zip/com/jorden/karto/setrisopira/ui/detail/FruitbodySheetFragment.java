package com.jorden.karto.setrisopira.ui.detail;

/* loaded from: classes.dex */
public final class FruitbodySheetFragment extends w1.AbstractComponentCallbacksC0987w {

    /* renamed from: e0, reason: collision with root package name */
    public q3.C0733b f6077e0;

    /* renamed from: f0, reason: collision with root package name */
    public final java.lang.Object f6078f0 = a.AbstractC0151a.C(Q3.f.i, new G4.t(this, new K3.g(1, this), 2));
    public final B0.a g0 = new B0.a(5, f4.s.a(M3.f.class), new C0.e(9, this));

    /* renamed from: h0, reason: collision with root package name */
    public boolean f6079h0;

    /* renamed from: i0, reason: collision with root package name */
    public final java.time.format.DateTimeFormatter f6080i0;

    public FruitbodySheetFragment() {
        java.time.format.DateTimeFormatter dateTimeFormatterOfPattern = java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy", java.util.Locale.getDefault());
        f4.i.d(dateTimeFormatterOfPattern, "ofPattern(...)");
        this.f6080i0 = dateTimeFormatterOfPattern;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [Q3.e, java.lang.Object] */
    @Override // w1.AbstractComponentCallbacksC0987w
    public final void F(android.view.View view) {
        f4.i.e(view, "view");
        q3.C0733b c0733b = this.f6077e0;
        if (c0733b == null) {
            return;
        }
        M3.m mVar = (M3.m) this.f6078f0.getValue();
        M3.f fVar = (M3.f) this.g0.getValue();
        mVar.getClass();
        java.lang.String str = fVar.f2478a;
        if (!f4.i.a(mVar.f2494f, str)) {
            mVar.f2494f = str;
            t3.e eVar = mVar.f2490b;
            eVar.getClass();
            s3.C0834a c0834aB = eVar.f9111a.b(str);
            if (c0834aB != null) {
                q4.AbstractC0784y.r(androidx.lifecycle.U.j(mVar), null, 0, new M3.k(mVar, str, c0834aB, null), 3);
            }
        }
        c0733b.f8560c.setOnClickListener(new M3.a(0, this));
        q4.AbstractC0784y.r(androidx.lifecycle.U.h(n()), null, 0, new M3.e(this, null), 3);
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final android.view.View x(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup) {
        f4.i.e(layoutInflater, "inflater");
        android.view.View viewInflate = layoutInflater.inflate(com.jorden.karto.setrisopira.R.layout.fragment_detail, viewGroup, false);
        int i = com.jorden.karto.setrisopira.R.id.copyLineButton;
        com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.copyLineButton);
        if (materialButton != null) {
            i = com.jorden.karto.setrisopira.R.id.pickDateButton;
            com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.pickDateButton);
            if (materialButton2 != null) {
                i = com.jorden.karto.setrisopira.R.id.seasonBand;
                com.jorden.karto.setrisopira.ui.common.SeasonBandView seasonBandView = (com.jorden.karto.setrisopira.ui.common.SeasonBandView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.seasonBand);
                if (seasonBandView != null) {
                    i = com.jorden.karto.setrisopira.R.id.seasonTitle;
                    if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.seasonTitle)) != null) {
                        i = com.jorden.karto.setrisopira.R.id.sheetArc;
                        com.jorden.karto.setrisopira.ui.common.SpanArcView spanArcView = (com.jorden.karto.setrisopira.ui.common.SpanArcView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.sheetArc);
                        if (spanArcView != null) {
                            i = com.jorden.karto.setrisopira.R.id.sheetHeader;
                            android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.sheetHeader);
                            if (linearLayout != null) {
                                i = com.jorden.karto.setrisopira.R.id.sheetLatin;
                                android.widget.TextView textView = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.sheetLatin);
                                if (textView != null) {
                                    i = com.jorden.karto.setrisopira.R.id.sheetName;
                                    android.widget.TextView textView2 = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.sheetName);
                                    if (textView2 != null) {
                                        i = com.jorden.karto.setrisopira.R.id.specFlesh;
                                        android.view.View viewU = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specFlesh);
                                        if (viewU != null) {
                                            l0.C0488m c0488mE = l0.C0488m.e(viewU);
                                            i = com.jorden.karto.setrisopira.R.id.specFruiting;
                                            android.view.View viewU2 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specFruiting);
                                            if (viewU2 != null) {
                                                l0.C0488m c0488mE2 = l0.C0488m.e(viewU2);
                                                i = com.jorden.karto.setrisopira.R.id.specHosts;
                                                android.view.View viewU3 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specHosts);
                                                if (viewU3 != null) {
                                                    l0.C0488m c0488mE3 = l0.C0488m.e(viewU3);
                                                    i = com.jorden.karto.setrisopira.R.id.specProfile;
                                                    android.view.View viewU4 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specProfile);
                                                    if (viewU4 != null) {
                                                        l0.C0488m c0488mE4 = l0.C0488m.e(viewU4);
                                                        i = com.jorden.karto.setrisopira.R.id.specSpan;
                                                        android.view.View viewU5 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specSpan);
                                                        if (viewU5 != null) {
                                                            l0.C0488m c0488mE5 = l0.C0488m.e(viewU5);
                                                            i = com.jorden.karto.setrisopira.R.id.specsSection;
                                                            if (((com.google.android.material.card.MaterialCardView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.specsSection)) != null) {
                                                                i = com.jorden.karto.setrisopira.R.id.visitDateLine;
                                                                android.widget.TextView textView3 = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.visitDateLine);
                                                                if (textView3 != null) {
                                                                    androidx.core.widget.NestedScrollView nestedScrollView = (androidx.core.widget.NestedScrollView) viewInflate;
                                                                    this.f6077e0 = new q3.C0733b(nestedScrollView, materialButton, materialButton2, seasonBandView, spanArcView, linearLayout, textView, textView2, c0488mE, c0488mE2, c0488mE3, c0488mE4, c0488mE5, textView3);
                                                                    f4.i.d(nestedScrollView, "getRoot(...)");
                                                                    return nestedScrollView;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void y() {
        this.f6077e0 = null;
        this.f10073N = true;
    }
}
