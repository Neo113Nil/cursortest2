package com.jorden.karto.setrisopira.ui.catalog;

/* loaded from: classes.dex */
public final class BracketRollFragment extends w1.AbstractComponentCallbacksC0987w {

    /* renamed from: e0, reason: collision with root package name */
    public q3.C0732a f6047e0;

    /* renamed from: f0, reason: collision with root package name */
    public final java.lang.Object f6048f0 = a.AbstractC0151a.C(Q3.f.i, new G4.t(this, new K3.g(0, this), 1));
    public K3.s g0;

    /* renamed from: h0, reason: collision with root package name */
    public boolean f6049h0;

    public static java.util.List M(q3.C0732a c0732a) {
        return b5.c.O(new Q3.h(c0732a.f8550c, "HOOF"), new Q3.h(c0732a.f8549b, "FAN"), new Q3.h(c0732a.f8552e, "TIERED"), new Q3.h(c0732a.f8548a, "CRUST"), new Q3.h(c0732a.f8551d, "ROSETTE"));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void F(android.view.View view) {
        f4.i.e(view, "view");
        q3.C0732a c0732a = this.f6047e0;
        if (c0732a == null) {
            return;
        }
        K3.s sVar = new K3.s(new K3.a(0, this));
        this.g0 = sVar;
        c0732a.f8556j.setAdapter(sVar);
        c0732a.f8557k.addTextChangedListener(new K3.c(this));
        for (Q3.h hVar : M(c0732a)) {
            java.lang.Object obj = hVar.i;
            f4.i.d(obj, "component1(...)");
            ((com.google.android.material.chip.Chip) obj).setOnClickListener(new I1.a(1, this, (java.lang.String) hVar.f3329j));
        }
        final int i = 0;
        c0732a.i.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: K3.b

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.catalog.BracketRollFragment f1687j;

            {
                this.f1687j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i) {
                    case 0:
                        this.f1687j.N().e(K3.i.f1695a);
                        break;
                    default:
                        this.f1687j.N().e(K3.i.f1695a);
                        break;
                }
            }
        });
        final int i6 = 1;
        c0732a.f8554g.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: K3.b

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.catalog.BracketRollFragment f1687j;

            {
                this.f1687j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i6) {
                    case 0:
                        this.f1687j.N().e(K3.i.f1695a);
                        break;
                    default:
                        this.f1687j.N().e(K3.i.f1695a);
                        break;
                }
            }
        });
        q4.AbstractC0784y.r(androidx.lifecycle.U.h(n()), null, 0, new K3.f(this, null), 3);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [Q3.e, java.lang.Object] */
    public final K3.p N() {
        return (K3.p) this.f6048f0.getValue();
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final android.view.View x(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup) {
        f4.i.e(layoutInflater, "inflater");
        android.view.View viewInflate = layoutInflater.inflate(com.jorden.karto.setrisopira.R.layout.fragment_catalog, viewGroup, false);
        int i = com.jorden.karto.setrisopira.R.id.chipCrust;
        com.google.android.material.chip.Chip chip = (com.google.android.material.chip.Chip) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.chipCrust);
        if (chip != null) {
            i = com.jorden.karto.setrisopira.R.id.chipFan;
            com.google.android.material.chip.Chip chip2 = (com.google.android.material.chip.Chip) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.chipFan);
            if (chip2 != null) {
                i = com.jorden.karto.setrisopira.R.id.chipHoof;
                com.google.android.material.chip.Chip chip3 = (com.google.android.material.chip.Chip) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.chipHoof);
                if (chip3 != null) {
                    i = com.jorden.karto.setrisopira.R.id.chipRosette;
                    com.google.android.material.chip.Chip chip4 = (com.google.android.material.chip.Chip) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.chipRosette);
                    if (chip4 != null) {
                        i = com.jorden.karto.setrisopira.R.id.chipTiered;
                        com.google.android.material.chip.Chip chip5 = (com.google.android.material.chip.Chip) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.chipTiered);
                        if (chip5 != null) {
                            i = com.jorden.karto.setrisopira.R.id.emptyArc;
                            com.jorden.karto.setrisopira.ui.common.SpanArcView spanArcView = (com.jorden.karto.setrisopira.ui.common.SpanArcView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.emptyArc);
                            if (spanArcView != null) {
                                i = com.jorden.karto.setrisopira.R.id.emptyBody;
                                if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.emptyBody)) != null) {
                                    i = com.jorden.karto.setrisopira.R.id.emptyClearButton;
                                    com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.emptyClearButton);
                                    if (materialButton != null) {
                                        i = com.jorden.karto.setrisopira.R.id.emptyState;
                                        android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.emptyState);
                                        if (linearLayout != null) {
                                            i = com.jorden.karto.setrisopira.R.id.emptyTitle;
                                            if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.emptyTitle)) != null) {
                                                i = com.jorden.karto.setrisopira.R.id.profileChips;
                                                if (((com.google.android.material.chip.ChipGroup) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.profileChips)) != null) {
                                                    i = com.jorden.karto.setrisopira.R.id.profileScroll;
                                                    if (((android.widget.HorizontalScrollView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.profileScroll)) != null) {
                                                        i = com.jorden.karto.setrisopira.R.id.profileTitle;
                                                        if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.profileTitle)) != null) {
                                                            i = com.jorden.karto.setrisopira.R.id.resetButton;
                                                            com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.resetButton);
                                                            if (materialButton2 != null) {
                                                                i = com.jorden.karto.setrisopira.R.id.rollList;
                                                                androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.rollList);
                                                                if (recyclerView != null) {
                                                                    i = com.jorden.karto.setrisopira.R.id.searchField;
                                                                    com.google.android.material.textfield.TextInputEditText textInputEditText = (com.google.android.material.textfield.TextInputEditText) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.searchField);
                                                                    if (textInputEditText != null) {
                                                                        i = com.jorden.karto.setrisopira.R.id.searchLayout;
                                                                        if (((com.google.android.material.textfield.TextInputLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.searchLayout)) != null) {
                                                                            android.widget.LinearLayout linearLayout2 = (android.widget.LinearLayout) viewInflate;
                                                                            this.f6047e0 = new q3.C0732a(linearLayout2, chip, chip2, chip3, chip4, chip5, spanArcView, materialButton, linearLayout, materialButton2, recyclerView, textInputEditText);
                                                                            f4.i.d(linearLayout2, "getRoot(...)");
                                                                            return linearLayout2;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void y() {
        androidx.recyclerview.widget.RecyclerView recyclerView;
        q3.C0732a c0732a = this.f6047e0;
        if (c0732a != null && (recyclerView = c0732a.f8556j) != null) {
            recyclerView.setAdapter(null);
        }
        this.f6047e0 = null;
        this.f10073N = true;
    }
}
