package com.jorden.karto.setrisopira.ui.common;

/* loaded from: classes.dex */
public final class TallyRingView extends android.view.View {
    public int i;

    /* renamed from: j, reason: collision with root package name */
    public int f6071j;

    /* renamed from: k, reason: collision with root package name */
    public java.lang.String f6072k;

    /* renamed from: l, reason: collision with root package name */
    public final android.graphics.Paint f6073l;

    /* renamed from: m, reason: collision with root package name */
    public final android.graphics.Paint f6074m;

    /* renamed from: n, reason: collision with root package name */
    public final android.graphics.Paint f6075n;

    /* renamed from: o, reason: collision with root package name */
    public final android.graphics.RectF f6076o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TallyRingView(android.content.Context context, android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        f4.i.e(context, "context");
        this.i = 12;
        this.f6072k = "";
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.STROKE;
        paint.setStyle(style);
        android.graphics.Paint.Cap cap = android.graphics.Paint.Cap.BUTT;
        paint.setStrokeCap(cap);
        paint.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_primary));
        this.f6073l = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_card_stroke));
        this.f6074m = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_primary));
        paint3.setTextAlign(android.graphics.Paint.Align.CENTER);
        this.f6075n = paint3;
        this.f6076o = new android.graphics.RectF();
    }

    public final java.lang.String getCentreLabel() {
        return this.f6072k;
    }

    public final int getFilledCount() {
        return this.f6071j;
    }

    public final int getSegmentCount() {
        return this.i;
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        f4.i.e(canvas, "canvas");
        super.onDraw(canvas);
        float fMin = java.lang.Math.min(getWidth(), getHeight());
        if (fMin <= 0.0f) {
            return;
        }
        float f6 = 0.14f * fMin;
        android.graphics.Paint paint = this.f6073l;
        paint.setStrokeWidth(f6);
        android.graphics.Paint paint2 = this.f6074m;
        paint2.setStrokeWidth(0.06f * fMin);
        android.graphics.Paint paint3 = this.f6075n;
        paint3.setTextSize(0.2f * fMin);
        float f7 = (0.04f * fMin) + (f6 / 2.0f);
        float width = ((getWidth() - fMin) / 2.0f) + f7;
        float height = ((getHeight() - fMin) / 2.0f) + f7;
        android.graphics.RectF rectF = this.f6076o;
        float f8 = f7 * 2.0f;
        rectF.set(width, height, (width + fMin) - f8, (fMin + height) - f8);
        int i = this.i;
        float f9 = 360.0f / i;
        float f10 = f9 * 0.18f;
        int i6 = 0;
        while (i6 < i) {
            canvas.drawArc(rectF, (f10 / 2.0f) + ((i6 * f9) - 90.0f), f9 - f10, false, i6 < this.f6071j ? paint : paint2);
            i6++;
        }
        if (this.f6072k.length() > 0) {
            canvas.drawText(this.f6072k, rectF.centerX(), rectF.centerY() - ((paint3.ascent() + paint3.descent()) / 2.0f), paint3);
        }
    }

    public final void setCentreLabel(java.lang.String str) {
        f4.i.e(str, "value");
        this.f6072k = str;
        invalidate();
    }

    public final void setFilledCount(int i) {
        if (i < 0) {
            i = 0;
        }
        this.f6071j = i;
        invalidate();
    }

    public final void setSegmentCount(int i) {
        if (i < 1) {
            i = 1;
        }
        this.i = i;
        invalidate();
    }
}
