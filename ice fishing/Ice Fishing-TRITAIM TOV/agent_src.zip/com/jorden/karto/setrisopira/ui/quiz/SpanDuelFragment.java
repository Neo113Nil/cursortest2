package com.jorden.karto.setrisopira.ui.quiz;

/* loaded from: classes.dex */
public final class SpanDuelFragment extends w1.AbstractComponentCallbacksC0987w {

    /* renamed from: e0, reason: collision with root package name */
    public q3.C0735d f6085e0;

    /* renamed from: f0, reason: collision with root package name */
    public final java.lang.Object f6086f0 = a.AbstractC0151a.C(Q3.f.i, new G4.t(this, new K3.g(4, this), 5));
    public final P3.c g0 = new P3.c();

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void F(android.view.View view) {
        f4.i.e(view, "view");
        q3.C0735d c0735d = this.f6085e0;
        if (c0735d == null) {
            return;
        }
        c0735d.f8586h.setAdapter(this.g0);
        final int i = 0;
        c0735d.f8580b.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: P3.d

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.quiz.SpanDuelFragment f3174j;

            {
                this.f3174j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i) {
                    case 0:
                        this.f3174j.N().f(P3.h.f3180a);
                        break;
                    case 1:
                        this.f3174j.N().f(P3.g.f3179a);
                        break;
                    case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                        this.f3174j.N().f(P3.i.f3181a);
                        break;
                    case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                        this.f3174j.N().f(P3.j.f3182a);
                        break;
                    default:
                        this.f3174j.N().f(P3.k.f3183a);
                        break;
                }
            }
        });
        final int i6 = 1;
        c0735d.f8579a.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: P3.d

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.quiz.SpanDuelFragment f3174j;

            {
                this.f3174j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i6) {
                    case 0:
                        this.f3174j.N().f(P3.h.f3180a);
                        break;
                    case 1:
                        this.f3174j.N().f(P3.g.f3179a);
                        break;
                    case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                        this.f3174j.N().f(P3.i.f3181a);
                        break;
                    case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                        this.f3174j.N().f(P3.j.f3182a);
                        break;
                    default:
                        this.f3174j.N().f(P3.k.f3183a);
                        break;
                }
            }
        });
        final int i7 = 2;
        c0735d.f8585g.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: P3.d

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.quiz.SpanDuelFragment f3174j;

            {
                this.f3174j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i7) {
                    case 0:
                        this.f3174j.N().f(P3.h.f3180a);
                        break;
                    case 1:
                        this.f3174j.N().f(P3.g.f3179a);
                        break;
                    case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                        this.f3174j.N().f(P3.i.f3181a);
                        break;
                    case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                        this.f3174j.N().f(P3.j.f3182a);
                        break;
                    default:
                        this.f3174j.N().f(P3.k.f3183a);
                        break;
                }
            }
        });
        final int i8 = 3;
        c0735d.f8584f.f8596f.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: P3.d

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.quiz.SpanDuelFragment f3174j;

            {
                this.f3174j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i8) {
                    case 0:
                        this.f3174j.N().f(P3.h.f3180a);
                        break;
                    case 1:
                        this.f3174j.N().f(P3.g.f3179a);
                        break;
                    case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                        this.f3174j.N().f(P3.i.f3181a);
                        break;
                    case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                        this.f3174j.N().f(P3.j.f3182a);
                        break;
                    default:
                        this.f3174j.N().f(P3.k.f3183a);
                        break;
                }
            }
        });
        final int i9 = 4;
        c0735d.f8589l.f8596f.setOnClickListener(new android.view.View.OnClickListener(this) { // from class: P3.d

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ com.jorden.karto.setrisopira.ui.quiz.SpanDuelFragment f3174j;

            {
                this.f3174j = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(android.view.View view2) {
                switch (i9) {
                    case 0:
                        this.f3174j.N().f(P3.h.f3180a);
                        break;
                    case 1:
                        this.f3174j.N().f(P3.g.f3179a);
                        break;
                    case o1.C0707g.FLOAT_FIELD_NUMBER /* 2 */:
                        this.f3174j.N().f(P3.i.f3181a);
                        break;
                    case o1.C0707g.INTEGER_FIELD_NUMBER /* 3 */:
                        this.f3174j.N().f(P3.j.f3182a);
                        break;
                    default:
                        this.f3174j.N().f(P3.k.f3183a);
                        break;
                }
            }
        });
        q4.AbstractC0784y.r(androidx.lifecycle.U.h(n()), null, 0, new P3.f(this, null), 3);
    }

    public final void M(q3.C0736e c0736e, s3.C0834a c0834a, P3.n nVar) {
        int color;
        android.content.Context context = c0736e.f8591a.getContext();
        c0736e.f8594d.setText(c0834a.f9022b);
        c0736e.f8593c.setText(c0834a.f9028h);
        float f6 = nVar.f3192e ? c0834a.f9029j : 0.5f;
        com.jorden.karto.setrisopira.ui.common.SpanArcView spanArcView = c0736e.f8592b;
        spanArcView.setSweepFraction(f6);
        java.lang.String str = c0834a.f9021a;
        boolean z5 = nVar.f3192e;
        if (z5) {
            s3.C0835b c0835b = nVar.f3190c;
            s3.C0834a c0834a2 = c0835b.f9030a;
            s3.C0834a c0834a3 = c0835b.f9031b;
            color = str.equals(c0834a2.f9024d >= c0834a3.f9024d ? c0834a2.f9021a : c0834a3.f9021a) ? context.getColor(com.jorden.karto.setrisopira.R.color.tint_1) : context.getColor(com.jorden.karto.setrisopira.R.color.tint_4);
        } else {
            color = context.getColor(L3.a.f2071a[java.lang.Math.abs(str.hashCode()) % 6]);
        }
        android.content.res.ColorStateList colorStateListValueOf = android.content.res.ColorStateList.valueOf(color);
        android.widget.LinearLayout linearLayout = c0736e.f8596f;
        linearLayout.setBackgroundTintList(colorStateListValueOf);
        spanArcView.setGroundColor(color);
        android.widget.TextView textView = c0736e.f8595e;
        if (z5) {
            textView.setVisibility(0);
            textView.setText(m(com.jorden.karto.setrisopira.R.string.duel_span_reveal, java.lang.Integer.valueOf(c0834a.f9024d)));
        } else {
            textView.setVisibility(4);
        }
        linearLayout.setClickable(!z5);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [Q3.e, java.lang.Object] */
    public final P3.s N() {
        return (P3.s) this.f6086f0.getValue();
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final android.view.View x(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup) {
        f4.i.e(layoutInflater, "inflater");
        android.view.View viewInflate = layoutInflater.inflate(com.jorden.karto.setrisopira.R.layout.fragment_quiz, viewGroup, false);
        int i = com.jorden.karto.setrisopira.R.id.againButton;
        com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.againButton);
        if (materialButton != null) {
            i = com.jorden.karto.setrisopira.R.id.beginButton;
            com.google.android.material.button.MaterialButton materialButton2 = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.beginButton);
            if (materialButton2 != null) {
                i = com.jorden.karto.setrisopira.R.id.duelPrompt;
                if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.duelPrompt)) != null) {
                    i = com.jorden.karto.setrisopira.R.id.finishedBest;
                    android.widget.TextView textView = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.finishedBest);
                    if (textView != null) {
                        i = com.jorden.karto.setrisopira.R.id.finishedState;
                        android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.finishedState);
                        if (linearLayout != null) {
                            i = com.jorden.karto.setrisopira.R.id.finishedTitle;
                            android.widget.TextView textView2 = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.finishedTitle);
                            if (textView2 != null) {
                                i = com.jorden.karto.setrisopira.R.id.leftPane;
                                android.view.View viewU = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.leftPane);
                                if (viewU != null) {
                                    q3.C0736e c0736eA = q3.C0736e.a(viewU);
                                    i = com.jorden.karto.setrisopira.R.id.nextButton;
                                    com.google.android.material.button.MaterialButton materialButton3 = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.nextButton);
                                    if (materialButton3 != null) {
                                        i = com.jorden.karto.setrisopira.R.id.outcomeList;
                                        androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.outcomeList);
                                        if (recyclerView != null) {
                                            i = com.jorden.karto.setrisopira.R.id.playState;
                                            android.widget.LinearLayout linearLayout2 = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.playState);
                                            if (linearLayout2 != null) {
                                                i = com.jorden.karto.setrisopira.R.id.readyBest;
                                                android.widget.TextView textView3 = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.readyBest);
                                                if (textView3 != null) {
                                                    i = com.jorden.karto.setrisopira.R.id.readyRules;
                                                    if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.readyRules)) != null) {
                                                        i = com.jorden.karto.setrisopira.R.id.readyState;
                                                        android.widget.LinearLayout linearLayout3 = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.readyState);
                                                        if (linearLayout3 != null) {
                                                            i = com.jorden.karto.setrisopira.R.id.readyTitle;
                                                            if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.readyTitle)) != null) {
                                                                i = com.jorden.karto.setrisopira.R.id.rightPane;
                                                                android.view.View viewU2 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.rightPane);
                                                                if (viewU2 != null) {
                                                                    q3.C0736e c0736eA2 = q3.C0736e.a(viewU2);
                                                                    i = com.jorden.karto.setrisopira.R.id.roundLabel;
                                                                    android.widget.TextView textView4 = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.roundLabel);
                                                                    if (textView4 != null) {
                                                                        android.widget.FrameLayout frameLayout = (android.widget.FrameLayout) viewInflate;
                                                                        this.f6085e0 = new q3.C0735d(frameLayout, materialButton, materialButton2, textView, linearLayout, textView2, c0736eA, materialButton3, recyclerView, linearLayout2, textView3, linearLayout3, c0736eA2, textView4);
                                                                        f4.i.d(frameLayout, "getRoot(...)");
                                                                        return frameLayout;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void y() {
        androidx.recyclerview.widget.RecyclerView recyclerView;
        q3.C0735d c0735d = this.f6085e0;
        if (c0735d != null && (recyclerView = c0735d.f8586h) != null) {
            recyclerView.setAdapter(null);
        }
        this.f6085e0 = null;
        this.f10073N = true;
    }
}
