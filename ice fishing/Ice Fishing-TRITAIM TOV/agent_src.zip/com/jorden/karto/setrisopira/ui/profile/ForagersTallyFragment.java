package com.jorden.karto.setrisopira.ui.profile;

/* loaded from: classes.dex */
public final class ForagersTallyFragment extends w1.AbstractComponentCallbacksC0987w {

    /* renamed from: e0, reason: collision with root package name */
    public q3.C0734c f6083e0;

    /* renamed from: f0, reason: collision with root package name */
    public final java.lang.Object f6084f0 = a.AbstractC0151a.C(Q3.f.i, new G4.t(this, new K3.g(3, this), 4));
    public final O3.m g0 = new O3.m(O3.m.f2789e);

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void F(android.view.View view) {
        f4.i.e(view, "view");
        q3.C0734c c0734c = this.f6083e0;
        if (c0734c == null) {
            return;
        }
        c0734c.i.setAdapter(this.g0);
        c0734c.f8571a.setOnClickListener(new M3.a(2, this));
        q4.AbstractC0784y.r(androidx.lifecycle.U.h(n()), null, 0, new O3.c(this, null), 3);
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final android.view.View x(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup) {
        f4.i.e(layoutInflater, "inflater");
        android.view.View viewInflate = layoutInflater.inflate(com.jorden.karto.setrisopira.R.layout.fragment_profile, viewGroup, false);
        int i = com.jorden.karto.setrisopira.R.id.clearTallyButton;
        com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.clearTallyButton);
        if (materialButton != null) {
            i = com.jorden.karto.setrisopira.R.id.ringTitle;
            if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.ringTitle)) != null) {
                i = com.jorden.karto.setrisopira.R.id.statBest;
                android.view.View viewU = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statBest);
                if (viewU != null) {
                    l0.C0488m c0488mE = l0.C0488m.e(viewU);
                    i = com.jorden.karto.setrisopira.R.id.statDuels;
                    android.view.View viewU2 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statDuels);
                    if (viewU2 != null) {
                        l0.C0488m c0488mE2 = l0.C0488m.e(viewU2);
                        i = com.jorden.karto.setrisopira.R.id.statMet;
                        android.view.View viewU3 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statMet);
                        if (viewU3 != null) {
                            l0.C0488m c0488mE3 = l0.C0488m.e(viewU3);
                            i = com.jorden.karto.setrisopira.R.id.statPoints;
                            android.view.View viewU4 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statPoints);
                            if (viewU4 != null) {
                                l0.C0488m c0488mE4 = l0.C0488m.e(viewU4);
                                i = com.jorden.karto.setrisopira.R.id.statWidest;
                                android.view.View viewU5 = h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statWidest);
                                if (viewU5 != null) {
                                    l0.C0488m c0488mE5 = l0.C0488m.e(viewU5);
                                    i = com.jorden.karto.setrisopira.R.id.statsGrid;
                                    if (((com.google.android.material.card.MaterialCardView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.statsGrid)) != null) {
                                        i = com.jorden.karto.setrisopira.R.id.tallyRing;
                                        com.jorden.karto.setrisopira.ui.common.TallyRingView tallyRingView = (com.jorden.karto.setrisopira.ui.common.TallyRingView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.tallyRing);
                                        if (tallyRingView != null) {
                                            i = com.jorden.karto.setrisopira.R.id.timelineEmpty;
                                            android.widget.LinearLayout linearLayout = (android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.timelineEmpty);
                                            if (linearLayout != null) {
                                                i = com.jorden.karto.setrisopira.R.id.timelineEmptyBody;
                                                if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.timelineEmptyBody)) != null) {
                                                    i = com.jorden.karto.setrisopira.R.id.timelineEmptyTitle;
                                                    if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.timelineEmptyTitle)) != null) {
                                                        i = com.jorden.karto.setrisopira.R.id.timelineTitle;
                                                        if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.timelineTitle)) != null) {
                                                            i = com.jorden.karto.setrisopira.R.id.visitTimeline;
                                                            androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.visitTimeline);
                                                            if (recyclerView != null) {
                                                                androidx.core.widget.NestedScrollView nestedScrollView = (androidx.core.widget.NestedScrollView) viewInflate;
                                                                this.f6083e0 = new q3.C0734c(nestedScrollView, materialButton, c0488mE, c0488mE2, c0488mE3, c0488mE4, c0488mE5, tallyRingView, linearLayout, recyclerView);
                                                                f4.i.d(nestedScrollView, "getRoot(...)");
                                                                return nestedScrollView;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void y() {
        androidx.recyclerview.widget.RecyclerView recyclerView;
        q3.C0734c c0734c = this.f6083e0;
        if (c0734c != null && (recyclerView = c0734c.i) != null) {
            recyclerView.setAdapter(null);
        }
        this.f6083e0 = null;
        this.f10073N = true;
    }
}
