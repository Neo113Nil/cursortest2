package com.jorden.karto.setrisopira.ui.common;

/* loaded from: classes.dex */
public final class SeasonBandView extends android.view.View {
    public java.util.List i;

    /* renamed from: j, reason: collision with root package name */
    public java.util.List f6050j;

    /* renamed from: k, reason: collision with root package name */
    public final android.graphics.Paint f6051k;

    /* renamed from: l, reason: collision with root package name */
    public final android.graphics.Paint f6052l;

    /* renamed from: m, reason: collision with root package name */
    public final android.graphics.Paint f6053m;

    /* renamed from: n, reason: collision with root package name */
    public final android.graphics.Paint f6054n;

    /* renamed from: o, reason: collision with root package name */
    public final android.graphics.RectF f6055o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SeasonBandView(android.content.Context context, android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        f4.i.e(context, "context");
        R3.v vVar = R3.v.i;
        this.i = vVar;
        this.f6050j = vVar;
        android.graphics.Paint paint = new android.graphics.Paint(1);
        paint.setStyle(android.graphics.Paint.Style.FILL);
        paint.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_secondary));
        this.f6051k = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(android.graphics.Paint.Style.STROKE);
        paint2.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_card_stroke));
        this.f6052l = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_on_primary));
        android.graphics.Paint.Align align = android.graphics.Paint.Align.CENTER;
        paint3.setTextAlign(align);
        this.f6053m = paint3;
        android.graphics.Paint paint4 = new android.graphics.Paint(1);
        paint4.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_muted));
        paint4.setTextAlign(align);
        this.f6054n = paint4;
        this.f6055o = new android.graphics.RectF();
    }

    public final java.util.List<java.lang.Integer> getActiveMonths() {
        return this.i;
    }

    public final java.util.List<java.lang.String> getMonthInitials() {
        return this.f6050j;
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        f4.i.e(canvas, "canvas");
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        float f6 = 0.006f * width;
        float f7 = (width - (11.0f * f6)) / 12.0f;
        float f8 = 0.72f * height;
        float f9 = 0.22f * f7;
        android.graphics.Paint paint = this.f6052l;
        paint.setStrokeWidth(height * 0.018f);
        android.graphics.Paint paint2 = this.f6053m;
        float f10 = 0.44f * f8;
        paint2.setTextSize(f10);
        android.graphics.Paint paint3 = this.f6054n;
        paint3.setTextSize(f10);
        for (int i = 1; i < 13; i++) {
            int i6 = i - 1;
            float f11 = (f7 + f6) * i6;
            android.graphics.RectF rectF = this.f6055o;
            rectF.set(f11, 0.0f, f11 + f7, f8);
            boolean zContains = this.i.contains(java.lang.Integer.valueOf(i));
            if (zContains) {
                canvas.drawRoundRect(rectF, f9, f9, this.f6051k);
            } else {
                canvas.drawRoundRect(rectF, f9, f9, paint);
            }
            java.lang.String str = (java.lang.String) R3.n.k0(i6, this.f6050j);
            if (str == null) {
                str = "";
            }
            if (str.length() > 0) {
                android.graphics.Paint paint4 = zContains ? paint2 : paint3;
                canvas.drawText(str, rectF.centerX(), (f8 / 2.0f) - ((paint4.ascent() + paint4.descent()) / 2.0f), paint4);
            }
        }
    }

    public final void setActiveMonths(java.util.List<java.lang.Integer> list) {
        f4.i.e(list, "value");
        this.i = list;
        invalidate();
    }

    public final void setMonthInitials(java.util.List<java.lang.String> list) {
        f4.i.e(list, "value");
        this.f6050j = list;
        invalidate();
    }
}
