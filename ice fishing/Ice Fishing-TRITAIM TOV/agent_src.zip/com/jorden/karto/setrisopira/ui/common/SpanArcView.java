package com.jorden.karto.setrisopira.ui.common;

/* loaded from: classes.dex */
public final class SpanArcView extends android.view.View {
    public float i;

    /* renamed from: j, reason: collision with root package name */
    public int f6056j;

    /* renamed from: k, reason: collision with root package name */
    public float f6057k;

    /* renamed from: l, reason: collision with root package name */
    public final android.graphics.Paint f6058l;

    /* renamed from: m, reason: collision with root package name */
    public final android.graphics.Paint f6059m;

    /* renamed from: n, reason: collision with root package name */
    public final android.graphics.Paint f6060n;

    /* renamed from: o, reason: collision with root package name */
    public final android.graphics.Paint f6061o;

    /* renamed from: p, reason: collision with root package name */
    public final android.graphics.RectF f6062p;

    /* renamed from: q, reason: collision with root package name */
    public final android.graphics.RectF f6063q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SpanArcView(android.content.Context context, android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        f4.i.e(context, "context");
        this.f6056j = context.getColor(com.jorden.karto.setrisopira.R.color.tint_0);
        this.f6057k = getResources().getDimension(com.jorden.karto.setrisopira.R.dimen.radius_tile);
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.FILL;
        paint.setStyle(style);
        this.f6058l = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        android.graphics.Paint.Style style2 = android.graphics.Paint.Style.STROKE;
        paint2.setStyle(style2);
        android.graphics.Paint.Cap cap = android.graphics.Paint.Cap.ROUND;
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.mark_ink_soft));
        this.f6059m = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setStyle(style2);
        paint3.setStrokeCap(cap);
        paint3.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.mark_ink));
        this.f6060n = paint3;
        android.graphics.Paint paint4 = new android.graphics.Paint(1);
        paint4.setStyle(style);
        paint4.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.mark_ink));
        this.f6061o = paint4;
        this.f6062p = new android.graphics.RectF();
        this.f6063q = new android.graphics.RectF();
    }

    public final float getCornerRadiusPx() {
        return this.f6057k;
    }

    public final int getGroundColor() {
        return this.f6056j;
    }

    public final float getSweepFraction() {
        return this.i;
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        f4.i.e(canvas, "canvas");
        super.onDraw(canvas);
        float fMin = java.lang.Math.min(getWidth(), getHeight());
        if (fMin <= 0.0f) {
            return;
        }
        android.graphics.Paint paint = this.f6058l;
        paint.setColor(this.f6056j);
        android.graphics.RectF rectF = this.f6063q;
        rectF.set(0.0f, 0.0f, getWidth(), getHeight());
        float f6 = this.f6057k;
        canvas.drawRoundRect(rectF, f6, f6, paint);
        float f7 = 0.13f * fMin;
        android.graphics.Paint paint2 = this.f6059m;
        paint2.setStrokeWidth(f7);
        android.graphics.Paint paint3 = this.f6060n;
        paint3.setStrokeWidth(f7);
        float f8 = f7 * 1.6f;
        float width = ((getWidth() - fMin) / 2.0f) + f8;
        float height = ((getHeight() - fMin) / 2.0f) + f8;
        android.graphics.RectF rectF2 = this.f6062p;
        float f9 = f8 * 2.0f;
        rectF2.set(width, height, (width + fMin) - f9, (height + fMin) - f9);
        canvas.drawArc(rectF2, -90.0f, 360.0f, false, paint2);
        canvas.drawArc(rectF2, -90.0f, this.i * 360.0f, false, paint3);
        canvas.drawCircle(rectF2.centerX(), rectF2.centerY(), fMin * 0.075f, this.f6061o);
    }

    public final void setCornerRadiusPx(float f6) {
        this.f6057k = f6;
        invalidate();
    }

    public final void setGroundColor(int i) {
        this.f6056j = i;
        invalidate();
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x0005 A[PHI: r0
      0x0005: PHI (r0v2 float) = (r0v0 float), (r0v1 float) binds: [B:3:0x0003, B:6:0x000b] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void setSweepFraction(float f6) {
        float f7 = 0.0f;
        if (f6 < 0.0f) {
            f6 = f7;
        } else {
            f7 = 1.0f;
            if (f6 > 1.0f) {
            }
        }
        this.i = f6;
        invalidate();
    }
}
