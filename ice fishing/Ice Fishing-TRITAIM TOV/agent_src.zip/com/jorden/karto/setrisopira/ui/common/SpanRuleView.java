package com.jorden.karto.setrisopira.ui.common;

/* loaded from: classes.dex */
public final class SpanRuleView extends android.view.View {
    public java.util.List i;

    /* renamed from: j, reason: collision with root package name */
    public java.lang.String f6064j;

    /* renamed from: k, reason: collision with root package name */
    public java.lang.String f6065k;

    /* renamed from: l, reason: collision with root package name */
    public final android.graphics.Paint f6066l;

    /* renamed from: m, reason: collision with root package name */
    public final android.graphics.Paint f6067m;

    /* renamed from: n, reason: collision with root package name */
    public final android.graphics.Paint f6068n;

    /* renamed from: o, reason: collision with root package name */
    public final android.graphics.Paint f6069o;

    /* renamed from: p, reason: collision with root package name */
    public final android.graphics.Path f6070p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SpanRuleView(android.content.Context context, android.util.AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        f4.i.e(context, "context");
        this.i = R3.v.i;
        this.f6064j = "";
        this.f6065k = "";
        android.graphics.Paint paint = new android.graphics.Paint(1);
        android.graphics.Paint.Style style = android.graphics.Paint.Style.STROKE;
        paint.setStyle(style);
        android.graphics.Paint.Cap cap = android.graphics.Paint.Cap.ROUND;
        paint.setStrokeCap(cap);
        paint.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.mark_ink));
        this.f6066l = paint;
        android.graphics.Paint paint2 = new android.graphics.Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_secondary));
        this.f6067m = paint2;
        android.graphics.Paint paint3 = new android.graphics.Paint(1);
        paint3.setStyle(style);
        paint3.setStrokeCap(cap);
        paint3.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.mark_ink_soft));
        this.f6068n = paint3;
        android.graphics.Paint paint4 = new android.graphics.Paint(1);
        paint4.setColor(context.getColor(com.jorden.karto.setrisopira.R.color.brand_muted));
        this.f6069o = paint4;
        this.f6070p = new android.graphics.Path();
    }

    public final java.lang.String getNarrowestLabel() {
        return this.f6064j;
    }

    public final java.util.List<java.lang.Integer> getSpans() {
        return this.i;
    }

    public final java.lang.String getWidestLabel() {
        return this.f6065k;
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        int iIntValue;
        android.graphics.Paint paint;
        f4.i.e(canvas, "canvas");
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        float f6 = width * 0.06f;
        float f7 = height * 0.66f;
        float f8 = width - f6;
        java.lang.Integer num = (java.lang.Integer) R3.n.q0(this.i);
        if (num == null || (iIntValue = num.intValue()) <= 0) {
            return;
        }
        android.graphics.Paint paint2 = this.f6066l;
        paint2.setStrokeWidth(0.022f * height);
        android.graphics.Paint paint3 = this.f6068n;
        paint3.setStrokeWidth(0.012f * height);
        android.graphics.Paint paint4 = this.f6067m;
        float f9 = height * 0.05f;
        paint4.setStrokeWidth(f9);
        android.graphics.Paint paint5 = this.f6069o;
        paint5.setTextSize(0.11f * height);
        canvas.drawLine(f6, f7, f8, f7, paint2);
        android.graphics.Path path = this.f6070p;
        path.reset();
        float f10 = 0.08f * height;
        path.moveTo(f6, f7 - f10);
        path.lineTo(f6, f10 + f7);
        float f11 = 0.12f * height;
        path.moveTo(f8, f7 - f11);
        path.lineTo(f8, f11 + f7);
        canvas.drawPath(path, paint2);
        for (int i = 1; i < 4; i++) {
            float f12 = ((i / 4.0f) * (f8 - f6)) + f6;
            canvas.drawLine(f12, f7 - f9, f12, f7 + f9, paint3);
        }
        int i6 = 0;
        for (java.lang.Object obj : R3.n.u0(this.i)) {
            int i7 = i6 + 1;
            if (i6 < 0) {
                b5.c.Y();
                throw null;
            }
            float fIntValue = ((((java.lang.Number) obj).intValue() / iIntValue) * (f8 - f6)) + f6;
            canvas.drawLine(fIntValue, f7, fIntValue, f7 - ((i6 % 2 == 0 ? 0.3f : 0.2f) * height), paint4);
            i6 = i7;
        }
        if (this.f6064j.length() > 0) {
            paint = paint5;
            canvas.drawText(this.f6064j, f6, (height * 0.26f) + f7, paint);
        } else {
            paint = paint5;
        }
        if (this.f6065k.length() > 0) {
            canvas.drawText(this.f6065k, f8 - paint.measureText(this.f6065k), (height * 0.26f) + f7, paint);
        }
    }

    public final void setNarrowestLabel(java.lang.String str) {
        f4.i.e(str, "value");
        this.f6064j = str;
        invalidate();
    }

    public final void setSpans(java.util.List<java.lang.Integer> list) {
        f4.i.e(list, "value");
        this.i = list;
        invalidate();
    }

    public final void setWidestLabel(java.lang.String str) {
        f4.i.e(str, "value");
        this.f6065k = str;
        invalidate();
    }
}
