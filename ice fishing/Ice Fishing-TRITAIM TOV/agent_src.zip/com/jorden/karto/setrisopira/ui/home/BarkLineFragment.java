package com.jorden.karto.setrisopira.ui.home;

/* loaded from: classes.dex */
public final class BarkLineFragment extends w1.AbstractComponentCallbacksC0987w {

    /* renamed from: e0, reason: collision with root package name */
    public B1.f f6081e0;

    /* renamed from: f0, reason: collision with root package name */
    public final java.lang.Object f6082f0 = a.AbstractC0151a.C(Q3.f.i, new G4.t(this, new K3.g(2, this), 3));
    public N3.i g0;

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void F(android.view.View view) {
        f4.i.e(view, "view");
        B1.f fVar = this.f6081e0;
        if (fVar == null) {
            return;
        }
        N3.i iVar = new N3.i(new K3.a(3, this));
        this.g0 = iVar;
        ((androidx.recyclerview.widget.RecyclerView) fVar.f77j).setAdapter(iVar);
        ((com.google.android.material.button.MaterialButton) fVar.f79l).setOnClickListener(new M3.a(1, this));
        q4.AbstractC0784y.r(androidx.lifecycle.U.h(n()), null, 0, new N3.b(this, null), 3);
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final android.view.View x(android.view.LayoutInflater layoutInflater, android.view.ViewGroup viewGroup) {
        f4.i.e(layoutInflater, "inflater");
        android.view.View viewInflate = layoutInflater.inflate(com.jorden.karto.setrisopira.R.layout.fragment_home, viewGroup, false);
        int i = com.jorden.karto.setrisopira.R.id.broadestRail;
        androidx.recyclerview.widget.RecyclerView recyclerView = (androidx.recyclerview.widget.RecyclerView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.broadestRail);
        if (recyclerView != null) {
            i = com.jorden.karto.setrisopira.R.id.homeHeader;
            if (((android.widget.LinearLayout) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeHeader)) != null) {
                i = com.jorden.karto.setrisopira.R.id.homeHeaderLine;
                if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeHeaderLine)) != null) {
                    i = com.jorden.karto.setrisopira.R.id.homeRailTitle;
                    if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeRailTitle)) != null) {
                        i = com.jorden.karto.setrisopira.R.id.homeRuleCaption;
                        if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeRuleCaption)) != null) {
                            i = com.jorden.karto.setrisopira.R.id.homeRuleTitle;
                            if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeRuleTitle)) != null) {
                                androidx.core.widget.NestedScrollView nestedScrollView = (androidx.core.widget.NestedScrollView) viewInflate;
                                int i6 = com.jorden.karto.setrisopira.R.id.homeTitle;
                                if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeTitle)) != null) {
                                    i6 = com.jorden.karto.setrisopira.R.id.homeWidestLabel;
                                    if (((android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeWidestLabel)) != null) {
                                        i6 = com.jorden.karto.setrisopira.R.id.homeWidestValue;
                                        android.widget.TextView textView = (android.widget.TextView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.homeWidestValue);
                                        if (textView != null) {
                                            i6 = com.jorden.karto.setrisopira.R.id.openRegisterButton;
                                            com.google.android.material.button.MaterialButton materialButton = (com.google.android.material.button.MaterialButton) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.openRegisterButton);
                                            if (materialButton != null) {
                                                i6 = com.jorden.karto.setrisopira.R.id.spanRule;
                                                com.jorden.karto.setrisopira.ui.common.SpanRuleView spanRuleView = (com.jorden.karto.setrisopira.ui.common.SpanRuleView) h4.AbstractC0412a.u(viewInflate, com.jorden.karto.setrisopira.R.id.spanRule);
                                                if (spanRuleView != null) {
                                                    this.f6081e0 = new B1.f(nestedScrollView, recyclerView, textView, materialButton, spanRuleView);
                                                    f4.i.d(nestedScrollView, "getRoot(...)");
                                                    return nestedScrollView;
                                                }
                                            }
                                        }
                                    }
                                }
                                i = i6;
                            }
                        }
                    }
                }
            }
        }
        throw new java.lang.NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override // w1.AbstractComponentCallbacksC0987w
    public final void y() {
        androidx.recyclerview.widget.RecyclerView recyclerView;
        B1.f fVar = this.f6081e0;
        if (fVar != null && (recyclerView = (androidx.recyclerview.widget.RecyclerView) fVar.f77j) != null) {
            recyclerView.setAdapter(null);
        }
        this.f6081e0 = null;
        this.f10073N = true;
    }
}
