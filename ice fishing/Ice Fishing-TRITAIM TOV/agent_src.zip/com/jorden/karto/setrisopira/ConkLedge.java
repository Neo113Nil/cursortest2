package com.jorden.karto.setrisopira;

/* loaded from: classes.dex */
public class ConkLedge extends android.app.Application {
    public static final /* synthetic */ int i = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        K3.a aVar = new K3.a(7, this);
        synchronized (Y4.a.f4195a) {
            X4.a aVar2 = new X4.a();
            if (Y4.a.f4196b != null) {
                throw new a5.b("A Koin Application has already been started");
            }
            Y4.a.f4196b = aVar2.f4058a;
            aVar.l(aVar2);
            aVar2.f4058a.p();
        }
    }
}
