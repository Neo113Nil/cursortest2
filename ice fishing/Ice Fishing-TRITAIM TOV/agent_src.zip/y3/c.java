package y3;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final v3.C0940c f10248a;

    /* renamed from: b, reason: collision with root package name */
    public final u3.C0880g f10249b;

    /* renamed from: c, reason: collision with root package name */
    public final x3.d f10250c;

    /* renamed from: d, reason: collision with root package name */
    public final w3.C0991a f10251d;

    public c(v3.C0940c c0940c, u3.C0880g c0880g, x3.d dVar, w3.C0991a c0991a) {
        this.f10248a = c0940c;
        this.f10249b = c0880g;
        this.f10250c = dVar;
        this.f10251d = c0991a;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object a(W3.c cVar) {
        y3.C1016a c1016a;
        y3.c cVar2;
        if (cVar instanceof y3.C1016a) {
            c1016a = (y3.C1016a) cVar;
            int i = c1016a.f10242o;
            if ((i & Integer.MIN_VALUE) != 0) {
                c1016a.f10242o = i - Integer.MIN_VALUE;
            } else {
                c1016a = new y3.C1016a(this, cVar);
            }
        }
        java.lang.Object objA = c1016a.f10240m;
        V3.a aVar = V3.a.i;
        int i6 = c1016a.f10242o;
        if (i6 == 0) {
            b5.c.Z(objA);
            c1016a.f10239l = this;
            c1016a.f10242o = 1;
            objA = this.f10248a.a(c1016a);
            if (objA == aVar) {
                return aVar;
            }
            cVar2 = this;
        } else {
            if (i6 != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            cVar2 = c1016a.f10239l;
            b5.c.Z(objA);
        }
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) objA;
        if (foragerTallyResponse == null) {
            return null;
        }
        w3.C0991a c0991a = cVar2.f10251d;
        java.lang.String speciesName = foragerTallyResponse.getSpeciesName();
        return f4.i.a(speciesName, "Ganoderma applanatum") ? A3.b.f47a : new A3.c(speciesName);
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0097 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object b(W3.c cVar) {
        y3.b bVar;
        x3.d dVar;
        y3.c cVar2;
        y3.c cVar3;
        java.lang.Object objA;
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse;
        y3.c cVar4;
        if (cVar instanceof y3.b) {
            bVar = (y3.b) cVar;
            int i = bVar.f10247p;
            if ((i & Integer.MIN_VALUE) != 0) {
                bVar.f10247p = i - Integer.MIN_VALUE;
            } else {
                bVar = new y3.b(this, cVar);
            }
        }
        java.lang.Object objF = bVar.f10245n;
        V3.a aVar = V3.a.i;
        int i6 = bVar.f10247p;
        if (i6 == 0) {
            b5.c.Z(objF);
            bVar.f10243l = this;
            dVar = this.f10250c;
            bVar.f10244m = dVar;
            bVar.f10247p = 1;
            objF = q4.AbstractC0784y.f(new u3.C0879f(this.f10249b, null), bVar);
            if (objF == aVar) {
                return aVar;
            }
            cVar2 = this;
        } else if (i6 == 1) {
            dVar = (x3.d) bVar.f10244m;
            cVar2 = bVar.f10243l;
            b5.c.Z(objF);
        } else {
            if (i6 != 2) {
                if (i6 != 3) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                foragerTallyResponse = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) bVar.f10244m;
                cVar4 = bVar.f10243l;
                b5.c.Z(objF);
                w3.C0991a c0991a = cVar4.f10251d;
                f4.i.e(foragerTallyResponse, "response");
                java.lang.String speciesName = foragerTallyResponse.getSpeciesName();
                return !f4.i.a(speciesName, "Ganoderma applanatum") ? A3.b.f47a : new A3.c(speciesName);
            }
            cVar3 = bVar.f10243l;
            b5.c.Z(objF);
            com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse2 = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) objF;
            v3.C0940c c0940c = cVar3.f10248a;
            bVar.f10243l = cVar3;
            bVar.f10244m = foragerTallyResponse2;
            bVar.f10247p = 3;
            objA = c0940c.f9714a.a(new p1.i(new v3.C0939b(c0940c, foragerTallyResponse2, null), null), bVar);
            if (objA != aVar) {
                objA = Q3.o.f3335a;
            }
            if (objA != aVar) {
                return aVar;
            }
            foragerTallyResponse = foragerTallyResponse2;
            cVar4 = cVar3;
            w3.C0991a c0991a2 = cVar4.f10251d;
            f4.i.e(foragerTallyResponse, "response");
            java.lang.String speciesName2 = foragerTallyResponse.getSpeciesName();
            if (!f4.i.a(speciesName2, "Ganoderma applanatum")) {
            }
        }
        bVar.f10243l = cVar2;
        bVar.f10244m = null;
        bVar.f10247p = 2;
        objF = dVar.a((A3.a) objF, bVar);
        if (objF == aVar) {
            return aVar;
        }
        cVar3 = cVar2;
        com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse foragerTallyResponse22 = (com.jorden.karto.setrisopira.feature.splash.data.remote.dto.ForagerTallyResponse) objF;
        v3.C0940c c0940c2 = cVar3.f10248a;
        bVar.f10243l = cVar3;
        bVar.f10244m = foragerTallyResponse22;
        bVar.f10247p = 3;
        objA = c0940c2.f9714a.a(new p1.i(new v3.C0939b(c0940c2, foragerTallyResponse22, null), null), bVar);
        if (objA != aVar) {
        }
        if (objA != aVar) {
        }
    }
}
