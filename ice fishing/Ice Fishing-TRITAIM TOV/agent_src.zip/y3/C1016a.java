package y3;

/* renamed from: y3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C1016a extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public y3.c f10239l;

    /* renamed from: m, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f10240m;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ y3.c f10241n;

    /* renamed from: o, reason: collision with root package name */
    public int f10242o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1016a(y3.c cVar, W3.c cVar2) {
        super(cVar2);
        this.f10241n = cVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f10240m = obj;
        this.f10242o |= Integer.MIN_VALUE;
        return this.f10241n.a(this);
    }
}
