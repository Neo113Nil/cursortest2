package y3;

/* loaded from: classes.dex */
public final class b extends W3.c {

    /* renamed from: l, reason: collision with root package name */
    public y3.c f10243l;

    /* renamed from: m, reason: collision with root package name */
    public java.lang.Object f10244m;

    /* renamed from: n, reason: collision with root package name */
    public /* synthetic */ java.lang.Object f10245n;

    /* renamed from: o, reason: collision with root package name */
    public final /* synthetic */ y3.c f10246o;

    /* renamed from: p, reason: collision with root package name */
    public int f10247p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(y3.c cVar, W3.c cVar2) {
        super(cVar2);
        this.f10246o = cVar;
    }

    @Override // W3.a
    public final java.lang.Object n(java.lang.Object obj) {
        this.f10245n = obj;
        this.f10247p |= Integer.MIN_VALUE;
        return this.f10246o.b(this);
    }
}
