package E3;

/* loaded from: classes.dex */
public final class d implements E3.e {

    /* renamed from: a, reason: collision with root package name */
    public final java.lang.String f392a;

    public d(java.lang.String str) {
        f4.i.e(str, "url");
        this.f392a = str;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof E3.d) && f4.i.a(this.f392a, ((E3.d) obj).f392a);
    }

    public final int hashCode() {
        return this.f392a.hashCode();
    }

    public final java.lang.String toString() {
        return D.e.q(new java.lang.StringBuilder("Tab(url="), this.f392a, ")");
    }
}
