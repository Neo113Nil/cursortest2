package E3;

/* loaded from: classes.dex */
public final class b implements E3.e {

    /* renamed from: a, reason: collision with root package name */
    public static final E3.b f390a = new E3.b();

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof E3.b);
    }

    public final int hashCode() {
        return -626078474;
    }

    public final java.lang.String toString() {
        return "Loading";
    }
}
