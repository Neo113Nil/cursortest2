package E3;

/* loaded from: classes.dex */
public final class c implements E3.e {

    /* renamed from: a, reason: collision with root package name */
    public static final E3.c f391a = new E3.c();

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof E3.c);
    }

    public final int hashCode() {
        return -750697409;
    }

    public final java.lang.String toString() {
        return "Main";
    }
}
