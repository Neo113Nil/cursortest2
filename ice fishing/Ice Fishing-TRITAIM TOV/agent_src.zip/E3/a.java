package E3;

/* loaded from: classes.dex */
public final class a implements E3.e {

    /* renamed from: a, reason: collision with root package name */
    public static final E3.a f389a = new E3.a();

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof E3.a);
    }

    public final int hashCode() {
        return -1803656126;
    }

    public final java.lang.String toString() {
        return "Error";
    }
}
