package com.uxdepy.xxeubg;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.uxdepy.xxeubg.core.Progress;
import com.uxdepy.xxeubg.core.Sfx;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.theme.Palette;
import com.uxdepy.xxeubg.theme.Skins;
import java.util.Arrays;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;

/* compiled from: MenuActivity.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0014J\b\u0010\u000e\u001a\u00020\u000bH\u0002J\b\u0010\u000f\u001a\u00020\u000bH\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/uxdepy/xxeubg/MenuActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", NotificationCompat.CATEGORY_PROGRESS, "Lcom/uxdepy/xxeubg/core/Progress;", "coinPill", "Landroid/widget/LinearLayout;", "dailyBtn", "Landroid/widget/TextView;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "claimDaily", "onResume", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class MenuActivity extends AppCompatActivity {
    private LinearLayout coinPill;
    private TextView dailyBtn;
    private Progress progress;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MenuActivity menuActivity = this;
        this.progress = new Progress(menuActivity);
        Skins skins = Skins.INSTANCE;
        Progress progress = this.progress;
        LinearLayout linearLayout = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        skins.apply(progress.selectedSkin());
        Sfx sfx = Sfx.INSTANCE;
        Context applicationContext = getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
        sfx.init(applicationContext);
        Sfx sfx2 = Sfx.INSTANCE;
        Progress progress2 = this.progress;
        if (progress2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress2 = null;
        }
        sfx2.setEnabled(progress2.getSfxOn());
        LinearLayout linearLayout2 = new LinearLayout(menuActivity);
        linearLayout2.setOrientation(1);
        linearLayout2.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout2.setPadding(Ui.INSTANCE.dp(menuActivity, 24), Ui.INSTANCE.dp(menuActivity, 24), Ui.INSTANCE.dp(menuActivity, 24), Ui.INSTANCE.dp(menuActivity, 32));
        Ui ui = Ui.INSTANCE;
        Progress progress3 = this.progress;
        if (progress3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress3 = null;
        }
        this.coinPill = ui.coinPill(menuActivity, progress3.getCoins());
        final TextView textView = new TextView(menuActivity);
        Progress progress4 = this.progress;
        if (progress4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress4 = null;
        }
        textView.setText(progress4.getSfxOn() ? "🔊" : "🔇");
        textView.setTextSize(18.0f);
        textView.setGravity(17);
        textView.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(menuActivity, 22)));
        textView.setPadding(Ui.INSTANCE.dp(menuActivity, 12), Ui.INSTANCE.dp(menuActivity, 8), Ui.INSTANCE.dp(menuActivity, 12), Ui.INSTANCE.dp(menuActivity, 8));
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MenuActivity.onCreate$lambda$2$lambda$1(MenuActivity.this, textView, view);
            }
        });
        TextView textView2 = new TextView(menuActivity);
        textView2.setText("🎁");
        textView2.setTextSize(18.0f);
        textView2.setGravity(17);
        Ui ui2 = Ui.INSTANCE;
        Progress progress5 = this.progress;
        if (progress5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress5 = null;
        }
        textView2.setBackground(ui2.rounded(progress5.canClaimDaily() ? Palette.INSTANCE.getAccent() : Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(menuActivity, 22)));
        textView2.setPadding(Ui.INSTANCE.dp(menuActivity, 12), Ui.INSTANCE.dp(menuActivity, 8), Ui.INSTANCE.dp(menuActivity, 12), Ui.INSTANCE.dp(menuActivity, 8));
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MenuActivity.this.claimDaily();
            }
        });
        this.dailyBtn = textView2;
        LinearLayout linearLayout3 = new LinearLayout(menuActivity);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        linearLayout3.addView(textView);
        TextView textView3 = this.dailyBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("dailyBtn");
            textView3 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(Ui.INSTANCE.dp(menuActivity, 10));
        Unit unit = Unit.INSTANCE;
        linearLayout3.addView(textView3, layoutParams);
        FrameLayout frameLayout = new FrameLayout(menuActivity);
        frameLayout.addView(linearLayout3, new FrameLayout.LayoutParams(-2, -2, 8388627));
        LinearLayout linearLayout4 = this.coinPill;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("coinPill");
        } else {
            linearLayout = linearLayout4;
        }
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-2, -2, 8388629));
        linearLayout2.addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
        linearLayout2.addView(new View(menuActivity), new LinearLayout.LayoutParams(-1, 0, 1.0f));
        TextView textView4 = new TextView(menuActivity);
        String string = getString(R.string.app_name);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String upperCase = string.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView4.setText(StringsKt.replaceFirst$default(upperCase, " ", "\n", false, 4, (Object) null));
        textView4.setTypeface(Ui.INSTANCE.black(menuActivity));
        textView4.setTextSize(44.0f);
        textView4.setLetterSpacing(0.02f);
        textView4.setGravity(17);
        textView4.setTextColor(Palette.INSTANCE.getText());
        textView4.setLineSpacing(0.0f, 0.92f);
        linearLayout2.addView(textView4, new LinearLayout.LayoutParams(-1, -2));
        TextView textView5 = new TextView(menuActivity);
        textView5.setText("POUR • SORT • SOLVE");
        textView5.setTypeface(Ui.INSTANCE.regular(menuActivity));
        textView5.setTextSize(14.0f);
        textView5.setLetterSpacing(0.3f);
        textView5.setGravity(17);
        textView5.setTextColor(Palette.INSTANCE.getAccent());
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = Ui.INSTANCE.dp(menuActivity, 10);
        Unit unit2 = Unit.INSTANCE;
        linearLayout2.addView(textView5, layoutParams2);
        TextView button = Ui.INSTANCE.button(menuActivity, "PLAY", Palette.INSTANCE.getAccent(), Palette.INSTANCE.getBackground(), new Function0() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$10;
                onCreate$lambda$10 = MenuActivity.onCreate$lambda$10(MenuActivity.this);
                return onCreate$lambda$10;
            }
        });
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = Ui.INSTANCE.dp(menuActivity, 40);
        Unit unit3 = Unit.INSTANCE;
        linearLayout2.addView(button, layoutParams3);
        TextView button2 = Ui.INSTANCE.button(menuActivity, "LEADERBOARD", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$12;
                onCreate$lambda$12 = MenuActivity.onCreate$lambda$12(MenuActivity.this);
                return onCreate$lambda$12;
            }
        });
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = Ui.INSTANCE.dp(menuActivity, 14);
        Unit unit4 = Unit.INSTANCE;
        linearLayout2.addView(button2, layoutParams4);
        TextView button3 = Ui.INSTANCE.button(menuActivity, "SHOP", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$14;
                onCreate$lambda$14 = MenuActivity.onCreate$lambda$14(MenuActivity.this);
                return onCreate$lambda$14;
            }
        });
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = Ui.INSTANCE.dp(menuActivity, 14);
        Unit unit5 = Unit.INSTANCE;
        linearLayout2.addView(button3, layoutParams5);
        TextView button4 = Ui.INSTANCE.button(menuActivity, "ACHIEVEMENTS", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$16;
                onCreate$lambda$16 = MenuActivity.onCreate$lambda$16(MenuActivity.this);
                return onCreate$lambda$16;
            }
        });
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = Ui.INSTANCE.dp(menuActivity, 14);
        Unit unit6 = Unit.INSTANCE;
        linearLayout2.addView(button4, layoutParams6);
        linearLayout2.addView(new View(menuActivity), new LinearLayout.LayoutParams(-1, 0, 1.0f));
        TextView textView6 = new TextView(menuActivity);
        textView6.setText("Privacy Policy");
        textView6.setTypeface(Ui.INSTANCE.regular(menuActivity));
        textView6.setTextSize(12.0f);
        textView6.setLetterSpacing(0.06f);
        textView6.setGravity(17);
        textView6.setTextColor(Palette.INSTANCE.getTextDim());
        textView6.setClickable(true);
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.MenuActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MenuActivity.onCreate$lambda$19$lambda$18(MenuActivity.this, view);
            }
        });
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.topMargin = Ui.INSTANCE.dp(menuActivity, 8);
        Unit unit7 = Unit.INSTANCE;
        linearLayout2.addView(textView6, layoutParams7);
        setContentView(linearLayout2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2$lambda$1(MenuActivity menuActivity, TextView textView, View view) {
        Progress progress = menuActivity.progress;
        Progress progress2 = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        boolean sfxOn = progress.getSfxOn();
        boolean z = !sfxOn;
        Progress progress3 = menuActivity.progress;
        if (progress3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
        } else {
            progress2 = progress3;
        }
        progress2.setSfxOn(z);
        Sfx.INSTANCE.setEnabled(z);
        textView.setText(!sfxOn ? "🔊" : "🔇");
        if (sfxOn) {
            return;
        }
        Sfx.INSTANCE.place();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$10(MenuActivity menuActivity) {
        menuActivity.startActivity(new Intent(menuActivity, (Class<?>) GameActivity.class));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$12(MenuActivity menuActivity) {
        menuActivity.startActivity(new Intent(menuActivity, (Class<?>) LeaderboardActivity.class));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$14(MenuActivity menuActivity) {
        menuActivity.startActivity(new Intent(menuActivity, (Class<?>) ShopActivity.class));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$16(MenuActivity menuActivity) {
        menuActivity.startActivity(new Intent(menuActivity, (Class<?>) AchievementsActivity.class));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$19$lambda$18(MenuActivity menuActivity, View view) {
        menuActivity.startActivity(new Intent(menuActivity, (Class<?>) PrivacyActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void claimDaily() {
        Progress progress = this.progress;
        Progress progress2 = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        int claimDaily = progress.claimDaily();
        if (claimDaily > 0) {
            Sfx.INSTANCE.place();
            Toast.makeText(this, "Daily reward: +" + claimDaily + " coins!", 0).show();
            TextView textView = this.dailyBtn;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("dailyBtn");
                textView = null;
            }
            textView.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(r4, 22)));
            LinearLayout linearLayout = this.coinPill;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("coinPill");
                linearLayout = null;
            }
            TextView textView2 = (TextView) linearLayout.findViewById(Ui.COIN_TEXT_ID);
            if (textView2 != null) {
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                Progress progress3 = this.progress;
                if (progress3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
                } else {
                    progress2 = progress3;
                }
                String format = String.format("%,d", Arrays.copyOf(new Object[]{Integer.valueOf(progress2.getCoins())}, 1));
                Intrinsics.checkNotNullExpressionValue(format, "format(...)");
                textView2.setText(format);
                return;
            }
            return;
        }
        Toast.makeText(this, "Come back tomorrow!", 0).show();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        Skins skins = Skins.INSTANCE;
        Progress progress = this.progress;
        Progress progress2 = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        skins.apply(progress.selectedSkin());
        LinearLayout linearLayout = this.coinPill;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("coinPill");
            linearLayout = null;
        }
        TextView textView = (TextView) linearLayout.findViewById(Ui.COIN_TEXT_ID);
        if (textView != null) {
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            Progress progress3 = this.progress;
            if (progress3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
                progress3 = null;
            }
            String format = String.format("%,d", Arrays.copyOf(new Object[]{Integer.valueOf(progress3.getCoins())}, 1));
            Intrinsics.checkNotNullExpressionValue(format, "format(...)");
            textView.setText(format);
        }
        TextView textView2 = this.dailyBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("dailyBtn");
                textView2 = null;
            }
            Ui ui = Ui.INSTANCE;
            Progress progress4 = this.progress;
            if (progress4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            } else {
                progress2 = progress4;
            }
            textView2.setBackground(ui.rounded(progress2.canClaimDaily() ? Palette.INSTANCE.getAccent() : Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(this, 22)));
        }
    }
}
