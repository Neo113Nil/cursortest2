package com.uxdepy.xxeubg;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.uxdepy.xxeubg.core.Overlay;
import com.uxdepy.xxeubg.core.Progress;
import com.uxdepy.xxeubg.core.Sfx;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.game.TubesView;
import com.uxdepy.xxeubg.theme.Palette;
import com.uxdepy.xxeubg.theme.Skins;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: GameActivity.kt */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0012\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014H\u0014J\u0010\u0010\u0015\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\rH\u0002J\b\u0010\u0017\u001a\u00020\u0012H\u0002J\u0018\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\bH\u0002J\b\u0010\u001d\u001a\u00020\u001eH\u0002J\u0018\u0010\u001f\u001a\u00020\u00122\u0006\u0010 \u001a\u00020\r2\u0006\u0010!\u001a\u00020\rH\u0016J\b\u0010\"\u001a\u00020\u0012H\u0016J\b\u0010#\u001a\u00020\u0012H\u0016J\b\u0010$\u001a\u00020\u0012H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lcom/uxdepy/xxeubg/GameActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "Lcom/uxdepy/xxeubg/game/TubesView$Listener;", "<init>", "()V", "tubesView", "Lcom/uxdepy/xxeubg/game/TubesView;", "levelLabel", "Landroid/widget/TextView;", "movesLabel", NotificationCompat.CATEGORY_PROGRESS, "Lcom/uxdepy/xxeubg/core/Progress;", "level", "", "solved", "finished", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "numColors", "l", "startLevel", "chip", "Landroid/widget/LinearLayout;", "label", "", "value", "chipLp", "Landroid/widget/LinearLayout$LayoutParams;", "onMove", "used", "limit", "onSolved", "onGameOver", "showPause", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class GameActivity extends AppCompatActivity implements TubesView.Listener {
    private boolean finished;
    private int level = 1;
    private TextView levelLabel;
    private TextView movesLabel;
    private Progress progress;
    private int solved;
    private TubesView tubesView;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GameActivity gameActivity = this;
        this.progress = new Progress(gameActivity);
        Skins skins = Skins.INSTANCE;
        Progress progress = this.progress;
        TubesView tubesView = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        skins.apply(progress.selectedSkin());
        Sfx sfx = Sfx.INSTANCE;
        Context applicationContext = getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
        sfx.init(applicationContext);
        Sfx sfx2 = Sfx.INSTANCE;
        Progress progress2 = this.progress;
        if (progress2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress2 = null;
        }
        sfx2.setEnabled(progress2.getSfxOn());
        LinearLayout linearLayout = new LinearLayout(gameActivity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout.setPadding(Ui.INSTANCE.dp(gameActivity, 16), Ui.INSTANCE.dp(gameActivity, 18), Ui.INSTANCE.dp(gameActivity, 16), Ui.INSTANCE.dp(gameActivity, 12));
        LinearLayout linearLayout2 = new LinearLayout(gameActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.levelLabel = new TextView(gameActivity);
        this.movesLabel = new TextView(gameActivity);
        TextView pauseChip = Overlay.INSTANCE.pauseChip(this, new Function0() { // from class: com.uxdepy.xxeubg.GameActivity$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$2;
                onCreate$lambda$2 = GameActivity.onCreate$lambda$2(GameActivity.this);
                return onCreate$lambda$2;
            }
        });
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
        layoutParams.setMarginEnd(Ui.INSTANCE.dp(gameActivity, 6));
        Unit unit = Unit.INSTANCE;
        linearLayout2.addView(pauseChip, layoutParams);
        TextView textView = this.levelLabel;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("levelLabel");
            textView = null;
        }
        linearLayout2.addView(chip("LEVEL", textView), chipLp());
        TextView textView2 = this.movesLabel;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movesLabel");
            textView2 = null;
        }
        linearLayout2.addView(chip("MOVES", textView2), chipLp());
        TubesView tubesView2 = new TubesView(gameActivity, null, 2, null);
        tubesView2.setListener(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams2.topMargin = Ui.INSTANCE.dp(gameActivity, 10);
        tubesView2.setLayoutParams(layoutParams2);
        this.tubesView = tubesView2;
        linearLayout.addView(linearLayout2);
        TubesView tubesView3 = this.tubesView;
        if (tubesView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tubesView");
        } else {
            tubesView = tubesView3;
        }
        linearLayout.addView(tubesView);
        setContentView(linearLayout);
        startLevel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$2(GameActivity gameActivity) {
        gameActivity.showPause();
        return Unit.INSTANCE;
    }

    private final int numColors(int l) {
        return RangesKt.coerceIn(((l - 1) / 2) + 4, 4, 8);
    }

    private final void startLevel() {
        int numColors = numColors(this.level);
        TextView textView = this.levelLabel;
        TubesView tubesView = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("levelLabel");
            textView = null;
        }
        textView.setText(String.valueOf(this.level));
        TubesView tubesView2 = this.tubesView;
        if (tubesView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tubesView");
        } else {
            tubesView = tubesView2;
        }
        tubesView.start(numColors, numColors * 6);
    }

    private final LinearLayout chip(String label, TextView value) {
        GameActivity gameActivity = this;
        LinearLayout linearLayout = new LinearLayout(gameActivity);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(gameActivity, 18)));
        linearLayout.setPadding(Ui.INSTANCE.dp(gameActivity, 10), Ui.INSTANCE.dp(gameActivity, 12), Ui.INSTANCE.dp(gameActivity, 10), Ui.INSTANCE.dp(gameActivity, 14));
        TextView textView = new TextView(gameActivity);
        textView.setText(label);
        textView.setTypeface(Ui.INSTANCE.regular(gameActivity));
        textView.setTextSize(12.0f);
        textView.setLetterSpacing(0.18f);
        textView.setTextColor(Palette.INSTANCE.getTextDim());
        textView.setGravity(17);
        linearLayout.addView(textView);
        value.setTypeface(Ui.INSTANCE.black(gameActivity));
        value.setTextSize(24.0f);
        value.setTextColor(Palette.INSTANCE.getAccent());
        value.setGravity(17);
        value.setText("-");
        linearLayout.addView(value);
        return linearLayout;
    }

    private final LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        GameActivity gameActivity = this;
        layoutParams.setMarginStart(Ui.INSTANCE.dp(gameActivity, 6));
        layoutParams.setMarginEnd(Ui.INSTANCE.dp(gameActivity, 6));
        return layoutParams;
    }

    @Override // com.uxdepy.xxeubg.game.TubesView.Listener
    public void onMove(int used, int limit) {
        TextView textView = this.movesLabel;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movesLabel");
            textView = null;
        }
        textView.setText(used + " / " + limit);
    }

    @Override // com.uxdepy.xxeubg.game.TubesView.Listener
    public void onSolved() {
        this.solved++;
        Progress progress = this.progress;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        progress.setCoins(progress.getCoins() + 5);
        this.level++;
        Overlay.show$default(Overlay.INSTANCE, this, "Level " + (this.level - 1), "Level Complete", CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to("Solved", String.valueOf(this.solved)), TuplesKt.to("Coins", "+5")}), CollectionsKt.listOf(new Overlay.Btn("Continue", true, new Function0() { // from class: com.uxdepy.xxeubg.GameActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onSolved$lambda$10;
                onSolved$lambda$10 = GameActivity.onSolved$lambda$10(GameActivity.this);
                return onSolved$lambda$10;
            }
        })), false, 32, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onSolved$lambda$10(GameActivity gameActivity) {
        if (!gameActivity.finished) {
            gameActivity.startLevel();
        }
        return Unit.INSTANCE;
    }

    @Override // com.uxdepy.xxeubg.game.TubesView.Listener
    public void onGameOver() {
        if (this.finished) {
            return;
        }
        this.finished = true;
        Progress progress = this.progress;
        Progress progress2 = null;
        if (progress == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
            progress = null;
        }
        Pair<Integer, Boolean> recordGame = progress.recordGame(this.solved);
        int intValue = recordGame.component1().intValue();
        boolean booleanValue = recordGame.component2().booleanValue();
        Intent putExtra = new Intent(this, (Class<?>) GameOverActivity.class).putExtra(GameOverActivity.EXTRA_SCORE, this.solved).putExtra(GameOverActivity.EXTRA_EARNED, intValue);
        Progress progress3 = this.progress;
        if (progress3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(NotificationCompat.CATEGORY_PROGRESS);
        } else {
            progress2 = progress3;
        }
        startActivity(putExtra.putExtra(GameOverActivity.EXTRA_BEST, progress2.getBest()).putExtra(GameOverActivity.EXTRA_NEWBEST, booleanValue));
        finish();
    }

    private final void showPause() {
        Overlay.INSTANCE.show(this, "", "Paused", CollectionsKt.emptyList(), CollectionsKt.listOf((Object[]) new Overlay.Btn[]{new Overlay.Btn("Resume", true, new Function0() { // from class: com.uxdepy.xxeubg.GameActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit unit;
                unit = Unit.INSTANCE;
                return unit;
            }
        }), new Overlay.Btn("Restart", false, new Function0() { // from class: com.uxdepy.xxeubg.GameActivity$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit showPause$lambda$12;
                showPause$lambda$12 = GameActivity.showPause$lambda$12(GameActivity.this);
                return showPause$lambda$12;
            }
        }, 2, null), new Overlay.Btn("Menu", false, new Function0() { // from class: com.uxdepy.xxeubg.GameActivity$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit showPause$lambda$13;
                showPause$lambda$13 = GameActivity.showPause$lambda$13(GameActivity.this);
                return showPause$lambda$13;
            }
        }, 2, null)}), true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showPause$lambda$12(GameActivity gameActivity) {
        gameActivity.startLevel();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit showPause$lambda$13(GameActivity gameActivity) {
        gameActivity.finish();
        return Unit.INSTANCE;
    }
}
