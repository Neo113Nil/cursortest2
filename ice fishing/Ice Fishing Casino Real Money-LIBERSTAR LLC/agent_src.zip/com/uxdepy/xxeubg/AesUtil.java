package com.uxdepy.xxeubg;

import android.util.Base64;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: AesUtil.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005¨\u0006\t"}, d2 = {"Lcom/uxdepy/xxeubg/AesUtil;", "", "<init>", "()V", "decrypt", "", "base64Ciphertext", "key", "iv", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class AesUtil {
    public static final AesUtil INSTANCE = new AesUtil();

    private AesUtil() {
    }

    public final String decrypt(String base64Ciphertext, String key, String iv) {
        Intrinsics.checkNotNullParameter(base64Ciphertext, "base64Ciphertext");
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(iv, "iv");
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            Charset UTF_8 = StandardCharsets.UTF_8;
            Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
            byte[] bytes = key.getBytes(UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");
            Charset UTF_82 = StandardCharsets.UTF_8;
            Intrinsics.checkNotNullExpressionValue(UTF_82, "UTF_8");
            byte[] bytes2 = iv.getBytes(UTF_82);
            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
            cipher.init(2, secretKeySpec, new IvParameterSpec(bytes2));
            byte[] doFinal = cipher.doFinal(Base64.decode(base64Ciphertext, 0));
            Intrinsics.checkNotNull(doFinal);
            Charset UTF_83 = StandardCharsets.UTF_8;
            Intrinsics.checkNotNullExpressionValue(UTF_83, "UTF_8");
            return new String(doFinal, UTF_83);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
