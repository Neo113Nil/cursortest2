package com.uxdepy.xxeubg;

import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.net.MailTo;
import com.uxdepy.xxeubg.core.ProgressKt;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;

/* compiled from: PrismPeakPrivacyPolicyActivity.kt */
@Metadata(d1 = {"\u0000E\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006*\u0001\u0014\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0015J\u0018\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0003J\u001d\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0002¢\u0006\u0002\u0010\u0015J\u0018\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0005H\u0002J\u0010\u0010\u0019\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0005H\u0002J \u0010\u001a\u001a\u00020\u00172\u0006\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u0005H\u0002J\u0010\u0010\u001d\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0005H\u0002J\u0018\u0010\u001e\u001a\u00020\u000b2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010\u001c\u001a\u00020\u0005H\u0002J\u0010\u0010!\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010\"\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010#\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010$\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\b\u0010%\u001a\u00020\u000bH\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007¨\u0006&"}, d2 = {"Lcom/uxdepy/xxeubg/PrismPeakPrivacyPolicyActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "urlOffer", "", "getUrlOffer", "()Ljava/lang/String;", "urlOffer$delegate", "Lkotlin/Lazy;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "configureWebView", "webView", "Landroid/webkit/WebView;", "loadingIndicator", "Landroid/widget/ProgressBar;", "createWebViewClient", "com/uxdepy/xxeubg/PrismPeakPrivacyPolicyActivity$createWebViewClient$1", "(Landroid/webkit/WebView;Landroid/widget/ProgressBar;)Lcom/uxdepy/xxeubg/PrismPeakPrivacyPolicyActivity$createWebViewClient$1;", "handleUrlLoading", "", "url", "launchIntentLink", "launchAppIntent", "action", "errorMessage", "launchDiiaApp", "launchIntent", "intent", "Landroid/content/Intent;", "acceptCookies", "setupDownloadListener", "setupBackNavigationListener", "setWebChromeClient", "goHome", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PrismPeakPrivacyPolicyActivity extends ComponentActivity {

    /* renamed from: urlOffer$delegate, reason: from kotlin metadata */
    private final Lazy urlOffer = LazyKt.lazy(new Function0() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            String urlOffer_delegate$lambda$0;
            urlOffer_delegate$lambda$0 = PrismPeakPrivacyPolicyActivity.urlOffer_delegate$lambda$0(PrismPeakPrivacyPolicyActivity.this);
            return urlOffer_delegate$lambda$0;
        }
    });

    private final String getUrlOffer() {
        return (String) this.urlOffer.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String urlOffer_delegate$lambda$0(PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity) {
        String stringExtra = prismPeakPrivacyPolicyActivity.getIntent().getStringExtra("url");
        return stringExtra == null ? "" : stringExtra;
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_remote_content);
        setRequestedOrientation(10);
        WebView webView = (WebView) findViewById(R.id.xxeubgWebView);
        Button button = (Button) findViewById(R.id.xxeubgBackButton);
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.xxeubgLoadingIndicator);
        button.setVisibility(StringsKt.contains$default((CharSequence) getUrlOffer(), (CharSequence) ProgressKt.SAFE_URL_PREFIX_PRISM_PEAK, false, 2, (Object) null) ? 0 : 8);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                PrismPeakPrivacyPolicyActivity.this.goHome();
            }
        });
        button.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/Exo2-Black.ttf"));
        Intrinsics.checkNotNull(webView);
        Intrinsics.checkNotNull(progressBar);
        configureWebView(webView, progressBar);
        setupDownloadListener(webView);
        setupBackNavigationListener(webView);
        setWebChromeClient(webView);
        webView.loadUrl(getUrlOffer());
    }

    private final void configureWebView(WebView webView, ProgressBar loadingIndicator) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setMixedContentMode(0);
        String userAgentString = settings.getUserAgentString();
        Intrinsics.checkNotNullExpressionValue(userAgentString, "getUserAgentString(...)");
        settings.setUserAgentString(StringsKt.replace$default(userAgentString, "; wv", "", false, 4, (Object) null));
        settings.setSupportZoom(true);
        settings.setSupportMultipleWindows(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        webView.setWebViewClient(createWebViewClient(webView, loadingIndicator));
        acceptCookies(webView);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$createWebViewClient$1] */
    private final PrismPeakPrivacyPolicyActivity$createWebViewClient$1 createWebViewClient(final WebView webView, final ProgressBar loadingIndicator) {
        return new WebViewClient() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$createWebViewClient$1
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                boolean handleUrlLoading;
                Intrinsics.checkNotNullParameter(view, "view");
                Intrinsics.checkNotNullParameter(request, "request");
                PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity = PrismPeakPrivacyPolicyActivity.this;
                WebView webView2 = webView;
                String uri = request.getUrl().toString();
                Intrinsics.checkNotNullExpressionValue(uri, "toString(...)");
                handleUrlLoading = prismPeakPrivacyPolicyActivity.handleUrlLoading(webView2, uri);
                return handleUrlLoading;
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                Intrinsics.checkNotNullParameter(view, "view");
                Intrinsics.checkNotNullParameter(url, "url");
                loadingIndicator.setVisibility(8);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean handleUrlLoading(WebView webView, String url) {
        if (StringsKt.startsWith$default(url, "tel:", false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.DIAL", url, "Failed to open Phone app.");
        }
        if (StringsKt.startsWith$default(url, MailTo.MAILTO_SCHEME, false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.SENDTO", url, "Failed to open Mail app.");
        }
        if (StringsKt.startsWith$default(url, "viber:", false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.VIEW", url, "Failed to open Viber.");
        }
        if (StringsKt.startsWith$default(url, "tg:", false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.VIEW", url, "Failed to open Telegram.");
        }
        if (StringsKt.startsWith$default(url, "whatsapp:", false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.VIEW", url, "Failed to open WhatsApp.");
        }
        if (StringsKt.startsWith$default(url, "line://", false, 2, (Object) null)) {
            return launchAppIntent("android.intent.action.VIEW", url, "Failed to open Line.");
        }
        if (StringsKt.startsWith$default(url, "https://diia.app", false, 2, (Object) null)) {
            return launchDiiaApp(url);
        }
        if (StringsKt.startsWith$default(url, "intent://", false, 2, (Object) null)) {
            return launchIntentLink(url);
        }
        webView.loadUrl(url);
        return false;
    }

    private final boolean launchIntentLink(String url) {
        Intent parseUri = Intent.parseUri(url, 1);
        Intrinsics.checkNotNull(parseUri);
        launchIntent(parseUri, "Failed to open app");
        return true;
    }

    private final boolean launchAppIntent(String action, String url, String errorMessage) {
        launchIntent(new Intent(action, Uri.parse(url)), errorMessage);
        return true;
    }

    private final boolean launchDiiaApp(String url) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
        intent.addCategory("android.intent.category.BROWSABLE");
        intent.setFlags(268435456);
        intent.setPackage("ua.gov.diia.app");
        launchIntent(intent, "Failed to open Diia app.");
        return true;
    }

    private final void launchIntent(Intent intent, String errorMessage) {
        try {
            startActivity(intent);
        } catch (Exception unused) {
            Toast.makeText(this, errorMessage, 0).show();
        }
    }

    private final void acceptCookies(WebView webView) {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
    }

    private final void setupDownloadListener(WebView webView) {
        webView.setDownloadListener(new DownloadListener() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$$ExternalSyntheticLambda1
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                PrismPeakPrivacyPolicyActivity.setupDownloadListener$lambda$6(PrismPeakPrivacyPolicyActivity.this, str, str2, str3, str4, j);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setupDownloadListener$lambda$6(PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity, String str, String str2, String str3, String str4, long j) {
        Intrinsics.checkNotNull(str);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str));
        request.setTitle(URLUtil.guessFileName(str, str3, str4));
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(str, str3, str4));
        request.setAllowedOverMetered(true);
        Object systemService = prismPeakPrivacyPolicyActivity.getSystemService("download");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.DownloadManager");
        ((DownloadManager) systemService).enqueue(request);
        Toast.makeText(prismPeakPrivacyPolicyActivity, "Downloading...", 0).show();
    }

    private final void setupBackNavigationListener(final WebView webView) {
        webView.setOnKeyListener(new View.OnKeyListener() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnKeyListener
            public final boolean onKey(View view, int i, KeyEvent keyEvent) {
                boolean z;
                z = PrismPeakPrivacyPolicyActivity.setupBackNavigationListener$lambda$7(webView, view, i, keyEvent);
                return z;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean setupBackNavigationListener$lambda$7(WebView webView, View view, int i, KeyEvent keyEvent) {
        if (i != 4 || keyEvent.getAction() != 1 || !webView.canGoBack()) {
            return false;
        }
        webView.goBack();
        return true;
    }

    private final void setWebChromeClient(WebView webView) {
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        webView.setWebChromeClient(new PrismPeakPrivacyPolicyActivity$setWebChromeClient$1(this, objectRef, getActivityResultRegistry().register("xxeubg-file-picker", new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$$ExternalSyntheticLambda3
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                PrismPeakPrivacyPolicyActivity.setWebChromeClient$lambda$9(Ref.ObjectRef.this, (ActivityResult) obj);
            }
        })));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setWebChromeClient$lambda$9(Ref.ObjectRef objectRef, ActivityResult result) {
        Uri[] uriArr;
        Intrinsics.checkNotNullParameter(result, "result");
        ValueCallback valueCallback = (ValueCallback) objectRef.element;
        if (valueCallback != null) {
            Intent data = result.getData();
            if (data != null) {
                Uri data2 = data.getData();
                Intrinsics.checkNotNull(data2);
                uriArr = new Uri[]{data2};
            } else {
                uriArr = null;
            }
            valueCallback.onReceiveValue(uriArr);
        }
        objectRef.element = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void goHome() {
        startActivity(new Intent(this, (Class<?>) MenuActivity.class));
        finish();
    }
}
