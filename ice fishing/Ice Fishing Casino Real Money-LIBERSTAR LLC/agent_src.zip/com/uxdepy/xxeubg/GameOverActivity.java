package com.uxdepy.xxeubg;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.theme.Palette;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: GameOverActivity.kt */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u001c2\u00020\u0001:\u0001\u001cB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014J(\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0018\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u000bH\u0002J\b\u0010\u0016\u001a\u00020\u0017H\u0002J\b\u0010\u0018\u001a\u00020\u0017H\u0002J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\rH\u0002¨\u0006\u001d"}, d2 = {"Lcom/uxdepy/xxeubg/GameOverActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "text", "Landroid/widget/TextView;", "s", "", "size", "", "color", "", "tf", "Landroid/graphics/Typeface;", "chip", "Landroid/widget/LinearLayout;", "label", "value", "wrap", "Landroid/widget/LinearLayout$LayoutParams;", "chipLp", "spacer", "Landroid/view/View;", "weight", "Companion", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class GameOverActivity extends AppCompatActivity {
    public static final String EXTRA_BEST = "best";
    public static final String EXTRA_EARNED = "earned";
    public static final String EXTRA_NEWBEST = "newbest";
    public static final String EXTRA_SCORE = "score";

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final int intExtra = getIntent().getIntExtra(EXTRA_SCORE, 0);
        int intExtra2 = getIntent().getIntExtra(EXTRA_EARNED, 0);
        int intExtra3 = getIntent().getIntExtra(EXTRA_BEST, 0);
        boolean booleanExtra = getIntent().getBooleanExtra(EXTRA_NEWBEST, false);
        GameOverActivity gameOverActivity = this;
        LinearLayout linearLayout = new LinearLayout(gameOverActivity);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout.setPadding(Ui.INSTANCE.dp(gameOverActivity, 28), Ui.INSTANCE.dp(gameOverActivity, 28), Ui.INSTANCE.dp(gameOverActivity, 28), Ui.INSTANCE.dp(gameOverActivity, 32));
        linearLayout.addView(spacer(2.0f));
        TextView text = text("OUT OF MOVES", 30.0f, Palette.INSTANCE.getAccent(), Ui.INSTANCE.black(gameOverActivity));
        text.setLetterSpacing(0.08f);
        linearLayout.addView(text);
        TextView text2 = text(String.valueOf(intExtra), 82.0f, Palette.INSTANCE.getText(), Ui.INSTANCE.black(gameOverActivity));
        ViewGroup.LayoutParams layoutParams = text2.getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams) layoutParams).topMargin = Ui.INSTANCE.dp(gameOverActivity, 8);
        linearLayout.addView(text2);
        TextView text3 = text("LEVELS SOLVED", 13.0f, Palette.INSTANCE.getTextDim(), Ui.INSTANCE.regular(gameOverActivity));
        text3.setLetterSpacing(0.24f);
        linearLayout.addView(text3);
        if (booleanExtra) {
            TextView textView = new TextView(gameOverActivity);
            textView.setText("★  NEW BEST");
            textView.setTypeface(Ui.INSTANCE.black(gameOverActivity));
            textView.setTextSize(13.0f);
            textView.setLetterSpacing(0.08f);
            textView.setTextColor(Palette.INSTANCE.getBackground());
            textView.setGravity(17);
            textView.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getAccent(), Ui.INSTANCE.dp(gameOverActivity, 14)));
            textView.setPadding(Ui.INSTANCE.dp(gameOverActivity, 16), Ui.INSTANCE.dp(gameOverActivity, 8), Ui.INSTANCE.dp(gameOverActivity, 16), Ui.INSTANCE.dp(gameOverActivity, 8));
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams2.topMargin = Ui.INSTANCE.dp(gameOverActivity, 18);
            textView.setLayoutParams(layoutParams2);
            linearLayout.addView(textView);
        }
        LinearLayout linearLayout2 = new LinearLayout(gameOverActivity);
        linearLayout2.setOrientation(0);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = Ui.INSTANCE.dp(gameOverActivity, 24);
        linearLayout2.setLayoutParams(layoutParams3);
        linearLayout2.addView(chip("BEST", String.valueOf(intExtra3)), chipLp());
        linearLayout2.addView(chip("COINS", "+" + intExtra2), chipLp());
        linearLayout.addView(linearLayout2);
        linearLayout.addView(spacer(2.0f));
        TextView button = Ui.INSTANCE.button(gameOverActivity, "RETRY", Palette.INSTANCE.getAccent(), Palette.INSTANCE.getBackground(), new Function0() { // from class: com.uxdepy.xxeubg.GameOverActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$8;
                onCreate$lambda$8 = GameOverActivity.onCreate$lambda$8(GameOverActivity.this);
                return onCreate$lambda$8;
            }
        });
        LinearLayout.LayoutParams wrap = wrap();
        wrap.topMargin = Ui.INSTANCE.dp(gameOverActivity, 8);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(button, wrap);
        TextView button2 = Ui.INSTANCE.button(gameOverActivity, "LEADERBOARD", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.GameOverActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$10;
                onCreate$lambda$10 = GameOverActivity.onCreate$lambda$10(GameOverActivity.this, intExtra);
                return onCreate$lambda$10;
            }
        });
        LinearLayout.LayoutParams wrap2 = wrap();
        wrap2.topMargin = Ui.INSTANCE.dp(gameOverActivity, 14);
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(button2, wrap2);
        TextView button3 = Ui.INSTANCE.button(gameOverActivity, "MENU", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.GameOverActivity$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$12;
                onCreate$lambda$12 = GameOverActivity.onCreate$lambda$12(GameOverActivity.this);
                return onCreate$lambda$12;
            }
        });
        LinearLayout.LayoutParams wrap3 = wrap();
        wrap3.topMargin = Ui.INSTANCE.dp(gameOverActivity, 14);
        Unit unit3 = Unit.INSTANCE;
        linearLayout.addView(button3, wrap3);
        setContentView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$8(GameOverActivity gameOverActivity) {
        gameOverActivity.startActivity(new Intent(gameOverActivity, (Class<?>) GameActivity.class));
        gameOverActivity.finish();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$10(GameOverActivity gameOverActivity, int i) {
        gameOverActivity.startActivity(new Intent(gameOverActivity, (Class<?>) LeaderboardActivity.class).putExtra(LeaderboardActivity.EXTRA_LATEST, i));
        gameOverActivity.finish();
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$12(GameOverActivity gameOverActivity) {
        gameOverActivity.finish();
        return Unit.INSTANCE;
    }

    private final TextView text(String s, float size, int color, Typeface tf) {
        TextView textView = new TextView(this);
        textView.setText(s);
        textView.setTextSize(size);
        textView.setTextColor(color);
        textView.setTypeface(tf);
        textView.setGravity(17);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return textView;
    }

    private final LinearLayout chip(String label, String value) {
        GameOverActivity gameOverActivity = this;
        LinearLayout linearLayout = new LinearLayout(gameOverActivity);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(gameOverActivity, 18)));
        linearLayout.setPadding(Ui.INSTANCE.dp(gameOverActivity, 10), Ui.INSTANCE.dp(gameOverActivity, 14), Ui.INSTANCE.dp(gameOverActivity, 10), Ui.INSTANCE.dp(gameOverActivity, 16));
        TextView text = text(label, 12.0f, Palette.INSTANCE.getTextDim(), Ui.INSTANCE.regular(gameOverActivity));
        text.setLetterSpacing(0.18f);
        linearLayout.addView(text);
        linearLayout.addView(text(value, 24.0f, Palette.INSTANCE.getAccent(), Ui.INSTANCE.black(gameOverActivity)));
        return linearLayout;
    }

    private final LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private final LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        GameOverActivity gameOverActivity = this;
        layoutParams.setMarginStart(Ui.INSTANCE.dp(gameOverActivity, 6));
        layoutParams.setMarginEnd(Ui.INSTANCE.dp(gameOverActivity, 6));
        return layoutParams;
    }

    private final View spacer(float weight) {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, weight));
        return view;
    }
}
