package com.uxdepy.xxeubg;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.theme.Palette;
import kotlin.Metadata;

/* compiled from: PrivacyActivity.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014¨\u0006\b"}, d2 = {"Lcom/uxdepy/xxeubg/PrivacyActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PrivacyActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PrivacyActivity privacyActivity = this;
        LinearLayout linearLayout = new LinearLayout(privacyActivity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        LinearLayout linearLayout2 = new LinearLayout(privacyActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(Ui.INSTANCE.dp(privacyActivity, 20), Ui.INSTANCE.dp(privacyActivity, 20), Ui.INSTANCE.dp(privacyActivity, 20), Ui.INSTANCE.dp(privacyActivity, 16));
        TextView textView = new TextView(privacyActivity);
        textView.setText("‹ BACK");
        textView.setTypeface(Ui.INSTANCE.black(privacyActivity));
        textView.setTextSize(15.0f);
        textView.setTextColor(Palette.INSTANCE.getAccent());
        textView.setClickable(true);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.PrivacyActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                PrivacyActivity.this.finish();
            }
        });
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(privacyActivity);
        textView2.setText("PRIVACY POLICY");
        textView2.setTypeface(Ui.INSTANCE.black(privacyActivity));
        textView2.setTextSize(16.0f);
        textView2.setLetterSpacing(0.04f);
        textView2.setTextColor(Palette.INSTANCE.getText());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(Ui.INSTANCE.dp(privacyActivity, 16));
        textView2.setLayoutParams(layoutParams);
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        WebView webView = new WebView(privacyActivity);
        webView.setBackgroundColor(Palette.INSTANCE.getBackground());
        webView.loadUrl("file:///android_asset/privacy_policy.html");
        linearLayout.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        setContentView(linearLayout);
    }
}
