package com.uxdepy.xxeubg.core;

import com.uxdepy.xxeubg.AesUtil;
import kotlin.Metadata;

/* compiled from: Progress.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"PRSMPK_PRISM_PEAK", "", "getPRSMPK_PRISM_PEAK", "()Ljava/lang/String;", "PPEAK_PRISM_PEAK", "PRISMPEAK_PRISM_PEAK", "SAFE_URL_PREFIX_PRISM_PEAK", "app_release"}, k = 2, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class ProgressKt {
    public static final String PPEAK_PRISM_PEAK = "ppeak";
    public static final String PRISMPEAK_PRISM_PEAK = "prismpeak";
    private static final String PRSMPK_PRISM_PEAK = AesUtil.INSTANCE.decrypt("eLs8fxC4fNz369n8lrqL+v2ddhb4pCLrOWxwTAyEjySQTEqNEYmWojkiLtxMRzzuWu8UVBPqNi4D/ayS1aI4Lg==", "x1IDvwdiwXPQGpju", "AjlmQN9qPZiKW2xa");
    public static final String SAFE_URL_PREFIX_PRISM_PEAK = "https://ceo481.github.io/prism-peak/";

    public static final String getPRSMPK_PRISM_PEAK() {
        return PRSMPK_PRISM_PEAK;
    }
}
