package com.uxdepy.xxeubg.core;

import android.R;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.uxdepy.xxeubg.theme.Palette;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Overlay.kt */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0018B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003JR\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u001a\b\u0002\u0010\u000b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\t0\r0\f2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\f2\b\b\u0002\u0010\u0010\u001a\u00020\u0011J\u001c\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0006\u001a\u00020\u00072\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015J\u001c\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0006\u001a\u00020\u00072\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015¨\u0006\u0019"}, d2 = {"Lcom/uxdepy/xxeubg/core/Overlay;", "", "<init>", "()V", "show", "Landroid/widget/FrameLayout;", "activity", "Landroid/app/Activity;", "eyebrow", "", "title", "stats", "", "Lkotlin/Pair;", "buttons", "Lcom/uxdepy/xxeubg/core/Overlay$Btn;", "dismissible", "", "pauseChip", "Landroid/widget/TextView;", "onClick", "Lkotlin/Function0;", "", "addPauseButton", "Btn", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Overlay {
    public static final Overlay INSTANCE = new Overlay();

    /* compiled from: Overlay.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\t\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010¨\u0006\u0011"}, d2 = {"Lcom/uxdepy/xxeubg/core/Overlay$Btn;", "", "label", "", "primary", "", "onClick", "Lkotlin/Function0;", "", "<init>", "(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)V", "getLabel", "()Ljava/lang/String;", "getPrimary", "()Z", "getOnClick", "()Lkotlin/jvm/functions/Function0;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Btn {
        private final String label;
        private final Function0<Unit> onClick;
        private final boolean primary;

        public Btn(String label, boolean z, Function0<Unit> onClick) {
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(onClick, "onClick");
            this.label = label;
            this.primary = z;
            this.onClick = onClick;
        }

        public /* synthetic */ Btn(String str, boolean z, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, (i & 2) != 0 ? false : z, function0);
        }

        public final String getLabel() {
            return this.label;
        }

        public final Function0<Unit> getOnClick() {
            return this.onClick;
        }

        public final boolean getPrimary() {
            return this.primary;
        }
    }

    private Overlay() {
    }

    public static /* synthetic */ FrameLayout show$default(Overlay overlay, Activity activity, String str, String str2, List list, List list2, boolean z, int i, Object obj) {
        if ((i & 8) != 0) {
            list = CollectionsKt.emptyList();
        }
        List list3 = list;
        if ((i & 32) != 0) {
            z = false;
        }
        return overlay.show(activity, str, str2, list3, list2, z);
    }

    private static final int show$dp(Activity activity, int i) {
        return Ui.INSTANCE.dp(activity, i);
    }

    public final FrameLayout show(Activity activity, String eyebrow, String title, List<Pair<String, String>> stats, List<Btn> buttons, boolean dismissible) {
        int i;
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(eyebrow, "eyebrow");
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(stats, "stats");
        Intrinsics.checkNotNullParameter(buttons, "buttons");
        FrameLayout frameLayout = (FrameLayout) activity.findViewById(R.id.content);
        Activity activity2 = activity;
        final FrameLayout frameLayout2 = new FrameLayout(activity2);
        frameLayout2.setBackgroundColor(-872415232);
        int i2 = 1;
        frameLayout2.setClickable(true);
        LinearLayout linearLayout = new LinearLayout(activity2);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBackground(), show$dp(activity, 28)));
        linearLayout.setPadding(show$dp(activity, 26), show$dp(activity, 30), show$dp(activity, 26), show$dp(activity, 26));
        int i3 = 17;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -2, 17);
        layoutParams.setMarginStart(show$dp(activity, 32));
        layoutParams.setMarginEnd(show$dp(activity, 32));
        linearLayout.setLayoutParams(layoutParams);
        if (eyebrow.length() > 0) {
            TextView textView = new TextView(activity2);
            String upperCase = eyebrow.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            textView.setText(upperCase);
            textView.setTypeface(Ui.INSTANCE.regular(activity2));
            textView.setTextSize(13.0f);
            textView.setLetterSpacing(0.2f);
            textView.setTextColor(Palette.INSTANCE.getAccent());
            textView.setGravity(17);
            linearLayout.addView(textView);
        }
        TextView textView2 = new TextView(activity2);
        String upperCase2 = title.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
        textView2.setText(upperCase2);
        textView2.setTypeface(Ui.INSTANCE.black(activity2));
        textView2.setTextSize(34.0f);
        textView2.setLetterSpacing(0.02f);
        textView2.setTextColor(Palette.INSTANCE.getText());
        textView2.setGravity(17);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = show$dp(activity, 6);
        textView2.setLayoutParams(layoutParams2);
        linearLayout.addView(textView2);
        int i4 = 12;
        int i5 = 0;
        if (stats.isEmpty()) {
            i = 0;
        } else {
            LinearLayout linearLayout2 = new LinearLayout(activity2);
            linearLayout2.setOrientation(0);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.topMargin = show$dp(activity, 20);
            linearLayout2.setLayoutParams(layoutParams3);
            for (Pair<String, String> pair : stats) {
                String component1 = pair.component1();
                String component2 = pair.component2();
                LinearLayout linearLayout3 = new LinearLayout(activity2);
                linearLayout3.setOrientation(i2);
                linearLayout3.setGravity(i3);
                linearLayout3.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), show$dp(activity, 16)));
                linearLayout3.setPadding(show$dp(activity, 10), show$dp(activity, i4), show$dp(activity, 10), show$dp(activity, 14));
                LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams4.setMarginStart(show$dp(activity, 5));
                layoutParams4.setMarginEnd(show$dp(activity, 5));
                linearLayout3.setLayoutParams(layoutParams4);
                TextView textView3 = new TextView(activity2);
                String upperCase3 = component1.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase3, "toUpperCase(...)");
                textView3.setText(upperCase3);
                textView3.setTypeface(Ui.INSTANCE.regular(activity2));
                textView3.setTextSize(11.0f);
                textView3.setLetterSpacing(0.14f);
                textView3.setTextColor(Palette.INSTANCE.getTextDim());
                textView3.setGravity(17);
                linearLayout3.addView(textView3);
                TextView textView4 = new TextView(activity2);
                textView4.setText(component2);
                textView4.setTypeface(Ui.INSTANCE.black(activity2));
                textView4.setTextSize(22.0f);
                textView4.setTextColor(Palette.INSTANCE.getAccent());
                textView4.setGravity(17);
                linearLayout3.addView(textView4);
                linearLayout2.addView(linearLayout3);
                i5 = 0;
                i4 = 12;
                i3 = 17;
                i2 = 1;
            }
            i = i5;
            linearLayout.addView(linearLayout2);
        }
        final Function0 function0 = new Function0() { // from class: com.uxdepy.xxeubg.core.Overlay$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit show$lambda$12;
                show$lambda$12 = Overlay.show$lambda$12(frameLayout2);
                return show$lambda$12;
            }
        };
        int i6 = i;
        for (Object obj : buttons) {
            int i7 = i6 + 1;
            if (i6 < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            final Btn btn = (Btn) obj;
            TextView button = Ui.INSTANCE.button(activity2, btn.getLabel(), btn.getPrimary() ? Palette.INSTANCE.getAccent() : Palette.INSTANCE.getBoardBg(), btn.getPrimary() ? Palette.INSTANCE.getBackground() : Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.core.Overlay$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit show$lambda$16$lambda$13;
                    show$lambda$16$lambda$13 = Overlay.show$lambda$16$lambda$13(Function0.this, btn);
                    return show$lambda$16$lambda$13;
                }
            });
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams5.topMargin = show$dp(activity, i6 == 0 ? 22 : 12);
            button.setLayoutParams(layoutParams5);
            linearLayout.addView(button);
            i6 = i7;
        }
        if (dismissible) {
            frameLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.core.Overlay$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    Function0.this.invoke();
                }
            });
        }
        frameLayout2.addView(linearLayout);
        frameLayout.addView(frameLayout2, new FrameLayout.LayoutParams(-1, -1));
        return frameLayout2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit show$lambda$12(FrameLayout frameLayout) {
        ViewParent parent = frameLayout.getParent();
        ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
        if (viewGroup == null) {
            return null;
        }
        viewGroup.removeView(frameLayout);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit show$lambda$16$lambda$13(Function0 function0, Btn btn) {
        function0.invoke();
        btn.getOnClick().invoke();
        return Unit.INSTANCE;
    }

    public final TextView pauseChip(Activity activity, final Function0<Unit> onClick) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        Activity activity2 = activity;
        TextView textView = new TextView(activity2);
        textView.setText("⏸");
        textView.setTextSize(20.0f);
        textView.setGravity(17);
        textView.setTextColor(Palette.INSTANCE.getText());
        textView.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(activity2, 18)));
        textView.setPadding(Ui.INSTANCE.dp(activity2, 15), 0, Ui.INSTANCE.dp(activity2, 15), 0);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.core.Overlay$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Function0.this.invoke();
            }
        });
        return textView;
    }

    public final void addPauseButton(Activity activity, final Function0<Unit> onClick) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        FrameLayout frameLayout = (FrameLayout) activity.findViewById(R.id.content);
        int identifier = activity.getResources().getIdentifier("status_bar_height", "dimen", "android");
        int dimensionPixelSize = identifier > 0 ? activity.getResources().getDimensionPixelSize(identifier) : Ui.INSTANCE.dp(activity, 24);
        Activity activity2 = activity;
        TextView textView = new TextView(activity2);
        textView.setText("⏸");
        textView.setTextSize(18.0f);
        textView.setGravity(17);
        textView.setTextColor(Palette.INSTANCE.getText());
        textView.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), Ui.INSTANCE.dp(activity2, 20)));
        textView.setPadding(Ui.INSTANCE.dp(activity2, 14), Ui.INSTANCE.dp(activity2, 8), Ui.INSTANCE.dp(activity2, 14), Ui.INSTANCE.dp(activity2, 8));
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.core.Overlay$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Function0.this.invoke();
            }
        });
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 8388661);
        layoutParams.topMargin = dimensionPixelSize + Ui.INSTANCE.dp(activity2, 10);
        layoutParams.setMarginEnd(Ui.INSTANCE.dp(activity2, 14));
        Unit unit = Unit.INSTANCE;
        frameLayout.addView(textView, layoutParams);
    }
}
