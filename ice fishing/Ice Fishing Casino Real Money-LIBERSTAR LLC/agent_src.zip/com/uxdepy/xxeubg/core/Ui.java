package com.uxdepy.xxeubg.core;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.uxdepy.xxeubg.theme.Palette;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;

/* compiled from: Ui.kt */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\r\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u0005J\u0016\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u0013J\u000e\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005J&\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u0005J4\u0010\u0018\u001a\u00020\u00192\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u00052\u0006\u0010\u001d\u001a\u00020\u00052\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001fJ\u0016\u0010!\u001a\u00020\"2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010#\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006$"}, d2 = {"Lcom/uxdepy/xxeubg/core/Ui;", "", "<init>", "()V", "COIN_TEXT_ID", "", "tfBlack", "Landroid/graphics/Typeface;", "tfRegular", "black", "c", "Landroid/content/Context;", "regular", "dp", "v", "rounded", "Landroid/graphics/drawable/GradientDrawable;", "color", "radiusPx", "", "oval", "roundedBordered", "strokeColor", "strokePx", "button", "Landroid/widget/TextView;", "label", "", "bg", "fg", "onClick", "Lkotlin/Function0;", "", "coinPill", "Landroid/widget/LinearLayout;", "coins", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Ui {
    public static final int COIN_TEXT_ID = 192;
    public static final Ui INSTANCE = new Ui();
    private static Typeface tfBlack;
    private static Typeface tfRegular;

    private Ui() {
    }

    public final Typeface black(Context c) {
        Intrinsics.checkNotNullParameter(c, "c");
        Typeface typeface = tfBlack;
        if (typeface != null) {
            return typeface;
        }
        Typeface createFromAsset = Typeface.createFromAsset(c.getAssets(), "fonts/Exo2-Black.ttf");
        tfBlack = createFromAsset;
        Intrinsics.checkNotNullExpressionValue(createFromAsset, "also(...)");
        return createFromAsset;
    }

    public final Typeface regular(Context c) {
        Intrinsics.checkNotNullParameter(c, "c");
        Typeface typeface = tfRegular;
        if (typeface != null) {
            return typeface;
        }
        Typeface createFromAsset = Typeface.createFromAsset(c.getAssets(), "fonts/Exo2-Regular.ttf");
        tfRegular = createFromAsset;
        Intrinsics.checkNotNullExpressionValue(createFromAsset, "also(...)");
        return createFromAsset;
    }

    public final int dp(Context c, int v) {
        Intrinsics.checkNotNullParameter(c, "c");
        return (int) (v * c.getResources().getDisplayMetrics().density);
    }

    public final GradientDrawable rounded(int color, float radiusPx) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(radiusPx);
        gradientDrawable.setColor(color);
        return gradientDrawable;
    }

    public final GradientDrawable oval(int color) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(color);
        return gradientDrawable;
    }

    public final GradientDrawable roundedBordered(int color, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(radiusPx);
        gradientDrawable.setColor(color);
        gradientDrawable.setStroke(strokePx, strokeColor);
        return gradientDrawable;
    }

    public final TextView button(Context c, String label, int bg, int fg, final Function0<Unit> onClick) {
        Intrinsics.checkNotNullParameter(c, "c");
        Intrinsics.checkNotNullParameter(label, "label");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        TextView textView = new TextView(c);
        textView.setText(label);
        Ui ui = INSTANCE;
        textView.setTypeface(ui.black(c));
        textView.setTextSize(18.0f);
        textView.setLetterSpacing(0.06f);
        textView.setGravity(17);
        textView.setTextColor(fg);
        textView.setBackground(ui.rounded(bg, ui.dp(c, 18)));
        textView.setPadding(ui.dp(c, 18), ui.dp(c, 16), ui.dp(c, 18), ui.dp(c, 16));
        textView.setClickable(true);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.uxdepy.xxeubg.core.Ui$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Function0.this.invoke();
            }
        });
        return textView;
    }

    public final LinearLayout coinPill(Context c, int coins) {
        Intrinsics.checkNotNullParameter(c, "c");
        LinearLayout linearLayout = new LinearLayout(c);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        Ui ui = INSTANCE;
        linearLayout.setBackground(ui.rounded(Palette.INSTANCE.getBoardBg(), ui.dp(c, 22)));
        linearLayout.setPadding(ui.dp(c, 14), ui.dp(c, 8), ui.dp(c, 16), ui.dp(c, 8));
        View view = new View(c);
        view.setBackground(ui.oval(-671430));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ui.dp(c, 16), ui.dp(c, 16));
        layoutParams.setMarginEnd(ui.dp(c, 8));
        view.setLayoutParams(layoutParams);
        linearLayout.addView(view);
        TextView textView = new TextView(c);
        textView.setId(COIN_TEXT_ID);
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String format = String.format("%,d", Arrays.copyOf(new Object[]{Integer.valueOf(coins)}, 1));
        Intrinsics.checkNotNullExpressionValue(format, "format(...)");
        textView.setText(format);
        textView.setTypeface(ui.black(c));
        textView.setTextSize(16.0f);
        textView.setTextColor(Palette.INSTANCE.getText());
        linearLayout.addView(textView);
        return linearLayout;
    }
}
