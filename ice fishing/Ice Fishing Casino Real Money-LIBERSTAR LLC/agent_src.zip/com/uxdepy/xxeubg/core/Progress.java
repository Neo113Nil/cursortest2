package com.uxdepy.xxeubg.core;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.core.app.NotificationCompat;
import com.uxdepy.xxeubg.GameOverActivity;
import com.uxdepy.xxeubg.game.Achievement;
import com.uxdepy.xxeubg.game.Stats;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;

/* compiled from: Progress.kt */
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010#\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\n0\u001aJ\u001a\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00100\u001c2\u0006\u0010\u001d\u001a\u00020\nJ\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\n0\u001fJ\u000e\u0010 \u001a\u00020\u00102\u0006\u0010!\u001a\u00020\nJ\u0006\u0010\"\u001a\u00020\nJ\u000e\u0010#\u001a\u00020$2\u0006\u0010!\u001a\u00020\nJ\u0016\u0010%\u001a\u00020\u00102\u0006\u0010!\u001a\u00020\n2\u0006\u0010&\u001a\u00020\nJ\b\u0010)\u001a\u00020*H\u0002J\u0006\u0010+\u001a\u00020\u0010J\u0006\u0010,\u001a\u00020\nJ\u0006\u0010-\u001a\u00020\nJ\u0006\u0010.\u001a\u00020/J\u000e\u00100\u001a\u00020\u00102\u0006\u00101\u001a\u000202J\u000e\u00103\u001a\b\u0012\u0004\u0012\u00020504H\u0002J\u000e\u00106\u001a\u00020\u00102\u0006\u0010!\u001a\u000205J\u000e\u00107\u001a\u00020\n2\u0006\u00101\u001a\u000202R\u0016\u0010\u0006\u001a\n \b*\u0004\u0018\u00010\u00070\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R$\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\n8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR$\u0010\u0011\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u00108F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R$\u0010\u0016\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\n8F@BX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0017\u0010\r\"\u0004\b\u0018\u0010\u000fR\u0011\u0010'\u001a\u00020\n8F¢\u0006\u0006\u001a\u0004\b(\u0010\r¨\u00068"}, d2 = {"Lcom/uxdepy/xxeubg/core/Progress;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "sp", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "v", "", "coins", "getCoins", "()I", "setCoins", "(I)V", "", "sfxOn", "getSfxOn", "()Z", "setSfxOn", "(Z)V", GameOverActivity.EXTRA_BEST, "getBest", "setBest", "leaderboard", "", "recordGame", "Lkotlin/Pair;", GameOverActivity.EXTRA_SCORE, "ownedSkins", "", "owns", "id", "selectedSkin", "selectSkin", "", "buySkin", "price", "gamesPlayed", "getGamesPlayed", "today", "", "canClaimDaily", "dailyStreak", "claimDaily", "stats", "Lcom/uxdepy/xxeubg/game/Stats;", "isAchieved", "a", "Lcom/uxdepy/xxeubg/game/Achievement;", "claimedAch", "", "", "isClaimed", "claimAchievement", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Progress {
    private final SharedPreferences sp;

    public Progress(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.sp = context.getSharedPreferences(NotificationCompat.CATEGORY_PROGRESS, 0);
    }

    public final int getCoins() {
        return this.sp.getInt("coins", 50);
    }

    public final void setCoins(int i) {
        this.sp.edit().putInt("coins", i).apply();
    }

    public final boolean getSfxOn() {
        return this.sp.getBoolean("sfx", true);
    }

    public final void setSfxOn(boolean z) {
        this.sp.edit().putBoolean("sfx", z).apply();
    }

    public final int getBest() {
        return this.sp.getInt(GameOverActivity.EXTRA_BEST, 0);
    }

    private final void setBest(int i) {
        this.sp.edit().putInt(GameOverActivity.EXTRA_BEST, i).apply();
    }

    public final List<Integer> leaderboard() {
        String string = this.sp.getString("scores", "");
        List split$default = StringsKt.split$default((CharSequence) (string != null ? string : ""), new String[]{","}, false, 0, 6, (Object) null);
        ArrayList arrayList = new ArrayList();
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            Integer intOrNull = StringsKt.toIntOrNull((String) it.next());
            if (intOrNull != null) {
                arrayList.add(intOrNull);
            }
        }
        return CollectionsKt.sortedDescending(arrayList);
    }

    public final Pair<Integer, Boolean> recordGame(int score) {
        boolean z = score > getBest();
        int i = score * 3;
        List take = CollectionsKt.take(CollectionsKt.sortedDescending(CollectionsKt.plus((Collection<? extends Integer>) leaderboard(), Integer.valueOf(score))), 10);
        SharedPreferences.Editor edit = this.sp.edit();
        edit.putString("scores", CollectionsKt.joinToString$default(take, ",", null, null, 0, null, null, 62, null));
        if (z) {
            edit.putInt(GameOverActivity.EXTRA_BEST, score);
        }
        edit.putInt("games", getGamesPlayed() + 1);
        edit.putInt("coins", getCoins() + i);
        edit.apply();
        return TuplesKt.to(Integer.valueOf(i), Boolean.valueOf(z));
    }

    public final Set<Integer> ownedSkins() {
        Set<String> stringSet = this.sp.getStringSet("skins", SetsKt.setOf("0"));
        if (stringSet == null) {
            stringSet = SetsKt.setOf("0");
        }
        ArrayList arrayList = new ArrayList();
        for (String str : stringSet) {
            Intrinsics.checkNotNull(str);
            Integer intOrNull = StringsKt.toIntOrNull(str);
            if (intOrNull != null) {
                arrayList.add(intOrNull);
            }
        }
        return CollectionsKt.toSet(arrayList);
    }

    public final boolean owns(int id) {
        return id == 0 || ownedSkins().contains(Integer.valueOf(id));
    }

    public final int selectedSkin() {
        return this.sp.getInt("skin_sel", 0);
    }

    public final void selectSkin(int id) {
        this.sp.edit().putInt("skin_sel", id).apply();
    }

    public final boolean buySkin(int id, int price) {
        if (owns(id)) {
            return true;
        }
        if (getCoins() < price) {
            return false;
        }
        Set<Integer> ownedSkins = ownedSkins();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(ownedSkins, 10));
        Iterator<T> it = ownedSkins.iterator();
        while (it.hasNext()) {
            arrayList.add(String.valueOf(((Number) it.next()).intValue()));
        }
        Set<String> mutableSet = CollectionsKt.toMutableSet(arrayList);
        mutableSet.add(String.valueOf(id));
        this.sp.edit().putStringSet("skins", mutableSet).putInt("coins", getCoins() - price).apply();
        return true;
    }

    public final int getGamesPlayed() {
        return this.sp.getInt("games", 0);
    }

    private final long today() {
        return System.currentTimeMillis() / 86400000;
    }

    public final boolean canClaimDaily() {
        return this.sp.getLong("daily_last", -1L) != today();
    }

    public final int dailyStreak() {
        return this.sp.getInt("daily_streak", 0);
    }

    public final int claimDaily() {
        if (!canClaimDaily()) {
            return 0;
        }
        long j = today();
        int dailyStreak = this.sp.getLong("daily_last", -1L) == j - 1 ? 1 + dailyStreak() : 1;
        int coerceAtMost = RangesKt.coerceAtMost(((dailyStreak - 1) * 10) + 20, 100);
        this.sp.edit().putLong("daily_last", j).putInt("daily_streak", dailyStreak).putInt("coins", getCoins() + coerceAtMost).apply();
        return coerceAtMost;
    }

    public final Stats stats() {
        return new Stats(getGamesPlayed(), getBest(), ownedSkins().size());
    }

    public final boolean isAchieved(Achievement a) {
        Intrinsics.checkNotNullParameter(a, "a");
        return a.getTest().invoke(stats()).booleanValue();
    }

    private final Set<String> claimedAch() {
        Set<String> stringSet = this.sp.getStringSet("ach_claimed", SetsKt.emptySet());
        if (stringSet == null) {
            stringSet = SetsKt.emptySet();
        }
        return CollectionsKt.toMutableSet(stringSet);
    }

    public final boolean isClaimed(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return claimedAch().contains(id);
    }

    public final int claimAchievement(Achievement a) {
        Intrinsics.checkNotNullParameter(a, "a");
        if (!isAchieved(a) || isClaimed(a.getId())) {
            return 0;
        }
        Set<String> claimedAch = claimedAch();
        claimedAch.add(a.getId());
        this.sp.edit().putStringSet("ach_claimed", claimedAch).putInt("coins", getCoins() + a.getReward()).apply();
        return a.getReward();
    }
}
