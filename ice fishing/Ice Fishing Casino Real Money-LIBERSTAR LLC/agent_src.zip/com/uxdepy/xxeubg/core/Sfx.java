package com.uxdepy.xxeubg.core;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import com.uxdepy.xxeubg.R;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: Sfx.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u000bJ\u001a\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u00072\b\b\u0002\u0010\u0014\u001a\u00020\u0015H\u0002J\u0006\u0010\u0006\u001a\u00020\rJ\u000e\u0010\u0016\u001a\u00020\r2\u0006\u0010\u0017\u001a\u00020\u0007J\u0006\u0010\u0018\u001a\u00020\rR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0019"}, d2 = {"Lcom/uxdepy/xxeubg/core/Sfx;", "", "<init>", "()V", "pool", "Landroid/media/SoundPool;", "place", "", "solved", "over", "enabled", "", "init", "", "ctx", "Landroid/content/Context;", "setEnabled", "e", "sound", "id", "rate", "", "perfect", "n", "gameOver", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Sfx {
    public static final Sfx INSTANCE = new Sfx();
    private static boolean enabled = true;
    private static int over;
    private static int place;
    private static SoundPool pool;
    private static int solved;

    private Sfx() {
    }

    public final void init(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        if (pool != null) {
            return;
        }
        SoundPool build = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build()).build();
        place = build.load(ctx, R.raw.sfx_swap, 1);
        solved = build.load(ctx, R.raw.sfx_match, 1);
        over = build.load(ctx, R.raw.sfx_lose, 1);
        pool = build;
    }

    public final void setEnabled(boolean e) {
        enabled = e;
    }

    static /* synthetic */ void sound$default(Sfx sfx, int i, float f, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            f = 1.0f;
        }
        sfx.sound(i, f);
    }

    private final void sound(int id, float rate) {
        SoundPool soundPool;
        if (!enabled || id == 0 || (soundPool = pool) == null) {
            return;
        }
        soundPool.play(id, 1.0f, 1.0f, 1, 0, rate);
    }

    public final void place() {
        sound$default(this, place, 0.0f, 2, null);
    }

    public final void perfect(int n) {
        sound(solved, RangesKt.coerceAtMost(((n - 1) * 0.08f) + 1.0f, 1.6f));
    }

    public final void gameOver() {
        sound$default(this, over, 0.0f, 2, null);
    }
}
