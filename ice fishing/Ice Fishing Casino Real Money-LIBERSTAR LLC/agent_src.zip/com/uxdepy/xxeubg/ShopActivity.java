package com.uxdepy.xxeubg;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.uxdepy.xxeubg.core.Progress;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.theme.Palette;
import com.uxdepy.xxeubg.theme.Skin;
import com.uxdepy.xxeubg.theme.Skins;
import java.util.Iterator;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ShopActivity.kt */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0014J\b\u0010\n\u001a\u00020\u0007H\u0002J \u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005H\u0002J \u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u0005H\u0002J\u0010\u0010\u0018\u001a\u00020\f2\u0006\u0010\u0019\u001a\u00020\u0005H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082D¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/uxdepy/xxeubg/ShopActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "gold", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "buildUi", "skinCard", "Landroid/view/View;", NotificationCompat.CATEGORY_PROGRESS, "Lcom/uxdepy/xxeubg/core/Progress;", "skin", "Lcom/uxdepy/xxeubg/theme/Skin;", "selected", "badge", "Landroid/widget/TextView;", "text", "", "bg", "fg", "pricePill", "price", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class ShopActivity extends AppCompatActivity {
    private final int gold = -671430;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private final void buildUi() {
        ShopActivity shopActivity = this;
        Progress progress = new Progress(shopActivity);
        Skins.INSTANCE.apply(progress.selectedSkin());
        int selectedSkin = progress.selectedSkin();
        LinearLayout linearLayout = new LinearLayout(shopActivity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout.setPadding(Ui.INSTANCE.dp(shopActivity, 20), Ui.INSTANCE.dp(shopActivity, 24), Ui.INSTANCE.dp(shopActivity, 20), Ui.INSTANCE.dp(shopActivity, 20));
        LinearLayout linearLayout2 = new LinearLayout(shopActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        TextView textView = new TextView(shopActivity);
        textView.setText("SHOP");
        textView.setTypeface(Ui.INSTANCE.black(shopActivity));
        textView.setTextSize(28.0f);
        textView.setLetterSpacing(0.06f);
        textView.setTextColor(Palette.INSTANCE.getText());
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView);
        linearLayout2.addView(Ui.INSTANCE.coinPill(shopActivity, progress.getCoins()));
        linearLayout.addView(linearLayout2);
        TextView textView2 = new TextView(shopActivity);
        textView2.setText("LIQUID SKINS");
        textView2.setTypeface(Ui.INSTANCE.regular(shopActivity));
        textView2.setTextSize(12.0f);
        textView2.setLetterSpacing(0.22f);
        textView2.setTextColor(Palette.INSTANCE.getTextDim());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(shopActivity, 16);
        textView2.setLayoutParams(layoutParams);
        linearLayout.addView(textView2);
        LinearLayout linearLayout3 = new LinearLayout(shopActivity);
        linearLayout3.setOrientation(1);
        Iterator<Skin> it = Skins.INSTANCE.getAll().iterator();
        while (it.hasNext()) {
            linearLayout3.addView(skinCard(progress, it.next(), selectedSkin));
        }
        ScrollView scrollView = new ScrollView(shopActivity);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        scrollView.addView(linearLayout3);
        scrollView.setVerticalScrollBarEnabled(false);
        linearLayout.addView(scrollView);
        TextView button = Ui.INSTANCE.button(shopActivity, "BACK", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.ShopActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit buildUi$lambda$7;
                buildUi$lambda$7 = ShopActivity.buildUi$lambda$7(ShopActivity.this);
                return buildUi$lambda$7;
            }
        });
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = Ui.INSTANCE.dp(shopActivity, 12);
        button.setLayoutParams(layoutParams2);
        linearLayout.addView(button);
        setContentView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit buildUi$lambda$7(ShopActivity shopActivity) {
        shopActivity.finish();
        return Unit.INSTANCE;
    }

    private final View skinCard(final Progress progress, final Skin skin, int selected) {
        GradientDrawable rounded;
        final boolean owns = progress.owns(skin.getId());
        boolean z = skin.getId() == selected;
        ShopActivity shopActivity = this;
        float dp = Ui.INSTANCE.dp(shopActivity, 20);
        LinearLayout linearLayout = new LinearLayout(shopActivity);
        linearLayout.setOrientation(1);
        if (z) {
            rounded = Ui.INSTANCE.roundedBordered(Palette.INSTANCE.getBoardBg(), dp, Palette.INSTANCE.getAccent(), Ui.INSTANCE.dp(shopActivity, 2));
        } else {
            rounded = Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), dp);
        }
        linearLayout.setBackground(rounded);
        linearLayout.setPadding(Ui.INSTANCE.dp(shopActivity, 16), Ui.INSTANCE.dp(shopActivity, 16), Ui.INSTANCE.dp(shopActivity, 16), Ui.INSTANCE.dp(shopActivity, 16));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(shopActivity, 14);
        linearLayout.setLayoutParams(layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(shopActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        TextView textView = new TextView(shopActivity);
        String upperCase = skin.getName().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView.setText(upperCase);
        textView.setTypeface(Ui.INSTANCE.black(shopActivity));
        textView.setTextSize(19.0f);
        textView.setTextColor(Palette.INSTANCE.getText());
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView);
        if (z) {
            linearLayout2.addView(badge("ACTIVE", Palette.INSTANCE.getAccent(), Palette.INSTANCE.getBackground()));
        } else if (!owns) {
            linearLayout2.addView(pricePill(skin.getPrice()));
        }
        linearLayout.addView(linearLayout2);
        LinearLayout linearLayout3 = new LinearLayout(shopActivity);
        linearLayout3.setOrientation(0);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = Ui.INSTANCE.dp(shopActivity, 14);
        linearLayout3.setLayoutParams(layoutParams2);
        int[] colors = skin.getColors();
        int length = colors.length;
        for (int i = 0; i < length; i++) {
            int i2 = colors[i];
            View view = new View(shopActivity);
            view.setBackground(Ui.INSTANCE.rounded(i2, Ui.INSTANCE.dp(shopActivity, 12)));
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, Ui.INSTANCE.dp(shopActivity, 46), 1.0f);
            if (i > 0) {
                layoutParams3.setMarginStart(Ui.INSTANCE.dp(shopActivity, 8));
            }
            Unit unit = Unit.INSTANCE;
            linearLayout3.addView(view, layoutParams3);
        }
        linearLayout.addView(linearLayout3);
        if (!z) {
            TextView button = Ui.INSTANCE.button(shopActivity, owns ? "USE" : "BUY", Palette.INSTANCE.getAccent(), Palette.INSTANCE.getBackground(), new Function0() { // from class: com.uxdepy.xxeubg.ShopActivity$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit skinCard$lambda$18;
                    skinCard$lambda$18 = ShopActivity.skinCard$lambda$18(owns, progress, skin, this);
                    return skinCard$lambda$18;
                }
            });
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams4.topMargin = Ui.INSTANCE.dp(shopActivity, 14);
            button.setLayoutParams(layoutParams4);
            linearLayout.addView(button);
        }
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit skinCard$lambda$18(boolean z, Progress progress, Skin skin, ShopActivity shopActivity) {
        if (z) {
            progress.selectSkin(skin.getId());
            shopActivity.recreate();
        } else if (progress.buySkin(skin.getId(), skin.getPrice())) {
            progress.selectSkin(skin.getId());
            shopActivity.recreate();
        } else {
            Toast.makeText(shopActivity, "Not enough coins", 0).show();
        }
        return Unit.INSTANCE;
    }

    private final TextView badge(String text, int bg, int fg) {
        ShopActivity shopActivity = this;
        TextView textView = new TextView(shopActivity);
        textView.setText(text);
        textView.setTypeface(Ui.INSTANCE.black(shopActivity));
        textView.setTextSize(12.0f);
        textView.setLetterSpacing(0.08f);
        textView.setTextColor(fg);
        textView.setBackground(Ui.INSTANCE.rounded(bg, Ui.INSTANCE.dp(shopActivity, 14)));
        textView.setPadding(Ui.INSTANCE.dp(shopActivity, 12), Ui.INSTANCE.dp(shopActivity, 6), Ui.INSTANCE.dp(shopActivity, 12), Ui.INSTANCE.dp(shopActivity, 6));
        return textView;
    }

    private final View pricePill(int price) {
        ShopActivity shopActivity = this;
        LinearLayout linearLayout = new LinearLayout(shopActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setBackground(Ui.INSTANCE.rounded(Palette.INSTANCE.getBackground(), Ui.INSTANCE.dp(shopActivity, 14)));
        linearLayout.setPadding(Ui.INSTANCE.dp(shopActivity, 12), Ui.INSTANCE.dp(shopActivity, 6), Ui.INSTANCE.dp(shopActivity, 12), Ui.INSTANCE.dp(shopActivity, 6));
        View view = new View(shopActivity);
        view.setBackground(Ui.INSTANCE.oval(this.gold));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(Ui.INSTANCE.dp(shopActivity, 14), Ui.INSTANCE.dp(shopActivity, 14));
        layoutParams.setMarginEnd(Ui.INSTANCE.dp(shopActivity, 6));
        view.setLayoutParams(layoutParams);
        linearLayout.addView(view);
        TextView textView = new TextView(shopActivity);
        textView.setText(String.valueOf(price));
        textView.setTypeface(Ui.INSTANCE.black(shopActivity));
        textView.setTextSize(14.0f);
        textView.setTextColor(Palette.INSTANCE.getText());
        linearLayout.addView(textView);
        return linearLayout;
    }
}
