package com.uxdepy.xxeubg;

/* loaded from: classes.dex */
public final class R {

    public static final class color {
        public static int bg = 0x7f050021;
        public static int ic_launcher_background = 0x7f050036;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher = 0x7f07005d;
        public static int loading_bg = 0x7f07005e;

        private drawable() {
        }
    }

    public static final class id {
        public static int xxeubgBackButton = 0x7f0800b4;
        public static int xxeubgLoadingIndicator = 0x7f0800b5;
        public static int xxeubgWebView = 0x7f0800b6;

        private id() {
        }
    }

    public static final class layout {
        public static int fragment_decision_gate = 0x7f0b001d;
        public static int fragment_remote_content = 0x7f0b001e;

        private layout() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f0c0000;
        public static int ic_launcher_foreground = 0x7f0c0001;
        public static int ic_launcher_round = 0x7f0c0002;

        private mipmap() {
        }
    }

    public static final class raw {
        public static int sfx_invalid = 0x7f0d0000;
        public static int sfx_lose = 0x7f0d0001;
        public static int sfx_match = 0x7f0d0002;
        public static int sfx_swap = 0x7f0d0003;
        public static int sfx_win = 0x7f0d0004;

        private raw() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0e001c;
        public static int launcher_label = 0x7f0e0024;

        private string() {
        }
    }

    public static final class style {
        public static int AppTheme = 0x7f0f0005;

        private style() {
        }
    }

    private R() {
    }
}
