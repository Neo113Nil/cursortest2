package com.uxdepy.xxeubg.theme;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Skins.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\n\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"Lcom/uxdepy/xxeubg/theme/Skin;", "", "id", "", "name", "", "price", "colors", "", "<init>", "(ILjava/lang/String;I[I)V", "getId", "()I", "getName", "()Ljava/lang/String;", "getPrice", "getColors", "()[I", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Skin {
    private final int[] colors;
    private final int id;
    private final String name;
    private final int price;

    public Skin(int i, String name, int i2, int[] colors) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(colors, "colors");
        this.id = i;
        this.name = name;
        this.price = i2;
        this.colors = colors;
    }

    public final int[] getColors() {
        return this.colors;
    }

    public final int getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final int getPrice() {
        return this.price;
    }
}
