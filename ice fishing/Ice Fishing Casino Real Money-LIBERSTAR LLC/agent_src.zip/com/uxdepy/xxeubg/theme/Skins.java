package com.uxdepy.xxeubg.theme;

import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* compiled from: Skins.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\u000bR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000e"}, d2 = {"Lcom/uxdepy/xxeubg/theme/Skins;", "", "<init>", "()V", "all", "", "Lcom/uxdepy/xxeubg/theme/Skin;", "getAll", "()Ljava/util/List;", "get", "id", "", "apply", "", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Skins {
    public static final Skins INSTANCE = new Skins();
    private static final List<Skin> all = CollectionsKt.listOf((Object[]) new Skin[]{new Skin(0, "Orchid", 0, new int[]{-1745454, -1745555, -1723555, -5118627, -10623633, -10623531, -10645531, -7250459}), new Skin(1, "Gold", 150, new int[]{-1717923, -6625955, -10623611, -10625307, -10651419, -5808667, -1745476, -1743779}), new Skin(2, "Jade", 250, new int[]{-10623588, -10631195, -10657307, -4301339, -1745499, -1738147, -1712035, -8133283}), new Skin(3, "Indigo", 400, new int[]{-9478683, -2794011, -1745521, -1732259, -2955939, -9575075, -10623565, -10636827})});

    private Skins() {
    }

    public final List<Skin> getAll() {
        return all;
    }

    public final Skin get(int id) {
        Object obj;
        Iterator<T> it = all.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (((Skin) obj).getId() == id) {
                break;
            }
        }
        Skin skin = (Skin) obj;
        return skin == null ? all.get(0) : skin;
    }

    public final void apply(int id) {
        Palette.INSTANCE.setLiquids(get(id).getColors());
    }
}
