package com.uxdepy.xxeubg.theme;

import android.graphics.Color;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Palette.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u0015\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0007R\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0007R\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015¨\u0006\u0016"}, d2 = {"Lcom/uxdepy/xxeubg/theme/Palette;", "", "<init>", "()V", "background", "", "getBackground", "()I", "boardBg", "getBoardBg", "text", "getText", "textDim", "getTextDim", "accent", "getAccent", "liquids", "", "getLiquids", "()[I", "setLiquids", "([I)V", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Palette {
    public static final Palette INSTANCE = new Palette();
    private static final int background = Color.parseColor("#4F1748");
    private static final int boardBg = Color.parseColor("#6F2064");
    private static final int text = Color.parseColor("#F8F6F8");
    private static final int textDim = Color.parseColor("#E4CDE1");
    private static final int accent = Color.parseColor("#F471E2");
    private static int[] liquids = {Color.parseColor("#FF5A5A"), Color.parseColor("#FF9F45"), Color.parseColor("#FFD34E"), Color.parseColor("#5BD97C"), Color.parseColor("#37D3D3"), Color.parseColor("#4C8CFF"), Color.parseColor("#A87CFF"), Color.parseColor("#FF6FC7")};

    private Palette() {
    }

    public final int getBackground() {
        return background;
    }

    public final int getBoardBg() {
        return boardBg;
    }

    public final int getText() {
        return text;
    }

    public final int getTextDim() {
        return textDim;
    }

    public final int getAccent() {
        return accent;
    }

    public final int[] getLiquids() {
        return liquids;
    }

    public final void setLiquids(int[] iArr) {
        Intrinsics.checkNotNullParameter(iArr, "<set-?>");
        liquids = iArr;
    }
}
