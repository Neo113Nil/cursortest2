package com.uxdepy.xxeubg;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.uxdepy.xxeubg.core.Progress;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.theme.Palette;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* compiled from: LeaderboardActivity.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014J \u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000eH\u0002¨\u0006\u0010"}, d2 = {"Lcom/uxdepy/xxeubg/LeaderboardActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "row", "Landroid/widget/LinearLayout;", "rank", "", GameOverActivity.EXTRA_SCORE, "highlight", "", "Companion", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class LeaderboardActivity extends AppCompatActivity {
    public static final String EXTRA_LATEST = "latest";

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LeaderboardActivity leaderboardActivity = this;
        Progress progress = new Progress(leaderboardActivity);
        int intExtra = getIntent().getIntExtra(EXTRA_LATEST, -1);
        List<Integer> leaderboard = progress.leaderboard();
        LinearLayout linearLayout = new LinearLayout(leaderboardActivity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout.setPadding(Ui.INSTANCE.dp(leaderboardActivity, 20), Ui.INSTANCE.dp(leaderboardActivity, 24), Ui.INSTANCE.dp(leaderboardActivity, 20), Ui.INSTANCE.dp(leaderboardActivity, 20));
        TextView textView = new TextView(leaderboardActivity);
        textView.setText("LEADERBOARD");
        textView.setTypeface(Ui.INSTANCE.black(leaderboardActivity));
        textView.setTextSize(28.0f);
        textView.setLetterSpacing(0.06f);
        textView.setTextColor(Palette.INSTANCE.getText());
        linearLayout.addView(textView);
        TextView textView2 = new TextView(leaderboardActivity);
        textView2.setText("YOUR BEST RUNS");
        textView2.setTypeface(Ui.INSTANCE.regular(leaderboardActivity));
        textView2.setTextSize(12.0f);
        textView2.setLetterSpacing(0.22f);
        textView2.setTextColor(Palette.INSTANCE.getTextDim());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(leaderboardActivity, 6);
        textView2.setLayoutParams(layoutParams);
        linearLayout.addView(textView2);
        LinearLayout linearLayout2 = new LinearLayout(leaderboardActivity);
        linearLayout2.setOrientation(1);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = Ui.INSTANCE.dp(leaderboardActivity, 16);
        linearLayout2.setLayoutParams(layoutParams2);
        if (leaderboard.isEmpty()) {
            TextView textView3 = new TextView(leaderboardActivity);
            textView3.setText("No runs yet — play to set a score!");
            textView3.setTypeface(Ui.INSTANCE.regular(leaderboardActivity));
            textView3.setTextSize(15.0f);
            textView3.setTextColor(Palette.INSTANCE.getTextDim());
            textView3.setGravity(17);
            textView3.setPadding(0, Ui.INSTANCE.dp(leaderboardActivity, 40), 0, 0);
            linearLayout2.addView(textView3);
        } else {
            Iterator<T> it = leaderboard.iterator();
            int i = 0;
            boolean z = false;
            while (it.hasNext()) {
                i++;
                int intValue = ((Number) it.next()).intValue();
                boolean z2 = !z && intValue == intExtra;
                if (z2) {
                    z = true;
                }
                linearLayout2.addView(row(i, intValue, z2));
            }
        }
        ScrollView scrollView = new ScrollView(leaderboardActivity);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        scrollView.addView(linearLayout2);
        scrollView.setVerticalScrollBarEnabled(false);
        linearLayout.addView(scrollView);
        TextView button = Ui.INSTANCE.button(leaderboardActivity, "BACK", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.LeaderboardActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCreate$lambda$8;
                onCreate$lambda$8 = LeaderboardActivity.onCreate$lambda$8(LeaderboardActivity.this);
                return onCreate$lambda$8;
            }
        });
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = Ui.INSTANCE.dp(leaderboardActivity, 12);
        button.setLayoutParams(layoutParams3);
        linearLayout.addView(button);
        setContentView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCreate$lambda$8(LeaderboardActivity leaderboardActivity) {
        leaderboardActivity.finish();
        return Unit.INSTANCE;
    }

    private final LinearLayout row(int rank, int score, boolean highlight) {
        GradientDrawable rounded;
        String str;
        LeaderboardActivity leaderboardActivity = this;
        float dp = Ui.INSTANCE.dp(leaderboardActivity, 16);
        LinearLayout linearLayout = new LinearLayout(leaderboardActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        if (highlight) {
            rounded = Ui.INSTANCE.roundedBordered(Palette.INSTANCE.getBoardBg(), dp, Palette.INSTANCE.getAccent(), Ui.INSTANCE.dp(leaderboardActivity, 2));
        } else {
            rounded = Ui.INSTANCE.rounded(Palette.INSTANCE.getBoardBg(), dp);
        }
        linearLayout.setBackground(rounded);
        linearLayout.setPadding(Ui.INSTANCE.dp(leaderboardActivity, 18), Ui.INSTANCE.dp(leaderboardActivity, 14), Ui.INSTANCE.dp(leaderboardActivity, 18), Ui.INSTANCE.dp(leaderboardActivity, 14));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(leaderboardActivity, 10);
        linearLayout.setLayoutParams(layoutParams);
        if (rank == 1) {
            str = "🥇";
        } else if (rank != 2) {
            str = rank != 3 ? "#" + rank : "🥉";
        } else {
            str = "🥈";
        }
        TextView textView = new TextView(leaderboardActivity);
        textView.setText(str);
        textView.setTypeface(Ui.INSTANCE.black(leaderboardActivity));
        textView.setTextSize(18.0f);
        textView.setTextColor(rank <= 3 ? Palette.INSTANCE.getText() : Palette.INSTANCE.getTextDim());
        textView.setLayoutParams(new LinearLayout.LayoutParams(Ui.INSTANCE.dp(leaderboardActivity, 44), -2));
        linearLayout.addView(textView);
        TextView textView2 = new TextView(leaderboardActivity);
        textView2.setText(highlight ? score + "  •  NEW" : String.valueOf(score));
        textView2.setTypeface(Ui.INSTANCE.black(leaderboardActivity));
        textView2.setTextSize(20.0f);
        Palette palette = Palette.INSTANCE;
        textView2.setTextColor(highlight ? palette.getAccent() : palette.getText());
        textView2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(leaderboardActivity);
        textView3.setText("LEVELS");
        textView3.setTypeface(Ui.INSTANCE.regular(leaderboardActivity));
        textView3.setTextSize(11.0f);
        textView3.setLetterSpacing(0.16f);
        textView3.setTextColor(Palette.INSTANCE.getTextDim());
        linearLayout.addView(textView3);
        return linearLayout;
    }
}
