package com.uxdepy.xxeubg.game;

import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Achievements.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/uxdepy/xxeubg/game/Achievements;", "", "<init>", "()V", "all", "", "Lcom/uxdepy/xxeubg/game/Achievement;", "getAll", "()Ljava/util/List;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Achievements {
    public static final Achievements INSTANCE = new Achievements();
    private static final List<Achievement> all = CollectionsKt.listOf((Object[]) new Achievement[]{new Achievement("play1", "First Pour", "Play your first game", 20, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$0;
            all$lambda$0 = Achievements.all$lambda$0((Stats) obj);
            return Boolean.valueOf(all$lambda$0);
        }
    }), new Achievement("s5", "Sorted", "Solve 5 levels in a run", 40, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$1;
            all$lambda$1 = Achievements.all$lambda$1((Stats) obj);
            return Boolean.valueOf(all$lambda$1);
        }
    }), new Achievement("s15", "Colour Wizard", "Solve 15 levels in a run", 60, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$2;
            all$lambda$2 = Achievements.all$lambda$2((Stats) obj);
            return Boolean.valueOf(all$lambda$2);
        }
    }), new Achievement("s30", "Master Sorter", "Solve 30 levels in a run", 100, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$3;
            all$lambda$3 = Achievements.all$lambda$3((Stats) obj);
            return Boolean.valueOf(all$lambda$3);
        }
    }), new Achievement("skins2", "Stylist", "Own 2 liquid skins", 50, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$4;
            all$lambda$4 = Achievements.all$lambda$4((Stats) obj);
            return Boolean.valueOf(all$lambda$4);
        }
    }), new Achievement("games10", "Regular", "Play 10 games", 40, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$5;
            all$lambda$5 = Achievements.all$lambda$5((Stats) obj);
            return Boolean.valueOf(all$lambda$5);
        }
    }), new Achievement("games50", "Devoted", "Play 50 games", 80, new Function1() { // from class: com.uxdepy.xxeubg.game.Achievements$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            boolean all$lambda$6;
            all$lambda$6 = Achievements.all$lambda$6((Stats) obj);
            return Boolean.valueOf(all$lambda$6);
        }
    })});

    private Achievements() {
    }

    public final List<Achievement> getAll() {
        return all;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$0(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getGamesPlayed() >= 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$1(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getBestScore() >= 5;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$2(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getBestScore() >= 15;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$3(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getBestScore() >= 30;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$4(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getSkinsOwned() >= 2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$5(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getGamesPlayed() >= 10;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean all$lambda$6(Stats it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getGamesPlayed() >= 50;
    }
}
