package com.uxdepy.xxeubg.game;

import kotlin.Metadata;

/* compiled from: Achievements.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\t\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\f"}, d2 = {"Lcom/uxdepy/xxeubg/game/Stats;", "", "gamesPlayed", "", "bestScore", "skinsOwned", "<init>", "(III)V", "getGamesPlayed", "()I", "getBestScore", "getSkinsOwned", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Stats {
    private final int bestScore;
    private final int gamesPlayed;
    private final int skinsOwned;

    public Stats(int i, int i2, int i3) {
        this.gamesPlayed = i;
        this.bestScore = i2;
        this.skinsOwned = i3;
    }

    public final int getGamesPlayed() {
        return this.gamesPlayed;
    }

    public final int getBestScore() {
        return this.bestScore;
    }

    public final int getSkinsOwned() {
        return this.skinsOwned;
    }
}
