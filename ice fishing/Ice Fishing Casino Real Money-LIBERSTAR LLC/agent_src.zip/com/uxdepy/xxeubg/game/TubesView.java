package com.uxdepy.xxeubg.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.uxdepy.xxeubg.core.Sfx;
import com.uxdepy.xxeubg.theme.Palette;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: TubesView.kt */
@Metadata(d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001:\u0001GB\u001d\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0016\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020\u00112\u0006\u0010-\u001a\u00020\u0011J(\u0010.\u001a\u00020+2\u0006\u0010/\u001a\u00020\u00112\u0006\u00100\u001a\u00020\u00112\u0006\u00101\u001a\u00020\u00112\u0006\u00102\u001a\u00020\u0011H\u0014J\u0018\u00103\u001a\u00020+2\u0006\u0010/\u001a\u00020\u00112\u0006\u00100\u001a\u00020\u0011H\u0002J\u0010\u00104\u001a\u00020\u00112\u0006\u00105\u001a\u00020\u0011H\u0002J\u0010\u00106\u001a\u00020+2\u0006\u00107\u001a\u000208H\u0014J\u0018\u00109\u001a\u00020+2\u0006\u00107\u001a\u0002082\u0006\u0010:\u001a\u00020\u0011H\u0002J\u0018\u0010;\u001a\u00020\u00112\u0006\u0010<\u001a\u00020\u00112\u0006\u0010=\u001a\u00020\u001bH\u0002J\u0010\u0010>\u001a\u00020\u00152\u0006\u0010?\u001a\u00020@H\u0016J\u0018\u0010A\u001a\u00020\u00112\u0006\u0010B\u001a\u00020\u001b2\u0006\u0010C\u001a\u00020\u001bH\u0002J\u0018\u0010D\u001a\u00020+2\u0006\u0010E\u001a\u00020\u00112\u0006\u0010F\u001a\u00020\u0011H\u0002R\u001c\u0010\b\u001a\u0004\u0018\u00010\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0016\u001a\u0012\u0012\u0004\u0012\u00020\u00180\u0017j\b\u0012\u0004\u0012\u00020\u0018`\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020%X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006H"}, d2 = {"Lcom/uxdepy/xxeubg/game/TubesView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "listener", "Lcom/uxdepy/xxeubg/game/TubesView$Listener;", "getListener", "()Lcom/uxdepy/xxeubg/game/TubesView$Listener;", "setListener", "(Lcom/uxdepy/xxeubg/game/TubesView$Listener;)V", "model", "Lcom/uxdepy/xxeubg/game/Tubes;", "moveLimit", "", "movesUsed", "selected", "done", "", "rects", "Ljava/util/ArrayList;", "Landroid/graphics/RectF;", "Lkotlin/collections/ArrayList;", "tubeW", "", "tubeH", "segH", "capSeg", "animDst", "animCount", "animT", "lastNs", "", "fill", "Landroid/graphics/Paint;", "stroke", "clip", "Landroid/graphics/Path;", "tmp", "start", "", "numColors", "limit", "onSizeChanged", "w", "h", "ow", "oh", "layout", "liquid", "ci", "onDraw", "canvas", "Landroid/graphics/Canvas;", "drawTube", "t", "darken", "c", "f", "onTouchEvent", "ev", "Landroid/view/MotionEvent;", "tubeAt", "x", "y", "doPour", "from", "to", "Listener", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class TubesView extends View {
    private int animCount;
    private int animDst;
    private float animT;
    private float capSeg;
    private final Path clip;
    private boolean done;
    private final Paint fill;
    private long lastNs;
    private Listener listener;
    private final Tubes model;
    private int moveLimit;
    private int movesUsed;
    private final ArrayList<RectF> rects;
    private float segH;
    private int selected;
    private final Paint stroke;
    private final RectF tmp;
    private float tubeH;
    private float tubeW;

    /* compiled from: TubesView.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H&J\b\u0010\u0007\u001a\u00020\u0003H&J\b\u0010\b\u001a\u00020\u0003H&¨\u0006\t"}, d2 = {"Lcom/uxdepy/xxeubg/game/TubesView$Listener;", "", "onMove", "", "used", "", "limit", "onSolved", "onGameOver", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public interface Listener {
        void onGameOver();

        void onMove(int used, int limit);

        void onSolved();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public TubesView(Context context) {
        this(context, null, 2, 0 == true ? 1 : 0);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    private final int darken(int c, float f) {
        return ((int) ((c & 255) * f)) | (-16777216) | (((int) (((c >> 16) & 255) * f)) << 16) | (((int) (((c >> 8) & 255) * f)) << 8);
    }

    public /* synthetic */ TubesView(Context context, AttributeSet attributeSet, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i & 2) != 0 ? null : attributeSet);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TubesView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Intrinsics.checkNotNullParameter(context, "context");
        this.model = new Tubes(0L, 1, null);
        this.selected = -1;
        this.rects = new ArrayList<>();
        this.animDst = -1;
        this.fill = new Paint(1);
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.stroke = paint;
        this.clip = new Path();
        this.tmp = new RectF();
    }

    public final Listener getListener() {
        return this.listener;
    }

    public final void setListener(Listener listener) {
        this.listener = listener;
    }

    public final void start(int numColors, int limit) {
        Tubes.generate$default(this.model, numColors, 0, 2, null);
        this.moveLimit = limit;
        this.movesUsed = 0;
        this.selected = -1;
        this.done = false;
        this.animDst = -1;
        this.animT = 0.0f;
        this.lastNs = 0L;
        if (getWidth() > 0 && getHeight() > 0) {
            layout(getWidth(), getHeight());
        }
        Listener listener = this.listener;
        if (listener != null) {
            listener.onMove(0, limit);
        }
        invalidate();
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        layout(w, h);
    }

    private final void layout(int w, int h) {
        int tubeCount = this.model.getTubeCount();
        if (tubeCount == 0) {
            return;
        }
        int i = tubeCount <= 5 ? 1 : 2;
        float f = i;
        int ceil = (int) Math.ceil(tubeCount / f);
        float f2 = w;
        float f3 = h;
        float min = Math.min(((0.86f * f2) / ceil) * 0.66f, ((0.8f * f3) / f) * 0.3f);
        this.tubeW = min;
        float f4 = 2.9f * min;
        this.tubeH = f4;
        float f5 = min * 0.5f;
        this.capSeg = f5;
        this.segH = (f4 - f5) / this.model.getCapacity();
        float f6 = this.tubeW * 1.55f;
        float f7 = this.tubeH;
        float f8 = 0.34f * f7;
        int i2 = i - 1;
        float f9 = (f3 - ((f * f7) + (i2 * f8))) / 2.0f;
        this.rects.clear();
        for (int i3 = 0; i3 < tubeCount; i3++) {
            this.rects.add(new RectF());
        }
        for (int i4 = 0; i4 < tubeCount; i4++) {
            int i5 = i4 / ceil;
            float f10 = ((f2 - ((((i5 < i2 ? ceil : tubeCount - (ceil * i2)) - 1) * f6) + this.tubeW)) / 2.0f) + ((i4 % ceil) * f6);
            float f11 = (i5 * (this.tubeH + f8)) + f9;
            this.rects.get(i4).set(f10, f11, this.tubeW + f10, this.tubeH + f11);
        }
    }

    private final int liquid(int ci) {
        return Palette.INSTANCE.getLiquids()[ci % Palette.INSTANCE.getLiquids().length];
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        if (this.rects.size() != this.model.getTubeCount()) {
            if (getWidth() <= 0) {
                return;
            } else {
                layout(getWidth(), getHeight());
            }
        }
        long nanoTime = System.nanoTime();
        float coerceAtMost = this.lastNs == 0 ? 0.0f : RangesKt.coerceAtMost((nanoTime - r2) / 1.0E9f, 0.05f);
        this.lastNs = nanoTime;
        float f = this.animT;
        if (f > 0.0f) {
            this.animT = f - (coerceAtMost * 5.5f);
        }
        int tubeCount = this.model.getTubeCount();
        while (true) {
            tubeCount--;
            if (-1 >= tubeCount) {
                break;
            } else {
                drawTube(canvas, tubeCount);
            }
        }
        if (this.animT > 0.0f) {
            postInvalidateOnAnimation();
        } else {
            this.animDst = -1;
            this.lastNs = 0L;
        }
    }

    private final void drawTube(Canvas canvas, int t) {
        RectF rectF = this.rects.get(t);
        Intrinsics.checkNotNullExpressionValue(rectF, "get(...)");
        RectF rectF2 = rectF;
        float f = t == this.selected ? (-this.tubeH) * 0.12f : 0.0f;
        this.tmp.set(rectF2.left, rectF2.top + f, rectF2.right, rectF2.bottom + f);
        float f2 = this.tubeW * 0.42f;
        canvas.save();
        this.clip.reset();
        this.clip.addRoundRect(this.tmp, f2, f2, Path.Direction.CW);
        canvas.clipPath(this.clip);
        this.fill.setColor(darken(Palette.INSTANCE.getBoardBg(), 0.7f));
        canvas.drawRect(this.tmp, this.fill);
        ArrayList<Integer> arrayList = this.model.getTubes().get(t);
        Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
        ArrayList<Integer> arrayList2 = arrayList;
        int size = arrayList2.size();
        for (int i = 0; i < size; i++) {
            float f3 = this.tmp.bottom;
            float f4 = this.segH;
            float f5 = f3 - (i * f4);
            float f6 = f5 - f4;
            if (t == this.animDst && i >= arrayList2.size() - this.animCount) {
                float coerceIn = RangesKt.coerceIn(this.animT, 0.0f, 1.0f) * this.tubeH * 0.7f;
                f5 -= coerceIn;
                f6 -= coerceIn;
            }
            float f7 = f5;
            Paint paint = this.fill;
            Integer num = arrayList2.get(i);
            Intrinsics.checkNotNullExpressionValue(num, "get(...)");
            paint.setColor(liquid(num.intValue()));
            canvas.drawRect(this.tmp.left, f6, this.tmp.right, f7, this.fill);
        }
        canvas.restore();
        this.stroke.setColor(t == this.selected ? Palette.INSTANCE.getAccent() : darken(Palette.INSTANCE.getTextDim(), 0.9f));
        this.stroke.setStrokeWidth(this.tubeW * (t == this.selected ? 0.08f : 0.05f));
        canvas.drawRoundRect(this.tmp, f2, f2, this.stroke);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent ev) {
        Intrinsics.checkNotNullParameter(ev, "ev");
        if (this.done || this.animT > 0.0f || ev.getAction() != 0) {
            return true;
        }
        int tubeAt = tubeAt(ev.getX(), ev.getY());
        if (tubeAt < 0) {
            this.selected = -1;
            invalidate();
            return true;
        }
        int i = this.selected;
        if (i < 0) {
            ArrayList<Integer> arrayList = this.model.getTubes().get(tubeAt);
            Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
            if (!arrayList.isEmpty()) {
                this.selected = tubeAt;
            }
        } else if (tubeAt == i) {
            this.selected = -1;
        } else if (this.model.canPour(i, tubeAt)) {
            doPour(this.selected, tubeAt);
            this.selected = -1;
        } else {
            ArrayList<Integer> arrayList2 = this.model.getTubes().get(tubeAt);
            Intrinsics.checkNotNullExpressionValue(arrayList2, "get(...)");
            if (arrayList2.isEmpty()) {
                tubeAt = -1;
            }
            this.selected = tubeAt;
        }
        invalidate();
        return true;
    }

    private final int tubeAt(float x, float y) {
        int size = this.rects.size();
        for (int i = 0; i < size; i++) {
            RectF rectF = this.rects.get(i);
            Intrinsics.checkNotNullExpressionValue(rectF, "get(...)");
            RectF rectF2 = rectF;
            if (x >= rectF2.left - (this.tubeW * 0.2f) && x <= rectF2.right + (this.tubeW * 0.2f) && y >= rectF2.top - (this.tubeH * 0.2f) && y <= rectF2.bottom + (this.tubeH * 0.15f)) {
                return i;
            }
        }
        return -1;
    }

    private final void doPour(int from, int to) {
        int pour = this.model.pour(from, to);
        if (pour <= 0) {
            return;
        }
        this.animDst = to;
        this.animCount = pour;
        this.animT = 1.0f;
        this.movesUsed++;
        Sfx.INSTANCE.place();
        Listener listener = this.listener;
        if (listener != null) {
            listener.onMove(this.movesUsed, this.moveLimit);
        }
        if (this.model.isSolved()) {
            this.done = true;
            Sfx.INSTANCE.perfect(1);
            Listener listener2 = this.listener;
            if (listener2 != null) {
                listener2.onSolved();
            }
        } else if (this.movesUsed >= this.moveLimit) {
            this.done = true;
            Sfx.INSTANCE.gameOver();
            Listener listener3 = this.listener;
            if (listener3 != null) {
                listener3.onGameOver();
            }
        }
        invalidate();
    }
}
