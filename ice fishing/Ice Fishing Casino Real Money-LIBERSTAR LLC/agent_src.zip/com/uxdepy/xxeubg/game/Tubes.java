package com.uxdepy.xxeubg.game;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Tubes.kt */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00072\b\b\u0002\u0010\u0019\u001a\u00020\u0007J\u000e\u0010\u001a\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0007J\u000e\u0010\u001c\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0007J\u0016\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u0007J\u0016\u0010!\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u0007J\u0006\u0010\"\u001a\u00020\u001eJ\b\u0010#\u001a\u00020$H\u0002J\b\u0010&\u001a\u00020\u001eH\u0002J \u0010'\u001a\u00020\u001e2\u0016\u0010(\u001a\u0012\u0012\u0004\u0012\u00020$0)j\b\u0012\u0004\u0012\u00020$`*H\u0002R\u0014\u0010\u0006\u001a\u00020\u0007X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001e\u0010\u000b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\tRA\u0010\r\u001a2\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u00020\u00070\u000ej\b\u0012\u0004\u0012\u00020\u0007`\u000f0\u000ej\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u00020\u00070\u000ej\b\u0012\u0004\u0012\u00020\u0007`\u000f`\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0014\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\tR\u000e\u0010%\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006+"}, d2 = {"Lcom/uxdepy/xxeubg/game/Tubes;", "", "seed", "", "<init>", "(J)V", "capacity", "", "getCapacity", "()I", "value", "colors", "getColors", "tubes", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "getTubes", "()Ljava/util/ArrayList;", "rng", "Ljava/util/Random;", "tubeCount", "getTubeCount", "generate", "", "numColors", "emptyTubes", "topColor", "t", "topRun", "canPour", "", "from", "to", "pour", "isSolved", "key", "", "nodes", "isSolvable", "dfs", "visited", "Ljava/util/HashSet;", "Lkotlin/collections/HashSet;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Tubes {
    private final int capacity;
    private int colors;
    private int nodes;
    private final Random rng;
    private final ArrayList<ArrayList<Integer>> tubes;

    public Tubes() {
        this(0L, 1, null);
    }

    public Tubes(long j) {
        this.capacity = 4;
        this.tubes = new ArrayList<>();
        this.rng = new Random(j);
    }

    public /* synthetic */ Tubes(long j, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? System.nanoTime() : j);
    }

    public final int getCapacity() {
        return this.capacity;
    }

    public final int getColors() {
        return this.colors;
    }

    public final ArrayList<ArrayList<Integer>> getTubes() {
        return this.tubes;
    }

    public final int getTubeCount() {
        return this.tubes.size();
    }

    public static /* synthetic */ void generate$default(Tubes tubes, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 2;
        }
        tubes.generate(i, i2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void generate(int numColors, int emptyTubes) {
        this.colors = numColors;
        int i = 0;
        do {
            i++;
            ArrayList arrayList = new ArrayList();
            for (int i2 = 0; i2 < numColors; i2++) {
                int i3 = this.capacity;
                for (int i4 = 0; i4 < i3; i4++) {
                    arrayList.add(Integer.valueOf(i2));
                }
            }
            Collections.shuffle(arrayList, this.rng);
            this.tubes.clear();
            int i5 = 0;
            for (int i6 = 0; i6 < numColors; i6++) {
                ArrayList arrayList2 = new ArrayList(this.capacity);
                int i7 = this.capacity;
                int i8 = 0;
                while (i8 < i7) {
                    arrayList2.add(arrayList.get(i5));
                    i8++;
                    i5++;
                }
                this.tubes.add(arrayList2);
            }
            for (int i9 = 0; i9 < emptyTubes; i9++) {
                this.tubes.add(new ArrayList<>(this.capacity));
            }
            if (isSolvable()) {
                return;
            }
        } while (i <= 80);
    }

    public final int topColor(int t) {
        ArrayList<Integer> arrayList = this.tubes.get(t);
        Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
        Integer num = (Integer) CollectionsKt.lastOrNull((List) arrayList);
        if (num != null) {
            return num.intValue();
        }
        return -1;
    }

    public final int topRun(int t) {
        ArrayList<Integer> arrayList = this.tubes.get(t);
        Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
        ArrayList<Integer> arrayList2 = arrayList;
        int i = 0;
        if (arrayList2.isEmpty()) {
            return 0;
        }
        int intValue = ((Number) CollectionsKt.last((List) arrayList2)).intValue();
        for (int size = arrayList2.size() - 1; size >= 0; size--) {
            Integer num = arrayList2.get(size);
            if (num == null || num.intValue() != intValue) {
                break;
            }
            i++;
        }
        return i;
    }

    public final boolean canPour(int from, int to) {
        if (from == to) {
            return false;
        }
        ArrayList<Integer> arrayList = this.tubes.get(from);
        Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
        ArrayList<Integer> arrayList2 = arrayList;
        ArrayList<Integer> arrayList3 = this.tubes.get(to);
        Intrinsics.checkNotNullExpressionValue(arrayList3, "get(...)");
        ArrayList<Integer> arrayList4 = arrayList3;
        if (!arrayList2.isEmpty() && arrayList4.size() < this.capacity) {
            if (arrayList4.isEmpty()) {
                return (arrayList2.size() == this.capacity && topRun(from) == this.capacity) ? false : true;
            }
            if (((Number) CollectionsKt.last((List) arrayList4)).intValue() == ((Number) CollectionsKt.last((List) arrayList2)).intValue()) {
                return true;
            }
        }
        return false;
    }

    public final int pour(int from, int to) {
        if (!canPour(from, to)) {
            return 0;
        }
        ArrayList<Integer> arrayList = this.tubes.get(from);
        Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
        ArrayList<Integer> arrayList2 = arrayList;
        ArrayList<Integer> arrayList3 = this.tubes.get(to);
        Intrinsics.checkNotNullExpressionValue(arrayList3, "get(...)");
        ArrayList<Integer> arrayList4 = arrayList3;
        int intValue = ((Number) CollectionsKt.last((List) arrayList2)).intValue();
        int min = Math.min(topRun(from), this.capacity - arrayList4.size());
        for (int i = 0; i < min; i++) {
            arrayList2.remove(arrayList2.size() - 1);
            arrayList4.add(Integer.valueOf(intValue));
        }
        return min;
    }

    public final boolean isSolved() {
        ArrayList<ArrayList<Integer>> arrayList = this.tubes;
        if ((arrayList instanceof Collection) && arrayList.isEmpty()) {
            return true;
        }
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            ArrayList arrayList2 = (ArrayList) it.next();
            if (!arrayList2.isEmpty()) {
                if (arrayList2.size() == this.capacity) {
                    ArrayList arrayList3 = arrayList2;
                    if (!(arrayList3 instanceof Collection) || !arrayList3.isEmpty()) {
                        Iterator it2 = arrayList3.iterator();
                        while (it2.hasNext()) {
                            int intValue = ((Number) it2.next()).intValue();
                            Integer num = (Integer) arrayList2.get(0);
                            if (num != null && intValue == num.intValue()) {
                            }
                        }
                    }
                }
                return false;
            }
        }
        return true;
    }

    private final String key() {
        ArrayList<ArrayList<Integer>> arrayList = this.tubes;
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(CollectionsKt.joinToString$default((ArrayList) it.next(), ",", null, null, 0, null, null, 62, null));
        }
        return CollectionsKt.joinToString$default(CollectionsKt.sorted(arrayList2), "|", null, null, 0, null, null, 62, null);
    }

    private final boolean isSolvable() {
        this.nodes = 0;
        return dfs(new HashSet<>());
    }

    private final boolean dfs(HashSet<String> visited) {
        if (isSolved()) {
            return true;
        }
        int i = this.nodes + 1;
        this.nodes = i;
        if (i > 40000 || !visited.add(key())) {
            return false;
        }
        int size = this.tubes.size();
        for (int i2 = 0; i2 < size; i2++) {
            int size2 = this.tubes.size();
            for (int i3 = 0; i3 < size2; i3++) {
                if (canPour(i2, i3)) {
                    ArrayList<Integer> arrayList = this.tubes.get(i2);
                    Intrinsics.checkNotNullExpressionValue(arrayList, "get(...)");
                    int intValue = ((Number) CollectionsKt.last((List) arrayList)).intValue();
                    int pour = pour(i2, i3);
                    if (pour > 0) {
                        boolean dfs = dfs(visited);
                        for (int i4 = 0; i4 < pour; i4++) {
                            this.tubes.get(i3).remove(this.tubes.get(i3).size() - 1);
                            this.tubes.get(i2).add(Integer.valueOf(intValue));
                        }
                        if (dfs) {
                            return true;
                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        return false;
    }
}
