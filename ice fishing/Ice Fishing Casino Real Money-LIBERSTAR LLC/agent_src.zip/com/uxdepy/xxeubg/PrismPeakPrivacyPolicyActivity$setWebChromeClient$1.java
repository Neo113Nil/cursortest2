package com.uxdepy.xxeubg;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;

/* compiled from: PrismPeakPrivacyPolicyActivity.kt */
@Metadata(d1 = {"\u0000G\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J,\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u00072\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0017J\u001c\u0010\u000e\u001a\u00020\u000f2\b\u0010\b\u001a\u0004\u0018\u00010\u00032\b\u0010\u0010\u001a\u0004\u0018\u00010\u0005H\u0016J\b\u0010\u0011\u001a\u00020\u000fH\u0016J2\u0010\u0012\u001a\u00020\u00072\b\u0010\u0013\u001a\u0004\u0018\u00010\t2\u0014\u0010\u0014\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00170\u0016\u0018\u00010\u00152\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019H\u0016R\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"com/uxdepy/xxeubg/PrismPeakPrivacyPolicyActivity$setWebChromeClient$1", "Landroid/webkit/WebChromeClient;", "customView", "Landroid/view/View;", "fullScreenCallback", "Landroid/webkit/WebChromeClient$CustomViewCallback;", "onCreateWindow", "", "view", "Landroid/webkit/WebView;", "isDialog", "isUserGesture", "resultMsg", "Landroid/os/Message;", "onShowCustomView", "", "callback", "onHideCustomView", "onShowFileChooser", "webView", "filePathCallback", "Landroid/webkit/ValueCallback;", "", "Landroid/net/Uri;", "fileChooserParams", "Landroid/webkit/WebChromeClient$FileChooserParams;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PrismPeakPrivacyPolicyActivity$setWebChromeClient$1 extends WebChromeClient {
    final /* synthetic */ PrismPeakPrivacyPolicyActivity $activity;
    final /* synthetic */ ActivityResultLauncher<Intent> $activityResultLauncher;
    final /* synthetic */ Ref.ObjectRef<ValueCallback<Uri[]>> $uploadMessage;
    private View customView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;

    PrismPeakPrivacyPolicyActivity$setWebChromeClient$1(PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity, Ref.ObjectRef<ValueCallback<Uri[]>> objectRef, ActivityResultLauncher<Intent> activityResultLauncher) {
        this.$activity = prismPeakPrivacyPolicyActivity;
        this.$uploadMessage = objectRef;
        this.$activityResultLauncher = activityResultLauncher;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
        if (view == null) {
            return false;
        }
        Context context = view.getContext();
        final WebView webView = new WebView(context);
        final PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity = this.$activity;
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        WebSettings settings = webView.getSettings();
        String userAgentString = webView.getSettings().getUserAgentString();
        Intrinsics.checkNotNullExpressionValue(userAgentString, "getUserAgentString(...)");
        settings.setUserAgentString(StringsKt.replace$default(userAgentString, "; wv", "", false, 4, (Object) null));
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$setWebChromeClient$1$onCreateWindow$newWebView$1$1
            @Override // android.webkit.WebChromeClient
            public void onCloseWindow(WebView window) {
                View decorView = PrismPeakPrivacyPolicyActivity.this.getWindow().getDecorView();
                FrameLayout frameLayout = decorView instanceof FrameLayout ? (FrameLayout) decorView : null;
                if (frameLayout != null) {
                    ViewParent parent = window != null ? window.getParent() : null;
                    frameLayout.removeView(parent instanceof View ? (View) parent : null);
                }
            }
        });
        View decorView = this.$activity.getWindow().getDecorView();
        Intrinsics.checkNotNull(decorView, "null cannot be cast to non-null type android.widget.FrameLayout");
        WindowCompat.setDecorFitsSystemWindows(this.$activity.getWindow(), false);
        FrameLayout frameLayout = new FrameLayout(context);
        PrismPeakPrivacyPolicyActivity prismPeakPrivacyPolicyActivity2 = this.$activity;
        frameLayout.setBackgroundColor(0);
        frameLayout.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout2 = frameLayout;
        ViewCompat.setOnApplyWindowInsetsListener(frameLayout2, new OnApplyWindowInsetsListener() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$setWebChromeClient$1$$ExternalSyntheticLambda0
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            public final WindowInsetsCompat onApplyWindowInsets(View view2, WindowInsetsCompat windowInsetsCompat) {
                WindowInsetsCompat onCreateWindow$lambda$2$lambda$1;
                onCreateWindow$lambda$2$lambda$1 = PrismPeakPrivacyPolicyActivity$setWebChromeClient$1.onCreateWindow$lambda$2$lambda$1(view2, windowInsetsCompat);
                return onCreateWindow$lambda$2$lambda$1;
            }
        });
        prismPeakPrivacyPolicyActivity2.getOnBackPressedDispatcher().addCallback(prismPeakPrivacyPolicyActivity2, new OnBackPressedCallback() { // from class: com.uxdepy.xxeubg.PrismPeakPrivacyPolicyActivity$setWebChromeClient$1$onCreateWindow$webViewContainer$1$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(true);
            }

            @Override // androidx.activity.OnBackPressedCallback
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                setEnabled(false);
                ViewParent parent = webView.getParent();
                ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
                if (viewGroup != null) {
                    viewGroup.removeView(webView);
                }
            }
        });
        ((FrameLayout) decorView).addView(frameLayout2, new FrameLayout.LayoutParams(-1, -1));
        ViewCompat.requestApplyInsets(frameLayout2);
        Object obj = resultMsg != null ? resultMsg.obj : null;
        WebView.WebViewTransport webViewTransport = obj instanceof WebView.WebViewTransport ? (WebView.WebViewTransport) obj : null;
        if (webViewTransport != null) {
            webViewTransport.setWebView(webView);
        }
        if (resultMsg != null) {
            resultMsg.sendToTarget();
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final WindowInsetsCompat onCreateWindow$lambda$2$lambda$1(View v, WindowInsetsCompat insets) {
        Intrinsics.checkNotNullParameter(v, "v");
        Intrinsics.checkNotNullParameter(insets, "insets");
        int i = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
        Insets insets2 = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        v.setPadding(0, insets2.top, 0, Math.max(i, insets2.bottom));
        return insets;
    }

    @Override // android.webkit.WebChromeClient
    public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if (this.customView != null) {
            if (callback != null) {
                callback.onCustomViewHidden();
            }
        } else {
            this.customView = view;
            this.fullScreenCallback = callback;
            View decorView = this.$activity.getWindow().getDecorView();
            Intrinsics.checkNotNull(decorView, "null cannot be cast to non-null type android.widget.FrameLayout");
            ((FrameLayout) decorView).addView(this.customView, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    @Override // android.webkit.WebChromeClient
    public void onHideCustomView() {
        View decorView = this.$activity.getWindow().getDecorView();
        Intrinsics.checkNotNull(decorView, "null cannot be cast to non-null type android.widget.FrameLayout");
        ((FrameLayout) decorView).removeView(this.customView);
        this.customView = null;
        WebChromeClient.CustomViewCallback customViewCallback = this.fullScreenCallback;
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.webkit.WebChromeClient
    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        ValueCallback<Uri[]> valueCallback = this.$uploadMessage.element;
        if (valueCallback != null) {
            valueCallback.onReceiveValue(null);
        }
        this.$uploadMessage.element = filePathCallback;
        ActivityResultLauncher<Intent> activityResultLauncher = this.$activityResultLauncher;
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        intent.addCategory("android.intent.category.OPENABLE");
        Intent createChooser = Intent.createChooser(intent, "Select a file");
        Intrinsics.checkNotNullExpressionValue(createChooser, "createChooser(...)");
        activityResultLauncher.launch(createChooser);
        return true;
    }
}
