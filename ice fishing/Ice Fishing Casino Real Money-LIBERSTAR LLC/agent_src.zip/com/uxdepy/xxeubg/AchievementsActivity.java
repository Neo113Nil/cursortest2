package com.uxdepy.xxeubg;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.uxdepy.xxeubg.core.Progress;
import com.uxdepy.xxeubg.core.Ui;
import com.uxdepy.xxeubg.game.Achievement;
import com.uxdepy.xxeubg.game.Achievements;
import com.uxdepy.xxeubg.theme.Palette;
import com.uxdepy.xxeubg.theme.Skins;
import java.util.Iterator;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: AchievementsActivity.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014J\b\u0010\b\u001a\u00020\u0005H\u0002J\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002¨\u0006\u000f"}, d2 = {"Lcom/uxdepy/xxeubg/AchievementsActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "buildUi", "card", "Landroid/view/View;", NotificationCompat.CATEGORY_PROGRESS, "Lcom/uxdepy/xxeubg/core/Progress;", "a", "Lcom/uxdepy/xxeubg/game/Achievement;", "app_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class AchievementsActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private final void buildUi() {
        AchievementsActivity achievementsActivity = this;
        Progress progress = new Progress(achievementsActivity);
        Skins.INSTANCE.apply(progress.selectedSkin());
        LinearLayout linearLayout = new LinearLayout(achievementsActivity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Palette.INSTANCE.getBackground());
        linearLayout.setPadding(Ui.INSTANCE.dp(achievementsActivity, 20), Ui.INSTANCE.dp(achievementsActivity, 24), Ui.INSTANCE.dp(achievementsActivity, 20), Ui.INSTANCE.dp(achievementsActivity, 20));
        LinearLayout linearLayout2 = new LinearLayout(achievementsActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        TextView textView = new TextView(achievementsActivity);
        textView.setText("ACHIEVEMENTS");
        textView.setTypeface(Ui.INSTANCE.black(achievementsActivity));
        textView.setTextSize(24.0f);
        textView.setLetterSpacing(0.04f);
        textView.setTextColor(Palette.INSTANCE.getText());
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView);
        linearLayout2.addView(Ui.INSTANCE.coinPill(achievementsActivity, progress.getCoins()));
        linearLayout.addView(linearLayout2);
        LinearLayout linearLayout3 = new LinearLayout(achievementsActivity);
        linearLayout3.setOrientation(1);
        Iterator<Achievement> it = Achievements.INSTANCE.getAll().iterator();
        while (it.hasNext()) {
            linearLayout3.addView(card(progress, it.next()));
        }
        ScrollView scrollView = new ScrollView(achievementsActivity);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        scrollView.addView(linearLayout3);
        scrollView.setVerticalScrollBarEnabled(false);
        linearLayout.addView(scrollView);
        TextView button = Ui.INSTANCE.button(achievementsActivity, "BACK", Palette.INSTANCE.getBoardBg(), Palette.INSTANCE.getText(), new Function0() { // from class: com.uxdepy.xxeubg.AchievementsActivity$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit buildUi$lambda$5;
                buildUi$lambda$5 = AchievementsActivity.buildUi$lambda$5(AchievementsActivity.this);
                return buildUi$lambda$5;
            }
        });
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(achievementsActivity, 12);
        button.setLayoutParams(layoutParams);
        linearLayout.addView(button);
        setContentView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit buildUi$lambda$5(AchievementsActivity achievementsActivity) {
        achievementsActivity.finish();
        return Unit.INSTANCE;
    }

    private final View card(final Progress progress, final Achievement a) {
        GradientDrawable rounded;
        TextView textView;
        boolean isAchieved = progress.isAchieved(a);
        boolean isClaimed = progress.isClaimed(a.getId());
        AchievementsActivity achievementsActivity = this;
        float dp = Ui.INSTANCE.dp(achievementsActivity, 18);
        LinearLayout linearLayout = new LinearLayout(achievementsActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        if (isAchieved && !isClaimed) {
            rounded = Ui.INSTANCE.roundedBordered(Palette.INSTANCE.getBoardBg(), dp, Palette.INSTANCE.getAccent(), Ui.INSTANCE.dp(achievementsActivity, 2));
        } else {
            rounded = Ui.INSTANCE.rounded(isAchieved ? Palette.INSTANCE.getBoardBg() : -15002832, dp);
        }
        linearLayout.setBackground(rounded);
        linearLayout.setPadding(Ui.INSTANCE.dp(achievementsActivity, 16), Ui.INSTANCE.dp(achievementsActivity, 14), Ui.INSTANCE.dp(achievementsActivity, 16), Ui.INSTANCE.dp(achievementsActivity, 14));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.INSTANCE.dp(achievementsActivity, 12);
        linearLayout.setLayoutParams(layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(achievementsActivity);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(achievementsActivity);
        String str = isAchieved ? "" : "🔒  ";
        String upperCase = a.getTitle().toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        textView2.setText(str + upperCase);
        textView2.setTypeface(Ui.INSTANCE.black(achievementsActivity));
        textView2.setTextSize(16.0f);
        Palette palette = Palette.INSTANCE;
        textView2.setTextColor(isAchieved ? palette.getText() : palette.getTextDim());
        linearLayout2.addView(textView2);
        TextView textView3 = new TextView(achievementsActivity);
        textView3.setText(a.getDesc());
        textView3.setTypeface(Ui.INSTANCE.regular(achievementsActivity));
        textView3.setTextSize(12.0f);
        textView3.setTextColor(Palette.INSTANCE.getTextDim());
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = Ui.INSTANCE.dp(achievementsActivity, 3);
        textView3.setLayoutParams(layoutParams2);
        linearLayout2.addView(textView3);
        linearLayout.addView(linearLayout2);
        if (isClaimed) {
            TextView textView4 = new TextView(achievementsActivity);
            textView4.setText("✓");
            textView4.setTypeface(Ui.INSTANCE.black(achievementsActivity));
            textView4.setTextSize(20.0f);
            textView4.setTextColor(Palette.INSTANCE.getAccent());
            textView = textView4;
        } else if (isAchieved) {
            textView = Ui.INSTANCE.button(achievementsActivity, "+" + a.getReward(), Palette.INSTANCE.getAccent(), Palette.INSTANCE.getBackground(), new Function0() { // from class: com.uxdepy.xxeubg.AchievementsActivity$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit card$lambda$15;
                    card$lambda$15 = AchievementsActivity.card$lambda$15(Progress.this, a, this);
                    return card$lambda$15;
                }
            });
        } else {
            TextView textView5 = new TextView(achievementsActivity);
            textView5.setText("+" + a.getReward());
            textView5.setTypeface(Ui.INSTANCE.black(achievementsActivity));
            textView5.setTextSize(14.0f);
            textView5.setTextColor(Palette.INSTANCE.getTextDim());
            textView = textView5;
        }
        linearLayout.addView(textView);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit card$lambda$15(Progress progress, Achievement achievement, AchievementsActivity achievementsActivity) {
        if (progress.claimAchievement(achievement) > 0) {
            achievementsActivity.recreate();
        }
        return Unit.INSTANCE;
    }
}
