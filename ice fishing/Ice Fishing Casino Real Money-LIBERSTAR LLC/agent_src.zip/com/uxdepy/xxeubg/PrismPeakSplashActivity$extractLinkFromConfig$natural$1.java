package com.uxdepy.xxeubg;

import com.joom.paranoid.Deobfuscator$app$Release;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PrismPeakSplashActivity.kt */
@Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
/* synthetic */ class PrismPeakSplashActivity$extractLinkFromConfig$natural$1 extends FunctionReferenceImpl implements Function2<String, String, Integer> {
    PrismPeakSplashActivity$extractLinkFromConfig$natural$1(Object obj) {
        super(2, obj, PrismPeakSplashActivity.class, Deobfuscator$app$Release.getString(-8812418572784647667L), Deobfuscator$app$Release.getString(-8812418637209157107L), 0);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Integer invoke(String str, String str2) {
        int naturalCompare;
        Intrinsics.checkNotNullParameter(str, Deobfuscator$app$Release.getString(-8812418869137391091L));
        Intrinsics.checkNotNullParameter(str2, Deobfuscator$app$Release.getString(-8812418882022292979L));
        naturalCompare = ((PrismPeakSplashActivity) this.receiver).naturalCompare(str, str2);
        return Integer.valueOf(naturalCompare);
    }
}
