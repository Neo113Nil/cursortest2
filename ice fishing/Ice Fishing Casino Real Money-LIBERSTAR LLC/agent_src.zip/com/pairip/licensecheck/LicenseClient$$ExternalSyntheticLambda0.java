package com.pairip.licensecheck;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class LicenseClient$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ LicenseClient f$0;

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.unbindFromLicensingService();
    }
}
