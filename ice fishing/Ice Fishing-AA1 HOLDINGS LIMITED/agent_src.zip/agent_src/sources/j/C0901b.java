package j;

import java.util.Iterator;

/* renamed from: j.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0901b extends AbstractC0904e implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public C0902c f7792a;

    /* renamed from: b, reason: collision with root package name */
    public C0902c f7793b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f7794c;

    public C0901b(C0902c c0902c, C0902c c0902c2, int i2) {
        this.f7794c = i2;
        this.f7792a = c0902c2;
        this.f7793b = c0902c;
    }

    @Override // j.AbstractC0904e
    public final void a(C0902c c0902c) {
        C0902c c0902c2;
        C0902c c0902c3 = null;
        if (this.f7792a == c0902c && c0902c == this.f7793b) {
            this.f7793b = null;
            this.f7792a = null;
        }
        C0902c c0902c4 = this.f7792a;
        if (c0902c4 == c0902c) {
            switch (this.f7794c) {
                case 0:
                    c0902c2 = c0902c4.f7798d;
                    break;
                default:
                    c0902c2 = c0902c4.f7797c;
                    break;
            }
            this.f7792a = c0902c2;
        }
        C0902c c0902c5 = this.f7793b;
        if (c0902c5 == c0902c) {
            C0902c c0902c6 = this.f7792a;
            if (c0902c5 != c0902c6 && c0902c6 != null) {
                c0902c3 = b(c0902c5);
            }
            this.f7793b = c0902c3;
        }
    }

    public final C0902c b(C0902c c0902c) {
        switch (this.f7794c) {
            case 0:
                return c0902c.f7797c;
            default:
                return c0902c.f7798d;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f7793b != null;
    }

    @Override // java.util.Iterator
    public final Object next() {
        C0902c c0902c = this.f7793b;
        C0902c c0902c2 = this.f7792a;
        this.f7793b = (c0902c == c0902c2 || c0902c2 == null) ? null : b(c0902c);
        return c0902c;
    }
}
