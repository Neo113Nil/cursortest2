package j;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: j.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0905f implements Iterable {

    /* renamed from: a, reason: collision with root package name */
    public C0902c f7802a;

    /* renamed from: b, reason: collision with root package name */
    public C0902c f7803b;

    /* renamed from: c, reason: collision with root package name */
    public final WeakHashMap f7804c = new WeakHashMap();

    /* renamed from: d, reason: collision with root package name */
    public int f7805d = 0;

    public C0902c a(Object obj) {
        C0902c c0902c = this.f7802a;
        while (c0902c != null && !c0902c.f7795a.equals(obj)) {
            c0902c = c0902c.f7797c;
        }
        return c0902c;
    }

    public Object b(Object obj) {
        C0902c a2 = a(obj);
        if (a2 == null) {
            return null;
        }
        this.f7805d--;
        WeakHashMap weakHashMap = this.f7804c;
        if (!weakHashMap.isEmpty()) {
            Iterator it = weakHashMap.keySet().iterator();
            while (it.hasNext()) {
                ((AbstractC0904e) it.next()).a(a2);
            }
        }
        C0902c c0902c = a2.f7798d;
        if (c0902c != null) {
            c0902c.f7797c = a2.f7797c;
        } else {
            this.f7802a = a2.f7797c;
        }
        C0902c c0902c2 = a2.f7797c;
        if (c0902c2 != null) {
            c0902c2.f7798d = c0902c;
        } else {
            this.f7803b = c0902c;
        }
        a2.f7797c = null;
        a2.f7798d = null;
        return a2.f7796b;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0048, code lost:
    
        if (r3.hasNext() != false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0050, code lost:
    
        if (((j.C0901b) r7).hasNext() != false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:?, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0054, code lost:
    
        return false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0905f)) {
            return false;
        }
        C0905f c0905f = (C0905f) obj;
        if (this.f7805d != c0905f.f7805d) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = c0905f.iterator();
        while (true) {
            C0901b c0901b = (C0901b) it;
            if (!c0901b.hasNext()) {
                break;
            }
            C0901b c0901b2 = (C0901b) it2;
            if (!c0901b2.hasNext()) {
                break;
            }
            Map.Entry entry = (Map.Entry) c0901b.next();
            Object next = c0901b2.next();
            if ((entry != null || next == null) && (entry == null || entry.equals(next))) {
            }
        }
        return false;
    }

    public final int hashCode() {
        Iterator it = iterator();
        int i2 = 0;
        while (true) {
            C0901b c0901b = (C0901b) it;
            if (!c0901b.hasNext()) {
                return i2;
            }
            i2 += ((Map.Entry) c0901b.next()).hashCode();
        }
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        C0901b c0901b = new C0901b(this.f7802a, this.f7803b, 0);
        this.f7804c.put(c0901b, Boolean.FALSE);
        return c0901b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("[");
        Iterator it = iterator();
        while (true) {
            C0901b c0901b = (C0901b) it;
            if (!c0901b.hasNext()) {
                sb.append("]");
                return sb.toString();
            }
            sb.append(((Map.Entry) c0901b.next()).toString());
            if (c0901b.hasNext()) {
                sb.append(", ");
            }
        }
    }
}
