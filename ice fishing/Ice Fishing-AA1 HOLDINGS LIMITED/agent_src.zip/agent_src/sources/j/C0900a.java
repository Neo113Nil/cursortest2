package j;

import java.util.HashMap;

/* renamed from: j.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0900a extends C0905f {

    /* renamed from: e, reason: collision with root package name */
    public final HashMap f7791e = new HashMap();

    @Override // j.C0905f
    public final C0902c a(Object obj) {
        return (C0902c) this.f7791e.get(obj);
    }

    @Override // j.C0905f
    public final Object b(Object obj) {
        Object b2 = super.b(obj);
        this.f7791e.remove(obj);
        return b2;
    }
}
