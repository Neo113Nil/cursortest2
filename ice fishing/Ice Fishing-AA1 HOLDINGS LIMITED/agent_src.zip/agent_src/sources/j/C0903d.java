package j;

import java.util.Iterator;

/* renamed from: j.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0903d extends AbstractC0904e implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public C0902c f7799a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f7800b = true;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0905f f7801c;

    public C0903d(C0905f c0905f) {
        this.f7801c = c0905f;
    }

    @Override // j.AbstractC0904e
    public final void a(C0902c c0902c) {
        C0902c c0902c2 = this.f7799a;
        if (c0902c == c0902c2) {
            C0902c c0902c3 = c0902c2.f7798d;
            this.f7799a = c0902c3;
            this.f7800b = c0902c3 == null;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f7800b) {
            return this.f7801c.f7802a != null;
        }
        C0902c c0902c = this.f7799a;
        return (c0902c == null || c0902c.f7797c == null) ? false : true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f7800b) {
            this.f7800b = false;
            this.f7799a = this.f7801c.f7802a;
        } else {
            C0902c c0902c = this.f7799a;
            this.f7799a = c0902c != null ? c0902c.f7797c : null;
        }
        return this.f7799a;
    }
}
