package j;

/* renamed from: j.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0904e {
    public abstract void a(C0902c c0902c);
}
