package j;

import java.util.Map;

/* renamed from: j.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0902c implements Map.Entry {

    /* renamed from: a, reason: collision with root package name */
    public final Object f7795a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f7796b;

    /* renamed from: c, reason: collision with root package name */
    public C0902c f7797c;

    /* renamed from: d, reason: collision with root package name */
    public C0902c f7798d;

    public C0902c(Object obj, Object obj2) {
        this.f7795a = obj;
        this.f7796b = obj2;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0902c)) {
            return false;
        }
        C0902c c0902c = (C0902c) obj;
        return this.f7795a.equals(c0902c.f7795a) && this.f7796b.equals(c0902c.f7796b);
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f7795a;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f7796b;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        return this.f7795a.hashCode() ^ this.f7796b.hashCode();
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        throw new UnsupportedOperationException("An entry modification is not supported");
    }

    public final String toString() {
        return this.f7795a + "=" + this.f7796b;
    }
}
