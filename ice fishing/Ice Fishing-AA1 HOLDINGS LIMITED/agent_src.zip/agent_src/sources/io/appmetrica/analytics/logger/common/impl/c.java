package io.appmetrica.analytics.logger.common.impl;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final d f7155a;

    /* renamed from: b, reason: collision with root package name */
    public final a f7156b;

    /* renamed from: c, reason: collision with root package name */
    public final b f7157c;

    public c(d dVar, a aVar, b bVar) {
        this.f7155a = dVar;
        this.f7156b = aVar;
        this.f7157c = bVar;
    }
}
