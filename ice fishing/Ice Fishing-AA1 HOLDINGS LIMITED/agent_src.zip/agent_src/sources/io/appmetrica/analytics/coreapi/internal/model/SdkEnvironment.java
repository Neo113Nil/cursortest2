package io.appmetrica.analytics.coreapi.internal.model;

import A1.a;
import java.util.List;
import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class SdkEnvironment {

    /* renamed from: a, reason: collision with root package name */
    private final AppVersionInfo f3580a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3581b;

    /* renamed from: c, reason: collision with root package name */
    private final ScreenInfo f3582c;

    /* renamed from: d, reason: collision with root package name */
    private final SdkInfo f3583d;

    /* renamed from: e, reason: collision with root package name */
    private final String f3584e;

    /* renamed from: f, reason: collision with root package name */
    private final List f3585f;

    public SdkEnvironment(AppVersionInfo appVersionInfo, String str, ScreenInfo screenInfo, SdkInfo sdkInfo, String str2, List<String> list) {
        this.f3580a = appVersionInfo;
        this.f3581b = str;
        this.f3582c = screenInfo;
        this.f3583d = sdkInfo;
        this.f3584e = str2;
        this.f3585f = list;
    }

    public static /* synthetic */ SdkEnvironment copy$default(SdkEnvironment sdkEnvironment, AppVersionInfo appVersionInfo, String str, ScreenInfo screenInfo, SdkInfo sdkInfo, String str2, List list, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            appVersionInfo = sdkEnvironment.f3580a;
        }
        if ((i2 & 2) != 0) {
            str = sdkEnvironment.f3581b;
        }
        String str3 = str;
        if ((i2 & 4) != 0) {
            screenInfo = sdkEnvironment.f3582c;
        }
        ScreenInfo screenInfo2 = screenInfo;
        if ((i2 & 8) != 0) {
            sdkInfo = sdkEnvironment.f3583d;
        }
        SdkInfo sdkInfo2 = sdkInfo;
        if ((i2 & 16) != 0) {
            str2 = sdkEnvironment.f3584e;
        }
        String str4 = str2;
        if ((i2 & 32) != 0) {
            list = sdkEnvironment.f3585f;
        }
        return sdkEnvironment.copy(appVersionInfo, str3, screenInfo2, sdkInfo2, str4, list);
    }

    public final AppVersionInfo component1() {
        return this.f3580a;
    }

    public final String component2() {
        return this.f3581b;
    }

    public final ScreenInfo component3() {
        return this.f3582c;
    }

    public final SdkInfo component4() {
        return this.f3583d;
    }

    public final String component5() {
        return this.f3584e;
    }

    public final List<String> component6() {
        return this.f3585f;
    }

    public final SdkEnvironment copy(AppVersionInfo appVersionInfo, String str, ScreenInfo screenInfo, SdkInfo sdkInfo, String str2, List<String> list) {
        return new SdkEnvironment(appVersionInfo, str, screenInfo, sdkInfo, str2, list);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SdkEnvironment)) {
            return false;
        }
        SdkEnvironment sdkEnvironment = (SdkEnvironment) obj;
        return j.a(this.f3580a, sdkEnvironment.f3580a) && j.a(this.f3581b, sdkEnvironment.f3581b) && j.a(this.f3582c, sdkEnvironment.f3582c) && j.a(this.f3583d, sdkEnvironment.f3583d) && j.a(this.f3584e, sdkEnvironment.f3584e) && j.a(this.f3585f, sdkEnvironment.f3585f);
    }

    public final String getAppFramework() {
        return this.f3581b;
    }

    public final AppVersionInfo getAppVersionInfo() {
        return this.f3580a;
    }

    public final String getDeviceType() {
        return this.f3584e;
    }

    public final List<String> getLocales() {
        return this.f3585f;
    }

    public final ScreenInfo getScreenInfo() {
        return this.f3582c;
    }

    public final SdkInfo getSdkInfo() {
        return this.f3583d;
    }

    public int hashCode() {
        return this.f3585f.hashCode() + a.f(this.f3584e, (this.f3583d.hashCode() + ((this.f3582c.hashCode() + a.f(this.f3581b, this.f3580a.hashCode() * 31, 31)) * 31)) * 31, 31);
    }

    public String toString() {
        return "SdkEnvironment(appVersionInfo=" + this.f3580a + ", appFramework=" + this.f3581b + ", screenInfo=" + this.f3582c + ", sdkInfo=" + this.f3583d + ", deviceType=" + this.f3584e + ", locales=" + this.f3585f + ')';
    }
}
