package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class e extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3612a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f3613b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3614c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Context context, String str, int i2) {
        super(0);
        this.f3612a = context;
        this.f3613b = str;
        this.f3614c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3612a.getPackageManager().getPackageInfo(this.f3613b, this.f3614c);
    }
}
