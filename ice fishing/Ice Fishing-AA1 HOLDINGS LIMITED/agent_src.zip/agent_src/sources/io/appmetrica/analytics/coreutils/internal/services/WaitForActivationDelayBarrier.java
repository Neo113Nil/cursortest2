package io.appmetrica.analytics.coreutils.internal.services;

import io.appmetrica.analytics.coreapi.internal.executors.ICommonExecutor;
import io.appmetrica.analytics.coreapi.internal.servicecomponents.ActivationBarrier;
import io.appmetrica.analytics.coreapi.internal.servicecomponents.ActivationBarrierCallback;
import io.appmetrica.analytics.coreutils.impl.m;
import io.appmetrica.analytics.coreutils.internal.time.SystemTimeProvider;

/* loaded from: classes.dex */
public class WaitForActivationDelayBarrier implements ActivationBarrier {

    /* renamed from: a, reason: collision with root package name */
    private long f3679a;

    /* renamed from: b, reason: collision with root package name */
    private final SystemTimeProvider f3680b;

    public static class ActivationBarrierHelper {

        /* renamed from: a, reason: collision with root package name */
        private boolean f3681a = false;

        /* renamed from: b, reason: collision with root package name */
        private final a f3682b;

        /* renamed from: c, reason: collision with root package name */
        private final WaitForActivationDelayBarrier f3683c;

        public ActivationBarrierHelper(Runnable runnable, WaitForActivationDelayBarrier waitForActivationDelayBarrier) {
            this.f3682b = new a(this, runnable);
            this.f3683c = waitForActivationDelayBarrier;
        }

        public void subscribeIfNeeded(long j2, ICommonExecutor iCommonExecutor) {
            if (this.f3681a) {
                iCommonExecutor.execute(new b(this));
            } else {
                this.f3683c.subscribe(j2, iCommonExecutor, this.f3682b);
            }
        }
    }

    public WaitForActivationDelayBarrier() {
        this(new SystemTimeProvider());
    }

    public void activate() {
        this.f3679a = this.f3680b.currentTimeMillis();
    }

    @Override // io.appmetrica.analytics.coreapi.internal.servicecomponents.ActivationBarrier
    public void subscribe(long j2, ICommonExecutor iCommonExecutor, ActivationBarrierCallback activationBarrierCallback) {
        iCommonExecutor.executeDelayed(new m(activationBarrierCallback), Math.max(j2 - (this.f3680b.currentTimeMillis() - this.f3679a), 0L));
    }

    public WaitForActivationDelayBarrier(SystemTimeProvider systemTimeProvider) {
        this.f3680b = systemTimeProvider;
    }
}
