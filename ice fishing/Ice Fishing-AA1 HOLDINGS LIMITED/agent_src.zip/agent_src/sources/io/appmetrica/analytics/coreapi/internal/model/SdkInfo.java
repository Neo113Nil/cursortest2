package io.appmetrica.analytics.coreapi.internal.model;

import A1.a;
import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class SdkInfo {

    /* renamed from: a, reason: collision with root package name */
    private final String f3586a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3587b;

    /* renamed from: c, reason: collision with root package name */
    private final String f3588c;

    public SdkInfo(String str, String str2, String str3) {
        this.f3586a = str;
        this.f3587b = str2;
        this.f3588c = str3;
    }

    public static /* synthetic */ SdkInfo copy$default(SdkInfo sdkInfo, String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = sdkInfo.f3586a;
        }
        if ((i2 & 2) != 0) {
            str2 = sdkInfo.f3587b;
        }
        if ((i2 & 4) != 0) {
            str3 = sdkInfo.f3588c;
        }
        return sdkInfo.copy(str, str2, str3);
    }

    public final String component1() {
        return this.f3586a;
    }

    public final String component2() {
        return this.f3587b;
    }

    public final String component3() {
        return this.f3588c;
    }

    public final SdkInfo copy(String str, String str2, String str3) {
        return new SdkInfo(str, str2, str3);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SdkInfo)) {
            return false;
        }
        SdkInfo sdkInfo = (SdkInfo) obj;
        return j.a(this.f3586a, sdkInfo.f3586a) && j.a(this.f3587b, sdkInfo.f3587b) && j.a(this.f3588c, sdkInfo.f3588c);
    }

    public final String getSdkBuildNumber() {
        return this.f3587b;
    }

    public final String getSdkBuildType() {
        return this.f3588c;
    }

    public final String getSdkVersionName() {
        return this.f3586a;
    }

    public int hashCode() {
        return this.f3588c.hashCode() + a.f(this.f3587b, this.f3586a.hashCode() * 31, 31);
    }

    public String toString() {
        return "SdkInfo(sdkVersionName=" + this.f3586a + ", sdkBuildNumber=" + this.f3587b + ", sdkBuildType=" + this.f3588c + ')';
    }
}
