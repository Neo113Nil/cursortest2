package io.appmetrica.analytics.coreutils.impl;

import io.appmetrica.analytics.coreutils.internal.services.FirstExecutionConditionServiceImpl;
import io.appmetrica.analytics.coreutils.internal.services.UtilityServiceProvider;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class l extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ UtilityServiceProvider f3632a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l(UtilityServiceProvider utilityServiceProvider) {
        super(0);
        this.f3632a = utilityServiceProvider;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return new FirstExecutionConditionServiceImpl(this.f3632a);
    }
}
