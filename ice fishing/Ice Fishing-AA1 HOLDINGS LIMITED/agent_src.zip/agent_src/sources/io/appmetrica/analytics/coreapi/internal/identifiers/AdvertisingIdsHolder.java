package io.appmetrica.analytics.coreapi.internal.identifiers;

/* loaded from: classes.dex */
public class AdvertisingIdsHolder {

    /* renamed from: a, reason: collision with root package name */
    private final AdTrackingInfoResult f3559a;

    /* renamed from: b, reason: collision with root package name */
    private final AdTrackingInfoResult f3560b;

    /* renamed from: c, reason: collision with root package name */
    private final AdTrackingInfoResult f3561c;

    public AdvertisingIdsHolder() {
        this(new AdTrackingInfoResult(), new AdTrackingInfoResult(), new AdTrackingInfoResult());
    }

    public AdTrackingInfoResult getGoogle() {
        return this.f3559a;
    }

    public AdTrackingInfoResult getHuawei() {
        return this.f3560b;
    }

    public AdTrackingInfoResult getYandex() {
        return this.f3561c;
    }

    public String toString() {
        return "AdvertisingIdsHolder{mGoogle=" + this.f3559a + ", mHuawei=" + this.f3560b + ", yandex=" + this.f3561c + '}';
    }

    public AdvertisingIdsHolder(AdTrackingInfoResult adTrackingInfoResult, AdTrackingInfoResult adTrackingInfoResult2, AdTrackingInfoResult adTrackingInfoResult3) {
        this.f3559a = adTrackingInfoResult;
        this.f3560b = adTrackingInfoResult2;
        this.f3561c = adTrackingInfoResult3;
    }
}
