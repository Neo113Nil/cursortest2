package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import h1.AbstractC0178d;
import h1.AbstractC0180f;
import io.appmetrica.analytics.billinginterface.internal.BillingInfo;
import io.appmetrica.analytics.billinginterface.internal.ProductType;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class g extends SafeRunnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ i f3526a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BillingResult f3527b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ List f3528c;

    public g(i iVar, BillingResult billingResult, List list) {
        this.f3526a = iVar;
        this.f3527b = billingResult;
        this.f3528c = list;
    }

    @Override // io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable
    public final void runSafety() {
        i iVar = this.f3526a;
        BillingResult billingResult = this.f3527b;
        List<Purchase> list = this.f3528c;
        iVar.getClass();
        if (billingResult.getResponseCode() != 0) {
            iVar.f3537f.onUpdateFinished();
        } else {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Purchase purchase : list) {
                for (String str : purchase.getProducts()) {
                    String str2 = iVar.f3535d;
                    BillingInfo billingInfo = new BillingInfo(kotlin.jvm.internal.j.a(str2, "inapp") ? ProductType.INAPP : kotlin.jvm.internal.j.a(str2, "subs") ? ProductType.SUBS : ProductType.UNKNOWN, str, purchase.getPurchaseToken(), purchase.getPurchaseTime(), 0L);
                    linkedHashMap.put(billingInfo.productId, billingInfo);
                }
            }
            Map<String, BillingInfo> billingInfoToUpdate = iVar.f3534c.getUpdatePolicy().getBillingInfoToUpdate(iVar.f3532a, linkedHashMap, iVar.f3534c.getBillingInfoManager());
            if (billingInfoToUpdate.isEmpty()) {
                m.a(linkedHashMap, billingInfoToUpdate, iVar.f3535d, iVar.f3534c.getBillingInfoManager());
                iVar.f3537f.onUpdateFinished();
            } else {
                List n02 = AbstractC0178d.n0(billingInfoToUpdate.keySet());
                n nVar = iVar.f3537f;
                h hVar = new h(linkedHashMap, billingInfoToUpdate, iVar);
                String str3 = iVar.f3535d;
                BillingClient billingClient = iVar.f3533b;
                UtilsProvider utilsProvider = iVar.f3534c;
                d dVar = iVar.f3536e;
                f fVar = new f(str3, billingClient, utilsProvider, hVar, list, dVar, nVar);
                dVar.f3515b.add(fVar);
                if (iVar.f3533b.isReady()) {
                    BillingClient billingClient2 = iVar.f3533b;
                    QueryProductDetailsParams.Builder newBuilder = QueryProductDetailsParams.newBuilder();
                    ArrayList arrayList = new ArrayList(AbstractC0180f.e0(n02));
                    Iterator it = n02.iterator();
                    while (it.hasNext()) {
                        arrayList.add(QueryProductDetailsParams.Product.newBuilder().setProductId((String) it.next()).setProductType(iVar.f3535d).build());
                    }
                    billingClient2.queryProductDetailsAsync(newBuilder.setProductList(arrayList).build(), fVar);
                } else {
                    iVar.f3536e.a(fVar);
                    nVar.onUpdateFinished();
                }
            }
        }
        i iVar2 = this.f3526a;
        iVar2.f3536e.a(iVar2);
    }
}
