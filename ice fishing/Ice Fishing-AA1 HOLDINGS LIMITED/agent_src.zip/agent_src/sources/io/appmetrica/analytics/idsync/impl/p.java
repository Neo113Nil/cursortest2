package io.appmetrica.analytics.idsync.impl;

import android.text.TextUtils;
import h1.AbstractC0178d;
import io.appmetrica.analytics.coreutils.internal.time.SystemTimeProvider;
import io.appmetrica.analytics.idsync.internal.model.Preconditions;
import io.appmetrica.analytics.idsync.internal.model.RequestConfig;
import io.appmetrica.analytics.modulesapi.internal.common.ModuleSelfReporter;
import io.appmetrica.analytics.modulesapi.internal.service.ServiceContext;
import io.appmetrica.analytics.network.internal.NetworkClient;
import io.appmetrica.analytics.network.internal.Request;
import io.appmetrica.analytics.network.internal.Response;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class p {

    /* renamed from: a, reason: collision with root package name */
    public final ServiceContext f3840a;

    /* renamed from: b, reason: collision with root package name */
    public final B f3841b;

    /* renamed from: c, reason: collision with root package name */
    public final SystemTimeProvider f3842c = new SystemTimeProvider();

    /* renamed from: d, reason: collision with root package name */
    public final q f3843d;

    /* renamed from: e, reason: collision with root package name */
    public final s f3844e;

    /* renamed from: f, reason: collision with root package name */
    public final i f3845f;

    public p(ServiceContext serviceContext, B b2) {
        this.f3840a = serviceContext;
        this.f3841b = b2;
        this.f3843d = new q(serviceContext.getNetworkContext().getSslSocketFactoryProvider(), this);
        this.f3844e = new s(serviceContext);
        this.f3845f = new i(serviceContext);
    }

    public static final void a(y yVar, p pVar) {
        if (yVar.f3853b) {
            B b2 = pVar.f3841b;
            String str = yVar.f3852a;
            b2.f3790d.put(str, new z(str, pVar.f3842c.currentTimeMillis(), yVar.f3855d ? 2 : 4));
            b2.f3787a.putString(b2.f3789c, b2.f3788b.fromModel(AbstractC0178d.n0(b2.f3790d.values())));
            i iVar = pVar.f3845f;
            ModuleSelfReporter selfReporter = iVar.f3817a.getSelfReporter();
            iVar.f3818b.getClass();
            selfReporter.reportEvent("id_sync", j.a(yVar));
        }
    }

    public static final void a(p pVar, RequestConfig requestConfig) {
        t c0200a;
        s sVar = pVar.f3844e;
        Preconditions preconditions = requestConfig.getPreconditions();
        sVar.getClass();
        if (r.f3848a[preconditions.getNetworkType().ordinal()] == 1) {
            c0200a = new C0201b(sVar.f3849a);
        } else {
            c0200a = new C0200a();
        }
        if (c0200a.a()) {
            q qVar = pVar.f3843d;
            qVar.getClass();
            Request.Builder builder = new Request.Builder(requestConfig.getUrl());
            for (Map.Entry<String, List<String>> entry : requestConfig.getHeaders().entrySet()) {
                builder.addHeader(entry.getKey(), AbstractC0178d.i0(entry.getValue(), ", ", null, null, null, 62));
            }
            Response execute = new NetworkClient.Builder().withSslSocketFactory(qVar.f3846a.getSslSocketFactory()).withUseCaches(false).withInstanceFollowRedirects(true).withMaxResponseSize(102400).build().newCall(builder.build()).execute();
            qVar.f3847b.a(new y(requestConfig.getType(), execute.isCompleted(), execute.getUrl(), requestConfig.getValidResponseCodes().contains(Integer.valueOf(execute.getCode())), execute.getCode(), execute.getResponseData().length == 0 ? execute.getErrorData() : execute.getResponseData(), execute.getHeaders()));
        }
    }

    public final void a(y yVar) {
        this.f3840a.getExecutorProvider().getModuleExecutor().execute(new F0.c(3, yVar, this));
    }

    public final void a(RequestConfig requestConfig) {
        long resendIntervalForValidResponse;
        if (TextUtils.isEmpty(requestConfig.getType()) || TextUtils.isEmpty(requestConfig.getUrl()) || requestConfig.getValidResponseCodes().isEmpty()) {
            return;
        }
        z zVar = (z) this.f3841b.f3790d.get(requestConfig.getType());
        if (zVar != null) {
            long currentTimeMillis = this.f3842c.currentTimeMillis();
            int a2 = v.a(zVar.f3861c);
            if (a2 != 1) {
                resendIntervalForValidResponse = a2 != 3 ? 0L : requestConfig.getResendIntervalForInvalidResponse();
            } else {
                resendIntervalForValidResponse = requestConfig.getResendIntervalForValidResponse();
            }
            if (currentTimeMillis - zVar.f3860b < resendIntervalForValidResponse) {
                return;
            }
        }
        this.f3840a.getExecutorProvider().getSupportIOExecutor().execute(new F0.c(2, this, requestConfig));
    }
}
