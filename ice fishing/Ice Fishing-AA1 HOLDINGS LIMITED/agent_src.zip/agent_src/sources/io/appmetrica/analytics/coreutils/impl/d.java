package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import android.content.pm.PackageManager;
import io.appmetrica.analytics.coreutils.internal.AndroidUtils;
import io.appmetrica.analytics.coreutils.internal.services.SafePackageManagerHelperForR;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class d extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3610a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f3611b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(Context context, String str) {
        super(0);
        this.f3610a = context;
        this.f3611b = str;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        PackageManager packageManager = this.f3610a.getPackageManager();
        return AndroidUtils.isApiAchieved(30) ? SafePackageManagerHelperForR.extractPackageInstaller(packageManager, this.f3611b) : packageManager.getInstallerPackageName(this.f3611b);
    }
}
