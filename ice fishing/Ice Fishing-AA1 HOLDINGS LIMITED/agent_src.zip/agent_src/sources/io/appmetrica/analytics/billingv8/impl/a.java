package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.QueryPurchasesParams;
import h1.AbstractC0179e;
import io.appmetrica.analytics.billinginterface.internal.config.BillingConfig;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable;

/* loaded from: classes.dex */
public final class a extends SafeRunnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ b f3504a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BillingResult f3505b;

    public a(b bVar, BillingResult billingResult) {
        this.f3504a = bVar;
        this.f3505b = billingResult;
    }

    @Override // io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable
    public final void runSafety() {
        b bVar = this.f3504a;
        BillingResult billingResult = this.f3505b;
        bVar.getClass();
        if (billingResult.getResponseCode() != 0) {
            bVar.f3510e.onUpdateFinished();
            return;
        }
        if (!bVar.f3507b.isReady()) {
            bVar.f3510e.onUpdateFinished();
            return;
        }
        for (String str : AbstractC0179e.c0("inapp", "subs")) {
            BillingConfig billingConfig = bVar.f3506a;
            BillingClient billingClient = bVar.f3507b;
            UtilsProvider utilsProvider = bVar.f3508c;
            d dVar = bVar.f3509d;
            i iVar = new i(billingConfig, billingClient, utilsProvider, str, dVar, bVar.f3510e);
            dVar.f3515b.add(iVar);
            bVar.f3507b.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(str).build(), iVar);
        }
    }
}
