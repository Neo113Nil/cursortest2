package io.appmetrica.analytics.logger.common.impl;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final String f7158a;

    public d(String str) {
        this.f7158a = str;
    }
}
