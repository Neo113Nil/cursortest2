package io.appmetrica.analytics.coreapi.internal.identifiers;

import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class SdkIdentifiers {

    /* renamed from: a, reason: collision with root package name */
    private final String f3570a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3571b;

    /* renamed from: c, reason: collision with root package name */
    private final String f3572c;

    public SdkIdentifiers(String str, String str2, String str3) {
        this.f3570a = str;
        this.f3571b = str2;
        this.f3572c = str3;
    }

    public static /* synthetic */ SdkIdentifiers copy$default(SdkIdentifiers sdkIdentifiers, String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = sdkIdentifiers.f3570a;
        }
        if ((i2 & 2) != 0) {
            str2 = sdkIdentifiers.f3571b;
        }
        if ((i2 & 4) != 0) {
            str3 = sdkIdentifiers.f3572c;
        }
        return sdkIdentifiers.copy(str, str2, str3);
    }

    public final String component1() {
        return this.f3570a;
    }

    public final String component2() {
        return this.f3571b;
    }

    public final String component3() {
        return this.f3572c;
    }

    public final SdkIdentifiers copy(String str, String str2, String str3) {
        return new SdkIdentifiers(str, str2, str3);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SdkIdentifiers)) {
            return false;
        }
        SdkIdentifiers sdkIdentifiers = (SdkIdentifiers) obj;
        return j.a(this.f3570a, sdkIdentifiers.f3570a) && j.a(this.f3571b, sdkIdentifiers.f3571b) && j.a(this.f3572c, sdkIdentifiers.f3572c);
    }

    public final String getDeviceId() {
        return this.f3571b;
    }

    public final String getDeviceIdHash() {
        return this.f3572c;
    }

    public final String getUuid() {
        return this.f3570a;
    }

    public int hashCode() {
        String str = this.f3570a;
        int hashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f3571b;
        int hashCode2 = (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f3572c;
        return hashCode2 + (str3 != null ? str3.hashCode() : 0);
    }

    public String toString() {
        return "SdkIdentifiers(uuid=" + this.f3570a + ", deviceId=" + this.f3571b + ", deviceIdHash=" + this.f3572c + ')';
    }
}
