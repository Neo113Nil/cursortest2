package io.appmetrica.analytics.coreutils.internal.permission;

import android.content.Context;
import h1.AbstractC0177c;
import io.appmetrica.analytics.coreapi.internal.system.PermissionExtractor;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class AnyOfPermissionStrategy extends MultiplePermissionBaseStrategy {
    public AnyOfPermissionStrategy(PermissionExtractor permissionExtractor, String... strArr) {
        super(permissionExtractor, AbstractC0177c.f0(strArr));
    }

    @Override // io.appmetrica.analytics.coreutils.internal.permission.MultiplePermissionBaseStrategy
    public boolean hasNecessaryPermissions(Context context, PermissionExtractor permissionExtractor, List<String> list) {
        if (list == null || !list.isEmpty()) {
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                if (permissionExtractor.hasPermission(context, (String) it.next())) {
                    return true;
                }
            }
        }
        return false;
    }
}
