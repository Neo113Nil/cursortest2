package io.appmetrica.analytics.ndkcrashesapi.internal;

/* loaded from: classes.dex */
public final class NativeCrashClientConfig {

    /* renamed from: a, reason: collision with root package name */
    private final String f7201a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7202b;

    public NativeCrashClientConfig(String str, String str2) {
        this.f7201a = str;
        this.f7202b = str2;
    }

    public final String getNativeCrashFolder() {
        return this.f7201a;
    }

    public final String getNativeCrashMetadata() {
        return this.f7202b;
    }
}
