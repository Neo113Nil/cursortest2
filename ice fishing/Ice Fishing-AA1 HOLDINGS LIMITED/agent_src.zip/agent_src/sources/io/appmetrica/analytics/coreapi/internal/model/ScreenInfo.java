package io.appmetrica.analytics.coreapi.internal.model;

/* loaded from: classes.dex */
public final class ScreenInfo {

    /* renamed from: a, reason: collision with root package name */
    private final int f3576a;

    /* renamed from: b, reason: collision with root package name */
    private final int f3577b;

    /* renamed from: c, reason: collision with root package name */
    private final int f3578c;

    /* renamed from: d, reason: collision with root package name */
    private final float f3579d;

    public ScreenInfo(int i2, int i3, int i4, float f2) {
        this.f3576a = i2;
        this.f3577b = i3;
        this.f3578c = i4;
        this.f3579d = f2;
    }

    public static /* synthetic */ ScreenInfo copy$default(ScreenInfo screenInfo, int i2, int i3, int i4, float f2, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            i2 = screenInfo.f3576a;
        }
        if ((i5 & 2) != 0) {
            i3 = screenInfo.f3577b;
        }
        if ((i5 & 4) != 0) {
            i4 = screenInfo.f3578c;
        }
        if ((i5 & 8) != 0) {
            f2 = screenInfo.f3579d;
        }
        return screenInfo.copy(i2, i3, i4, f2);
    }

    public final int component1() {
        return this.f3576a;
    }

    public final int component2() {
        return this.f3577b;
    }

    public final int component3() {
        return this.f3578c;
    }

    public final float component4() {
        return this.f3579d;
    }

    public final ScreenInfo copy(int i2, int i3, int i4, float f2) {
        return new ScreenInfo(i2, i3, i4, f2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ScreenInfo)) {
            return false;
        }
        ScreenInfo screenInfo = (ScreenInfo) obj;
        return this.f3576a == screenInfo.f3576a && this.f3577b == screenInfo.f3577b && this.f3578c == screenInfo.f3578c && Float.valueOf(this.f3579d).equals(Float.valueOf(screenInfo.f3579d));
    }

    public final int getDpi() {
        return this.f3578c;
    }

    public final int getHeight() {
        return this.f3577b;
    }

    public final float getScaleFactor() {
        return this.f3579d;
    }

    public final int getWidth() {
        return this.f3576a;
    }

    public int hashCode() {
        return Float.hashCode(this.f3579d) + ((Integer.hashCode(this.f3578c) + ((Integer.hashCode(this.f3577b) + (Integer.hashCode(this.f3576a) * 31)) * 31)) * 31);
    }

    public String toString() {
        return "ScreenInfo(width=" + this.f3576a + ", height=" + this.f3577b + ", dpi=" + this.f3578c + ", scaleFactor=" + this.f3579d + ')';
    }
}
