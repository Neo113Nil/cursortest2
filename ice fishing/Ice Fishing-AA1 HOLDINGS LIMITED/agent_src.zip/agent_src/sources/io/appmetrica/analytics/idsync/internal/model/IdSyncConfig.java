package io.appmetrica.analytics.idsync.internal.model;

import java.util.List;
import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class IdSyncConfig {

    /* renamed from: a, reason: collision with root package name */
    private final boolean f3868a;

    /* renamed from: b, reason: collision with root package name */
    private final long f3869b;

    /* renamed from: c, reason: collision with root package name */
    private final List f3870c;

    public IdSyncConfig(boolean z2, long j2, List<RequestConfig> list) {
        this.f3868a = z2;
        this.f3869b = j2;
        this.f3870c = list;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!IdSyncConfig.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        if (obj == null) {
            throw new NullPointerException("null cannot be cast to non-null type io.appmetrica.analytics.idsync.internal.model.IdSyncConfig");
        }
        IdSyncConfig idSyncConfig = (IdSyncConfig) obj;
        return this.f3868a == idSyncConfig.f3868a && this.f3869b == idSyncConfig.f3869b && j.a(this.f3870c, idSyncConfig.f3870c);
    }

    public final boolean getEnabled() {
        return this.f3868a;
    }

    public final long getLaunchDelay() {
        return this.f3869b;
    }

    public final List<RequestConfig> getRequests() {
        return this.f3870c;
    }

    public int hashCode() {
        return this.f3870c.hashCode() + ((Long.hashCode(this.f3869b) + (Boolean.hashCode(this.f3868a) * 31)) * 31);
    }

    public String toString() {
        return "IdSyncConfig(enabled=" + this.f3868a + ", launchDelay=" + this.f3869b + ", requests=" + this.f3870c + ')';
    }
}
