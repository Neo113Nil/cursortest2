package io.appmetrica.analytics.billing.internal.config;

import io.appmetrica.analytics.billing.impl.s;

/* loaded from: classes.dex */
public final class BillingConfig {

    /* renamed from: a, reason: collision with root package name */
    private final int f3443a;

    /* renamed from: b, reason: collision with root package name */
    private final int f3444b;

    public BillingConfig(int i2, int i3) {
        this.f3443a = i2;
        this.f3444b = i3;
    }

    public final int getFirstCollectingInappMaxAgeSeconds() {
        return this.f3444b;
    }

    public final int getSendFrequencySeconds() {
        return this.f3443a;
    }

    public String toString() {
        return "BillingConfig(sendFrequencySeconds=" + this.f3443a + ", firstCollectingInappMaxAgeSeconds=" + this.f3444b + ')';
    }

    public BillingConfig() {
        this(new s().f3384a, new s().f3385b);
    }
}
