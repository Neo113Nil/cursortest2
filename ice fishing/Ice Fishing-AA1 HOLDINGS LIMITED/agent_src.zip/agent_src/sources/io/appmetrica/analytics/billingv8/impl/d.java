package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingClient;
import java.util.LinkedHashSet;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final BillingClient f3514a;

    /* renamed from: b, reason: collision with root package name */
    public final LinkedHashSet f3515b = new LinkedHashSet();

    public d(BillingClient billingClient) {
        this.f3514a = billingClient;
    }

    public final void a(Object obj) {
        this.f3515b.remove(obj);
        if (this.f3515b.size() == 0) {
            this.f3514a.endConnection();
        }
    }
}
