package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.modulesapi.internal.service.ServiceContext;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: a, reason: collision with root package name */
    public final ServiceContext f3849a;

    public s(ServiceContext serviceContext) {
        this.f3849a = serviceContext;
    }
}
