package io.appmetrica.analytics.idsync.impl;

import java.util.Map;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public final String f3852a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f3853b;

    /* renamed from: c, reason: collision with root package name */
    public final String f3854c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f3855d;

    /* renamed from: e, reason: collision with root package name */
    public final int f3856e;

    /* renamed from: f, reason: collision with root package name */
    public final byte[] f3857f;

    /* renamed from: g, reason: collision with root package name */
    public final Map f3858g;

    public y(String str, boolean z2, String str2, boolean z3, int i2, byte[] bArr, Map map) {
        this.f3852a = str;
        this.f3853b = z2;
        this.f3854c = str2;
        this.f3855d = z3;
        this.f3856e = i2;
        this.f3857f = bArr;
        this.f3858g = map;
    }

    public final String toString() {
        return "RequestResult(type='" + this.f3852a + "', isCompleted=" + this.f3853b + ", url=" + this.f3854c + ", responseCodeIsValid=" + this.f3855d + ", responseCode=" + this.f3856e + ", responseBody=" + this.f3857f + ", responseHeaders=" + this.f3858g + ')';
    }
}
