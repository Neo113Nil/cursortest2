package io.appmetrica.analytics.coreapi.internal.identifiers;

import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class AppSetId {

    /* renamed from: a, reason: collision with root package name */
    private final String f3562a;

    /* renamed from: b, reason: collision with root package name */
    private final AppSetIdScope f3563b;

    public AppSetId(String str, AppSetIdScope appSetIdScope) {
        this.f3562a = str;
        this.f3563b = appSetIdScope;
    }

    public static /* synthetic */ AppSetId copy$default(AppSetId appSetId, String str, AppSetIdScope appSetIdScope, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = appSetId.f3562a;
        }
        if ((i2 & 2) != 0) {
            appSetIdScope = appSetId.f3563b;
        }
        return appSetId.copy(str, appSetIdScope);
    }

    public final String component1() {
        return this.f3562a;
    }

    public final AppSetIdScope component2() {
        return this.f3563b;
    }

    public final AppSetId copy(String str, AppSetIdScope appSetIdScope) {
        return new AppSetId(str, appSetIdScope);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppSetId)) {
            return false;
        }
        AppSetId appSetId = (AppSetId) obj;
        return j.a(this.f3562a, appSetId.f3562a) && this.f3563b == appSetId.f3563b;
    }

    public final String getId() {
        return this.f3562a;
    }

    public final AppSetIdScope getScope() {
        return this.f3563b;
    }

    public int hashCode() {
        String str = this.f3562a;
        return this.f3563b.hashCode() + ((str == null ? 0 : str.hashCode()) * 31);
    }

    public String toString() {
        return "AppSetId(id=" + this.f3562a + ", scope=" + this.f3563b + ')';
    }
}
