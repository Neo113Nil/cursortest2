package io.appmetrica.analytics.billingv8.impl;

import h1.AbstractC0178d;
import io.appmetrica.analytics.billinginterface.internal.BillingInfo;
import io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoManager;
import io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoStorage;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class c implements BillingInfoManager {

    /* renamed from: a, reason: collision with root package name */
    public final BillingInfoStorage f3511a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f3512b;

    /* renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f3513c;

    public c(BillingInfoStorage billingInfoStorage) {
        this.f3511a = billingInfoStorage;
        this.f3512b = billingInfoStorage.isFirstInappCheckOccurred();
        List<BillingInfo> billingInfo = billingInfoStorage.getBillingInfo();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Object obj : billingInfo) {
            linkedHashMap.put(((BillingInfo) obj).productId, obj);
        }
        this.f3513c = linkedHashMap;
    }

    @Override // io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoManager
    public final BillingInfo get(String str) {
        return (BillingInfo) this.f3513c.get(str);
    }

    @Override // io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoManager
    public final boolean isFirstInappCheckOccurred() {
        return this.f3512b;
    }

    @Override // io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoManager
    public final void markFirstInappCheckOccurred() {
        if (this.f3512b) {
            return;
        }
        this.f3512b = true;
        this.f3511a.saveInfo(AbstractC0178d.n0(this.f3513c.values()), this.f3512b);
    }

    @Override // io.appmetrica.analytics.billinginterface.internal.storage.BillingInfoManager
    public final void update(Map<String, ? extends BillingInfo> map) {
        for (BillingInfo billingInfo : map.values()) {
            this.f3513c.put(billingInfo.productId, billingInfo);
        }
        this.f3511a.saveInfo(AbstractC0178d.n0(this.f3513c.values()), this.f3512b);
    }
}
