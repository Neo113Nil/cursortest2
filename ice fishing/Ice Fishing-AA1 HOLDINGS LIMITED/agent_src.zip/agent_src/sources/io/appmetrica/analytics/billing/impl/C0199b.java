package io.appmetrica.analytics.billing.impl;

import h1.AbstractC0180f;
import io.appmetrica.analytics.billinginterface.internal.BillingInfo;
import io.appmetrica.analytics.coreapi.internal.data.ProtobufConverter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: io.appmetrica.analytics.billing.impl.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0199b implements ProtobufConverter {

    /* renamed from: a, reason: collision with root package name */
    public final i f3354a;

    /* JADX WARN: Multi-variable type inference failed */
    public C0199b() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final d fromModel(C0198a c0198a) {
        d dVar = new d();
        List list = c0198a.f3352a;
        ArrayList arrayList = new ArrayList(AbstractC0180f.e0(list));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(this.f3354a.fromModel((BillingInfo) it.next()));
        }
        Object[] array = arrayList.toArray(new c[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
        }
        dVar.f3365a = (c[]) array;
        dVar.f3366b = c0198a.f3353b;
        return dVar;
    }

    public C0199b(i iVar) {
        this.f3354a = iVar;
    }

    public /* synthetic */ C0199b(i iVar, int i2, kotlin.jvm.internal.f fVar) {
        this((i2 & 1) != 0 ? new i() : iVar);
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final C0198a toModel(d dVar) {
        c[] cVarArr = dVar.f3365a;
        ArrayList arrayList = new ArrayList(cVarArr.length);
        for (c cVar : cVarArr) {
            arrayList.add(this.f3354a.toModel(cVar));
        }
        return new C0198a(arrayList, dVar.f3366b);
    }
}
