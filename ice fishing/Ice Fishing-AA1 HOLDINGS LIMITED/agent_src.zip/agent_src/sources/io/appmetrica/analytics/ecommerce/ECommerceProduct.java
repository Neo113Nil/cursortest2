package io.appmetrica.analytics.ecommerce;

import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class ECommerceProduct {

    /* renamed from: a, reason: collision with root package name */
    private final String f3721a;

    /* renamed from: b, reason: collision with root package name */
    private String f3722b;

    /* renamed from: c, reason: collision with root package name */
    private List f3723c;

    /* renamed from: d, reason: collision with root package name */
    private Map f3724d;

    /* renamed from: e, reason: collision with root package name */
    private ECommercePrice f3725e;

    /* renamed from: f, reason: collision with root package name */
    private ECommercePrice f3726f;

    /* renamed from: g, reason: collision with root package name */
    private List f3727g;

    public ECommerceProduct(String str) {
        this.f3721a = str;
    }

    public ECommercePrice getActualPrice() {
        return this.f3725e;
    }

    public List<String> getCategoriesPath() {
        return this.f3723c;
    }

    public String getName() {
        return this.f3722b;
    }

    public ECommercePrice getOriginalPrice() {
        return this.f3726f;
    }

    public Map<String, String> getPayload() {
        return this.f3724d;
    }

    public List<String> getPromocodes() {
        return this.f3727g;
    }

    public String getSku() {
        return this.f3721a;
    }

    public ECommerceProduct setActualPrice(ECommercePrice eCommercePrice) {
        this.f3725e = eCommercePrice;
        return this;
    }

    public ECommerceProduct setCategoriesPath(List<String> list) {
        this.f3723c = list;
        return this;
    }

    public ECommerceProduct setName(String str) {
        this.f3722b = str;
        return this;
    }

    public ECommerceProduct setOriginalPrice(ECommercePrice eCommercePrice) {
        this.f3726f = eCommercePrice;
        return this;
    }

    public ECommerceProduct setPayload(Map<String, String> map) {
        this.f3724d = map;
        return this;
    }

    public ECommerceProduct setPromocodes(List<String> list) {
        this.f3727g = list;
        return this;
    }

    public String toString() {
        return "ECommerceProduct{sku='" + this.f3721a + "', name='" + this.f3722b + "', categoriesPath=" + this.f3723c + ", payload=" + this.f3724d + ", actualPrice=" + this.f3725e + ", originalPrice=" + this.f3726f + ", promocodes=" + this.f3727g + '}';
    }
}
