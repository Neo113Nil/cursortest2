package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.idsync.internal.model.NetworkType;

/* loaded from: classes.dex */
public abstract /* synthetic */ class w {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f3851a;

    static {
        int[] iArr = new int[NetworkType.values().length];
        iArr[NetworkType.CELL.ordinal()] = 1;
        f3851a = iArr;
    }
}
