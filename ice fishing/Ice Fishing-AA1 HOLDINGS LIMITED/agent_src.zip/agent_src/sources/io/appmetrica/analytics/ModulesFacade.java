package io.appmetrica.analytics;

import android.content.Context;
import io.appmetrica.analytics.impl.AbstractC0686si;
import io.appmetrica.analytics.impl.C0526md;
import io.appmetrica.analytics.impl.C0578od;
import io.appmetrica.analytics.impl.C0604pd;
import io.appmetrica.analytics.impl.C0630qd;
import io.appmetrica.analytics.impl.C0655rd;
import io.appmetrica.analytics.impl.C0681sd;
import io.appmetrica.analytics.impl.C0707td;
import io.appmetrica.analytics.impl.C0733ud;
import io.appmetrica.analytics.impl.C0798x0;

/* loaded from: classes.dex */
public final class ModulesFacade {
    public static final int EXTERNAL_ATTRIBUTION_ADJUST = 2;
    public static final int EXTERNAL_ATTRIBUTION_AIRBRIDGE = 5;
    public static final int EXTERNAL_ATTRIBUTION_APPSFLYER = 1;
    public static final int EXTERNAL_ATTRIBUTION_KOCHAVA = 3;
    public static final int EXTERNAL_ATTRIBUTION_SINGULAR = 6;
    public static final int EXTERNAL_ATTRIBUTION_TENJIN = 4;

    /* renamed from: a, reason: collision with root package name */
    private static C0733ud f3300a = new C0733ud();

    public static IModuleReporter getModuleReporter(Context context, String str) {
        C0733ud c0733ud = f3300a;
        C0526md c0526md = c0733ud.f6797b;
        c0526md.f6187b.a(context);
        c0526md.f6189d.a(str);
        c0733ud.f6798c.f3996a.a(context.getApplicationContext().getApplicationContext());
        return AbstractC0686si.f6658a.a(context.getApplicationContext(), str);
    }

    public static boolean isActivatedForApp() {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.getClass();
        c0733ud.f6798c.getClass();
        c0733ud.f6796a.getClass();
        return C0798x0.a();
    }

    public static void reportAdRevenue(AdRevenue adRevenue) {
        reportAdRevenue(adRevenue, Boolean.TRUE);
    }

    public static void reportEvent(ModuleEvent moduleEvent) {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.f6186a.a(null);
        c0733ud.f6798c.getClass();
        c0733ud.f6799d.execute(new C0604pd(c0733ud, moduleEvent));
    }

    public static void reportExternalAttribution(int i2, String str) {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.getClass();
        c0733ud.f6798c.getClass();
        c0733ud.f6799d.execute(new C0630qd(c0733ud, i2, str));
    }

    public static void sendEventsBuffer() {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.getClass();
        c0733ud.f6798c.getClass();
        AppMetrica.sendEventsBuffer();
    }

    public static void setAdvIdentifiersTracking(boolean z2) {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.getClass();
        c0733ud.f6798c.getClass();
        c0733ud.f6799d.execute(new C0655rd(c0733ud, z2));
    }

    public static void setProxy(C0733ud c0733ud) {
        f3300a = c0733ud;
    }

    public static void setSessionExtra(String str, byte[] bArr) {
        C0733ud c0733ud = f3300a;
        c0733ud.f6797b.f6188c.a(str);
        c0733ud.f6798c.getClass();
        c0733ud.f6799d.execute(new C0681sd(c0733ud, str, bArr));
    }

    public static void subscribeForAutoCollectedData(Context context, String str) {
        C0733ud c0733ud = f3300a;
        C0526md c0526md = c0733ud.f6797b;
        c0526md.f6187b.a(context);
        c0526md.f6189d.a(str);
        c0733ud.f6798c.f3996a.a(context.getApplicationContext());
        c0733ud.f6799d.execute(new C0707td(str));
    }

    public static void reportAdRevenue(AdRevenue adRevenue, Boolean bool) {
        C0733ud c0733ud = f3300a;
        boolean booleanValue = bool.booleanValue();
        c0733ud.f6797b.getClass();
        c0733ud.f6798c.getClass();
        c0733ud.f6799d.execute(new C0578od(c0733ud, adRevenue, booleanValue));
    }
}
