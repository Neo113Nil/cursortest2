package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PurchasesUpdatedListener;
import java.util.List;

/* loaded from: classes.dex */
public final class l implements PurchasesUpdatedListener {
    public final void onPurchasesUpdated(BillingResult billingResult, List list) {
    }
}
