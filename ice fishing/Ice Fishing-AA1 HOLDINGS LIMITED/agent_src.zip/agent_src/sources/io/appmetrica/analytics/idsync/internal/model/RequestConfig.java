package io.appmetrica.analytics.idsync.internal.model;

import A1.a;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class RequestConfig {

    /* renamed from: a, reason: collision with root package name */
    private final String f3873a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3874b;

    /* renamed from: c, reason: collision with root package name */
    private final Preconditions f3875c;

    /* renamed from: d, reason: collision with root package name */
    private final Map f3876d;

    /* renamed from: e, reason: collision with root package name */
    private final long f3877e;

    /* renamed from: f, reason: collision with root package name */
    private final long f3878f;

    /* renamed from: g, reason: collision with root package name */
    private final List f3879g;

    public RequestConfig(String str, String str2, Preconditions preconditions, Map<String, ? extends List<String>> map, long j2, long j3, List<Integer> list) {
        this.f3873a = str;
        this.f3874b = str2;
        this.f3875c = preconditions;
        this.f3876d = map;
        this.f3877e = j2;
        this.f3878f = j3;
        this.f3879g = list;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!RequestConfig.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        if (obj == null) {
            throw new NullPointerException("null cannot be cast to non-null type io.appmetrica.analytics.idsync.internal.model.RequestConfig");
        }
        RequestConfig requestConfig = (RequestConfig) obj;
        return this.f3877e == requestConfig.f3877e && this.f3878f == requestConfig.f3878f && j.a(this.f3873a, requestConfig.f3873a) && j.a(this.f3874b, requestConfig.f3874b) && j.a(this.f3875c, requestConfig.f3875c) && j.a(this.f3876d, requestConfig.f3876d) && j.a(this.f3879g, requestConfig.f3879g);
    }

    public final Map<String, List<String>> getHeaders() {
        return this.f3876d;
    }

    public final Preconditions getPreconditions() {
        return this.f3875c;
    }

    public final long getResendIntervalForInvalidResponse() {
        return this.f3878f;
    }

    public final long getResendIntervalForValidResponse() {
        return this.f3877e;
    }

    public final String getType() {
        return this.f3873a;
    }

    public final String getUrl() {
        return this.f3874b;
    }

    public final List<Integer> getValidResponseCodes() {
        return this.f3879g;
    }

    public int hashCode() {
        return this.f3879g.hashCode() + ((this.f3876d.hashCode() + ((this.f3875c.hashCode() + a.f(this.f3874b, a.f(this.f3873a, (Long.hashCode(this.f3878f) + (Long.hashCode(this.f3877e) * 31)) * 31, 31), 31)) * 31)) * 31);
    }

    public String toString() {
        return "RequestConfig(type='" + this.f3873a + "', url='" + this.f3874b + "', preconditions=" + this.f3875c + ", headers=" + this.f3876d + ", resendIntervalForValidResponse=" + this.f3877e + ", resendIntervalForInvalidResponse=" + this.f3878f + ", validResponseCodes=" + this.f3879g + ')';
    }
}
