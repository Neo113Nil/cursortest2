package io.appmetrica.analytics.ecommerce;

import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class ECommerceOrder {

    /* renamed from: a, reason: collision with root package name */
    private final String f3716a;

    /* renamed from: b, reason: collision with root package name */
    private final List f3717b;

    /* renamed from: c, reason: collision with root package name */
    private Map f3718c;

    public ECommerceOrder(String str, List<ECommerceCartItem> list) {
        this.f3716a = str;
        this.f3717b = list;
    }

    public List<ECommerceCartItem> getCartItems() {
        return this.f3717b;
    }

    public String getIdentifier() {
        return this.f3716a;
    }

    public Map<String, String> getPayload() {
        return this.f3718c;
    }

    public ECommerceOrder setPayload(Map<String, String> map) {
        this.f3718c = map;
        return this;
    }

    public String toString() {
        return "ECommerceOrder{identifier='" + this.f3716a + "', cartItems=" + this.f3717b + ", payload=" + this.f3718c + '}';
    }
}
