package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.protobuf.nano.CodedInputByteBufferNano;
import io.appmetrica.analytics.protobuf.nano.CodedOutputByteBufferNano;
import io.appmetrica.analytics.protobuf.nano.InternalNano;
import io.appmetrica.analytics.protobuf.nano.MessageNano;
import io.appmetrica.analytics.protobuf.nano.WireFormatNano;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class m extends MessageNano {

    /* renamed from: h, reason: collision with root package name */
    public static volatile m[] f3824h;

    /* renamed from: a, reason: collision with root package name */
    public byte[] f3825a;

    /* renamed from: b, reason: collision with root package name */
    public l f3826b;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f3827c;

    /* renamed from: d, reason: collision with root package name */
    public k[] f3828d;

    /* renamed from: e, reason: collision with root package name */
    public long f3829e;

    /* renamed from: f, reason: collision with root package name */
    public long f3830f;

    /* renamed from: g, reason: collision with root package name */
    public int[] f3831g;

    public m() {
        a();
    }

    public static m[] b() {
        if (f3824h == null) {
            synchronized (InternalNano.LAZY_INIT_LOCK) {
                try {
                    if (f3824h == null) {
                        f3824h = new m[0];
                    }
                } finally {
                }
            }
        }
        return f3824h;
    }

    public final m a() {
        byte[] bArr = WireFormatNano.EMPTY_BYTES;
        this.f3825a = bArr;
        this.f3826b = null;
        this.f3827c = bArr;
        this.f3828d = k.b();
        this.f3829e = 86400000L;
        this.f3830f = 3600000L;
        this.f3831g = WireFormatNano.EMPTY_INT_ARRAY;
        this.cachedSize = -1;
        return this;
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    public final int computeSerializedSize() {
        int computeSerializedSize = super.computeSerializedSize();
        byte[] bArr = this.f3825a;
        byte[] bArr2 = WireFormatNano.EMPTY_BYTES;
        if (!Arrays.equals(bArr, bArr2)) {
            computeSerializedSize += CodedOutputByteBufferNano.computeBytesSize(1, this.f3825a);
        }
        l lVar = this.f3826b;
        if (lVar != null) {
            computeSerializedSize += CodedOutputByteBufferNano.computeMessageSize(2, lVar);
        }
        if (!Arrays.equals(this.f3827c, bArr2)) {
            computeSerializedSize += CodedOutputByteBufferNano.computeBytesSize(3, this.f3827c);
        }
        k[] kVarArr = this.f3828d;
        int i2 = 0;
        if (kVarArr != null && kVarArr.length > 0) {
            int i3 = 0;
            while (true) {
                k[] kVarArr2 = this.f3828d;
                if (i3 >= kVarArr2.length) {
                    break;
                }
                k kVar = kVarArr2[i3];
                if (kVar != null) {
                    computeSerializedSize = CodedOutputByteBufferNano.computeMessageSize(4, kVar) + computeSerializedSize;
                }
                i3++;
            }
        }
        long j2 = this.f3829e;
        if (j2 != 86400000) {
            computeSerializedSize += CodedOutputByteBufferNano.computeUInt64Size(5, j2);
        }
        long j3 = this.f3830f;
        if (j3 != 3600000) {
            computeSerializedSize += CodedOutputByteBufferNano.computeUInt64Size(6, j3);
        }
        int[] iArr = this.f3831g;
        if (iArr == null || iArr.length <= 0) {
            return computeSerializedSize;
        }
        int i4 = 0;
        while (true) {
            int[] iArr2 = this.f3831g;
            if (i2 >= iArr2.length) {
                return computeSerializedSize + i4 + iArr2.length;
            }
            i4 += CodedOutputByteBufferNano.computeUInt32SizeNoTag(iArr2[i2]);
            i2++;
        }
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    public final void writeTo(CodedOutputByteBufferNano codedOutputByteBufferNano) {
        byte[] bArr = this.f3825a;
        byte[] bArr2 = WireFormatNano.EMPTY_BYTES;
        if (!Arrays.equals(bArr, bArr2)) {
            codedOutputByteBufferNano.writeBytes(1, this.f3825a);
        }
        l lVar = this.f3826b;
        if (lVar != null) {
            codedOutputByteBufferNano.writeMessage(2, lVar);
        }
        if (!Arrays.equals(this.f3827c, bArr2)) {
            codedOutputByteBufferNano.writeBytes(3, this.f3827c);
        }
        k[] kVarArr = this.f3828d;
        int i2 = 0;
        if (kVarArr != null && kVarArr.length > 0) {
            int i3 = 0;
            while (true) {
                k[] kVarArr2 = this.f3828d;
                if (i3 >= kVarArr2.length) {
                    break;
                }
                k kVar = kVarArr2[i3];
                if (kVar != null) {
                    codedOutputByteBufferNano.writeMessage(4, kVar);
                }
                i3++;
            }
        }
        long j2 = this.f3829e;
        if (j2 != 86400000) {
            codedOutputByteBufferNano.writeUInt64(5, j2);
        }
        long j3 = this.f3830f;
        if (j3 != 3600000) {
            codedOutputByteBufferNano.writeUInt64(6, j3);
        }
        int[] iArr = this.f3831g;
        if (iArr != null && iArr.length > 0) {
            while (true) {
                int[] iArr2 = this.f3831g;
                if (i2 >= iArr2.length) {
                    break;
                }
                codedOutputByteBufferNano.writeUInt32(7, iArr2[i2]);
                i2++;
            }
        }
        super.writeTo(codedOutputByteBufferNano);
    }

    public static m b(CodedInputByteBufferNano codedInputByteBufferNano) {
        return new m().mergeFrom(codedInputByteBufferNano);
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final m mergeFrom(CodedInputByteBufferNano codedInputByteBufferNano) {
        while (true) {
            int readTag = codedInputByteBufferNano.readTag();
            if (readTag == 0) {
                return this;
            }
            if (readTag == 10) {
                this.f3825a = codedInputByteBufferNano.readBytes();
            } else if (readTag == 18) {
                if (this.f3826b == null) {
                    this.f3826b = new l();
                }
                codedInputByteBufferNano.readMessage(this.f3826b);
            } else if (readTag == 26) {
                this.f3827c = codedInputByteBufferNano.readBytes();
            } else if (readTag == 34) {
                int repeatedFieldArrayLength = WireFormatNano.getRepeatedFieldArrayLength(codedInputByteBufferNano, 34);
                k[] kVarArr = this.f3828d;
                int length = kVarArr == null ? 0 : kVarArr.length;
                int i2 = repeatedFieldArrayLength + length;
                k[] kVarArr2 = new k[i2];
                if (length != 0) {
                    System.arraycopy(kVarArr, 0, kVarArr2, 0, length);
                }
                while (length < i2 - 1) {
                    k kVar = new k();
                    kVarArr2[length] = kVar;
                    codedInputByteBufferNano.readMessage(kVar);
                    codedInputByteBufferNano.readTag();
                    length++;
                }
                k kVar2 = new k();
                kVarArr2[length] = kVar2;
                codedInputByteBufferNano.readMessage(kVar2);
                this.f3828d = kVarArr2;
            } else if (readTag == 40) {
                this.f3829e = codedInputByteBufferNano.readUInt64();
            } else if (readTag == 48) {
                this.f3830f = codedInputByteBufferNano.readUInt64();
            } else if (readTag == 56) {
                int repeatedFieldArrayLength2 = WireFormatNano.getRepeatedFieldArrayLength(codedInputByteBufferNano, 56);
                int[] iArr = this.f3831g;
                int length2 = iArr == null ? 0 : iArr.length;
                int i3 = repeatedFieldArrayLength2 + length2;
                int[] iArr2 = new int[i3];
                if (length2 != 0) {
                    System.arraycopy(iArr, 0, iArr2, 0, length2);
                }
                while (length2 < i3 - 1) {
                    iArr2[length2] = codedInputByteBufferNano.readUInt32();
                    codedInputByteBufferNano.readTag();
                    length2++;
                }
                iArr2[length2] = codedInputByteBufferNano.readUInt32();
                this.f3831g = iArr2;
            } else if (readTag != 58) {
                if (!WireFormatNano.parseUnknownField(codedInputByteBufferNano, readTag)) {
                    return this;
                }
            } else {
                int pushLimit = codedInputByteBufferNano.pushLimit(codedInputByteBufferNano.readRawVarint32());
                int position = codedInputByteBufferNano.getPosition();
                int i4 = 0;
                while (codedInputByteBufferNano.getBytesUntilLimit() > 0) {
                    codedInputByteBufferNano.readUInt32();
                    i4++;
                }
                codedInputByteBufferNano.rewindToPosition(position);
                int[] iArr3 = this.f3831g;
                int length3 = iArr3 == null ? 0 : iArr3.length;
                int i5 = i4 + length3;
                int[] iArr4 = new int[i5];
                if (length3 != 0) {
                    System.arraycopy(iArr3, 0, iArr4, 0, length3);
                }
                while (length3 < i5) {
                    iArr4[length3] = codedInputByteBufferNano.readUInt32();
                    length3++;
                }
                this.f3831g = iArr4;
                codedInputByteBufferNano.popLimit(pushLimit);
            }
        }
    }

    public static m a(byte[] bArr) {
        return (m) MessageNano.mergeFrom(new m(), bArr);
    }
}
