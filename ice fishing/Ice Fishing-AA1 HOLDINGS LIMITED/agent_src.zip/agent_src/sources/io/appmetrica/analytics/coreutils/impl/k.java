package io.appmetrica.analytics.coreutils.impl;

import android.content.ComponentName;
import android.content.Context;
import g1.C0137i;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class k extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3628a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ComponentName f3629b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3630c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f3631d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(Context context, ComponentName componentName, int i2, int i3) {
        super(0);
        this.f3628a = context;
        this.f3629b = componentName;
        this.f3630c = i2;
        this.f3631d = i3;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        this.f3628a.getPackageManager().setComponentEnabledSetting(this.f3629b, this.f3630c, this.f3631d);
        return C0137i.f2940a;
    }
}
