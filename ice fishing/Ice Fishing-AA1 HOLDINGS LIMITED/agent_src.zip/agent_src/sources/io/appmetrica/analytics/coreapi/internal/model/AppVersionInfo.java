package io.appmetrica.analytics.coreapi.internal.model;

import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class AppVersionInfo {

    /* renamed from: a, reason: collision with root package name */
    private final String f3574a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3575b;

    public AppVersionInfo(String str, String str2) {
        this.f3574a = str;
        this.f3575b = str2;
    }

    public static /* synthetic */ AppVersionInfo copy$default(AppVersionInfo appVersionInfo, String str, String str2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = appVersionInfo.f3574a;
        }
        if ((i2 & 2) != 0) {
            str2 = appVersionInfo.f3575b;
        }
        return appVersionInfo.copy(str, str2);
    }

    public final String component1() {
        return this.f3574a;
    }

    public final String component2() {
        return this.f3575b;
    }

    public final AppVersionInfo copy(String str, String str2) {
        return new AppVersionInfo(str, str2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppVersionInfo)) {
            return false;
        }
        AppVersionInfo appVersionInfo = (AppVersionInfo) obj;
        return j.a(this.f3574a, appVersionInfo.f3574a) && j.a(this.f3575b, appVersionInfo.f3575b);
    }

    public final String getAppBuildNumber() {
        return this.f3575b;
    }

    public final String getAppVersionName() {
        return this.f3574a;
    }

    public int hashCode() {
        return this.f3575b.hashCode() + (this.f3574a.hashCode() * 31);
    }

    public String toString() {
        return "AppVersionInfo(appVersionName=" + this.f3574a + ", appBuildNumber=" + this.f3575b + ')';
    }
}
