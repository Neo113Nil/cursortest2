package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import android.content.Intent;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class j extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3625a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Intent f3626b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3627c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(Context context, Intent intent, int i2) {
        super(0);
        this.f3625a = context;
        this.f3626b = intent;
        this.f3627c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3625a.getPackageManager().resolveService(this.f3626b, this.f3627c);
    }
}
