package io.appmetrica.analytics.billingv8;

/* loaded from: classes.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "io.appmetrica.analytics.billingv8";
}
