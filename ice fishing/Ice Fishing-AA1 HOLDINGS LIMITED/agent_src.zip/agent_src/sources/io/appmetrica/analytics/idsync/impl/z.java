package io.appmetrica.analytics.idsync.impl;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public final String f3859a;

    /* renamed from: b, reason: collision with root package name */
    public final long f3860b;

    /* renamed from: c, reason: collision with root package name */
    public final int f3861c;

    public z(String str, long j2, int i2) {
        this.f3859a = str;
        this.f3860b = j2;
        this.f3861c = i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof z)) {
            return false;
        }
        z zVar = (z) obj;
        return kotlin.jvm.internal.j.a(this.f3859a, zVar.f3859a) && this.f3860b == zVar.f3860b && this.f3861c == zVar.f3861c;
    }

    public final int hashCode() {
        return v.a(this.f3861c) + ((Long.hashCode(this.f3860b) + (this.f3859a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "RequestState(type=" + this.f3859a + ", lastAttempt=" + this.f3860b + ", lastAttemptResult=" + u.b(this.f3861c) + ')';
    }
}
