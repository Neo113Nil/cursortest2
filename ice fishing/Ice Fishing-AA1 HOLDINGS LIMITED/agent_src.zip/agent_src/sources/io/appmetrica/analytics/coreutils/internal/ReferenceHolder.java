package io.appmetrica.analytics.coreutils.internal;

import h1.AbstractC0178d;
import java.util.LinkedHashSet;
import java.util.Set;

/* loaded from: classes.dex */
public final class ReferenceHolder {

    /* renamed from: a, reason: collision with root package name */
    private final LinkedHashSet f3634a = new LinkedHashSet();

    public final Set<Object> peekReferences() {
        return AbstractC0178d.r0(this.f3634a);
    }

    public final void removeReference(Object obj) {
        this.f3634a.remove(obj);
    }

    public final void storeReference(Object obj) {
        this.f3634a.add(obj);
    }
}
