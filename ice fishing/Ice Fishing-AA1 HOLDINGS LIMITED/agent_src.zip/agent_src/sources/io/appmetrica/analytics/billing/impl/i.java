package io.appmetrica.analytics.billing.impl;

import io.appmetrica.analytics.billinginterface.internal.BillingInfo;
import io.appmetrica.analytics.billinginterface.internal.ProductType;
import io.appmetrica.analytics.coreapi.internal.data.ProtobufConverter;

/* loaded from: classes.dex */
public final class i implements ProtobufConverter {
    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final c fromModel(BillingInfo billingInfo) {
        c cVar = new c();
        int i2 = h.f3367a[billingInfo.type.ordinal()];
        cVar.f3356a = i2 != 1 ? i2 != 2 ? 1 : 3 : 2;
        cVar.f3357b = billingInfo.productId;
        cVar.f3358c = billingInfo.purchaseToken;
        cVar.f3359d = billingInfo.purchaseTime;
        cVar.f3360e = billingInfo.sendTime;
        return cVar;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final BillingInfo toModel(c cVar) {
        ProductType productType;
        int i2 = cVar.f3356a;
        if (i2 == 2) {
            productType = ProductType.INAPP;
        } else if (i2 != 3) {
            productType = ProductType.UNKNOWN;
        } else {
            productType = ProductType.SUBS;
        }
        return new BillingInfo(productType, cVar.f3357b, cVar.f3358c, cVar.f3359d, cVar.f3360e);
    }
}
