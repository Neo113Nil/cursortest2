package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PurchasesResponseListener;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import java.util.List;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class k implements PurchasesResponseListener {

    /* renamed from: a, reason: collision with root package name */
    public final UtilsProvider f3541a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0982a f3542b;

    /* renamed from: c, reason: collision with root package name */
    public final List f3543c;

    /* renamed from: d, reason: collision with root package name */
    public final List f3544d;

    /* renamed from: e, reason: collision with root package name */
    public final d f3545e;

    /* renamed from: f, reason: collision with root package name */
    public final n f3546f;

    public k(UtilsProvider utilsProvider, InterfaceC0982a interfaceC0982a, List list, List list2, d dVar, n nVar) {
        this.f3541a = utilsProvider;
        this.f3542b = interfaceC0982a;
        this.f3543c = list;
        this.f3544d = list2;
        this.f3545e = dVar;
        this.f3546f = nVar;
    }

    public final void onQueryPurchasesResponse(BillingResult billingResult, List list) {
        this.f3541a.getWorkerExecutor().execute(new j(this, billingResult, list));
    }
}
