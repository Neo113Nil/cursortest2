package io.appmetrica.analytics.idsync.impl;

import h1.AbstractC0178d;
import io.appmetrica.analytics.coreapi.internal.data.JsonParser;
import io.appmetrica.analytics.coreutils.internal.parsing.RemoteConfigJsonUtils;
import io.appmetrica.analytics.idsync.internal.model.IdSyncConfig;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class c implements JsonParser {

    /* renamed from: a, reason: collision with root package name */
    public final e f3792a;

    /* renamed from: b, reason: collision with root package name */
    public final String f3793b = "id_sync";

    /* renamed from: c, reason: collision with root package name */
    public final String f3794c = "id_sync";

    /* renamed from: d, reason: collision with root package name */
    public final String f3795d = "launch_delay_seconds";

    /* renamed from: e, reason: collision with root package name */
    public final String f3796e = "requests";

    /* renamed from: f, reason: collision with root package name */
    public final String f3797f = "type";

    /* renamed from: g, reason: collision with root package name */
    public final String f3798g = "url";

    /* renamed from: h, reason: collision with root package name */
    public final String f3799h = "headers";

    /* renamed from: i, reason: collision with root package name */
    public final String f3800i = "resend_interval_for_valid_response";

    /* renamed from: j, reason: collision with root package name */
    public final String f3801j = "resend_interval_for_invalid_response";

    /* renamed from: k, reason: collision with root package name */
    public final String f3802k = "valid_response_codes";

    /* renamed from: l, reason: collision with root package name */
    public final String f3803l = "preconditions";

    /* renamed from: m, reason: collision with root package name */
    public final String f3804m = "network";

    /* renamed from: n, reason: collision with root package name */
    public final String f3805n = "cell";

    public c(e eVar) {
        this.f3792a = eVar;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Parser
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final IdSyncConfig parse(JSONObject jSONObject) {
        m[] mVarArr;
        JSONArray jSONArray;
        int i2;
        k[] kVarArr;
        JSONArray jSONArray2;
        int i3;
        JSONObject jSONObject2;
        byte[][] bArr;
        int[] iArr;
        int[] iArr2;
        int i4;
        JSONObject optJSONObject = jSONObject.optJSONObject(this.f3794c);
        if (optJSONObject == null) {
            optJSONObject = new JSONObject();
        }
        o oVar = new o();
        oVar.f3838a = RemoteConfigJsonUtils.extractFeature(jSONObject, this.f3793b, oVar.f3838a);
        n nVar = new n();
        nVar.f3833a = RemoteConfigJsonUtils.extractMillisFromSecondsOrDefault(optJSONObject, this.f3795d, nVar.f3833a);
        JSONArray optJSONArray = optJSONObject.optJSONArray(this.f3796e);
        int i5 = 0;
        if (optJSONArray == null) {
            mVarArr = new m[0];
        } else {
            int length = optJSONArray.length();
            m[] mVarArr2 = new m[length];
            int i6 = 0;
            while (i6 < length) {
                JSONObject optJSONObject2 = optJSONArray.optJSONObject(i6);
                m mVar = new m();
                if (optJSONObject2 == null) {
                    jSONArray = optJSONArray;
                    i2 = length;
                    i4 = i5;
                } else {
                    String optString = optJSONObject2.optString(this.f3797f);
                    Charset charset = x1.a.f8290a;
                    mVar.f3825a = optString.getBytes(charset);
                    JSONObject optJSONObject3 = optJSONObject2.optJSONObject(this.f3803l);
                    l lVar = new l();
                    if (optJSONObject3 != null && kotlin.jvm.internal.j.a(optJSONObject3.optString(this.f3804m), this.f3805n)) {
                        lVar.f3823a = 1;
                    }
                    mVar.f3826b = lVar;
                    mVar.f3827c = optJSONObject2.optString(this.f3798g).getBytes(charset);
                    JSONObject optJSONObject4 = optJSONObject2.optJSONObject(this.f3799h);
                    if (optJSONObject4 == null) {
                        kVarArr = new k[i5];
                        jSONArray = optJSONArray;
                        i2 = length;
                    } else {
                        ArrayList arrayList = new ArrayList();
                        Iterator<String> keys = optJSONObject4.keys();
                        while (keys.hasNext()) {
                            String next = keys.next();
                            k kVar = new k();
                            kVar.f3820a = next.getBytes(x1.a.f8290a);
                            JSONArray optJSONArray2 = optJSONObject4.optJSONArray(next);
                            if (optJSONArray2 == null) {
                                bArr = new byte[i5][];
                                jSONArray2 = optJSONArray;
                                i3 = length;
                                jSONObject2 = optJSONObject4;
                            } else {
                                int length2 = optJSONArray2.length();
                                byte[][] bArr2 = new byte[length2][];
                                jSONArray2 = optJSONArray;
                                int i7 = 0;
                                while (i7 < length2) {
                                    bArr2[i7] = optJSONArray2.optString(i7).getBytes(x1.a.f8290a);
                                    i7++;
                                    length = length;
                                    optJSONObject4 = optJSONObject4;
                                }
                                i3 = length;
                                jSONObject2 = optJSONObject4;
                                bArr = bArr2;
                            }
                            kVar.f3821b = bArr;
                            arrayList.add(kVar);
                            optJSONArray = jSONArray2;
                            length = i3;
                            optJSONObject4 = jSONObject2;
                            i5 = 0;
                        }
                        jSONArray = optJSONArray;
                        i2 = length;
                        Object[] array = arrayList.toArray(new k[i5]);
                        if (array == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
                        }
                        kVarArr = (k[]) array;
                    }
                    mVar.f3828d = kVarArr;
                    mVar.f3829e = RemoteConfigJsonUtils.extractMillisFromSecondsOrDefault(optJSONObject2, this.f3800i, mVar.f3829e);
                    mVar.f3830f = RemoteConfigJsonUtils.extractMillisFromSecondsOrDefault(optJSONObject2, this.f3801j, mVar.f3830f);
                    JSONArray optJSONArray3 = optJSONObject2.optJSONArray(this.f3802k);
                    if (optJSONArray3 == null) {
                        iArr = new int[0];
                    } else {
                        int length3 = optJSONArray3.length();
                        int[] iArr3 = new int[length3];
                        for (int i8 = 0; i8 < length3; i8++) {
                            iArr3[i8] = optJSONArray3.optInt(i8);
                        }
                        iArr = iArr3;
                    }
                    ArrayList arrayList2 = new ArrayList();
                    for (int i9 : iArr) {
                        if (i9 != 0) {
                            arrayList2.add(Integer.valueOf(i9));
                        }
                    }
                    if (arrayList2.isEmpty()) {
                        arrayList2 = null;
                    }
                    if (arrayList2 != null) {
                        iArr2 = AbstractC0178d.m0(arrayList2);
                        i4 = 0;
                    } else {
                        i4 = 0;
                        iArr2 = new int[]{200};
                    }
                    mVar.f3831g = iArr2;
                }
                mVarArr2[i6] = mVar;
                i6++;
                i5 = i4;
                optJSONArray = jSONArray;
                length = i2;
            }
            mVarArr = mVarArr2;
        }
        nVar.f3834b = mVarArr;
        oVar.f3839b = nVar;
        return this.f3792a.toModel(oVar);
    }

    public final IdSyncConfig b(JSONObject jSONObject) {
        return (IdSyncConfig) JsonParser.DefaultImpls.parseOrNull(this, jSONObject);
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Parser
    public final Object parseOrNull(JSONObject jSONObject) {
        return (IdSyncConfig) JsonParser.DefaultImpls.parseOrNull(this, jSONObject);
    }
}
