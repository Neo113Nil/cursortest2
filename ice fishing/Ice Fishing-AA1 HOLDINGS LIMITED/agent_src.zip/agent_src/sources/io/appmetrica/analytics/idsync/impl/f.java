package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.coreapi.internal.executors.IHandlerExecutor;
import io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable;
import io.appmetrica.analytics.idsync.internal.model.IdSyncConfig;
import io.appmetrica.analytics.idsync.internal.model.RequestConfig;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class f extends SafeRunnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ h f3808a;

    public f(h hVar) {
        this.f3808a = hVar;
    }

    @Override // io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable
    public final void runSafety() {
        IdSyncConfig idSyncConfig;
        if (this.f3808a.f3815f && (idSyncConfig = this.f3808a.f3814e) != null) {
            this.f3808a.getClass();
            if (h.a(idSyncConfig)) {
                List<RequestConfig> requests = idSyncConfig.getRequests();
                h hVar = this.f3808a;
                Iterator<T> it = requests.iterator();
                while (it.hasNext()) {
                    hVar.f3813d.a((RequestConfig) it.next());
                }
                h hVar2 = this.f3808a;
                IHandlerExecutor iHandlerExecutor = hVar2.f3812c;
                f fVar = hVar2.f3816g;
                if (fVar != null) {
                    iHandlerExecutor.executeDelayed(fVar, hVar2.f3811b);
                } else {
                    kotlin.jvm.internal.j.g("syncRunnable");
                    throw null;
                }
            }
        }
    }
}
