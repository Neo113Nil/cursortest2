package io.appmetrica.analytics.billing.internal.config;

import io.appmetrica.analytics.billing.impl.t;

/* loaded from: classes.dex */
public final class RemoteBillingConfig {

    /* renamed from: a, reason: collision with root package name */
    private final boolean f3445a;

    /* renamed from: b, reason: collision with root package name */
    private final BillingConfig f3446b;

    public RemoteBillingConfig(boolean z2, BillingConfig billingConfig) {
        this.f3445a = z2;
        this.f3446b = billingConfig;
    }

    public final BillingConfig getConfig() {
        return this.f3446b;
    }

    public final boolean getEnabled() {
        return this.f3445a;
    }

    public String toString() {
        return "RemoteBillingConfig(enabled=" + this.f3445a + ", config=" + this.f3446b + ')';
    }

    public RemoteBillingConfig() {
        this(new t().f3387a, new BillingConfig());
    }
}
