package io.appmetrica.analytics.coreutils.internal.cache;

/* loaded from: classes.dex */
public interface CachedDataProvider {

    public static class CachedData<T> {

        /* renamed from: a, reason: collision with root package name */
        private final String f3635a;

        /* renamed from: b, reason: collision with root package name */
        private volatile long f3636b;

        /* renamed from: c, reason: collision with root package name */
        private volatile long f3637c;

        /* renamed from: d, reason: collision with root package name */
        private long f3638d = 0;

        /* renamed from: e, reason: collision with root package name */
        private Object f3639e = null;

        public CachedData(long j2, long j3, String str) {
            this.f3635a = A1.a.k("[CachedData-", str, "]");
            this.f3636b = j2;
            this.f3637c = j3;
        }

        public T getData() {
            return (T) this.f3639e;
        }

        public long getExpiryTime() {
            return this.f3637c;
        }

        public long getRefreshTime() {
            return this.f3636b;
        }

        public final boolean isEmpty() {
            return this.f3639e == null;
        }

        public void setData(T t) {
            this.f3639e = t;
            this.f3638d = System.currentTimeMillis();
        }

        public void setExpirationPolicy(long j2, long j3) {
            this.f3636b = j2;
            this.f3637c = j3;
        }

        public final boolean shouldClearData() {
            if (this.f3638d == 0) {
                return false;
            }
            long currentTimeMillis = System.currentTimeMillis() - this.f3638d;
            return currentTimeMillis > this.f3637c || currentTimeMillis < 0;
        }

        public final boolean shouldUpdateData() {
            long currentTimeMillis = System.currentTimeMillis() - this.f3638d;
            return currentTimeMillis > this.f3636b || currentTimeMillis < 0;
        }

        public String toString() {
            return "CachedData{tag='" + this.f3635a + "', refreshTime=" + this.f3636b + ", expiryTime=" + this.f3637c + ", mCachedTime=" + this.f3638d + ", mCachedData=" + this.f3639e + '}';
        }
    }
}
