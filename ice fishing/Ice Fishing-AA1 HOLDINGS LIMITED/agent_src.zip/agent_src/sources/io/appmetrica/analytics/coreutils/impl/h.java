package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import android.content.Intent;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class h extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3620a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Intent f3621b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3622c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(Context context, Intent intent, int i2) {
        super(0);
        this.f3620a = context;
        this.f3621b = intent;
        this.f3622c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3620a.getPackageManager().resolveActivity(this.f3621b, this.f3622c);
    }
}
