package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable;
import java.util.List;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class e extends SafeRunnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f f3516a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BillingResult f3517b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ QueryProductDetailsResult f3518c;

    public e(f fVar, BillingResult billingResult, QueryProductDetailsResult queryProductDetailsResult) {
        this.f3516a = fVar;
        this.f3517b = billingResult;
        this.f3518c = queryProductDetailsResult;
    }

    @Override // io.appmetrica.analytics.coreutils.internal.executors.SafeRunnable
    public final void runSafety() {
        f fVar = this.f3516a;
        BillingResult billingResult = this.f3517b;
        List productDetailsList = this.f3518c.getProductDetailsList();
        fVar.getClass();
        if (billingResult.getResponseCode() != 0 || productDetailsList.isEmpty()) {
            fVar.f3525g.onUpdateFinished();
        } else {
            UtilsProvider utilsProvider = fVar.f3521c;
            InterfaceC0982a interfaceC0982a = fVar.f3522d;
            List list = fVar.f3523e;
            d dVar = fVar.f3524f;
            k kVar = new k(utilsProvider, interfaceC0982a, list, productDetailsList, dVar, fVar.f3525g);
            dVar.f3515b.add(kVar);
            if (fVar.f3520b.isReady()) {
                fVar.f3520b.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(fVar.f3519a).build(), kVar);
            } else {
                fVar.f3524f.a(kVar);
                fVar.f3525g.onUpdateFinished();
            }
        }
        f fVar2 = this.f3516a;
        fVar2.f3524f.a(fVar2);
    }
}
