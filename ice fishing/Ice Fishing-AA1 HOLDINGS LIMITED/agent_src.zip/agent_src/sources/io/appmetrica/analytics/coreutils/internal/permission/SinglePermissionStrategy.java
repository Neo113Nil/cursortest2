package io.appmetrica.analytics.coreutils.internal.permission;

import android.content.Context;
import io.appmetrica.analytics.coreapi.internal.permission.PermissionResolutionStrategy;
import io.appmetrica.analytics.coreapi.internal.system.PermissionExtractor;

/* loaded from: classes.dex */
public final class SinglePermissionStrategy implements PermissionResolutionStrategy {

    /* renamed from: a, reason: collision with root package name */
    private final PermissionExtractor f3659a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3660b;

    public SinglePermissionStrategy(PermissionExtractor permissionExtractor, String str) {
        this.f3659a = permissionExtractor;
        this.f3660b = str;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.permission.PermissionResolutionStrategy
    public boolean hasNecessaryPermissions(Context context) {
        return this.f3659a.hasPermission(context, this.f3660b);
    }
}
