package io.appmetrica.analytics.ecommerce;

import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class ECommerceScreen {

    /* renamed from: a, reason: collision with root package name */
    private String f3731a;

    /* renamed from: b, reason: collision with root package name */
    private List f3732b;

    /* renamed from: c, reason: collision with root package name */
    private String f3733c;

    /* renamed from: d, reason: collision with root package name */
    private Map f3734d;

    public List<String> getCategoriesPath() {
        return this.f3732b;
    }

    public String getName() {
        return this.f3731a;
    }

    public Map<String, String> getPayload() {
        return this.f3734d;
    }

    public String getSearchQuery() {
        return this.f3733c;
    }

    public ECommerceScreen setCategoriesPath(List<String> list) {
        this.f3732b = list;
        return this;
    }

    public ECommerceScreen setName(String str) {
        this.f3731a = str;
        return this;
    }

    public ECommerceScreen setPayload(Map<String, String> map) {
        this.f3734d = map;
        return this;
    }

    public ECommerceScreen setSearchQuery(String str) {
        this.f3733c = str;
        return this;
    }

    public String toString() {
        return "ECommerceScreen{name='" + this.f3731a + "', categoriesPath=" + this.f3732b + ", searchQuery='" + this.f3733c + "', payload=" + this.f3734d + '}';
    }
}
