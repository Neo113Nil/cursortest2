package io.appmetrica.analytics.ecommerce;

/* loaded from: classes.dex */
public class ECommerceReferrer {

    /* renamed from: a, reason: collision with root package name */
    private String f3728a;

    /* renamed from: b, reason: collision with root package name */
    private String f3729b;

    /* renamed from: c, reason: collision with root package name */
    private ECommerceScreen f3730c;

    public String getIdentifier() {
        return this.f3729b;
    }

    public ECommerceScreen getScreen() {
        return this.f3730c;
    }

    public String getType() {
        return this.f3728a;
    }

    public ECommerceReferrer setIdentifier(String str) {
        this.f3729b = str;
        return this;
    }

    public ECommerceReferrer setScreen(ECommerceScreen eCommerceScreen) {
        this.f3730c = eCommerceScreen;
        return this;
    }

    public ECommerceReferrer setType(String str) {
        this.f3728a = str;
        return this;
    }

    public String toString() {
        return "ECommerceReferrer{type='" + this.f3728a + "', identifier='" + this.f3729b + "', screen=" + this.f3730c + '}';
    }
}
