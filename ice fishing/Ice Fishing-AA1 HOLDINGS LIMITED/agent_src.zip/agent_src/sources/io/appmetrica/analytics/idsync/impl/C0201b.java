package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.coreapi.internal.system.NetworkType;
import io.appmetrica.analytics.modulesapi.internal.service.ServiceContext;

/* renamed from: io.appmetrica.analytics.idsync.impl.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0201b implements t {

    /* renamed from: a, reason: collision with root package name */
    public final ServiceContext f3791a;

    public C0201b(ServiceContext serviceContext) {
        this.f3791a = serviceContext;
    }

    @Override // io.appmetrica.analytics.idsync.impl.t
    public final boolean a() {
        return this.f3791a.getActiveNetworkTypeProvider().getNetworkType(this.f3791a.getContext()) == NetworkType.CELL;
    }
}
