package io.appmetrica.analytics.coreutils.impl;

import android.content.ComponentName;
import android.content.Context;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class a extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3602a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ComponentName f3603b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3604c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(Context context, ComponentName componentName, int i2) {
        super(0);
        this.f3602a = context;
        this.f3603b = componentName;
        this.f3604c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3602a.getPackageManager().getActivityInfo(this.f3603b, this.f3604c);
    }
}
