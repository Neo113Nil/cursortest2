package io.appmetrica.analytics.coreutils.internal.cache;

import io.appmetrica.analytics.coreapi.internal.cache.CacheUpdateScheduler;
import io.appmetrica.analytics.coreapi.internal.cache.UpdateConditionsChecker;
import io.appmetrica.analytics.coreapi.internal.executors.ICommonExecutor;
import io.appmetrica.analytics.locationapi.internal.ILastKnownUpdater;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public class LocationDataCacheUpdateScheduler implements CacheUpdateScheduler {

    /* renamed from: a, reason: collision with root package name */
    private final ICommonExecutor f3641a;

    /* renamed from: b, reason: collision with root package name */
    private final ILastKnownUpdater f3642b;

    /* renamed from: c, reason: collision with root package name */
    private final UpdateConditionsChecker f3643c;

    /* renamed from: d, reason: collision with root package name */
    private final a f3644d = new a(this);

    /* renamed from: e, reason: collision with root package name */
    private final b f3645e = new b(this);

    public LocationDataCacheUpdateScheduler(ICommonExecutor iCommonExecutor, ILastKnownUpdater iLastKnownUpdater, UpdateConditionsChecker updateConditionsChecker, String str) {
        this.f3641a = iCommonExecutor;
        this.f3642b = iLastKnownUpdater;
        this.f3643c = updateConditionsChecker;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.cache.CacheUpdateScheduler
    public void onStateUpdated() {
        this.f3641a.remove(this.f3644d);
        this.f3641a.executeDelayed(this.f3644d, 90L, TimeUnit.SECONDS);
    }

    @Override // io.appmetrica.analytics.coreapi.internal.cache.CacheUpdateScheduler
    public void scheduleUpdateIfNeededNow() {
        this.f3641a.execute(this.f3645e);
    }

    public void startUpdates() {
        onStateUpdated();
    }

    public void stopUpdates() {
        this.f3641a.remove(this.f3644d);
        this.f3641a.remove(this.f3645e);
    }
}
