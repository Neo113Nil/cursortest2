package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.coreapi.internal.data.ProtobufConverter;
import io.appmetrica.analytics.idsync.internal.model.IdSyncConfig;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class e implements ProtobufConverter {

    /* renamed from: a, reason: collision with root package name */
    public final x f3807a = new x();

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final o fromModel(IdSyncConfig idSyncConfig) {
        o oVar = new o();
        oVar.f3838a = idSyncConfig.getEnabled();
        n nVar = new n();
        nVar.f3833a = idSyncConfig.getLaunchDelay();
        int size = idSyncConfig.getRequests().size();
        m[] mVarArr = new m[size];
        for (int i2 = 0; i2 < size; i2++) {
            mVarArr[i2] = this.f3807a.fromModel(idSyncConfig.getRequests().get(i2));
        }
        nVar.f3834b = mVarArr;
        oVar.f3839b = nVar;
        return oVar;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final IdSyncConfig toModel(o oVar) {
        n nVar = oVar.f3839b;
        if (nVar == null) {
            nVar = new n();
        }
        boolean z2 = oVar.f3838a;
        long j2 = nVar.f3833a;
        m[] mVarArr = nVar.f3834b;
        ArrayList arrayList = new ArrayList(mVarArr.length);
        for (m mVar : mVarArr) {
            arrayList.add(this.f3807a.toModel(mVar));
        }
        return new IdSyncConfig(z2, j2, arrayList);
    }
}
