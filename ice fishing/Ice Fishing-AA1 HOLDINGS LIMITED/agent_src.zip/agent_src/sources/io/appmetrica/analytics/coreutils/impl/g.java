package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class g extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3618a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f3619b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(Context context, String str) {
        super(0);
        this.f3618a = context;
        this.f3619b = str;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return Boolean.valueOf(this.f3618a.getPackageManager().hasSystemFeature(this.f3619b));
    }
}
