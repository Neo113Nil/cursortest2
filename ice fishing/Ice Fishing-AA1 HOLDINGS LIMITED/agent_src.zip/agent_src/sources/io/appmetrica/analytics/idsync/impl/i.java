package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.modulesapi.internal.service.ServiceContext;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public final ServiceContext f3817a;

    /* renamed from: b, reason: collision with root package name */
    public final j f3818b = new j();

    public i(ServiceContext serviceContext) {
        this.f3817a = serviceContext;
    }
}
