package io.appmetrica.analytics.ndkcrashesapi.internal;

/* loaded from: classes.dex */
public final class NativeCrashServiceConfig {

    /* renamed from: a, reason: collision with root package name */
    private final String f7203a;

    public NativeCrashServiceConfig(String str) {
        this.f7203a = str;
    }

    public final String getNativeCrashFolder() {
        return this.f7203a;
    }
}
