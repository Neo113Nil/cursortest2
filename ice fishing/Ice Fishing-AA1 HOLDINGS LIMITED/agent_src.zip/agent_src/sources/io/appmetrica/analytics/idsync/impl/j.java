package io.appmetrica.analytics.idsync.impl;

import android.util.Base64;
import java.util.Collection;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class j {
    public static String a(y yVar) {
        String encodeToString;
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("type", yVar.f3852a);
        jSONObject.put("url", yVar.f3854c);
        jSONObject.put("responseCode", yVar.f3856e);
        byte[] bArr = yVar.f3857f;
        try {
            encodeToString = new String(bArr, x1.a.f8290a);
        } catch (Throwable unused) {
            encodeToString = Base64.encodeToString(bArr, 0);
        }
        jSONObject.put("responseBody", encodeToString);
        Map map = yVar.f3858g;
        JSONObject jSONObject2 = new JSONObject();
        for (Map.Entry entry : map.entrySet()) {
            jSONObject2.putOpt((String) entry.getKey(), new JSONArray((Collection) entry.getValue()));
        }
        jSONObject.put("responseHeaders", jSONObject2);
        return jSONObject.toString();
    }
}
