package io.appmetrica.analytics.coreutils.impl;

import android.content.ComponentName;
import android.content.Context;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class f extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3615a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ComponentName f3616b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3617c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(Context context, ComponentName componentName, int i2) {
        super(0);
        this.f3615a = context;
        this.f3616b = componentName;
        this.f3617c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3615a.getPackageManager().getServiceInfo(this.f3616b, this.f3617c);
    }
}
