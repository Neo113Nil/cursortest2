package io.appmetrica.analytics.coreutils.internal.logger;

import android.text.TextUtils;
import io.appmetrica.analytics.coreutils.internal.ApiKeyUtils;
import io.appmetrica.analytics.logger.appmetrica.internal.PublicLogger;
import java.util.HashMap;

/* loaded from: classes.dex */
public abstract class LoggerStorage {

    /* renamed from: a, reason: collision with root package name */
    private static HashMap f3654a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    private static final Object f3655b = new Object();

    /* renamed from: c, reason: collision with root package name */
    private static volatile PublicLogger f3656c = PublicLogger.getAnonymousInstance();

    public static PublicLogger getMainPublicOrAnonymousLogger() {
        return f3656c;
    }

    public static PublicLogger getOrCreateMainPublicLogger(String str) {
        f3656c = getOrCreatePublicLogger(str);
        return f3656c;
    }

    public static PublicLogger getOrCreatePublicLogger(String str) {
        if (TextUtils.isEmpty(str)) {
            return PublicLogger.getAnonymousInstance();
        }
        PublicLogger publicLogger = (PublicLogger) f3654a.get(str);
        if (publicLogger == null) {
            synchronized (f3655b) {
                try {
                    publicLogger = (PublicLogger) f3654a.get(str);
                    if (publicLogger == null) {
                        publicLogger = new PublicLogger(ApiKeyUtils.createPartialApiKey(str));
                        f3654a.put(str, publicLogger);
                    }
                } finally {
                }
            }
        }
        return publicLogger;
    }

    public static void unsetPublicLoggers() {
        f3654a = new HashMap();
        f3656c = PublicLogger.getAnonymousInstance();
    }
}
