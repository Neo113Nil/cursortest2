package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.protobuf.nano.CodedInputByteBufferNano;
import io.appmetrica.analytics.protobuf.nano.CodedOutputByteBufferNano;
import io.appmetrica.analytics.protobuf.nano.InternalNano;
import io.appmetrica.analytics.protobuf.nano.MessageNano;
import io.appmetrica.analytics.protobuf.nano.WireFormatNano;

/* loaded from: classes.dex */
public final class o extends MessageNano {

    /* renamed from: c, reason: collision with root package name */
    public static final int f3835c = 0;

    /* renamed from: d, reason: collision with root package name */
    public static final int f3836d = 1;

    /* renamed from: e, reason: collision with root package name */
    public static volatile o[] f3837e;

    /* renamed from: a, reason: collision with root package name */
    public boolean f3838a;

    /* renamed from: b, reason: collision with root package name */
    public n f3839b;

    public o() {
        a();
    }

    public static o[] b() {
        if (f3837e == null) {
            synchronized (InternalNano.LAZY_INIT_LOCK) {
                try {
                    if (f3837e == null) {
                        f3837e = new o[0];
                    }
                } finally {
                }
            }
        }
        return f3837e;
    }

    public final o a() {
        this.f3838a = false;
        this.f3839b = null;
        this.cachedSize = -1;
        return this;
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    public final int computeSerializedSize() {
        int computeSerializedSize = super.computeSerializedSize();
        boolean z2 = this.f3838a;
        if (z2) {
            computeSerializedSize += CodedOutputByteBufferNano.computeBoolSize(1, z2);
        }
        n nVar = this.f3839b;
        return nVar != null ? computeSerializedSize + CodedOutputByteBufferNano.computeMessageSize(2, nVar) : computeSerializedSize;
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    public final void writeTo(CodedOutputByteBufferNano codedOutputByteBufferNano) {
        boolean z2 = this.f3838a;
        if (z2) {
            codedOutputByteBufferNano.writeBool(1, z2);
        }
        n nVar = this.f3839b;
        if (nVar != null) {
            codedOutputByteBufferNano.writeMessage(2, nVar);
        }
        super.writeTo(codedOutputByteBufferNano);
    }

    @Override // io.appmetrica.analytics.protobuf.nano.MessageNano
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final o mergeFrom(CodedInputByteBufferNano codedInputByteBufferNano) {
        while (true) {
            int readTag = codedInputByteBufferNano.readTag();
            if (readTag == 0) {
                return this;
            }
            if (readTag == 8) {
                this.f3838a = codedInputByteBufferNano.readBool();
            } else if (readTag != 18) {
                if (!WireFormatNano.parseUnknownField(codedInputByteBufferNano, readTag)) {
                    return this;
                }
            } else {
                if (this.f3839b == null) {
                    this.f3839b = new n();
                }
                codedInputByteBufferNano.readMessage(this.f3839b);
            }
        }
    }

    public static o b(CodedInputByteBufferNano codedInputByteBufferNano) {
        return new o().mergeFrom(codedInputByteBufferNano);
    }

    public static o a(byte[] bArr) {
        return (o) MessageNano.mergeFrom(new o(), bArr);
    }
}
