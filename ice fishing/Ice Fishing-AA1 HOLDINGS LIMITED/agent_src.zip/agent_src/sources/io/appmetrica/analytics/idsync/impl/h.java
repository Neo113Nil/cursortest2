package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.coreapi.internal.executors.IHandlerExecutor;
import io.appmetrica.analytics.idsync.internal.model.IdSyncConfig;
import io.appmetrica.analytics.modulesapi.internal.service.ServiceContext;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final ServiceContext f3810a;

    /* renamed from: c, reason: collision with root package name */
    public final IHandlerExecutor f3812c;

    /* renamed from: d, reason: collision with root package name */
    public final p f3813d;

    /* renamed from: e, reason: collision with root package name */
    public volatile IdSyncConfig f3814e;

    /* renamed from: f, reason: collision with root package name */
    public volatile boolean f3815f;

    /* renamed from: b, reason: collision with root package name */
    public final long f3811b = TimeUnit.MINUTES.toMillis(1);

    /* renamed from: g, reason: collision with root package name */
    public final f f3816g = new f(this);

    public h(ServiceContext serviceContext) {
        this.f3810a = serviceContext;
        this.f3812c = serviceContext.getExecutorProvider().getModuleExecutor();
        this.f3813d = new p(serviceContext, new B(serviceContext.getServiceStorageProvider().modulePreferences("id-sync")));
    }

    public static boolean a(IdSyncConfig idSyncConfig) {
        idSyncConfig.getEnabled();
        return idSyncConfig.getEnabled() && !idSyncConfig.getRequests().isEmpty();
    }

    public final synchronized void b(IdSyncConfig idSyncConfig) {
        try {
            if (!kotlin.jvm.internal.j.a(this.f3814e, idSyncConfig)) {
                this.f3814e = idSyncConfig;
                if (a(idSyncConfig) && !this.f3815f) {
                    this.f3810a.getActivationBarrier().subscribe(idSyncConfig.getLaunchDelay(), this.f3812c, new g(this));
                    this.f3815f = true;
                } else if (!a(idSyncConfig) && this.f3815f) {
                    this.f3815f = false;
                    IHandlerExecutor iHandlerExecutor = this.f3812c;
                    f fVar = this.f3816g;
                    if (fVar == null) {
                        kotlin.jvm.internal.j.g("syncRunnable");
                        throw null;
                    }
                    iHandlerExecutor.remove(fVar);
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
