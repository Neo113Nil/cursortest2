package io.appmetrica.analytics.billingv8.impl;

import g1.C0137i;
import java.util.LinkedHashMap;
import java.util.Map;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class h extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Map f3529a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Map f3530b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ i f3531c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(LinkedHashMap linkedHashMap, Map map, i iVar) {
        super(0);
        this.f3529a = linkedHashMap;
        this.f3530b = map;
        this.f3531c = iVar;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        Map map = this.f3529a;
        Map map2 = this.f3530b;
        i iVar = this.f3531c;
        m.a(map, map2, iVar.f3535d, iVar.f3534c.getBillingInfoManager());
        return C0137i.f2940a;
    }
}
