package io.appmetrica.analytics.idsync.impl;

import io.appmetrica.analytics.coreapi.internal.io.SslSocketFactoryProvider;

/* loaded from: classes.dex */
public final class q {

    /* renamed from: a, reason: collision with root package name */
    public final SslSocketFactoryProvider f3846a;

    /* renamed from: b, reason: collision with root package name */
    public final p f3847b;

    public q(SslSocketFactoryProvider sslSocketFactoryProvider, p pVar) {
        this.f3846a = sslSocketFactoryProvider;
        this.f3847b = pVar;
    }
}
