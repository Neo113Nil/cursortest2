package io.appmetrica.analytics.idsync.impl;

import h1.AbstractC0180f;
import h1.AbstractC0189o;
import h1.AbstractC0190p;
import io.appmetrica.analytics.modulesapi.internal.common.ModulePreferences;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class B {

    /* renamed from: a, reason: collision with root package name */
    public final ModulePreferences f3787a;

    /* renamed from: b, reason: collision with root package name */
    public final A f3788b = new A();

    /* renamed from: c, reason: collision with root package name */
    public final String f3789c = "request_state";

    /* renamed from: d, reason: collision with root package name */
    public final Map f3790d = AbstractC0189o.g0(a());

    public B(ModulePreferences modulePreferences) {
        this.f3787a = modulePreferences;
    }

    public final LinkedHashMap a() {
        List<z> model = this.f3788b.toModel(this.f3787a.getString(this.f3789c, null));
        int Z2 = AbstractC0190p.Z(AbstractC0180f.e0(model));
        if (Z2 < 16) {
            Z2 = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(Z2);
        for (Object obj : model) {
            linkedHashMap.put(((z) obj).f3859a, obj);
        }
        return linkedHashMap;
    }
}
