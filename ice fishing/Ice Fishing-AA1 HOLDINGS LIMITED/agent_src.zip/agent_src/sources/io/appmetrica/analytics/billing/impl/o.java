package io.appmetrica.analytics.billing.impl;

import io.appmetrica.analytics.billinginterface.internal.Period;
import io.appmetrica.analytics.billinginterface.internal.ProductInfo;
import io.appmetrica.analytics.billinginterface.internal.ProductType;
import io.appmetrica.analytics.protobuf.nano.MessageNano;
import java.nio.charset.Charset;
import java.util.Currency;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public final class o {
    public static byte[] a(ProductInfo productInfo) {
        String str;
        z zVar = new z();
        zVar.f3424a = productInfo.quantity;
        zVar.f3429f = productInfo.priceMicros;
        try {
            str = Currency.getInstance(productInfo.priceCurrency).getCurrencyCode();
        } catch (Throwable unused) {
            str = "";
        }
        Charset charset = x1.a.f8290a;
        zVar.f3425b = str.getBytes(charset);
        zVar.f3426c = productInfo.sku.getBytes(charset);
        u uVar = new u();
        uVar.f3390a = productInfo.purchaseOriginalJson.getBytes(charset);
        uVar.f3391b = productInfo.signature.getBytes(charset);
        zVar.f3428e = uVar;
        zVar.f3430g = true;
        zVar.f3431h = 1;
        int i2 = n.f3377a[productInfo.type.ordinal()];
        zVar.f3432i = (i2 == 1 || i2 != 2) ? 1 : 2;
        y yVar = new y();
        yVar.f3413a = productInfo.purchaseToken.getBytes(charset);
        yVar.f3414b = TimeUnit.MILLISECONDS.toSeconds(productInfo.purchaseTime);
        zVar.f3433j = yVar;
        if (productInfo.type == ProductType.SUBS) {
            x xVar = new x();
            xVar.f3406a = productInfo.autoRenewing;
            Period period = productInfo.subscriptionPeriod;
            if (period != null) {
                w wVar = new w();
                wVar.f3403a = period.number;
                int i3 = n.f3378b[period.timeUnit.ordinal()];
                wVar.f3404b = i3 != 1 ? i3 != 2 ? i3 != 3 ? i3 != 4 ? 0 : 4 : 3 : 2 : 1;
                xVar.f3407b = wVar;
            }
            v vVar = new v();
            vVar.f3393a = productInfo.introductoryPriceMicros;
            Period period2 = productInfo.introductoryPricePeriod;
            if (period2 != null) {
                w wVar2 = new w();
                wVar2.f3403a = period2.number;
                int i4 = n.f3378b[period2.timeUnit.ordinal()];
                wVar2.f3404b = i4 != 1 ? i4 != 2 ? i4 != 3 ? i4 != 4 ? 0 : 4 : 3 : 2 : 1;
                vVar.f3394b = wVar2;
            }
            vVar.f3395c = productInfo.introductoryPriceCycles;
            xVar.f3408c = vVar;
            zVar.f3434k = xVar;
        }
        return MessageNano.toByteArray(zVar);
    }
}
