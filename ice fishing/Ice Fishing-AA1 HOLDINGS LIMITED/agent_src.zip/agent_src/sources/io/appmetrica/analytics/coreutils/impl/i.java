package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import android.content.pm.PackageManager;
import io.appmetrica.analytics.coreutils.internal.AndroidUtils;
import io.appmetrica.analytics.coreutils.internal.services.PackageManagerUtilsTiramisu;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class i extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3623a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f3624b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(Context context, String str) {
        super(0);
        this.f3623a = context;
        this.f3624b = str;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        PackageManager packageManager = this.f3623a.getPackageManager();
        return AndroidUtils.isApiAchieved(33) ? PackageManagerUtilsTiramisu.INSTANCE.resolveContentProvider(packageManager, this.f3624b) : packageManager.resolveContentProvider(this.f3624b, 128);
    }
}
