package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PurchasesResponseListener;
import io.appmetrica.analytics.billinginterface.internal.config.BillingConfig;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import java.util.List;

/* loaded from: classes.dex */
public final class i implements PurchasesResponseListener {

    /* renamed from: a, reason: collision with root package name */
    public final BillingConfig f3532a;

    /* renamed from: b, reason: collision with root package name */
    public final BillingClient f3533b;

    /* renamed from: c, reason: collision with root package name */
    public final UtilsProvider f3534c;

    /* renamed from: d, reason: collision with root package name */
    public final String f3535d;

    /* renamed from: e, reason: collision with root package name */
    public final d f3536e;

    /* renamed from: f, reason: collision with root package name */
    public final n f3537f;

    public i(BillingConfig billingConfig, BillingClient billingClient, UtilsProvider utilsProvider, String str, d dVar, n nVar) {
        this.f3532a = billingConfig;
        this.f3533b = billingClient;
        this.f3534c = utilsProvider;
        this.f3535d = str;
        this.f3536e = dVar;
        this.f3537f = nVar;
    }

    public final void onQueryPurchasesResponse(BillingResult billingResult, List list) {
        this.f3534c.getWorkerExecutor().execute(new g(this, billingResult, list));
    }
}
