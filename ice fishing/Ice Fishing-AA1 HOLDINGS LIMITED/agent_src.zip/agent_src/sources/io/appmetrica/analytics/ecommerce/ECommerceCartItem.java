package io.appmetrica.analytics.ecommerce;

import io.appmetrica.analytics.impl.AbstractC0563no;
import java.math.BigDecimal;

/* loaded from: classes.dex */
public class ECommerceCartItem {

    /* renamed from: a, reason: collision with root package name */
    private final ECommerceProduct f3712a;

    /* renamed from: b, reason: collision with root package name */
    private final BigDecimal f3713b;

    /* renamed from: c, reason: collision with root package name */
    private final ECommercePrice f3714c;

    /* renamed from: d, reason: collision with root package name */
    private ECommerceReferrer f3715d;

    public ECommerceCartItem(ECommerceProduct eCommerceProduct, ECommercePrice eCommercePrice, long j2) {
        this(eCommerceProduct, eCommercePrice, AbstractC0563no.a(j2));
    }

    public ECommerceProduct getProduct() {
        return this.f3712a;
    }

    public BigDecimal getQuantity() {
        return this.f3713b;
    }

    public ECommerceReferrer getReferrer() {
        return this.f3715d;
    }

    public ECommercePrice getRevenue() {
        return this.f3714c;
    }

    public ECommerceCartItem setReferrer(ECommerceReferrer eCommerceReferrer) {
        this.f3715d = eCommerceReferrer;
        return this;
    }

    public String toString() {
        return "ECommerceCartItem{product=" + this.f3712a + ", quantity=" + this.f3713b + ", revenue=" + this.f3714c + ", referrer=" + this.f3715d + '}';
    }

    public ECommerceCartItem(ECommerceProduct eCommerceProduct, ECommercePrice eCommercePrice, double d2) {
        this(eCommerceProduct, eCommercePrice, new BigDecimal(AbstractC0563no.a(d2)));
    }

    public ECommerceCartItem(ECommerceProduct eCommerceProduct, ECommercePrice eCommercePrice, BigDecimal bigDecimal) {
        this.f3712a = eCommerceProduct;
        this.f3713b = bigDecimal;
        this.f3714c = eCommercePrice;
    }
}
