package io.appmetrica.analytics.idsync.impl;

import h1.AbstractC0177c;
import h1.AbstractC0178d;
import h1.AbstractC0190p;
import io.appmetrica.analytics.coreapi.internal.data.ProtobufConverter;
import io.appmetrica.analytics.idsync.internal.model.NetworkType;
import io.appmetrica.analytics.idsync.internal.model.Preconditions;
import io.appmetrica.analytics.idsync.internal.model.RequestConfig;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class x implements ProtobufConverter {
    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final m fromModel(RequestConfig requestConfig) {
        m mVar = new m();
        String type = requestConfig.getType();
        Charset charset = x1.a.f8290a;
        mVar.f3825a = type.getBytes(charset);
        l lVar = new l();
        lVar.f3823a = w.f3851a[requestConfig.getPreconditions().getNetworkType().ordinal()] != 1 ? 0 : 1;
        mVar.f3826b = lVar;
        mVar.f3827c = requestConfig.getUrl().getBytes(charset);
        Map<String, List<String>> headers = requestConfig.getHeaders();
        ArrayList arrayList = new ArrayList(headers.size());
        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            String key = entry.getKey();
            List<String> value = entry.getValue();
            k kVar = new k();
            kVar.f3820a = key.getBytes(x1.a.f8290a);
            int size = value.size();
            byte[][] bArr = new byte[size][];
            for (int i2 = 0; i2 < size; i2++) {
                bArr[i2] = value.get(i2).getBytes(x1.a.f8290a);
            }
            kVar.f3821b = bArr;
            arrayList.add(kVar);
        }
        Object[] array = arrayList.toArray(new k[0]);
        if (array == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
        }
        mVar.f3828d = (k[]) array;
        mVar.f3829e = requestConfig.getResendIntervalForValidResponse();
        mVar.f3830f = requestConfig.getResendIntervalForInvalidResponse();
        mVar.f3831g = AbstractC0178d.m0(requestConfig.getValidResponseCodes());
        return mVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:6:0x001b, code lost:
    
        if (r2 == null) goto L9;
     */
    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final RequestConfig toModel(m mVar) {
        NetworkType networkType;
        byte[] bArr = mVar.f3825a;
        Charset charset = x1.a.f8290a;
        String str = new String(bArr, charset);
        l lVar = mVar.f3826b;
        if (lVar != null) {
            if (lVar.f3823a == 1) {
                networkType = NetworkType.CELL;
            } else {
                networkType = NetworkType.ANY;
            }
        }
        networkType = NetworkType.ANY;
        Preconditions preconditions = new Preconditions(networkType);
        String str2 = new String(mVar.f3827c, charset);
        k[] kVarArr = mVar.f3828d;
        int Z2 = AbstractC0190p.Z(kVarArr.length);
        if (Z2 < 16) {
            Z2 = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(Z2);
        for (k kVar : kVarArr) {
            String str3 = new String(kVar.f3820a, x1.a.f8290a);
            byte[][] bArr2 = kVar.f3821b;
            ArrayList arrayList = new ArrayList(bArr2.length);
            for (byte[] bArr3 : bArr2) {
                arrayList.add(new String(bArr3, x1.a.f8290a));
            }
            linkedHashMap.put(str3, arrayList);
        }
        return new RequestConfig(str, str2, preconditions, linkedHashMap, mVar.f3829e, mVar.f3830f, AbstractC0177c.e0(mVar.f3831g));
    }
}
