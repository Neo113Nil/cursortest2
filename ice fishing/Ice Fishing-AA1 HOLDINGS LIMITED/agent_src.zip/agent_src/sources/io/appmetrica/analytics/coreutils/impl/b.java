package io.appmetrica.analytics.coreutils.impl;

import android.content.Context;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class b extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Context f3605a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f3606b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3607c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(Context context, String str, int i2) {
        super(0);
        this.f3605a = context;
        this.f3606b = str;
        this.f3607c = i2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        return this.f3605a.getPackageManager().getApplicationInfo(this.f3606b, this.f3607c);
    }
}
