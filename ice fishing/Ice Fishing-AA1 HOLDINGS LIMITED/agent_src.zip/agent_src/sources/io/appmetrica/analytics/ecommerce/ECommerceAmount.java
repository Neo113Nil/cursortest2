package io.appmetrica.analytics.ecommerce;

import A1.a;
import io.appmetrica.analytics.impl.AbstractC0563no;
import java.math.BigDecimal;

/* loaded from: classes.dex */
public class ECommerceAmount {

    /* renamed from: a, reason: collision with root package name */
    private final BigDecimal f3710a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3711b;

    public ECommerceAmount(long j2, String str) {
        this(AbstractC0563no.a(j2), str);
    }

    public BigDecimal getAmount() {
        return this.f3710a;
    }

    public String getUnit() {
        return this.f3711b;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ECommerceAmount{amount=");
        sb.append(this.f3710a);
        sb.append(", unit='");
        return a.m(sb, this.f3711b, "'}");
    }

    public ECommerceAmount(double d2, String str) {
        this(new BigDecimal(AbstractC0563no.a(d2)), str);
    }

    public ECommerceAmount(BigDecimal bigDecimal, String str) {
        this.f3710a = bigDecimal;
        this.f3711b = str;
    }
}
