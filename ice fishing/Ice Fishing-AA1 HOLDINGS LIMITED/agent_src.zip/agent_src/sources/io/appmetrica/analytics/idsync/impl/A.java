package io.appmetrica.analytics.idsync.impl;

import h1.AbstractC0180f;
import h1.C0186l;
import io.appmetrica.analytics.coreapi.internal.data.Converter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class A implements Converter {

    /* renamed from: a, reason: collision with root package name */
    public final String f3783a = "request_state";

    /* renamed from: b, reason: collision with root package name */
    public final String f3784b = "type";

    /* renamed from: c, reason: collision with root package name */
    public final String f3785c = "last_attempt";

    /* renamed from: d, reason: collision with root package name */
    public final String f3786d = "prev_attempt_result";

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [h1.l] */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.util.ArrayList] */
    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String fromModel(List<z> list) {
        ?? r2;
        JSONObject jSONObject;
        JSONObject jSONObject2 = new JSONObject();
        String str = this.f3783a;
        if (list != null) {
            r2 = new ArrayList(AbstractC0180f.e0(list));
            for (z zVar : list) {
                try {
                    jSONObject = new JSONObject();
                    jSONObject.put(this.f3784b, zVar.f3859a);
                    jSONObject.put(this.f3785c, zVar.f3860b);
                    jSONObject.put(this.f3786d, u.a(zVar.f3861c));
                } catch (Throwable unused) {
                    jSONObject = new JSONObject();
                }
                r2.add(jSONObject);
            }
        } else {
            r2 = C0186l.f3203a;
        }
        jSONObject2.put(str, new JSONArray((Collection) r2));
        return jSONObject2.toString();
    }

    @Override // io.appmetrica.analytics.coreapi.internal.data.Converter
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final List<z> toModel(String str) {
        JSONArray optJSONArray;
        z zVar;
        int i2;
        try {
            ArrayList arrayList = new ArrayList();
            if (str == null || (optJSONArray = new JSONObject(str).optJSONArray(this.f3783a)) == null) {
                return arrayList;
            }
            int length = optJSONArray.length();
            for (int i3 = 0; i3 < length; i3++) {
                JSONObject optJSONObject = optJSONArray.optJSONObject(i3);
                if (optJSONObject != null) {
                    try {
                        String string = optJSONObject.getString(this.f3784b);
                        long j2 = optJSONObject.getLong(this.f3785c);
                        String string2 = optJSONObject.getString(this.f3786d);
                        int[] b2 = v.b(4);
                        int length2 = b2.length;
                        int i4 = 0;
                        while (true) {
                            if (i4 >= length2) {
                                i2 = 0;
                                break;
                            }
                            i2 = b2[i4];
                            if (kotlin.jvm.internal.j.a(u.a(i2), string2)) {
                                break;
                            }
                            i4++;
                        }
                        if (i2 == 0) {
                            i2 = 1;
                        }
                        zVar = new z(string, j2, i2);
                    } catch (Throwable unused) {
                        zVar = null;
                    }
                    if (zVar != null) {
                        arrayList.add(zVar);
                    }
                }
            }
            return arrayList;
        } catch (Throwable unused2) {
            return C0186l.f3203a;
        }
    }
}
