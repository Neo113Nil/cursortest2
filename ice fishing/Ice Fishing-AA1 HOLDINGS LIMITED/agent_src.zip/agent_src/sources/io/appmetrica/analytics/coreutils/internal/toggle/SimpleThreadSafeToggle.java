package io.appmetrica.analytics.coreutils.internal.toggle;

import io.appmetrica.analytics.coreapi.internal.control.Toggle;
import io.appmetrica.analytics.coreapi.internal.control.ToggleObserver;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.internal.f;

/* loaded from: classes.dex */
public abstract class SimpleThreadSafeToggle implements Toggle {

    /* renamed from: a, reason: collision with root package name */
    private final String f3707a;

    /* renamed from: b, reason: collision with root package name */
    private boolean f3708b;

    /* renamed from: c, reason: collision with root package name */
    private final ArrayList f3709c;

    public SimpleThreadSafeToggle(boolean z2, String str) {
        this.f3707a = str;
        this.f3708b = z2;
        this.f3709c = new ArrayList();
    }

    @Override // io.appmetrica.analytics.coreapi.internal.control.Toggle
    public synchronized boolean getActualState() {
        return this.f3708b;
    }

    public final String getTag() {
        return this.f3707a;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.control.Toggle
    public synchronized void registerObserver(ToggleObserver toggleObserver, boolean z2) {
        this.f3709c.add(toggleObserver);
        if (z2) {
            toggleObserver.onStateChanged(getActualState());
        }
    }

    @Override // io.appmetrica.analytics.coreapi.internal.control.Toggle
    public synchronized void removeObserver(ToggleObserver toggleObserver) {
        this.f3709c.remove(toggleObserver);
    }

    public final synchronized void updateState(boolean z2) {
        if (z2 != getActualState()) {
            this.f3708b = z2;
            Iterator it = this.f3709c.iterator();
            while (it.hasNext()) {
                ((ToggleObserver) it.next()).onStateChanged(z2);
            }
        }
    }

    public /* synthetic */ SimpleThreadSafeToggle(boolean z2, String str, int i2, f fVar) {
        this((i2 & 1) != 0 ? false : z2, str);
    }
}
