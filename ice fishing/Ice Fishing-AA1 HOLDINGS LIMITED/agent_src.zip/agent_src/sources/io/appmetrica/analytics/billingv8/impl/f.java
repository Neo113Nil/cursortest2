package io.appmetrica.analytics.billingv8.impl;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.QueryProductDetailsResult;
import io.appmetrica.analytics.billinginterface.internal.library.UtilsProvider;
import java.util.List;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class f implements ProductDetailsResponseListener {

    /* renamed from: a, reason: collision with root package name */
    public final String f3519a;

    /* renamed from: b, reason: collision with root package name */
    public final BillingClient f3520b;

    /* renamed from: c, reason: collision with root package name */
    public final UtilsProvider f3521c;

    /* renamed from: d, reason: collision with root package name */
    public final InterfaceC0982a f3522d;

    /* renamed from: e, reason: collision with root package name */
    public final List f3523e;

    /* renamed from: f, reason: collision with root package name */
    public final d f3524f;

    /* renamed from: g, reason: collision with root package name */
    public final n f3525g;

    public f(String str, BillingClient billingClient, UtilsProvider utilsProvider, h hVar, List list, d dVar, n nVar) {
        this.f3519a = str;
        this.f3520b = billingClient;
        this.f3521c = utilsProvider;
        this.f3522d = hVar;
        this.f3523e = list;
        this.f3524f = dVar;
        this.f3525g = nVar;
    }

    public final void onProductDetailsResponse(BillingResult billingResult, QueryProductDetailsResult queryProductDetailsResult) {
        this.f3521c.getWorkerExecutor().execute(new e(this, billingResult, queryProductDetailsResult));
    }
}
