package io.appmetrica.analytics.ecommerce;

import java.util.List;

/* loaded from: classes.dex */
public class ECommercePrice {

    /* renamed from: a, reason: collision with root package name */
    private final ECommerceAmount f3719a;

    /* renamed from: b, reason: collision with root package name */
    private List f3720b;

    public ECommercePrice(ECommerceAmount eCommerceAmount) {
        this.f3719a = eCommerceAmount;
    }

    public ECommerceAmount getFiat() {
        return this.f3719a;
    }

    public List<ECommerceAmount> getInternalComponents() {
        return this.f3720b;
    }

    public ECommercePrice setInternalComponents(List<ECommerceAmount> list) {
        this.f3720b = list;
        return this;
    }

    public String toString() {
        return "ECommercePrice{fiat=" + this.f3719a + ", internalComponents=" + this.f3720b + '}';
    }
}
