package io.appmetrica.analytics.coreapi.internal.servicecomponents;

import java.util.Arrays;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class ServiceModuleCounterReport {
    public static final Companion Companion = new Companion(null);

    /* renamed from: a, reason: collision with root package name */
    private final String f3589a;

    /* renamed from: b, reason: collision with root package name */
    private final String f3590b;

    /* renamed from: c, reason: collision with root package name */
    private final byte[] f3591c;

    /* renamed from: d, reason: collision with root package name */
    private final int f3592d;

    public static final class Builder {

        /* renamed from: a, reason: collision with root package name */
        private String f3593a;

        /* renamed from: b, reason: collision with root package name */
        private String f3594b;

        /* renamed from: c, reason: collision with root package name */
        private byte[] f3595c;

        /* renamed from: d, reason: collision with root package name */
        private int f3596d;

        public final ServiceModuleCounterReport build() {
            return new ServiceModuleCounterReport(this.f3593a, this.f3594b, this.f3595c, this.f3596d);
        }

        public final Builder withName(String str) {
            this.f3593a = str;
            return this;
        }

        public final Builder withType(int i2) {
            this.f3596d = i2;
            return this;
        }

        public final Builder withValue(String str) {
            this.f3594b = str;
            return this;
        }

        public final Builder withValueBytes(byte[] bArr) {
            this.f3595c = bArr;
            return this;
        }
    }

    public static final class Companion {
        public /* synthetic */ Companion(f fVar) {
            this();
        }

        public final Builder newBuilder() {
            return new Builder();
        }

        private Companion() {
        }
    }

    public ServiceModuleCounterReport(String str, String str2, byte[] bArr, int i2) {
        this.f3589a = str;
        this.f3590b = str2;
        this.f3591c = bArr;
        this.f3592d = i2;
    }

    public static /* synthetic */ ServiceModuleCounterReport copy$default(ServiceModuleCounterReport serviceModuleCounterReport, String str, String str2, byte[] bArr, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = serviceModuleCounterReport.f3589a;
        }
        if ((i3 & 2) != 0) {
            str2 = serviceModuleCounterReport.f3590b;
        }
        if ((i3 & 4) != 0) {
            bArr = serviceModuleCounterReport.f3591c;
        }
        if ((i3 & 8) != 0) {
            i2 = serviceModuleCounterReport.f3592d;
        }
        return serviceModuleCounterReport.copy(str, str2, bArr, i2);
    }

    public final String component1() {
        return this.f3589a;
    }

    public final String component2() {
        return this.f3590b;
    }

    public final byte[] component3() {
        return this.f3591c;
    }

    public final int component4() {
        return this.f3592d;
    }

    public final ServiceModuleCounterReport copy(String str, String str2, byte[] bArr, int i2) {
        return new ServiceModuleCounterReport(str, str2, bArr, i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ServiceModuleCounterReport)) {
            return false;
        }
        ServiceModuleCounterReport serviceModuleCounterReport = (ServiceModuleCounterReport) obj;
        return this.f3592d == serviceModuleCounterReport.f3592d && j.a(this.f3589a, serviceModuleCounterReport.f3589a) && j.a(this.f3590b, serviceModuleCounterReport.f3590b) && Arrays.equals(this.f3591c, serviceModuleCounterReport.f3591c);
    }

    public final String getName() {
        return this.f3589a;
    }

    public final int getType() {
        return this.f3592d;
    }

    public final String getValue() {
        return this.f3590b;
    }

    public final byte[] getValueBytes() {
        return this.f3591c;
    }

    public int hashCode() {
        int i2 = this.f3592d * 31;
        String str = this.f3589a;
        int hashCode = (i2 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f3590b;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        byte[] bArr = this.f3591c;
        return hashCode2 + (bArr != null ? Arrays.hashCode(bArr) : 0);
    }

    public String toString() {
        return "ServiceModuleCounterReport(name=" + this.f3589a + ", value=" + this.f3590b + ", valueBytes=" + Arrays.toString(this.f3591c) + ", type=" + this.f3592d + ')';
    }
}
