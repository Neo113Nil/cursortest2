package io.appmetrica.analytics.ndkcrashesapi.internal;

import kotlin.jvm.internal.f;

/* loaded from: classes.dex */
public final class NativeCrash {

    /* renamed from: a, reason: collision with root package name */
    private final NativeCrashSource f7189a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7190b;

    /* renamed from: c, reason: collision with root package name */
    private final String f7191c;

    /* renamed from: d, reason: collision with root package name */
    private final String f7192d;

    /* renamed from: e, reason: collision with root package name */
    private final long f7193e;

    /* renamed from: f, reason: collision with root package name */
    private final String f7194f;

    public static final class Builder {

        /* renamed from: a, reason: collision with root package name */
        private final NativeCrashSource f7195a;

        /* renamed from: b, reason: collision with root package name */
        private final String f7196b;

        /* renamed from: c, reason: collision with root package name */
        private final String f7197c;

        /* renamed from: d, reason: collision with root package name */
        private final String f7198d;

        /* renamed from: e, reason: collision with root package name */
        private final long f7199e;

        /* renamed from: f, reason: collision with root package name */
        private final String f7200f;

        public Builder(NativeCrashSource nativeCrashSource, String str, String str2, String str3, long j2, String str4) {
            this.f7195a = nativeCrashSource;
            this.f7196b = str;
            this.f7197c = str2;
            this.f7198d = str3;
            this.f7199e = j2;
            this.f7200f = str4;
        }

        public final NativeCrash build() {
            return new NativeCrash(this.f7195a, this.f7196b, this.f7197c, this.f7198d, this.f7199e, this.f7200f, null);
        }
    }

    public /* synthetic */ NativeCrash(NativeCrashSource nativeCrashSource, String str, String str2, String str3, long j2, String str4, f fVar) {
        this(nativeCrashSource, str, str2, str3, j2, str4);
    }

    public final long getCreationTime() {
        return this.f7193e;
    }

    public final String getDumpFile() {
        return this.f7192d;
    }

    public final String getHandlerVersion() {
        return this.f7190b;
    }

    public final String getMetadata() {
        return this.f7194f;
    }

    public final NativeCrashSource getSource() {
        return this.f7189a;
    }

    public final String getUuid() {
        return this.f7191c;
    }

    private NativeCrash(NativeCrashSource nativeCrashSource, String str, String str2, String str3, long j2, String str4) {
        this.f7189a = nativeCrashSource;
        this.f7190b = str;
        this.f7191c = str2;
        this.f7192d = str3;
        this.f7193e = j2;
        this.f7194f = str4;
    }
}
