package io.appmetrica.analytics.coreapi.internal.identifiers;

import kotlin.jvm.internal.j;

/* loaded from: classes.dex */
public final class PlatformIdentifiers {

    /* renamed from: a, reason: collision with root package name */
    private final SimpleAdvertisingIdGetter f3568a;

    /* renamed from: b, reason: collision with root package name */
    private final AppSetIdProvider f3569b;

    public PlatformIdentifiers(SimpleAdvertisingIdGetter simpleAdvertisingIdGetter, AppSetIdProvider appSetIdProvider) {
        this.f3568a = simpleAdvertisingIdGetter;
        this.f3569b = appSetIdProvider;
    }

    public static /* synthetic */ PlatformIdentifiers copy$default(PlatformIdentifiers platformIdentifiers, SimpleAdvertisingIdGetter simpleAdvertisingIdGetter, AppSetIdProvider appSetIdProvider, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            simpleAdvertisingIdGetter = platformIdentifiers.f3568a;
        }
        if ((i2 & 2) != 0) {
            appSetIdProvider = platformIdentifiers.f3569b;
        }
        return platformIdentifiers.copy(simpleAdvertisingIdGetter, appSetIdProvider);
    }

    public final SimpleAdvertisingIdGetter component1() {
        return this.f3568a;
    }

    public final AppSetIdProvider component2() {
        return this.f3569b;
    }

    public final PlatformIdentifiers copy(SimpleAdvertisingIdGetter simpleAdvertisingIdGetter, AppSetIdProvider appSetIdProvider) {
        return new PlatformIdentifiers(simpleAdvertisingIdGetter, appSetIdProvider);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PlatformIdentifiers)) {
            return false;
        }
        PlatformIdentifiers platformIdentifiers = (PlatformIdentifiers) obj;
        return j.a(this.f3568a, platformIdentifiers.f3568a) && j.a(this.f3569b, platformIdentifiers.f3569b);
    }

    public final SimpleAdvertisingIdGetter getAdvIdentifiersProvider() {
        return this.f3568a;
    }

    public final AppSetIdProvider getAppSetIdProvider() {
        return this.f3569b;
    }

    public int hashCode() {
        return this.f3569b.hashCode() + (this.f3568a.hashCode() * 31);
    }

    public String toString() {
        return "PlatformIdentifiers(advIdentifiersProvider=" + this.f3568a + ", appSetIdProvider=" + this.f3569b + ')';
    }
}
