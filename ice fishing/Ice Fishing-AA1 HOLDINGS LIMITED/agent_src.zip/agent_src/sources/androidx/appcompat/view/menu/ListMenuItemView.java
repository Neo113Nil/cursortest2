package androidx.appcompat.view.menu;

import K.f;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import c.AbstractC0091a;
import com.watchfacestudio.pred01.R;
import g.j;
import g.k;
import g.q;
import io.appmetrica.analytics.coreutils.internal.io.Base64Utils;
import java.lang.reflect.Field;
import y.x;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements q, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a, reason: collision with root package name */
    public k f1856a;

    /* renamed from: b, reason: collision with root package name */
    public ImageView f1857b;

    /* renamed from: c, reason: collision with root package name */
    public RadioButton f1858c;

    /* renamed from: d, reason: collision with root package name */
    public TextView f1859d;

    /* renamed from: e, reason: collision with root package name */
    public CheckBox f1860e;

    /* renamed from: f, reason: collision with root package name */
    public TextView f1861f;

    /* renamed from: g, reason: collision with root package name */
    public ImageView f1862g;

    /* renamed from: h, reason: collision with root package name */
    public ImageView f1863h;

    /* renamed from: i, reason: collision with root package name */
    public LinearLayout f1864i;

    /* renamed from: j, reason: collision with root package name */
    public final Drawable f1865j;

    /* renamed from: k, reason: collision with root package name */
    public final int f1866k;

    /* renamed from: l, reason: collision with root package name */
    public final Context f1867l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1868m;

    /* renamed from: n, reason: collision with root package name */
    public final Drawable f1869n;

    /* renamed from: o, reason: collision with root package name */
    public final boolean f1870o;

    /* renamed from: p, reason: collision with root package name */
    public LayoutInflater f1871p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f1872q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        f J2 = f.J(getContext(), attributeSet, AbstractC0091a.f2434n, R.attr.listMenuViewStyle);
        this.f1865j = J2.z(5);
        TypedArray typedArray = (TypedArray) J2.f945c;
        this.f1866k = typedArray.getResourceId(1, -1);
        this.f1868m = typedArray.getBoolean(7, false);
        this.f1867l = context;
        this.f1869n = J2.z(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f1870o = obtainStyledAttributes.hasValue(0);
        J2.M();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f1871p == null) {
            this.f1871p = LayoutInflater.from(getContext());
        }
        return this.f1871p;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f1862g;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f1863h;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1863h.getLayoutParams();
        rect.top = this.f1863h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x005b, code lost:
    
        if (r0 == false) goto L28;
     */
    /* JADX WARN: Removed duplicated region for block: B:13:0x003f  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0125  */
    @Override // g.q
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void c(k kVar) {
        boolean z2;
        String sb;
        boolean z3;
        this.f1856a = kVar;
        int i2 = 0;
        setVisibility(kVar.isVisible() ? 0 : 8);
        setTitle(kVar.f2878e);
        setCheckable(kVar.isCheckable());
        if (kVar.f2887n.n()) {
            if ((kVar.f2887n.m() ? kVar.f2883j : kVar.f2881h) != 0) {
                z2 = true;
                kVar.f2887n.m();
                if (z2) {
                    k kVar2 = this.f1856a;
                    if (kVar2.f2887n.n()) {
                        if ((kVar2.f2887n.m() ? kVar2.f2883j : kVar2.f2881h) != 0) {
                            z3 = true;
                        }
                    }
                    z3 = false;
                }
                i2 = 8;
                if (i2 == 0) {
                    TextView textView = this.f1861f;
                    k kVar3 = this.f1856a;
                    char c2 = kVar3.f2887n.m() ? kVar3.f2883j : kVar3.f2881h;
                    if (c2 == 0) {
                        sb = "";
                    } else {
                        j jVar = kVar3.f2887n;
                        Resources resources = jVar.f2853a.getResources();
                        StringBuilder sb2 = new StringBuilder();
                        if (ViewConfiguration.get(jVar.f2853a).hasPermanentMenuKey()) {
                            sb2.append(resources.getString(R.string.abc_prepend_shortcut_label));
                        }
                        int i3 = jVar.m() ? kVar3.f2884k : kVar3.f2882i;
                        k.a(sb2, i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                        k.a(sb2, i3, Base64Utils.IO_BUFFER_SIZE, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                        k.a(sb2, i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                        k.a(sb2, i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                        k.a(sb2, i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                        k.a(sb2, i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                        if (c2 == '\b') {
                            sb2.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                        } else if (c2 == '\n') {
                            sb2.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                        } else if (c2 != ' ') {
                            sb2.append(c2);
                        } else {
                            sb2.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                        }
                        sb = sb2.toString();
                    }
                    textView.setText(sb);
                }
                if (this.f1861f.getVisibility() != i2) {
                    this.f1861f.setVisibility(i2);
                }
                setIcon(kVar.getIcon());
                setEnabled(kVar.isEnabled());
                setSubMenuArrowVisible(kVar.hasSubMenu());
                setContentDescription(kVar.f2890q);
            }
        }
        z2 = false;
        kVar.f2887n.m();
        if (z2) {
        }
        i2 = 8;
        if (i2 == 0) {
        }
        if (this.f1861f.getVisibility() != i2) {
        }
        setIcon(kVar.getIcon());
        setEnabled(kVar.isEnabled());
        setSubMenuArrowVisible(kVar.hasSubMenu());
        setContentDescription(kVar.f2890q);
    }

    @Override // g.q
    public k getItemData() {
        return this.f1856a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        Field field = x.f8355a;
        setBackground(this.f1865j);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f1859d = textView;
        int i2 = this.f1866k;
        if (i2 != -1) {
            textView.setTextAppearance(this.f1867l, i2);
        }
        this.f1861f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f1862g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f1869n);
        }
        this.f1863h = (ImageView) findViewById(R.id.group_divider);
        this.f1864i = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (this.f1857b != null && this.f1868m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1857b.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        View view;
        if (!z2 && this.f1858c == null && this.f1860e == null) {
            return;
        }
        if ((this.f1856a.f2896x & 4) != 0) {
            if (this.f1858c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1858c = radioButton;
                LinearLayout linearLayout = this.f1864i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1858c;
            view = this.f1860e;
        } else {
            if (this.f1860e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1860e = checkBox;
                LinearLayout linearLayout2 = this.f1864i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1860e;
            view = this.f1858c;
        }
        if (z2) {
            compoundButton.setChecked(this.f1856a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f1860e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f1858c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if ((this.f1856a.f2896x & 4) != 0) {
            if (this.f1858c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1858c = radioButton;
                LinearLayout linearLayout = this.f1864i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1858c;
        } else {
            if (this.f1860e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1860e = checkBox;
                LinearLayout linearLayout2 = this.f1864i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1860e;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f1872q = z2;
        this.f1868m = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f1863h;
        if (imageView != null) {
            imageView.setVisibility((this.f1870o || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1856a.f2887n.getClass();
        boolean z2 = this.f1872q;
        if (z2 || this.f1868m) {
            ImageView imageView = this.f1857b;
            if (imageView == null && drawable == null && !this.f1868m) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f1857b = imageView2;
                LinearLayout linearLayout = this.f1864i;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f1868m) {
                this.f1857b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f1857b;
            if (!z2) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f1857b.getVisibility() != 0) {
                this.f1857b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f1859d.getVisibility() != 8) {
                this.f1859d.setVisibility(8);
            }
        } else {
            this.f1859d.setText(charSequence);
            if (this.f1859d.getVisibility() != 0) {
                this.f1859d.setVisibility(0);
            }
        }
    }
}
