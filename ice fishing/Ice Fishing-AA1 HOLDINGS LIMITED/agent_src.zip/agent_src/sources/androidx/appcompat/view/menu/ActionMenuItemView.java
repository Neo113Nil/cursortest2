package androidx.appcompat.view.menu;

import a.AbstractC0059a;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import c.AbstractC0091a;
import g.a;
import g.b;
import g.i;
import g.j;
import g.k;
import g.q;
import h.C0168u;
import h.InterfaceC0158j;

/* loaded from: classes.dex */
public class ActionMenuItemView extends C0168u implements q, View.OnClickListener, InterfaceC0158j {

    /* renamed from: e, reason: collision with root package name */
    public k f1844e;

    /* renamed from: f, reason: collision with root package name */
    public CharSequence f1845f;

    /* renamed from: g, reason: collision with root package name */
    public Drawable f1846g;

    /* renamed from: h, reason: collision with root package name */
    public i f1847h;

    /* renamed from: i, reason: collision with root package name */
    public a f1848i;

    /* renamed from: j, reason: collision with root package name */
    public b f1849j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1850k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f1851l;

    /* renamed from: m, reason: collision with root package name */
    public final int f1852m;

    /* renamed from: n, reason: collision with root package name */
    public int f1853n;

    /* renamed from: o, reason: collision with root package name */
    public final int f1854o;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f1850k = e();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0091a.f2423c, 0, 0);
        this.f1852m = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f1854o = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f1853n = -1;
        setSaveEnabled(false);
    }

    @Override // h.InterfaceC0158j
    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // h.InterfaceC0158j
    public final boolean b() {
        return !TextUtils.isEmpty(getText()) && this.f1844e.getIcon() == null;
    }

    @Override // g.q
    public final void c(k kVar) {
        this.f1844e = kVar;
        setIcon(kVar.getIcon());
        setTitle(kVar.getTitleCondensed());
        setId(kVar.f2874a);
        setVisibility(kVar.isVisible() ? 0 : 8);
        setEnabled(kVar.isEnabled());
        if (kVar.hasSubMenu() && this.f1848i == null) {
            this.f1848i = new a(this);
        }
    }

    public final boolean e() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        return i2 >= 480 || (i2 >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    public final void f() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f1845f);
        if (this.f1846g != null && ((this.f1844e.f2897y & 4) != 4 || (!this.f1850k && !this.f1851l))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        setText(z4 ? this.f1845f : null);
        CharSequence charSequence = this.f1844e.f2890q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z4 ? null : this.f1844e.f2878e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f1844e.f2891r;
        if (TextUtils.isEmpty(charSequence2)) {
            AbstractC0059a.K(this, z4 ? null : this.f1844e.f2878e);
        } else {
            AbstractC0059a.K(this, charSequence2);
        }
    }

    @Override // g.q
    public k getItemData() {
        return this.f1844e;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i iVar = this.f1847h;
        if (iVar != null) {
            iVar.a(this.f1844e);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1850k = e();
        f();
    }

    @Override // h.C0168u, android.widget.TextView, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        boolean isEmpty = TextUtils.isEmpty(getText());
        if (!isEmpty && (i4 = this.f1853n) >= 0) {
            super.setPadding(i4, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        int i5 = this.f1852m;
        int min = mode == Integer.MIN_VALUE ? Math.min(size, i5) : i5;
        if (mode != 1073741824 && i5 > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i3);
        }
        if (!isEmpty || this.f1846g == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1846g.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        a aVar;
        if (this.f1844e.hasSubMenu() && (aVar = this.f1848i) != null && aVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f1851l != z2) {
            this.f1851l = z2;
            k kVar = this.f1844e;
            if (kVar != null) {
                j jVar = kVar.f2887n;
                jVar.f2863k = true;
                jVar.o(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1846g = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.f1854o;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (intrinsicHeight * (i2 / intrinsicWidth));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (intrinsicWidth * (i2 / intrinsicHeight));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, null, null, null);
        f();
    }

    public void setItemInvoker(i iVar) {
        this.f1847h = iVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i2, int i3, int i4, int i5) {
        this.f1853n = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(b bVar) {
        this.f1849j = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f1845f = charSequence;
        f();
    }
}
