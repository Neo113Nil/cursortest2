package androidx.appcompat.widget;

import K.f;
import Y0.i;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import c.AbstractC0091a;
import com.watchfacestudio.pred01.R;
import d.AbstractC0103a;
import f.C0125d;
import g.j;
import g.k;
import h.C0154f;
import h.C0157i;
import h.C0165q;
import h.C0168u;
import h.InterfaceC0171x;
import h.P;
import h.j0;
import h.k0;
import h.l0;
import h.m0;
import h.n0;
import h.o0;
import h.r;
import h.u0;
import java.lang.reflect.Field;
import java.util.ArrayList;
import y.x;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* renamed from: A, reason: collision with root package name */
    public ColorStateList f2014A;

    /* renamed from: B, reason: collision with root package name */
    public boolean f2015B;

    /* renamed from: C, reason: collision with root package name */
    public boolean f2016C;

    /* renamed from: D, reason: collision with root package name */
    public final ArrayList f2017D;

    /* renamed from: E, reason: collision with root package name */
    public final ArrayList f2018E;

    /* renamed from: F, reason: collision with root package name */
    public final int[] f2019F;
    public final i G;

    /* renamed from: H, reason: collision with root package name */
    public o0 f2020H;

    /* renamed from: I, reason: collision with root package name */
    public k0 f2021I;

    /* renamed from: J, reason: collision with root package name */
    public boolean f2022J;

    /* renamed from: K, reason: collision with root package name */
    public final C.b f2023K;

    /* renamed from: a, reason: collision with root package name */
    public ActionMenuView f2024a;

    /* renamed from: b, reason: collision with root package name */
    public C0168u f2025b;

    /* renamed from: c, reason: collision with root package name */
    public C0168u f2026c;

    /* renamed from: d, reason: collision with root package name */
    public C0165q f2027d;

    /* renamed from: e, reason: collision with root package name */
    public r f2028e;

    /* renamed from: f, reason: collision with root package name */
    public final Drawable f2029f;

    /* renamed from: g, reason: collision with root package name */
    public final CharSequence f2030g;

    /* renamed from: h, reason: collision with root package name */
    public C0165q f2031h;

    /* renamed from: i, reason: collision with root package name */
    public View f2032i;

    /* renamed from: j, reason: collision with root package name */
    public Context f2033j;

    /* renamed from: k, reason: collision with root package name */
    public int f2034k;

    /* renamed from: l, reason: collision with root package name */
    public int f2035l;

    /* renamed from: m, reason: collision with root package name */
    public int f2036m;

    /* renamed from: n, reason: collision with root package name */
    public final int f2037n;

    /* renamed from: o, reason: collision with root package name */
    public final int f2038o;

    /* renamed from: p, reason: collision with root package name */
    public int f2039p;

    /* renamed from: q, reason: collision with root package name */
    public int f2040q;

    /* renamed from: r, reason: collision with root package name */
    public int f2041r;

    /* renamed from: s, reason: collision with root package name */
    public int f2042s;
    public P t;

    /* renamed from: u, reason: collision with root package name */
    public int f2043u;

    /* renamed from: v, reason: collision with root package name */
    public int f2044v;

    /* renamed from: w, reason: collision with root package name */
    public final int f2045w;

    /* renamed from: x, reason: collision with root package name */
    public CharSequence f2046x;

    /* renamed from: y, reason: collision with root package name */
    public CharSequence f2047y;

    /* renamed from: z, reason: collision with root package name */
    public ColorStateList f2048z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f2045w = 8388627;
        this.f2017D = new ArrayList();
        this.f2018E = new ArrayList();
        this.f2019F = new int[2];
        this.G = new i(18, this);
        this.f2023K = new C.b(8, this);
        f J2 = f.J(getContext(), attributeSet, AbstractC0091a.t, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) J2.f945c;
        this.f2035l = typedArray.getResourceId(28, 0);
        this.f2036m = typedArray.getResourceId(19, 0);
        this.f2045w = typedArray.getInteger(0, 8388627);
        this.f2037n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f2042s = dimensionPixelOffset;
        this.f2041r = dimensionPixelOffset;
        this.f2040q = dimensionPixelOffset;
        this.f2039p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f2039p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f2040q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f2041r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f2042s = dimensionPixelOffset5;
        }
        this.f2038o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        P p2 = this.t;
        p2.f3023h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            p2.f3020e = dimensionPixelSize;
            p2.f3016a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            p2.f3021f = dimensionPixelSize2;
            p2.f3017b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            p2.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f2043u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f2044v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f2029f = J2.z(4);
        this.f2030g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f2033j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable z2 = J2.z(16);
        if (z2 != null) {
            setNavigationIcon(z2);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable z3 = J2.z(11);
        if (z3 != null) {
            setLogo(z3);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(J2.y(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(J2.y(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        J2.M();
    }

    public static l0 g() {
        l0 l0Var = new l0(-2, -2);
        l0Var.f3108b = 0;
        l0Var.f3107a = 8388627;
        return l0Var;
    }

    private MenuInflater getMenuInflater() {
        return new C0125d(getContext());
    }

    public static l0 h(ViewGroup.LayoutParams layoutParams) {
        boolean z2 = layoutParams instanceof l0;
        if (z2) {
            l0 l0Var = (l0) layoutParams;
            l0 l0Var2 = new l0(l0Var);
            l0Var2.f3108b = 0;
            l0Var2.f3108b = l0Var.f3108b;
            return l0Var2;
        }
        if (z2) {
            l0 l0Var3 = new l0((l0) layoutParams);
            l0Var3.f3108b = 0;
            return l0Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            l0 l0Var4 = new l0(layoutParams);
            l0Var4.f3108b = 0;
            return l0Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        l0 l0Var5 = new l0(marginLayoutParams);
        l0Var5.f3108b = 0;
        ((ViewGroup.MarginLayoutParams) l0Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) l0Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) l0Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) l0Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return l0Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i2) {
        Field field = x.f8355a;
        boolean z2 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        arrayList.clear();
        if (!z2) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                l0 l0Var = (l0) childAt.getLayoutParams();
                if (l0Var.f3108b == 0 && r(childAt) && i(l0Var.f3107a) == absoluteGravity) {
                    arrayList.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            l0 l0Var2 = (l0) childAt2.getLayoutParams();
            if (l0Var2.f3108b == 0 && r(childAt2) && i(l0Var2.f3107a) == absoluteGravity) {
                arrayList.add(childAt2);
            }
        }
    }

    public final void b(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        l0 g2 = layoutParams == null ? g() : !checkLayoutParams(layoutParams) ? h(layoutParams) : (l0) layoutParams;
        g2.f3108b = 1;
        if (!z2 || this.f2032i == null) {
            addView(view, g2);
        } else {
            view.setLayoutParams(g2);
            this.f2018E.add(view);
        }
    }

    public final void c() {
        if (this.f2031h == null) {
            C0165q c0165q = new C0165q(getContext());
            this.f2031h = c0165q;
            c0165q.setImageDrawable(this.f2029f);
            this.f2031h.setContentDescription(this.f2030g);
            l0 g2 = g();
            g2.f3107a = (this.f2037n & 112) | 8388611;
            g2.f3108b = 2;
            this.f2031h.setLayoutParams(g2);
            this.f2031h.setOnClickListener(new j0(this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof l0);
    }

    public final void d() {
        if (this.t == null) {
            P p2 = new P();
            p2.f3016a = 0;
            p2.f3017b = 0;
            p2.f3018c = Integer.MIN_VALUE;
            p2.f3019d = Integer.MIN_VALUE;
            p2.f3020e = 0;
            p2.f3021f = 0;
            p2.f3022g = false;
            p2.f3023h = false;
            this.t = p2;
        }
    }

    public final void e() {
        if (this.f2024a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f2024a = actionMenuView;
            actionMenuView.setPopupTheme(this.f2034k);
            this.f2024a.setOnMenuItemClickListener(this.G);
            this.f2024a.getClass();
            l0 g2 = g();
            g2.f3107a = (this.f2037n & 112) | 8388613;
            this.f2024a.setLayoutParams(g2);
            b(this.f2024a, false);
        }
        ActionMenuView actionMenuView2 = this.f2024a;
        if (actionMenuView2.f1918p == null) {
            j jVar = (j) actionMenuView2.getMenu();
            if (this.f2021I == null) {
                this.f2021I = new k0(this);
            }
            this.f2024a.setExpandedActionViewsExclusive(true);
            jVar.b(this.f2021I, this.f2033j);
        }
    }

    public final void f() {
        if (this.f2027d == null) {
            this.f2027d = new C0165q(getContext());
            l0 g2 = g();
            g2.f3107a = (this.f2037n & 112) | 8388611;
            this.f2027d.setLayoutParams(g2);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0165q c0165q = this.f2031h;
        if (c0165q != null) {
            return c0165q.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0165q c0165q = this.f2031h;
        if (c0165q != null) {
            return c0165q.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        P p2 = this.t;
        if (p2 != null) {
            return p2.f3022g ? p2.f3016a : p2.f3017b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f2044v;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        P p2 = this.t;
        if (p2 != null) {
            return p2.f3016a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        P p2 = this.t;
        if (p2 != null) {
            return p2.f3017b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        P p2 = this.t;
        if (p2 != null) {
            return p2.f3022g ? p2.f3017b : p2.f3016a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f2043u;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        j jVar;
        ActionMenuView actionMenuView = this.f2024a;
        return (actionMenuView == null || (jVar = actionMenuView.f1918p) == null || !jVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f2044v, 0));
    }

    public int getCurrentContentInsetLeft() {
        Field field = x.f8355a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        Field field = x.f8355a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f2043u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        r rVar = this.f2028e;
        if (rVar != null) {
            return rVar.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        r rVar = this.f2028e;
        if (rVar != null) {
            return rVar.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f2024a.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        C0165q c0165q = this.f2027d;
        if (c0165q != null) {
            return c0165q.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0165q c0165q = this.f2027d;
        if (c0165q != null) {
            return c0165q.getDrawable();
        }
        return null;
    }

    public C0157i getOuterActionMenuPresenter() {
        return null;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f2024a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f2033j;
    }

    public int getPopupTheme() {
        return this.f2034k;
    }

    public CharSequence getSubtitle() {
        return this.f2047y;
    }

    public final TextView getSubtitleTextView() {
        return this.f2026c;
    }

    public CharSequence getTitle() {
        return this.f2046x;
    }

    public int getTitleMarginBottom() {
        return this.f2042s;
    }

    public int getTitleMarginEnd() {
        return this.f2040q;
    }

    public int getTitleMarginStart() {
        return this.f2039p;
    }

    public int getTitleMarginTop() {
        return this.f2041r;
    }

    public final TextView getTitleTextView() {
        return this.f2025b;
    }

    public InterfaceC0171x getWrapper() {
        Drawable drawable;
        if (this.f2020H == null) {
            o0 o0Var = new o0();
            o0Var.f3131l = 0;
            o0Var.f3120a = this;
            o0Var.f3127h = getTitle();
            o0Var.f3128i = getSubtitle();
            o0Var.f3126g = o0Var.f3127h != null;
            o0Var.f3125f = getNavigationIcon();
            f J2 = f.J(getContext(), null, AbstractC0091a.f2421a, R.attr.actionBarStyle);
            o0Var.f3132m = J2.z(15);
            TypedArray typedArray = (TypedArray) J2.f945c;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                o0Var.f3126g = true;
                o0Var.f3127h = text;
                if ((o0Var.f3121b & 8) != 0) {
                    o0Var.f3120a.setTitle(text);
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                o0Var.f3128i = text2;
                if ((o0Var.f3121b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable z2 = J2.z(20);
            if (z2 != null) {
                o0Var.f3124e = z2;
                o0Var.c();
            }
            Drawable z3 = J2.z(17);
            if (z3 != null) {
                o0Var.f3123d = z3;
                o0Var.c();
            }
            if (o0Var.f3125f == null && (drawable = o0Var.f3132m) != null) {
                o0Var.f3125f = drawable;
                int i2 = o0Var.f3121b & 4;
                Toolbar toolbar = o0Var.f3120a;
                if (i2 != 0) {
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            o0Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View inflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = o0Var.f3122c;
                if (view != null && (o0Var.f3121b & 16) != 0) {
                    removeView(view);
                }
                o0Var.f3122c = inflate;
                if (inflate != null && (o0Var.f3121b & 16) != 0) {
                    addView(inflate);
                }
                o0Var.a(o0Var.f3121b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int max = Math.max(dimensionPixelOffset, 0);
                int max2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.t.a(max, max2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f2035l = resourceId2;
                C0168u c0168u = this.f2025b;
                if (c0168u != null) {
                    c0168u.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f2036m = resourceId3;
                C0168u c0168u2 = this.f2026c;
                if (c0168u2 != null) {
                    c0168u2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            J2.M();
            if (R.string.abc_action_bar_up_description != o0Var.f3131l) {
                o0Var.f3131l = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i3 = o0Var.f3131l;
                    o0Var.f3129j = i3 != 0 ? getContext().getString(i3) : null;
                    o0Var.b();
                }
            }
            o0Var.f3129j = getNavigationContentDescription();
            setNavigationOnClickListener(new j0(o0Var));
            this.f2020H = o0Var;
        }
        return this.f2020H;
    }

    public final int i(int i2) {
        Field field = x.f8355a;
        int layoutDirection = getLayoutDirection();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, layoutDirection) & 7;
        return (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) ? absoluteGravity : layoutDirection == 1 ? 5 : 3;
    }

    public final int j(View view, int i2) {
        l0 l0Var = (l0) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = l0Var.f3107a & 112;
        if (i4 != 16 && i4 != 48 && i4 != 80) {
            i4 = this.f2045w & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) l0Var).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = ((ViewGroup.MarginLayoutParams) l0Var).topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = ((ViewGroup.MarginLayoutParams) l0Var).bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final boolean m(View view) {
        return view.getParent() == this || this.f2018E.contains(view);
    }

    public final int n(View view, int i2, int i3, int[] iArr) {
        l0 l0Var = (l0) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) l0Var).leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int j2 = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, j2, max + measuredWidth, view.getMeasuredHeight() + j2);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) l0Var).rightMargin + max;
    }

    public final int o(View view, int i2, int i3, int[] iArr) {
        l0 l0Var = (l0) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) l0Var).rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int j2 = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, j2, max, view.getMeasuredHeight() + j2);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) l0Var).leftMargin);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f2023K);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f2016C = false;
        }
        if (!this.f2016C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f2016C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f2016C = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:113:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x011e  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x029b A[LOOP:0: B:40:0x0299->B:41:0x029b, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x02b8 A[LOOP:1: B:44:0x02b6->B:45:0x02b8, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x02d6 A[LOOP:2: B:48:0x02d4->B:49:0x02d6, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0317  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0325 A[LOOP:3: B:57:0x0323->B:58:0x0325, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0222  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        boolean r2;
        boolean r3;
        int i8;
        int i9;
        int i10;
        int i11;
        boolean z3;
        int i12;
        int i13;
        int i14;
        int paddingTop;
        int i15;
        int i16;
        int i17;
        int i18;
        int size;
        int i19;
        int i20;
        int size2;
        int i21;
        int size3;
        int i22;
        int i23;
        int size4;
        int i24;
        Field field = x.f8355a;
        boolean z4 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i25 = width - paddingRight;
        int[] iArr = this.f2019F;
        iArr[1] = 0;
        iArr[0] = 0;
        int minimumHeight = getMinimumHeight();
        int min = minimumHeight >= 0 ? Math.min(minimumHeight, i5 - i3) : 0;
        if (!r(this.f2027d)) {
            i6 = paddingLeft;
        } else {
            if (z4) {
                i7 = o(this.f2027d, i25, min, iArr);
                i6 = paddingLeft;
                if (r(this.f2031h)) {
                    if (z4) {
                        i7 = o(this.f2031h, i7, min, iArr);
                    } else {
                        i6 = n(this.f2031h, i6, min, iArr);
                    }
                }
                if (r(this.f2024a)) {
                    if (z4) {
                        i6 = n(this.f2024a, i6, min, iArr);
                    } else {
                        i7 = o(this.f2024a, i7, min, iArr);
                    }
                }
                int currentContentInsetLeft = getCurrentContentInsetLeft();
                int currentContentInsetRight = getCurrentContentInsetRight();
                iArr[0] = Math.max(0, currentContentInsetLeft - i6);
                iArr[1] = Math.max(0, currentContentInsetRight - (i25 - i7));
                int max = Math.max(i6, currentContentInsetLeft);
                int min2 = Math.min(i7, i25 - currentContentInsetRight);
                if (r(this.f2032i)) {
                    if (z4) {
                        min2 = o(this.f2032i, min2, min, iArr);
                    } else {
                        max = n(this.f2032i, max, min, iArr);
                    }
                }
                if (r(this.f2028e)) {
                    if (z4) {
                        min2 = o(this.f2028e, min2, min, iArr);
                    } else {
                        max = n(this.f2028e, max, min, iArr);
                    }
                }
                r2 = r(this.f2025b);
                r3 = r(this.f2026c);
                if (r2) {
                    i8 = paddingRight;
                    i9 = 0;
                } else {
                    l0 l0Var = (l0) this.f2025b.getLayoutParams();
                    i8 = paddingRight;
                    i9 = ((ViewGroup.MarginLayoutParams) l0Var).bottomMargin + this.f2025b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) l0Var).topMargin;
                }
                if (r3) {
                    i10 = width;
                } else {
                    l0 l0Var2 = (l0) this.f2026c.getLayoutParams();
                    i10 = width;
                    i9 += this.f2026c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) l0Var2).topMargin + ((ViewGroup.MarginLayoutParams) l0Var2).bottomMargin;
                }
                if (!r2 || r3) {
                    C0168u c0168u = !r2 ? this.f2025b : this.f2026c;
                    C0168u c0168u2 = !r3 ? this.f2026c : this.f2025b;
                    l0 l0Var3 = (l0) c0168u.getLayoutParams();
                    l0 l0Var4 = (l0) c0168u2.getLayoutParams();
                    if ((r2 || this.f2025b.getMeasuredWidth() <= 0) && (!r3 || this.f2026c.getMeasuredWidth() <= 0)) {
                        i11 = paddingLeft;
                        z3 = false;
                    } else {
                        i11 = paddingLeft;
                        z3 = true;
                    }
                    i12 = this.f2045w & 112;
                    i13 = min;
                    if (i12 != 48) {
                        i14 = max;
                        paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) l0Var3).topMargin + this.f2041r;
                    } else if (i12 != 80) {
                        int i26 = (((height - paddingTop2) - paddingBottom) - i9) / 2;
                        i14 = max;
                        int i27 = ((ViewGroup.MarginLayoutParams) l0Var3).topMargin + this.f2041r;
                        if (i26 < i27) {
                            i26 = i27;
                        } else {
                            int i28 = (((height - paddingBottom) - i9) - i26) - paddingTop2;
                            int i29 = ((ViewGroup.MarginLayoutParams) l0Var3).bottomMargin;
                            int i30 = this.f2042s;
                            if (i28 < i29 + i30) {
                                i26 = Math.max(0, i26 - ((((ViewGroup.MarginLayoutParams) l0Var4).bottomMargin + i30) - i28));
                            }
                        }
                        paddingTop = paddingTop2 + i26;
                    } else {
                        i14 = max;
                        paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) l0Var4).bottomMargin) - this.f2042s) - i9;
                    }
                    if (z4) {
                        int i31 = (z3 ? this.f2039p : 0) - iArr[0];
                        int max2 = Math.max(0, i31) + i14;
                        iArr[0] = Math.max(0, -i31);
                        if (r2) {
                            l0 l0Var5 = (l0) this.f2025b.getLayoutParams();
                            int measuredWidth = this.f2025b.getMeasuredWidth() + max2;
                            int measuredHeight = this.f2025b.getMeasuredHeight() + paddingTop;
                            this.f2025b.layout(max2, paddingTop, measuredWidth, measuredHeight);
                            i15 = measuredWidth + this.f2040q;
                            paddingTop = measuredHeight + ((ViewGroup.MarginLayoutParams) l0Var5).bottomMargin;
                        } else {
                            i15 = max2;
                        }
                        if (r3) {
                            int i32 = paddingTop + ((ViewGroup.MarginLayoutParams) ((l0) this.f2026c.getLayoutParams())).topMargin;
                            int measuredWidth2 = this.f2026c.getMeasuredWidth() + max2;
                            this.f2026c.layout(max2, i32, measuredWidth2, this.f2026c.getMeasuredHeight() + i32);
                            i16 = measuredWidth2 + this.f2040q;
                        } else {
                            i16 = max2;
                        }
                        max = z3 ? Math.max(i15, i16) : max2;
                    } else {
                        int i33 = (z3 ? this.f2039p : 0) - iArr[1];
                        min2 -= Math.max(0, i33);
                        iArr[1] = Math.max(0, -i33);
                        if (r2) {
                            l0 l0Var6 = (l0) this.f2025b.getLayoutParams();
                            int measuredWidth3 = min2 - this.f2025b.getMeasuredWidth();
                            int measuredHeight2 = this.f2025b.getMeasuredHeight() + paddingTop;
                            this.f2025b.layout(measuredWidth3, paddingTop, min2, measuredHeight2);
                            i17 = measuredWidth3 - this.f2040q;
                            paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) l0Var6).bottomMargin;
                        } else {
                            i17 = min2;
                        }
                        if (r3) {
                            int i34 = paddingTop + ((ViewGroup.MarginLayoutParams) ((l0) this.f2026c.getLayoutParams())).topMargin;
                            this.f2026c.layout(min2 - this.f2026c.getMeasuredWidth(), i34, min2, this.f2026c.getMeasuredHeight() + i34);
                            i18 = min2 - this.f2040q;
                        } else {
                            i18 = min2;
                        }
                        if (z3) {
                            min2 = Math.min(i17, i18);
                        }
                        max = i14;
                    }
                } else {
                    i11 = paddingLeft;
                    i13 = min;
                }
                ArrayList arrayList = this.f2017D;
                a(arrayList, 3);
                size = arrayList.size();
                i19 = max;
                for (i20 = 0; i20 < size; i20++) {
                    i19 = n((View) arrayList.get(i20), i19, i13, iArr);
                }
                int i35 = i13;
                a(arrayList, 5);
                size2 = arrayList.size();
                for (i21 = 0; i21 < size2; i21++) {
                    min2 = o((View) arrayList.get(i21), min2, i35, iArr);
                }
                a(arrayList, 1);
                int i36 = iArr[0];
                int i37 = iArr[1];
                size3 = arrayList.size();
                int i38 = i37;
                int i39 = i36;
                i22 = 0;
                int i40 = 0;
                while (i22 < size3) {
                    View view = (View) arrayList.get(i22);
                    l0 l0Var7 = (l0) view.getLayoutParams();
                    int i41 = ((ViewGroup.MarginLayoutParams) l0Var7).leftMargin - i39;
                    int i42 = ((ViewGroup.MarginLayoutParams) l0Var7).rightMargin - i38;
                    int max3 = Math.max(0, i41);
                    int max4 = Math.max(0, i42);
                    int max5 = Math.max(0, -i41);
                    int max6 = Math.max(0, -i42);
                    i40 += view.getMeasuredWidth() + max3 + max4;
                    i22++;
                    i38 = max6;
                    i39 = max5;
                }
                i23 = ((((i10 - i11) - i8) / 2) + i11) - (i40 / 2);
                int i43 = i40 + i23;
                if (i23 >= i19) {
                    i19 = i43 > min2 ? i23 - (i43 - min2) : i23;
                }
                size4 = arrayList.size();
                for (i24 = 0; i24 < size4; i24++) {
                    i19 = n((View) arrayList.get(i24), i19, i35, iArr);
                }
                arrayList.clear();
            }
            i6 = n(this.f2027d, paddingLeft, min, iArr);
        }
        i7 = i25;
        if (r(this.f2031h)) {
        }
        if (r(this.f2024a)) {
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - i6);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i25 - i7));
        int max7 = Math.max(i6, currentContentInsetLeft2);
        int min22 = Math.min(i7, i25 - currentContentInsetRight2);
        if (r(this.f2032i)) {
        }
        if (r(this.f2028e)) {
        }
        r2 = r(this.f2025b);
        r3 = r(this.f2026c);
        if (r2) {
        }
        if (r3) {
        }
        if (r2) {
        }
        if (!r2) {
        }
        if (!r3) {
        }
        l0 l0Var32 = (l0) c0168u.getLayoutParams();
        l0 l0Var42 = (l0) c0168u2.getLayoutParams();
        if (r2) {
        }
        i11 = paddingLeft;
        z3 = false;
        i12 = this.f2045w & 112;
        i13 = min;
        if (i12 != 48) {
        }
        if (z4) {
        }
        ArrayList arrayList2 = this.f2017D;
        a(arrayList2, 3);
        size = arrayList2.size();
        i19 = max7;
        while (i20 < size) {
        }
        int i352 = i13;
        a(arrayList2, 5);
        size2 = arrayList2.size();
        while (i21 < size2) {
        }
        a(arrayList2, 1);
        int i362 = iArr[0];
        int i372 = iArr[1];
        size3 = arrayList2.size();
        int i382 = i372;
        int i392 = i362;
        i22 = 0;
        int i402 = 0;
        while (i22 < size3) {
        }
        i23 = ((((i10 - i11) - i8) / 2) + i11) - (i402 / 2);
        int i432 = i402 + i23;
        if (i23 >= i19) {
        }
        size4 = arrayList2.size();
        while (i24 < size4) {
        }
        arrayList2.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        boolean a2 = u0.a(this);
        int i11 = !a2 ? 1 : 0;
        int i12 = 0;
        if (r(this.f2027d)) {
            q(this.f2027d, i2, 0, i3, this.f2038o);
            i4 = k(this.f2027d) + this.f2027d.getMeasuredWidth();
            i5 = Math.max(0, l(this.f2027d) + this.f2027d.getMeasuredHeight());
            i6 = View.combineMeasuredStates(0, this.f2027d.getMeasuredState());
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
        }
        if (r(this.f2031h)) {
            q(this.f2031h, i2, 0, i3, this.f2038o);
            i4 = k(this.f2031h) + this.f2031h.getMeasuredWidth();
            i5 = Math.max(i5, l(this.f2031h) + this.f2031h.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f2031h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i4);
        int max2 = Math.max(0, currentContentInsetStart - i4);
        int[] iArr = this.f2019F;
        iArr[a2 ? 1 : 0] = max2;
        if (r(this.f2024a)) {
            q(this.f2024a, i2, max, i3, this.f2038o);
            i7 = k(this.f2024a) + this.f2024a.getMeasuredWidth();
            i5 = Math.max(i5, l(this.f2024a) + this.f2024a.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f2024a.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max3 = max + Math.max(currentContentInsetEnd, i7);
        iArr[i11] = Math.max(0, currentContentInsetEnd - i7);
        if (r(this.f2032i)) {
            max3 += p(this.f2032i, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, l(this.f2032i) + this.f2032i.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f2032i.getMeasuredState());
        }
        if (r(this.f2028e)) {
            max3 += p(this.f2028e, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, l(this.f2028e) + this.f2028e.getMeasuredHeight());
            i6 = View.combineMeasuredStates(i6, this.f2028e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (((l0) childAt.getLayoutParams()).f3108b == 0 && r(childAt)) {
                max3 += p(childAt, i2, max3, i3, 0, iArr);
                i5 = Math.max(i5, l(childAt) + childAt.getMeasuredHeight());
                i6 = View.combineMeasuredStates(i6, childAt.getMeasuredState());
            }
        }
        int i14 = this.f2041r + this.f2042s;
        int i15 = this.f2039p + this.f2040q;
        if (r(this.f2025b)) {
            p(this.f2025b, i2, max3 + i15, i3, i14, iArr);
            int k2 = k(this.f2025b) + this.f2025b.getMeasuredWidth();
            i8 = l(this.f2025b) + this.f2025b.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i6, this.f2025b.getMeasuredState());
            i10 = k2;
        } else {
            i8 = 0;
            i9 = i6;
            i10 = 0;
        }
        if (r(this.f2026c)) {
            i10 = Math.max(i10, p(this.f2026c, i2, max3 + i15, i3, i8 + i14, iArr));
            i8 += l(this.f2026c) + this.f2026c.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i9, this.f2026c.getMeasuredState());
        }
        int max4 = Math.max(i5, i8);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max4;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max3 + i10, getSuggestedMinimumWidth()), i2, (-16777216) & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, i9 << 16);
        if (this.f2022J) {
            int childCount2 = getChildCount();
            for (int i16 = 0; i16 < childCount2; i16++) {
                View childAt2 = getChildAt(i16);
                if (!r(childAt2) || childAt2.getMeasuredWidth() <= 0 || childAt2.getMeasuredHeight() <= 0) {
                }
            }
            setMeasuredDimension(resolveSizeAndState, i12);
        }
        i12 = resolveSizeAndState2;
        setMeasuredDimension(resolveSizeAndState, i12);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof n0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        n0 n0Var = (n0) parcelable;
        super.onRestoreInstanceState(n0Var.f306a);
        ActionMenuView actionMenuView = this.f2024a;
        j jVar = actionMenuView != null ? actionMenuView.f1918p : null;
        int i2 = n0Var.f3112c;
        if (i2 != 0 && this.f2021I != null && jVar != null && (findItem = jVar.findItem(i2)) != null) {
            findItem.expandActionView();
        }
        if (n0Var.f3113d) {
            C.b bVar = this.f2023K;
            removeCallbacks(bVar);
            post(bVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        P p2 = this.t;
        boolean z2 = i2 == 1;
        if (z2 == p2.f3022g) {
            return;
        }
        p2.f3022g = z2;
        if (!p2.f3023h) {
            p2.f3016a = p2.f3020e;
            p2.f3017b = p2.f3021f;
            return;
        }
        if (z2) {
            int i3 = p2.f3019d;
            if (i3 == Integer.MIN_VALUE) {
                i3 = p2.f3020e;
            }
            p2.f3016a = i3;
            int i4 = p2.f3018c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = p2.f3021f;
            }
            p2.f3017b = i4;
            return;
        }
        int i5 = p2.f3018c;
        if (i5 == Integer.MIN_VALUE) {
            i5 = p2.f3020e;
        }
        p2.f3016a = i5;
        int i6 = p2.f3019d;
        if (i6 == Integer.MIN_VALUE) {
            i6 = p2.f3021f;
        }
        p2.f3017b = i6;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C0157i c0157i;
        C0154f c0154f;
        k kVar;
        n0 n0Var = new n0(super.onSaveInstanceState());
        k0 k0Var = this.f2021I;
        if (k0Var != null && (kVar = k0Var.f3099b) != null) {
            n0Var.f3112c = kVar.f2874a;
        }
        ActionMenuView actionMenuView = this.f2024a;
        n0Var.f3113d = (actionMenuView == null || (c0157i = actionMenuView.f1921s) == null || (c0154f = c0157i.f3092r) == null || !c0154f.b()) ? false : true;
        return n0Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f2015B = false;
        }
        if (!this.f2015B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f2015B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f2015B = false;
        }
        return true;
    }

    public final int p(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final void q(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean r(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(AbstractC0103a.a(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f2022J = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f2044v) {
            this.f2044v = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f2043u) {
            this.f2043u = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(AbstractC0103a.a(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(AbstractC0103a.a(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        f();
        this.f2027d.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f2024a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f2034k != i2) {
            this.f2034k = i2;
            if (i2 == 0) {
                this.f2033j = getContext();
            } else {
                this.f2033j = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f2042s = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f2040q = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f2039p = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f2041r = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        l0 l0Var = new l0(context, attributeSet);
        l0Var.f3107a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0091a.f2422b);
        l0Var.f3107a = obtainStyledAttributes.getInt(0, 0);
        obtainStyledAttributes.recycle();
        l0Var.f3108b = 0;
        return l0Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0165q c0165q = this.f2031h;
        if (c0165q != null) {
            c0165q.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f2031h.setImageDrawable(drawable);
        } else {
            C0165q c0165q = this.f2031h;
            if (c0165q != null) {
                c0165q.setImageDrawable(this.f2029f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f2028e == null) {
                this.f2028e = new r(getContext(), 0);
            }
            if (!m(this.f2028e)) {
                b(this.f2028e, true);
            }
        } else {
            r rVar = this.f2028e;
            if (rVar != null && m(rVar)) {
                removeView(this.f2028e);
                this.f2018E.remove(this.f2028e);
            }
        }
        r rVar2 = this.f2028e;
        if (rVar2 != null) {
            rVar2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f2028e == null) {
            this.f2028e = new r(getContext(), 0);
        }
        r rVar = this.f2028e;
        if (rVar != null) {
            rVar.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            f();
        }
        C0165q c0165q = this.f2027d;
        if (c0165q != null) {
            c0165q.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            f();
            if (!m(this.f2027d)) {
                b(this.f2027d, true);
            }
        } else {
            C0165q c0165q = this.f2027d;
            if (c0165q != null && m(c0165q)) {
                removeView(this.f2027d);
                this.f2018E.remove(this.f2027d);
            }
        }
        C0165q c0165q2 = this.f2027d;
        if (c0165q2 != null) {
            c0165q2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0168u c0168u = this.f2026c;
            if (c0168u != null && m(c0168u)) {
                removeView(this.f2026c);
                this.f2018E.remove(this.f2026c);
            }
        } else {
            if (this.f2026c == null) {
                Context context = getContext();
                C0168u c0168u2 = new C0168u(context, null);
                this.f2026c = c0168u2;
                c0168u2.setSingleLine();
                this.f2026c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f2036m;
                if (i2 != 0) {
                    this.f2026c.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f2014A;
                if (colorStateList != null) {
                    this.f2026c.setTextColor(colorStateList);
                }
            }
            if (!m(this.f2026c)) {
                b(this.f2026c, true);
            }
        }
        C0168u c0168u3 = this.f2026c;
        if (c0168u3 != null) {
            c0168u3.setText(charSequence);
        }
        this.f2047y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f2014A = colorStateList;
        C0168u c0168u = this.f2026c;
        if (c0168u != null) {
            c0168u.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0168u c0168u = this.f2025b;
            if (c0168u != null && m(c0168u)) {
                removeView(this.f2025b);
                this.f2018E.remove(this.f2025b);
            }
        } else {
            if (this.f2025b == null) {
                Context context = getContext();
                C0168u c0168u2 = new C0168u(context, null);
                this.f2025b = c0168u2;
                c0168u2.setSingleLine();
                this.f2025b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f2035l;
                if (i2 != 0) {
                    this.f2025b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f2048z;
                if (colorStateList != null) {
                    this.f2025b.setTextColor(colorStateList);
                }
            }
            if (!m(this.f2025b)) {
                b(this.f2025b, true);
            }
        }
        C0168u c0168u3 = this.f2025b;
        if (c0168u3 != null) {
            c0168u3.setText(charSequence);
        }
        this.f2046x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f2048z = colorStateList;
        C0168u c0168u = this.f2025b;
        if (c0168u != null) {
            c0168u.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(m0 m0Var) {
    }
}
