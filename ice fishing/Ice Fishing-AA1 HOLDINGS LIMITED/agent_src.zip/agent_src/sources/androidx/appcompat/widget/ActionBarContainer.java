package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import c.AbstractC0091a;
import com.watchfacestudio.pred01.R;
import h.C0149a;
import h.Q;
import java.lang.reflect.Field;
import y.x;

/* loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1873a;

    /* renamed from: b, reason: collision with root package name */
    public View f1874b;

    /* renamed from: c, reason: collision with root package name */
    public View f1875c;

    /* renamed from: d, reason: collision with root package name */
    public Drawable f1876d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f1877e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f1878f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f1879g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1880h;

    /* renamed from: i, reason: collision with root package name */
    public final int f1881i;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0149a c0149a = new C0149a(this);
        Field field = x.f8355a;
        setBackground(c0149a);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0091a.f2421a);
        boolean z2 = false;
        this.f1876d = obtainStyledAttributes.getDrawable(0);
        this.f1877e = obtainStyledAttributes.getDrawable(2);
        this.f1881i = obtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f1879g = true;
            this.f1878f = obtainStyledAttributes.getDrawable(1);
        }
        obtainStyledAttributes.recycle();
        if (!this.f1879g ? !(this.f1876d != null || this.f1877e != null) : this.f1878f == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1876d;
        if (drawable != null && drawable.isStateful()) {
            this.f1876d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f1877e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f1877e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f1878f;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f1878f.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1876d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f1877e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f1878f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f1874b = findViewById(R.id.action_bar);
        this.f1875c = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1873a || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        boolean z3 = true;
        if (this.f1879g) {
            Drawable drawable = this.f1878f;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z3 = false;
            }
        } else {
            if (this.f1876d == null) {
                z3 = false;
            } else if (this.f1874b.getVisibility() == 0) {
                this.f1876d.setBounds(this.f1874b.getLeft(), this.f1874b.getTop(), this.f1874b.getRight(), this.f1874b.getBottom());
            } else {
                View view = this.f1875c;
                if (view == null || view.getVisibility() != 0) {
                    this.f1876d.setBounds(0, 0, 0, 0);
                } else {
                    this.f1876d.setBounds(this.f1875c.getLeft(), this.f1875c.getTop(), this.f1875c.getRight(), this.f1875c.getBottom());
                }
            }
            this.f1880h = false;
        }
        if (z3) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        if (this.f1874b == null && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && (i4 = this.f1881i) >= 0) {
            i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i4, View.MeasureSpec.getSize(i3)), Integer.MIN_VALUE);
        }
        super.onMeasure(i2, i3);
        if (this.f1874b == null) {
            return;
        }
        View.MeasureSpec.getMode(i3);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f1876d;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1876d);
        }
        this.f1876d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1874b;
            if (view != null) {
                this.f1876d.setBounds(view.getLeft(), this.f1874b.getTop(), this.f1874b.getRight(), this.f1874b.getBottom());
            }
        }
        boolean z2 = false;
        if (!this.f1879g ? !(this.f1876d != null || this.f1877e != null) : this.f1878f == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f1878f;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f1878f);
        }
        this.f1878f = drawable;
        boolean z2 = this.f1879g;
        boolean z3 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z2 && (drawable2 = this.f1878f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z2 ? !(this.f1876d != null || this.f1877e != null) : this.f1878f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f1877e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1877e);
        }
        this.f1877e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f1880h && this.f1877e != null) {
                throw null;
            }
        }
        boolean z2 = false;
        if (!this.f1879g ? !(this.f1876d != null || this.f1877e != null) : this.f1878f == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z2) {
        this.f1873a = z2;
        setDescendantFocusability(z2 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z2 = i2 == 0;
        Drawable drawable = this.f1876d;
        if (drawable != null) {
            drawable.setVisible(z2, false);
        }
        Drawable drawable2 = this.f1877e;
        if (drawable2 != null) {
            drawable2.setVisible(z2, false);
        }
        Drawable drawable3 = this.f1878f;
        if (drawable3 != null) {
            drawable3.setVisible(z2, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1876d;
        boolean z2 = this.f1879g;
        return (drawable == drawable2 && !z2) || (drawable == this.f1877e && this.f1880h) || ((drawable == this.f1878f && z2) || super.verifyDrawable(drawable));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i2) {
        if (i2 != 0) {
            return super.startActionModeForChild(view, callback, i2);
        }
        return null;
    }

    public void setTabContainer(Q q2) {
    }
}
