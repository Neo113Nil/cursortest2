package androidx.appcompat.widget;

import P.C0055l;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import com.watchfacestudio.pred01.R;
import d.AbstractC0103a;
import h.C0150b;
import h.C0153e;
import h.InterfaceC0152d;
import h.InterfaceC0171x;
import h.RunnableC0151c;
import h.o0;
import h.u0;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import y.AbstractC1035n;
import y.InterfaceC1029h;
import y.InterfaceC1030i;
import y.x;

/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC1029h, InterfaceC1030i {

    /* renamed from: y, reason: collision with root package name */
    public static final int[] f1894y = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* renamed from: a, reason: collision with root package name */
    public int f1895a;

    /* renamed from: b, reason: collision with root package name */
    public ContentFrameLayout f1896b;

    /* renamed from: c, reason: collision with root package name */
    public ActionBarContainer f1897c;

    /* renamed from: d, reason: collision with root package name */
    public InterfaceC0171x f1898d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f1899e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1900f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1901g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1902h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f1903i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1904j;

    /* renamed from: k, reason: collision with root package name */
    public int f1905k;

    /* renamed from: l, reason: collision with root package name */
    public final Rect f1906l;

    /* renamed from: m, reason: collision with root package name */
    public final Rect f1907m;

    /* renamed from: n, reason: collision with root package name */
    public final Rect f1908n;

    /* renamed from: o, reason: collision with root package name */
    public final Rect f1909o;

    /* renamed from: p, reason: collision with root package name */
    public final Rect f1910p;

    /* renamed from: q, reason: collision with root package name */
    public final Rect f1911q;

    /* renamed from: r, reason: collision with root package name */
    public final Rect f1912r;

    /* renamed from: s, reason: collision with root package name */
    public OverScroller f1913s;
    public ViewPropertyAnimator t;

    /* renamed from: u, reason: collision with root package name */
    public final C0150b f1914u;

    /* renamed from: v, reason: collision with root package name */
    public final RunnableC0151c f1915v;

    /* renamed from: w, reason: collision with root package name */
    public final RunnableC0151c f1916w;

    /* renamed from: x, reason: collision with root package name */
    public final C0055l f1917x;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1906l = new Rect();
        this.f1907m = new Rect();
        this.f1908n = new Rect();
        this.f1909o = new Rect();
        this.f1910p = new Rect();
        this.f1911q = new Rect();
        this.f1912r = new Rect();
        this.f1914u = new C0150b(this);
        this.f1915v = new RunnableC0151c(this, 0);
        this.f1916w = new RunnableC0151c(this, 1);
        i(context);
        this.f1917x = new C0055l(2);
    }

    public static boolean g(View view, Rect rect, boolean z2) {
        boolean z3;
        C0153e c0153e = (C0153e) view.getLayoutParams();
        int i2 = ((ViewGroup.MarginLayoutParams) c0153e).leftMargin;
        int i3 = rect.left;
        if (i2 != i3) {
            ((ViewGroup.MarginLayoutParams) c0153e).leftMargin = i3;
            z3 = true;
        } else {
            z3 = false;
        }
        int i4 = ((ViewGroup.MarginLayoutParams) c0153e).topMargin;
        int i5 = rect.top;
        if (i4 != i5) {
            ((ViewGroup.MarginLayoutParams) c0153e).topMargin = i5;
            z3 = true;
        }
        int i6 = ((ViewGroup.MarginLayoutParams) c0153e).rightMargin;
        int i7 = rect.right;
        if (i6 != i7) {
            ((ViewGroup.MarginLayoutParams) c0153e).rightMargin = i7;
            z3 = true;
        }
        if (z2) {
            int i8 = ((ViewGroup.MarginLayoutParams) c0153e).bottomMargin;
            int i9 = rect.bottom;
            if (i8 != i9) {
                ((ViewGroup.MarginLayoutParams) c0153e).bottomMargin = i9;
                return true;
            }
        }
        return z3;
    }

    @Override // y.InterfaceC1029h
    public final void a(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // y.InterfaceC1029h
    public final void b(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(viewGroup, i2, i3, i4, i5);
        }
    }

    @Override // y.InterfaceC1029h
    public final void c(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0153e;
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.f1899e == null || this.f1900f) {
            return;
        }
        if (this.f1897c.getVisibility() == 0) {
            i2 = (int) (this.f1897c.getTranslationY() + this.f1897c.getBottom() + 0.5f);
        } else {
            i2 = 0;
        }
        this.f1899e.setBounds(0, i2, getWidth(), this.f1899e.getIntrinsicHeight() + i2);
        this.f1899e.draw(canvas);
    }

    @Override // y.InterfaceC1030i
    public final void e(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        b(viewGroup, i2, i3, i4, i5, i6);
    }

    @Override // y.InterfaceC1029h
    public final boolean f(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        j();
        Field field = x.f8355a;
        getWindowSystemUiVisibility();
        boolean g2 = g(this.f1897c, rect, false);
        Rect rect2 = this.f1909o;
        rect2.set(rect);
        Method method = u0.f3178a;
        Rect rect3 = this.f1906l;
        if (method != null) {
            try {
                method.invoke(this, rect2, rect3);
            } catch (Exception e2) {
                Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e2);
            }
        }
        Rect rect4 = this.f1910p;
        if (!rect4.equals(rect2)) {
            rect4.set(rect2);
            g2 = true;
        }
        Rect rect5 = this.f1907m;
        if (!rect5.equals(rect3)) {
            rect5.set(rect3);
            g2 = true;
        }
        if (g2) {
            requestLayout();
        }
        return true;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0153e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0153e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1897c;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0055l c0055l = this.f1917x;
        return c0055l.f1486c | c0055l.f1485b;
    }

    public CharSequence getTitle() {
        j();
        return ((o0) this.f1898d).f3120a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f1915v);
        removeCallbacks(this.f1916w);
        ViewPropertyAnimator viewPropertyAnimator = this.t;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f1894y);
        this.f1895a = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f1899e = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        this.f1900f = context.getApplicationInfo().targetSdkVersion < 19;
        this.f1913s = new OverScroller(context);
    }

    public final void j() {
        InterfaceC0171x wrapper;
        if (this.f1896b == null) {
            this.f1896b = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f1897c = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof InterfaceC0171x) {
                wrapper = (InterfaceC0171x) findViewById;
            } else {
                if (!(findViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(findViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) findViewById).getWrapper();
            }
            this.f1898d = wrapper;
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        Field field = x.f8355a;
        AbstractC1035n.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                C0153e c0153e = (C0153e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) c0153e).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) c0153e).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        j();
        measureChildWithMargins(this.f1897c, i2, 0, i3, 0);
        C0153e c0153e = (C0153e) this.f1897c.getLayoutParams();
        int i4 = 0;
        int max = Math.max(0, this.f1897c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0153e).leftMargin + ((ViewGroup.MarginLayoutParams) c0153e).rightMargin);
        int max2 = Math.max(0, this.f1897c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0153e).topMargin + ((ViewGroup.MarginLayoutParams) c0153e).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f1897c.getMeasuredState());
        Field field = x.f8355a;
        boolean z2 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z2) {
            i4 = this.f1895a;
            if (this.f1902h && this.f1897c.getTabContainer() != null) {
                i4 += this.f1895a;
            }
        } else if (this.f1897c.getVisibility() != 8) {
            i4 = this.f1897c.getMeasuredHeight();
        }
        Rect rect = this.f1906l;
        Rect rect2 = this.f1908n;
        rect2.set(rect);
        Rect rect3 = this.f1911q;
        rect3.set(this.f1909o);
        if (this.f1901g || z2) {
            rect3.top += i4;
            rect3.bottom = rect3.bottom;
        } else {
            rect2.top += i4;
            rect2.bottom = rect2.bottom;
        }
        g(this.f1896b, rect2, true);
        Rect rect4 = this.f1912r;
        if (!rect4.equals(rect3)) {
            rect4.set(rect3);
            this.f1896b.a(rect3);
        }
        measureChildWithMargins(this.f1896b, i2, 0, i3, 0);
        C0153e c0153e2 = (C0153e) this.f1896b.getLayoutParams();
        int max3 = Math.max(max, this.f1896b.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0153e2).leftMargin + ((ViewGroup.MarginLayoutParams) c0153e2).rightMargin);
        int max4 = Math.max(max2, this.f1896b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0153e2).topMargin + ((ViewGroup.MarginLayoutParams) c0153e2).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f1896b.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.f1903i || !z2) {
            return false;
        }
        this.f1913s.fling(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f1913s.getFinalY() > this.f1897c.getHeight()) {
            h();
            this.f1916w.run();
        } else {
            h();
            this.f1915v.run();
        }
        this.f1904j = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f1905k + i3;
        this.f1905k = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1917x.f1485b = i2;
        this.f1905k = getActionBarHideOffset();
        h();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f1897c.getVisibility() != 0) {
            return false;
        }
        return this.f1903i;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f1903i || this.f1904j) {
            return;
        }
        if (this.f1905k <= this.f1897c.getHeight()) {
            h();
            postDelayed(this.f1915v, 600L);
        } else {
            h();
            postDelayed(this.f1916w, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        j();
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
    }

    public void setActionBarHideOffset(int i2) {
        h();
        this.f1897c.setTranslationY(-Math.max(0, Math.min(i2, this.f1897c.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC0152d interfaceC0152d) {
        if (getWindowToken() != null) {
            throw null;
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f1902h = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f1903i) {
            this.f1903i = z2;
            if (z2) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        j();
        o0 o0Var = (o0) this.f1898d;
        o0Var.f3123d = i2 != 0 ? AbstractC0103a.a(o0Var.f3120a.getContext(), i2) : null;
        o0Var.c();
    }

    public void setLogo(int i2) {
        j();
        o0 o0Var = (o0) this.f1898d;
        o0Var.f3124e = i2 != 0 ? AbstractC0103a.a(o0Var.f3120a.getContext(), i2) : null;
        o0Var.c();
    }

    public void setOverlayMode(boolean z2) {
        this.f1901g = z2;
        this.f1900f = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    public void setWindowCallback(Window.Callback callback) {
        j();
        ((o0) this.f1898d).f3130k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        j();
        o0 o0Var = (o0) this.f1898d;
        if (o0Var.f3126g) {
            return;
        }
        o0Var.f3127h = charSequence;
        if ((o0Var.f3121b & 8) != 0) {
            o0Var.f3120a.setTitle(charSequence);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0153e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        j();
        o0 o0Var = (o0) this.f1898d;
        o0Var.f3123d = drawable;
        o0Var.c();
    }

    @Override // y.InterfaceC1029h
    public final void d(int i2, int i3, int[] iArr, int i4) {
    }
}
