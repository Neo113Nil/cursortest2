package androidx.appcompat.widget;

import K.f;
import a.AbstractC0059a;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import c.AbstractC0091a;
import com.watchfacestudio.pred01.R;
import f.InterfaceC0122a;
import h.AbstractC0142E;
import h.AbstractC0162n;
import h.C0143F;
import h.S;
import h.T;
import h.U;
import h.V;
import h.W;
import h.X;
import h.Y;
import h.Z;
import h.a0;
import h.b0;
import h.c0;
import h.e0;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import y.x;

/* loaded from: classes.dex */
public class SearchView extends AbstractC0142E implements InterfaceC0122a {

    /* renamed from: l0, reason: collision with root package name */
    public static final O1.c f1936l0;

    /* renamed from: A, reason: collision with root package name */
    public final Rect f1937A;

    /* renamed from: B, reason: collision with root package name */
    public final int[] f1938B;

    /* renamed from: C, reason: collision with root package name */
    public final int[] f1939C;

    /* renamed from: D, reason: collision with root package name */
    public final ImageView f1940D;

    /* renamed from: E, reason: collision with root package name */
    public final Drawable f1941E;

    /* renamed from: F, reason: collision with root package name */
    public final int f1942F;
    public final int G;

    /* renamed from: H, reason: collision with root package name */
    public final Intent f1943H;

    /* renamed from: I, reason: collision with root package name */
    public final Intent f1944I;

    /* renamed from: J, reason: collision with root package name */
    public final CharSequence f1945J;

    /* renamed from: K, reason: collision with root package name */
    public View.OnFocusChangeListener f1946K;

    /* renamed from: L, reason: collision with root package name */
    public View.OnClickListener f1947L;

    /* renamed from: R, reason: collision with root package name */
    public boolean f1948R;

    /* renamed from: S, reason: collision with root package name */
    public boolean f1949S;

    /* renamed from: T, reason: collision with root package name */
    public D.c f1950T;

    /* renamed from: U, reason: collision with root package name */
    public boolean f1951U;

    /* renamed from: V, reason: collision with root package name */
    public CharSequence f1952V;

    /* renamed from: W, reason: collision with root package name */
    public boolean f1953W;

    /* renamed from: a0, reason: collision with root package name */
    public boolean f1954a0;

    /* renamed from: b0, reason: collision with root package name */
    public int f1955b0;

    /* renamed from: c0, reason: collision with root package name */
    public boolean f1956c0;

    /* renamed from: d0, reason: collision with root package name */
    public CharSequence f1957d0;
    public boolean e0;
    public int f0;

    /* renamed from: g0, reason: collision with root package name */
    public SearchableInfo f1958g0;

    /* renamed from: h0, reason: collision with root package name */
    public Bundle f1959h0;

    /* renamed from: i0, reason: collision with root package name */
    public final T f1960i0;

    /* renamed from: j0, reason: collision with root package name */
    public final T f1961j0;
    public final WeakHashMap k0;

    /* renamed from: p, reason: collision with root package name */
    public final SearchAutoComplete f1962p;

    /* renamed from: q, reason: collision with root package name */
    public final View f1963q;

    /* renamed from: r, reason: collision with root package name */
    public final View f1964r;

    /* renamed from: s, reason: collision with root package name */
    public final View f1965s;
    public final ImageView t;

    /* renamed from: u, reason: collision with root package name */
    public final ImageView f1966u;

    /* renamed from: v, reason: collision with root package name */
    public final ImageView f1967v;

    /* renamed from: w, reason: collision with root package name */
    public final ImageView f1968w;

    /* renamed from: x, reason: collision with root package name */
    public final View f1969x;

    /* renamed from: y, reason: collision with root package name */
    public c0 f1970y;

    /* renamed from: z, reason: collision with root package name */
    public final Rect f1971z;

    public static class SearchAutoComplete extends AbstractC0162n {

        /* renamed from: d, reason: collision with root package name */
        public int f1972d;

        /* renamed from: e, reason: collision with root package name */
        public SearchView f1973e;

        /* renamed from: f, reason: collision with root package name */
        public boolean f1974f;

        /* renamed from: g, reason: collision with root package name */
        public final c f1975g;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1975g = new c(this);
            this.f1972d = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i2 = configuration.screenWidthDp;
            int i3 = configuration.screenHeightDp;
            if (i2 >= 960 && i3 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i2 < 600) {
                return (i2 < 640 || i3 < 480) ? 160 : 192;
            }
            return 192;
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.f1972d <= 0 || super.enoughToFilter();
        }

        @Override // h.AbstractC0162n, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f1974f) {
                c cVar = this.f1975g;
                removeCallbacks(cVar);
                post(cVar);
            }
            return onCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z2, int i2, Rect rect) {
            super.onFocusChanged(z2, i2, rect);
            SearchView searchView = this.f1973e;
            searchView.u(searchView.f1949S);
            searchView.post(searchView.f1960i0);
            if (searchView.f1962p.hasFocus()) {
                searchView.j();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i2, KeyEvent keyEvent) {
            if (i2 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f1973e.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i2, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z2) {
            Method method;
            super.onWindowFocusChanged(z2);
            if (z2 && this.f1973e.hasFocus() && getVisibility() == 0) {
                this.f1974f = true;
                Context context = getContext();
                O1.c cVar = SearchView.f1936l0;
                if (context.getResources().getConfiguration().orientation != 2 || (method = SearchView.f1936l0.f1368c) == null) {
                    return;
                }
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z2) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            c cVar = this.f1975g;
            if (!z2) {
                this.f1974f = false;
                removeCallbacks(cVar);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f1974f = true;
                    return;
                }
                this.f1974f = false;
                removeCallbacks(cVar);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f1973e = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i2) {
            super.setThreshold(i2);
            this.f1972d = i2;
        }
    }

    static {
        O1.c cVar = new O1.c();
        try {
            Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
            cVar.f1366a = declaredMethod;
            declaredMethod.setAccessible(true);
        } catch (NoSuchMethodException unused) {
        }
        try {
            Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
            cVar.f1367b = declaredMethod2;
            declaredMethod2.setAccessible(true);
        } catch (NoSuchMethodException unused2) {
        }
        try {
            Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
            cVar.f1368c = method;
            method.setAccessible(true);
        } catch (NoSuchMethodException unused3) {
        }
        f1936l0 = cVar;
    }

    public SearchView(Context context) {
        this(context, null);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f1962p;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.f1954a0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f1962p;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.f1954a0 = false;
    }

    public int getImeOptions() {
        return this.f1962p.getImeOptions();
    }

    public int getInputType() {
        return this.f1962p.getInputType();
    }

    public int getMaxWidth() {
        return this.f1955b0;
    }

    public CharSequence getQuery() {
        return this.f1962p.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f1952V;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f1958g0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f1945J : getContext().getText(this.f1958g0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.G;
    }

    public int getSuggestionRowLayout() {
        return this.f1942F;
    }

    public D.c getSuggestionsAdapter() {
        return this.f1950T;
    }

    public final Intent h(String str, Uri uri, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f1957d0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f1959h0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f1958g0.getSearchActivity());
        return intent;
    }

    public final Intent i(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f1959h0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void j() {
        int i2 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f1962p;
        if (i2 >= 29) {
            searchAutoComplete.refreshAutoCompleteResults();
            return;
        }
        O1.c cVar = f1936l0;
        Method method = cVar.f1366a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        Method method2 = cVar.f1367b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void k() {
        SearchAutoComplete searchAutoComplete = this.f1962p;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText("");
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.f1948R) {
            clearFocus();
            u(true);
        }
    }

    public final void l(int i2) {
        int i3;
        String h2;
        Cursor cursor = this.f1950T.f220c;
        if (cursor != null && cursor.moveToPosition(i2)) {
            Intent intent = null;
            try {
                int i4 = e0.f3047y;
                String h3 = e0.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (h3 == null) {
                    h3 = this.f1958g0.getSuggestIntentAction();
                }
                if (h3 == null) {
                    h3 = "android.intent.action.SEARCH";
                }
                String h4 = e0.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (h4 == null) {
                    h4 = this.f1958g0.getSuggestIntentData();
                }
                if (h4 != null && (h2 = e0.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                    h4 = h4 + "/" + Uri.encode(h2);
                }
                intent = h(h3, h4 == null ? null : Uri.parse(h4), e0.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), e0.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e2) {
                try {
                    i3 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i3 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i3 + " returned exception.", e2);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e3) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e3);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f1962p;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void m(int i2) {
        Editable text = this.f1962p.getText();
        Cursor cursor = this.f1950T.f220c;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i2)) {
            setQuery(text);
            return;
        }
        String c2 = this.f1950T.c(cursor);
        if (c2 != null) {
            setQuery(c2);
        } else {
            setQuery(text);
        }
    }

    public final void n(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public final void o() {
        SearchAutoComplete searchAutoComplete = this.f1962p;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f1958g0 != null) {
            getContext().startActivity(h("android.intent.action.SEARCH", null, null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.f1960i0);
        post(this.f1961j0);
        super.onDetachedFromWindow();
    }

    @Override // h.AbstractC0142E, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            int[] iArr = this.f1938B;
            SearchAutoComplete searchAutoComplete = this.f1962p;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.f1939C;
            getLocationInWindow(iArr2);
            int i6 = iArr[1] - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i7;
            int height = searchAutoComplete.getHeight() + i6;
            Rect rect = this.f1971z;
            rect.set(i7, i6, width, height);
            int i8 = rect.left;
            int i9 = rect.right;
            int i10 = i5 - i3;
            Rect rect2 = this.f1937A;
            rect2.set(i8, 0, i9, i10);
            c0 c0Var = this.f1970y;
            if (c0Var == null) {
                c0 c0Var2 = new c0(rect2, rect, searchAutoComplete);
                this.f1970y = c0Var2;
                setTouchDelegate(c0Var2);
            } else {
                c0Var.f3037b.set(rect2);
                Rect rect3 = c0Var.f3039d;
                rect3.set(rect2);
                int i11 = -c0Var.f3040e;
                rect3.inset(i11, i11);
                c0Var.f3038c.set(rect);
            }
        }
    }

    @Override // h.AbstractC0142E, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        if (this.f1949S) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            int i5 = this.f1955b0;
            size = i5 > 0 ? Math.min(i5, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f1955b0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i4 = this.f1955b0) > 0) {
            size = Math.min(i4, size);
        }
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b0 b0Var = (b0) parcelable;
        super.onRestoreInstanceState(b0Var.f306a);
        u(b0Var.f3033c);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        b0 b0Var = new b0(super.onSaveInstanceState());
        b0Var.f3033c = this.f1949S;
        return b0Var;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        post(this.f1960i0);
    }

    public final void p() {
        boolean isEmpty = TextUtils.isEmpty(this.f1962p.getText());
        int i2 = (!isEmpty || (this.f1948R && !this.e0)) ? 0 : 8;
        ImageView imageView = this.f1967v;
        imageView.setVisibility(i2);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(!isEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public final void q() {
        int[] iArr = this.f1962p.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f1964r.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f1965s.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void r() {
        Drawable drawable;
        CharSequence queryHint = getQueryHint();
        if (queryHint == null) {
            queryHint = "";
        }
        boolean z2 = this.f1948R;
        SearchAutoComplete searchAutoComplete = this.f1962p;
        if (z2 && (drawable = this.f1941E) != null) {
            int textSize = (int) (searchAutoComplete.getTextSize() * 1.25d);
            drawable.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i2, Rect rect) {
        if (this.f1954a0 || !isFocusable()) {
            return false;
        }
        if (this.f1949S) {
            return super.requestFocus(i2, rect);
        }
        boolean requestFocus = this.f1962p.requestFocus(i2, rect);
        if (requestFocus) {
            u(false);
        }
        return requestFocus;
    }

    public final void s() {
        this.f1965s.setVisibility(((this.f1951U || this.f1956c0) && !this.f1949S && (this.f1966u.getVisibility() == 0 || this.f1968w.getVisibility() == 0)) ? 0 : 8);
    }

    public void setAppSearchData(Bundle bundle) {
        this.f1959h0 = bundle;
    }

    public void setIconified(boolean z2) {
        if (z2) {
            k();
            return;
        }
        u(false);
        SearchAutoComplete searchAutoComplete = this.f1962p;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f1947L;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z2) {
        if (this.f1948R == z2) {
            return;
        }
        this.f1948R = z2;
        u(z2);
        r();
    }

    public void setImeOptions(int i2) {
        this.f1962p.setImeOptions(i2);
    }

    public void setInputType(int i2) {
        this.f1962p.setInputType(i2);
    }

    public void setMaxWidth(int i2) {
        this.f1955b0 = i2;
        requestLayout();
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f1946K = onFocusChangeListener;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f1947L = onClickListener;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f1952V = charSequence;
        r();
    }

    public void setQueryRefinementEnabled(boolean z2) {
        this.f1953W = z2;
        D.c cVar = this.f1950T;
        if (cVar instanceof e0) {
            ((e0) cVar).f3056q = z2 ? 2 : 1;
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f1958g0 = searchableInfo;
        Intent intent = null;
        SearchAutoComplete searchAutoComplete = this.f1962p;
        if (searchableInfo != null) {
            searchAutoComplete.setThreshold(searchableInfo.getSuggestThreshold());
            searchAutoComplete.setImeOptions(this.f1958g0.getImeOptions());
            int inputType = this.f1958g0.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.f1958g0.getSuggestAuthority() != null) {
                    inputType |= 589824;
                }
            }
            searchAutoComplete.setInputType(inputType);
            D.c cVar = this.f1950T;
            if (cVar != null) {
                cVar.b(null);
            }
            if (this.f1958g0.getSuggestAuthority() != null) {
                e0 e0Var = new e0(getContext(), this, this.f1958g0, this.k0);
                this.f1950T = e0Var;
                searchAutoComplete.setAdapter(e0Var);
                ((e0) this.f1950T).f3056q = this.f1953W ? 2 : 1;
            }
            r();
        }
        SearchableInfo searchableInfo2 = this.f1958g0;
        boolean z2 = false;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.f1958g0.getVoiceSearchLaunchWebSearch()) {
                intent = this.f1943H;
            } else if (this.f1958g0.getVoiceSearchLaunchRecognizer()) {
                intent = this.f1944I;
            }
            if (intent != null) {
                z2 = getContext().getPackageManager().resolveActivity(intent, 65536) != null;
            }
        }
        this.f1956c0 = z2;
        if (z2) {
            searchAutoComplete.setPrivateImeOptions("nm");
        }
        u(this.f1949S);
    }

    public void setSubmitButtonEnabled(boolean z2) {
        this.f1951U = z2;
        u(this.f1949S);
    }

    public void setSuggestionsAdapter(D.c cVar) {
        this.f1950T = cVar;
        this.f1962p.setAdapter(cVar);
    }

    public final void t(boolean z2) {
        boolean z3 = this.f1951U;
        this.f1966u.setVisibility((!z3 || !(z3 || this.f1956c0) || this.f1949S || !hasFocus() || (!z2 && this.f1956c0)) ? 8 : 0);
    }

    public final void u(boolean z2) {
        this.f1949S = z2;
        int i2 = 8;
        int i3 = z2 ? 0 : 8;
        boolean isEmpty = TextUtils.isEmpty(this.f1962p.getText());
        this.t.setVisibility(i3);
        t(!isEmpty);
        this.f1963q.setVisibility(z2 ? 8 : 0);
        ImageView imageView = this.f1940D;
        imageView.setVisibility((imageView.getDrawable() == null || this.f1948R) ? 8 : 0);
        p();
        if (this.f1956c0 && !this.f1949S && isEmpty) {
            this.f1966u.setVisibility(8);
            i2 = 0;
        }
        this.f1968w.setVisibility(i2);
        s();
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1971z = new Rect();
        this.f1937A = new Rect();
        this.f1938B = new int[2];
        this.f1939C = new int[2];
        this.f1960i0 = new T(this, 0);
        this.f1961j0 = new T(this, 1);
        this.k0 = new WeakHashMap();
        a aVar = new a(this);
        b bVar = new b(this);
        W w2 = new W(this);
        X x2 = new X(this);
        C0143F c0143f = new C0143F(1, this);
        S s2 = new S(this);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0091a.f2437q, i2, 0);
        f fVar = new f(context, obtainStyledAttributes);
        LayoutInflater.from(context).inflate(obtainStyledAttributes.getResourceId(9, R.layout.abc_search_view), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f1962p = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f1963q = findViewById(R.id.search_edit_frame);
        View findViewById = findViewById(R.id.search_plate);
        this.f1964r = findViewById;
        View findViewById2 = findViewById(R.id.submit_area);
        this.f1965s = findViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.t = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f1966u = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f1967v = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f1968w = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.f1940D = imageView5;
        Drawable z2 = fVar.z(10);
        Field field = x.f8355a;
        findViewById.setBackground(z2);
        findViewById2.setBackground(fVar.z(14));
        imageView.setImageDrawable(fVar.z(13));
        imageView2.setImageDrawable(fVar.z(7));
        imageView3.setImageDrawable(fVar.z(4));
        imageView4.setImageDrawable(fVar.z(16));
        imageView5.setImageDrawable(fVar.z(13));
        this.f1941E = fVar.z(12);
        AbstractC0059a.K(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.f1942F = obtainStyledAttributes.getResourceId(15, R.layout.abc_search_dropdown_item_icons_2line);
        this.G = obtainStyledAttributes.getResourceId(5, 0);
        imageView.setOnClickListener(aVar);
        imageView3.setOnClickListener(aVar);
        imageView2.setOnClickListener(aVar);
        imageView4.setOnClickListener(aVar);
        searchAutoComplete.setOnClickListener(aVar);
        searchAutoComplete.addTextChangedListener(s2);
        searchAutoComplete.setOnEditorActionListener(w2);
        searchAutoComplete.setOnItemClickListener(x2);
        searchAutoComplete.setOnItemSelectedListener(c0143f);
        searchAutoComplete.setOnKeyListener(bVar);
        searchAutoComplete.setOnFocusChangeListener(new U(this));
        setIconifiedByDefault(obtainStyledAttributes.getBoolean(8, true));
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(1, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.f1945J = obtainStyledAttributes.getText(6);
        this.f1952V = obtainStyledAttributes.getText(11);
        int i3 = obtainStyledAttributes.getInt(3, -1);
        if (i3 != -1) {
            setImeOptions(i3);
        }
        int i4 = obtainStyledAttributes.getInt(2, -1);
        if (i4 != -1) {
            setInputType(i4);
        }
        setFocusable(obtainStyledAttributes.getBoolean(0, true));
        fVar.M();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f1943H = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f1944I = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f1969x = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new V(this));
        }
        u(this.f1948R);
        r();
    }

    public void setOnCloseListener(Y y2) {
    }

    public void setOnQueryTextListener(Z z2) {
    }

    public void setOnSuggestionListener(a0 a0Var) {
    }
}
