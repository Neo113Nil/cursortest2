package androidx.core.graphics.drawable;

import U.a;
import U.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.nio.charset.Charset;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i2 = iconCompat.f2065a;
        if (aVar.e(1)) {
            i2 = ((b) aVar).f1684e.readInt();
        }
        iconCompat.f2065a = i2;
        byte[] bArr = iconCompat.f2067c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f1684e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f2067c = bArr;
        iconCompat.f2068d = aVar.f(iconCompat.f2068d, 3);
        int i3 = iconCompat.f2069e;
        if (aVar.e(4)) {
            i3 = ((b) aVar).f1684e.readInt();
        }
        iconCompat.f2069e = i3;
        int i4 = iconCompat.f2070f;
        if (aVar.e(5)) {
            i4 = ((b) aVar).f1684e.readInt();
        }
        iconCompat.f2070f = i4;
        iconCompat.f2071g = (ColorStateList) aVar.f(iconCompat.f2071g, 6);
        String str = iconCompat.f2073i;
        if (aVar.e(7)) {
            str = ((b) aVar).f1684e.readString();
        }
        iconCompat.f2073i = str;
        String str2 = iconCompat.f2074j;
        if (aVar.e(8)) {
            str2 = ((b) aVar).f1684e.readString();
        }
        iconCompat.f2074j = str2;
        iconCompat.f2072h = PorterDuff.Mode.valueOf(iconCompat.f2073i);
        switch (iconCompat.f2065a) {
            case -1:
                Parcelable parcelable = iconCompat.f2068d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f2066b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f2068d;
                if (parcelable2 != null) {
                    iconCompat.f2066b = parcelable2;
                } else {
                    byte[] bArr3 = iconCompat.f2067c;
                    iconCompat.f2066b = bArr3;
                    iconCompat.f2065a = 3;
                    iconCompat.f2069e = 0;
                    iconCompat.f2070f = bArr3.length;
                }
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str3 = new String(iconCompat.f2067c, Charset.forName("UTF-16"));
                iconCompat.f2066b = str3;
                if (iconCompat.f2065a == 2 && iconCompat.f2074j == null) {
                    iconCompat.f2074j = str3.split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f2066b = iconCompat.f2067c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f2073i = iconCompat.f2072h.name();
        switch (iconCompat.f2065a) {
            case -1:
                iconCompat.f2068d = (Parcelable) iconCompat.f2066b;
                break;
            case 1:
            case 5:
                iconCompat.f2068d = (Parcelable) iconCompat.f2066b;
                break;
            case 2:
                iconCompat.f2067c = ((String) iconCompat.f2066b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f2067c = (byte[]) iconCompat.f2066b;
                break;
            case 4:
            case 6:
                iconCompat.f2067c = iconCompat.f2066b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f2065a;
        if (-1 != i2) {
            aVar.h(1);
            ((b) aVar).f1684e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f2067c;
        if (bArr != null) {
            aVar.h(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f1684e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f2068d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f1684e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f2069e;
        if (i3 != 0) {
            aVar.h(4);
            ((b) aVar).f1684e.writeInt(i3);
        }
        int i4 = iconCompat.f2070f;
        if (i4 != 0) {
            aVar.h(5);
            ((b) aVar).f1684e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f2071g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f1684e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f2073i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f1684e.writeString(str);
        }
        String str2 = iconCompat.f2074j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f1684e.writeString(str2);
        }
    }
}
