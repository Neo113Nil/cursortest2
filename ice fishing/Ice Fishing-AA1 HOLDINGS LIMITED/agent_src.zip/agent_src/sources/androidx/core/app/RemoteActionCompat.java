package androidx.core.app;

import U.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f2058a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f2059b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f2060c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f2061d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f2062e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2063f;
}
