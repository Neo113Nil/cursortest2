package androidx.core.app;

import U.a;
import U.b;
import U.c;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVar = remoteActionCompat.f2058a;
        if (aVar.e(1)) {
            cVar = aVar.g();
        }
        remoteActionCompat.f2058a = (IconCompat) cVar;
        CharSequence charSequence = remoteActionCompat.f2059b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f1684e);
        }
        remoteActionCompat.f2059b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f2060c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f1684e);
        }
        remoteActionCompat.f2060c = charSequence2;
        remoteActionCompat.f2061d = (PendingIntent) aVar.f(remoteActionCompat.f2061d, 4);
        boolean z2 = remoteActionCompat.f2062e;
        if (aVar.e(5)) {
            z2 = ((b) aVar).f1684e.readInt() != 0;
        }
        remoteActionCompat.f2062e = z2;
        boolean z3 = remoteActionCompat.f2063f;
        if (aVar.e(6)) {
            z3 = ((b) aVar).f1684e.readInt() != 0;
        }
        remoteActionCompat.f2063f = z3;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f2058a;
        aVar.h(1);
        aVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f2059b;
        aVar.h(2);
        Parcel parcel = ((b) aVar).f1684e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f2060c;
        aVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f2061d;
        aVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z2 = remoteActionCompat.f2062e;
        aVar.h(5);
        parcel.writeInt(z2 ? 1 : 0);
        boolean z3 = remoteActionCompat.f2063f;
        aVar.h(6);
        parcel.writeInt(z3 ? 1 : 0);
    }
}
