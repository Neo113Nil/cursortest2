package androidx.recyclerview.widget;

import A1.a;
import L.b;
import P.C0056m;
import P.C0057n;
import P.E;
import P.v;
import P.w;
import a.AbstractC0059a;
import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import m0.j;

/* loaded from: classes.dex */
public class LinearLayoutManager extends v {

    /* renamed from: h, reason: collision with root package name */
    public final int f2325h;

    /* renamed from: i, reason: collision with root package name */
    public j f2326i;

    /* renamed from: j, reason: collision with root package name */
    public final b f2327j;

    /* renamed from: k, reason: collision with root package name */
    public final boolean f2328k;

    /* renamed from: l, reason: collision with root package name */
    public final boolean f2329l = false;

    /* renamed from: m, reason: collision with root package name */
    public boolean f2330m = false;

    /* renamed from: n, reason: collision with root package name */
    public final boolean f2331n = true;

    /* renamed from: o, reason: collision with root package name */
    public C0057n f2332o = null;

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f2325h = 1;
        this.f2328k = false;
        C0056m c0056m = new C0056m(0);
        c0056m.f1488b = -1;
        c0056m.f1489c = Integer.MIN_VALUE;
        c0056m.f1490d = false;
        c0056m.f1491e = false;
        C0056m w2 = v.w(context, attributeSet, i2, i3);
        int i4 = w2.f1488b;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException(a.g(i4, "invalid orientation:"));
        }
        a(null);
        if (i4 != this.f2325h || this.f2327j == null) {
            this.f2327j = b.a(this, i4);
            this.f2325h = i4;
            H();
        }
        boolean z2 = w2.f1490d;
        a(null);
        if (z2 != this.f2328k) {
            this.f2328k = z2;
            H();
        }
        Q(w2.f1491e);
    }

    @Override // P.v
    public final void A(AccessibilityEvent accessibilityEvent) {
        super.A(accessibilityEvent);
        if (p() > 0) {
            View P2 = P(0, p(), false);
            if (P2 != null) {
                ((w) P2.getLayoutParams()).getClass();
                throw null;
            }
            accessibilityEvent.setFromIndex(-1);
            View P3 = P(p() - 1, -1, false);
            if (P3 == null) {
                accessibilityEvent.setToIndex(-1);
            } else {
                ((w) P3.getLayoutParams()).getClass();
                throw null;
            }
        }
    }

    @Override // P.v
    public final void B(Parcelable parcelable) {
        if (parcelable instanceof C0057n) {
            this.f2332o = (C0057n) parcelable;
            H();
        }
    }

    @Override // P.v
    public final Parcelable C() {
        C0057n c0057n = this.f2332o;
        if (c0057n != null) {
            C0057n c0057n2 = new C0057n();
            c0057n2.f1492a = c0057n.f1492a;
            c0057n2.f1493b = c0057n.f1493b;
            c0057n2.f1494c = c0057n.f1494c;
            return c0057n2;
        }
        C0057n c0057n3 = new C0057n();
        if (p() <= 0) {
            c0057n3.f1492a = -1;
            return c0057n3;
        }
        M();
        boolean z2 = this.f2329l;
        c0057n3.f1494c = z2;
        if (!z2) {
            v.v(o(z2 ? p() - 1 : 0));
            throw null;
        }
        View o2 = o(z2 ? 0 : p() - 1);
        c0057n3.f1493b = this.f2327j.d() - this.f2327j.b(o2);
        v.v(o2);
        throw null;
    }

    public final int J(E e2) {
        if (p() == 0) {
            return 0;
        }
        M();
        b bVar = this.f2327j;
        boolean z2 = !this.f2331n;
        return AbstractC0059a.h(e2, bVar, O(z2), N(z2), this, this.f2331n);
    }

    public final void K(E e2) {
        if (p() == 0) {
            return;
        }
        M();
        boolean z2 = !this.f2331n;
        View O2 = O(z2);
        View N2 = N(z2);
        if (p() == 0 || e2.a() == 0 || O2 == null || N2 == null) {
            return;
        }
        ((w) O2.getLayoutParams()).getClass();
        throw null;
    }

    public final int L(E e2) {
        if (p() == 0) {
            return 0;
        }
        M();
        b bVar = this.f2327j;
        boolean z2 = !this.f2331n;
        return AbstractC0059a.i(e2, bVar, O(z2), N(z2), this, this.f2331n);
    }

    public final void M() {
        if (this.f2326i == null) {
            this.f2326i = new j(12, false);
        }
    }

    public final View N(boolean z2) {
        return this.f2329l ? P(0, p(), z2) : P(p() - 1, -1, z2);
    }

    public final View O(boolean z2) {
        return this.f2329l ? P(p() - 1, -1, z2) : P(0, p(), z2);
    }

    public final View P(int i2, int i3, boolean z2) {
        M();
        int i4 = z2 ? 24579 : 320;
        return this.f2325h == 0 ? this.f1504c.q(i2, i3, i4, 320) : this.f1505d.q(i2, i3, i4, 320);
    }

    public void Q(boolean z2) {
        a(null);
        if (this.f2330m == z2) {
            return;
        }
        this.f2330m = z2;
        H();
    }

    @Override // P.v
    public final void a(String str) {
        RecyclerView recyclerView;
        if (this.f2332o != null || (recyclerView = this.f1503b) == null) {
            return;
        }
        recyclerView.b(str);
    }

    @Override // P.v
    public final boolean b() {
        return this.f2325h == 0;
    }

    @Override // P.v
    public final boolean c() {
        return this.f2325h == 1;
    }

    @Override // P.v
    public final int f(E e2) {
        return J(e2);
    }

    @Override // P.v
    public final void g(E e2) {
        K(e2);
    }

    @Override // P.v
    public final int h(E e2) {
        return L(e2);
    }

    @Override // P.v
    public final int i(E e2) {
        return J(e2);
    }

    @Override // P.v
    public final void j(E e2) {
        K(e2);
    }

    @Override // P.v
    public final int k(E e2) {
        return L(e2);
    }

    @Override // P.v
    public w l() {
        return new w(-2, -2);
    }

    @Override // P.v
    public final boolean y() {
        return true;
    }

    @Override // P.v
    public final void z(RecyclerView recyclerView) {
    }
}
