package androidx.recyclerview.widget;

import B1.q;
import C.b;
import C.d;
import K.f;
import O.a;
import P.A;
import P.B;
import P.C;
import P.C0045b;
import P.C0046c;
import P.C0050g;
import P.C0051h;
import P.D;
import P.E;
import P.F;
import P.G;
import P.I;
import P.O;
import P.RunnableC0053j;
import P.p;
import P.s;
import P.t;
import P.v;
import P.w;
import P.z;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import io.appmetrica.analytics.AppMetricaDefaultValues;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import m0.j;
import u.e;
import y.AbstractC1037p;
import y.C1028g;
import y.r;
import y.x;
import y.y;

/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup {

    /* renamed from: m0, reason: collision with root package name */
    public static final int[] f2333m0 = {R.attr.nestedScrollingEnabled};

    /* renamed from: n0, reason: collision with root package name */
    public static final int[] f2334n0 = {R.attr.clipToPadding};

    /* renamed from: o0, reason: collision with root package name */
    public static final Class[] f2335o0;

    /* renamed from: p0, reason: collision with root package name */
    public static final p f2336p0;

    /* renamed from: A, reason: collision with root package name */
    public EdgeEffect f2337A;

    /* renamed from: B, reason: collision with root package name */
    public EdgeEffect f2338B;

    /* renamed from: C, reason: collision with root package name */
    public EdgeEffect f2339C;

    /* renamed from: D, reason: collision with root package name */
    public t f2340D;

    /* renamed from: E, reason: collision with root package name */
    public int f2341E;

    /* renamed from: F, reason: collision with root package name */
    public int f2342F;
    public VelocityTracker G;

    /* renamed from: H, reason: collision with root package name */
    public int f2343H;

    /* renamed from: I, reason: collision with root package name */
    public int f2344I;

    /* renamed from: J, reason: collision with root package name */
    public int f2345J;

    /* renamed from: K, reason: collision with root package name */
    public int f2346K;

    /* renamed from: L, reason: collision with root package name */
    public int f2347L;

    /* renamed from: R, reason: collision with root package name */
    public final int f2348R;

    /* renamed from: S, reason: collision with root package name */
    public final int f2349S;

    /* renamed from: T, reason: collision with root package name */
    public final float f2350T;

    /* renamed from: U, reason: collision with root package name */
    public final float f2351U;

    /* renamed from: V, reason: collision with root package name */
    public boolean f2352V;

    /* renamed from: W, reason: collision with root package name */
    public final G f2353W;

    /* renamed from: a, reason: collision with root package name */
    public final B f2354a;

    /* renamed from: a0, reason: collision with root package name */
    public RunnableC0053j f2355a0;

    /* renamed from: b, reason: collision with root package name */
    public D f2356b;

    /* renamed from: b0, reason: collision with root package name */
    public final C0051h f2357b0;

    /* renamed from: c, reason: collision with root package name */
    public final f f2358c;

    /* renamed from: c0, reason: collision with root package name */
    public final E f2359c0;

    /* renamed from: d, reason: collision with root package name */
    public final f f2360d;

    /* renamed from: d0, reason: collision with root package name */
    public ArrayList f2361d0;

    /* renamed from: e, reason: collision with root package name */
    public final j f2362e;
    public final j e0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2363f;
    public I f0;

    /* renamed from: g, reason: collision with root package name */
    public final Rect f2364g;

    /* renamed from: g0, reason: collision with root package name */
    public C1028g f2365g0;

    /* renamed from: h, reason: collision with root package name */
    public final Rect f2366h;

    /* renamed from: h0, reason: collision with root package name */
    public final int[] f2367h0;

    /* renamed from: i, reason: collision with root package name */
    public v f2368i;

    /* renamed from: i0, reason: collision with root package name */
    public final int[] f2369i0;

    /* renamed from: j, reason: collision with root package name */
    public final ArrayList f2370j;

    /* renamed from: j0, reason: collision with root package name */
    public final int[] f2371j0;

    /* renamed from: k, reason: collision with root package name */
    public final ArrayList f2372k;
    public final ArrayList k0;

    /* renamed from: l, reason: collision with root package name */
    public C0050g f2373l;

    /* renamed from: l0, reason: collision with root package name */
    public final b f2374l0;

    /* renamed from: m, reason: collision with root package name */
    public boolean f2375m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f2376n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f2377o;

    /* renamed from: p, reason: collision with root package name */
    public int f2378p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f2379q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f2380r;

    /* renamed from: s, reason: collision with root package name */
    public int f2381s;
    public final AccessibilityManager t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f2382u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f2383v;

    /* renamed from: w, reason: collision with root package name */
    public int f2384w;

    /* renamed from: x, reason: collision with root package name */
    public final int f2385x;

    /* renamed from: y, reason: collision with root package name */
    public s f2386y;

    /* renamed from: z, reason: collision with root package name */
    public EdgeEffect f2387z;

    static {
        Class cls = Integer.TYPE;
        f2335o0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f2336p0 = new p();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public RecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        float a2;
        char c2;
        int i2;
        TypedArray typedArray;
        char c3;
        Constructor constructor;
        int i3 = 15;
        this.f2354a = new B(this);
        this.f2362e = new j(17);
        this.f2364g = new Rect();
        this.f2366h = new Rect();
        new RectF();
        this.f2370j = new ArrayList();
        this.f2372k = new ArrayList();
        this.f2378p = 0;
        this.f2382u = false;
        this.f2383v = false;
        this.f2384w = 0;
        this.f2385x = 0;
        this.f2386y = new s();
        C0046c c0046c = new C0046c();
        Object[] objArr = null;
        c0046c.f1496a = null;
        c0046c.f1497b = new ArrayList();
        c0046c.f1498c = 250L;
        c0046c.f1499d = 250L;
        c0046c.f1432e = new ArrayList();
        c0046c.f1433f = new ArrayList();
        c0046c.f1434g = new ArrayList();
        c0046c.f1435h = new ArrayList();
        c0046c.f1436i = new ArrayList();
        c0046c.f1437j = new ArrayList();
        c0046c.f1438k = new ArrayList();
        c0046c.f1439l = new ArrayList();
        c0046c.f1440m = new ArrayList();
        c0046c.f1441n = new ArrayList();
        c0046c.f1442o = new ArrayList();
        this.f2340D = c0046c;
        this.f2341E = 0;
        this.f2342F = -1;
        this.f2350T = Float.MIN_VALUE;
        this.f2351U = Float.MIN_VALUE;
        boolean z2 = true;
        this.f2352V = true;
        this.f2353W = new G(this);
        this.f2357b0 = new C0051h();
        E e2 = new E();
        e2.f1391a = 0;
        e2.f1392b = false;
        e2.f1393c = false;
        e2.f1394d = false;
        e2.f1395e = false;
        this.f2359c0 = e2;
        j jVar = new j(i3, false);
        this.e0 = jVar;
        this.f2367h0 = new int[2];
        this.f2369i0 = new int[2];
        this.f2371j0 = new int[2];
        this.k0 = new ArrayList();
        this.f2374l0 = new b(5, this);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f2334n0, 0, 0);
            this.f2363f = obtainStyledAttributes.getBoolean(0, true);
            obtainStyledAttributes.recycle();
        } else {
            this.f2363f = true;
        }
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f2347L = viewConfiguration.getScaledTouchSlop();
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 26) {
            Method method = y.B.f8296a;
            a2 = y.a(viewConfiguration);
        } else {
            a2 = y.B.a(viewConfiguration, context);
        }
        this.f2350T = a2;
        this.f2351U = i4 >= 26 ? y.b(viewConfiguration) : y.B.a(viewConfiguration, context);
        this.f2348R = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2349S = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.f2340D.f1496a = jVar;
        this.f2358c = new f(new j(14, this));
        this.f2360d = new f(new q(i3, this));
        Field field = x.f8355a;
        if ((i4 >= 26 ? r.c(this) : 0) == 0 && i4 >= 26) {
            r.m(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.t = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new I(this));
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, a.f1244a, 0, 0);
            String string = obtainStyledAttributes2.getString(7);
            if (obtainStyledAttributes2.getInt(1, -1) == -1) {
                setDescendantFocusability(262144);
            }
            if (obtainStyledAttributes2.getBoolean(2, false)) {
                StateListDrawable stateListDrawable = (StateListDrawable) obtainStyledAttributes2.getDrawable(5);
                Drawable drawable = obtainStyledAttributes2.getDrawable(6);
                StateListDrawable stateListDrawable2 = (StateListDrawable) obtainStyledAttributes2.getDrawable(3);
                Drawable drawable2 = obtainStyledAttributes2.getDrawable(4);
                if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                    throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + h());
                }
                Resources resources = getContext().getResources();
                c2 = 3;
                i2 = 4;
                typedArray = obtainStyledAttributes2;
                c3 = 2;
                new C0050g(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(com.watchfacestudio.pred01.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(com.watchfacestudio.pred01.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(com.watchfacestudio.pred01.R.dimen.fastscroll_margin));
            } else {
                c2 = 3;
                i2 = 4;
                typedArray = obtainStyledAttributes2;
                c3 = 2;
            }
            typedArray.recycle();
            if (string != null) {
                String trim = string.trim();
                if (!trim.isEmpty()) {
                    if (trim.charAt(0) == '.') {
                        trim = context.getPackageName() + trim;
                    } else if (!trim.contains(".")) {
                        trim = RecyclerView.class.getPackage().getName() + '.' + trim;
                    }
                    try {
                        Class<? extends U> asSubclass = (isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).loadClass(trim).asSubclass(v.class);
                        try {
                            constructor = asSubclass.getConstructor(f2335o0);
                            Object[] objArr2 = new Object[i2];
                            objArr2[0] = context;
                            objArr2[1] = attributeSet;
                            objArr2[c3] = 0;
                            objArr2[c2] = 0;
                            objArr = objArr2;
                        } catch (NoSuchMethodException e3) {
                            try {
                                constructor = asSubclass.getConstructor(null);
                            } catch (NoSuchMethodException e4) {
                                e4.initCause(e3);
                                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + trim, e4);
                            }
                        }
                        constructor.setAccessible(true);
                        setLayoutManager((v) constructor.newInstance(objArr));
                    } catch (ClassCastException e5) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + trim, e5);
                    } catch (ClassNotFoundException e6) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + trim, e6);
                    } catch (IllegalAccessException e7) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + trim, e7);
                    } catch (InstantiationException e8) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + trim, e8);
                    } catch (InvocationTargetException e9) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + trim, e9);
                    }
                }
            }
            TypedArray obtainStyledAttributes3 = context.obtainStyledAttributes(attributeSet, f2333m0, 0, 0);
            z2 = obtainStyledAttributes3.getBoolean(0, true);
            obtainStyledAttributes3.recycle();
        } else {
            setDescendantFocusability(262144);
        }
        setNestedScrollingEnabled(z2);
    }

    private C1028g getScrollingChildHelper() {
        if (this.f2365g0 == null) {
            this.f2365g0 = new C1028g(this);
        }
        return this.f2365g0;
    }

    public static void j(View view) {
        if (view == null) {
            return;
        }
        ((w) view.getLayoutParams()).getClass();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i2, int i3) {
        v vVar = this.f2368i;
        if (vVar != null) {
            vVar.getClass();
        }
        super.addFocusables(arrayList, i2, i3);
    }

    public final void b(String str) {
        if (this.f2384w > 0) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + h());
        }
        if (this.f2385x > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException("" + h()));
        }
    }

    public final void c(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.f2387z;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.f2387z.onRelease();
            z2 = this.f2387z.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f2338B;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.f2338B.onRelease();
            z2 |= this.f2338B.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2337A;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.f2337A.onRelease();
            z2 |= this.f2337A.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2339C;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.f2339C.onRelease();
            z2 |= this.f2339C.isFinished();
        }
        if (z2) {
            Field field = x.f8355a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof w) && this.f2368i.d((w) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.b()) {
            return this.f2368i.f(this.f2359c0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.b()) {
            this.f2368i.g(this.f2359c0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.b()) {
            return this.f2368i.h(this.f2359c0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.c()) {
            return this.f2368i.i(this.f2359c0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.c()) {
            this.f2368i.j(this.f2359c0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        v vVar = this.f2368i;
        if (vVar != null && vVar.c()) {
            return this.f2368i.k(this.f2359c0);
        }
        return 0;
    }

    public final void d() {
        f fVar = this.f2358c;
        if (!this.f2377o || this.f2382u) {
            int i2 = e.f8229a;
            Trace.beginSection("RV FullInvalidate");
            Log.e("RecyclerView", "No adapter attached; skipping layout");
            Trace.endSection();
            return;
        }
        if (((ArrayList) fVar.f945c).size() > 0) {
            fVar.getClass();
            if (((ArrayList) fVar.f945c).size() > 0) {
                int i3 = e.f8229a;
                Trace.beginSection("RV FullInvalidate");
                Log.e("RecyclerView", "No adapter attached; skipping layout");
                Trace.endSection();
            }
        }
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().b(f2, f3);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().d(i2, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        ArrayList arrayList = this.f2370j;
        int size = arrayList.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            C0050g c0050g = (C0050g) arrayList.get(i2);
            if (c0050g.f1459l != c0050g.f1461n.getWidth() || c0050g.f1460m != c0050g.f1461n.getHeight()) {
                c0050g.f1459l = c0050g.f1461n.getWidth();
                c0050g.f1460m = c0050g.f1461n.getHeight();
                c0050g.e(0);
            } else if (c0050g.f1468v != 0) {
                if (c0050g.f1462o) {
                    int i3 = c0050g.f1459l;
                    int i4 = c0050g.f1451d;
                    int i5 = i3 - i4;
                    int i6 = 0 - (0 / 2);
                    StateListDrawable stateListDrawable = c0050g.f1449b;
                    stateListDrawable.setBounds(0, 0, i4, 0);
                    int i7 = c0050g.f1460m;
                    Drawable drawable = c0050g.f1450c;
                    drawable.setBounds(0, 0, c0050g.f1452e, i7);
                    RecyclerView recyclerView = c0050g.f1461n;
                    Field field = x.f8355a;
                    if (recyclerView.getLayoutDirection() == 1) {
                        drawable.draw(canvas);
                        canvas.translate(i4, i6);
                        canvas.scale(-1.0f, 1.0f);
                        stateListDrawable.draw(canvas);
                        canvas.scale(1.0f, 1.0f);
                        canvas.translate(-i4, -i6);
                    } else {
                        canvas.translate(i5, 0.0f);
                        drawable.draw(canvas);
                        canvas.translate(0.0f, i6);
                        stateListDrawable.draw(canvas);
                        canvas.translate(-i5, -i6);
                    }
                }
                if (c0050g.f1463p) {
                    int i8 = c0050g.f1460m;
                    int i9 = c0050g.f1455h;
                    int i10 = i8 - i9;
                    StateListDrawable stateListDrawable2 = c0050g.f1453f;
                    stateListDrawable2.setBounds(0, 0, 0, i9);
                    int i11 = c0050g.f1459l;
                    Drawable drawable2 = c0050g.f1454g;
                    drawable2.setBounds(0, 0, i11, c0050g.f1456i);
                    canvas.translate(0.0f, i10);
                    drawable2.draw(canvas);
                    canvas.translate(0 - (0 / 2), 0.0f);
                    stateListDrawable2.draw(canvas);
                    canvas.translate(-r9, -i10);
                }
            }
        }
        EdgeEffect edgeEffect = this.f2387z;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f2363f ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f2387z;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.f2337A;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.f2363f) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f2337A;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.f2338B;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f2363f ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(-paddingTop, -width);
            EdgeEffect edgeEffect6 = this.f2338B;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.f2339C;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f2363f) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f2339C;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if ((z2 || this.f2340D == null || arrayList.size() <= 0 || !this.f2340D.b()) ? z2 : true) {
            Field field2 = x.f8355a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public final void e(int i2, int i3) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        Field field = x.f8355a;
        setMeasuredDimension(v.e(i2, paddingRight, getMinimumWidth()), v.e(i3, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public final boolean f(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, i4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i2) {
        int i3;
        this.f2368i.getClass();
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i2);
        if (findNextFocus != null && !findNextFocus.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i2);
            }
            o(findNextFocus, null);
            return view;
        }
        if (findNextFocus != null && findNextFocus != this && i(findNextFocus) != null) {
            if (view == null || i(view) == null) {
                return findNextFocus;
            }
            int width = view.getWidth();
            int height = view.getHeight();
            Rect rect = this.f2364g;
            char c2 = 0;
            rect.set(0, 0, width, height);
            int width2 = findNextFocus.getWidth();
            int height2 = findNextFocus.getHeight();
            Rect rect2 = this.f2366h;
            rect2.set(0, 0, width2, height2);
            offsetDescendantRectToMyCoords(view, rect);
            offsetDescendantRectToMyCoords(findNextFocus, rect2);
            RecyclerView recyclerView = this.f2368i.f1503b;
            Field field = x.f8355a;
            int i4 = recyclerView.getLayoutDirection() == 1 ? -1 : 1;
            int i5 = rect.left;
            int i6 = rect2.left;
            if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
                i3 = 1;
            } else {
                int i7 = rect.right;
                int i8 = rect2.right;
                i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
            }
            int i9 = rect.top;
            int i10 = rect2.top;
            if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
                c2 = 1;
            } else {
                int i11 = rect.bottom;
                int i12 = rect2.bottom;
                if ((i11 > i12 || i9 >= i12) && i9 > i10) {
                    c2 = 65535;
                }
            }
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 17) {
                        if (i2 != 33) {
                            if (i2 != 66) {
                                if (i2 != 130) {
                                    throw new IllegalArgumentException("Invalid direction: " + i2 + h());
                                }
                                if (c2 > 0) {
                                    return findNextFocus;
                                }
                            } else if (i3 > 0) {
                                return findNextFocus;
                            }
                        } else if (c2 < 0) {
                            return findNextFocus;
                        }
                    } else if (i3 < 0) {
                        return findNextFocus;
                    }
                } else {
                    if (c2 > 0) {
                        return findNextFocus;
                    }
                    if (c2 == 0 && i3 * i4 >= 0) {
                        return findNextFocus;
                    }
                }
            } else {
                if (c2 < 0) {
                    return findNextFocus;
                }
                if (c2 == 0 && i3 * i4 <= 0) {
                    return findNextFocus;
                }
            }
        }
        return super.focusSearch(view, i2);
    }

    public final boolean g(int[] iArr, int i2) {
        return getScrollingChildHelper().d(0, 0, 0, 0, iArr, i2, null);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        v vVar = this.f2368i;
        if (vVar != null) {
            return vVar.l();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        v vVar = this.f2368i;
        if (vVar != null) {
            return vVar.m(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    public P.q getAdapter() {
        return null;
    }

    @Override // android.view.View
    public int getBaseline() {
        v vVar = this.f2368i;
        if (vVar == null) {
            return super.getBaseline();
        }
        vVar.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i2, int i3) {
        return super.getChildDrawingOrder(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f2363f;
    }

    public I getCompatAccessibilityDelegate() {
        return this.f0;
    }

    public s getEdgeEffectFactory() {
        return this.f2386y;
    }

    public t getItemAnimator() {
        return this.f2340D;
    }

    public int getItemDecorationCount() {
        return this.f2370j.size();
    }

    public v getLayoutManager() {
        return this.f2368i;
    }

    public int getMaxFlingVelocity() {
        return this.f2349S;
    }

    public int getMinFlingVelocity() {
        return this.f2348R;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public P.x getOnFlingListener() {
        return null;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f2352V;
    }

    public A getRecycledViewPool() {
        B b2 = this.f2354a;
        if (b2.f1388e == null) {
            A a2 = new A();
            a2.f1382a = new SparseArray();
            a2.f1383b = 0;
            b2.f1388e = a2;
        }
        return b2.f1388e;
    }

    public int getScrollState() {
        return this.f2341E;
    }

    public final String h() {
        return " " + super.toString() + ", adapter:null, layout:" + this.f2368i + ", context:" + getContext();
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:?, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View i(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        return null;
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f2375m;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f8345d;
    }

    public final boolean k() {
        return getScrollingChildHelper().f(1);
    }

    public final boolean l() {
        return !this.f2377o || this.f2382u || ((ArrayList) this.f2358c.f945c).size() > 0;
    }

    public final void m() {
        int D2 = this.f2360d.D();
        for (int i2 = 0; i2 < D2; i2++) {
            ((w) this.f2360d.C(i2).getLayoutParams()).f1510b = true;
        }
        ArrayList arrayList = this.f2354a.f1385b;
        if (arrayList.size() <= 0) {
            return;
        }
        A1.a.p(arrayList.get(0));
        throw null;
    }

    public final void n(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f2342F) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f2342F = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.f2345J = x2;
            this.f2343H = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.f2346K = y2;
            this.f2344I = y2;
        }
    }

    public final void o(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f2364g;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof w) {
            w wVar = (w) layoutParams;
            if (!wVar.f1510b) {
                int i2 = rect.left;
                Rect rect2 = wVar.f1509a;
                rect.left = i2 - rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f2368i.G(this, view, this.f2364g, !this.f2377o, view2 == null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0053, code lost:
    
        if (r1 >= 30.0f) goto L19;
     */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onAttachedToWindow() {
        float f2;
        super.onAttachedToWindow();
        boolean z2 = false;
        this.f2384w = 0;
        this.f2375m = true;
        if (this.f2377o && !isLayoutRequested()) {
            z2 = true;
        }
        this.f2377o = z2;
        v vVar = this.f2368i;
        if (vVar != null) {
            vVar.f1506e = true;
        }
        ThreadLocal threadLocal = RunnableC0053j.f1478e;
        RunnableC0053j runnableC0053j = (RunnableC0053j) threadLocal.get();
        this.f2355a0 = runnableC0053j;
        if (runnableC0053j == null) {
            RunnableC0053j runnableC0053j2 = new RunnableC0053j();
            runnableC0053j2.f1480a = new ArrayList();
            runnableC0053j2.f1483d = new ArrayList();
            this.f2355a0 = runnableC0053j2;
            Field field = x.f8355a;
            Display display = getDisplay();
            if (!isInEditMode() && display != null) {
                f2 = display.getRefreshRate();
            }
            f2 = 60.0f;
            RunnableC0053j runnableC0053j3 = this.f2355a0;
            runnableC0053j3.f1482c = (long) (1.0E9f / f2);
            threadLocal.set(runnableC0053j3);
        }
        this.f2355a0.f1480a.add(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        Object obj;
        super.onDetachedFromWindow();
        t tVar = this.f2340D;
        if (tVar != null) {
            tVar.a();
        }
        setScrollState(0);
        G g2 = this.f2353W;
        g2.f1402g.removeCallbacks(g2);
        g2.f1398c.abortAnimation();
        this.f2375m = false;
        v vVar = this.f2368i;
        if (vVar != null) {
            vVar.f1506e = false;
            vVar.z(this);
        }
        this.k0.clear();
        removeCallbacks(this.f2374l0);
        this.f2362e.getClass();
        do {
            K1.e eVar = O.f1429a;
            int i2 = eVar.f979a;
            obj = null;
            if (i2 > 0) {
                int i3 = i2 - 1;
                Object[] objArr = (Object[]) eVar.f980b;
                Object obj2 = objArr[i3];
                kotlin.jvm.internal.j.c(obj2, "null cannot be cast to non-null type T of androidx.core.util.Pools.SimplePool");
                objArr[i3] = null;
                eVar.f979a--;
                obj = obj2;
            }
        } while (obj != null);
        RunnableC0053j runnableC0053j = this.f2355a0;
        if (runnableC0053j != null) {
            runnableC0053j.f1480a.remove(this);
            this.f2355a0 = null;
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f2370j;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((C0050g) arrayList.get(i2)).getClass();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0068  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f2;
        float f3;
        if (this.f2368i != null && !this.f2379q && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.f2368i.c() ? -motionEvent.getAxisValue(9) : 0.0f;
                if (this.f2368i.b()) {
                    f3 = motionEvent.getAxisValue(10);
                    if (f2 == 0.0f || f3 != 0.0f) {
                        q((int) (f3 * this.f2350T), (int) (f2 * this.f2351U), motionEvent);
                    }
                }
                f3 = 0.0f;
                if (f2 == 0.0f) {
                }
                q((int) (f3 * this.f2350T), (int) (f2 * this.f2351U), motionEvent);
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.f2368i.c()) {
                        f2 = -axisValue;
                        f3 = 0.0f;
                        if (f2 == 0.0f) {
                        }
                        q((int) (f3 * this.f2350T), (int) (f2 * this.f2351U), motionEvent);
                    } else if (this.f2368i.b()) {
                        f3 = axisValue;
                        f2 = 0.0f;
                        if (f2 == 0.0f) {
                        }
                        q((int) (f3 * this.f2350T), (int) (f2 * this.f2351U), motionEvent);
                    }
                }
                f2 = 0.0f;
                f3 = 0.0f;
                if (f2 == 0.0f) {
                }
                q((int) (f3 * this.f2350T), (int) (f2 * this.f2351U), motionEvent);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.f2379q) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 3 || action == 0) {
            this.f2373l = null;
        }
        ArrayList arrayList = this.f2372k;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0050g c0050g = (C0050g) arrayList.get(i2);
            if (c0050g.c(motionEvent) && action != 3) {
                this.f2373l = c0050g;
                p();
                setScrollState(0);
                return true;
            }
        }
        v vVar = this.f2368i;
        if (vVar == null) {
            return false;
        }
        boolean b2 = vVar.b();
        boolean c2 = this.f2368i.c();
        if (this.G == null) {
            this.G = VelocityTracker.obtain();
        }
        this.G.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f2380r) {
                this.f2380r = false;
            }
            this.f2342F = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.f2345J = x2;
            this.f2343H = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.f2346K = y2;
            this.f2344I = y2;
            if (this.f2341E == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
            }
            int[] iArr = this.f2371j0;
            iArr[1] = 0;
            iArr[0] = 0;
            int i3 = b2;
            if (c2) {
                i3 = (b2 ? 1 : 0) | 2;
            }
            getScrollingChildHelper().g(i3, 0);
        } else if (actionMasked == 1) {
            this.G.clear();
            s(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.f2342F);
            if (findPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f2342F + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.f2341E != 1) {
                int i4 = x3 - this.f2343H;
                int i5 = y3 - this.f2344I;
                if (b2 == 0 || Math.abs(i4) <= this.f2347L) {
                    z2 = false;
                } else {
                    this.f2345J = x3;
                    z2 = true;
                }
                if (c2 && Math.abs(i5) > this.f2347L) {
                    this.f2346K = y3;
                    z2 = true;
                }
                if (z2) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            p();
            setScrollState(0);
        } else if (actionMasked == 5) {
            this.f2342F = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.f2345J = x4;
            this.f2343H = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.f2346K = y4;
            this.f2344I = y4;
        } else if (actionMasked == 6) {
            n(motionEvent);
        }
        return this.f2341E == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6 = e.f8229a;
        Trace.beginSection("RV OnLayout");
        Log.e("RecyclerView", "No adapter attached; skipping layout");
        Trace.endSection();
        this.f2377o = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        v vVar = this.f2368i;
        if (vVar == null) {
            e(i2, i3);
            return;
        }
        if (vVar.y()) {
            View.MeasureSpec.getMode(i2);
            View.MeasureSpec.getMode(i3);
            this.f2368i.f1503b.e(i2, i3);
        } else {
            if (this.f2376n) {
                this.f2368i.f1503b.e(i2, i3);
                return;
            }
            E e2 = this.f2359c0;
            if (e2.f1395e) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            e2.getClass();
            this.f2378p++;
            this.f2368i.f1503b.e(i2, i3);
            if (this.f2378p < 1) {
                this.f2378p = 1;
            }
            this.f2378p--;
            e2.f1393c = false;
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (this.f2384w > 0) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof D)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        D d2 = (D) parcelable;
        this.f2356b = d2;
        super.onRestoreInstanceState(d2.f306a);
        v vVar = this.f2368i;
        if (vVar == null || (parcelable2 = this.f2356b.f1390c) == null) {
            return;
        }
        vVar.B(parcelable2);
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        D d2 = new D(super.onSaveInstanceState());
        D d3 = this.f2356b;
        if (d3 != null) {
            d2.f1390c = d3.f1390c;
        } else {
            v vVar = this.f2368i;
            if (vVar != null) {
                d2.f1390c = vVar.C();
            } else {
                d2.f1390c = null;
            }
        }
        return d2;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        this.f2339C = null;
        this.f2337A = null;
        this.f2338B = null;
        this.f2387z = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x023a  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x024c  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.f2379q || this.f2380r) {
            return false;
        }
        int action = motionEvent.getAction();
        C0050g c0050g = this.f2373l;
        if (c0050g != null) {
            if (action != 0) {
                if (c0050g.f1464q != 0) {
                    if (motionEvent.getAction() == 0) {
                        boolean b2 = c0050g.b(motionEvent.getX(), motionEvent.getY());
                        boolean a2 = c0050g.a(motionEvent.getX(), motionEvent.getY());
                        if (b2 || a2) {
                            if (a2) {
                                c0050g.f1465r = 1;
                                c0050g.f1458k = (int) motionEvent.getX();
                            } else if (b2) {
                                c0050g.f1465r = 2;
                                c0050g.f1457j = (int) motionEvent.getY();
                            }
                            c0050g.e(2);
                        }
                    } else if (motionEvent.getAction() == 1 && c0050g.f1464q == 2) {
                        c0050g.f1457j = 0.0f;
                        c0050g.f1458k = 0.0f;
                        c0050g.e(1);
                        c0050g.f1465r = 0;
                    } else if (motionEvent.getAction() == 2 && c0050g.f1464q == 2) {
                        c0050g.f();
                        int i2 = c0050g.f1465r;
                        int i3 = c0050g.f1448a;
                        if (i2 == 1) {
                            float x2 = motionEvent.getX();
                            int[] iArr = c0050g.t;
                            iArr[0] = i3;
                            int i4 = c0050g.f1459l - i3;
                            iArr[1] = i4;
                            float max = Math.max(i3, Math.min(i4, x2));
                            if (Math.abs(0 - max) >= 2.0f) {
                                float f2 = c0050g.f1458k;
                                int computeHorizontalScrollRange = c0050g.f1461n.computeHorizontalScrollRange();
                                c0050g.f1461n.computeHorizontalScrollOffset();
                                int d2 = C0050g.d(f2, max, iArr, computeHorizontalScrollRange, 0, c0050g.f1459l);
                                if (d2 != 0) {
                                    c0050g.f1461n.scrollBy(d2, 0);
                                }
                                c0050g.f1458k = max;
                            }
                        }
                        if (c0050g.f1465r == 2) {
                            float y2 = motionEvent.getY();
                            int[] iArr2 = c0050g.f1466s;
                            iArr2[0] = i3;
                            int i5 = c0050g.f1460m - i3;
                            iArr2[1] = i5;
                            float max2 = Math.max(i3, Math.min(i5, y2));
                            if (Math.abs(0 - max2) >= 2.0f) {
                                float f3 = c0050g.f1457j;
                                int computeVerticalScrollRange = c0050g.f1461n.computeVerticalScrollRange();
                                c0050g.f1461n.computeVerticalScrollOffset();
                                int d3 = C0050g.d(f3, max2, iArr2, computeVerticalScrollRange, 0, c0050g.f1460m);
                                if (d3 != 0) {
                                    c0050g.f1461n.scrollBy(0, d3);
                                }
                                c0050g.f1457j = max2;
                            }
                        }
                    }
                }
                if (action == 3 || action == 1) {
                    this.f2373l = null;
                }
                p();
                setScrollState(0);
                return true;
            }
            this.f2373l = null;
        }
        if (action != 0) {
            ArrayList arrayList = this.f2372k;
            int size = arrayList.size();
            for (int i6 = 0; i6 < size; i6++) {
                C0050g c0050g2 = (C0050g) arrayList.get(i6);
                if (c0050g2.c(motionEvent)) {
                    this.f2373l = c0050g2;
                    p();
                    setScrollState(0);
                    return true;
                }
            }
        }
        v vVar = this.f2368i;
        if (vVar == null) {
            return false;
        }
        boolean b3 = vVar.b();
        boolean c2 = this.f2368i.c();
        if (this.G == null) {
            this.G = VelocityTracker.obtain();
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        int[] iArr3 = this.f2371j0;
        if (actionMasked == 0) {
            iArr3[1] = 0;
            iArr3[0] = 0;
        }
        obtain.offsetLocation(iArr3[0], iArr3[1]);
        if (actionMasked == 0) {
            this.f2342F = motionEvent.getPointerId(0);
            int x3 = (int) (motionEvent.getX() + 0.5f);
            this.f2345J = x3;
            this.f2343H = x3;
            int y3 = (int) (motionEvent.getY() + 0.5f);
            this.f2346K = y3;
            this.f2344I = y3;
            int i7 = b3;
            if (c2) {
                i7 = (b3 ? 1 : 0) | 2;
            }
            getScrollingChildHelper().g(i7, 0);
        } else {
            if (actionMasked == 1) {
                this.G.addMovement(obtain);
                VelocityTracker velocityTracker = this.G;
                int i8 = this.f2349S;
                velocityTracker.computeCurrentVelocity(AppMetricaDefaultValues.DEFAULT_MAX_REPORTS_IN_DATABASE_COUNT, i8);
                float f4 = b3 != 0 ? -this.G.getXVelocity(this.f2342F) : 0.0f;
                float f5 = c2 ? -this.G.getYVelocity(this.f2342F) : 0.0f;
                if (f4 != 0.0f || f5 != 0.0f) {
                    int i9 = (int) f4;
                    int i10 = (int) f5;
                    v vVar2 = this.f2368i;
                    if (vVar2 == null) {
                        Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                    } else if (!this.f2379q) {
                        boolean b4 = vVar2.b();
                        boolean c3 = this.f2368i.c();
                        int i11 = this.f2348R;
                        if (b4 == 0 || Math.abs(i9) < i11) {
                            i9 = 0;
                        }
                        if (!c3 || Math.abs(i10) < i11) {
                            i10 = 0;
                        }
                        if (i9 != 0 || i10 != 0) {
                            float f6 = i9;
                            float f7 = i10;
                            if (!dispatchNestedPreFling(f6, f7)) {
                                boolean z3 = b4 != 0 || c3;
                                dispatchNestedFling(f6, f7, z3);
                                int i12 = b4;
                                if (z3) {
                                    if (c3) {
                                        i12 = (b4 ? 1 : 0) | 2;
                                    }
                                    getScrollingChildHelper().g(i12, 1);
                                    int i13 = -i8;
                                    int max3 = Math.max(i13, Math.min(i9, i8));
                                    int max4 = Math.max(i13, Math.min(i10, i8));
                                    G g2 = this.f2353W;
                                    g2.f1402g.setScrollState(2);
                                    g2.f1397b = 0;
                                    g2.f1396a = 0;
                                    g2.f1398c.fling(0, 0, max3, max4, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                    g2.a();
                                    p();
                                    obtain.recycle();
                                    return true;
                                }
                            }
                        }
                    }
                }
                setScrollState(0);
                p();
                obtain.recycle();
                return true;
            }
            if (actionMasked == 2) {
                int findPointerIndex = motionEvent.findPointerIndex(this.f2342F);
                if (findPointerIndex < 0) {
                    Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f2342F + " not found. Did any MotionEvents get skipped?");
                    return false;
                }
                int x4 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                int y4 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                int i14 = this.f2345J - x4;
                int i15 = this.f2346K - y4;
                boolean f8 = f(i14, i15, this.f2369i0, this.f2367h0, 0);
                int[] iArr4 = this.f2367h0;
                if (f8) {
                    int[] iArr5 = this.f2369i0;
                    i14 -= iArr5[0];
                    i15 -= iArr5[1];
                    obtain.offsetLocation(iArr4[0], iArr4[1]);
                    iArr3[0] = iArr3[0] + iArr4[0];
                    iArr3[1] = iArr3[1] + iArr4[1];
                }
                if (this.f2341E != 1) {
                    if (b3 != 0) {
                        int abs = Math.abs(i14);
                        int i16 = this.f2347L;
                        if (abs > i16) {
                            i14 = i14 > 0 ? i14 - i16 : i14 + i16;
                            z2 = true;
                            if (c2) {
                                int abs2 = Math.abs(i15);
                                int i17 = this.f2347L;
                                if (abs2 > i17) {
                                    i15 = i15 > 0 ? i15 - i17 : i15 + i17;
                                    z2 = true;
                                }
                            }
                            if (z2) {
                                setScrollState(1);
                            }
                        }
                    }
                    z2 = false;
                    if (c2) {
                    }
                    if (z2) {
                    }
                }
                int i18 = i15;
                if (this.f2341E == 1) {
                    this.f2345J = x4 - iArr4[0];
                    this.f2346K = y4 - iArr4[1];
                    q(b3 != 0 ? i14 : 0, c2 ? i18 : 0, obtain);
                    RunnableC0053j runnableC0053j = this.f2355a0;
                    if (runnableC0053j != null && (i14 != 0 || i18 != 0)) {
                        runnableC0053j.a(this, i14, i18);
                    }
                }
            } else if (actionMasked == 3) {
                p();
                setScrollState(0);
            } else if (actionMasked == 5) {
                this.f2342F = motionEvent.getPointerId(actionIndex);
                int x5 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                this.f2345J = x5;
                this.f2343H = x5;
                int y5 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                this.f2346K = y5;
                this.f2344I = y5;
            } else if (actionMasked == 6) {
                n(motionEvent);
            }
        }
        this.G.addMovement(obtain);
        obtain.recycle();
        return true;
    }

    public final void p() {
        VelocityTracker velocityTracker = this.G;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z2 = false;
        s(0);
        EdgeEffect edgeEffect = this.f2387z;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.f2387z.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f2337A;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.f2337A.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2338B;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.f2338B.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2339C;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.f2339C.isFinished();
        }
        if (z2) {
            Field field = x.f8355a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0171  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void q(int i2, int i3, MotionEvent motionEvent) {
        d();
        if (!this.f2370j.isEmpty()) {
            invalidate();
        }
        int[] iArr = this.f2367h0;
        boolean z2 = false;
        boolean z3 = true;
        if (g(iArr, 0)) {
            int i4 = this.f2345J;
            int i5 = iArr[0];
            this.f2345J = i4 - i5;
            int i6 = this.f2346K;
            int i7 = iArr[1];
            this.f2346K = i6 - i7;
            if (motionEvent != null) {
                motionEvent.offsetLocation(i5, i7);
            }
            int[] iArr2 = this.f2371j0;
            iArr2[0] = iArr2[0] + iArr[0];
            iArr2[1] = iArr2[1] + iArr[1];
        } else if (getOverScrollMode() != 2) {
            if (motionEvent != null && (motionEvent.getSource() & 8194) != 8194) {
                float x2 = motionEvent.getX();
                float f2 = 0;
                float y2 = motionEvent.getY();
                if (f2 < 0.0f) {
                    if (this.f2387z == null) {
                        this.f2386y.getClass();
                        EdgeEffect edgeEffect = new EdgeEffect(getContext());
                        this.f2387z = edgeEffect;
                        if (this.f2363f) {
                            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
                        } else {
                            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
                        }
                    }
                    d.a(this.f2387z, (-f2) / getWidth(), 1.0f - (y2 / getHeight()));
                } else {
                    if (f2 > 0.0f) {
                        if (this.f2338B == null) {
                            this.f2386y.getClass();
                            EdgeEffect edgeEffect2 = new EdgeEffect(getContext());
                            this.f2338B = edgeEffect2;
                            if (this.f2363f) {
                                edgeEffect2.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
                            } else {
                                edgeEffect2.setSize(getMeasuredHeight(), getMeasuredWidth());
                            }
                        }
                        d.a(this.f2338B, f2 / getWidth(), y2 / getHeight());
                    }
                    if (f2 >= 0.0f) {
                        if (this.f2337A == null) {
                            this.f2386y.getClass();
                            EdgeEffect edgeEffect3 = new EdgeEffect(getContext());
                            this.f2337A = edgeEffect3;
                            if (this.f2363f) {
                                edgeEffect3.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
                            } else {
                                edgeEffect3.setSize(getMeasuredWidth(), getMeasuredHeight());
                            }
                        }
                        d.a(this.f2337A, (-f2) / getHeight(), x2 / getWidth());
                    } else if (f2 > 0.0f) {
                        if (this.f2339C == null) {
                            this.f2386y.getClass();
                            EdgeEffect edgeEffect4 = new EdgeEffect(getContext());
                            this.f2339C = edgeEffect4;
                            if (this.f2363f) {
                                edgeEffect4.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
                            } else {
                                edgeEffect4.setSize(getMeasuredWidth(), getMeasuredHeight());
                            }
                        }
                        d.a(this.f2339C, f2 / getHeight(), 1.0f - (x2 / getWidth()));
                    } else {
                        z3 = z2;
                    }
                    if (!z3 || f2 != 0.0f || f2 != 0.0f) {
                        Field field = x.f8355a;
                        postInvalidateOnAnimation();
                    }
                }
                z2 = true;
                if (f2 >= 0.0f) {
                }
                if (!z3) {
                }
                Field field2 = x.f8355a;
                postInvalidateOnAnimation();
            }
            c(i2, i3);
        }
        if (awakenScrollBars()) {
            return;
        }
        invalidate();
    }

    public final void r(int i2, int i3) {
        int i4;
        v vVar = this.f2368i;
        if (vVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2379q) {
            return;
        }
        int i5 = !vVar.b() ? 0 : i2;
        int i6 = !this.f2368i.c() ? 0 : i3;
        if (i5 == 0 && i6 == 0) {
            return;
        }
        G g2 = this.f2353W;
        g2.getClass();
        int abs = Math.abs(i5);
        int abs2 = Math.abs(i6);
        boolean z2 = abs > abs2;
        int sqrt = (int) Math.sqrt(0);
        int sqrt2 = (int) Math.sqrt((i6 * i6) + (i5 * i5));
        RecyclerView recyclerView = g2.f1402g;
        int width = z2 ? recyclerView.getWidth() : recyclerView.getHeight();
        int i7 = width / 2;
        float f2 = width;
        float f3 = i7;
        float sin = (((float) Math.sin((Math.min(1.0f, (sqrt2 * 1.0f) / f2) - 0.5f) * 0.47123894f)) * f3) + f3;
        if (sqrt > 0) {
            i4 = Math.round(Math.abs(sin / sqrt) * 1000.0f) * 4;
        } else {
            if (!z2) {
                abs = abs2;
            }
            i4 = (int) (((abs / f2) + 1.0f) * 300.0f);
        }
        int min = Math.min(i4, 2000);
        p pVar = f2336p0;
        if (g2.f1399d != pVar) {
            g2.f1399d = pVar;
            g2.f1398c = new OverScroller(recyclerView.getContext(), pVar);
        }
        recyclerView.setScrollState(2);
        g2.f1397b = 0;
        g2.f1396a = 0;
        g2.f1398c.startScroll(0, 0, i5, i6, min);
        g2.a();
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z2) {
        j(view);
        view.clearAnimation();
        j(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        this.f2368i.getClass();
        if (this.f2384w <= 0 && view2 != null) {
            o(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f2368i.G(this, view, rect, z2, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        ArrayList arrayList = this.f2372k;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((C0050g) arrayList.get(i2)).getClass();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f2378p != 0 || this.f2379q) {
            return;
        }
        super.requestLayout();
    }

    public final void s(int i2) {
        getScrollingChildHelper().h(i2);
    }

    @Override // android.view.View
    public final void scrollBy(int i2, int i3) {
        v vVar = this.f2368i;
        if (vVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2379q) {
            return;
        }
        boolean b2 = vVar.b();
        boolean c2 = this.f2368i.c();
        if (b2 || c2) {
            if (!b2) {
                i2 = 0;
            }
            if (!c2) {
                i3 = 0;
            }
            q(i2, i3, null);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (this.f2384w <= 0) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.f2381s |= contentChangeTypes != 0 ? contentChangeTypes : 0;
        }
    }

    public void setAccessibilityDelegateCompat(I i2) {
        this.f0 = i2;
        x.a(this, i2);
    }

    public void setAdapter(P.q qVar) {
        setLayoutFrozen(false);
        t tVar = this.f2340D;
        if (tVar != null) {
            tVar.a();
        }
        v vVar = this.f2368i;
        B b2 = this.f2354a;
        if (vVar != null) {
            vVar.E();
            this.f2368i.F(b2);
        }
        b2.f1384a.clear();
        ArrayList arrayList = b2.f1385b;
        int size = arrayList.size() - 1;
        if (size >= 0) {
            A1.a.p(arrayList.get(size));
            throw null;
        }
        arrayList.clear();
        C0051h c0051h = b2.f1389f.f2357b0;
        c0051h.getClass();
        c0051h.f1472c = 0;
        f fVar = this.f2358c;
        fVar.N((ArrayList) fVar.f945c);
        fVar.N((ArrayList) fVar.f946d);
        b2.f1384a.clear();
        ArrayList arrayList2 = b2.f1385b;
        int size2 = arrayList2.size() - 1;
        if (size2 >= 0) {
            A1.a.p(arrayList2.get(size2));
            throw null;
        }
        arrayList2.clear();
        RecyclerView recyclerView = b2.f1389f;
        C0051h c0051h2 = recyclerView.f2357b0;
        c0051h2.getClass();
        c0051h2.f1472c = 0;
        if (b2.f1388e == null) {
            A a2 = new A();
            a2.f1382a = new SparseArray();
            a2.f1383b = 0;
            b2.f1388e = a2;
        }
        A a3 = b2.f1388e;
        if (a3.f1383b == 0) {
            SparseArray sparseArray = a3.f1382a;
            if (sparseArray.size() > 0) {
                ((z) sparseArray.valueAt(0)).getClass();
                throw null;
            }
        }
        this.f2359c0.f1392b = true;
        this.f2383v = this.f2383v;
        this.f2382u = true;
        int D2 = this.f2360d.D();
        for (int i2 = 0; i2 < D2; i2++) {
            j(this.f2360d.C(i2));
        }
        m();
        int size3 = arrayList2.size();
        for (int i3 = 0; i3 < size3; i3++) {
            if (arrayList2.get(i3) != null) {
                throw new ClassCastException();
            }
        }
        int size4 = arrayList2.size() - 1;
        if (size4 >= 0) {
            A1.a.p(arrayList2.get(size4));
            throw null;
        }
        arrayList2.clear();
        C0051h c0051h3 = recyclerView.f2357b0;
        c0051h3.getClass();
        c0051h3.f1472c = 0;
        requestLayout();
    }

    public void setChildDrawingOrderCallback(P.r rVar) {
        if (rVar == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.f2363f) {
            this.f2339C = null;
            this.f2337A = null;
            this.f2338B = null;
            this.f2387z = null;
        }
        this.f2363f = z2;
        super.setClipToPadding(z2);
        if (this.f2377o) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(s sVar) {
        sVar.getClass();
        this.f2386y = sVar;
        this.f2339C = null;
        this.f2337A = null;
        this.f2338B = null;
        this.f2387z = null;
    }

    public void setHasFixedSize(boolean z2) {
        this.f2376n = z2;
    }

    public void setItemAnimator(t tVar) {
        t tVar2 = this.f2340D;
        if (tVar2 != null) {
            tVar2.a();
            this.f2340D.f1496a = null;
        }
        this.f2340D = tVar;
        if (tVar != null) {
            tVar.f1496a = this.e0;
        }
    }

    public void setItemViewCacheSize(int i2) {
        B b2 = this.f2354a;
        b2.f1386c = i2;
        b2.b();
    }

    public void setLayoutFrozen(boolean z2) {
        if (z2 != this.f2379q) {
            b("Do not setLayoutFrozen in layout or scroll");
            if (!z2) {
                this.f2379q = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f2379q = true;
            this.f2380r = true;
            setScrollState(0);
            G g2 = this.f2353W;
            g2.f1402g.removeCallbacks(g2);
            g2.f1398c.abortAnimation();
        }
    }

    public void setLayoutManager(v vVar) {
        q qVar;
        if (vVar == this.f2368i) {
            return;
        }
        setScrollState(0);
        G g2 = this.f2353W;
        g2.f1402g.removeCallbacks(g2);
        g2.f1398c.abortAnimation();
        v vVar2 = this.f2368i;
        B b2 = this.f2354a;
        if (vVar2 != null) {
            t tVar = this.f2340D;
            if (tVar != null) {
                tVar.a();
            }
            this.f2368i.E();
            this.f2368i.F(b2);
            b2.f1384a.clear();
            ArrayList arrayList = b2.f1385b;
            int size = arrayList.size() - 1;
            if (size >= 0) {
                A1.a.p(arrayList.get(size));
                throw null;
            }
            arrayList.clear();
            C0051h c0051h = b2.f1389f.f2357b0;
            c0051h.getClass();
            c0051h.f1472c = 0;
            if (this.f2375m) {
                v vVar3 = this.f2368i;
                vVar3.f1506e = false;
                vVar3.z(this);
            }
            this.f2368i.I(null);
            this.f2368i = null;
        } else {
            b2.f1384a.clear();
            ArrayList arrayList2 = b2.f1385b;
            int size2 = arrayList2.size() - 1;
            if (size2 >= 0) {
                A1.a.p(arrayList2.get(size2));
                throw null;
            }
            arrayList2.clear();
            C0051h c0051h2 = b2.f1389f.f2357b0;
            c0051h2.getClass();
            c0051h2.f1472c = 0;
        }
        f fVar = this.f2360d;
        ((C0045b) fVar.f945c).c();
        ArrayList arrayList3 = (ArrayList) fVar.f946d;
        int size3 = arrayList3.size() - 1;
        while (true) {
            qVar = (q) fVar.f944b;
            if (size3 < 0) {
                break;
            }
            j((View) arrayList3.get(size3));
            arrayList3.remove(size3);
            size3--;
        }
        RecyclerView recyclerView = (RecyclerView) qVar.f110b;
        int childCount = recyclerView.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = recyclerView.getChildAt(i2);
            j(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f2368i = vVar;
        if (vVar != null) {
            if (vVar.f1503b != null) {
                throw new IllegalArgumentException("LayoutManager " + vVar + " is already attached to a RecyclerView:" + vVar.f1503b.h());
            }
            vVar.I(this);
            if (this.f2375m) {
                this.f2368i.f1506e = true;
            }
        }
        b2.b();
        requestLayout();
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        C1028g scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f8345d) {
            Field field = x.f8355a;
            AbstractC1037p.z(scrollingChildHelper.f8344c);
        }
        scrollingChildHelper.f8345d = z2;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f2352V = z2;
    }

    public void setRecycledViewPool(A a2) {
        B b2 = this.f2354a;
        if (b2.f1388e != null) {
            r1.f1383b--;
        }
        b2.f1388e = a2;
        if (a2 != null) {
            b2.f1389f.getAdapter();
        }
    }

    public void setScrollState(int i2) {
        if (i2 == this.f2341E) {
            return;
        }
        this.f2341E = i2;
        if (i2 != 2) {
            G g2 = this.f2353W;
            g2.f1402g.removeCallbacks(g2);
            g2.f1398c.abortAnimation();
        }
        v vVar = this.f2368i;
        if (vVar != null) {
            vVar.D(i2);
        }
        ArrayList arrayList = this.f2361d0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((P.y) this.f2361d0.get(size)).getClass();
            }
        }
    }

    public void setScrollingTouchSlop(int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                this.f2347L = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
        }
        this.f2347L = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(F f2) {
        this.f2354a.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().g(i2, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        v vVar = this.f2368i;
        if (vVar != null) {
            return vVar.n(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + h());
    }

    public void setOnFlingListener(P.x xVar) {
    }

    @Deprecated
    public void setOnScrollListener(P.y yVar) {
    }

    public void setRecyclerListener(C c2) {
    }
}
