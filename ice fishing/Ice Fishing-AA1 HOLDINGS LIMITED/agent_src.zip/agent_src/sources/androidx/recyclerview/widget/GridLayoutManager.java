package androidx.recyclerview.widget;

import A1.a;
import B1.q;
import P.B;
import P.C0054k;
import P.E;
import P.v;
import P.w;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: p, reason: collision with root package name */
    public final int f2323p;

    /* renamed from: q, reason: collision with root package name */
    public final q f2324q;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f2323p = -1;
        new SparseIntArray();
        new SparseIntArray();
        q qVar = new q(14);
        this.f2324q = qVar;
        new Rect();
        int i4 = v.w(context, attributeSet, i2, i3).f1489c;
        if (i4 == this.f2323p) {
            return;
        }
        if (i4 < 1) {
            throw new IllegalArgumentException(a.g(i4, "Span count should be at least 1. Provided "));
        }
        this.f2323p = i4;
        ((SparseIntArray) qVar.f110b).clear();
        H();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void Q(boolean z2) {
        if (z2) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.Q(false);
    }

    public final int R(B b2, E e2, int i2) {
        boolean z2 = e2.f1393c;
        q qVar = this.f2324q;
        if (!z2) {
            int i3 = this.f2323p;
            qVar.getClass();
            return q.p(i2, i3);
        }
        RecyclerView recyclerView = b2.f1389f;
        if (i2 < 0 || i2 >= recyclerView.f2359c0.a()) {
            throw new IndexOutOfBoundsException("invalid position " + i2 + ". State item count is " + recyclerView.f2359c0.a() + recyclerView.h());
        }
        int x2 = !recyclerView.f2359c0.f1393c ? i2 : recyclerView.f2358c.x(i2, 0);
        if (x2 != -1) {
            int i4 = this.f2323p;
            qVar.getClass();
            return q.p(x2, i4);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i2);
        return 0;
    }

    @Override // P.v
    public final boolean d(w wVar) {
        return wVar instanceof C0054k;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, P.v
    public final w l() {
        return this.f2325h == 0 ? new C0054k(-2, -1) : new C0054k(-1, -2);
    }

    @Override // P.v
    public final w m(Context context, AttributeSet attributeSet) {
        return new C0054k(context, attributeSet);
    }

    @Override // P.v
    public final w n(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0054k((ViewGroup.MarginLayoutParams) layoutParams) : new C0054k(layoutParams);
    }

    @Override // P.v
    public final int q(B b2, E e2) {
        if (this.f2325h == 1) {
            return this.f2323p;
        }
        if (e2.a() < 1) {
            return 0;
        }
        return R(b2, e2, e2.a() - 1) + 1;
    }

    @Override // P.v
    public final int x(B b2, E e2) {
        if (this.f2325h == 0) {
            return this.f2323p;
        }
        if (e2.a() < 1) {
            return 0;
        }
        return R(b2, e2, e2.a() - 1) + 1;
    }
}
