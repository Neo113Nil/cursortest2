package androidx.recyclerview.widget;

import H1.m;
import L.b;
import P.B;
import P.C0055l;
import P.C0056m;
import P.E;
import P.J;
import P.L;
import P.M;
import P.v;
import P.w;
import a.AbstractC0059a;
import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.util.BitSet;
import m0.j;
import y.x;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends v {

    /* renamed from: h, reason: collision with root package name */
    public final int f2388h;

    /* renamed from: i, reason: collision with root package name */
    public final M[] f2389i;

    /* renamed from: j, reason: collision with root package name */
    public final b f2390j;

    /* renamed from: k, reason: collision with root package name */
    public final b f2391k;

    /* renamed from: l, reason: collision with root package name */
    public final int f2392l;

    /* renamed from: m, reason: collision with root package name */
    public final boolean f2393m;

    /* renamed from: n, reason: collision with root package name */
    public final boolean f2394n = false;

    /* renamed from: o, reason: collision with root package name */
    public final m f2395o;

    /* renamed from: p, reason: collision with root package name */
    public final int f2396p;

    /* renamed from: q, reason: collision with root package name */
    public L f2397q;

    /* renamed from: r, reason: collision with root package name */
    public final boolean f2398r;

    /* renamed from: s, reason: collision with root package name */
    public final C.b f2399s;

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f2388h = -1;
        this.f2393m = false;
        m mVar = new m();
        this.f2395o = mVar;
        this.f2396p = 2;
        new Rect();
        new j(16, this);
        this.f2398r = true;
        this.f2399s = new C.b(6, this);
        C0056m w2 = v.w(context, attributeSet, i2, i3);
        int i4 = w2.f1488b;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        a(null);
        if (i4 != this.f2392l) {
            this.f2392l = i4;
            b bVar = this.f2390j;
            this.f2390j = this.f2391k;
            this.f2391k = bVar;
            H();
        }
        int i5 = w2.f1489c;
        a(null);
        if (i5 != this.f2388h) {
            mVar.f751a = null;
            H();
            this.f2388h = i5;
            new BitSet(this.f2388h);
            this.f2389i = new M[this.f2388h];
            for (int i6 = 0; i6 < this.f2388h; i6++) {
                this.f2389i[i6] = new M(this, i6);
            }
            H();
        }
        boolean z2 = w2.f1490d;
        a(null);
        L l2 = this.f2397q;
        if (l2 != null && l2.f1416h != z2) {
            l2.f1416h = z2;
        }
        this.f2393m = z2;
        H();
        C0055l c0055l = new C0055l(0);
        c0055l.f1485b = 0;
        c0055l.f1486c = 0;
        this.f2390j = b.a(this, this.f2392l);
        this.f2391k = b.a(this, 1 - this.f2392l);
    }

    @Override // P.v
    public final void A(AccessibilityEvent accessibilityEvent) {
        super.A(accessibilityEvent);
        if (p() > 0) {
            View O2 = O(false);
            View N2 = N(false);
            if (O2 == null || N2 == null) {
                return;
            }
            ((w) O2.getLayoutParams()).getClass();
            throw null;
        }
    }

    @Override // P.v
    public final void B(Parcelable parcelable) {
        if (parcelable instanceof L) {
            this.f2397q = (L) parcelable;
            H();
        }
    }

    @Override // P.v
    public final Parcelable C() {
        L l2 = this.f2397q;
        if (l2 != null) {
            L l3 = new L();
            l3.f1411c = l2.f1411c;
            l3.f1409a = l2.f1409a;
            l3.f1410b = l2.f1410b;
            l3.f1412d = l2.f1412d;
            l3.f1413e = l2.f1413e;
            l3.f1414f = l2.f1414f;
            l3.f1416h = l2.f1416h;
            l3.f1417i = l2.f1417i;
            l3.f1418j = l2.f1418j;
            l3.f1415g = l2.f1415g;
            return l3;
        }
        L l4 = new L();
        l4.f1416h = this.f2393m;
        l4.f1417i = false;
        l4.f1418j = false;
        l4.f1413e = 0;
        if (p() > 0) {
            P();
            l4.f1409a = 0;
            View N2 = this.f2394n ? N(true) : O(true);
            if (N2 != null) {
                ((w) N2.getLayoutParams()).getClass();
                throw null;
            }
            l4.f1410b = -1;
            int i2 = this.f2388h;
            l4.f1411c = i2;
            l4.f1412d = new int[i2];
            for (int i3 = 0; i3 < this.f2388h; i3++) {
                M m2 = this.f2389i[i3];
                int i4 = m2.f1420b;
                if (i4 == Integer.MIN_VALUE) {
                    if (m2.f1419a.size() == 0) {
                        i4 = Integer.MIN_VALUE;
                    } else {
                        View view = (View) m2.f1419a.get(0);
                        J j2 = (J) view.getLayoutParams();
                        m2.f1420b = m2.f1423e.f2390j.c(view);
                        j2.getClass();
                        i4 = m2.f1420b;
                    }
                }
                if (i4 != Integer.MIN_VALUE) {
                    i4 -= this.f2390j.e();
                }
                l4.f1412d[i3] = i4;
            }
        } else {
            l4.f1409a = -1;
            l4.f1410b = -1;
            l4.f1411c = 0;
        }
        return l4;
    }

    @Override // P.v
    public final void D(int i2) {
        if (i2 == 0) {
            J();
        }
    }

    public final boolean J() {
        int i2 = this.f2388h;
        boolean z2 = this.f2394n;
        if (p() == 0 || this.f2396p == 0 || !this.f1506e) {
            return false;
        }
        if (z2) {
            Q();
            P();
        } else {
            P();
            Q();
        }
        int p2 = p();
        int i3 = p2 - 1;
        new BitSet(i2).set(0, i2, true);
        if (this.f2392l == 1) {
            RecyclerView recyclerView = this.f1503b;
            Field field = x.f8355a;
            if (recyclerView.getLayoutDirection() != 1) {
            }
        }
        if (z2) {
            p2 = -1;
        } else {
            i3 = 0;
        }
        if (i3 == p2) {
            return false;
        }
        ((J) o(i3).getLayoutParams()).getClass();
        throw null;
    }

    public final int K(E e2) {
        if (p() == 0) {
            return 0;
        }
        b bVar = this.f2390j;
        boolean z2 = !this.f2398r;
        return AbstractC0059a.h(e2, bVar, O(z2), N(z2), this, this.f2398r);
    }

    public final void L(E e2) {
        if (p() == 0) {
            return;
        }
        boolean z2 = !this.f2398r;
        View O2 = O(z2);
        View N2 = N(z2);
        if (p() == 0 || e2.a() == 0 || O2 == null || N2 == null) {
            return;
        }
        ((w) O2.getLayoutParams()).getClass();
        throw null;
    }

    public final int M(E e2) {
        if (p() == 0) {
            return 0;
        }
        b bVar = this.f2390j;
        boolean z2 = !this.f2398r;
        return AbstractC0059a.i(e2, bVar, O(z2), N(z2), this, this.f2398r);
    }

    public final View N(boolean z2) {
        int e2 = this.f2390j.e();
        int d2 = this.f2390j.d();
        View view = null;
        for (int p2 = p() - 1; p2 >= 0; p2--) {
            View o2 = o(p2);
            int c2 = this.f2390j.c(o2);
            int b2 = this.f2390j.b(o2);
            if (b2 > e2 && c2 < d2) {
                if (b2 <= d2 || !z2) {
                    return o2;
                }
                if (view == null) {
                    view = o2;
                }
            }
        }
        return view;
    }

    public final View O(boolean z2) {
        int e2 = this.f2390j.e();
        int d2 = this.f2390j.d();
        int p2 = p();
        View view = null;
        for (int i2 = 0; i2 < p2; i2++) {
            View o2 = o(i2);
            int c2 = this.f2390j.c(o2);
            if (this.f2390j.b(o2) > e2 && c2 < d2) {
                if (c2 >= e2 || !z2) {
                    return o2;
                }
                if (view == null) {
                    view = o2;
                }
            }
        }
        return view;
    }

    public final void P() {
        if (p() == 0) {
            return;
        }
        v.v(o(0));
        throw null;
    }

    public final void Q() {
        int p2 = p();
        if (p2 == 0) {
            return;
        }
        v.v(o(p2 - 1));
        throw null;
    }

    @Override // P.v
    public final void a(String str) {
        RecyclerView recyclerView;
        if (this.f2397q != null || (recyclerView = this.f1503b) == null) {
            return;
        }
        recyclerView.b(str);
    }

    @Override // P.v
    public final boolean b() {
        return this.f2392l == 0;
    }

    @Override // P.v
    public final boolean c() {
        return this.f2392l == 1;
    }

    @Override // P.v
    public final boolean d(w wVar) {
        return wVar instanceof J;
    }

    @Override // P.v
    public final int f(E e2) {
        return K(e2);
    }

    @Override // P.v
    public final void g(E e2) {
        L(e2);
    }

    @Override // P.v
    public final int h(E e2) {
        return M(e2);
    }

    @Override // P.v
    public final int i(E e2) {
        return K(e2);
    }

    @Override // P.v
    public final void j(E e2) {
        L(e2);
    }

    @Override // P.v
    public final int k(E e2) {
        return M(e2);
    }

    @Override // P.v
    public final w l() {
        return this.f2392l == 0 ? new J(-2, -1) : new J(-1, -2);
    }

    @Override // P.v
    public final w m(Context context, AttributeSet attributeSet) {
        return new J(context, attributeSet);
    }

    @Override // P.v
    public final w n(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new J((ViewGroup.MarginLayoutParams) layoutParams) : new J(layoutParams);
    }

    @Override // P.v
    public final int q(B b2, E e2) {
        if (this.f2392l == 1) {
            return this.f2388h;
        }
        super.q(b2, e2);
        return 1;
    }

    @Override // P.v
    public final int x(B b2, E e2) {
        if (this.f2392l == 0) {
            return this.f2388h;
        }
        super.x(b2, e2);
        return 1;
    }

    @Override // P.v
    public final boolean y() {
        return this.f2396p != 0;
    }

    @Override // P.v
    public final void z(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f1503b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.f2399s);
        }
        for (int i2 = 0; i2 < this.f2388h; i2++) {
            M m2 = this.f2389i[i2];
            m2.f1419a.clear();
            m2.f1420b = Integer.MIN_VALUE;
            m2.f1421c = Integer.MIN_VALUE;
        }
        recyclerView.requestLayout();
    }
}
