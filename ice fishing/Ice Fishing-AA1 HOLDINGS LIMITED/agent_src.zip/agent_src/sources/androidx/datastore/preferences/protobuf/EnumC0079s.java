package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF0' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: androidx.datastore.preferences.protobuf.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0079s {

    /* renamed from: b, reason: collision with root package name */
    public static final EnumC0079s f2248b;

    /* renamed from: c, reason: collision with root package name */
    public static final EnumC0079s f2249c;

    /* renamed from: d, reason: collision with root package name */
    public static final EnumC0079s[] f2250d;

    /* renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ EnumC0079s[] f2251e;

    /* renamed from: a, reason: collision with root package name */
    public final int f2252a;

    /* JADX INFO: Fake field, exist only in values array */
    EnumC0079s EF0;

    static {
        B b2 = B.DOUBLE;
        EnumC0079s enumC0079s = new EnumC0079s("DOUBLE", 0, 0, 1, b2);
        B b3 = B.FLOAT;
        EnumC0079s enumC0079s2 = new EnumC0079s("FLOAT", 1, 1, 1, b3);
        B b4 = B.LONG;
        EnumC0079s enumC0079s3 = new EnumC0079s("INT64", 2, 2, 1, b4);
        EnumC0079s enumC0079s4 = new EnumC0079s("UINT64", 3, 3, 1, b4);
        B b5 = B.INT;
        EnumC0079s enumC0079s5 = new EnumC0079s("INT32", 4, 4, 1, b5);
        EnumC0079s enumC0079s6 = new EnumC0079s("FIXED64", 5, 5, 1, b4);
        EnumC0079s enumC0079s7 = new EnumC0079s("FIXED32", 6, 6, 1, b5);
        B b6 = B.BOOLEAN;
        EnumC0079s enumC0079s8 = new EnumC0079s("BOOL", 7, 7, 1, b6);
        B b7 = B.STRING;
        EnumC0079s enumC0079s9 = new EnumC0079s("STRING", 8, 8, 1, b7);
        B b8 = B.MESSAGE;
        EnumC0079s enumC0079s10 = new EnumC0079s("MESSAGE", 9, 9, 1, b8);
        B b9 = B.BYTE_STRING;
        EnumC0079s enumC0079s11 = new EnumC0079s("BYTES", 10, 10, 1, b9);
        EnumC0079s enumC0079s12 = new EnumC0079s("UINT32", 11, 11, 1, b5);
        B b10 = B.ENUM;
        EnumC0079s enumC0079s13 = new EnumC0079s("ENUM", 12, 12, 1, b10);
        EnumC0079s enumC0079s14 = new EnumC0079s("SFIXED32", 13, 13, 1, b5);
        EnumC0079s enumC0079s15 = new EnumC0079s("SFIXED64", 14, 14, 1, b4);
        EnumC0079s enumC0079s16 = new EnumC0079s("SINT32", 15, 15, 1, b5);
        EnumC0079s enumC0079s17 = new EnumC0079s("SINT64", 16, 16, 1, b4);
        EnumC0079s enumC0079s18 = new EnumC0079s("GROUP", 17, 17, 1, b8);
        EnumC0079s enumC0079s19 = new EnumC0079s("DOUBLE_LIST", 18, 18, 2, b2);
        EnumC0079s enumC0079s20 = new EnumC0079s("FLOAT_LIST", 19, 19, 2, b3);
        EnumC0079s enumC0079s21 = new EnumC0079s("INT64_LIST", 20, 20, 2, b4);
        EnumC0079s enumC0079s22 = new EnumC0079s("UINT64_LIST", 21, 21, 2, b4);
        EnumC0079s enumC0079s23 = new EnumC0079s("INT32_LIST", 22, 22, 2, b5);
        EnumC0079s enumC0079s24 = new EnumC0079s("FIXED64_LIST", 23, 23, 2, b4);
        EnumC0079s enumC0079s25 = new EnumC0079s("FIXED32_LIST", 24, 24, 2, b5);
        EnumC0079s enumC0079s26 = new EnumC0079s("BOOL_LIST", 25, 25, 2, b6);
        EnumC0079s enumC0079s27 = new EnumC0079s("STRING_LIST", 26, 26, 2, b7);
        EnumC0079s enumC0079s28 = new EnumC0079s("MESSAGE_LIST", 27, 27, 2, b8);
        EnumC0079s enumC0079s29 = new EnumC0079s("BYTES_LIST", 28, 28, 2, b9);
        EnumC0079s enumC0079s30 = new EnumC0079s("UINT32_LIST", 29, 29, 2, b5);
        EnumC0079s enumC0079s31 = new EnumC0079s("ENUM_LIST", 30, 30, 2, b10);
        EnumC0079s enumC0079s32 = new EnumC0079s("SFIXED32_LIST", 31, 31, 2, b5);
        EnumC0079s enumC0079s33 = new EnumC0079s("SFIXED64_LIST", 32, 32, 2, b4);
        EnumC0079s enumC0079s34 = new EnumC0079s("SINT32_LIST", 33, 33, 2, b5);
        EnumC0079s enumC0079s35 = new EnumC0079s("SINT64_LIST", 34, 34, 2, b4);
        EnumC0079s enumC0079s36 = new EnumC0079s("DOUBLE_LIST_PACKED", 35, 35, 3, b2);
        f2248b = enumC0079s36;
        EnumC0079s enumC0079s37 = new EnumC0079s("FLOAT_LIST_PACKED", 36, 36, 3, b3);
        EnumC0079s enumC0079s38 = new EnumC0079s("INT64_LIST_PACKED", 37, 37, 3, b4);
        EnumC0079s enumC0079s39 = new EnumC0079s("UINT64_LIST_PACKED", 38, 38, 3, b4);
        EnumC0079s enumC0079s40 = new EnumC0079s("INT32_LIST_PACKED", 39, 39, 3, b5);
        EnumC0079s enumC0079s41 = new EnumC0079s("FIXED64_LIST_PACKED", 40, 40, 3, b4);
        EnumC0079s enumC0079s42 = new EnumC0079s("FIXED32_LIST_PACKED", 41, 41, 3, b5);
        EnumC0079s enumC0079s43 = new EnumC0079s("BOOL_LIST_PACKED", 42, 42, 3, b6);
        EnumC0079s enumC0079s44 = new EnumC0079s("UINT32_LIST_PACKED", 43, 43, 3, b5);
        EnumC0079s enumC0079s45 = new EnumC0079s("ENUM_LIST_PACKED", 44, 44, 3, b10);
        EnumC0079s enumC0079s46 = new EnumC0079s("SFIXED32_LIST_PACKED", 45, 45, 3, b5);
        EnumC0079s enumC0079s47 = new EnumC0079s("SFIXED64_LIST_PACKED", 46, 46, 3, b4);
        EnumC0079s enumC0079s48 = new EnumC0079s("SINT32_LIST_PACKED", 47, 47, 3, b5);
        EnumC0079s enumC0079s49 = new EnumC0079s("SINT64_LIST_PACKED", 48, 48, 3, b4);
        f2249c = enumC0079s49;
        f2251e = new EnumC0079s[]{enumC0079s, enumC0079s2, enumC0079s3, enumC0079s4, enumC0079s5, enumC0079s6, enumC0079s7, enumC0079s8, enumC0079s9, enumC0079s10, enumC0079s11, enumC0079s12, enumC0079s13, enumC0079s14, enumC0079s15, enumC0079s16, enumC0079s17, enumC0079s18, enumC0079s19, enumC0079s20, enumC0079s21, enumC0079s22, enumC0079s23, enumC0079s24, enumC0079s25, enumC0079s26, enumC0079s27, enumC0079s28, enumC0079s29, enumC0079s30, enumC0079s31, enumC0079s32, enumC0079s33, enumC0079s34, enumC0079s35, enumC0079s36, enumC0079s37, enumC0079s38, enumC0079s39, enumC0079s40, enumC0079s41, enumC0079s42, enumC0079s43, enumC0079s44, enumC0079s45, enumC0079s46, enumC0079s47, enumC0079s48, enumC0079s49, new EnumC0079s("GROUP_LIST", 49, 49, 2, b8), new EnumC0079s("MAP", 50, 50, 4, B.VOID)};
        EnumC0079s[] values = values();
        f2250d = new EnumC0079s[values.length];
        for (EnumC0079s enumC0079s50 : values) {
            f2250d[enumC0079s50.f2252a] = enumC0079s50;
        }
    }

    public EnumC0079s(String str, int i2, int i3, int i4, B b2) {
        this.f2252a = i3;
        int b3 = H.j.b(i4);
        if (b3 == 1) {
            b2.getClass();
        } else if (b3 == 3) {
            b2.getClass();
        }
        if (i4 == 1) {
            b2.ordinal();
        }
    }

    public static EnumC0079s valueOf(String str) {
        return (EnumC0079s) Enum.valueOf(EnumC0079s.class, str);
    }

    public static EnumC0079s[] values() {
        return (EnumC0079s[]) f2251e.clone();
    }

    public final int a() {
        return this.f2252a;
    }
}
