package androidx.datastore.preferences.protobuf;

import java.util.Map;

/* loaded from: classes.dex */
public final class Z implements Map.Entry, Comparable {

    /* renamed from: a, reason: collision with root package name */
    public final Comparable f2169a;

    /* renamed from: b, reason: collision with root package name */
    public Object f2170b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Y f2171c;

    public Z(Y y2, Comparable comparable, Object obj) {
        this.f2171c = y2;
        this.f2169a = comparable;
        this.f2170b = obj;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.f2169a.compareTo(((Z) obj).f2169a);
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        Comparable comparable = this.f2169a;
        if (comparable == null ? key == null : comparable.equals(key)) {
            Object obj2 = this.f2170b;
            Object value = entry.getValue();
            if (obj2 == null ? value == null : obj2.equals(value)) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f2169a;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f2170b;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Comparable comparable = this.f2169a;
        int hashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f2170b;
        return (obj != null ? obj.hashCode() : 0) ^ hashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        this.f2171c.b();
        Object obj2 = this.f2170b;
        this.f2170b = obj;
        return obj2;
    }

    public final String toString() {
        return this.f2169a + "=" + this.f2170b;
    }
}
