package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class D {

    /* renamed from: a, reason: collision with root package name */
    public static final C f2116a;

    /* renamed from: b, reason: collision with root package name */
    public static final C f2117b;

    static {
        T t = T.f2150c;
        C c2 = null;
        try {
            c2 = (C) Class.forName("androidx.datastore.preferences.protobuf.ListFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f2116a = c2;
        f2117b = new C();
    }
}
