package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* renamed from: androidx.datastore.preferences.protobuf.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0072k {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0071j f2221a;

    /* renamed from: b, reason: collision with root package name */
    public int f2222b;

    /* renamed from: c, reason: collision with root package name */
    public int f2223c;

    /* renamed from: d, reason: collision with root package name */
    public int f2224d = 0;

    public C0072k(AbstractC0071j abstractC0071j) {
        Charset charset = AbstractC0085y.f2267a;
        this.f2221a = abstractC0071j;
        abstractC0071j.f2214b = this;
    }

    public final int a() {
        int i2 = this.f2224d;
        if (i2 != 0) {
            this.f2222b = i2;
            this.f2224d = 0;
        } else {
            this.f2222b = this.f2221a.u();
        }
        int i3 = this.f2222b;
        if (i3 == 0 || i3 == this.f2223c) {
            return Integer.MAX_VALUE;
        }
        return i3 >>> 3;
    }

    public final void b(Object obj, W w2, C0076o c0076o) {
        int i2 = this.f2223c;
        this.f2223c = ((this.f2222b >>> 3) << 3) | 4;
        try {
            w2.b(obj, this, c0076o);
            if (this.f2222b == this.f2223c) {
            } else {
                throw new A("Failed to parse the message.");
            }
        } finally {
            this.f2223c = i2;
        }
    }

    public final void c(Object obj, W w2, C0076o c0076o) {
        AbstractC0071j abstractC0071j = this.f2221a;
        int v2 = abstractC0071j.v();
        if (abstractC0071j.f2213a >= 100) {
            throw new A("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        int e2 = abstractC0071j.e(v2);
        abstractC0071j.f2213a++;
        w2.b(obj, this, c0076o);
        abstractC0071j.a(0);
        abstractC0071j.f2213a--;
        abstractC0071j.d(e2);
    }

    public final void d(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Boolean.valueOf(abstractC0071j.f()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Boolean.valueOf(abstractC0071j.f()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final C0068g e() {
        w(2);
        return this.f2221a.g();
    }

    public final void f(InterfaceC0084x interfaceC0084x) {
        int u2;
        if ((this.f2222b & 7) != 2) {
            throw A.b();
        }
        do {
            ((U) interfaceC0084x).add(e());
            AbstractC0071j abstractC0071j = this.f2221a;
            if (abstractC0071j.c()) {
                return;
            } else {
                u2 = abstractC0071j.u();
            }
        } while (u2 == this.f2222b);
        this.f2224d = u2;
    }

    public final void g(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0084x).add(Double.valueOf(abstractC0071j.h()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0071j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0071j.b() + v2;
        do {
            ((U) interfaceC0084x).add(Double.valueOf(abstractC0071j.h()));
        } while (abstractC0071j.b() < b2);
    }

    public final void h(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.i()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.i()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final Object i(r0 r0Var, Class cls, C0076o c0076o) {
        int ordinal = r0Var.ordinal();
        AbstractC0071j abstractC0071j = this.f2221a;
        switch (ordinal) {
            case 0:
                w(1);
                return Double.valueOf(abstractC0071j.h());
            case 1:
                w(5);
                return Float.valueOf(abstractC0071j.l());
            case 2:
                w(0);
                return Long.valueOf(abstractC0071j.n());
            case 3:
                w(0);
                return Long.valueOf(abstractC0071j.w());
            case 4:
                w(0);
                return Integer.valueOf(abstractC0071j.m());
            case 5:
                w(1);
                return Long.valueOf(abstractC0071j.k());
            case 6:
                w(5);
                return Integer.valueOf(abstractC0071j.j());
            case 7:
                w(0);
                return Boolean.valueOf(abstractC0071j.f());
            case 8:
                w(2);
                return abstractC0071j.t();
            case 9:
            default:
                throw new IllegalArgumentException("unsupported field type.");
            case 10:
                w(2);
                W a2 = T.f2150c.a(cls);
                AbstractC0083w g2 = a2.g();
                c(g2, a2, c0076o);
                a2.h(g2);
                return g2;
            case 11:
                return e();
            case 12:
                w(0);
                return Integer.valueOf(abstractC0071j.v());
            case 13:
                w(0);
                return Integer.valueOf(abstractC0071j.i());
            case 14:
                w(5);
                return Integer.valueOf(abstractC0071j.o());
            case 15:
                w(1);
                return Long.valueOf(abstractC0071j.p());
            case 16:
                w(0);
                return Integer.valueOf(abstractC0071j.q());
            case 17:
                w(0);
                return Long.valueOf(abstractC0071j.r());
        }
    }

    public final void j(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 2) {
            int v2 = abstractC0071j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0071j.b() + v2;
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.j()));
            } while (abstractC0071j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.j()));
            if (abstractC0071j.c()) {
                return;
            } else {
                u2 = abstractC0071j.u();
            }
        } while (u2 == this.f2222b);
        this.f2224d = u2;
    }

    public final void k(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.k()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0071j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0071j.b() + v2;
        do {
            ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.k()));
        } while (abstractC0071j.b() < b2);
    }

    public final void l(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 2) {
            int v2 = abstractC0071j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0071j.b() + v2;
            do {
                ((U) interfaceC0084x).add(Float.valueOf(abstractC0071j.l()));
            } while (abstractC0071j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0084x).add(Float.valueOf(abstractC0071j.l()));
            if (abstractC0071j.c()) {
                return;
            } else {
                u2 = abstractC0071j.u();
            }
        } while (u2 == this.f2222b);
        this.f2224d = u2;
    }

    public final void m(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.m()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.m()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void n(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.n()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.n()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void o(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 2) {
            int v2 = abstractC0071j.v();
            if ((v2 & 3) != 0) {
                throw new A("Failed to parse the message.");
            }
            int b2 = abstractC0071j.b() + v2;
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.o()));
            } while (abstractC0071j.b() < b2);
            return;
        }
        if (i2 != 5) {
            throw A.b();
        }
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.o()));
            if (abstractC0071j.c()) {
                return;
            } else {
                u2 = abstractC0071j.u();
            }
        } while (u2 == this.f2222b);
        this.f2224d = u2;
    }

    public final void p(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 1) {
            do {
                ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.p()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int v2 = abstractC0071j.v();
        if ((v2 & 7) != 0) {
            throw new A("Failed to parse the message.");
        }
        int b2 = abstractC0071j.b() + v2;
        do {
            ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.p()));
        } while (abstractC0071j.b() < b2);
    }

    public final void q(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.q()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.q()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void r(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.r()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.r()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void s(InterfaceC0084x interfaceC0084x, boolean z2) {
        String s2;
        int u2;
        if ((this.f2222b & 7) != 2) {
            throw A.b();
        }
        do {
            AbstractC0071j abstractC0071j = this.f2221a;
            if (z2) {
                w(2);
                s2 = abstractC0071j.t();
            } else {
                w(2);
                s2 = abstractC0071j.s();
            }
            ((U) interfaceC0084x).add(s2);
            if (abstractC0071j.c()) {
                return;
            } else {
                u2 = abstractC0071j.u();
            }
        } while (u2 == this.f2222b);
        this.f2224d = u2;
    }

    public final void t(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.v()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Integer.valueOf(abstractC0071j.v()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void u(InterfaceC0084x interfaceC0084x) {
        int u2;
        int i2 = this.f2222b & 7;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (i2 == 0) {
            do {
                ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.w()));
                if (abstractC0071j.c()) {
                    return;
                } else {
                    u2 = abstractC0071j.u();
                }
            } while (u2 == this.f2222b);
            this.f2224d = u2;
            return;
        }
        if (i2 != 2) {
            throw A.b();
        }
        int b2 = abstractC0071j.b() + abstractC0071j.v();
        do {
            ((U) interfaceC0084x).add(Long.valueOf(abstractC0071j.w()));
        } while (abstractC0071j.b() < b2);
        v(b2);
    }

    public final void v(int i2) {
        if (this.f2221a.b() != i2) {
            throw A.e();
        }
    }

    public final void w(int i2) {
        if ((this.f2222b & 7) != i2) {
            throw A.b();
        }
    }

    public final boolean x() {
        int i2;
        AbstractC0071j abstractC0071j = this.f2221a;
        if (abstractC0071j.c() || (i2 = this.f2222b) == this.f2223c) {
            return false;
        }
        return abstractC0071j.x(i2);
    }
}
