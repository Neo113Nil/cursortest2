package androidx.datastore.preferences.protobuf;

import a.AbstractC0059a;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.KotlinVersion;

/* renamed from: androidx.datastore.preferences.protobuf.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0074m extends AbstractC0059a {

    /* renamed from: j, reason: collision with root package name */
    public static final Logger f2226j = Logger.getLogger(C0074m.class.getName());

    /* renamed from: k, reason: collision with root package name */
    public static final boolean f2227k = j0.f2218d;

    /* renamed from: e, reason: collision with root package name */
    public F f2228e;

    /* renamed from: f, reason: collision with root package name */
    public final byte[] f2229f;

    /* renamed from: g, reason: collision with root package name */
    public final int f2230g;

    /* renamed from: h, reason: collision with root package name */
    public int f2231h;

    /* renamed from: i, reason: collision with root package name */
    public final F.m0 f2232i;

    public C0074m(F.m0 m0Var, int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("bufferSize must be >= 0");
        }
        int max = Math.max(i2, 20);
        this.f2229f = new byte[max];
        this.f2230g = max;
        this.f2232i = m0Var;
    }

    public static int e0(int i2) {
        return u0(i2) + 1;
    }

    public static int f0(int i2, C0068g c0068g) {
        int u02 = u0(i2);
        int size = c0068g.size();
        return w0(size) + size + u02;
    }

    public static int g0(int i2) {
        return u0(i2) + 8;
    }

    public static int h0(int i2, int i3) {
        return y0(i3) + u0(i2);
    }

    public static int i0(int i2) {
        return u0(i2) + 4;
    }

    public static int j0(int i2) {
        return u0(i2) + 8;
    }

    public static int k0(int i2) {
        return u0(i2) + 4;
    }

    public static int l0(int i2, AbstractC0062a abstractC0062a, W w2) {
        return abstractC0062a.a(w2) + (u0(i2) * 2);
    }

    public static int m0(int i2, int i3) {
        return y0(i3) + u0(i2);
    }

    public static int n0(int i2, long j2) {
        return y0(j2) + u0(i2);
    }

    public static int o0(int i2) {
        return u0(i2) + 4;
    }

    public static int p0(int i2) {
        return u0(i2) + 8;
    }

    public static int q0(int i2, int i3) {
        return w0((i3 >> 31) ^ (i3 << 1)) + u0(i2);
    }

    public static int r0(int i2, long j2) {
        return y0((j2 >> 63) ^ (j2 << 1)) + u0(i2);
    }

    public static int s0(int i2, String str) {
        return t0(str) + u0(i2);
    }

    public static int t0(String str) {
        int length;
        try {
            length = m0.a(str);
        } catch (l0 unused) {
            length = str.getBytes(AbstractC0085y.f2267a).length;
        }
        return w0(length) + length;
    }

    public static int u0(int i2) {
        return w0(i2 << 3);
    }

    public static int v0(int i2, int i3) {
        return w0(i3) + u0(i2);
    }

    public static int w0(int i2) {
        return (352 - (Integer.numberOfLeadingZeros(i2) * 9)) >>> 6;
    }

    public static int x0(int i2, long j2) {
        return y0(j2) + u0(i2);
    }

    public static int y0(long j2) {
        return (640 - (Long.numberOfLeadingZeros(j2) * 9)) >>> 6;
    }

    public final void A0(int i2) {
        if (this.f2230g - this.f2231h < i2) {
            z0();
        }
    }

    public final void B0(byte b2) {
        if (this.f2231h == this.f2230g) {
            z0();
        }
        int i2 = this.f2231h;
        this.f2231h = i2 + 1;
        this.f2229f[i2] = b2;
    }

    public final void C0(byte[] bArr, int i2, int i3) {
        int i4 = this.f2231h;
        int i5 = this.f2230g;
        int i6 = i5 - i4;
        byte[] bArr2 = this.f2229f;
        if (i6 >= i3) {
            System.arraycopy(bArr, i2, bArr2, i4, i3);
            this.f2231h += i3;
            return;
        }
        System.arraycopy(bArr, i2, bArr2, i4, i6);
        int i7 = i2 + i6;
        int i8 = i3 - i6;
        this.f2231h = i5;
        z0();
        if (i8 > i5) {
            this.f2232i.write(bArr, i7, i8);
        } else {
            System.arraycopy(bArr, i7, bArr2, 0, i8);
            this.f2231h = i8;
        }
    }

    public final void D0(int i2, boolean z2) {
        A0(11);
        b0(i2, 0);
        byte b2 = z2 ? (byte) 1 : (byte) 0;
        int i3 = this.f2231h;
        this.f2231h = i3 + 1;
        this.f2229f[i3] = b2;
    }

    public final void E0(int i2, C0068g c0068g) {
        O0(i2, 2);
        F0(c0068g);
    }

    public final void F0(C0068g c0068g) {
        Q0(c0068g.size());
        R(c0068g.f2195b, c0068g.e(), c0068g.size());
    }

    public final void G0(int i2, int i3) {
        A0(14);
        b0(i2, 5);
        Z(i3);
    }

    public final void H0(int i2) {
        A0(4);
        Z(i2);
    }

    public final void I0(int i2, long j2) {
        A0(18);
        b0(i2, 1);
        a0(j2);
    }

    public final void J0(long j2) {
        A0(8);
        a0(j2);
    }

    public final void K0(int i2, int i3) {
        A0(20);
        b0(i2, 0);
        if (i3 >= 0) {
            c0(i3);
        } else {
            d0(i3);
        }
    }

    public final void L0(int i2) {
        if (i2 >= 0) {
            Q0(i2);
        } else {
            S0(i2);
        }
    }

    public final void M0(int i2, String str) {
        O0(i2, 2);
        N0(str);
    }

    public final void N0(String str) {
        try {
            int length = str.length() * 3;
            int w02 = w0(length);
            int i2 = w02 + length;
            int i3 = this.f2230g;
            if (i2 > i3) {
                byte[] bArr = new byte[length];
                int r2 = m0.f2233a.r(str, bArr, 0, length);
                Q0(r2);
                C0(bArr, 0, r2);
                return;
            }
            if (i2 > i3 - this.f2231h) {
                z0();
            }
            int w03 = w0(str.length());
            int i4 = this.f2231h;
            byte[] bArr2 = this.f2229f;
            try {
                try {
                    if (w03 == w02) {
                        int i5 = i4 + w03;
                        this.f2231h = i5;
                        int r3 = m0.f2233a.r(str, bArr2, i5, i3 - i5);
                        this.f2231h = i4;
                        c0((r3 - i4) - w03);
                        this.f2231h = r3;
                    } else {
                        int a2 = m0.a(str);
                        c0(a2);
                        this.f2231h = m0.f2233a.r(str, bArr2, this.f2231h, a2);
                    }
                } catch (ArrayIndexOutOfBoundsException e2) {
                    throw new C0073l(e2);
                }
            } catch (l0 e3) {
                this.f2231h = i4;
                throw e3;
            }
        } catch (l0 e4) {
            f2226j.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e4);
            byte[] bytes = str.getBytes(AbstractC0085y.f2267a);
            try {
                Q0(bytes.length);
                R(bytes, 0, bytes.length);
            } catch (IndexOutOfBoundsException e5) {
                throw new C0073l(e5);
            }
        }
    }

    public final void O0(int i2, int i3) {
        Q0((i2 << 3) | i3);
    }

    public final void P0(int i2, int i3) {
        A0(20);
        b0(i2, 0);
        c0(i3);
    }

    public final void Q0(int i2) {
        A0(5);
        c0(i2);
    }

    @Override // a.AbstractC0059a
    public final void R(byte[] bArr, int i2, int i3) {
        C0(bArr, i2, i3);
    }

    public final void R0(int i2, long j2) {
        A0(20);
        b0(i2, 0);
        d0(j2);
    }

    public final void S0(long j2) {
        A0(10);
        d0(j2);
    }

    public final void Z(int i2) {
        int i3 = this.f2231h;
        int i4 = i3 + 1;
        this.f2231h = i4;
        byte b2 = (byte) (i2 & KotlinVersion.MAX_COMPONENT_VALUE);
        byte[] bArr = this.f2229f;
        bArr[i3] = b2;
        int i5 = i3 + 2;
        this.f2231h = i5;
        bArr[i4] = (byte) ((i2 >> 8) & KotlinVersion.MAX_COMPONENT_VALUE);
        int i6 = i3 + 3;
        this.f2231h = i6;
        bArr[i5] = (byte) ((i2 >> 16) & KotlinVersion.MAX_COMPONENT_VALUE);
        this.f2231h = i3 + 4;
        bArr[i6] = (byte) ((i2 >> 24) & KotlinVersion.MAX_COMPONENT_VALUE);
    }

    public final void a0(long j2) {
        int i2 = this.f2231h;
        int i3 = i2 + 1;
        this.f2231h = i3;
        byte[] bArr = this.f2229f;
        bArr[i2] = (byte) (j2 & 255);
        int i4 = i2 + 2;
        this.f2231h = i4;
        bArr[i3] = (byte) ((j2 >> 8) & 255);
        int i5 = i2 + 3;
        this.f2231h = i5;
        bArr[i4] = (byte) ((j2 >> 16) & 255);
        int i6 = i2 + 4;
        this.f2231h = i6;
        bArr[i5] = (byte) (255 & (j2 >> 24));
        int i7 = i2 + 5;
        this.f2231h = i7;
        bArr[i6] = (byte) (((int) (j2 >> 32)) & KotlinVersion.MAX_COMPONENT_VALUE);
        int i8 = i2 + 6;
        this.f2231h = i8;
        bArr[i7] = (byte) (((int) (j2 >> 40)) & KotlinVersion.MAX_COMPONENT_VALUE);
        int i9 = i2 + 7;
        this.f2231h = i9;
        bArr[i8] = (byte) (((int) (j2 >> 48)) & KotlinVersion.MAX_COMPONENT_VALUE);
        this.f2231h = i2 + 8;
        bArr[i9] = (byte) (((int) (j2 >> 56)) & KotlinVersion.MAX_COMPONENT_VALUE);
    }

    public final void b0(int i2, int i3) {
        c0((i2 << 3) | i3);
    }

    public final void c0(int i2) {
        boolean z2 = f2227k;
        byte[] bArr = this.f2229f;
        if (z2) {
            while ((i2 & (-128)) != 0) {
                int i3 = this.f2231h;
                this.f2231h = i3 + 1;
                j0.j(bArr, i3, (byte) ((i2 | 128) & KotlinVersion.MAX_COMPONENT_VALUE));
                i2 >>>= 7;
            }
            int i4 = this.f2231h;
            this.f2231h = i4 + 1;
            j0.j(bArr, i4, (byte) i2);
            return;
        }
        while ((i2 & (-128)) != 0) {
            int i5 = this.f2231h;
            this.f2231h = i5 + 1;
            bArr[i5] = (byte) ((i2 | 128) & KotlinVersion.MAX_COMPONENT_VALUE);
            i2 >>>= 7;
        }
        int i6 = this.f2231h;
        this.f2231h = i6 + 1;
        bArr[i6] = (byte) i2;
    }

    public final void d0(long j2) {
        boolean z2 = f2227k;
        byte[] bArr = this.f2229f;
        if (z2) {
            while ((j2 & (-128)) != 0) {
                int i2 = this.f2231h;
                this.f2231h = i2 + 1;
                j0.j(bArr, i2, (byte) ((((int) j2) | 128) & KotlinVersion.MAX_COMPONENT_VALUE));
                j2 >>>= 7;
            }
            int i3 = this.f2231h;
            this.f2231h = i3 + 1;
            j0.j(bArr, i3, (byte) j2);
            return;
        }
        while ((j2 & (-128)) != 0) {
            int i4 = this.f2231h;
            this.f2231h = i4 + 1;
            bArr[i4] = (byte) ((((int) j2) | 128) & KotlinVersion.MAX_COMPONENT_VALUE);
            j2 >>>= 7;
        }
        int i5 = this.f2231h;
        this.f2231h = i5 + 1;
        bArr[i5] = (byte) j2;
    }

    public final void z0() {
        this.f2232i.write(this.f2229f, 0, this.f2231h);
        this.f2231h = 0;
    }
}
