package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class T {

    /* renamed from: c, reason: collision with root package name */
    public static final T f2150c = new T();

    /* renamed from: b, reason: collision with root package name */
    public final ConcurrentHashMap f2152b = new ConcurrentHashMap();

    /* renamed from: a, reason: collision with root package name */
    public final F f2151a = new F();

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v6, types: [androidx.datastore.preferences.protobuf.O] */
    /* JADX WARN: Type inference failed for: r4v8, types: [androidx.datastore.preferences.protobuf.O] */
    public final W a(Class cls) {
        C0077p c0077p;
        N x2;
        N n2;
        Class cls2;
        AbstractC0085y.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f2152b;
        W w2 = (W) concurrentHashMap.get(cls);
        if (w2 != null) {
            return w2;
        }
        F f2 = this.f2151a;
        f2.getClass();
        Class cls3 = X.f2160a;
        if (!AbstractC0083w.class.isAssignableFrom(cls) && (cls2 = X.f2160a) != null && !cls2.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
        }
        V b2 = ((E) f2.f2120a).b(cls);
        if ((b2.f2159d & 2) == 2) {
            boolean isAssignableFrom = AbstractC0083w.class.isAssignableFrom(cls);
            AbstractC0083w abstractC0083w = b2.f2156a;
            if (isAssignableFrom) {
                n2 = new O(X.f2162c, AbstractC0078q.f2237a, abstractC0083w);
            } else {
                e0 e0Var = X.f2161b;
                C0077p c0077p2 = AbstractC0078q.f2238b;
                if (c0077p2 == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
                n2 = new O(e0Var, c0077p2, abstractC0083w);
            }
            x2 = n2;
        } else if (AbstractC0083w.class.isAssignableFrom(cls)) {
            P p2 = Q.f2149b;
            C c2 = D.f2117b;
            e0 e0Var2 = X.f2162c;
            C0077p c0077p3 = H.j.b(b2.d()) != 1 ? AbstractC0078q.f2237a : null;
            J j2 = K.f2128b;
            int[] iArr = N.f2130n;
            if (!(b2 instanceof V)) {
                b2.getClass();
                throw new ClassCastException();
            }
            x2 = N.x(b2, p2, c2, e0Var2, c0077p3, j2);
        } else {
            P p3 = Q.f2148a;
            C c3 = D.f2116a;
            e0 e0Var3 = X.f2161b;
            if (H.j.b(b2.d()) != 1) {
                c0077p = AbstractC0078q.f2238b;
                if (c0077p == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
            } else {
                c0077p = null;
            }
            J j3 = K.f2127a;
            int[] iArr2 = N.f2130n;
            if (!(b2 instanceof V)) {
                b2.getClass();
                throw new ClassCastException();
            }
            x2 = N.x(b2, p3, c3, e0Var3, c0077p, j3);
        }
        W w3 = (W) concurrentHashMap.putIfAbsent(cls, x2);
        return w3 != null ? w3 : x2;
    }
}
