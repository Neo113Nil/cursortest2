package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public enum n0 extends r0 {
}
