package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class C {
    public static void a(long j2, Object obj) {
        AbstractC0063b abstractC0063b = (AbstractC0063b) ((InterfaceC0084x) j0.f2216b.h(j2, obj));
        if (abstractC0063b.f2176a) {
            abstractC0063b.f2176a = false;
        }
    }

    public static InterfaceC0084x b(long j2, Object obj) {
        InterfaceC0084x interfaceC0084x = (InterfaceC0084x) j0.f2216b.h(j2, obj);
        if (((AbstractC0063b) interfaceC0084x).f2176a) {
            return interfaceC0084x;
        }
        U u2 = (U) interfaceC0084x;
        int i2 = u2.f2155c;
        U c2 = u2.c(i2 == 0 ? 10 : i2 * 2);
        j0.o(obj, j2, c2);
        return c2;
    }
}
