package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0078q {

    /* renamed from: a, reason: collision with root package name */
    public static final C0077p f2237a = new C0077p();

    /* renamed from: b, reason: collision with root package name */
    public static final C0077p f2238b;

    static {
        T t = T.f2150c;
        C0077p c0077p = null;
        try {
            c0077p = (C0077p) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f2238b = c0077p;
    }
}
