package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0067f extends C0068g {

    /* renamed from: e, reason: collision with root package name */
    public final int f2190e;

    /* renamed from: f, reason: collision with root package name */
    public final int f2191f;

    public C0067f(byte[] bArr, int i2, int i3) {
        super(bArr);
        C0068g.b(i2, i2 + i3, bArr.length);
        this.f2190e = i2;
        this.f2191f = i3;
    }

    @Override // androidx.datastore.preferences.protobuf.C0068g
    public final byte a(int i2) {
        int i3 = this.f2191f;
        if (((i3 - (i2 + 1)) | i2) >= 0) {
            return this.f2195b[this.f2190e + i2];
        }
        if (i2 < 0) {
            throw new ArrayIndexOutOfBoundsException(A1.a.g(i2, "Index < 0: "));
        }
        throw new ArrayIndexOutOfBoundsException(A1.a.i("Index > length: ", i2, i3, ", "));
    }

    @Override // androidx.datastore.preferences.protobuf.C0068g
    public final void d(int i2, byte[] bArr) {
        System.arraycopy(this.f2195b, this.f2190e, bArr, 0, i2);
    }

    @Override // androidx.datastore.preferences.protobuf.C0068g
    public final int e() {
        return this.f2190e;
    }

    @Override // androidx.datastore.preferences.protobuf.C0068g
    public final byte f(int i2) {
        return this.f2195b[this.f2190e + i2];
    }

    @Override // androidx.datastore.preferences.protobuf.C0068g
    public final int size() {
        return this.f2191f;
    }
}
