package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class r {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f2239c = 0;

    /* renamed from: a, reason: collision with root package name */
    public final Y f2240a = Y.f();

    /* renamed from: b, reason: collision with root package name */
    public boolean f2241b;

    static {
        new r(0);
    }

    public r() {
    }

    public static void b(C0074m c0074m, r0 r0Var, int i2, Object obj) {
        if (r0Var == r0.f2243d) {
            c0074m.O0(i2, 3);
            ((AbstractC0062a) obj).b(c0074m);
            c0074m.O0(i2, 4);
            return;
        }
        c0074m.O0(i2, r0Var.f2247b);
        switch (r0Var.ordinal()) {
            case 0:
                c0074m.J0(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                c0074m.H0(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                c0074m.S0(((Long) obj).longValue());
                break;
            case 3:
                c0074m.S0(((Long) obj).longValue());
                break;
            case 4:
                c0074m.L0(((Integer) obj).intValue());
                break;
            case 5:
                c0074m.J0(((Long) obj).longValue());
                break;
            case 6:
                c0074m.H0(((Integer) obj).intValue());
                break;
            case 7:
                c0074m.B0(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case 8:
                if (!(obj instanceof C0068g)) {
                    c0074m.N0((String) obj);
                    break;
                } else {
                    c0074m.F0((C0068g) obj);
                    break;
                }
            case 9:
                ((AbstractC0062a) obj).b(c0074m);
                break;
            case 10:
                AbstractC0062a abstractC0062a = (AbstractC0062a) obj;
                c0074m.getClass();
                c0074m.Q0(((AbstractC0083w) abstractC0062a).a(null));
                abstractC0062a.b(c0074m);
                break;
            case 11:
                if (!(obj instanceof C0068g)) {
                    byte[] bArr = (byte[]) obj;
                    int length = bArr.length;
                    c0074m.Q0(length);
                    c0074m.C0(bArr, 0, length);
                    break;
                } else {
                    c0074m.F0((C0068g) obj);
                    break;
                }
            case 12:
                c0074m.Q0(((Integer) obj).intValue());
                break;
            case 13:
                c0074m.L0(((Integer) obj).intValue());
                break;
            case 14:
                c0074m.H0(((Integer) obj).intValue());
                break;
            case 15:
                c0074m.J0(((Long) obj).longValue());
                break;
            case 16:
                int intValue = ((Integer) obj).intValue();
                c0074m.Q0((intValue >> 31) ^ (intValue << 1));
                break;
            case 17:
                long longValue = ((Long) obj).longValue();
                c0074m.S0((longValue >> 63) ^ (longValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f2241b) {
            return;
        }
        Y y2 = this.f2240a;
        int size = y2.f2164a.size();
        for (int i2 = 0; i2 < size; i2++) {
            Map.Entry c2 = y2.c(i2);
            if (c2.getValue() instanceof AbstractC0083w) {
                AbstractC0083w abstractC0083w = (AbstractC0083w) c2.getValue();
                abstractC0083w.getClass();
                T t = T.f2150c;
                t.getClass();
                t.a(abstractC0083w.getClass()).h(abstractC0083w);
                abstractC0083w.j();
            }
        }
        if (!y2.f2166c) {
            if (y2.f2164a.size() > 0) {
                y2.c(0).getKey().getClass();
                throw new ClassCastException();
            }
            Iterator it = y2.d().iterator();
            if (it.hasNext()) {
                ((Map.Entry) it.next()).getKey().getClass();
                throw new ClassCastException();
            }
        }
        if (!y2.f2166c) {
            y2.f2165b = y2.f2165b.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(y2.f2165b);
            y2.f2168e = y2.f2168e.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(y2.f2168e);
            y2.f2166c = true;
        }
        this.f2241b = true;
    }

    public final Object clone() {
        r rVar = new r();
        Y y2 = this.f2240a;
        if (y2.f2164a.size() > 0) {
            Map.Entry c2 = y2.c(0);
            if (c2.getKey() != null) {
                throw new ClassCastException();
            }
            c2.getValue();
            throw null;
        }
        Iterator it = y2.d().iterator();
        if (!it.hasNext()) {
            return rVar;
        }
        Map.Entry entry = (Map.Entry) it.next();
        if (entry.getKey() != null) {
            throw new ClassCastException();
        }
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof r) {
            return this.f2240a.equals(((r) obj).f2240a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f2240a.hashCode();
    }

    public r(int i2) {
        a();
        a();
    }
}
