package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class d0 {

    /* renamed from: f, reason: collision with root package name */
    public static final d0 f2183f = new d0(0, new int[0], new Object[0], false);

    /* renamed from: a, reason: collision with root package name */
    public int f2184a;

    /* renamed from: b, reason: collision with root package name */
    public int[] f2185b;

    /* renamed from: c, reason: collision with root package name */
    public Object[] f2186c;

    /* renamed from: d, reason: collision with root package name */
    public int f2187d = -1;

    /* renamed from: e, reason: collision with root package name */
    public boolean f2188e;

    public d0(int i2, int[] iArr, Object[] objArr, boolean z2) {
        this.f2184a = i2;
        this.f2185b = iArr;
        this.f2186c = objArr;
        this.f2188e = z2;
    }

    public final void a(int i2) {
        int[] iArr = this.f2185b;
        if (i2 > iArr.length) {
            int i3 = this.f2184a;
            int i4 = (i3 / 2) + i3;
            if (i4 >= i2) {
                i2 = i4;
            }
            if (i2 < 8) {
                i2 = 8;
            }
            this.f2185b = Arrays.copyOf(iArr, i2);
            this.f2186c = Arrays.copyOf(this.f2186c, i2);
        }
    }

    public final int b() {
        int x02;
        int i2 = this.f2187d;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int i4 = 0; i4 < this.f2184a; i4++) {
            int i5 = this.f2185b[i4];
            int i6 = i5 >>> 3;
            int i7 = i5 & 7;
            if (i7 == 0) {
                x02 = C0074m.x0(i6, ((Long) this.f2186c[i4]).longValue());
            } else if (i7 == 1) {
                ((Long) this.f2186c[i4]).getClass();
                x02 = C0074m.j0(i6);
            } else if (i7 == 2) {
                x02 = C0074m.f0(i6, (C0068g) this.f2186c[i4]);
            } else if (i7 == 3) {
                i3 = ((d0) this.f2186c[i4]).b() + (C0074m.u0(i6) * 2) + i3;
            } else {
                if (i7 != 5) {
                    throw new IllegalStateException(A.b());
                }
                ((Integer) this.f2186c[i4]).getClass();
                x02 = C0074m.i0(i6);
            }
            i3 = x02 + i3;
        }
        this.f2187d = i3;
        return i3;
    }

    public final void c(int i2, Object obj) {
        if (!this.f2188e) {
            throw new UnsupportedOperationException();
        }
        a(this.f2184a + 1);
        int[] iArr = this.f2185b;
        int i3 = this.f2184a;
        iArr[i3] = i2;
        this.f2186c[i3] = obj;
        this.f2184a = i3 + 1;
    }

    public final void d(F f2) {
        if (this.f2184a == 0) {
            return;
        }
        f2.getClass();
        for (int i2 = 0; i2 < this.f2184a; i2++) {
            int i3 = this.f2185b[i2];
            Object obj = this.f2186c[i2];
            int i4 = i3 >>> 3;
            int i5 = i3 & 7;
            if (i5 == 0) {
                f2.j(i4, ((Long) obj).longValue());
            } else if (i5 == 1) {
                f2.f(i4, ((Long) obj).longValue());
            } else if (i5 == 2) {
                f2.b(i4, (C0068g) obj);
            } else if (i5 == 3) {
                C0074m c0074m = (C0074m) f2.f2120a;
                c0074m.O0(i4, 3);
                ((d0) obj).d(f2);
                c0074m.O0(i4, 4);
            } else {
                if (i5 != 5) {
                    throw new RuntimeException(A.b());
                }
                f2.e(i4, ((Integer) obj).intValue());
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        int i2 = this.f2184a;
        if (i2 == d0Var.f2184a) {
            int[] iArr = this.f2185b;
            int[] iArr2 = d0Var.f2185b;
            int i3 = 0;
            while (true) {
                if (i3 >= i2) {
                    Object[] objArr = this.f2186c;
                    Object[] objArr2 = d0Var.f2186c;
                    int i4 = this.f2184a;
                    for (int i5 = 0; i5 < i4; i5++) {
                        if (objArr[i5].equals(objArr2[i5])) {
                        }
                    }
                    return true;
                }
                if (iArr[i3] != iArr2[i3]) {
                    break;
                }
                i3++;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i2 = this.f2184a;
        int i3 = (527 + i2) * 31;
        int[] iArr = this.f2185b;
        int i4 = 17;
        int i5 = 17;
        for (int i6 = 0; i6 < i2; i6++) {
            i5 = (i5 * 31) + iArr[i6];
        }
        int i7 = (i3 + i5) * 31;
        Object[] objArr = this.f2186c;
        int i8 = this.f2184a;
        for (int i9 = 0; i9 < i8; i9++) {
            i4 = (i4 * 31) + objArr[i9].hashCode();
        }
        return i7 + i4;
    }
}
