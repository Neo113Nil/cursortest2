package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0081u implements Cloneable {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0083w f2265a;

    /* renamed from: b, reason: collision with root package name */
    public AbstractC0083w f2266b;

    public AbstractC0081u(AbstractC0083w abstractC0083w) {
        this.f2265a = abstractC0083w;
        if (abstractC0083w.i()) {
            throw new IllegalArgumentException("Default instance must be immutable.");
        }
        this.f2266b = abstractC0083w.k();
    }

    public final AbstractC0083w a() {
        AbstractC0083w b2 = b();
        b2.getClass();
        if (AbstractC0083w.h(b2, true)) {
            return b2;
        }
        throw new c0();
    }

    public final AbstractC0083w b() {
        if (!this.f2266b.i()) {
            return this.f2266b;
        }
        AbstractC0083w abstractC0083w = this.f2266b;
        abstractC0083w.getClass();
        T t = T.f2150c;
        t.getClass();
        t.a(abstractC0083w.getClass()).h(abstractC0083w);
        abstractC0083w.j();
        return this.f2266b;
    }

    public final void c() {
        if (this.f2266b.i()) {
            return;
        }
        AbstractC0083w k2 = this.f2265a.k();
        AbstractC0083w abstractC0083w = this.f2266b;
        T t = T.f2150c;
        t.getClass();
        t.a(k2.getClass()).c(k2, abstractC0083w);
        this.f2266b = k2;
    }

    public final Object clone() {
        AbstractC0081u abstractC0081u = (AbstractC0081u) this.f2265a.e(5);
        abstractC0081u.f2266b = b();
        return abstractC0081u;
    }
}
