package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* loaded from: classes.dex */
public final class F {

    /* renamed from: b, reason: collision with root package name */
    public static final C0080t f2119b = new C0080t(1);

    /* renamed from: a, reason: collision with root package name */
    public final Object f2120a;

    public F(C0074m c0074m) {
        AbstractC0085y.a(c0074m, "output");
        this.f2120a = c0074m;
        c0074m.f2228e = this;
    }

    public void a(int i2, boolean z2) {
        ((C0074m) this.f2120a).D0(i2, z2);
    }

    public void b(int i2, C0068g c0068g) {
        ((C0074m) this.f2120a).E0(i2, c0068g);
    }

    public void c(int i2, double d2) {
        C0074m c0074m = (C0074m) this.f2120a;
        c0074m.getClass();
        c0074m.I0(i2, Double.doubleToRawLongBits(d2));
    }

    public void d(int i2, int i3) {
        ((C0074m) this.f2120a).K0(i2, i3);
    }

    public void e(int i2, int i3) {
        ((C0074m) this.f2120a).G0(i2, i3);
    }

    public void f(int i2, long j2) {
        ((C0074m) this.f2120a).I0(i2, j2);
    }

    public void g(int i2, float f2) {
        C0074m c0074m = (C0074m) this.f2120a;
        c0074m.getClass();
        c0074m.G0(i2, Float.floatToRawIntBits(f2));
    }

    public void h(int i2, Object obj, W w2) {
        C0074m c0074m = (C0074m) this.f2120a;
        c0074m.O0(i2, 3);
        w2.d((AbstractC0062a) obj, c0074m.f2228e);
        c0074m.O0(i2, 4);
    }

    public void i(int i2, int i3) {
        ((C0074m) this.f2120a).K0(i2, i3);
    }

    public void j(int i2, long j2) {
        ((C0074m) this.f2120a).R0(i2, j2);
    }

    public void k(int i2, Object obj, W w2) {
        C0074m c0074m = (C0074m) this.f2120a;
        AbstractC0062a abstractC0062a = (AbstractC0062a) obj;
        c0074m.O0(i2, 2);
        c0074m.Q0(abstractC0062a.a(w2));
        w2.d(abstractC0062a, c0074m.f2228e);
    }

    public void l(int i2, int i3) {
        ((C0074m) this.f2120a).G0(i2, i3);
    }

    public void m(int i2, long j2) {
        ((C0074m) this.f2120a).I0(i2, j2);
    }

    public void n(int i2, int i3) {
        ((C0074m) this.f2120a).P0(i2, (i3 >> 31) ^ (i3 << 1));
    }

    public void o(int i2, long j2) {
        ((C0074m) this.f2120a).R0(i2, (j2 >> 63) ^ (j2 << 1));
    }

    public void p(int i2, int i3) {
        ((C0074m) this.f2120a).P0(i2, i3);
    }

    public void q(int i2, long j2) {
        ((C0074m) this.f2120a).R0(i2, j2);
    }

    public F() {
        T t = T.f2150c;
        Object obj = f2119b;
        try {
            obj = (L) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
        }
        L[] lArr = {C0080t.f2263b, obj};
        E e2 = new E();
        e2.f2118a = lArr;
        Charset charset = AbstractC0085y.f2267a;
        this.f2120a = e2;
    }
}
