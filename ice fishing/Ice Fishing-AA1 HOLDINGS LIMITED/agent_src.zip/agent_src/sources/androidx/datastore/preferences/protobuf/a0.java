package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class a0 implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public int f2172a = -1;

    /* renamed from: b, reason: collision with root package name */
    public boolean f2173b;

    /* renamed from: c, reason: collision with root package name */
    public Iterator f2174c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Y f2175d;

    public a0(Y y2) {
        this.f2175d = y2;
    }

    public final Iterator a() {
        if (this.f2174c == null) {
            this.f2174c = this.f2175d.f2165b.entrySet().iterator();
        }
        return this.f2174c;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i2 = this.f2172a + 1;
        Y y2 = this.f2175d;
        if (i2 >= y2.f2164a.size()) {
            return !y2.f2165b.isEmpty() && a().hasNext();
        }
        return true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        this.f2173b = true;
        int i2 = this.f2172a + 1;
        this.f2172a = i2;
        Y y2 = this.f2175d;
        return i2 < y2.f2164a.size() ? (Map.Entry) y2.f2164a.get(this.f2172a) : (Map.Entry) a().next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f2173b) {
            throw new IllegalStateException("remove() was called before next()");
        }
        this.f2173b = false;
        int i2 = Y.f2163f;
        Y y2 = this.f2175d;
        y2.b();
        if (this.f2172a >= y2.f2164a.size()) {
            a().remove();
            return;
        }
        int i3 = this.f2172a;
        this.f2172a = i3 - 1;
        y2.h(i3);
    }
}
