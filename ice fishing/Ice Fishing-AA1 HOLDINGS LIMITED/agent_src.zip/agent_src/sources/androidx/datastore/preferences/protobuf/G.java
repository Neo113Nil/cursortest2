package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: a, reason: collision with root package name */
    public final n0 f2121a;

    /* renamed from: b, reason: collision with root package name */
    public final p0 f2122b;

    /* renamed from: c, reason: collision with root package name */
    public final H.k f2123c;

    public G(n0 n0Var, p0 p0Var, H.k kVar) {
        this.f2121a = n0Var;
        this.f2122b = p0Var;
        this.f2123c = kVar;
    }
}
