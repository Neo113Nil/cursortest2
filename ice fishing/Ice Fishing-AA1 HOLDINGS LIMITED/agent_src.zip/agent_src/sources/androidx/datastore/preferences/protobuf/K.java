package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class K {

    /* renamed from: a, reason: collision with root package name */
    public static final J f2127a;

    /* renamed from: b, reason: collision with root package name */
    public static final J f2128b;

    static {
        T t = T.f2150c;
        J j2 = null;
        try {
            j2 = (J) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f2127a = j2;
        f2128b = new J();
    }
}
