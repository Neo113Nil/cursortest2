package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public interface W {
    boolean a(Object obj);

    void b(Object obj, C0072k c0072k, C0076o c0076o);

    void c(Object obj, Object obj2);

    void d(Object obj, F f2);

    int e(AbstractC0083w abstractC0083w);

    int f(AbstractC0083w abstractC0083w);

    AbstractC0083w g();

    void h(Object obj);

    boolean i(AbstractC0083w abstractC0083w, Object obj);
}
