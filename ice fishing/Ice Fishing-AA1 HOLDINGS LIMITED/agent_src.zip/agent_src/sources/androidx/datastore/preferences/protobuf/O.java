package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class O implements W {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0083w f2145a;

    /* renamed from: b, reason: collision with root package name */
    public final e0 f2146b;

    /* renamed from: c, reason: collision with root package name */
    public final C0077p f2147c;

    public O(e0 e0Var, C0077p c0077p, AbstractC0083w abstractC0083w) {
        this.f2146b = e0Var;
        c0077p.getClass();
        this.f2147c = c0077p;
        this.f2145a = abstractC0083w;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final boolean a(Object obj) {
        this.f2147c.getClass();
        A1.a.p(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void b(Object obj, C0072k c0072k, C0076o c0076o) {
        this.f2146b.getClass();
        e0.a(obj);
        this.f2147c.getClass();
        obj.getClass();
        throw new ClassCastException();
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void c(Object obj, Object obj2) {
        X.A(this.f2146b, obj, obj2);
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void d(Object obj, F f2) {
        this.f2147c.getClass();
        A1.a.p(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final int e(AbstractC0083w abstractC0083w) {
        this.f2146b.getClass();
        return abstractC0083w.unknownFields.hashCode();
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final int f(AbstractC0083w abstractC0083w) {
        this.f2146b.getClass();
        d0 d0Var = abstractC0083w.unknownFields;
        int i2 = d0Var.f2187d;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int i4 = 0; i4 < d0Var.f2184a; i4++) {
            int i5 = d0Var.f2185b[i4] >>> 3;
            i3 += C0074m.f0(3, (C0068g) d0Var.f2186c[i4]) + C0074m.v0(2, i5) + (C0074m.u0(1) * 2);
        }
        d0Var.f2187d = i3;
        return i3;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final AbstractC0083w g() {
        AbstractC0083w abstractC0083w = this.f2145a;
        return abstractC0083w != null ? abstractC0083w.k() : ((AbstractC0081u) abstractC0083w.e(5)).b();
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final void h(Object obj) {
        this.f2146b.getClass();
        e0.b(obj);
        this.f2147c.getClass();
        A1.a.p(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.W
    public final boolean i(AbstractC0083w abstractC0083w, Object obj) {
        this.f2146b.getClass();
        return abstractC0083w.unknownFields.equals(((AbstractC0083w) obj).unknownFields);
    }
}
