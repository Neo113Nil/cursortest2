package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: androidx.datastore.preferences.protobuf.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0065d implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public int f2180a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final int f2181b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0068g f2182c;

    public C0065d(C0068g c0068g) {
        this.f2182c = c0068g;
        this.f2181b = c0068g.size();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f2180a < this.f2181b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i2 = this.f2180a;
        if (i2 >= this.f2181b) {
            throw new NoSuchElementException();
        }
        this.f2180a = i2 + 1;
        return Byte.valueOf(this.f2182c.f(i2));
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
