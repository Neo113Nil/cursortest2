package androidx.datastore.preferences.protobuf;

import java.util.Collections;

/* renamed from: androidx.datastore.preferences.protobuf.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0076o {

    /* renamed from: a, reason: collision with root package name */
    public static volatile C0076o f2235a;

    /* renamed from: b, reason: collision with root package name */
    public static final C0076o f2236b;

    static {
        C0076o c0076o = new C0076o();
        Collections.emptyMap();
        f2236b = c0076o;
    }

    public static C0076o a() {
        T t = T.f2150c;
        C0076o c0076o = f2235a;
        if (c0076o == null) {
            synchronized (C0076o.class) {
                try {
                    c0076o = f2235a;
                    if (c0076o == null) {
                        Class cls = AbstractC0075n.f2234a;
                        C0076o c0076o2 = null;
                        if (cls != null) {
                            try {
                                c0076o2 = (C0076o) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                            } catch (Exception unused) {
                            }
                        }
                        if (c0076o2 == null) {
                            c0076o2 = f2236b;
                        }
                        f2235a = c0076o2;
                        c0076o = c0076o2;
                    }
                } finally {
                }
            }
        }
        return c0076o;
    }
}
