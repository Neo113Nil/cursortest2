package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class V {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0083w f2156a;

    /* renamed from: b, reason: collision with root package name */
    public final String f2157b;

    /* renamed from: c, reason: collision with root package name */
    public final Object[] f2158c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2159d;

    public V(AbstractC0083w abstractC0083w, String str, Object[] objArr) {
        this.f2156a = abstractC0083w;
        this.f2157b = str;
        this.f2158c = objArr;
        char charAt = str.charAt(0);
        if (charAt < 55296) {
            this.f2159d = charAt;
            return;
        }
        int i2 = charAt & 8191;
        int i3 = 1;
        int i4 = 13;
        while (true) {
            int i5 = i3 + 1;
            char charAt2 = str.charAt(i3);
            if (charAt2 < 55296) {
                this.f2159d = i2 | (charAt2 << i4);
                return;
            } else {
                i2 |= (charAt2 & 8191) << i4;
                i4 += 13;
                i3 = i5;
            }
        }
    }

    public final AbstractC0062a a() {
        return this.f2156a;
    }

    public final Object[] b() {
        return this.f2158c;
    }

    public final String c() {
        return this.f2157b;
    }

    public final int d() {
        int i2 = this.f2159d;
        if ((i2 & 1) != 0) {
            return 1;
        }
        return (i2 & 4) == 4 ? 3 : 2;
    }
}
