package androidx.preference;

import a.AbstractC0059a;
import android.content.Context;
import android.util.AttributeSet;
import com.watchfacestudio.pred01.R;

/* loaded from: classes.dex */
public class PreferenceCategory extends PreferenceGroup {
    public PreferenceCategory(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, AbstractC0059a.v(context, R.attr.preferenceCategoryStyle, android.R.attr.preferenceCategoryStyle));
    }
}
