package androidx.preference;

import a.AbstractC0059a;
import android.content.Context;
import android.util.AttributeSet;
import com.watchfacestudio.pred01.R;

/* loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {
    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, AbstractC0059a.v(context, R.attr.preferenceScreenStyle, android.R.attr.preferenceScreenStyle));
    }
}
