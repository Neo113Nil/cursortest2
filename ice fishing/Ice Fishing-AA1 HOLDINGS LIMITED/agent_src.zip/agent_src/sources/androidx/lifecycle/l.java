package androidx.lifecycle;

import android.os.Looper;
import i.C0191a;
import j.C0900a;
import j.C0901b;
import j.C0902c;
import j.C0903d;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class l extends f {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f2279a;

    /* renamed from: b, reason: collision with root package name */
    public C0900a f2280b;

    /* renamed from: c, reason: collision with root package name */
    public e f2281c;

    /* renamed from: d, reason: collision with root package name */
    public final WeakReference f2282d;

    /* renamed from: e, reason: collision with root package name */
    public int f2283e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2284f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2285g;

    /* renamed from: h, reason: collision with root package name */
    public final ArrayList f2286h;

    /* renamed from: i, reason: collision with root package name */
    public final B1.s f2287i;

    public l(j jVar) {
        new AtomicReference();
        this.f2279a = true;
        this.f2280b = new C0900a();
        e eVar = e.f2271b;
        this.f2281c = eVar;
        this.f2286h = new ArrayList();
        this.f2282d = new WeakReference(jVar);
        this.f2287i = new B1.s(eVar);
    }

    public final void a(i iVar) {
        Object obj;
        j jVar;
        ArrayList arrayList = this.f2286h;
        c("addObserver");
        e eVar = this.f2281c;
        e eVar2 = e.f2270a;
        if (eVar != eVar2) {
            eVar2 = e.f2271b;
        }
        k kVar = new k();
        int i2 = m.f2288a;
        kVar.f2278b = iVar;
        kVar.f2277a = eVar2;
        C0900a c0900a = this.f2280b;
        C0902c a2 = c0900a.a(iVar);
        if (a2 != null) {
            obj = a2.f7796b;
        } else {
            HashMap hashMap = c0900a.f7791e;
            C0902c c0902c = new C0902c(iVar, kVar);
            c0900a.f7805d++;
            C0902c c0902c2 = c0900a.f7803b;
            if (c0902c2 == null) {
                c0900a.f7802a = c0902c;
                c0900a.f7803b = c0902c;
            } else {
                c0902c2.f7797c = c0902c;
                c0902c.f7798d = c0902c2;
                c0900a.f7803b = c0902c;
            }
            hashMap.put(iVar, c0902c);
            obj = null;
        }
        if (((k) obj) == null && (jVar = (j) this.f2282d.get()) != null) {
            boolean z2 = this.f2283e != 0 || this.f2284f;
            e b2 = b(iVar);
            this.f2283e++;
            while (kVar.f2277a.compareTo(b2) < 0 && this.f2280b.f7791e.containsKey(iVar)) {
                arrayList.add(kVar.f2277a);
                b bVar = d.Companion;
                e eVar3 = kVar.f2277a;
                bVar.getClass();
                d a3 = b.a(eVar3);
                if (a3 == null) {
                    throw new IllegalStateException("no event up from " + kVar.f2277a);
                }
                kVar.a(jVar, a3);
                arrayList.remove(arrayList.size() - 1);
                b2 = b(iVar);
            }
            if (!z2) {
                e();
            }
            this.f2283e--;
        }
    }

    public final e b(i iVar) {
        HashMap hashMap = this.f2280b.f7791e;
        C0902c c0902c = hashMap.containsKey(iVar) ? ((C0902c) hashMap.get(iVar)).f7798d : null;
        e eVar = c0902c != null ? ((k) c0902c.f7796b).f2277a : null;
        ArrayList arrayList = this.f2286h;
        e eVar2 = arrayList.isEmpty() ? null : (e) arrayList.get(arrayList.size() - 1);
        e state1 = this.f2281c;
        kotlin.jvm.internal.j.e(state1, "state1");
        if (eVar == null || eVar.compareTo(state1) >= 0) {
            eVar = state1;
        }
        return (eVar2 == null || eVar2.compareTo(eVar) >= 0) ? eVar : eVar2;
    }

    public final void c(String str) {
        C0191a c0191a;
        if (this.f2279a) {
            if (C0191a.f3206f != null) {
                c0191a = C0191a.f3206f;
            } else {
                synchronized (C0191a.class) {
                    try {
                        if (C0191a.f3206f == null) {
                            C0191a.f3206f = new C0191a(0);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                c0191a = C0191a.f3206f;
            }
            ((C0191a) c0191a.f3207e).getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(A1.a.k("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void d(d event) {
        kotlin.jvm.internal.j.e(event, "event");
        c("handleLifecycleEvent");
        e a2 = event.a();
        e eVar = this.f2281c;
        if (eVar == a2) {
            return;
        }
        e eVar2 = e.f2271b;
        e eVar3 = e.f2270a;
        if (eVar == eVar2 && a2 == eVar3) {
            throw new IllegalStateException(("no event down from " + this.f2281c + " in component " + this.f2282d.get()).toString());
        }
        this.f2281c = a2;
        if (this.f2284f || this.f2283e != 0) {
            this.f2285g = true;
            return;
        }
        this.f2284f = true;
        e();
        this.f2284f = false;
        if (this.f2281c == eVar3) {
            this.f2280b = new C0900a();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0031, code lost:
    
        r8.f2285g = false;
        r0 = r8.f2281c;
        r1 = r8.f2287i;
        r1.getClass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x003a, code lost:
    
        if (r0 != null) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x003c, code lost:
    
        r0 = C1.l.f198a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x003e, code lost:
    
        r1.b(null, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0041, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void e() {
        j jVar = (j) this.f2282d.get();
        if (jVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            C0900a c0900a = this.f2280b;
            if (c0900a.f7805d != 0) {
                C0902c c0902c = c0900a.f7802a;
                kotlin.jvm.internal.j.b(c0902c);
                e eVar = ((k) c0902c.f7796b).f2277a;
                C0902c c0902c2 = this.f2280b.f7803b;
                kotlin.jvm.internal.j.b(c0902c2);
                e eVar2 = ((k) c0902c2.f7796b).f2277a;
                if (eVar == eVar2 && this.f2281c == eVar2) {
                    break;
                }
                this.f2285g = false;
                e eVar3 = this.f2281c;
                C0902c c0902c3 = this.f2280b.f7802a;
                kotlin.jvm.internal.j.b(c0902c3);
                if (eVar3.compareTo(((k) c0902c3.f7796b).f2277a) < 0) {
                    C0900a c0900a2 = this.f2280b;
                    C0901b c0901b = new C0901b(c0900a2.f7803b, c0900a2.f7802a, 1);
                    c0900a2.f7804c.put(c0901b, Boolean.FALSE);
                    while (c0901b.hasNext() && !this.f2285g) {
                        Map.Entry entry = (Map.Entry) c0901b.next();
                        kotlin.jvm.internal.j.d(entry, "next()");
                        i iVar = (i) entry.getKey();
                        k kVar = (k) entry.getValue();
                        while (kVar.f2277a.compareTo(this.f2281c) > 0 && !this.f2285g && this.f2280b.f7791e.containsKey(iVar)) {
                            b bVar = d.Companion;
                            e state = kVar.f2277a;
                            bVar.getClass();
                            kotlin.jvm.internal.j.e(state, "state");
                            int ordinal = state.ordinal();
                            d dVar = ordinal != 2 ? ordinal != 3 ? ordinal != 4 ? null : d.ON_PAUSE : d.ON_STOP : d.ON_DESTROY;
                            if (dVar == null) {
                                throw new IllegalStateException("no event down from " + kVar.f2277a);
                            }
                            this.f2286h.add(dVar.a());
                            kVar.a(jVar, dVar);
                            this.f2286h.remove(r5.size() - 1);
                        }
                    }
                }
                C0902c c0902c4 = this.f2280b.f7803b;
                if (!this.f2285g && c0902c4 != null && this.f2281c.compareTo(((k) c0902c4.f7796b).f2277a) > 0) {
                    C0900a c0900a3 = this.f2280b;
                    c0900a3.getClass();
                    C0903d c0903d = new C0903d(c0900a3);
                    c0900a3.f7804c.put(c0903d, Boolean.FALSE);
                    while (c0903d.hasNext() && !this.f2285g) {
                        Map.Entry entry2 = (Map.Entry) c0903d.next();
                        i iVar2 = (i) entry2.getKey();
                        k kVar2 = (k) entry2.getValue();
                        while (kVar2.f2277a.compareTo(this.f2281c) < 0 && !this.f2285g && this.f2280b.f7791e.containsKey(iVar2)) {
                            this.f2286h.add(kVar2.f2277a);
                            b bVar2 = d.Companion;
                            e eVar4 = kVar2.f2277a;
                            bVar2.getClass();
                            d a2 = b.a(eVar4);
                            if (a2 == null) {
                                throw new IllegalStateException("no event up from " + kVar2.f2277a);
                            }
                            kVar2.a(jVar, a2);
                            this.f2286h.remove(r4.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
    }
}
