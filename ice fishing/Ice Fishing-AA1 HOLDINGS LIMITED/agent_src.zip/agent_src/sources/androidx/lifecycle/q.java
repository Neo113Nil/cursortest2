package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* loaded from: classes.dex */
public final class q extends a {
    final /* synthetic */ r this$0;

    public q(r rVar) {
        this.this$0 = rVar;
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        kotlin.jvm.internal.j.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i2 = u.f2302b;
            Fragment findFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            kotlin.jvm.internal.j.c(findFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((u) findFragmentByTag).f2303a = this.this$0.f2301h;
        }
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        kotlin.jvm.internal.j.e(activity, "activity");
        r rVar = this.this$0;
        int i2 = rVar.f2295b - 1;
        rVar.f2295b = i2;
        if (i2 == 0) {
            Handler handler = rVar.f2298e;
            kotlin.jvm.internal.j.b(handler);
            handler.postDelayed(rVar.f2300g, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        kotlin.jvm.internal.j.e(activity, "activity");
        o.a(activity, new p(this.this$0));
    }

    @Override // androidx.lifecycle.a, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        kotlin.jvm.internal.j.e(activity, "activity");
        r rVar = this.this$0;
        int i2 = rVar.f2294a - 1;
        rVar.f2294a = i2;
        if (i2 == 0 && rVar.f2296c) {
            rVar.f2299f.d(d.ON_STOP);
            rVar.f2297d = true;
        }
    }
}
