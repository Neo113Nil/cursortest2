package androidx.lifecycle;

import android.app.Activity;

/* loaded from: classes.dex */
public final class p extends a {
    final /* synthetic */ r this$0;

    public p(r rVar) {
        this.this$0 = rVar;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostResumed(Activity activity) {
        kotlin.jvm.internal.j.e(activity, "activity");
        this.this$0.c();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostStarted(Activity activity) {
        kotlin.jvm.internal.j.e(activity, "activity");
        r rVar = this.this$0;
        int i2 = rVar.f2294a + 1;
        rVar.f2294a = i2;
        if (i2 == 1 && rVar.f2297d) {
            rVar.f2299f.d(d.ON_START);
            rVar.f2297d = false;
        }
    }
}
