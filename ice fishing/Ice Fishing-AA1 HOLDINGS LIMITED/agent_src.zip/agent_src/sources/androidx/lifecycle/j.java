package androidx.lifecycle;

/* loaded from: classes.dex */
public interface j {
    l b();
}
