package androidx.lifecycle;

import j.C0905f;

/* loaded from: classes.dex */
public class n {

    /* renamed from: d, reason: collision with root package name */
    public static final Object f2289d = new Object();

    /* renamed from: a, reason: collision with root package name */
    public final Object f2290a;

    /* renamed from: b, reason: collision with root package name */
    public volatile Object f2291b;

    /* renamed from: c, reason: collision with root package name */
    public volatile Object f2292c;

    public n() {
        new C0905f();
        Object obj = f2289d;
        this.f2292c = obj;
        this.f2291b = obj;
    }
}
