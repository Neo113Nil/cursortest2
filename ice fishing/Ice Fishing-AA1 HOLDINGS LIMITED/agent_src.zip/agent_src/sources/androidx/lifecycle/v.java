package androidx.lifecycle;

import F.U;
import android.os.Bundle;
import g1.C0135g;

/* loaded from: classes.dex */
public final class v {

    /* renamed from: a, reason: collision with root package name */
    public final H1.i f2304a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f2305b;

    /* renamed from: c, reason: collision with root package name */
    public Bundle f2306c;

    /* renamed from: d, reason: collision with root package name */
    public final C0135g f2307d;

    public v(H1.i savedStateRegistry, K.e eVar) {
        kotlin.jvm.internal.j.e(savedStateRegistry, "savedStateRegistry");
        this.f2304a = savedStateRegistry;
        this.f2307d = u0.a.C(new U(3, eVar));
    }
}
