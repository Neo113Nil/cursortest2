package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public static final e f2270a;

    /* renamed from: b, reason: collision with root package name */
    public static final e f2271b;

    /* renamed from: c, reason: collision with root package name */
    public static final e f2272c;

    /* renamed from: d, reason: collision with root package name */
    public static final e f2273d;

    /* renamed from: e, reason: collision with root package name */
    public static final e f2274e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ e[] f2275f;

    static {
        e eVar = new e("DESTROYED", 0);
        f2270a = eVar;
        e eVar2 = new e("INITIALIZED", 1);
        f2271b = eVar2;
        e eVar3 = new e("CREATED", 2);
        f2272c = eVar3;
        e eVar4 = new e("STARTED", 3);
        f2273d = eVar4;
        e eVar5 = new e("RESUMED", 4);
        f2274e = eVar5;
        f2275f = new e[]{eVar, eVar2, eVar3, eVar4, eVar5};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) f2275f.clone();
    }
}
