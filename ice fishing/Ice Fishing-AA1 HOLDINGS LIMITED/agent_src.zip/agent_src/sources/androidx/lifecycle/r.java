package androidx.lifecycle;

import android.os.Handler;

/* loaded from: classes.dex */
public final class r implements j {

    /* renamed from: i, reason: collision with root package name */
    public static final r f2293i = new r();

    /* renamed from: a, reason: collision with root package name */
    public int f2294a;

    /* renamed from: b, reason: collision with root package name */
    public int f2295b;

    /* renamed from: e, reason: collision with root package name */
    public Handler f2298e;

    /* renamed from: c, reason: collision with root package name */
    public boolean f2296c = true;

    /* renamed from: d, reason: collision with root package name */
    public boolean f2297d = true;

    /* renamed from: f, reason: collision with root package name */
    public final l f2299f = new l(this);

    /* renamed from: g, reason: collision with root package name */
    public final F0.a f2300g = new F0.a(4, this);

    /* renamed from: h, reason: collision with root package name */
    public final Y0.i f2301h = new Y0.i(11, this);

    @Override // androidx.lifecycle.j
    public final l b() {
        return this.f2299f;
    }

    public final void c() {
        int i2 = this.f2295b + 1;
        this.f2295b = i2;
        if (i2 == 1) {
            if (this.f2296c) {
                this.f2299f.d(d.ON_RESUME);
                this.f2296c = false;
            } else {
                Handler handler = this.f2298e;
                kotlin.jvm.internal.j.b(handler);
                handler.removeCallbacks(this.f2300g);
            }
        }
    }
}
