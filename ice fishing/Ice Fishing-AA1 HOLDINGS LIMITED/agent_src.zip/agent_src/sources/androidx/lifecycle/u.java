package androidx.lifecycle;

import a.AbstractC0059a;
import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* loaded from: classes.dex */
public final class u extends Fragment {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f2302b = 0;

    /* renamed from: a, reason: collision with root package name */
    public Y0.i f2303a;

    public final void a(d dVar) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            kotlin.jvm.internal.j.d(activity, "activity");
            AbstractC0059a.q(activity, dVar);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(d.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(d.ON_DESTROY);
        this.f2303a = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(d.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        Y0.i iVar = this.f2303a;
        if (iVar != null) {
            ((r) iVar.f1762b).c();
        }
        a(d.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        Y0.i iVar = this.f2303a;
        if (iVar != null) {
            r rVar = (r) iVar.f1762b;
            int i2 = rVar.f2294a + 1;
            rVar.f2294a = i2;
            if (i2 == 1 && rVar.f2297d) {
                rVar.f2299f.d(d.ON_START);
                rVar.f2297d = false;
            }
        }
        a(d.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(d.ON_STOP);
    }
}
