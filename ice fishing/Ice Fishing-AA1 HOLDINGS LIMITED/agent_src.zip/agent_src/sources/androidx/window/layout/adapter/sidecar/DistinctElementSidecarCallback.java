package androidx.window.layout.adapter.sidecar;

import android.os.IBinder;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarInterface;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import c0.C0097f;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class DistinctElementSidecarCallback implements SidecarInterface.SidecarCallback {

    /* renamed from: b, reason: collision with root package name */
    public SidecarDeviceState f2402b;

    /* renamed from: d, reason: collision with root package name */
    public final C0097f f2404d;

    /* renamed from: e, reason: collision with root package name */
    public final SidecarInterface.SidecarCallback f2405e;

    /* renamed from: a, reason: collision with root package name */
    public final Object f2401a = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final WeakHashMap f2403c = new WeakHashMap();

    public DistinctElementSidecarCallback(C0097f c0097f, SidecarInterface.SidecarCallback sidecarCallback) {
        this.f2404d = c0097f;
        this.f2405e = sidecarCallback;
    }

    public void onDeviceStateChanged(SidecarDeviceState sidecarDeviceState) {
        if (sidecarDeviceState == null) {
            return;
        }
        synchronized (this.f2401a) {
            try {
                C0097f c0097f = this.f2404d;
                SidecarDeviceState sidecarDeviceState2 = this.f2402b;
                c0097f.getClass();
                if (C0097f.a(sidecarDeviceState2, sidecarDeviceState)) {
                    return;
                }
                this.f2402b = sidecarDeviceState;
                this.f2405e.onDeviceStateChanged(sidecarDeviceState);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void onWindowLayoutChanged(IBinder iBinder, SidecarWindowLayoutInfo sidecarWindowLayoutInfo) {
        synchronized (this.f2401a) {
            try {
                SidecarWindowLayoutInfo sidecarWindowLayoutInfo2 = (SidecarWindowLayoutInfo) this.f2403c.get(iBinder);
                this.f2404d.getClass();
                if (C0097f.d(sidecarWindowLayoutInfo2, sidecarWindowLayoutInfo)) {
                    return;
                }
                this.f2403c.put(iBinder, sidecarWindowLayoutInfo);
                this.f2405e.onWindowLayoutChanged(iBinder, sidecarWindowLayoutInfo);
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
