package I1;

import P.C0052i;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Comparator;

/* loaded from: classes.dex */
public final class b implements Comparator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f851a;

    public /* synthetic */ b(int i2) {
        this.f851a = i2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x001c, code lost:
    
        if (r0 == null) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:?, code lost:
    
        return 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:?, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0028, code lost:
    
        if (r0 != false) goto L16;
     */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int compare(Object obj, Object obj2) {
        switch (this.f851a) {
            case 0:
                return ((String) obj).compareTo((String) obj2);
            default:
                C0052i c0052i = (C0052i) obj;
                C0052i c0052i2 = (C0052i) obj2;
                RecyclerView recyclerView = c0052i.f1476d;
                if ((recyclerView == null) == (c0052i2.f1476d == null)) {
                    boolean z2 = c0052i.f1473a;
                    if (z2 == c0052i2.f1473a) {
                        int i2 = c0052i2.f1474b - c0052i.f1474b;
                        if (i2 != 0) {
                            return i2;
                        }
                        int i3 = c0052i.f1475c - c0052i2.f1475c;
                        if (i3 != 0) {
                            return i3;
                        }
                        return 0;
                    }
                }
                break;
        }
    }
}
