package I1;

import java.util.concurrent.ThreadFactory;

/* loaded from: classes.dex */
public final class c implements ThreadFactory {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f852a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f853b;

    public c(String str, boolean z2) {
        this.f852a = str;
        this.f853b = z2;
    }

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        Thread thread = new Thread(runnable, this.f852a);
        thread.setDaemon(this.f853b);
        return thread;
    }
}
