package H;

import B1.q;
import r1.InterfaceC0993l;
import y1.InterfaceC1066u;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0993l f622a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC1066u f623b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f624c = new Object();

    /* renamed from: d, reason: collision with root package name */
    public volatile q f625d;

    public c(InterfaceC0993l interfaceC0993l, InterfaceC1066u interfaceC1066u) {
        this.f622a = interfaceC0993l;
        this.f623b = interfaceC1066u;
    }
}
