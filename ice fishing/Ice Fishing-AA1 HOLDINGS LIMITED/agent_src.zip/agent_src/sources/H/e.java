package H;

import androidx.datastore.preferences.protobuf.H;
import androidx.datastore.preferences.protobuf.r0;

/* loaded from: classes.dex */
public abstract class e {

    /* renamed from: a, reason: collision with root package name */
    public static final H f626a = new H(r0.f2242c, r0.f2244e, k.x());
}
