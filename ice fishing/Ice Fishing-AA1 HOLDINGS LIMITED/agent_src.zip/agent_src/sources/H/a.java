package H;

import android.content.Context;
import h1.C0186l;
import r1.InterfaceC0993l;

/* loaded from: classes.dex */
public final class a extends kotlin.jvm.internal.k implements InterfaceC0993l {

    /* renamed from: e, reason: collision with root package name */
    public static final a f618e = new a(1);

    @Override // r1.InterfaceC0993l
    public final Object invoke(Object obj) {
        Context it = (Context) obj;
        kotlin.jvm.internal.j.e(it, "it");
        return C0186l.f3203a;
    }
}
