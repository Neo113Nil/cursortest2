package H;

import O0.q;
import a0.InterfaceC0060a;
import android.content.Context;
import g1.C0137i;
import java.io.File;
import r1.InterfaceC0982a;

/* loaded from: classes.dex */
public final class b extends kotlin.jvm.internal.k implements InterfaceC0982a {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f619e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f620f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f621g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(int i2, Object obj, Object obj2) {
        super(0);
        this.f619e = i2;
        this.f620f = obj;
        this.f621g = obj2;
    }

    @Override // r1.InterfaceC0982a
    public final Object invoke() {
        switch (this.f619e) {
            case 0:
                Context context = (Context) this.f620f;
                ((c) this.f621g).getClass();
                String fileName = "FlutterSharedPreferences".concat(".preferences_pb");
                kotlin.jvm.internal.j.e(fileName, "fileName");
                return new File(context.getApplicationContext().getFilesDir(), "datastore/".concat(fileName));
            default:
                ((InterfaceC0060a) ((Z.b) this.f620f).f1804b).a((q) this.f621g);
                return C0137i.f2940a;
        }
    }
}
