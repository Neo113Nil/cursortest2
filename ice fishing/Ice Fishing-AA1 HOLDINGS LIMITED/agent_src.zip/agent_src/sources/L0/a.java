package L0;

import android.location.LocationManager;
import io.appmetrica.analytics.coreapi.internal.backport.FunctionWithThrowable;
import io.appmetrica.analytics.location.impl.r;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements FunctionWithThrowable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1005a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ r f1006b;

    public /* synthetic */ a(r rVar, int i2) {
        this.f1005a = i2;
        this.f1006b = rVar;
    }

    @Override // io.appmetrica.analytics.coreapi.internal.backport.FunctionWithThrowable
    public final Object apply(Object obj) {
        switch (this.f1005a) {
            case 0:
                return r.b(this.f1006b, (LocationManager) obj);
            default:
                return r.a(this.f1006b, (LocationManager) obj);
        }
    }
}
