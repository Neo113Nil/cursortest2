package com.level.satisfying.introsadium;

/* compiled from: r8-map-id-11af519dbe316057ed2a298a845068ba4c467299989f2684005492b25fcf65a9 */
/* loaded from: classes.dex */
public final class MainActivity extends defpackage.tc implements defpackage.lw {
    public volatile defpackage.H5ezHFOx u1ini7mx5;
    public final java.lang.Object StngpVtf9yo = new java.lang.Object();
    public boolean waURbuirewRD = false;

    public MainActivity() {
        defpackage.gy gyVar = new defpackage.gy(this);
        defpackage.bg bgVar = this.W5FAnWAgjb;
        bgVar.getClass();
        defpackage.tc tcVar = bgVar.ylSKsaanMX;
        if (tcVar != null) {
            gyVar.uqTSxTys(tcVar);
        }
        bgVar.uqTSxTys.add(gyVar);
    }

    public final defpackage.H5ezHFOx LFnzeXdDl() {
        if (this.u1ini7mx5 == null) {
            synchronized (this.StngpVtf9yo) {
                try {
                    if (this.u1ini7mx5 == null) {
                        this.u1ini7mx5 = new defpackage.H5ezHFOx(this);
                    }
                } finally {
                }
            }
        }
        return this.u1ini7mx5;
    }

    @Override // defpackage.xx
    public final defpackage.ha1 RiT1pIxhfr() {
        defpackage.ha1 ha1Var = (defpackage.ha1) this.py3wcD97C.getValue();
        defpackage.fh fhVar = (defpackage.fh) ((defpackage.wj) defpackage.ri.m2STG5wmHS(this, defpackage.wj.class));
        defpackage.m50 m50VarUqTSxTys = fhVar.uqTSxTys();
        defpackage.qmRpkR0D5 qmrpkr0d5 = new defpackage.qmRpkR0D5(fhVar.uqTSxTys, fhVar.ylSKsaanMX);
        ha1Var.getClass();
        return new defpackage.dy(m50VarUqTSxTys, ha1Var, qmrpkr0d5);
    }

    public final void gHUb2uEC(android.os.Bundle bundle) {
        super.onCreate(bundle);
        defpackage.H5ezHFOx h5ezHFOxLFnzeXdDl = LFnzeXdDl();
        defpackage.va5YRU6p va5yru6p = h5ezHFOxLFnzeXdDl.tWcvOOWH9;
        com.level.satisfying.introsadium.MainActivity mainActivity = va5yru6p.nkkcEAIx0Qs;
        defpackage.sZfAAOvQykR szfaaovqykr = new defpackage.sZfAAOvQykR(0, va5yru6p.W5FAnWAgjb);
        defpackage.ja1 ja1VarW5FAnWAgjb = mainActivity.W5FAnWAgjb();
        defpackage.ah ahVarLjTaex5iF = defpackage.sw.ljTaex5iF(mainActivity);
        ahVarLjTaex5iF.getClass();
        defpackage.jBfXuTnE1 jbfxutne1 = new defpackage.jBfXuTnE1(ja1VarW5FAnWAgjb, szfaaovqykr, ahVarLjTaex5iF);
        defpackage.ia iaVarUqTSxTys = defpackage.mr0.uqTSxTys(defpackage.Ef3Zc9Pk.class);
        java.lang.String strYlSKsaanMX = iaVarUqTSxTys.ylSKsaanMX();
        if (strYlSKsaanMX == null) {
            defpackage.n4.jZSYjPy3("Local and anonymous classes can not be ViewModels");
            return;
        }
        defpackage.ou0 ou0Var = ((defpackage.Ef3Zc9Pk) jbfxutne1.H81XNRPaPZz(iaVarUqTSxTys, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strYlSKsaanMX))).j0O4MaEUapB;
        h5ezHFOxLFnzeXdDl.Xpcv1SmtlB = ou0Var;
        if (((defpackage.ud0) ou0Var.ylSKsaanMX) == null) {
            defpackage.ud0 ud0VarNkkcEAIx0Qs = h5ezHFOxLFnzeXdDl.xi6fZPZsle.nkkcEAIx0Qs();
            if (ou0Var.uqTSxTys) {
                ou0Var.ylSKsaanMX = ud0VarNkkcEAIx0Qs;
            } else {
                defpackage.n4.vaKZpAfR7PAy("setExtras should only be called for an Activity that extends ComponentActivity");
            }
        }
    }

    @Override // defpackage.lw
    public final java.lang.Object j0O4MaEUapB() {
        return LFnzeXdDl().j0O4MaEUapB();
    }

    @Override // defpackage.tc, defpackage.sc, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        defpackage.h31 h31Var = new defpackage.h31(new defpackage.cv0(28));
        defpackage.co coVar = defpackage.vn.uqTSxTys;
        android.view.View decorView = getWindow().getDecorView();
        decorView.getClass();
        defpackage.co boVar = defpackage.vn.uqTSxTys;
        if (boVar == null) {
            int i = android.os.Build.VERSION.SDK_INT;
            boVar = i >= 35 ? new defpackage.bo() : i >= 30 ? new defpackage.ao() : i >= 29 ? new defpackage.zn() : i >= 28 ? new defpackage.yn() : i >= 26 ? new defpackage.xn() : new defpackage.wn();
            defpackage.vn.uqTSxTys = boVar;
        }
        defpackage.co coVar2 = boVar;
        defpackage.c6 c6Var = new defpackage.c6(coVar2, h31Var, h31Var, this, decorView, 1);
        android.view.ViewGroup viewGroup = (android.view.ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                defpackage.un unVar = new defpackage.un(c6Var, viewGroup.getContext());
                unVar.setTag(coVar2);
                unVar.setVisibility(8);
                unVar.setWillNotDraw(true);
                viewGroup.addView(unVar);
                break;
            }
            int i3 = i2 + 1;
            android.view.View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new java.lang.IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof defpackage.co) {
                break;
            } else {
                i2 = i3;
            }
        }
        c6Var.run();
        android.view.Window window = getWindow();
        window.getClass();
        coVar2.uqTSxTys(window);
        gHUb2uEC(bundle);
        defpackage.fd fdVar = defpackage.l9.nkkcEAIx0Qs;
        android.view.ViewGroup.LayoutParams layoutParams = defpackage.uc.uqTSxTys;
        android.view.View childAt2 = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        defpackage.fe feVar = childAt2 instanceof defpackage.fe ? (defpackage.fe) childAt2 : null;
        if (feVar != null) {
            feVar.setParentCompositionContext(null);
            feVar.setContent(fdVar);
            return;
        }
        defpackage.fe feVar2 = new defpackage.fe(this);
        feVar2.setParentCompositionContext(null);
        feVar2.setContent(fdVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (defpackage.rx.HnjwzDHYC0a(decorView2) == null) {
            decorView2.setTag(com.level.satisfying.introsadium.R.id.view_tree_lifecycle_owner, this);
        }
        if (defpackage.vv.py3wcD97C(decorView2) == null) {
            decorView2.setTag(com.level.satisfying.introsadium.R.id.view_tree_view_model_store_owner, this);
        }
        if (defpackage.ey.m2STG5wmHS(decorView2) == null) {
            decorView2.setTag(com.level.satisfying.introsadium.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(feVar2, defpackage.uc.uqTSxTys);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        defpackage.ou0 ou0Var = LFnzeXdDl().Xpcv1SmtlB;
        if (ou0Var != null) {
            ou0Var.ylSKsaanMX = null;
        }
    }
}
