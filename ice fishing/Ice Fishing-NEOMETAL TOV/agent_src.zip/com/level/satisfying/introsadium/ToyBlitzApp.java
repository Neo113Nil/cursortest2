package com.level.satisfying.introsadium;

/* compiled from: r8-map-id-11af519dbe316057ed2a298a845068ba4c467299989f2684005492b25fcf65a9 */
/* loaded from: classes.dex */
public class ToyBlitzApp extends android.app.Application implements defpackage.lw {
    public boolean nkkcEAIx0Qs = false;
    public final defpackage.j4 W5FAnWAgjb = new defpackage.j4(new defpackage.qmRpkR0D5(17, this));

    @Override // defpackage.lw
    public final java.lang.Object j0O4MaEUapB() {
        return this.W5FAnWAgjb.j0O4MaEUapB();
    }

    @Override // android.app.Application
    public final void onCreate() {
        if (!this.nkkcEAIx0Qs) {
            this.nkkcEAIx0Qs = true;
            ((defpackage.p51) this.W5FAnWAgjb.j0O4MaEUapB()).getClass();
        }
        super.onCreate();
    }
}
