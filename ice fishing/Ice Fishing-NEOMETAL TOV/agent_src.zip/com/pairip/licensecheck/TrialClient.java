package com.pairip.licensecheck;

/* loaded from: classes.dex */
public final class TrialClient {
    public static void stopTrial(android.content.Context context) {
        com.pairip.licensecheck.LicenseClient.stopTrial(context);
    }

    private TrialClient() {
    }
}
