package com.kolosta.rejin.keldranis.nav;

import defpackage.cp;
import defpackage.im0;
import defpackage.ji0;
import defpackage.kk1;
import defpackage.pk0;
import defpackage.yu;

@kk1
/* loaded from: classes.dex */
public final class HomeRoute {
    public static final HomeRoute INSTANCE = new HomeRoute();
    public static final /* synthetic */ pk0 a = yu.K(im0.f, new cp(19));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof HomeRoute);
    }

    public final int hashCode() {
        return -158355116;
    }

    public final ji0 serializer() {
        return (ji0) a.getValue();
    }

    public final String toString() {
        return "HomeRoute";
    }
}
