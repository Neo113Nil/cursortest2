package com.kolosta.rejin.keldranis.nav;

import defpackage.cp;
import defpackage.im0;
import defpackage.ji0;
import defpackage.kk1;
import defpackage.pk0;
import defpackage.yu;

@kk1
/* loaded from: classes.dex */
public final class GameRoute {
    public static final GameRoute INSTANCE = new GameRoute();
    public static final /* synthetic */ pk0 a = yu.K(im0.f, new cp(18));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof GameRoute);
    }

    public final int hashCode() {
        return -1275408863;
    }

    public final ji0 serializer() {
        return (ji0) a.getValue();
    }

    public final String toString() {
        return "GameRoute";
    }
}
