package com.kolosta.rejin.keldranis.nav;

import defpackage.i2;
import defpackage.im0;
import defpackage.ji0;
import defpackage.kk1;
import defpackage.pk0;
import defpackage.yu;

@kk1
/* loaded from: classes.dex */
public final class CatalogRoute {
    public static final CatalogRoute INSTANCE = new CatalogRoute();
    public static final /* synthetic */ pk0 a = yu.K(im0.f, new i2(15));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof CatalogRoute);
    }

    public final int hashCode() {
        return 549789894;
    }

    public final ji0 serializer() {
        return (ji0) a.getValue();
    }

    public final String toString() {
        return "CatalogRoute";
    }
}
