package com.kolosta.rejin.keldranis.nav;

import defpackage.im0;
import defpackage.ji0;
import defpackage.kk1;
import defpackage.pk0;
import defpackage.po0;
import defpackage.yu;

@kk1
/* loaded from: classes.dex */
public final class ProfileRoute {
    public static final ProfileRoute INSTANCE = new ProfileRoute();
    public static final /* synthetic */ pk0 a = yu.K(im0.f, new po0(13));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof ProfileRoute);
    }

    public final int hashCode() {
        return -1373540042;
    }

    public final ji0 serializer() {
        return (ji0) a.getValue();
    }

    public final String toString() {
        return "ProfileRoute";
    }
}
