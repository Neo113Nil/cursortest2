package com.kolosta.rejin.keldranis.nav;

import defpackage.gk1;
import defpackage.kk1;
import defpackage.m2;
import defpackage.vv;
import defpackage.wv;
import defpackage.xr0;
import java.util.ArrayList;

@kk1
/* loaded from: classes.dex */
public final class DetailRoute {
    public static final wv Companion = new wv();
    public final int a;

    public DetailRoute(int i, int i2) {
        String str;
        if (1 == (i & 1)) {
            this.a = i2;
            return;
        }
        gk1 gk1VarD = vv.a.d();
        gk1VarD.getClass();
        ArrayList arrayList = new ArrayList();
        int i3 = (~i) & 1;
        int i4 = 0;
        while (i4 < 32) {
            if ((i3 & 1) != 0) {
                arrayList.add(gk1VarD.d(i4));
            }
            i4++;
            i3 = 0;
        }
        String strA = gk1VarD.a();
        strA.getClass();
        if (arrayList.size() == 1) {
            str = "Field '" + ((String) arrayList.get(0)) + "' is required for type with serial name '" + strA + "', but it was missing";
        } else {
            str = "Fields " + arrayList + " are required for type with serial name '" + strA + "', but they were missing";
        }
        throw new xr0(str, null);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof DetailRoute) && this.a == ((DetailRoute) obj).a;
    }

    public final int hashCode() {
        return Integer.hashCode(this.a);
    }

    public final String toString() {
        return m2.h(this.a, "DetailRoute(id=", ")");
    }

    public DetailRoute(int i) {
        this.a = i;
    }
}
