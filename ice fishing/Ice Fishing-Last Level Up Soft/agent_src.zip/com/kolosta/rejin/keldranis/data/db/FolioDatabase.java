package com.kolosta.rejin.keldranis.data.db;

import defpackage.ce1;
import defpackage.x60;

/* loaded from: classes.dex */
public abstract class FolioDatabase extends ce1 {
    public abstract x60 m();
}
