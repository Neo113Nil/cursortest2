package com.kolosta.rejin.keldranis.data.db;

import defpackage.ac1;
import defpackage.k20;
import defpackage.mq1;
import defpackage.ph0;
import defpackage.q10;
import defpackage.x6;
import defpackage.x60;
import defpackage.y60;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
public final class FolioDatabase_Impl extends FolioDatabase {
    public final mq1 l = new mq1(new x6(15, this));

    @Override // defpackage.ce1
    public final List b(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // defpackage.ce1
    public final ph0 c() {
        return new ph0(this, new LinkedHashMap(), new LinkedHashMap(), "wagon_records", "reader");
    }

    @Override // defpackage.ce1
    public final q10 d() {
        return new y60(this);
    }

    @Override // defpackage.ce1
    public final Set g() {
        return new LinkedHashSet();
    }

    @Override // defpackage.ce1
    public final LinkedHashMap h() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(ac1.a(x60.class), k20.f);
        return linkedHashMap;
    }

    @Override // com.kolosta.rejin.keldranis.data.db.FolioDatabase
    public final x60 m() {
        return (x60) this.l.getValue();
    }
}
