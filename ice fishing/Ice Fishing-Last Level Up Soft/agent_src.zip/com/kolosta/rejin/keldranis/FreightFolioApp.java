package com.kolosta.rejin.keldranis;

import android.app.Application;
import android.content.Context;
import defpackage.at;
import defpackage.ny;
import defpackage.p4;
import defpackage.w10;

/* loaded from: classes.dex */
public final class FreightFolioApp extends Application {
    public at f;

    @Override // android.app.Application
    public final void onCreate() {
        Object obj = ny.h;
        super.onCreate();
        Context applicationContext = getApplicationContext();
        applicationContext.getClass();
        at atVar = new at();
        p4 p4Var = new p4(11, new w10(applicationContext, false));
        ny nyVar = new ny();
        nyVar.g = obj;
        nyVar.f = p4Var;
        at atVar2 = new at();
        atVar2.f = nyVar;
        ny nyVar2 = new ny();
        nyVar2.g = obj;
        nyVar2.f = atVar2;
        atVar.f = nyVar2;
        this.f = atVar;
    }
}
