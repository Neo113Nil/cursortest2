package com.kolosta.rejin.keldranis;

import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.at;
import defpackage.c10;
import defpackage.d10;
import defpackage.e10;
import defpackage.f10;
import defpackage.fh0;
import defpackage.fn;
import defpackage.g10;
import defpackage.gq0;
import defpackage.h10;
import defpackage.i10;
import defpackage.j10;
import defpackage.jo;
import defpackage.ks1;
import defpackage.mk1;
import defpackage.nq1;
import defpackage.ns1;
import defpackage.pu1;
import defpackage.tm;
import defpackage.um;

/* loaded from: classes.dex */
public final class MainActivity extends tm {
    public static final /* synthetic */ int z = 0;

    @Override // defpackage.tm, defpackage.sm, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        nq1 nq1Var = new nq1(new mk1(6));
        nq1 nq1Var2 = new nq1(new mk1(6));
        f10 f10Var = e10.a;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        f10 j10Var = e10.a;
        if (j10Var == null) {
            int i = Build.VERSION.SDK_INT;
            j10Var = i >= 35 ? new j10() : i >= 30 ? new i10() : i >= 29 ? new h10() : i >= 28 ? new g10() : new f10();
            e10.a = j10Var;
        }
        f10 f10Var2 = j10Var;
        c10 c10Var = new c10(f10Var2, nq1Var, nq1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                d10 d10Var = new d10(c10Var, viewGroup.getContext());
                d10Var.setTag(f10Var2);
                d10Var.setVisibility(8);
                d10Var.setWillNotDraw(true);
                viewGroup.addView(d10Var);
                break;
            }
            int i3 = i2 + 1;
            View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof f10) {
                break;
            } else {
                i2 = i3;
            }
        }
        c10Var.run();
        Window window = getWindow();
        window.getClass();
        f10Var2.a(window);
        Application application = getApplication();
        application.getClass();
        at atVar = ((FreightFolioApp) application).f;
        if (atVar == null) {
            fh0.y("component");
            throw null;
        }
        fn fnVar = new fn(-726727115, new gq0(atVar, 0, (byte) 0), true);
        ViewGroup.LayoutParams layoutParams = um.a;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        jo joVar = childAt2 instanceof jo ? (jo) childAt2 : null;
        if (joVar != null) {
            joVar.setParentCompositionContext(null);
            joVar.setContent(fnVar);
            return;
        }
        jo joVar2 = new jo(this);
        joVar2.setParentCompositionContext(null);
        joVar2.setContent(fnVar);
        View decorView2 = getWindow().getDecorView();
        if (pu1.c(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (ns1.c(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (ks1.e(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(joVar2, um.a);
    }
}
