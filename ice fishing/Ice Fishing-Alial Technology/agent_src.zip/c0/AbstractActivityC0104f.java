package c0;

/* renamed from: c0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0104f extends android.app.Activity implements androidx.lifecycle.i {

    /* renamed from: i, reason: collision with root package name */
    public static final int f1689i = android.view.View.generateViewId();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1690e = false;

    /* renamed from: f, reason: collision with root package name */
    public c0.C0107i f1691f;

    /* renamed from: g, reason: collision with root package name */
    public final androidx.lifecycle.j f1692g;

    /* renamed from: h, reason: collision with root package name */
    public final android.window.OnBackInvokedCallback f1693h;

    public AbstractActivityC0104f() {
        int i2 = android.os.Build.VERSION.SDK_INT;
        this.f1693h = i2 < 33 ? null : i2 >= 34 ? new c0.C0103e(this) : new android.window.OnBackInvokedCallback() { // from class: c0.d
            public final void onBackInvoked() {
                this.f1687a.onBackPressed();
            }
        };
        this.f1692g = new androidx.lifecycle.j(this);
    }

    @Override // androidx.lifecycle.i
    public final androidx.lifecycle.j a() {
        return this.f1692g;
    }

    public final java.lang.String b() {
        java.lang.String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int c() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        java.lang.String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new java.lang.NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new java.lang.IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final java.lang.String d() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final java.lang.String e() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            android.os.Bundle bundleG = g();
            java.lang.String string = bundleG != null ? bundleG.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final java.lang.String f() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            android.os.Bundle bundleG = g();
            if (bundleG != null) {
                return bundleG.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final android.os.Bundle g() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void h(boolean z2) {
        if (z2 && !this.f1690e) {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f1693h);
                this.f1690e = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1690e || android.os.Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1693h);
        this.f1690e = false;
    }

    public final boolean i() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (d() != null || this.f1691f.f1704g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean j() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : d() == null;
    }

    public final boolean k(java.lang.String str) {
        c0.C0107i c0107i = this.f1691f;
        if (c0107i == null) {
            android.util.Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0107i.f1707j) {
            return true;
        }
        android.util.Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, android.content.Intent intent) {
        if (k("onActivityResult")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            if (c0107i.f1699b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            java.util.Objects.toString(intent);
            J.b bVar = c0107i.f1699b.f1787d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                ((d0.C0114d) bVar.f425h).d(i2, i3, intent);
                android.os.Trace.endSection();
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (k("onBackPressed")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                c0113c.f1792i.f2694a.D("popRoute", null, null);
            } else {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:204:0x04a8  */
    /* JADX WARN: Removed duplicated region for block: B:211:0x0553  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x055e  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x05b0 A[LOOP:1: B:218:0x05a8->B:220:0x05b0, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:224:0x05c7  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x05be A[EDGE_INSN: B:290:0x05be->B:221:0x05be BREAK  A[LOOP:1: B:218:0x05a8->B:220:0x05b0], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:292:0x05db A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r6v10, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(android.os.Bundle bundle) throws java.lang.IllegalAccessException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        byte[] byteArray;
        io.flutter.plugin.platform.k kVar;
        int i2;
        android.util.SparseArray sparseArray;
        int i3;
        android.util.SparseArray sparseArray2;
        int i4;
        try {
            android.os.Bundle bundleG = g();
            if (bundleG != null && (i4 = bundleG.getInt("io.flutter.embedding.android.NormalTheme", -1)) != -1) {
                setTheme(i4);
            }
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            android.util.Log.e("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
        super.onCreate(bundle);
        if (bundle != null) {
            h(bundle.getBoolean("enableOnBackInvokedCallbackState"));
        }
        c0.C0107i c0107i = new c0.C0107i(this);
        this.f1691f = c0107i;
        c0107i.c();
        if (c0107i.f1699b == null) {
            java.lang.String strD = c0107i.f1698a.d();
            if (strD != null) {
                if (d0.C0120j.f1840c == null) {
                    d0.C0120j.f1840c = new d0.C0120j(1);
                }
                d0.C0113c c0113c = (d0.C0113c) d0.C0120j.f1840c.f1841a.get(strD);
                c0107i.f1699b = c0113c;
                c0107i.f1704g = true;
                if (c0113c == null) {
                    throw new java.lang.IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + strD + "'");
                }
            } else {
                c0107i.f1698a.getClass();
                c0107i.f1699b = null;
                java.lang.String stringExtra = c0107i.f1698a.getIntent().getStringExtra("cached_engine_group_id");
                if (stringExtra != null) {
                    if (d0.C0120j.f1839b == null) {
                        synchronized (d0.C0120j.class) {
                            try {
                                if (d0.C0120j.f1839b == null) {
                                    d0.C0120j.f1839b = new d0.C0120j(0);
                                }
                            } finally {
                            }
                        }
                    }
                    d0.C0119i c0119i = (d0.C0119i) d0.C0120j.f1839b.f1841a.get(stringExtra);
                    if (c0119i == null) {
                        throw new java.lang.IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + stringExtra + "'");
                    }
                    c0.AbstractActivityC0104f abstractActivityC0104f = c0107i.f1698a;
                    abstractActivityC0104f.getClass();
                    d0.C0118h c0118h = new d0.C0118h(abstractActivityC0104f);
                    c0107i.a(c0118h);
                    c0107i.f1699b = c0119i.a(c0118h);
                    c0107i.f1704g = false;
                } else {
                    c0.AbstractActivityC0104f abstractActivityC0104f2 = c0107i.f1698a;
                    abstractActivityC0104f2.getClass();
                    android.content.Intent intent = abstractActivityC0104f2.getIntent();
                    if (intent.getExtras() != null) {
                        for (java.lang.String str : intent.getExtras().keySet()) {
                            d0.C0115e c0115eA = d0.AbstractC0116f.a(str);
                            if (c0115eA == null) {
                                c0115eA = d0.AbstractC0116f.a("--".concat(str));
                            }
                            if (c0115eA == null) {
                                c0115eA = d0.AbstractC0116f.a("--" + str + "=");
                            }
                            if (c0115eA != null) {
                                break;
                            }
                        }
                    }
                    c0.AbstractActivityC0104f abstractActivityC0104f3 = c0107i.f1698a;
                    abstractActivityC0104f3.getClass();
                    android.content.Intent intent2 = c0107i.f1698a.getIntent();
                    java.util.ArrayList arrayList = new java.util.ArrayList();
                    if (intent2.getBooleanExtra("trace-startup", false)) {
                        arrayList.add("--trace-startup");
                    }
                    if (intent2.getBooleanExtra("start-paused", false)) {
                        arrayList.add("--start-paused");
                    }
                    int intExtra = intent2.getIntExtra("vm-service-port", 0);
                    if (intExtra > 0) {
                        arrayList.add("--vm-service-port=" + intExtra);
                    }
                    if (intent2.getBooleanExtra("disable-service-auth-codes", false)) {
                        arrayList.add("--disable-service-auth-codes");
                    }
                    if (intent2.getBooleanExtra("endless-trace-buffer", false)) {
                        arrayList.add("--endless-trace-buffer");
                    }
                    if (intent2.getBooleanExtra("use-test-fonts", false)) {
                        arrayList.add("--use-test-fonts");
                    }
                    if (intent2.getBooleanExtra("enable-dart-profiling", false)) {
                        arrayList.add("--enable-dart-profiling");
                    }
                    if (intent2.getBooleanExtra("profile-startup", false)) {
                        arrayList.add("--profile-startup");
                    }
                    if (intent2.getBooleanExtra("enable-software-rendering", false)) {
                        arrayList.add("--enable-software-rendering");
                    }
                    if (intent2.getBooleanExtra("skia-deterministic-rendering", false)) {
                        arrayList.add("--skia-deterministic-rendering");
                    }
                    if (intent2.getBooleanExtra("trace-skia", false)) {
                        arrayList.add("--trace-skia");
                    }
                    java.lang.String stringExtra2 = intent2.getStringExtra("trace-skia-allowlist");
                    if (stringExtra2 != null) {
                        arrayList.add("--trace-skia-allowlist=".concat(stringExtra2));
                    }
                    if (intent2.getBooleanExtra("trace-systrace", false)) {
                        arrayList.add("--trace-systrace");
                    }
                    if (intent2.hasExtra("trace-to-file")) {
                        arrayList.add("--trace-to-file=" + intent2.getStringExtra("trace-to-file"));
                    }
                    if (intent2.hasExtra("profile-microtasks")) {
                        arrayList.add("--profile-microtasks");
                    }
                    if (intent2.hasExtra("enable-impeller")) {
                        if (intent2.getBooleanExtra("enable-impeller", false)) {
                            arrayList.add("--enable-impeller=true");
                        } else {
                            arrayList.add("--enable-impeller=false");
                        }
                    }
                    if (intent2.getBooleanExtra("enable-vulkan-validation", false)) {
                        arrayList.add("--enable-vulkan-validation");
                    }
                    if (intent2.hasExtra("enable-hcpp-and-surface-control")) {
                        if (intent2.getBooleanExtra("enable-hcpp-and-surface-control", false)) {
                            arrayList.add("--enable-hcpp-and-surface-control=true");
                        } else {
                            arrayList.add("--enable-hcpp-and-surface-control=false");
                        }
                    }
                    if (intent2.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
                        arrayList.add("--dump-skp-on-shader-compilation");
                    }
                    if (intent2.getBooleanExtra("cache-sksl", false)) {
                        arrayList.add("--cache-sksl");
                    }
                    if (intent2.getBooleanExtra("purge-persistent-cache", false)) {
                        arrayList.add("--purge-persistent-cache");
                    }
                    if (intent2.getBooleanExtra("verbose-logging", false)) {
                        arrayList.add("--verbose-logging");
                    }
                    if (intent2.hasExtra("dart-flags")) {
                        arrayList.add("--dart-flags=" + intent2.getStringExtra("dart-flags"));
                    }
                    java.util.HashSet hashSet = new java.util.HashSet(arrayList);
                    d0.C0119i c0119i2 = new d0.C0119i(abstractActivityC0104f3, (java.lang.String[]) hashSet.toArray(new java.lang.String[hashSet.size()]));
                    c0.AbstractActivityC0104f abstractActivityC0104f4 = c0107i.f1698a;
                    abstractActivityC0104f4.getClass();
                    d0.C0118h c0118h2 = new d0.C0118h(abstractActivityC0104f4);
                    c0118h2.f1836e = false;
                    c0118h2.f1837f = c0107i.f1698a.j();
                    c0107i.a(c0118h2);
                    c0107i.f1699b = c0119i2.a(c0118h2);
                    c0107i.f1704g = false;
                }
            }
        }
        c0107i.f1698a.getClass();
        J.b bVar = c0107i.f1699b.f1787d;
        androidx.lifecycle.j jVar = c0107i.f1698a.f1692g;
        bVar.getClass();
        s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            c0.C0107i c0107i2 = (c0.C0107i) bVar.f424g;
            if (c0107i2 != null) {
                c0107i2.b();
            }
            bVar.e();
            bVar.f424g = c0107i;
            c0.AbstractActivityC0104f abstractActivityC0104f5 = c0107i.f1698a;
            abstractActivityC0104f5.getClass();
            bVar.b(abstractActivityC0104f5, jVar);
            android.os.Trace.endSection();
            c0.AbstractActivityC0104f abstractActivityC0104f6 = c0107i.f1698a;
            abstractActivityC0104f6.getClass();
            c0.AbstractActivityC0104f abstractActivityC0104f7 = c0107i.f1698a;
            d0.C0113c c0113c2 = c0107i.f1699b;
            abstractActivityC0104f7.getClass();
            c0107i.f1701d = new io.flutter.plugin.platform.e(abstractActivityC0104f7, c0113c2.f1795l, abstractActivityC0104f7);
            c0.AbstractActivityC0104f abstractActivityC0104f8 = c0107i.f1698a;
            d0.C0113c c0113c3 = c0107i.f1699b;
            abstractActivityC0104f8.getClass();
            c0107i.f1702e = new q0.C0228a(f1689i, abstractActivityC0104f6, c0113c3.f1797n);
            c0.AbstractActivityC0104f abstractActivityC0104f9 = c0107i.f1698a;
            d0.C0113c c0113c4 = c0107i.f1699b;
            if (!abstractActivityC0104f9.f1691f.f1704g) {
                a.AbstractC0069a.C(c0113c4);
            }
            c0107i.f1707j = true;
            c0.C0107i c0107i3 = this.f1691f;
            c0107i3.c();
            if (bundle != null) {
                bundle.getBundle("plugins");
                byteArray = bundle.getByteArray("framework");
            } else {
                byteArray = null;
            }
            if (c0107i3.f1698a.j()) {
                l0.C0209l c0209l = c0107i3.f1699b.f1794k;
                c0209l.f2742e = true;
                l0.C0208k c0208k = c0209l.f2741d;
                if (c0208k != null) {
                    c0208k.c(l0.C0209l.a(byteArray));
                    c0209l.f2741d = null;
                    c0209l.f2739b = byteArray;
                } else if (c0209l.f2743f) {
                    c0209l.f2740c.D("push", l0.C0209l.a(byteArray), new l0.C0208k(0, c0209l, byteArray));
                } else {
                    c0209l.f2739b = byteArray;
                }
            }
            c0107i3.f1698a.getClass();
            J.b bVar2 = c0107i3.f1699b.f1787d;
            if (bVar2.f()) {
                s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onRestoreInstanceState");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((d0.C0114d) bVar2.f425h).f1812f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
            }
            this.f1692g.a(androidx.lifecycle.d.ON_CREATE);
            if (c() == 2) {
                getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            }
            c0.C0107i c0107i4 = this.f1691f;
            boolean z2 = (c() == 1 ? (char) 1 : (char) 2) == 1;
            c0107i4.c();
            if (c0107i4.f1698a.c() == 1) {
                c0.AbstractActivityC0104f abstractActivityC0104f10 = c0107i4.f1698a;
                abstractActivityC0104f10.getClass();
                c0.l lVar = new c0.l(abstractActivityC0104f10, c0107i4.f1698a.c() != 1);
                c0107i4.f1698a.getClass();
                c0.AbstractActivityC0104f abstractActivityC0104f11 = c0107i4.f1698a;
                abstractActivityC0104f11.getClass();
                c0107i4.f1700c = new c0.r(abstractActivityC0104f11, lVar);
            } else {
                c0.AbstractActivityC0104f abstractActivityC0104f12 = c0107i4.f1698a;
                abstractActivityC0104f12.getClass();
                c0.n nVar = new c0.n(abstractActivityC0104f12);
                nVar.setOpaque(c0107i4.f1698a.c() == 1);
                c0107i4.f1698a.getClass();
                c0.AbstractActivityC0104f abstractActivityC0104f13 = c0107i4.f1698a;
                abstractActivityC0104f13.getClass();
                c0107i4.f1700c = new c0.r(abstractActivityC0104f13, nVar);
            }
            c0107i4.f1700c.f1745k.add(c0107i4.f1709l);
            c0107i4.f1698a.getClass();
            c0.r rVar = c0107i4.f1700c;
            d0.C0113c c0113c5 = c0107i4.f1699b;
            rVar.getClass();
            java.util.Objects.toString(c0113c5);
            if (!rVar.c()) {
                rVar.f1747m = c0113c5;
                io.flutter.embedding.engine.renderer.h hVar = c0113c5.f1785b;
                rVar.f1746l = hVar.f2383c;
                rVar.f1743i.a(hVar);
                c0.C0105g c0105g = rVar.f1734B;
                hVar.a(c0105g);
                if (rVar.f1739e) {
                    hVar.f2381a.addResizingFlutterUiListener(rVar.f1733A);
                }
                rVar.f1749o = new L.Q(rVar, rVar.f1747m.f1791h);
                d0.C0113c c0113c6 = rVar.f1747m;
                rVar.f1750p = new io.flutter.plugin.editing.l(rVar, c0113c6.r, c0113c6.f1796m, c0113c6.f1801s, c0113c6.f1802t);
                try {
                    android.view.textservice.TextServicesManager textServicesManager = (android.view.textservice.TextServicesManager) rVar.getContext().getSystemService("textservices");
                    rVar.f1755v = textServicesManager;
                    rVar.f1751q = new io.flutter.plugin.editing.h(textServicesManager, rVar.f1747m.f1799p);
                } catch (java.lang.Exception unused2) {
                    android.util.Log.e("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
                }
                new L.Q(rVar, rVar.f1750p.f2433b, rVar.f1747m.f1796m);
                rVar.r = rVar.f1747m.f1788e;
                rVar.f1752s = new L.C0026b(rVar);
                rVar.f1753t = new c0.C0100b(rVar.f1747m.f1785b, false);
                io.flutter.view.h hVar2 = new io.flutter.view.h(rVar, c0113c5.f1789f, (android.view.accessibility.AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), c0113c5.f1803u);
                rVar.f1754u = hVar2;
                hVar2.r = rVar.f1758y;
                boolean zIsEnabled = hVar2.f2595c.isEnabled();
                boolean zIsTouchExplorationEnabled = rVar.f1754u.f2595c.isTouchExplorationEnabled();
                if (rVar.f1747m.f1785b.f2381a.getIsSoftwareRenderingEnabled()) {
                    rVar.setWillNotDraw((zIsEnabled || zIsTouchExplorationEnabled) ? false : true);
                } else {
                    rVar.setWillNotDraw(false);
                }
                d0.C0113c c0113c7 = rVar.f1747m;
                c0113c7.f1801s.f2480l.f2448a = rVar.f1754u;
                new c0.C0100b(c0113c7.f1785b, true);
                d0.C0113c c0113c8 = rVar.f1747m;
                c0113c8.f1802t.f2465j.f2448a = rVar.f1754u;
                new c0.C0100b(c0113c8.f1785b, true);
                rVar.f1750p.f2433b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(android.provider.Settings.System.getUriFor("show_password"), false, rVar.f1759z);
                rVar.e();
                kVar = c0113c5.f1801s;
                kVar.f2475g = rVar;
                i2 = 0;
                while (true) {
                    sparseArray = kVar.r;
                    if (i2 < sparseArray.size()) {
                        break;
                    }
                    kVar.f2475g.addView((io.flutter.plugin.platform.g) sparseArray.valueAt(i2));
                    i2++;
                }
                i3 = 0;
                while (true) {
                    sparseArray2 = kVar.f2484p;
                    if (i3 < sparseArray2.size()) {
                        android.util.SparseArray sparseArray3 = kVar.f2483o;
                        if (sparseArray3.size() > 0) {
                            sparseArray3.valueAt(0).getClass();
                            throw new java.lang.ClassCastException();
                        }
                        io.flutter.plugin.platform.j jVar2 = c0113c5.f1802t;
                        jVar2.f2462g = rVar;
                        int i5 = 0;
                        while (true) {
                            android.util.SparseArray sparseArray4 = jVar2.f2467l;
                            if (i5 >= sparseArray4.size()) {
                                android.util.SparseArray sparseArray5 = jVar2.f2466k;
                                if (sparseArray5.size() > 0) {
                                    sparseArray5.valueAt(0).getClass();
                                    throw new java.lang.ClassCastException();
                                }
                                java.util.Iterator it2 = rVar.f1748n.iterator();
                                if (it2.hasNext()) {
                                    it2.next().getClass();
                                    throw new java.lang.ClassCastException();
                                }
                                if (rVar.f1746l) {
                                    c0105g.a();
                                }
                            } else {
                                if (sparseArray4.valueAt(i5) != null) {
                                    throw new java.lang.ClassCastException();
                                }
                                jVar2.f2462g.addView(null);
                                i5++;
                            }
                        }
                    } else {
                        if (sparseArray2.valueAt(i3) != null) {
                            throw new java.lang.ClassCastException();
                        }
                        kVar.f2475g.addView(null);
                        i3++;
                    }
                }
            } else if (c0113c5 != rVar.f1747m) {
                rVar.a();
                rVar.f1747m = c0113c5;
                io.flutter.embedding.engine.renderer.h hVar3 = c0113c5.f1785b;
                rVar.f1746l = hVar3.f2383c;
                rVar.f1743i.a(hVar3);
                c0.C0105g c0105g2 = rVar.f1734B;
                hVar3.a(c0105g2);
                if (rVar.f1739e) {
                }
                rVar.f1749o = new L.Q(rVar, rVar.f1747m.f1791h);
                d0.C0113c c0113c62 = rVar.f1747m;
                rVar.f1750p = new io.flutter.plugin.editing.l(rVar, c0113c62.r, c0113c62.f1796m, c0113c62.f1801s, c0113c62.f1802t);
                android.view.textservice.TextServicesManager textServicesManager2 = (android.view.textservice.TextServicesManager) rVar.getContext().getSystemService("textservices");
                rVar.f1755v = textServicesManager2;
                rVar.f1751q = new io.flutter.plugin.editing.h(textServicesManager2, rVar.f1747m.f1799p);
                new L.Q(rVar, rVar.f1750p.f2433b, rVar.f1747m.f1796m);
                rVar.r = rVar.f1747m.f1788e;
                rVar.f1752s = new L.C0026b(rVar);
                rVar.f1753t = new c0.C0100b(rVar.f1747m.f1785b, false);
                io.flutter.view.h hVar22 = new io.flutter.view.h(rVar, c0113c5.f1789f, (android.view.accessibility.AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), c0113c5.f1803u);
                rVar.f1754u = hVar22;
                hVar22.r = rVar.f1758y;
                boolean zIsEnabled2 = hVar22.f2595c.isEnabled();
                boolean zIsTouchExplorationEnabled2 = rVar.f1754u.f2595c.isTouchExplorationEnabled();
                if (rVar.f1747m.f1785b.f2381a.getIsSoftwareRenderingEnabled()) {
                }
                d0.C0113c c0113c72 = rVar.f1747m;
                c0113c72.f1801s.f2480l.f2448a = rVar.f1754u;
                new c0.C0100b(c0113c72.f1785b, true);
                d0.C0113c c0113c82 = rVar.f1747m;
                c0113c82.f1802t.f2465j.f2448a = rVar.f1754u;
                new c0.C0100b(c0113c82.f1785b, true);
                rVar.f1750p.f2433b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(android.provider.Settings.System.getUriFor("show_password"), false, rVar.f1759z);
                rVar.e();
                kVar = c0113c5.f1801s;
                kVar.f2475g = rVar;
                i2 = 0;
                while (true) {
                    sparseArray = kVar.r;
                    if (i2 < sparseArray.size()) {
                    }
                    kVar.f2475g.addView((io.flutter.plugin.platform.g) sparseArray.valueAt(i2));
                    i2++;
                }
                i3 = 0;
                while (true) {
                    sparseArray2 = kVar.f2484p;
                    if (i3 < sparseArray2.size()) {
                    }
                    kVar.f2475g.addView(null);
                    i3++;
                }
            }
            c0107i4.f1700c.setId(f1689i);
            if (z2) {
                c0.r rVar2 = c0107i4.f1700c;
                if (c0107i4.f1698a.c() != 1) {
                    throw new java.lang.IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
                }
                if (c0107i4.f1703f != null) {
                    rVar2.getViewTreeObserver().removeOnPreDrawListener(c0107i4.f1703f);
                }
                c0107i4.f1703f = new c0.ViewTreeObserverOnPreDrawListenerC0106h(c0107i4, rVar2);
                rVar2.getViewTreeObserver().addOnPreDrawListener(c0107i4.f1703f);
            }
            setContentView(c0107i4.f1700c);
            android.view.Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            if (android.os.Build.VERSION.SDK_INT < 35) {
                window.setStatusBarColor(1073741824);
            }
            window.getDecorView().setSystemUiVisibility(1280);
        } catch (java.lang.Throwable th3) {
            try {
                android.os.Trace.endSection();
            } catch (java.lang.Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (k("onDestroy")) {
            this.f1691f.e();
            this.f1691f.f();
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1693h);
            this.f1690e = false;
        }
        c0.C0107i c0107i = this.f1691f;
        if (c0107i != null) {
            c0107i.f1698a = null;
            c0107i.f1699b = null;
            c0107i.f1700c = null;
            c0107i.f1701d = null;
            c0107i.f1702e = null;
            this.f1691f = null;
        }
        this.f1692g.a(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        if (k("onNewIntent")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            J.b bVar = c0113c.f1787d;
            if (bVar.f()) {
                s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((d0.C0114d) bVar.f425h).f1810d).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            java.lang.String strD = c0107i.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            l0.C0198a c0198a = c0107i.f1699b.f1792i;
            c0198a.getClass();
            java.util.HashMap map = new java.util.HashMap();
            map.put("location", strD);
            c0198a.f2694a.D("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (k("onPause")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            c0107i.f1698a.getClass();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                l0.C0201d c0201d = c0113c.f1790g;
                c0201d.a(3, c0201d.f2700c);
            }
        }
        this.f1692g.a(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (k("onPostResume")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            if (c0107i.f1699b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0107i.f1701d;
            if (eVar != null) {
                eVar.b();
            }
            java.util.Iterator it = c0107i.f1699b.f1801s.f2481m.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, java.lang.String[] strArr, int[] iArr) {
        if (k("onRequestPermissionsResult")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            if (c0107i.f1699b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            java.util.Arrays.toString(strArr);
            java.util.Arrays.toString(iArr);
            J.b bVar = c0107i.f1699b.f1787d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                java.util.Iterator it = ((java.util.HashSet) ((d0.C0114d) bVar.f425h).f1808b).iterator();
                if (!it.hasNext()) {
                    android.os.Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new java.lang.ClassCastException();
                    }
                    throw null;
                }
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1692g.a(androidx.lifecycle.d.ON_RESUME);
        if (k("onResume")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            c0107i.f1699b.f1785b.d();
            c0107i.f1698a.getClass();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                l0.C0201d c0201d = c0113c.f1790g;
                c0201d.a(2, c0201d.f2700c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(android.os.Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (k("onSaveInstanceState")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            if (c0107i.f1698a.j()) {
                bundle.putByteArray("framework", c0107i.f1699b.f1794k.f2739b);
            }
            c0107i.f1698a.getClass();
            android.os.Bundle bundle2 = new android.os.Bundle();
            J.b bVar = c0107i.f1699b.f1787d;
            if (bVar.f()) {
                s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((d0.C0114d) bVar.f425h).f1812f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0107i.f1698a.d() == null || c0107i.f1698a.i()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0107i.f1698a.f1690e);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        android.os.Bundle bundleG;
        super.onStart();
        this.f1692g.a(androidx.lifecycle.d.ON_START);
        if (k("onStart")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            if (c0107i.f1698a.d() == null && !c0107i.f1699b.f1786c.f1852j) {
                java.lang.String strF = c0107i.f1698a.f();
                if (strF == null) {
                    c0.AbstractActivityC0104f abstractActivityC0104f = c0107i.f1698a;
                    abstractActivityC0104f.getClass();
                    strF = c0107i.d(abstractActivityC0104f.getIntent());
                    if (strF == null) {
                        strF = "/";
                    }
                }
                c0.AbstractActivityC0104f abstractActivityC0104f2 = c0107i.f1698a;
                abstractActivityC0104f2.getClass();
                try {
                    bundleG = abstractActivityC0104f2.g();
                } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
                }
                java.lang.String string = bundleG != null ? bundleG.getString("io.flutter.EntrypointUri") : null;
                c0107i.f1698a.e();
                c0107i.f1699b.f1792i.f2694a.D("setInitialRoute", strF, null);
                java.lang.String strB = c0107i.f1698a.b();
                if (strB == null || strB.isEmpty()) {
                    strB = ((h0.d) L.C0026b.C().f525g).f2336e.f2324b;
                }
                c0107i.f1699b.f1786c.a(string == null ? new e0.C0125a(strB, c0107i.f1698a.e()) : new e0.C0125a(strB, string, c0107i.f1698a.e()), (java.util.List) c0107i.f1698a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            java.lang.Integer num = c0107i.f1708k;
            if (num != null) {
                c0107i.f1700c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (k("onStop")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            c0107i.f1698a.getClass();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                l0.C0201d c0201d = c0113c.f1790g;
                c0201d.a(5, c0201d.f2700c);
            }
            c0107i.f1708k = java.lang.Integer.valueOf(c0107i.f1700c.getVisibility());
            c0107i.f1700c.setVisibility(8);
            d0.C0113c c0113c2 = c0107i.f1699b;
            if (c0113c2 != null) {
                c0113c2.f1785b.b(40);
            }
        }
        this.f1692g.a(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (k("onTrimMemory")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                if (c0107i.f1706i && i2 >= 10) {
                    io.flutter.embedding.engine.FlutterJNI flutterJNI = c0113c.f1786c.f1847e;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    l0.C0199b c0199b = c0107i.f1699b.f1800q;
                    c0199b.getClass();
                    java.util.HashMap map = new java.util.HashMap(1);
                    map.put("type", "memoryPressure");
                    c0199b.f2695a.i(map, null);
                }
                c0107i.f1699b.f1785b.b(i2);
                io.flutter.plugin.platform.k kVar = c0107i.f1699b.f1801s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                java.util.Iterator it = kVar.f2481m.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (k("onUserLeaveHint")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            J.b bVar = c0113c.f1787d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            s0.AbstractC0244a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                java.util.Iterator it = ((java.util.HashSet) ((d0.C0114d) bVar.f425h).f1811e).iterator();
                if (!it.hasNext()) {
                    android.os.Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new java.lang.ClassCastException();
                    }
                    throw null;
                }
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (k("onWindowFocusChanged")) {
            c0.C0107i c0107i = this.f1691f;
            c0107i.c();
            c0107i.f1698a.getClass();
            d0.C0113c c0113c = c0107i.f1699b;
            if (c0113c != null) {
                l0.C0201d c0201d = c0113c.f1790g;
                if (z2) {
                    c0201d.a(c0201d.f2698a, true);
                } else {
                    c0201d.a(c0201d.f2698a, false);
                }
            }
        }
    }
}
