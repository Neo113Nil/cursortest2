package com.oceanbounce.fishskyquest;

/* loaded from: classes.dex */
public final class MainActivity extends c0.AbstractActivityC0104f {
}
