package com.pairip.licensecheck;

/* loaded from: classes.dex */
public class LicenseClient implements android.content.ServiceConnection {
    private static final int ERROR_INVALID_PACKAGE_NAME = 3;
    private static final int EVENTUAL_SHUTDOWN_DELAY_MILLIS = 30000;
    private static final int FIRST_ISOLATED_UID = 99000;
    private static final int FLAG_RPC_CALL = 0;
    private static final int LAST_ISOLATED_UID = 99999;
    private static final int LICENSED = 0;
    private static final int MAX_RETRIES = 3;
    private static final int MILLIS_PER_SEC = 1000;
    private static final int NOT_LICENSED = 2;
    private static final java.lang.String PAYLOAD_PAYWALL = "PAYWALL_INTENT";
    private static final int PER_USER_RANGE = 100000;
    private static final int REPEATED_CHECK_RETRY_DELAY_MILLIS = 300000;
    private static final int RETRY_DELAY_MILLIS = 1000;
    private static final java.lang.String SERVICE_INTERFACE_CLASS_NAME = "com.android.vending.licensing.ILicensingService";
    private static final java.lang.String SERVICE_PACKAGE = "com.android.vending";
    private static final java.lang.String TAG = "LicenseClient";
    private static final int TRANSACTION_CHECK_LICENSE_V2 = 2;
    private static final int TRANSACTION_REPORT_SUCCESSFUL_LICENSE_CHECK = 3;
    protected static boolean eventualShutdownEnabled = true;
    public static boolean gracefulShutdownEnabled = true;
    private static final android.os.Handler handler;
    protected static java.lang.String licensePubKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4Ybgup8UekKtHDRNGuj/t71BmJGWif5XAUUAprewZiRWyVGSbNK+m3Ei7CHQTZ4g3Dt/6cJRLCYsYk3U4prQhJUsNcQFkzrKl8NevKUU6vjaZ/3+oZdx9RQRijtEkqixuxKhOU3TOVxBErRt95qIkxGcN2XryEtAMwZaNLUlJsJKrSnEi1y9B9A7hbsTOUCNK/VgI+tK+6kJXn1zQeCseproycbqbmPphMyKBLMDYU2isvJ5GokwSX+h6dD+5eeTkChp2lvoPVp6TpiUkyDMCjJuz0a48jgG+27TyG/eDfnvBtxh/dunao8Vg9TNjBT85qhhk561zG9c29b9I3USjQIDAQAB";
    protected static boolean localCheckEnabled = true;
    protected static com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor mainThreadRunner = null;
    protected static java.lang.String packageName = "com.oceanbounce.fishskyquest";
    protected static boolean repeatedCheckEnabled = true;
    private static android.os.Bundle responsePayload;
    private final android.content.Context context;
    protected static java.lang.Runnable exitAction = new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient.1
        @Override // java.lang.Runnable
        public void run() {
            java.lang.System.exit(0);
        }
    };
    protected static com.pairip.licensecheck.LicenseClient.LicenseCheckState licenseCheckState = com.pairip.licensecheck.LicenseClient.LicenseCheckState.CHECK_REQUIRED;
    protected static com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor backgroundRunner = new com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda2
        @Override // com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor
        public final void run(java.lang.Runnable runnable) {
            new java.lang.Thread(runnable).start();
        }
    };
    protected com.pairip.licensecheck.LicenseClient.DelayedTaskExecutor delayedTaskExecutor = new com.pairip.licensecheck.LicenseClient.DelayedTaskExecutorImpl();
    private int retryNum = 0;
    protected boolean waitingForRepeatedCheck = false;
    private long repeatedCheckStartElapsedRealtime = 0;

    public interface DelayedTaskExecutor {
        void schedule(java.lang.Runnable task, long delayMillis);
    }

    public interface ImmediateTaskExecutor {
        void run(java.lang.Runnable task);
    }

    public enum LicenseCheckState {
        CHECK_REQUIRED,
        FULL_CHECK_OK,
        LOCAL_CHECK_OK,
        LOCAL_CHECK_REPORTED,
        REPEATED_CHECK_REQUIRED
    }

    static {
        final android.os.Handler handler2 = new android.os.Handler(android.os.Looper.getMainLooper());
        handler = handler2;
        java.util.Objects.requireNonNull(handler2);
        mainThreadRunner = new com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda3
            @Override // com.pairip.licensecheck.LicenseClient.ImmediateTaskExecutor
            public final void run(java.lang.Runnable runnable) {
                handler2.post(runnable);
            }
        };
    }

    public static void checkLicense(android.content.Context context) {
        if (isIsolatedProcess()) {
            android.util.Log.i(TAG, "Skipping license check in isolated process.");
        } else {
            new com.pairip.licensecheck.LicenseClient(context).initializeLicenseCheck();
        }
    }

    private static boolean isIsolatedProcess() {
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            return android.os.Process.isIsolated();
        }
        int iMyUid = android.os.Process.myUid() % PER_USER_RANGE;
        return iMyUid >= FIRST_ISOLATED_UID && iMyUid <= LAST_ISOLATED_UID;
    }

    public static java.lang.String getLicensePubKey() {
        return licensePubKey;
    }

    public LicenseClient(android.content.Context context) {
        this.context = context;
    }

    public void initializeLicenseCheck() {
        int iOrdinal = licenseCheckState.ordinal();
        if (iOrdinal == 0) {
            if (localCheckEnabled) {
                backgroundRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() throws android.content.pm.PackageManager.NameNotFoundException {
                        this.f$0.lambda$initializeLicenseCheck$0();
                    }
                });
                return;
            } else {
                connectToLicensingService();
                return;
            }
        }
        if (iOrdinal != 1) {
            if (iOrdinal != 4) {
                return;
            }
            connectToLicensingService();
        } else {
            try {
                com.pairip.licensecheck.LicenseResponseHelper.validateResponse(responsePayload, packageName);
            } catch (com.pairip.licensecheck.LicenseCheckException e2) {
                handleError(e2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$initializeLicenseCheck$0() throws android.content.pm.PackageManager.NameNotFoundException {
        final boolean zPerformLocalInstallerCheck = performLocalInstallerCheck();
        mainThreadRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$initializeLicenseCheck$1(zPerformLocalInstallerCheck);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$initializeLicenseCheck$1(boolean z2) {
        if (z2) {
            licenseCheckState = com.pairip.licensecheck.LicenseClient.LicenseCheckState.LOCAL_CHECK_OK;
        }
        connectToLicensingService();
    }

    private boolean performLocalInstallerCheck() throws android.content.pm.PackageManager.NameNotFoundException {
        try {
            if (android.os.Build.VERSION.SDK_INT < 30) {
                android.util.Log.i(TAG, "Local install check bypassed due to old SDK version.");
                return false;
            }
            android.content.pm.PackageManager packageManager = this.context.getPackageManager();
            if (packageManager == null) {
                android.util.Log.i(TAG, "Local install check bypassed due to package manager not found.");
                return false;
            }
            android.content.pm.PackageInfo packageInfo = packageManager.getPackageInfo(packageName, 0);
            if (packageInfo != null && packageInfo.applicationInfo != null) {
                int i2 = packageInfo.applicationInfo.flags;
                if ((i2 & 1) == 0 && (i2 & 128) == 0) {
                    android.content.pm.InstallSourceInfo installSourceInfo = packageManager.getInstallSourceInfo(packageName);
                    if (installSourceInfo == null) {
                        android.util.Log.i(TAG, "Local install check bypassed due to install source info not found.");
                        return false;
                    }
                    java.lang.String installingPackageName = installSourceInfo.getInstallingPackageName();
                    if (installingPackageName != null && installingPackageName.equals(SERVICE_PACKAGE)) {
                        return true;
                    }
                    android.util.Log.i(TAG, "Local install check failed due to wrong installer.");
                    return false;
                }
                android.util.Log.i(TAG, "Local install check passed due to system app.");
                return true;
            }
            android.util.Log.i(TAG, "Local install check bypassed due to app package info not found.");
            return false;
        } catch (java.lang.Exception e2) {
            android.util.Log.w(TAG, "Could not obtain package info for local installer check.", e2);
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void connectToLicensingService() {
        android.util.Log.d(TAG, "Connecting to the licensing service...");
        try {
            if (this.context.bindService(new android.content.Intent(SERVICE_INTERFACE_CLASS_NAME).setPackage(SERVICE_PACKAGE).setAction(SERVICE_INTERFACE_CLASS_NAME), this, 1)) {
                return;
            }
            retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Could not bind with the licensing service."));
        } catch (java.lang.SecurityException e2) {
            retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Not allowed to bind with the licensing service.", e2));
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceConnected(android.content.ComponentName componentName, final android.os.IBinder licensingServiceBinder) {
        android.util.Log.d(TAG, "Connected to the licensing service.");
        int iOrdinal = licenseCheckState.ordinal();
        if (iOrdinal != 0) {
            if (iOrdinal == 2) {
                backgroundRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onServiceConnected$1(licensingServiceBinder);
                    }
                });
                return;
            } else if (iOrdinal != 4) {
                return;
            }
        }
        backgroundRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$onServiceConnected$0(licensingServiceBinder);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onServiceConnected$0(android.os.IBinder iBinder) {
        try {
            checkLicenseInternal(iBinder);
        } catch (com.pairip.licensecheck.LicenseCheckException e2) {
            handleError(e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onServiceConnected$1(android.os.IBinder iBinder) {
        try {
            reportSuccessfulLicenseCheck(iBinder);
        } catch (java.lang.Exception e2) {
            android.util.Log.e(TAG, "Error while reporting license check: " + android.util.Log.getStackTraceString(e2));
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(android.content.ComponentName componentName) {
        if (licenseCheckState.equals(com.pairip.licensecheck.LicenseClient.LicenseCheckState.REPEATED_CHECK_REQUIRED) && this.waitingForRepeatedCheck) {
            android.util.Log.d(TAG, "Ignoring service disconnection in REPEATED_CHECK_REQUIRED state.");
        } else {
            android.util.Log.w(TAG, "Unexpectedly disconnected from the licensing service.");
            retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Licensing service unexpectedly disconnected."));
        }
    }

    private void checkLicenseInternal(android.os.IBinder licensingServiceBinder) throws com.pairip.licensecheck.LicenseCheckException {
        if (licensingServiceBinder == null) {
            retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Received a null binder."));
            return;
        }
        android.util.Log.d(TAG, "Sending request to licensing service...");
        android.os.Parcel parcelObtain = android.os.Parcel.obtain();
        android.os.Parcel parcelObtain2 = android.os.Parcel.obtain();
        try {
            try {
                populateInputDataForLicenseCheckV2(parcelObtain, licensingServiceBinder);
                if (!licensingServiceBinder.transact(2, parcelObtain, parcelObtain2, 0)) {
                    handleError(new com.pairip.licensecheck.LicenseCheckException("Licensing service could not process request."));
                }
            } catch (android.os.DeadObjectException e2) {
                retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Licensing service process died.", e2));
            } catch (android.os.RemoteException e3) {
                handleError(new com.pairip.licensecheck.LicenseCheckException("Error when calling licensing service.", e3));
            }
        } finally {
            parcelObtain.recycle();
            parcelObtain2.recycle();
            android.util.Log.d(TAG, "Request to licensing service sent.");
        }
    }

    public void reportSuccessfulLicenseCheck(android.os.IBinder licensingServiceBinder) throws com.pairip.licensecheck.LicenseCheckException {
        if (licensingServiceBinder == null) {
            retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Received a null binder."), true);
            return;
        }
        android.util.Log.d(TAG, "Sending request to license reporting service...");
        android.os.Parcel parcelObtain = android.os.Parcel.obtain();
        android.os.Parcel parcelObtain2 = android.os.Parcel.obtain();
        try {
            try {
                populateInputDataForReportAutoVerifiedLicense(parcelObtain, licensingServiceBinder);
                boolean zTransact = licensingServiceBinder.transact(3, parcelObtain, parcelObtain2, 0);
                if (!zTransact) {
                    android.util.Log.e(TAG, "Error sending request to license reporting service.");
                }
                if (zTransact) {
                    mainThreadRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda8
                        @Override // java.lang.Runnable
                        public final void run() {
                            com.pairip.licensecheck.LicenseClient.licenseCheckState = com.pairip.licensecheck.LicenseClient.LicenseCheckState.LOCAL_CHECK_REPORTED;
                        }
                    });
                }
            } catch (android.os.DeadObjectException e2) {
                retryOrThrow(new com.pairip.licensecheck.LicenseCheckException("Licensing service process died.", e2), true);
            } catch (android.os.RemoteException e3) {
                android.util.Log.e(TAG, "Error when calling licensing service." + java.lang.String.valueOf(e3));
            }
        } finally {
            parcelObtain.recycle();
            parcelObtain2.recycle();
            android.util.Log.d(TAG, "Request to licensing reporting service sent.");
        }
    }

    private void populateInputDataForLicenseCheckV2(android.os.Parcel inputData, android.os.IBinder licensingService) throws android.os.RemoteException {
        inputData.writeInterfaceToken(licensingService.getInterfaceDescriptor());
        inputData.writeString(packageName);
        inputData.writeStrongBinder(createResultListener(this).asBinder());
        inputData.writeInt(0);
    }

    private void populateInputDataForReportAutoVerifiedLicense(android.os.Parcel inputData, android.os.IBinder licensingService) throws android.os.RemoteException {
        inputData.writeInterfaceToken(licensingService.getInterfaceDescriptor());
        inputData.writeString(packageName);
        inputData.writeInt(0);
    }

    private static com.pairip.licensecheck.ILicenseV2ResultListener createResultListener(com.pairip.licensecheck.LicenseClient client) {
        return new com.pairip.licensecheck.ILicenseV2ResultListener.Stub() { // from class: com.pairip.licensecheck.LicenseClient.2
            @Override // com.pairip.licensecheck.ILicenseV2ResultListener
            public void verifyLicense(int responseCode, android.os.Bundle responsePayload2) throws com.pairip.licensecheck.LicenseCheckException {
                com.pairip.licensecheck.LicenseClient.this.processResponse(responseCode, responsePayload2);
            }
        };
    }

    private void retryOrThrow(com.pairip.licensecheck.LicenseCheckException error) {
        retryOrThrow(error, false);
    }

    private void retryOrThrow(com.pairip.licensecheck.LicenseCheckException error, boolean ignoreErrorOnFinalFailure) {
        int i2 = this.retryNum;
        if (i2 < 3) {
            this.retryNum = i2 + 1;
            this.delayedTaskExecutor.schedule(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.connectToLicensingService();
                }
            }, 1000L);
            android.util.Log.d(TAG, java.lang.String.format("Retry #%d. License check failed with error '%s'. Next try in %ds...", java.lang.Integer.valueOf(this.retryNum), error == null ? "null" : error.getMessage(), 1L));
        } else {
            if (ignoreErrorOnFinalFailure) {
                android.util.Log.e(TAG, "Retry limit reached for: " + java.lang.String.valueOf(error));
                return;
            }
            handleError(error);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void processResponse(int responseCode, final android.os.Bundle responsePayload2) throws com.pairip.licensecheck.LicenseCheckException {
        try {
            if (responseCode == 3) {
                throw new com.pairip.licensecheck.LicenseCheckException("Request package name invalid.");
            }
            if (responseCode != 0) {
                if (responseCode == 2) {
                    startPaywallActivity((android.app.PendingIntent) responsePayload2.getParcelable(PAYLOAD_PAYWALL));
                    return;
                }
                throw new com.pairip.licensecheck.LicenseCheckException(java.lang.String.format("Unexpected response code %d received.", java.lang.Integer.valueOf(responseCode)));
            }
            com.pairip.licensecheck.LicenseResponseHelper.validateResponse(responsePayload2, packageName);
            android.util.Log.i(TAG, "License check succeeded.");
            final com.pairip.licensecheck.RepeatedCheckMetadata repeatedCheckMetadata = repeatedCheckEnabled ? com.pairip.licensecheck.LicenseResponseHelper.getRepeatedCheckMetadata(responsePayload2) : null;
            mainThreadRunner.run(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$processResponse$0(repeatedCheckMetadata, responsePayload2);
                }
            });
        } catch (com.pairip.licensecheck.LicenseCheckException e2) {
            handleError(e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$processResponse$0(com.pairip.licensecheck.RepeatedCheckMetadata repeatedCheckMetadata, android.os.Bundle bundle) {
        if (repeatedCheckMetadata != null) {
            licenseCheckState = com.pairip.licensecheck.LicenseClient.LicenseCheckState.REPEATED_CHECK_REQUIRED;
            this.repeatedCheckStartElapsedRealtime = getElapsedRealtimeMillis();
            scheduleRepeatedLicenseCheck(repeatedCheckMetadata);
        } else {
            licenseCheckState = com.pairip.licensecheck.LicenseClient.LicenseCheckState.FULL_CHECK_OK;
        }
        responsePayload = bundle;
    }

    private void scheduleRepeatedLicenseCheck(final com.pairip.licensecheck.RepeatedCheckMetadata repeatedCheckMetadata) {
        long jMin = java.lang.Math.min(java.lang.Math.min(repeatedCheckMetadata.getDurationToRetryMillis(), java.lang.Math.max(0L, repeatedCheckMetadata.getTimeToRetryMillis() - getCurrentTimeMillis())), 300000L);
        if (!this.waitingForRepeatedCheck) {
            this.waitingForRepeatedCheck = true;
            try {
                this.context.unbindService(this);
            } catch (java.lang.RuntimeException e2) {
                android.util.Log.e(TAG, "Failed to unbind service for repeated license check.", e2);
            }
        }
        this.delayedTaskExecutor.schedule(new java.lang.Runnable() { // from class: com.pairip.licensecheck.LicenseClient$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$scheduleRepeatedLicenseCheck$0(repeatedCheckMetadata);
            }
        }, jMin);
        android.util.Log.d(TAG, java.lang.String.format("Repeated license check is scheduled in %d ms...", java.lang.Long.valueOf(jMin)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$scheduleRepeatedLicenseCheck$0(com.pairip.licensecheck.RepeatedCheckMetadata repeatedCheckMetadata) {
        long elapsedRealtimeMillis = getElapsedRealtimeMillis() - this.repeatedCheckStartElapsedRealtime;
        if (getCurrentTimeMillis() >= repeatedCheckMetadata.getTimeToRetryMillis() || elapsedRealtimeMillis >= repeatedCheckMetadata.getDurationToRetryMillis()) {
            this.waitingForRepeatedCheck = false;
            connectToLicensingService();
        } else {
            android.util.Log.d(TAG, "Repeated license check is rescheduled.");
            scheduleRepeatedLicenseCheck(repeatedCheckMetadata);
        }
    }

    private void handleError(com.pairip.licensecheck.LicenseCheckException ex) {
        android.util.Log.e(TAG, "Error while checking license: " + android.util.Log.getStackTraceString(ex));
        if (licenseCheckState.equals(com.pairip.licensecheck.LicenseClient.LicenseCheckState.FULL_CHECK_OK)) {
            return;
        }
        startErrorDialogActivity();
    }

    private void startPaywallActivity(android.app.PendingIntent paywallIntent) {
        android.content.Intent intentCreateCloseAppIntentOrExitIfAppInBackground = createCloseAppIntentOrExitIfAppInBackground();
        intentCreateCloseAppIntentOrExitIfAppInBackground.putExtra(com.pairip.licensecheck.LicenseActivity.PAYWALL_INTENT_ARG_NAME, paywallIntent);
        intentCreateCloseAppIntentOrExitIfAppInBackground.putExtra(com.pairip.licensecheck.LicenseActivity.ACTIVITY_TYPE_ARG_NAME, com.pairip.licensecheck.LicenseActivity.ActivityType.PAYWALL);
        scheduleAppShutdown();
        this.context.startActivity(intentCreateCloseAppIntentOrExitIfAppInBackground);
    }

    private void startErrorDialogActivity() {
        android.content.Intent intentCreateCloseAppIntentOrExitIfAppInBackground = createCloseAppIntentOrExitIfAppInBackground();
        intentCreateCloseAppIntentOrExitIfAppInBackground.putExtra(com.pairip.licensecheck.LicenseActivity.ACTIVITY_TYPE_ARG_NAME, com.pairip.licensecheck.LicenseActivity.ActivityType.ERROR_DIALOG);
        scheduleAppShutdown();
        this.context.startActivity(intentCreateCloseAppIntentOrExitIfAppInBackground);
    }

    private android.content.Intent createCloseAppIntentOrExitIfAppInBackground() {
        if (!isForeground()) {
            exitAction.run();
        }
        android.content.Intent intent = new android.content.Intent(this.context, (java.lang.Class<?>) com.pairip.licensecheck.LicenseActivity.class);
        if (gracefulShutdownEnabled) {
            intent.addFlags(65536);
        } else {
            intent.addFlags(67108864);
            intent.addFlags(32768);
        }
        intent.addFlags(268435456);
        return intent;
    }

    private boolean isForeground() {
        android.app.ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new android.app.ActivityManager.RunningAppProcessInfo();
        android.app.ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance <= 100;
    }

    protected long getCurrentTimeMillis() {
        return java.lang.System.currentTimeMillis();
    }

    protected long getElapsedRealtimeMillis() {
        return android.os.SystemClock.elapsedRealtime();
    }

    private void scheduleAppShutdown() {
        if (eventualShutdownEnabled) {
            this.delayedTaskExecutor.schedule(exitAction, 30000L);
        }
    }

    private static class DelayedTaskExecutorImpl implements com.pairip.licensecheck.LicenseClient.DelayedTaskExecutor {
        private final android.os.Handler handler;

        private DelayedTaskExecutorImpl() {
            this.handler = new android.os.Handler(android.os.Looper.getMainLooper());
        }

        @Override // com.pairip.licensecheck.LicenseClient.DelayedTaskExecutor
        public void schedule(java.lang.Runnable task, long delayMillis) {
            this.handler.postDelayed(task, delayMillis);
        }
    }
}
