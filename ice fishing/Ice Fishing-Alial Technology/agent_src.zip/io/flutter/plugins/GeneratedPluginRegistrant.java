package io.flutter.plugins;

/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final java.lang.String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(d0.C0113c c0113c) {
        try {
            c0113c.f1787d.a(new r0.J());
        } catch (java.lang.Exception e2) {
            android.util.Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e2);
        }
    }
}
