package com.icefishingdrift.app.data.local;

import androidx.compose.foundation.be;
import androidx.compose.foundation.e;
import androidx.compose.foundation.jc3;
import androidx.compose.foundation.l11;
import androidx.compose.foundation.pf0;
import androidx.compose.foundation.td0;
import androidx.compose.foundation.v10;
import androidx.compose.foundation.v20;
import androidx.compose.foundation.y13;
import androidx.compose.foundation.yc2;
import com.icefishingdrift.app.data.local.AppDatabase_Impl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-e4752f470793bc316f1b08a2c8a0096351e33ae325d154a9d99e173c72ea0362 */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final y13 IWJJ8C1S4U5b4QVv3Z9k;
    public final y13 YM8MrPDCuQGSNdDmty9e;

    public AppDatabase_Impl() {
        final int i = 0;
        this.YM8MrPDCuQGSNdDmty9e = new y13(new td0(this) { // from class: androidx.compose.foundation.d
            public final /* synthetic */ AppDatabase_Impl gqsM9OKvA60bCyp8lC8y;

            {
                this.gqsM9OKvA60bCyp8lC8y = this;
            }

            @Override // androidx.compose.foundation.td0
            public final Object invoke() {
                int i2 = i;
                AppDatabase_Impl appDatabase_Impl = this.gqsM9OKvA60bCyp8lC8y;
                switch (i2) {
                    case qh0.Oz4Rzi4EXZc37U9canjI /* 0 */:
                        return new jc3(appDatabase_Impl);
                    default:
                        return new pf0(appDatabase_Impl);
                }
            }
        });
        final int i2 = 1;
        this.IWJJ8C1S4U5b4QVv3Z9k = new y13(new td0(this) { // from class: androidx.compose.foundation.d
            public final /* synthetic */ AppDatabase_Impl gqsM9OKvA60bCyp8lC8y;

            {
                this.gqsM9OKvA60bCyp8lC8y = this;
            }

            @Override // androidx.compose.foundation.td0
            public final Object invoke() {
                int i22 = i2;
                AppDatabase_Impl appDatabase_Impl = this.gqsM9OKvA60bCyp8lC8y;
                switch (i22) {
                    case qh0.Oz4Rzi4EXZc37U9canjI /* 0 */:
                        return new jc3(appDatabase_Impl);
                    default:
                        return new pf0(appDatabase_Impl);
                }
            }
        });
    }

    @Override // androidx.compose.foundation.kh2
    public final List IjINFEVs68ysOFtGU2Wx(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // androidx.compose.foundation.kh2
    public final l11 Oz4Rzi4EXZc37U9canjI() {
        return new l11(this, new LinkedHashMap(), new LinkedHashMap(), "users", "game_results");
    }

    @Override // androidx.compose.foundation.kh2
    public final LinkedHashMap PjiblhSItCtjq553Us1W() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        be beVarFickVf4ijXK7btIiWK00 = yc2.FickVf4ijXK7btIiWK00(jc3.class);
        v20 v20Var = v20.PjiblhSItCtjq553Us1W;
        linkedHashMap.put(beVarFickVf4ijXK7btIiWK00, v20Var);
        linkedHashMap.put(yc2.FickVf4ijXK7btIiWK00(pf0.class), v20Var);
        return linkedHashMap;
    }

    @Override // androidx.compose.foundation.kh2
    public final Set YM8MrPDCuQGSNdDmty9e() {
        return new LinkedHashSet();
    }

    @Override // com.icefishingdrift.app.data.local.AppDatabase
    public final jc3 aEQ3yN26ZCKUnIEzHV1y() {
        return (jc3) this.YM8MrPDCuQGSNdDmty9e.getValue();
    }

    @Override // com.icefishingdrift.app.data.local.AppDatabase
    public final pf0 rlEEGzGk60nJ7xK1QjPD() {
        return (pf0) this.IWJJ8C1S4U5b4QVv3Z9k.getValue();
    }

    @Override // androidx.compose.foundation.kh2
    public final v10 vdEn2c12rjT9VCVUNnx1() {
        return new e(this);
    }
}
