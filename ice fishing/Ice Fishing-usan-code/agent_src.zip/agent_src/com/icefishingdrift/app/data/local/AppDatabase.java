package com.icefishingdrift.app.data.local;

import androidx.compose.foundation.jc3;
import androidx.compose.foundation.kh2;
import androidx.compose.foundation.pf0;

/* compiled from: r8-map-id-e4752f470793bc316f1b08a2c8a0096351e33ae325d154a9d99e173c72ea0362 */
/* loaded from: classes.dex */
public abstract class AppDatabase extends kh2 {
    public abstract jc3 aEQ3yN26ZCKUnIEzHV1y();

    public abstract pf0 rlEEGzGk60nJ7xK1QjPD();
}
