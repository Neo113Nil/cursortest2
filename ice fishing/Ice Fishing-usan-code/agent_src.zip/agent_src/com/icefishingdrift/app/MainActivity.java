package com.icefishingdrift.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.compose.foundation.c23;
import androidx.compose.foundation.ci;
import androidx.compose.foundation.i10;
import androidx.compose.foundation.j10;
import androidx.compose.foundation.jj;
import androidx.compose.foundation.k10;
import androidx.compose.foundation.l10;
import androidx.compose.foundation.m10;
import androidx.compose.foundation.mh2;
import androidx.compose.foundation.n01;
import androidx.compose.foundation.n10;
import androidx.compose.foundation.n6;
import androidx.compose.foundation.o10;
import androidx.compose.foundation.p;
import androidx.compose.foundation.pg2;
import androidx.compose.foundation.rh;
import androidx.compose.foundation.ri2;
import androidx.compose.foundation.si2;
import androidx.compose.foundation.si3;
import androidx.compose.foundation.ti3;
import androidx.compose.foundation.ui3;
import androidx.compose.foundation.uk2;
import androidx.compose.foundation.wi2;
import androidx.compose.foundation.y01;

/* compiled from: r8-map-id-e4752f470793bc316f1b08a2c8a0096351e33ae325d154a9d99e173c72ea0362 */
/* loaded from: classes.dex */
public final class MainActivity extends Hilt_MainActivity {
    public p RRuZhHQHw4ILJNzcKwpe;

    @Override // com.icefishingdrift.app.Hilt_MainActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        c23 c23Var = new c23(0, 0, new uk2(14));
        c23 c23Var2 = new c23(j10.FickVf4ijXK7btIiWK00, j10.fEm7en8liOLrkiXNcbMC, new uk2(14));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        k10 o10Var = j10.yYreybWBFGdFwFy0Mtfj;
        if (o10Var == null) {
            int i = Build.VERSION.SDK_INT;
            o10Var = i >= 35 ? new o10() : i >= 30 ? new n10() : i >= 29 ? new m10() : i >= 28 ? new l10() : new k10();
            j10.yYreybWBFGdFwFy0Mtfj = o10Var;
        }
        k10 k10Var = o10Var;
        n6 n6Var = new n6(k10Var, c23Var, c23Var2, this, decorView, 2);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                i10 i10Var = new i10(n6Var, viewGroup.getContext());
                i10Var.setTag(k10Var);
                i10Var.setVisibility(8);
                i10Var.setWillNotDraw(true);
                viewGroup.addView(i10Var);
                break;
            }
            int i3 = i2 + 1;
            View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof k10) {
                break;
            } else {
                i2 = i3;
            }
        }
        n6Var.run();
        Window window = getWindow();
        window.getClass();
        k10Var.FickVf4ijXK7btIiWK00(window);
        Window window2 = getWindow();
        getWindow().getDecorView();
        int i4 = Build.VERSION.SDK_INT;
        pg2 ui3Var = i4 >= 35 ? new ui3(window2) : i4 >= 30 ? new ti3(window2) : new si3(window2);
        ui3Var.kSbrgeDRLAig9WDPnSmD(false);
        ui3Var.aEQ3yN26ZCKUnIEzHV1y(false);
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setRequestedOrientation(1);
        ci ciVar = n01.yYreybWBFGdFwFy0Mtfj;
        ViewGroup.LayoutParams layoutParams = rh.FickVf4ijXK7btIiWK00;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        jj jjVar = childAt2 instanceof jj ? (jj) childAt2 : null;
        if (jjVar != null) {
            jjVar.setParentCompositionContext(null);
            jjVar.setContent(ciVar);
        } else {
            jj jjVar2 = new jj(this);
            jjVar2.setParentCompositionContext(null);
            jjVar2.setContent(ciVar);
            View decorView2 = getWindow().getDecorView();
            if (ri2.Oz4Rzi4EXZc37U9canjI(decorView2) == null) {
                decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
            }
            if (wi2.yYreybWBFGdFwFy0Mtfj(decorView2) == null) {
                decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
            }
            if (si2.yYreybWBFGdFwFy0Mtfj(decorView2) == null) {
                decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
            }
            setContentView(jjVar2, rh.FickVf4ijXK7btIiWK00);
        }
        if (mh2.d1L5kLX53PYWBb2jr1ik(this, "android.permission.POST_NOTIFICATIONS") == 0 || i5 < 33) {
            return;
        }
        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    }

    @Override // android.app.Activity
    public final void onStart() {
        super.onStart();
        p pVar = this.RRuZhHQHw4ILJNzcKwpe;
        if (pVar == null) {
            y01.l3QMbzlLgZaD8SboOQLP("soundManager");
            throw null;
        }
        if (pVar.WPgfD6bl3P2FSxmELD4a && pVar.IjINFEVs68ysOFtGU2Wx) {
            pVar.yYreybWBFGdFwFy0Mtfj();
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        p pVar = this.RRuZhHQHw4ILJNzcKwpe;
        if (pVar == null) {
            y01.l3QMbzlLgZaD8SboOQLP("soundManager");
            throw null;
        }
        pVar.FickVf4ijXK7btIiWK00();
        super.onStop();
    }
}
