package com.icefishingdrift.app;

import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.compose.foundation.CpQcbAWLFkWIeOVYFjBp;
import androidx.compose.foundation.WmKSRYz5y4GP90wyndeJ;
import androidx.compose.foundation.ZzgkdBN6Bk7gfCgXg11U;
import androidx.compose.foundation.a52;
import androidx.compose.foundation.aWM6oxJovZ9HP0KOF9y4;
import androidx.compose.foundation.be;
import androidx.compose.foundation.gg0;
import androidx.compose.foundation.ji2;
import androidx.compose.foundation.kc4;
import androidx.compose.foundation.kp;
import androidx.compose.foundation.lj0;
import androidx.compose.foundation.lo;
import androidx.compose.foundation.lu;
import androidx.compose.foundation.nj0;
import androidx.compose.foundation.nq2;
import androidx.compose.foundation.rf3;
import androidx.compose.foundation.tf3;
import androidx.compose.foundation.vcI6NfhOaNU2SEC1qGIa;
import androidx.compose.foundation.yc2;
import androidx.compose.foundation.z61;
import androidx.compose.foundation.zq;

/* compiled from: r8-map-id-e4752f470793bc316f1b08a2c8a0096351e33ae325d154a9d99e173c72ea0362 */
/* loaded from: classes.dex */
public abstract class Hilt_MainActivity extends ComponentActivity implements gg0 {
    public volatile CpQcbAWLFkWIeOVYFjBp gqsM9OKvA60bCyp8lC8y;
    public final Object XYEEBv0bzVUbXUXsvXAf = new Object();
    public boolean n7fTXzmaEs8S05T2jWoJ = false;

    public Hilt_MainActivity() {
        addOnContextAvailableListener(new nj0((MainActivity) this));
    }

    @Override // androidx.compose.foundation.gg0
    public final Object FickVf4ijXK7btIiWK00() {
        return WPgfD6bl3P2FSxmELD4a().FickVf4ijXK7btIiWK00();
    }

    public final CpQcbAWLFkWIeOVYFjBp WPgfD6bl3P2FSxmELD4a() {
        if (this.gqsM9OKvA60bCyp8lC8y == null) {
            synchronized (this.XYEEBv0bzVUbXUXsvXAf) {
                try {
                    if (this.gqsM9OKvA60bCyp8lC8y == null) {
                        this.gqsM9OKvA60bCyp8lC8y = new CpQcbAWLFkWIeOVYFjBp(this);
                    }
                } finally {
                }
            }
        }
        return this.gqsM9OKvA60bCyp8lC8y;
    }

    @Override // androidx.activity.ComponentActivity, androidx.compose.foundation.ui0
    public final rf3 getDefaultViewModelProviderFactory() {
        rf3 defaultViewModelProviderFactory = super.getDefaultViewModelProviderFactory();
        kp kpVar = (kp) ((lu) zq.gqsM9OKvA60bCyp8lC8y(this, lu.class));
        z61 z61VarFickVf4ijXK7btIiWK00 = kpVar.FickVf4ijXK7btIiWK00();
        a52 a52Var = new a52(5, kpVar.FickVf4ijXK7btIiWK00, kpVar.fEm7en8liOLrkiXNcbMC);
        defaultViewModelProviderFactory.getClass();
        return new lj0(z61VarFickVf4ijXK7btIiWK00, defaultViewModelProviderFactory, a52Var);
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        CpQcbAWLFkWIeOVYFjBp cpQcbAWLFkWIeOVYFjBpWPgfD6bl3P2FSxmELD4a = WPgfD6bl3P2FSxmELD4a();
        aWM6oxJovZ9HP0KOF9y4 awm6oxjovz9hp0kof9y4 = cpQcbAWLFkWIeOVYFjBpWPgfD6bl3P2FSxmELD4a.n7fTXzmaEs8S05T2jWoJ;
        Hilt_MainActivity hilt_MainActivity = awm6oxjovz9hp0kof9y4.PjiblhSItCtjq553Us1W;
        ZzgkdBN6Bk7gfCgXg11U zzgkdBN6Bk7gfCgXg11U = new ZzgkdBN6Bk7gfCgXg11U(0, awm6oxjovz9hp0kof9y4.gqsM9OKvA60bCyp8lC8y);
        tf3 viewModelStore = hilt_MainActivity.getViewModelStore();
        lo loVarWPgfD6bl3P2FSxmELD4a = ji2.WPgfD6bl3P2FSxmELD4a(hilt_MainActivity);
        viewModelStore.getClass();
        loVarWPgfD6bl3P2FSxmELD4a.getClass();
        nq2 nq2Var = new nq2(viewModelStore, zzgkdBN6Bk7gfCgXg11U, loVarWPgfD6bl3P2FSxmELD4a);
        be beVarFickVf4ijXK7btIiWK00 = yc2.FickVf4ijXK7btIiWK00(WmKSRYz5y4GP90wyndeJ.class);
        String strFEm7en8liOLrkiXNcbMC = beVarFickVf4ijXK7btIiWK00.fEm7en8liOLrkiXNcbMC();
        if (strFEm7en8liOLrkiXNcbMC == null) {
            vcI6NfhOaNU2SEC1qGIa.Oz4Rzi4EXZc37U9canjI("Local and anonymous classes can not be ViewModels");
            return;
        }
        kc4 kc4Var = ((WmKSRYz5y4GP90wyndeJ) nq2Var.yYreybWBFGdFwFy0Mtfj(beVarFickVf4ijXK7btIiWK00, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strFEm7en8liOLrkiXNcbMC))).fEm7en8liOLrkiXNcbMC;
        cpQcbAWLFkWIeOVYFjBpWPgfD6bl3P2FSxmELD4a.RRuZhHQHw4ILJNzcKwpe = kc4Var;
        if (((lo) kc4Var.gqsM9OKvA60bCyp8lC8y) == null) {
            lo defaultViewModelCreationExtras = cpQcbAWLFkWIeOVYFjBpWPgfD6bl3P2FSxmELD4a.XYEEBv0bzVUbXUXsvXAf.getDefaultViewModelCreationExtras();
            if (kc4Var.PjiblhSItCtjq553Us1W) {
                kc4Var.gqsM9OKvA60bCyp8lC8y = defaultViewModelCreationExtras;
            } else {
                vcI6NfhOaNU2SEC1qGIa.YM8MrPDCuQGSNdDmty9e("setExtras should only be called for an Activity that extends ComponentActivity");
            }
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        kc4 kc4Var = WPgfD6bl3P2FSxmELD4a().RRuZhHQHw4ILJNzcKwpe;
        if (kc4Var != null) {
            kc4Var.gqsM9OKvA60bCyp8lC8y = null;
        }
    }
}
