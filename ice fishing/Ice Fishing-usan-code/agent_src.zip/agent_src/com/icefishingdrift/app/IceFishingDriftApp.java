package com.icefishingdrift.app;

import android.app.Application;
import androidx.compose.foundation.gg0;
import androidx.compose.foundation.r;
import androidx.compose.foundation.rg0;
import androidx.compose.foundation.uq0;
import androidx.compose.foundation.xu1;
import androidx.compose.foundation.ys0;

/* compiled from: r8-map-id-e4752f470793bc316f1b08a2c8a0096351e33ae325d154a9d99e173c72ea0362 */
/* loaded from: classes.dex */
public final class IceFishingDriftApp extends Application implements gg0 {
    public boolean PjiblhSItCtjq553Us1W = false;
    public final r gqsM9OKvA60bCyp8lC8y = new r(new rg0(18, this));

    @Override // androidx.compose.foundation.gg0
    public final Object FickVf4ijXK7btIiWK00() {
        return this.gqsM9OKvA60bCyp8lC8y.FickVf4ijXK7btIiWK00();
    }

    public final void fEm7en8liOLrkiXNcbMC() {
        if (!this.PjiblhSItCtjq553Us1W) {
            this.PjiblhSItCtjq553Us1W = true;
            ((ys0) this.gqsM9OKvA60bCyp8lC8y.FickVf4ijXK7btIiWK00()).getClass();
        }
        super.onCreate();
    }

    @Override // android.app.Application
    public final void onCreate() {
        fEm7en8liOLrkiXNcbMC();
        ((uq0) xu1.FickVf4ijXK7btIiWK00.getValue()).initWithContext(this, "b8412f8e-c530-4cbc-9f15-7e7ab56db855");
    }
}
