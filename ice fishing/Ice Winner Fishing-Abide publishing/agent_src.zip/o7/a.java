package o7;

import a1.d;
import a1.m;
import a1.p;
import a5.r;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.window.BackEvent;
import androidx.compose.foundation.layout.FillElement;
import androidx.lifecycle.b1;
import androidx.lifecycle.k;
import androidx.lifecycle.v0;
import androidx.lifecycle.x0;
import androidx.lifecycle.z0;
import b6.h;
import c0.o;
import com.appsflyer.R;
import d6.e;
import de.l;
import e.i;
import fe.r0;
import fe.u0;
import id.d0;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Pair;
import kotlin.collections.o0;
import kotlin.collections.x;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import m2.s;
import n1.f;
import o0.a1;
import o0.e1;
import o0.n1;
import o0.q;
import o0.s1;
import o0.y;
import r1.c;
import x0.j;
import x1.f0;
import z1.a0;
import z1.g;
import z1.t;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public abstract class a implements ee.b, ee.a {

    /* renamed from: a, reason: collision with root package name */
    public static Context f6531a;

    /* renamed from: b, reason: collision with root package name */
    public static Boolean f6532b;

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f6533c = 0;

    /* renamed from: d, reason: collision with root package name */
    public static f f6534d;

    /* renamed from: e, reason: collision with root package name */
    public static f f6535e;

    public static final void D(a1 isVisible, q qVar, int i8) {
        Intrinsics.checkNotNullParameter(isVisible, "isVisible");
        qVar.a0(-817351878);
        int i10 = (qVar.f(isVisible) ? 4 : 2) | i8;
        if (qVar.Q(i10 & 1, (i10 & 3) != 2)) {
            Activity activity = (Activity) qVar.j(i.f2154a);
            b1 b1VarA = c4.a.a(qVar);
            if (b1VarA == null) {
                throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
            }
            Object obj = (e) h0(d0.a(e.class), b1VarA, c.g(b1VarA, qVar), b1VarA instanceof k ? ((k) b1VarA).f() : b4.a.f1052b, qVar);
            Object[] objArr = new Object[0];
            Object objL = qVar.L();
            Object obj2 = o0.k.f6241a;
            if (objL == obj2) {
                objL = new h(5);
                qVar.j0(objL);
            }
            e1 e1Var = (e1) j.c(objArr, (Function0) objL, qVar);
            Object[] objArr2 = new Object[0];
            Object objL2 = qVar.L();
            if (objL2 == obj2) {
                objL2 = new h(6);
                qVar.j0(objL2);
            }
            a1 a1Var = (a1) j.c(objArr2, (Function0) objL2, qVar);
            if (e1Var.h() == 0.0f) {
                qVar.Z(-1559890905);
                if (activity != null) {
                    q3.a.g(activity, w5.a.f8399d);
                }
                G(0, qVar);
            } else {
                qVar.Z(-1561455320);
            }
            qVar.q(false);
            if (((Boolean) isVisible.getValue()).booleanValue() && ((Boolean) a1Var.getValue()).booleanValue()) {
                qVar.Z(-1559738788);
                p pVarK = K(androidx.compose.foundation.layout.c.f712c, e1Var.h());
                f0 f0VarD = o.d(a1.c.f24d, false);
                int iHashCode = Long.hashCode(qVar.T);
                n1 n1VarL = qVar.l();
                p pVarB = i.e.B(pVarK, qVar);
                z1.k.f9365h.getClass();
                Function0 function0 = z1.j.f9357b;
                qVar.c0();
                if (qVar.S) {
                    qVar.k(function0);
                } else {
                    qVar.m0();
                }
                y.w(f0VarD, z1.j.f9360e, qVar);
                y.w(n1VarL, z1.j.f9359d, qVar);
                z1.i iVar = z1.j.f9361f;
                if (qVar.S || !Intrinsics.b(qVar.L(), Integer.valueOf(iHashCode))) {
                    d.t(iHashCode, qVar, iHashCode, iVar);
                }
                y.w(pVarB, z1.j.f9358c, qVar);
                if (activity != null) {
                    q3.a.g(activity, w5.a.f8401i);
                }
                boolean zH = qVar.h(activity) | qVar.f(e1Var);
                Object objL3 = qVar.L();
                if (zH || objL3 == obj2) {
                    objL3 = new d6.a(0, activity, e1Var);
                    qVar.j0(objL3);
                }
                Function0 function02 = (Function0) objL3;
                boolean zH2 = qVar.h(activity) | qVar.f(e1Var) | qVar.f(a1Var) | qVar.h(obj);
                Object objL4 = qVar.L();
                if (zH2 || objL4 == obj2) {
                    objL4 = new d6.b(activity, obj, e1Var, a1Var, 0);
                    qVar.j0(objL4);
                }
                i.e.c(function02, (Function0) objL4, qVar, 0);
                qVar.q(true);
            } else {
                qVar.Z(-1561455320);
            }
            qVar.q(false);
        } else {
            qVar.T();
        }
        s1 s1VarS = qVar.s();
        if (s1VarS != null) {
            s1VarS.f6350d = new d6.c(isVisible, i8);
        }
    }

    public static final j4.b E(BackEvent backEvent) {
        Intrinsics.checkNotNullParameter(backEvent, "backEvent");
        float touchX = backEvent.getTouchX();
        float touchY = backEvent.getTouchY();
        return new j4.b(backEvent.getSwipeEdge(), backEvent.getProgress(), touchX, touchY, Build.VERSION.SDK_INT >= 36 ? backEvent.getFrameTimeMillis() : 0L);
    }

    public static final l F(String serialName, de.e original) {
        Intrinsics.checkNotNullParameter(serialName, "serialName");
        Intrinsics.checkNotNullParameter(original, "original");
        if (StringsKt.v(serialName)) {
            throw new IllegalArgumentException("Blank serial names are prohibited");
        }
        if (!serialName.equals(original.b())) {
            if (original.c() instanceof de.d) {
                u0.a(serialName);
            }
            return new l(serialName, original);
        }
        throw new IllegalArgumentException(("The name of the wrapped descriptor (" + serialName + ") cannot be the same as the name of the original descriptor (" + original.b() + ')').toString());
    }

    public static final void G(int i8, q qVar) {
        qVar.a0(414382727);
        if (qVar.Q(i8 & 1, i8 != 0)) {
            FillElement fillElement = androidx.compose.foundation.layout.c.f712c;
            f0 f0VarD = o.d(a1.c.f24d, false);
            int iHashCode = Long.hashCode(qVar.T);
            n1 n1VarL = qVar.l();
            p pVarB = i.e.B(fillElement, qVar);
            z1.k.f9365h.getClass();
            a0 a0Var = z1.j.f9357b;
            qVar.c0();
            if (qVar.S) {
                qVar.k(a0Var);
            } else {
                qVar.m0();
            }
            y.w(f0VarD, z1.j.f9360e, qVar);
            y.w(n1VarL, z1.j.f9359d, qVar);
            z1.i iVar = z1.j.f9361f;
            if (qVar.S || !Intrinsics.b(qVar.L(), Integer.valueOf(iHashCode))) {
                d.t(iHashCode, qVar, iHashCode, iVar);
            }
            y.w(pVarB, z1.j.f9358c, qVar);
            t5.d.f(i.e.H(fillElement, 1.4f, 1.4f), qVar, 48);
            t5.d.d(androidx.compose.foundation.layout.b.f709a.a(androidx.compose.foundation.layout.a.f(m.f50a, 24), a1.c.f30n), null, 0, qVar, 0);
            qVar.q(true);
        } else {
            qVar.T();
        }
        s1 s1VarS = qVar.s();
        if (s1VarS != null) {
            s1VarS.f6350d = new b6.i(i8, 2);
        }
    }

    public static final int H(float[] fArr) {
        int i8 = 0;
        if (fArr.length < 16) {
            return 0;
        }
        int i10 = (fArr[0] == 1.0f && fArr[1] == 0.0f && fArr[2] == 0.0f && fArr[4] == 0.0f && fArr[5] == 1.0f && fArr[6] == 0.0f && fArr[8] == 0.0f && fArr[9] == 0.0f && fArr[10] == 1.0f) ? 1 : 0;
        if (fArr[12] == 0.0f && fArr[13] == 0.0f && fArr[14] == 0.0f && fArr[15] == 1.0f) {
            i8 = 1;
        }
        return (i10 << 1) | i8;
    }

    public static final boolean I(d1.f fVar, long j8) {
        if (!fVar.f51d.f63t) {
            return false;
        }
        t tVar = g.s(fVar).J.f9271c;
        if (!tVar.T.f63t) {
            return false;
        }
        long J = tVar.J(0L);
        float fIntBitsToFloat = Float.intBitsToFloat((int) (J >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (J & 4294967295L));
        long j9 = fVar.f1957w;
        float f3 = ((int) (j9 >> 32)) + fIntBitsToFloat;
        float f10 = ((int) (j9 & 4294967295L)) + fIntBitsToFloat2;
        float fIntBitsToFloat3 = Float.intBitsToFloat((int) (j8 >> 32));
        if (fIntBitsToFloat > fIntBitsToFloat3 || fIntBitsToFloat3 > f3) {
            return false;
        }
        float fIntBitsToFloat4 = Float.intBitsToFloat((int) (j8 & 4294967295L));
        return fIntBitsToFloat2 <= fIntBitsToFloat4 && fIntBitsToFloat4 <= f10;
    }

    public static final boolean J(long j8) {
        return !u2.i.a(j8, 9223372034707292159L);
    }

    public static final p K(p pVar, float f3) {
        return f3 == 1.0f ? pVar : androidx.compose.ui.graphics.a.c(pVar, 0.0f, 0.0f, f3, null, 520187);
    }

    public static final de.f L(String serialName, a.a kind, de.e[] typeParameters, Function1 builder) {
        Intrinsics.checkNotNullParameter(serialName, "serialName");
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(typeParameters, "typeParameters");
        Intrinsics.checkNotNullParameter(builder, "builder");
        if (StringsKt.v(serialName)) {
            throw new IllegalArgumentException("Blank serial names are prohibited");
        }
        if (kind.equals(de.j.f2131g)) {
            throw new IllegalArgumentException("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
        }
        de.a aVar = new de.a(serialName);
        builder.invoke(aVar);
        return new de.f(serialName, kind, aVar.f2101c.size(), x.t(typeParameters), aVar);
    }

    public static void M(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static boolean O(String current, String str) {
        Intrinsics.checkNotNullParameter(current, "current");
        if (Intrinsics.b(current, str)) {
            return true;
        }
        if (current.length() != 0) {
            int i8 = 0;
            int i10 = 0;
            int i11 = 0;
            while (true) {
                if (i8 < current.length()) {
                    char cCharAt = current.charAt(i8);
                    int i12 = i11 + 1;
                    if (i11 == 0 && cCharAt != '(') {
                        break;
                    }
                    if (cCharAt != '(') {
                        if (cCharAt == ')' && i10 - 1 == 0 && i11 != current.length() - 1) {
                            break;
                        }
                    } else {
                        i10++;
                    }
                    i8++;
                    i11 = i12;
                } else if (i10 == 0) {
                    String strSubstring = current.substring(1, current.length() - 1);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
                    return Intrinsics.b(StringsKt.C(strSubstring).toString(), str);
                }
            }
        }
        return false;
    }

    public static final bd.b P(Enum[] entries) {
        Intrinsics.checkNotNullParameter(entries, "entries");
        return new bd.b(entries);
    }

    public static final boolean Q(long j8, long j9) {
        return j8 == j9;
    }

    public static final p4.e R(View view) {
        Intrinsics.checkNotNullParameter(view, "<this>");
        while (view != null) {
            Object tag = view.getTag(R.id.view_tree_saved_state_registry_owner);
            p4.e eVar = tag instanceof p4.e ? (p4.e) tag : null;
            if (eVar != null) {
                return eVar;
            }
            Object objI = a.a.I(view);
            view = objI instanceof View ? (View) objI : null;
        }
        return null;
    }

    public static final int S(s sVar, int i8) {
        boolean z5 = sVar.compareTo(s.f5302j) >= 0;
        boolean z10 = i8 == 1;
        if (z10 && z5) {
            return 3;
        }
        if (z5) {
            return 1;
        }
        return z10 ? 2 : 0;
    }

    public static final long T(long j8) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j8 >> 32)) / 2.0f;
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (j8 & 4294967295L)) / 2.0f;
        return (Float.floatToRawIntBits(fIntBitsToFloat2) & 4294967295L) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32);
    }

    public static final float U(Layout layout, int i8, Paint paint) {
        float fAbs;
        float width;
        float lineLeft = layout.getLineLeft(i8);
        k2.h hVar = k2.j.f4108a;
        if (layout.getEllipsisCount(i8) <= 0 || layout.getParagraphDirection(i8) != 1 || lineLeft >= 0.0f) {
            return 0.0f;
        }
        float fMeasureText = paint.measureText("…") + (layout.getPrimaryHorizontal(layout.getEllipsisStart(i8) + layout.getLineStart(i8)) - lineLeft);
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i8);
        if ((paragraphAlignment == null ? -1 : l2.d.f4819a[paragraphAlignment.ordinal()]) == 1) {
            fAbs = Math.abs(lineLeft);
            width = (layout.getWidth() - fMeasureText) / 2.0f;
        } else {
            fAbs = Math.abs(lineLeft);
            width = layout.getWidth() - fMeasureText;
        }
        return width + fAbs;
    }

    public static final float V(Layout layout, int i8, Paint paint) {
        float width;
        float width2;
        k2.h hVar = k2.j.f4108a;
        if (layout.getEllipsisCount(i8) <= 0) {
            return 0.0f;
        }
        if (layout.getParagraphDirection(i8) != -1 || layout.getWidth() >= layout.getLineRight(i8)) {
            return 0.0f;
        }
        float fMeasureText = paint.measureText("…") + (layout.getLineRight(i8) - layout.getPrimaryHorizontal(layout.getEllipsisStart(i8) + layout.getLineStart(i8)));
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i8);
        if ((paragraphAlignment != null ? l2.d.f4819a[paragraphAlignment.ordinal()] : -1) == 1) {
            width = layout.getWidth() - layout.getLineRight(i8);
            width2 = (layout.getWidth() - fMeasureText) / 2.0f;
        } else {
            width = layout.getWidth() - layout.getLineRight(i8);
            width2 = layout.getWidth() - fMeasureText;
        }
        return width - width2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v8, types: [java.util.Map] */
    public static final void X(Context context) {
        LinkedHashMap linkedHashMapB;
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(context, "context");
        File databasePath = context.getDatabasePath("androidx.work.workdb");
        Intrinsics.checkNotNullExpressionValue(databasePath, "context.getDatabasePath(WORK_DATABASE_NAME)");
        if (databasePath.exists()) {
            r.d().a(b5.p.f1105a, "Migrating WorkDatabase to the no-backup directory");
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(context, "context");
            File databasePath2 = context.getDatabasePath("androidx.work.workdb");
            Intrinsics.checkNotNullExpressionValue(databasePath2, "context.getDatabasePath(WORK_DATABASE_NAME)");
            Intrinsics.checkNotNullParameter(context, "context");
            File file = new File(b5.a.f1057a.a(context), "androidx.work.workdb");
            String[] strArr = b5.p.f1106b;
            int iA = o0.a(strArr.length);
            if (iA < 16) {
                iA = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(iA);
            for (String str : strArr) {
                linkedHashMap.put(new File(databasePath2.getPath() + str), new File(file.getPath() + str));
            }
            Pair pair = new Pair(databasePath2, file);
            Intrinsics.checkNotNullParameter(linkedHashMap, "<this>");
            Intrinsics.checkNotNullParameter(pair, "pair");
            if (linkedHashMap.isEmpty()) {
                linkedHashMapB = o0.b(pair);
            } else {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap(linkedHashMap);
                linkedHashMap2.put(databasePath2, file);
                linkedHashMapB = linkedHashMap2;
            }
            for (Map.Entry entry : linkedHashMapB.entrySet()) {
                File file2 = (File) entry.getKey();
                File file3 = (File) entry.getValue();
                if (file2.exists()) {
                    if (file3.exists()) {
                        r.d().g(b5.p.f1105a, "Over-writing contents of " + file3);
                    }
                    r.d().a(b5.p.f1105a, file2.renameTo(file3) ? "Migrated " + file2 + "to " + file3 : "Renaming " + file2 + " to " + file3 + " failed");
                }
            }
        }
    }

    public static final void Y(View view, p4.e eVar) {
        Intrinsics.checkNotNullParameter(view, "<this>");
        view.setTag(R.id.view_tree_saved_state_registry_owner, eVar);
    }

    public static void b0(EditorInfo editorInfo, CharSequence charSequence, int i8, int i10) {
        if (editorInfo.extras == null) {
            editorInfo.extras = new Bundle();
        }
        editorInfo.extras.putCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT", charSequence != null ? new SpannableStringBuilder(charSequence) : null);
        editorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD", i8);
        editorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END", i10);
    }

    public static final String e0(int i8, q qVar) {
        return ((Resources) qVar.j(a2.e1.f172c)).getString(i8);
    }

    public static final String f0(int i8, Object[] objArr, q qVar) {
        return ((Resources) qVar.j(a2.e1.f172c)).getString(i8, Arrays.copyOf(objArr, objArr.length));
    }

    public static String g0(long j8) {
        int i8 = (int) (j8 >> 32);
        int i10 = (int) (j8 & 4294967295L);
        if (Float.intBitsToFloat(i8) == Float.intBitsToFloat(i10)) {
            return "CornerRadius.circular(" + a.a.T(Float.intBitsToFloat(i8)) + ')';
        }
        return "CornerRadius.elliptical(" + a.a.T(Float.intBitsToFloat(i8)) + ", " + a.a.T(Float.intBitsToFloat(i10)) + ')';
    }

    public static final v0 h0(id.i iVar, b1 b1Var, oc.e factory, b4.c extras, q qVar) {
        z0 z0VarG;
        if (factory != null) {
            androidx.lifecycle.a1 store = b1Var.g();
            Intrinsics.checkNotNullParameter(store, "store");
            Intrinsics.checkNotNullParameter(factory, "factory");
            Intrinsics.checkNotNullParameter(extras, "extras");
            z0VarG = new z0(store, factory, extras);
        } else if (b1Var instanceof k) {
            androidx.lifecycle.a1 store2 = b1Var.g();
            x0 factory2 = ((k) b1Var).e();
            Intrinsics.checkNotNullParameter(store2, "store");
            Intrinsics.checkNotNullParameter(factory2, "factory");
            Intrinsics.checkNotNullParameter(extras, "extras");
            z0VarG = new z0(store2, factory2, extras);
        } else {
            z0VarG = f7.g.g(b1Var, null, 6);
        }
        return z0VarG.a(iVar);
    }

    public static void i0(Parcel parcel, int i8, Bundle bundle) {
        if (bundle == null) {
            return;
        }
        int iN0 = n0(parcel, i8);
        parcel.writeBundle(bundle);
        o0(parcel, iN0);
    }

    public static void j0(Parcel parcel, int i8, Parcelable parcelable, int i10) {
        if (parcelable == null) {
            return;
        }
        int iN0 = n0(parcel, i8);
        parcelable.writeToParcel(parcel, i10);
        o0(parcel, iN0);
    }

    public static void k0(Parcel parcel, int i8, String str) {
        if (str == null) {
            return;
        }
        int iN0 = n0(parcel, i8);
        parcel.writeString(str);
        o0(parcel, iN0);
    }

    public static void l0(Parcel parcel, int i8, Parcelable[] parcelableArr, int i10) {
        if (parcelableArr == null) {
            return;
        }
        int iN0 = n0(parcel, i8);
        parcel.writeInt(parcelableArr.length);
        for (Parcelable parcelable : parcelableArr) {
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                int iDataPosition = parcel.dataPosition();
                parcel.writeInt(1);
                int iDataPosition2 = parcel.dataPosition();
                parcelable.writeToParcel(parcel, i10);
                int iDataPosition3 = parcel.dataPosition();
                parcel.setDataPosition(iDataPosition);
                parcel.writeInt(iDataPosition3 - iDataPosition2);
                parcel.setDataPosition(iDataPosition3);
            }
        }
        o0(parcel, iN0);
    }

    public static void m0(Parcel parcel, int i8, List list) {
        if (list == null) {
            return;
        }
        int iN0 = n0(parcel, i8);
        int size = list.size();
        parcel.writeInt(size);
        for (int i10 = 0; i10 < size; i10++) {
            Parcelable parcelable = (Parcelable) list.get(i10);
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                int iDataPosition = parcel.dataPosition();
                parcel.writeInt(1);
                int iDataPosition2 = parcel.dataPosition();
                parcelable.writeToParcel(parcel, 0);
                int iDataPosition3 = parcel.dataPosition();
                parcel.setDataPosition(iDataPosition);
                parcel.writeInt(iDataPosition3 - iDataPosition2);
                parcel.setDataPosition(iDataPosition3);
            }
        }
        o0(parcel, iN0);
    }

    public static int n0(Parcel parcel, int i8) {
        parcel.writeInt(i8 | (-65536));
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    public static void o0(Parcel parcel, int i8) {
        int iDataPosition = parcel.dataPosition();
        parcel.setDataPosition(i8 - 4);
        parcel.writeInt(iDataPosition - i8);
        parcel.setDataPosition(iDataPosition);
    }

    public static void p0(Parcel parcel, int i8, int i10) {
        parcel.writeInt(i8 | (i10 << 16));
    }

    @Override // ee.a
    public ee.b A(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return o(descriptor.j(i8));
    }

    @Override // ee.b
    public double B() {
        N();
        throw null;
    }

    public void N() {
        throw new be.e(d0.a(getClass()) + " can't retrieve untyped values");
    }

    public abstract void W();

    @Override // ee.b
    public Object a(be.a deserializer) {
        Intrinsics.checkNotNullParameter(deserializer, "deserializer");
        return deserializer.a(this);
    }

    public abstract void a0(boolean z5);

    @Override // ee.b
    public abstract long b();

    @Override // ee.a
    public short c(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return w();
    }

    public abstract void c0();

    @Override // ee.a
    public char d(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return j();
    }

    public abstract void d0();

    @Override // ee.a
    public byte e(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return t();
    }

    public void f(de.e descriptor) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
    }

    @Override // ee.a
    public long g(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return b();
    }

    @Override // ee.b
    public boolean h() {
        N();
        throw null;
    }

    @Override // ee.b
    public boolean i() {
        return true;
    }

    @Override // ee.b
    public char j() {
        N();
        throw null;
    }

    @Override // ee.a
    public boolean k(de.e descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return h();
    }

    @Override // ee.a
    public Object l(de.e descriptor, Boolean bool) {
        fe.f deserializer = fe.f.f2494a;
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        Intrinsics.checkNotNullParameter(deserializer, "deserializer");
        fe.f.f2495b.getClass();
        if (!i()) {
            return null;
        }
        Intrinsics.checkNotNullParameter(deserializer, "deserializer");
        return a(deserializer);
    }

    @Override // ee.b
    public ee.a m(de.e descriptor) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return this;
    }

    @Override // ee.a
    public double n(r0 descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return B();
    }

    @Override // ee.b
    public ee.b o(de.e descriptor) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return this;
    }

    @Override // ee.b
    public abstract int q();

    @Override // ee.a
    public float s(de.e descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return y();
    }

    @Override // ee.b
    public abstract byte t();

    public Object u(de.e descriptor, int i8, be.a deserializer, Object obj) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        Intrinsics.checkNotNullParameter(deserializer, "deserializer");
        Intrinsics.checkNotNullParameter(deserializer, "deserializer");
        return a(deserializer);
    }

    @Override // ee.a
    public String v(de.e descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return x();
    }

    @Override // ee.b
    public abstract short w();

    @Override // ee.b
    public String x() {
        N();
        throw null;
    }

    @Override // ee.b
    public float y() {
        N();
        throw null;
    }

    @Override // ee.a
    public int z(de.e descriptor, int i8) {
        Intrinsics.checkNotNullParameter(descriptor, "descriptor");
        return q();
    }

    public void Z(boolean z5) {
    }
}
