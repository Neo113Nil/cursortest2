package g6;

import a1.p;
import android.app.Activity;
import android.os.Build;
import androidx.lifecycle.b1;
import androidx.lifecycle.k;
import b6.h;
import c6.f;
import c6.t;
import e.i;
import f4.l;
import id.d0;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.z;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import o0.a1;
import o0.q;
import o0.s1;
import o0.y;
import sd.m;
import w0.e;
import x0.g;
import x0.j;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final e f2776a = new e(1602447806, false, new f(6));

    /* renamed from: b, reason: collision with root package name */
    public static final e f2777b = new e(404938770, false, new f(7));

    public static final void a(p pVar, q qVar, int i8) {
        qVar.a0(-1975520836);
        int i10 = 2;
        final int i11 = 0;
        final int i12 = 1;
        if (qVar.Q(i8 & 1, (i8 & 3) != 2)) {
            b1 b1VarA = c4.a.a(qVar);
            if (b1VarA == null) {
                throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
            }
            final h6.d dVar = ((h6.a) o7.a.h0(d0.a(h6.a.class), b1VarA, r1.c.g(b1VarA, qVar), b1VarA instanceof k ? ((k) b1VarA).f() : b4.a.f1052b, qVar)).f3015b;
            a1 a1VarK = y.k(dVar.f3031f, qVar);
            a1 a1VarK2 = y.k(dVar.f3033h, qVar);
            Object[] objArr = new Object[0];
            Object objL = qVar.L();
            Object obj = o0.k.f6241a;
            if (objL == obj) {
                objL = new h(13);
                qVar.j0(objL);
            }
            a1 a1Var = (a1) j.c(objArr, (Function0) objL, qVar);
            yc.a aVar = null;
            if (Build.VERSION.SDK_INT >= 33) {
                qVar.Z(1196034535);
                boolean zF = qVar.f(a1Var);
                Object objL2 = qVar.L();
                if (zF || objL2 == obj) {
                    objL2 = new c6.q(a1Var, 1);
                    qVar.j0(objL2);
                }
                n6.b bVarR = a.a.R("android.permission.POST_NOTIFICATIONS", (Function1) objL2, qVar);
                Boolean bool = (Boolean) a1VarK2.getValue();
                bool.getClass();
                boolean zF2 = qVar.f(a1VarK2) | qVar.f(bVarR);
                Object objL3 = qVar.L();
                if (zF2 || objL3 == obj) {
                    objL3 = new t(bVarR, a1VarK2, null);
                    qVar.j0(objL3);
                }
                y.f(bool, (Function2) objL3, qVar);
                qVar.q(false);
            } else {
                qVar.Z(1196351727);
                Unit unit = Unit.f4213a;
                boolean zF3 = qVar.f(a1Var);
                Object objL4 = qVar.L();
                if (zF3 || objL4 == obj) {
                    objL4 = new c(a1Var, aVar, i11);
                    qVar.j0(objL4);
                }
                y.f(unit, (Function2) objL4, qVar);
                qVar.q(false);
            }
            Unit unit2 = Unit.f4213a;
            boolean zH = qVar.h(dVar);
            Object objL5 = qVar.L();
            if (zH || objL5 == obj) {
                objL5 = new d6.d(dVar, aVar, i10);
                qVar.j0(objL5);
            }
            y.f(unit2, (Function2) objL5, qVar);
            if (((Boolean) a1VarK.getValue()).booleanValue()) {
                qVar.Z(1196627906);
                boolean zH2 = qVar.h(dVar);
                Object objL6 = qVar.L();
                if (zH2 || objL6 == obj) {
                    objL6 = new Function0() { // from class: g6.a
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            switch (i11) {
                                case 0:
                                    m mVar = dVar.f3035j;
                                    if (mVar != null) {
                                        mVar.P(Unit.f4213a);
                                    }
                                    break;
                                default:
                                    f4.h hVar = dVar.f3028c;
                                    Intrinsics.checkNotNullParameter(hVar, "<this>");
                                    if (!hVar.isEmpty()) {
                                        hVar.remove(z.e(hVar));
                                    }
                                    break;
                            }
                            return Unit.f4213a;
                        }
                    };
                    qVar.j0(objL6);
                }
                t5.d.e((Function0) objL6, qVar, 0);
            } else {
                qVar.Z(1194472166);
            }
            qVar.q(false);
            f4.h hVar = dVar.f3028c;
            qVar.Z(1967008021);
            Object[] objArr2 = new Object[0];
            Object objL7 = qVar.L();
            if (objL7 == obj) {
                objL7 = new k4.a(26);
                qVar.j0(objL7);
            }
            x0.c cVar = (x0.c) j.d(objArr2, x0.c.f8476e, (Function0) objL7, qVar, 384);
            cVar.f8479c = (x0.e) qVar.j(g.f8484a);
            qVar.q(false);
            boolean zF4 = qVar.f(cVar);
            Object objL8 = qVar.L();
            int i13 = 3;
            if (zF4 || objL8 == obj) {
                objL8 = new f4.m(new l(cVar, 0), new e(-1320822745, true, new ae.b(i13, cVar)));
                qVar.j0(objL8);
            }
            f4.m mVar = (f4.m) objL8;
            b1 b1VarA2 = c4.a.a(qVar);
            if (b1VarA2 == null) {
                throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
            }
            Activity activity = (Activity) qVar.j(i.f2154a);
            boolean zH3 = qVar.h(activity);
            Object objL9 = qVar.L();
            if (zH3 || objL9 == obj) {
                objL9 = new e4.e(activity, 0);
                qVar.j0(objL9);
            }
            Function0 function0 = (Function0) objL9;
            boolean zF5 = qVar.f(y.u(function0, qVar)) | qVar.f(b1VarA2);
            Object objL10 = qVar.L();
            if (zF5 || objL10 == obj) {
                androidx.lifecycle.a1 a1VarG = b1VarA2.g();
                objL10 = new e4.d(new b6.l(6, function0, a1VarG), new e(-1481256515, true, new ae.b(i10, a1VarG)));
                qVar.j0(objL10);
            }
            List listF = z.f(mVar, (e4.d) objL10);
            qVar.Z(-99934026);
            f4.f fVar = new f4.f(0);
            f4.f.a(fVar, fVar, r5.c.INSTANCE, w0.k.d(1775080726, new b(a1Var, i11), qVar));
            f4.f.a(fVar, fVar, r5.d.INSTANCE, f2776a);
            f4.f.a(fVar, fVar, r5.b.INSTANCE, f2777b);
            ae.c cVar2 = new ae.c(i13, fVar);
            qVar.q(false);
            boolean zH4 = qVar.h(dVar);
            Object objL11 = qVar.L();
            if (zH4 || objL11 == obj) {
                objL11 = new Function0() { // from class: g6.a
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        switch (i12) {
                            case 0:
                                m mVar2 = dVar.f3035j;
                                if (mVar2 != null) {
                                    mVar2.P(Unit.f4213a);
                                }
                                break;
                            default:
                                f4.h hVar2 = dVar.f3028c;
                                Intrinsics.checkNotNullParameter(hVar2, "<this>");
                                if (!hVar2.isEmpty()) {
                                    hVar2.remove(z.e(hVar2));
                                }
                                break;
                        }
                        return Unit.f4213a;
                    }
                };
                qVar.j0(objL11);
            }
            a.a.g(hVar, pVar, null, (Function0) objL11, listF, null, null, null, null, cVar2, qVar, 48);
        } else {
            qVar.T();
        }
        s1 s1VarS = qVar.s();
        if (s1VarS != null) {
            s1VarS.f6350d = new c0.l(pVar, i8, i12);
        }
    }
}
