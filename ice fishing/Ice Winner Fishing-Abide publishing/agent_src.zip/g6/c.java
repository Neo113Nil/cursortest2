package g6;

import ad.i;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import o0.a1;
import sd.v;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class c extends i implements Function2 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2774d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a1 f2775e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c(a1 a1Var, yc.a aVar, int i8) {
        super(2, aVar);
        this.f2774d = i8;
        this.f2775e = a1Var;
    }

    @Override // ad.a
    public final yc.a create(Object obj, yc.a aVar) {
        switch (this.f2774d) {
            case 0:
                return new c(this.f2775e, aVar, 0);
            default:
                return new c(this.f2775e, aVar, 1);
        }
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        v vVar = (v) obj;
        yc.a aVar = (yc.a) obj2;
        switch (this.f2774d) {
        }
        return ((c) create(vVar, aVar)).invokeSuspend(Unit.f4213a);
    }

    @Override // ad.a
    public final Object invokeSuspend(Object obj) {
        int i8 = this.f2774d;
        a1 a1Var = this.f2775e;
        switch (i8) {
            case 0:
                zc.a aVar = zc.a.f9574d;
                r1.c.r(obj);
                if (!((Boolean) a1Var.getValue()).booleanValue()) {
                    a1Var.setValue(Boolean.TRUE);
                }
                break;
            default:
                zc.a aVar2 = zc.a.f9574d;
                r1.c.r(obj);
                if (!((Boolean) a1Var.getValue()).booleanValue()) {
                    a1Var.setValue(Boolean.TRUE);
                }
                break;
        }
        return Unit.f4213a;
    }
}
