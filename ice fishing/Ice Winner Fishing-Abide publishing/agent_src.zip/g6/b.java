package g6;

import androidx.lifecycle.p;
import f4.i;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import o0.a1;
import o0.k;
import o0.q;
import o0.y;
import z3.e;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final /* synthetic */ class b implements hd.c {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2772d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a1 f2773e;

    public /* synthetic */ b(a1 a1Var, int i8) {
        this.f2772d = i8;
        this.f2773e = a1Var;
    }

    @Override // hd.c
    public final Object a(Object obj, Object obj2, Object obj3) {
        p pVar;
        switch (this.f2772d) {
            case 0:
                r5.c it = (r5.c) obj;
                q qVar = (q) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                Intrinsics.checkNotNullParameter(it, "it");
                if (qVar.Q(iIntValue & 1, (iIntValue & 17) != 16)) {
                    o7.a.D(this.f2773e, qVar, 0);
                } else {
                    qVar.T();
                }
                break;
            default:
                i iVar = (i) obj;
                q qVar2 = (q) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                if ((iIntValue2 & 6) == 0) {
                    iIntValue2 |= qVar2.f(iVar) ? 4 : 2;
                }
                if (qVar2.Q(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                    List list = (List) this.f2773e.getValue();
                    boolean z5 = (iIntValue2 & 14) == 4;
                    Object objL = qVar2.L();
                    if (z5 || objL == k.f6241a) {
                        objL = new ae.c(7, iVar);
                        qVar2.j0(objL);
                    }
                    Function1 function1 = (Function1) objL;
                    if (list instanceof RandomAccess) {
                        int size = list.size();
                        for (int i8 = 0; i8 < size; i8++) {
                            if (((Boolean) function1.invoke(list.get(i8))).booleanValue()) {
                                pVar = p.k;
                            }
                        }
                        pVar = p.f867i;
                    } else {
                        if (list == null || !list.isEmpty()) {
                            Iterator it2 = list.iterator();
                            while (it2.hasNext()) {
                                if (((Boolean) function1.invoke(it2.next())).booleanValue()) {
                                    pVar = p.k;
                                }
                            }
                        }
                        pVar = p.f867i;
                    }
                    y.a(e.f9534a.a(p6.d.q(pVar, qVar2)), w0.k.d(-1713684244, new e4.b(iVar, 3, (byte) 0), qVar2), qVar2, 56);
                } else {
                    qVar2.T();
                }
                break;
        }
        return Unit.f4213a;
    }
}
