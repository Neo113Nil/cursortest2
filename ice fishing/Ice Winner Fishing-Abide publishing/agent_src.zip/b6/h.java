package b6;

import c0.d0;
import com.appsflyer.attribution.RequestError;
import com.devsisters.cook.data.p000native.NativeStoreManager;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import fe.n0;
import fe.p0;
import ge.a0;
import ge.t;
import ge.w;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.UUID;
import kotlin.Unit;
import kotlin.collections.x;
import kotlin.jvm.functions.Function0;
import o0.b0;
import o0.e1;
import o0.u2;
import o0.y;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final /* synthetic */ class h implements Function0 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1169d;

    public /* synthetic */ h(int i8) {
        this.f1169d = i8;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        int i8 = 0;
        switch (this.f1169d) {
            case 0:
                return Unit.f4213a;
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                return new d0(0);
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                b0 b0Var = c4.a.f1480a;
                return null;
            case 3:
                return Unit.f4213a;
            case 4:
                return Unit.f4213a;
            case 5:
                return new e1(0.0f);
            case 6:
                return y.r(Boolean.TRUE);
            case 7:
                return UUID.randomUUID().toString();
            case 8:
                return Unit.f4213a;
            case 9:
                b0 b0Var2 = e.j.f2155a;
                return null;
            case 10:
                b0 b0Var3 = e.k.f2156a;
                return null;
            case RequestError.STOP_TRACKING /* 11 */:
                u2 u2Var = f0.c.f2309a;
                return null;
            case 12:
                return n0.c(new ArrayList(0));
            case 13:
                return y.r(Boolean.FALSE);
            case 14:
                return ge.d0.f2840b;
            case 15:
                return w.f2864b;
            case 16:
                return t.f2862b;
            case 17:
                return a0.f2834b;
            case 18:
                return ge.g.f2846b;
            case 19:
                ld.d.f5040d.getClass();
                return Integer.valueOf(ld.d.f5041e.a().nextInt(2147418112) + 65536);
            case 20:
                b0 b0Var4 = h0.a.f2882a;
                return null;
            case 21:
                return h0.c.f2886b;
            case 22:
                return new HashSet();
            case 23:
                throw new IllegalStateException("Unexpected access to LocalNavAnimatedContentScope. You should only access LocalNavAnimatedContentScope inside a NavEntry passed to NavDisplay.");
            case 24:
                return y.r(Boolean.FALSE);
            case 25:
                return x.t(NativeStoreManager.getExceptions());
            case 26:
                String[] schemeMap = NativeStoreManager.getSchemeMap();
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                int iA = cd.c.a(0, schemeMap.length - 1, 2);
                if (iA >= 0) {
                    while (true) {
                        int i10 = i8 + 1;
                        if (i10 < schemeMap.length) {
                            linkedHashMap.put(schemeMap[i8], schemeMap[i10]);
                        }
                        if (i8 != iA) {
                            i8 += 2;
                        }
                    }
                }
                return linkedHashMap;
            case 27:
                return Unit.f4213a;
            case 28:
                return Unit.f4213a;
            default:
                return Unit.f4213a;
        }
    }

    public /* synthetic */ h(p0 p0Var) {
        this.f1169d = 12;
    }
}
