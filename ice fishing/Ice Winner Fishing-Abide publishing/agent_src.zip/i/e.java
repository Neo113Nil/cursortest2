package i;

import a1.k;
import a1.l;
import a1.m;
import a1.p;
import a2.e1;
import a2.v0;
import a5.a0;
import a5.z;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.icu.text.DecimalFormatSymbols;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import android.view.ViewStructure;
import android.view.Window;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.view.translation.TranslationResponseValue;
import android.view.translation.ViewTranslationResponse;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.lifecycle.o;
import androidx.lifecycle.p0;
import androidx.lifecycle.u;
import androidx.lifecycle.w;
import b1.n;
import c0.f1;
import com.appsflyer.attribution.RequestError;
import com.devsisters.cook.data.p000native.NativeStoreManager;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import g2.g;
import g2.h;
import g2.i;
import g2.t;
import he.v;
import i.e;
import id.d0;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.x;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import m2.s;
import n1.f;
import o0.a1;
import o0.f0;
import o0.i2;
import o0.q;
import o0.s1;
import o0.y;
import t.e0;
import t.i0;
import x0.j;
import z1.h0;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f3301b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f3302c = 0;

    /* renamed from: d, reason: collision with root package name */
    public static f f3303d;

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f3304a;

    public /* synthetic */ e(int i8) {
        this.f3304a = i8;
    }

    public static final p A(p pVar, q qVar) {
        if (pVar.a(k.f47d)) {
            return pVar;
        }
        qVar.U(1219399079, 0, null, null);
        p pVar2 = (p) pVar.b(m.f50a, new l(0, qVar));
        qVar.q(false);
        return pVar2;
    }

    public static final p B(p pVar, q qVar) {
        qVar.Z(439770924);
        p pVarA = A(pVar, qVar);
        qVar.q(false);
        return pVarA;
    }

    public static MappedByteBuffer C(Context context, Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor;
        try {
            parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", null);
        } catch (IOException unused) {
        }
        if (parcelFileDescriptorOpenFileDescriptor == null) {
            if (parcelFileDescriptorOpenFileDescriptor != null) {
                parcelFileDescriptorOpenFileDescriptor.close();
                return null;
            }
            return null;
        }
        try {
            FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
            try {
                FileChannel channel = fileInputStream.getChannel();
                MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                fileInputStream.close();
                parcelFileDescriptorOpenFileDescriptor.close();
                return map;
            } finally {
            }
        } finally {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:113:0x029b  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x034f  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0352  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x0360  */
    /* JADX WARN: Removed duplicated region for block: B:174:0x0366  */
    /* JADX WARN: Removed duplicated region for block: B:185:0x03ab  */
    /* JADX WARN: Removed duplicated region for block: B:227:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x016d A[PHI: r20 r21 r22 r23 r24 r25 r26 r27 r28
      0x016d: PHI (r20v6 b1.c) = (r20v5 b1.c), (r20v7 b1.c) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r21v6 boolean) = (r21v5 boolean), (r21v7 boolean) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r22v13 i2.a) = (r22v12 i2.a), (r22v14 i2.a) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r23v6 b1.m) = (r23v5 b1.m), (r23v7 b1.m) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r24v6 java.lang.Boolean) = (r24v5 java.lang.Boolean), (r24v7 java.lang.Boolean) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r25v11 g2.g) = (r25v10 g2.g), (r25v12 g2.g) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r26v6 boolean) = (r26v5 boolean), (r26v7 boolean) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r27v6 java.lang.Integer) = (r27v5 java.lang.Integer), (r27v7 java.lang.Integer) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]
      0x016d: PHI (r28v12 j2.e) = (r28v11 j2.e), (r28v13 j2.e) binds: [B:10:0x004e, B:62:0x016b] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void E(ViewStructure viewStructure, h0 h0Var, AutofillId autofillId, String str, h2.b bVar) {
        int i8;
        long j8;
        long j9;
        char c10;
        long j10;
        i2.a aVar;
        g gVar;
        j2.e eVar;
        b1.c cVar;
        boolean z5;
        b1.m mVar;
        Boolean bool;
        boolean z10;
        Integer num;
        Integer num2;
        List list;
        boolean z11;
        boolean z12;
        String strV;
        String[] strArrD;
        String[] strArrD2;
        i0 i0Var;
        long[] jArr;
        Object[] objArr;
        Integer num3;
        long[] jArr2;
        Object[] objArr2;
        i0 i0Var2;
        i2.a aVar2;
        g gVar2;
        j2.e eVar2;
        int i10;
        Integer num4 = 1;
        t tVar = g2.q.f2723a;
        t tVar2 = h.f2659a;
        i iVarU = h0Var.u();
        int i11 = 8;
        if (iVarU == null || (i0Var2 = iVarU.f2684d) == null) {
            i8 = 2;
            j8 = 128;
            j9 = 255;
            c10 = 7;
            j10 = -9187201950435737472L;
            aVar = null;
            gVar = null;
            eVar = null;
            cVar = null;
            z5 = false;
            mVar = null;
            bool = null;
            z10 = false;
            num = null;
        } else {
            j8 = 128;
            Object[] objArr3 = i0Var2.f7267b;
            Object[] objArr4 = i0Var2.f7268c;
            long[] jArr3 = i0Var2.f7266a;
            j9 = 255;
            int length = jArr3.length - 2;
            i8 = 2;
            if (length >= 0) {
                int i12 = 0;
                cVar = null;
                z5 = false;
                aVar2 = null;
                mVar = null;
                bool = null;
                gVar2 = null;
                z10 = false;
                num = null;
                eVar2 = null;
                c10 = 7;
                while (true) {
                    long j11 = jArr3[i12];
                    j10 = -9187201950435737472L;
                    if ((((~j11) << 7) & j11 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i13 = 8 - ((~(i12 - length)) >>> 31);
                        int i14 = 0;
                        while (i14 < i13) {
                            if ((j11 & 255) < 128) {
                                int i15 = (i12 << 3) + i14;
                                Object obj = objArr3[i15];
                                Object obj2 = objArr4[i15];
                                t tVar3 = (t) obj;
                                i10 = i11;
                                if (Intrinsics.b(tVar3, g2.q.f2739r)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type androidx.compose.ui.autofill.ContentDataType");
                                    cVar = (b1.c) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.f2723a)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                                    CharSequence charSequence = (String) CollectionsKt.firstOrNull((List) obj2);
                                    if (charSequence != null) {
                                        viewStructure.setContentDescription(charSequence);
                                    }
                                } else if (Intrinsics.b(tVar3, g2.q.f2738q)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type androidx.compose.ui.autofill.ContentType");
                                    mVar = (b1.m) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.E)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type androidx.compose.ui.text.AnnotatedString");
                                    eVar2 = (j2.e) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.k)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type kotlin.Boolean");
                                    viewStructure.setFocused(((Boolean) obj2).booleanValue());
                                } else if (Intrinsics.b(tVar3, g2.q.L)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type kotlin.Int");
                                    num = (Integer) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.I)) {
                                    z10 = true;
                                } else if (Intrinsics.b(tVar3, g2.q.f2745x)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type androidx.compose.ui.semantics.Role");
                                    gVar2 = (g) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.G)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type kotlin.Boolean");
                                    bool = (Boolean) obj2;
                                } else if (Intrinsics.b(tVar3, g2.q.H)) {
                                    Intrinsics.d(obj2, "null cannot be cast to non-null type androidx.compose.ui.state.ToggleableState");
                                    aVar2 = (i2.a) obj2;
                                } else if (Intrinsics.b(tVar3, h.f2660b)) {
                                    viewStructure.setClickable(true);
                                } else if (Intrinsics.b(tVar3, h.f2661c)) {
                                    viewStructure.setLongClickable(true);
                                } else if (Intrinsics.b(tVar3, h.f2677t)) {
                                    viewStructure.setFocusable(true);
                                } else if (Intrinsics.b(tVar3, h.f2667i)) {
                                    z5 = true;
                                }
                            } else {
                                i10 = i11;
                            }
                            j11 >>= i10;
                            i14++;
                            i11 = i10;
                        }
                        if (i13 != i11) {
                            break;
                        }
                        if (i12 == length) {
                            break;
                        }
                        i12++;
                        i11 = 8;
                    }
                }
            } else {
                c10 = 7;
                j10 = -9187201950435737472L;
                cVar = null;
                z5 = false;
                aVar2 = null;
                mVar = null;
                bool = null;
                gVar2 = null;
                z10 = false;
                num = null;
                eVar2 = null;
            }
            aVar = aVar2;
            gVar = gVar2;
            eVar = eVar2;
        }
        i iVarU2 = h0Var.u();
        if (iVarU2 != null && iVarU2.f2686i && !iVarU2.f2687j) {
            iVarU2 = iVarU2.a();
            e0 e0Var = new e0(((q0.e) ((q0.b) h0Var.l()).f6726e).f6736i);
            e0Var.b(h0Var.l());
            while (e0Var.h()) {
                h0 h0Var2 = (h0) e0Var.j(e0Var.f7239b - 1);
                i iVarU3 = h0Var2.u();
                if (iVarU3 != null && !iVarU3.f2686i) {
                    iVarU2.e(iVarU3);
                    if (!iVarU3.f2687j) {
                        e0Var.b(h0Var2.l());
                    }
                }
            }
        }
        if (iVarU2 == null || (i0Var = iVarU2.f2684d) == null) {
            num2 = num4;
            list = null;
        } else {
            Object[] objArr5 = i0Var.f7267b;
            Object[] objArr6 = i0Var.f7268c;
            long[] jArr4 = i0Var.f7266a;
            int length2 = jArr4.length - 2;
            if (length2 >= 0) {
                int i16 = 0;
                list = null;
                while (true) {
                    long j12 = jArr4[i16];
                    if ((((~j12) << c10) & j12 & j10) != j10) {
                        int i17 = 8 - ((~(i16 - length2)) >>> 31);
                        int i18 = 0;
                        while (i18 < i17) {
                            if ((j12 & j9) < j8) {
                                int i19 = (i16 << 3) + i18;
                                Object obj3 = objArr5[i19];
                                num3 = num4;
                                Object obj4 = objArr6[i19];
                                jArr2 = jArr4;
                                t tVar4 = (t) obj3;
                                objArr2 = objArr5;
                                if (Intrinsics.b(tVar4, g2.q.f2731i)) {
                                    viewStructure.setEnabled(false);
                                } else if (Intrinsics.b(tVar4, g2.q.A)) {
                                    Intrinsics.d(obj4, "null cannot be cast to non-null type kotlin.collections.List<androidx.compose.ui.text.AnnotatedString>");
                                    list = (List) obj4;
                                }
                            } else {
                                num3 = num4;
                                jArr2 = jArr4;
                                objArr2 = objArr5;
                            }
                            j12 >>= 8;
                            i18++;
                            jArr4 = jArr2;
                            objArr5 = objArr2;
                            num4 = num3;
                        }
                        num2 = num4;
                        jArr = jArr4;
                        objArr = objArr5;
                        if (i17 != 8) {
                            break;
                        }
                    } else {
                        num2 = num4;
                        jArr = jArr4;
                        objArr = objArr5;
                    }
                    if (i16 == length2) {
                        break;
                    }
                    i16++;
                    jArr4 = jArr;
                    objArr5 = objArr;
                    num4 = num2;
                }
            }
        }
        Integer numValueOf = Integer.valueOf(h0Var.f9323e);
        if (h0Var.r() == null) {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : -1;
        viewStructure.setAutofillId(autofillId, iIntValue);
        viewStructure.setId(iIntValue, str, null, null);
        Integer numValueOf2 = (cVar == null && !z5) ? aVar != null ? Integer.valueOf(i8) : null : num2;
        if (numValueOf2 != null) {
            viewStructure.setAutofillType(numValueOf2.intValue());
        }
        if (mVar != null && (strArrD2 = a.a.D(mVar)) != null) {
            viewStructure.setAutofillHints(strArrD2);
        }
        bVar.f2970a.l(h0Var.f9323e, new n(0, viewStructure));
        if (bool != null) {
            viewStructure.setSelected(bool.booleanValue());
        }
        if (aVar != null) {
            viewStructure.setCheckable(true);
            viewStructure.setChecked(aVar == i2.a.f3388d);
        } else if (bool != null && (gVar == null || gVar.f2658a != 4)) {
            viewStructure.setCheckable(true);
            viewStructure.setChecked(bool.booleanValue());
        }
        b1.m.f981a.getClass();
        String str2 = (String) x.n(a.a.D(b1.l.f980b));
        if (mVar != null && (strArrD = a.a.D(mVar)) != null) {
            boolean zM = x.m(strArrD, str2);
            z11 = true;
            boolean z13 = zM;
            z12 = (!z10 || z13) ? z11 : false;
            if (z12) {
                viewStructure.setDataIsSensitive(true);
            }
            viewStructure.setVisibility(h0Var.J.f9272d.L0() ? 4 : 0);
            if (list != null) {
                int size = list.size();
                String strM = "";
                for (int i20 = 0; i20 < size; i20++) {
                    j2.e eVar3 = (j2.e) list.get(i20);
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(strM);
                    strM = a1.d.m(sb2, eVar3.f3720e, '\n');
                }
                viewStructure.setText(strM);
                viewStructure.setClassName("android.widget.TextView");
            }
            if (((q0.b) h0Var.l()).isEmpty() && gVar != null && (strV = v0.v(gVar.f2658a)) != null) {
                viewStructure.setClassName(strV);
            }
            if (z5) {
                return;
            }
            viewStructure.setClassName("android.widget.EditText");
            if (Build.VERSION.SDK_INT >= 28 && num != null) {
                viewStructure.setMaxTextLength(num.intValue());
            }
            if (eVar != null) {
                viewStructure.setAutofillValue(AutofillValue.forText(eVar.f3720e));
            }
            if (z12) {
                viewStructure.setInputType(129);
                return;
            }
            return;
        }
        z11 = true;
        if (z10) {
        }
        if (z12) {
        }
        viewStructure.setVisibility(h0Var.J.f9272d.L0() ? 4 : 0);
        if (list != null) {
        }
        if (((q0.b) h0Var.l()).isEmpty()) {
            viewStructure.setClassName(strV);
        }
        if (z5) {
        }
    }

    public static final void F(i2 i2Var, o0.c cVar, int i8) {
        while (true) {
            int i10 = i2Var.f6232v;
            if (i8 > i10 && i8 < i2Var.f6231u) {
                return;
            }
            if (i10 == 0 && i8 == 0) {
                return;
            }
            i2Var.N();
            if (i2Var.x(i2Var.f6232v)) {
                cVar.m();
            }
            i2Var.j();
        }
    }

    public static final e.l G(e eVar, Function1 function1, q qVar) {
        Object bVar;
        e eVar2;
        y.u(eVar, qVar);
        a1 a1VarU = y.u(function1, qVar);
        Object[] objArr = new Object[0];
        Object objL = qVar.L();
        Object obj = o0.k.f6241a;
        if (objL == obj) {
            objL = new b6.h(7);
            qVar.j0(objL);
        }
        String str = (String) j.c(objArr, (Function0) objL, qVar);
        h.d dVar = (h.d) qVar.j(e.j.f2155a);
        if (dVar == null) {
            qVar.Z(1213380307);
            Object baseContext = (Context) qVar.j(e1.f171b);
            while (true) {
                if (!(baseContext instanceof ContextWrapper)) {
                    baseContext = null;
                    break;
                }
                if (baseContext instanceof h.d) {
                    break;
                }
                baseContext = ((ContextWrapper) baseContext).getBaseContext();
            }
            dVar = (h.d) baseContext;
        } else {
            qVar.Z(1213379439);
        }
        qVar.q(false);
        if (dVar == null) {
            throw new IllegalStateException("No ActivityResultRegistryOwner was provided via LocalActivityResultRegistryOwner");
        }
        d.j jVar = ((d.k) dVar).f1909n;
        Object objL2 = qVar.L();
        if (objL2 == obj) {
            objL2 = new e.a();
            qVar.j0(objL2);
        }
        e.a aVar = (e.a) objL2;
        Object objL3 = qVar.L();
        if (objL3 == obj) {
            objL3 = new e.l(aVar);
            qVar.j0(objL3);
        }
        e.l lVar = (e.l) objL3;
        boolean zH = qVar.h(aVar) | qVar.h(jVar) | qVar.f(str) | qVar.h(eVar) | qVar.f(a1VarU);
        Object objL4 = qVar.L();
        if (zH || objL4 == obj) {
            eVar2 = eVar;
            bVar = new e.b(aVar, jVar, str, eVar2, a1VarU);
            qVar.j0(bVar);
        } else {
            bVar = objL4;
            eVar2 = eVar;
        }
        Function1 function12 = (Function1) bVar;
        boolean zF = qVar.f(jVar) | qVar.f(str) | qVar.f(eVar2);
        Object objL5 = qVar.L();
        if (zF || objL5 == obj) {
            objL5 = new f0(function12);
            qVar.j0(objL5);
        }
        return lVar;
    }

    public static final p H(p pVar, float f3, float f10) {
        return (f3 == 1.0f && f10 == 1.0f) ? pVar : androidx.compose.ui.graphics.a.c(pVar, f3, f10, 0.0f, null, 524284);
    }

    public static void I(Window window, boolean z5) {
        int i8 = Build.VERSION.SDK_INT;
        if (i8 >= 35) {
            c2.b.e(window, z5);
        } else {
            if (i8 >= 30) {
                c2.b.d(window, z5);
                return;
            }
            View decorView = window.getDecorView();
            int systemUiVisibility = decorView.getSystemUiVisibility();
            decorView.setSystemUiVisibility(z5 ? systemUiVisibility & (-1793) : systemUiVisibility | 1792);
        }
    }

    public static void J(TextView textView, int i8) {
        if (i8 < 0) {
            throw new IllegalArgumentException();
        }
        if (Build.VERSION.SDK_INT >= 28) {
            b3.n.o(textView, i8);
            return;
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i10 = textView.getIncludeFontPadding() ? fontMetricsInt.top : fontMetricsInt.ascent;
        if (i8 > Math.abs(i10)) {
            textView.setPadding(textView.getPaddingLeft(), i8 + i10, textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }

    public static void K(TextView textView, int i8) {
        if (i8 < 0) {
            throw new IllegalArgumentException();
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i10 = textView.getIncludeFontPadding() ? fontMetricsInt.bottom : fontMetricsInt.descent;
        if (i8 > Math.abs(i10)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), i8 - i10);
        }
    }

    public static void L(TextView textView, int i8) {
        if (i8 < 0) {
            throw new IllegalArgumentException();
        }
        if (i8 != textView.getPaint().getFontMetricsInt(null)) {
            textView.setLineSpacing(i8 - r0, 1.0f);
        }
    }

    public static final int M(a0 state) {
        Intrinsics.checkNotNullParameter(state, "state");
        int iOrdinal = state.ordinal();
        if (iOrdinal == 0) {
            return 0;
        }
        int i8 = 1;
        if (iOrdinal != 1) {
            i8 = 2;
            if (iOrdinal != 2) {
                i8 = 3;
                if (iOrdinal != 3) {
                    i8 = 4;
                    if (iOrdinal != 4) {
                        if (iOrdinal == 5) {
                            return 5;
                        }
                        throw new uc.n();
                    }
                }
            }
        }
        return i8;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0029  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0036  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object N(int i8, Object obj, m2.y yVar, s sVar, int i10) {
        Object[] objArr;
        Object[] objArr2;
        if (!(obj instanceof Typeface)) {
            return obj;
        }
        boolean z5 = false;
        int i11 = 0;
        z5 = false;
        if ((i8 & 1) == 0 || Intrinsics.b(yVar.f5308a, sVar)) {
            objArr = false;
        } else {
            s sVar2 = s.f5302j;
            if (sVar.compareTo(sVar2) >= 0 && Intrinsics.e(yVar.f5308a.f5305d, sVar2.f5305d) < 0) {
                objArr = true;
            }
        }
        if ((i8 & 2) != 0) {
            yVar.getClass();
            objArr2 = i10 != 0;
        }
        if (objArr2 != true && objArr != true) {
            return obj;
        }
        if (Build.VERSION.SDK_INT >= 28) {
            int i12 = objArr != false ? sVar.f5305d : yVar.f5308a.f5305d;
            if (objArr2 != true) {
                yVar.getClass();
            } else if (i10 == 1) {
                z5 = true;
            }
            return Typeface.create((Typeface) obj, i12, z5);
        }
        Object[] objArr3 = objArr2 == true && i10 == 1;
        if (objArr3 == true && objArr == true) {
            i11 = 3;
        } else if (objArr == true) {
            i11 = 1;
        } else if (objArr3 != false) {
            i11 = 2;
        }
        return Typeface.create((Typeface) obj, i11);
    }

    public static byte[] O(com.google.firebase.messaging.d dVar) throws IOException {
        ArrayDeque arrayDeque = new ArrayDeque(20);
        int iMin = Math.min(8192, Math.max(128, Integer.highestOneBit(0) * 2));
        int i8 = 0;
        while (i8 < 2147483639) {
            int iMin2 = Math.min(iMin, 2147483639 - i8);
            byte[] bArr = new byte[iMin2];
            arrayDeque.add(bArr);
            int i10 = 0;
            while (i10 < iMin2) {
                int i11 = dVar.read(bArr, i10, iMin2 - i10);
                if (i11 == -1) {
                    return k(arrayDeque, i8);
                }
                i10 += i11;
                i8 += i11;
            }
            long j8 = iMin * (iMin < 4096 ? 4 : 2);
            iMin = j8 > 2147483647L ? Integer.MAX_VALUE : j8 < -2147483648L ? Integer.MIN_VALUE : (int) j8;
        }
        if (dVar.read() == -1) {
            return k(arrayDeque, 2147483639);
        }
        throw new OutOfMemoryError("input is too large to fit in a byte array");
    }

    public static final void a(n6.a permissionState, o oVar, q qVar, int i8) {
        Intrinsics.checkNotNullParameter(permissionState, "permissionState");
        qVar.a0(-1770945943);
        int i10 = (qVar.f(permissionState) ? 4 : 2) | i8 | 48;
        if ((i10 & 19) == 18 && qVar.A()) {
            qVar.T();
        } else {
            oVar = o.ON_RESUME;
            qVar.Z(-2101357749);
            boolean z5 = (i10 & 14) == 4;
            Object objL = qVar.L();
            o0.v0 v0Var = o0.k.f6241a;
            if (z5 || objL == v0Var) {
                objL = new d.d(1, oVar, permissionState);
                qVar.j0(objL);
            }
            androidx.lifecycle.s sVar = (androidx.lifecycle.s) objL;
            qVar.q(false);
            w wVarH = ((u) qVar.j(z3.e.f9534a)).h();
            qVar.Z(-2101338711);
            boolean zH = qVar.h(wVarH) | qVar.h(sVar);
            Object objL2 = qVar.L();
            if (zH || objL2 == v0Var) {
                objL2 = new b6.l(15, wVarH, sVar);
                qVar.j0(objL2);
            }
            qVar.q(false);
            y.c(wVarH, sVar, (Function1) objL2, qVar);
        }
        s1 s1VarS = qVar.s();
        if (s1VarS != null) {
            s1VarS.f6350d = new c0.s(i8, 9, permissionState, oVar);
        }
    }

    public static final g1.c b(long j8, long j9) {
        int i8 = (int) (j8 >> 32);
        int i10 = (int) (j8 & 4294967295L);
        return new g1.c(Float.intBitsToFloat(i8), Float.intBitsToFloat(i10), Float.intBitsToFloat((int) (j9 >> 32)) + Float.intBitsToFloat(i8), Float.intBitsToFloat((int) (j9 & 4294967295L)) + Float.intBitsToFloat(i10));
    }

    public static final void c(final Function0 onFinished, final Function0 onPolicy, q qVar, final int i8) {
        final Function0 function0;
        q qVar2;
        s1 s1VarS;
        Function2 function2;
        a1 a1Var;
        Context context;
        boolean z5;
        q qVar3 = qVar;
        a2.t tVar = a2.t.f360m;
        Intrinsics.checkNotNullParameter(onFinished, "onFinished");
        Intrinsics.checkNotNullParameter(onPolicy, "onPolicy");
        qVar3.a0(1248818648);
        int i10 = (qVar3.h(onFinished) ? 4 : 2) | i8 | (qVar3.h(onPolicy) ? 32 : 16);
        if (qVar3.Q(i10 & 1, (i10 & 19) != 18)) {
            Context context2 = (Context) qVar3.j(e1.f171b);
            Object objL = qVar3.L();
            o0.v0 v0Var = o0.k.f6241a;
            if (objL == v0Var) {
                objL = y.r(null);
                qVar3.j0(objL);
            }
            a1 a1Var2 = (a1) objL;
            Object objL2 = qVar3.L();
            if (objL2 == v0Var) {
                objL2 = y.r(null);
                qVar3.j0(objL2);
            }
            a1 a1Var3 = (a1) objL2;
            Object objL3 = qVar3.L();
            if (objL3 == v0Var) {
                objL3 = y.r(null);
                qVar3.j0(objL3);
            }
            a1 a1Var4 = (a1) objL3;
            Object objL4 = qVar3.L();
            if (objL4 == v0Var) {
                objL4 = y.r(Boolean.FALSE);
                qVar3.j0(objL4);
            }
            a1 a1Var5 = (a1) objL4;
            Object objL5 = qVar3.L();
            if (objL5 == v0Var) {
                objL5 = y.r(Boolean.FALSE);
                qVar3.j0(objL5);
            }
            a1 a1Var6 = (a1) objL5;
            Object objL6 = qVar3.L();
            if (objL6 == v0Var) {
                objL6 = y.r(Boolean.FALSE);
                qVar3.j0(objL6);
            }
            a1 a1Var7 = (a1) objL6;
            Object[] objArr = new Object[0];
            Object objL7 = qVar3.L();
            if (objL7 == v0Var) {
                objL7 = new b6.h(24);
                qVar3.j0(objL7);
            }
            a1 a1Var8 = (a1) j.c(objArr, (Function0) objL7, qVar3);
            Object objL8 = qVar3.L();
            if (objL8 == v0Var) {
                a1Var = a1Var6;
                objL8 = new j6.b(new e.c(a1Var3), new e.c(a1Var2));
                qVar3.j0(objL8);
            } else {
                a1Var = a1Var6;
            }
            j6.b chromeClient = (j6.b) objL8;
            Object objL9 = qVar3.L();
            if (objL9 == v0Var) {
                objL9 = new j6.a(context2, new j5.e(onFinished, onPolicy));
                qVar3.j0(objL9);
            }
            j6.a viewClient = (j6.a) objL9;
            Object objL10 = qVar3.L();
            Object obj = objL10;
            if (objL10 == v0Var) {
                Intrinsics.checkNotNullParameter(context2, "context");
                Intrinsics.checkNotNullParameter(viewClient, "viewClient");
                Intrinsics.checkNotNullParameter(chromeClient, "chromeClient");
                m6.a aVar = new m6.a(context2);
                aVar.setWebViewClient(viewClient);
                aVar.setWebChromeClient(chromeClient);
                e(aVar, false);
                aVar.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
                qVar3.j0(aVar);
                obj = aVar;
            }
            m6.a aVar2 = (m6.a) obj;
            Boolean bool = (Boolean) a1Var8.getValue();
            bool.getClass();
            boolean zF = qVar3.f(a1Var8);
            Object objL11 = qVar3.L();
            if (zF || objL11 == v0Var) {
                context = context2;
                objL11 = new g6.c(a1Var8, null, 1);
                qVar3.j0(objL11);
            } else {
                context = context2;
            }
            y.f(bool, (Function2) objL11, qVar3);
            boolean zH = qVar3.h(aVar2);
            Object objL12 = qVar3.L();
            if (zH || objL12 == v0Var) {
                objL12 = new p0(4, aVar2);
                qVar3.j0(objL12);
            }
            j5.f.a(false, (Function0) objL12, qVar3, 0);
            Activity activity = (Activity) qVar3.j(e.i.f2154a);
            Window window = activity != null ? activity.getWindow() : null;
            boolean zH2 = qVar3.h(window);
            Object objL13 = qVar3.L();
            if (zH2 || objL13 == v0Var) {
                objL13 = new ae.c(9, window);
                qVar3.j0(objL13);
            }
            y.d(window, (Function1) objL13, qVar3);
            p pVarL = Build.VERSION.SDK_INT <= 27 ? l(androidx.compose.foundation.layout.c.f712c, tVar, new f1(0)) : l(androidx.compose.foundation.layout.c.f712c, tVar, new f1(1));
            boolean zH3 = qVar3.h(aVar2);
            Object objL14 = qVar3.L();
            if (zH3 || objL14 == v0Var) {
                objL14 = new ae.c(10, aVar2);
                qVar3.j0(objL14);
            }
            androidx.compose.ui.viewinterop.a.b((Function1) objL14, pVarL, null, qVar3, 0);
            boolean zB = Intrinsics.b((l6.g) a1Var4.getValue(), l6.g.f5032a);
            PermissionRequest permissionRequest = (PermissionRequest) a1Var2.getValue();
            Object objL15 = qVar3.L();
            if (objL15 == v0Var) {
                objL15 = new d6.b(a1Var2, a1Var7, a1Var5, a1Var4);
                qVar3.j0(objL15);
            }
            Function0 function02 = (Function0) objL15;
            Object objL16 = qVar3.L();
            if (objL16 == v0Var) {
                objL16 = new i6.a(a1Var4, a1Var5, 0);
                qVar3.j0(objL16);
            }
            a1 a1Var9 = a1Var;
            l6.c.b(zB, permissionRequest, function02, (Function0) objL16, qVar3, 3456);
            boolean zBooleanValue = ((Boolean) a1Var7.getValue()).booleanValue();
            Object objL17 = qVar3.L();
            if (objL17 == v0Var) {
                objL17 = new c0.s(2, a1Var3, a1Var7);
                qVar3.j0(objL17);
            }
            l6.c.a((Function2) objL17, zBooleanValue, qVar3, 6);
            boolean zBooleanValue2 = ((Boolean) a1Var9.getValue()).booleanValue();
            Object objL18 = qVar3.L();
            if (objL18 == v0Var) {
                objL18 = new b6.l(7, a1Var3, a1Var9);
                qVar3.j0(objL18);
            }
            l6.c.f(zBooleanValue2, (Function1) objL18, qVar3, 48);
            boolean z10 = ((ValueCallback) a1Var3.getValue()) != null;
            Object objL19 = qVar3.L();
            if (objL19 == v0Var) {
                objL19 = new e6.d(a1Var4, 6);
                qVar3.j0(objL19);
            }
            Function0 function03 = (Function0) objL19;
            Object objL20 = qVar3.L();
            if (objL20 == v0Var) {
                objL20 = new e6.d(a1Var9, 7);
                qVar3.j0(objL20);
            }
            Function0 function04 = (Function0) objL20;
            Object objL21 = qVar3.L();
            if (objL21 == v0Var) {
                objL21 = new e6.d(a1Var3, 8);
                qVar3.j0(objL21);
            }
            l6.c.c(z10, function03, function04, (Function0) objL21, null, qVar, 3504);
            q qVar4 = qVar;
            if (((Boolean) a1Var5.getValue()).booleanValue()) {
                qVar4.Z(553680875);
                l6.g gVar = (l6.g) a1Var4.getValue();
                if (gVar == null) {
                    qVar4.q(false);
                    s1VarS = qVar4.s();
                    if (s1VarS != null) {
                        final int i11 = 0;
                        function2 = new Function2(i8, i11, onFinished, onPolicy) { // from class: i6.b

                            /* renamed from: d, reason: collision with root package name */
                            public final /* synthetic */ int f3499d;

                            /* renamed from: e, reason: collision with root package name */
                            public final /* synthetic */ Function0 f3500e;

                            /* renamed from: i, reason: collision with root package name */
                            public final /* synthetic */ Function0 f3501i;

                            {
                                this.f3499d = i11;
                                this.f3500e = onFinished;
                                this.f3501i = onPolicy;
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                int i12 = this.f3499d;
                                q qVar5 = (q) obj2;
                                ((Integer) obj3).getClass();
                                switch (i12) {
                                    case 0:
                                        e.c(this.f3500e, this.f3501i, qVar5, y.y(1));
                                        break;
                                    default:
                                        e.c(this.f3500e, this.f3501i, qVar5, y.y(1));
                                        break;
                                }
                                return Unit.f4213a;
                            }
                        };
                        s1VarS.f6350d = function2;
                    }
                    return;
                }
                function0 = onFinished;
                Object objL22 = qVar4.L();
                if (objL22 == v0Var) {
                    objL22 = new e6.d(a1Var5, 9);
                    qVar4.j0(objL22);
                }
                Function0 function05 = (Function0) objL22;
                Context context3 = context;
                boolean zH4 = qVar4.h(context3);
                Object objL23 = qVar4.L();
                if (zH4 || objL23 == v0Var) {
                    objL23 = new i4.c(context3, a1Var4, a1Var5, 1);
                    qVar4.j0(objL23);
                }
                l6.c.e(gVar, function05, (Function0) objL23, null, qVar4, 48);
                z5 = false;
            } else {
                z5 = false;
                function0 = onFinished;
                qVar4.Z(547949130);
            }
            qVar4.q(z5);
            qVar2 = qVar4;
        } else {
            function0 = onFinished;
            qVar3.T();
            qVar2 = qVar3;
        }
        s1VarS = qVar2.s();
        if (s1VarS != null) {
            final int i12 = 1;
            function2 = new Function2(i8, i12, function0, onPolicy) { // from class: i6.b

                /* renamed from: d, reason: collision with root package name */
                public final /* synthetic */ int f3499d;

                /* renamed from: e, reason: collision with root package name */
                public final /* synthetic */ Function0 f3500e;

                /* renamed from: i, reason: collision with root package name */
                public final /* synthetic */ Function0 f3501i;

                {
                    this.f3499d = i12;
                    this.f3500e = function0;
                    this.f3501i = onPolicy;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    int i122 = this.f3499d;
                    q qVar5 = (q) obj2;
                    ((Integer) obj3).getClass();
                    switch (i122) {
                        case 0:
                            e.c(this.f3500e, this.f3501i, qVar5, y.y(1));
                            break;
                        default:
                            e.c(this.f3500e, this.f3501i, qVar5, y.y(1));
                            break;
                    }
                    return Unit.f4213a;
                }
            };
            s1VarS.f6350d = function2;
        }
    }

    public static final void d(v vVar) {
        Intrinsics.checkNotNullParameter(vVar, "<this>");
        if ((vVar instanceof v ? vVar : null) != null) {
            return;
        }
        throw new IllegalStateException("This serializer can be used only with Json format.Expected Encoder to be JsonEncoder, got " + d0.a(vVar.getClass()));
    }

    public static final void e(WebView webView, boolean z5) {
        Intrinsics.checkNotNullParameter(webView, "<this>");
        Context context = webView.getContext();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setCacheMode(-1);
        settings.setMixedContentMode(0);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setBlockNetworkLoads(false);
        Intrinsics.c(context);
        Intrinsics.checkNotNullParameter(context, "context");
        String defaultUserAgent = WebSettings.getDefaultUserAgent(context);
        Intrinsics.checkNotNullExpressionValue(defaultUserAgent, "getDefaultUserAgent(...)");
        settings.setUserAgentString(kotlin.text.t.i(kotlin.text.t.i(defaultUserAgent, "; wv", ""), "Version/4.0", ""));
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setOffscreenPreRaster(false);
        settings.setSupportMultipleWindows(true);
        settings.setNeedInitialFocus(true);
        settings.setSupportZoom(true);
        webView.setInitialScale(0);
        int i8 = Build.VERSION.SDK_INT;
        if (i8 >= 26) {
            webView.setImportantForAutofill(8);
        }
        if (i8 <= 27) {
            settings.setSaveFormData(true);
        }
        if (i8 <= 30) {
            settings.setAllowFileAccessFromFileURLs(false);
        }
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        webView.setSaveEnabled(true);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        if (z5) {
            return;
        }
        NativeStoreManager.INSTANCE.applyHardwareLayer(webView, null);
    }

    public static final ge.k f(ee.b bVar) {
        Intrinsics.checkNotNullParameter(bVar, "<this>");
        ge.k kVar = bVar instanceof ge.k ? (ge.k) bVar : null;
        if (kVar != null) {
            return kVar;
        }
        throw new IllegalStateException("This serializer can be used only with Json format.Expected Decoder to be JsonDecoder, got " + d0.a(bVar.getClass()));
    }

    public static final LinkedHashSet g(byte[] bytes) throws IOException {
        ObjectInputStream objectInputStream;
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        if (bytes.length == 0) {
            return linkedHashSet;
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        try {
            try {
                objectInputStream = new ObjectInputStream(byteArrayInputStream);
            } catch (IOException e10) {
                e10.printStackTrace();
            }
            try {
                int i8 = objectInputStream.readInt();
                for (int i10 = 0; i10 < i8; i10++) {
                    Uri uri = Uri.parse(objectInputStream.readUTF());
                    boolean z5 = objectInputStream.readBoolean();
                    Intrinsics.checkNotNullExpressionValue(uri, "uri");
                    linkedHashSet.add(new a5.d(z5, uri));
                }
                Unit unit = Unit.f4213a;
                objectInputStream.close();
                Unit unit2 = Unit.f4213a;
                byteArrayInputStream.close();
                return linkedHashSet;
            } finally {
            }
        } finally {
        }
    }

    public static final int h(float f3) {
        return Math.round((float) Math.ceil(f3));
    }

    public static void i(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static void j(Closeable closeable) throws IOException {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    public static byte[] k(ArrayDeque arrayDeque, int i8) {
        if (arrayDeque.isEmpty()) {
            return new byte[0];
        }
        byte[] bArr = (byte[]) arrayDeque.remove();
        if (bArr.length == i8) {
            return bArr;
        }
        int length = i8 - bArr.length;
        byte[] bArrCopyOf = Arrays.copyOf(bArr, i8);
        while (length > 0) {
            byte[] bArr2 = (byte[]) arrayDeque.remove();
            int iMin = Math.min(length, bArr2.length);
            System.arraycopy(bArr2, 0, bArrCopyOf, i8 - length, iMin);
            length -= iMin;
        }
        return bArrCopyOf;
    }

    public static final p l(p pVar, Function1 function1, hd.c cVar) {
        return pVar.e(new a1.j(function1, cVar));
    }

    public static boolean m(File file, Resources resources, int i8) throws Throwable {
        InputStream inputStreamOpenRawResource;
        try {
            inputStreamOpenRawResource = resources.openRawResource(i8);
            try {
                boolean zN = n(file, inputStreamOpenRawResource);
                j(inputStreamOpenRawResource);
                return zN;
            } catch (Throwable th) {
                th = th;
                j(inputStreamOpenRawResource);
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            inputStreamOpenRawResource = null;
        }
    }

    public static boolean n(File file, InputStream inputStream) throws Throwable {
        FileOutputStream fileOutputStream;
        StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream2 = null;
        try {
            try {
                fileOutputStream = new FileOutputStream(file, false);
            } catch (IOException e10) {
                e = e10;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int i8 = inputStream.read(bArr);
                if (i8 == -1) {
                    j(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return true;
                }
                fileOutputStream.write(bArr, 0, i8);
            }
        } catch (IOException e11) {
            e = e11;
            fileOutputStream2 = fileOutputStream;
            Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
            j(fileOutputStream2);
            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            return false;
        } catch (Throwable th2) {
            th = th2;
            fileOutputStream2 = fileOutputStream;
            j(fileOutputStream2);
            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
            throw th;
        }
    }

    public static Handler o(Looper looper) {
        if (Build.VERSION.SDK_INT >= 28) {
            return b3.n.a(looper);
        }
        try {
            return (Handler) Handler.class.getDeclaredConstructor(Looper.class, Handler.Callback.class, Boolean.TYPE).newInstance(looper, null, Boolean.TRUE);
        } catch (IllegalAccessException e10) {
            e = e10;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (InstantiationException e11) {
            e = e11;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (NoSuchMethodException e12) {
            e = e12;
            Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", e);
            return new Handler(looper);
        } catch (InvocationTargetException e13) {
            Throwable cause = e13.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException(cause);
        }
    }

    public static void p(c1.c cVar, LongSparseArray longSparseArray) {
        TranslationResponseValue value;
        CharSequence text;
        g2.m mVar;
        g2.l lVar;
        Function1 function1;
        int size = longSparseArray.size();
        for (int i8 = 0; i8 < size; i8++) {
            long jKeyAt = longSparseArray.keyAt(i8);
            ViewTranslationResponse viewTranslationResponseG = a2.k.g(longSparseArray.get(jKeyAt));
            if (viewTranslationResponseG != null && (value = viewTranslationResponseG.getValue("android:text")) != null && (text = value.getText()) != null && (mVar = (g2.m) cVar.h().b((int) jKeyAt)) != null && (lVar = mVar.f2697a) != null) {
                Object objG = lVar.f2693d.f2684d.g(h.f2668j);
                if (objG == null) {
                    objG = null;
                }
                g2.a aVar = (g2.a) objG;
                if (aVar != null && (function1 = (Function1) aVar.f2647b) != null) {
                }
            }
        }
    }

    public static Object q(Object obj, Class cls) {
        if (obj instanceof rc.a) {
            return cls.cast(obj);
        }
        if (obj instanceof rc.b) {
            return q(((rc.b) obj).d(), cls);
        }
        throw new IllegalStateException("Given component holder " + obj.getClass() + " does not implement " + rc.a.class + " or " + rc.b.class);
    }

    public static final String r(id.i iVar) {
        id.h hVar = id.i.f3638b;
        Class jClass = iVar.f3640a;
        hVar.getClass();
        Intrinsics.checkNotNullParameter(jClass, "jClass");
        String strConcat = null;
        if (jClass.isAnonymousClass() || jClass.isLocalClass()) {
            return null;
        }
        if (!jClass.isArray()) {
            String name = jClass.getName();
            Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
            String strA = id.h.a(name);
            return strA == null ? jClass.getCanonicalName() : strA;
        }
        Class<?> componentType = jClass.getComponentType();
        if (componentType.isPrimitive()) {
            String name2 = componentType.getName();
            Intrinsics.checkNotNullExpressionValue(name2, "getName(...)");
            String strA2 = id.h.a(name2);
            if (strA2 != null) {
                strConcat = strA2.concat("Array");
            }
        }
        return strConcat == null ? "kotlin.Array" : strConcat;
    }

    public static final int s(Cursor c10, String name) {
        String strR;
        Intrinsics.checkNotNullParameter(c10, "c");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(c10, "c");
        Intrinsics.checkNotNullParameter(name, "name");
        int columnIndex = c10.getColumnIndex(name);
        if (columnIndex < 0) {
            columnIndex = c10.getColumnIndex("`" + name + '`');
            if (columnIndex < 0) {
                if (Build.VERSION.SDK_INT <= 25 && name.length() != 0) {
                    String[] columnNames = c10.getColumnNames();
                    Intrinsics.checkNotNullExpressionValue(columnNames, "columnNames");
                    Intrinsics.checkNotNullParameter(columnNames, "columnNames");
                    Intrinsics.checkNotNullParameter(name, "name");
                    String strConcat = ".".concat(name);
                    String str = "." + name + '`';
                    int length = columnNames.length;
                    int i8 = 0;
                    int i10 = 0;
                    while (i10 < length) {
                        String str2 = columnNames[i10];
                        int i11 = i8 + 1;
                        if (str2.length() >= name.length() + 2 && (kotlin.text.t.e(str2, strConcat) || (str2.charAt(0) == '`' && kotlin.text.t.e(str2, str)))) {
                            columnIndex = i8;
                            break;
                        }
                        i10++;
                        i8 = i11;
                    }
                    columnIndex = -1;
                } else {
                    columnIndex = -1;
                }
            }
        }
        if (columnIndex >= 0) {
            return columnIndex;
        }
        try {
            String[] columnNames2 = c10.getColumnNames();
            Intrinsics.checkNotNullExpressionValue(columnNames2, "c.columnNames");
            strR = x.r(63, columnNames2);
        } catch (Exception e10) {
            Log.d("RoomCursorUtil", "Cannot collect column names for debug purposes", e10);
            strR = "unknown";
        }
        throw new IllegalArgumentException("column '" + name + "' does not exist. Available columns: " + strR);
    }

    public static String t(int i8) {
        switch (i8) {
            case -1:
                return "SUCCESS_CACHE";
            case 0:
                return "SUCCESS";
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
            case 9:
            case RequestError.STOP_TRACKING /* 11 */:
            case 12:
            default:
                return a1.d.g(i8, "unknown status code: ");
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case 3:
                return "SERVICE_DISABLED";
            case 4:
                return "SIGN_IN_REQUIRED";
            case 5:
                return "INVALID_ACCOUNT";
            case 6:
                return "RESOLUTION_REQUIRED";
            case 7:
                return "NETWORK_ERROR";
            case 8:
                return "INTERNAL_ERROR";
            case 10:
                return "DEVELOPER_ERROR";
            case 13:
                return "ERROR";
            case 14:
                return "INTERRUPTED";
            case 15:
                return "TIMEOUT";
            case 16:
                return "CANCELED";
            case 17:
                return "API_NOT_CONNECTED";
            case 18:
                return "DEAD_CLIENT";
            case 19:
                return "REMOTE_EXCEPTION";
            case 20:
                return "CONNECTION_SUSPENDED_DURING_CALL";
            case 21:
                return "RECONNECTION_TIMED_OUT_DURING_UPDATE";
            case 22:
                return "RECONNECTION_TIMED_OUT";
        }
    }

    public static File u(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i8 = 0; i8 < 100; i8++) {
            File file = new File(cacheDir, str + i8);
            if (file.createNewFile()) {
                return file;
            }
        }
        return null;
    }

    public static j3.a v(n.d0 d0Var) {
        int i8 = Build.VERSION.SDK_INT;
        if (i8 >= 28) {
            return new j3.a(b3.n.l(d0Var));
        }
        TextPaint textPaint = new TextPaint(d0Var.getPaint());
        TextDirectionHeuristic textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
        int breakStrategy = d0Var.getBreakStrategy();
        int hyphenationFrequency = d0Var.getHyphenationFrequency();
        if (d0Var.getTransformationMethod() instanceof PasswordTransformationMethod) {
            textDirectionHeuristic = TextDirectionHeuristics.LTR;
        } else {
            if (i8 < 28 || (d0Var.getInputType() & 15) != 3) {
                boolean z5 = d0Var.getLayoutDirection() == 1;
                switch (d0Var.getTextDirection()) {
                    case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                        textDirectionHeuristic = TextDirectionHeuristics.ANYRTL_LTR;
                        break;
                    case 3:
                        textDirectionHeuristic = TextDirectionHeuristics.LTR;
                        break;
                    case 4:
                        textDirectionHeuristic = TextDirectionHeuristics.RTL;
                        break;
                    case 5:
                        textDirectionHeuristic = TextDirectionHeuristics.LOCALE;
                        break;
                    case 6:
                        break;
                    case 7:
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                        break;
                    default:
                        if (z5) {
                            textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                            break;
                        }
                        break;
                }
            } else {
                byte directionality = Character.getDirectionality(b3.n.d(DecimalFormatSymbols.getInstance(d0Var.getTextLocale()))[0].codePointAt(0));
                textDirectionHeuristic = (directionality == 1 || directionality == 2) ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR;
            }
        }
        return new j3.a(textPaint, textDirectionHeuristic, breakStrategy, hyphenationFrequency);
    }

    public static final a5.a w(int i8) {
        if (i8 == 0) {
            return a5.a.f427d;
        }
        if (i8 == 1) {
            return a5.a.f428e;
        }
        throw new IllegalArgumentException(a1.d.h(i8, "Could not convert ", " to BackoffPolicy"));
    }

    public static final a5.s x(int i8) {
        if (i8 == 0) {
            return a5.s.f479d;
        }
        if (i8 == 1) {
            return a5.s.f480e;
        }
        if (i8 == 2) {
            return a5.s.f481i;
        }
        if (i8 == 3) {
            return a5.s.f482j;
        }
        if (i8 == 4) {
            return a5.s.k;
        }
        if (Build.VERSION.SDK_INT < 30 || i8 != 5) {
            throw new IllegalArgumentException(a1.d.h(i8, "Could not convert ", " to NetworkType"));
        }
        return a5.s.f483l;
    }

    public static final z y(int i8) {
        if (i8 == 0) {
            return z.f494d;
        }
        if (i8 == 1) {
            return z.f495e;
        }
        throw new IllegalArgumentException(a1.d.h(i8, "Could not convert ", " to OutOfQuotaPolicy"));
    }

    public static final a0 z(int i8) {
        if (i8 == 0) {
            return a0.f430d;
        }
        if (i8 == 1) {
            return a0.f431e;
        }
        if (i8 == 2) {
            return a0.f432i;
        }
        if (i8 == 3) {
            return a0.f433j;
        }
        if (i8 == 4) {
            return a0.k;
        }
        if (i8 == 5) {
            return a0.f434l;
        }
        throw new IllegalArgumentException(a1.d.h(i8, "Could not convert ", " to State"));
    }

    public final Object D(int i8, Intent intent) {
        List arrayList;
        switch (this.f3304a) {
            case 0:
                if (i8 != -1) {
                    intent = null;
                }
                if (intent == null) {
                    return null;
                }
                Uri data = intent.getData();
                if (data != null) {
                    return data;
                }
                Intrinsics.checkNotNullParameter(intent, "<this>");
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                Uri data2 = intent.getData();
                if (data2 != null) {
                    linkedHashSet.add(data2);
                }
                ClipData clipData = intent.getClipData();
                if (clipData == null && linkedHashSet.isEmpty()) {
                    arrayList = kotlin.collections.i0.f4227d;
                } else {
                    if (clipData != null) {
                        int itemCount = clipData.getItemCount();
                        for (int i10 = 0; i10 < itemCount; i10++) {
                            Uri uri = clipData.getItemAt(i10).getUri();
                            if (uri != null) {
                                linkedHashSet.add(uri);
                            }
                        }
                    }
                    arrayList = new ArrayList(linkedHashSet);
                }
                return (Uri) CollectionsKt.firstOrNull(arrayList);
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                if (intent == null || i8 != -1) {
                    return Boolean.FALSE;
                }
                int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                boolean z5 = false;
                if (intArrayExtra != null) {
                    int length = intArrayExtra.length;
                    int i11 = 0;
                    while (true) {
                        if (i11 < length) {
                            if (intArrayExtra[i11] == 0) {
                                z5 = true;
                            } else {
                                i11++;
                            }
                        }
                    }
                }
                return Boolean.valueOf(z5);
            default:
                return Boolean.valueOf(i8 == -1);
        }
    }
}
