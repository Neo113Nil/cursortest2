package j6;

import android.content.Context;
import android.os.Message;
import android.webkit.WebView;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final Context f3943a;

    /* renamed from: b, reason: collision with root package name */
    public final Message f3944b;

    /* renamed from: c, reason: collision with root package name */
    public final WebView f3945c;

    public f(Context context, Message resultMsg, e.c pickFileCallback, e.c videoPermissionCallback, WebView webView) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(resultMsg, "resultMsg");
        Intrinsics.checkNotNullParameter(pickFileCallback, "pickFileCallback");
        Intrinsics.checkNotNullParameter(videoPermissionCallback, "videoPermissionCallback");
        this.f3943a = context;
        this.f3944b = resultMsg;
        this.f3945c = webView;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!f.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        Intrinsics.d(obj, "null cannot be cast to non-null type com.devsisters.cook.special.client.basic.PopUpAuthWindow");
        f fVar = (f) obj;
        return Intrinsics.b(this.f3943a, fVar.f3943a) && Intrinsics.b(this.f3944b, fVar.f3944b);
    }

    public final int hashCode() {
        return this.f3944b.hashCode() + (this.f3943a.hashCode() * 31);
    }
}
