package j6;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import b6.h;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Unit;
import kotlin.collections.z;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.t;
import uc.l;
import uc.q;
import uc.r;
import uc.s;
import uc.v;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class a extends WebViewClient {

    /* renamed from: a, reason: collision with root package name */
    public final Context f3929a;

    /* renamed from: b, reason: collision with root package name */
    public final k6.a f3930b;

    /* renamed from: c, reason: collision with root package name */
    public final v f3931c;

    /* renamed from: d, reason: collision with root package name */
    public final v f3932d;

    /* renamed from: e, reason: collision with root package name */
    public final Handler f3933e;

    /* renamed from: f, reason: collision with root package name */
    public b5.f f3934f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f3935g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f3936h;

    public a(Context context, k6.a clientCallBack) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(clientCallBack, "clientCallBack");
        this.f3929a = context;
        this.f3930b = clientCallBack;
        this.f3931c = l.b(new h(25));
        this.f3932d = l.b(new h(26));
        this.f3933e = new Handler(Looper.getMainLooper());
        this.f3935g = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00e7  */
    /* JADX WARN: Type inference failed for: r8v2, types: [uc.r] */
    /* JADX WARN: Type inference failed for: r8v4, types: [android.content.Intent] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean a(String str) {
        String strF;
        Intent intent;
        String scheme = Uri.parse(str).getScheme();
        if (scheme != null) {
            if (z.f("about", "http", "https", "blob", "data").contains(scheme)) {
                List list = (List) this.f3931c.getValue();
                if (list == null || !list.isEmpty()) {
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        if (t.j(str, (String) it.next())) {
                            Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(str));
                            String str2 = (StringsKt.q(str, "facebook.com", false) || StringsKt.q(str, "fb.com", false) || StringsKt.q(str, "fb.me", false)) ? "com.facebook.katana" : null;
                            if (str2 != null) {
                                intent2.setPackage(str2);
                            }
                            b(intent2, scheme);
                            return true;
                        }
                    }
                }
            } else {
                int iHashCode = scheme.hashCode();
                if (iHashCode == -1183762788) {
                    if (scheme.equals("intent")) {
                        try {
                            q qVar = s.f7770e;
                            strF = Intent.parseUri(str, 1);
                        } catch (Throwable th) {
                            q qVar2 = s.f7770e;
                            strF = r1.c.f(th);
                        }
                        intent = strF instanceof r ? null : strF;
                    }
                    if (intent != null) {
                    }
                } else if (iHashCode != -1081572750) {
                    intent = (iHashCode == 114715 && scheme.equals("tel")) ? new Intent("android.intent.action.DIAL", Uri.parse(str)) : new Intent("android.intent.action.VIEW", Uri.parse(str));
                    if (intent != null) {
                        b(intent, scheme);
                        return true;
                    }
                } else {
                    if (scheme.equals("mailto")) {
                        intent = new Intent("android.intent.action.SENDTO", Uri.parse(str));
                    }
                    if (intent != null) {
                    }
                }
            }
        }
        return false;
    }

    public final void b(Intent intent, String str) {
        if (c(intent)) {
            return;
        }
        String packageName = intent.getPackage();
        if (packageName == null) {
            ComponentName component = intent.getComponent();
            packageName = component != null ? component.getPackageName() : null;
        }
        if (packageName == null) {
            packageName = (String) ((Map) this.f3932d.getValue()).get(str);
        }
        Context context = this.f3929a;
        if (packageName == null) {
            Toast.makeText(context, "No application found!", 1).show();
            return;
        }
        Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=".concat(packageName)));
        intent2.setPackage("com.android.vending");
        Intent intent3 = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=".concat(packageName)));
        Intent intent4 = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=".concat(packageName)));
        if (c(intent2) || c(intent3) || c(intent4)) {
            return;
        }
        Toast.makeText(context, "No application found!", 1).show();
    }

    public final boolean c(Intent intent) {
        Object objF;
        try {
            q qVar = s.f7770e;
            this.f3929a.startActivity(intent);
            objF = Unit.f4213a;
        } catch (Throwable th) {
            q qVar2 = s.f7770e;
            objF = r1.c.f(th);
        }
        boolean z5 = objF instanceof r;
        boolean z10 = !z5;
        if (!z5) {
            this.f3930b.e();
        }
        return z10;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageCommitVisible(WebView webView, String str) {
        super.onPageCommitVisible(webView, str);
        if (!this.f3935g || this.f3936h) {
            return;
        }
        b5.f fVar = new b5.f(12, this, str);
        this.f3934f = fVar;
        this.f3933e.postDelayed(fVar, 1000L);
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
        super.onReceivedHttpError(webView, webResourceRequest, webResourceResponse);
        if (this.f3935g && webResourceResponse != null && webResourceResponse.getStatusCode() == 403) {
            this.f3936h = true;
            b5.f fVar = this.f3934f;
            if (fVar != null) {
                this.f3933e.removeCallbacks(fVar);
            }
            this.f3930b.g();
        }
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        Object objF;
        Uri url;
        String string;
        try {
            q qVar = s.f7770e;
        } catch (Throwable th) {
            q qVar2 = s.f7770e;
            objF = r1.c.f(th);
        }
        if (webResourceRequest != null && (url = webResourceRequest.getUrl()) != null && (string = url.toString()) != null) {
            objF = Boolean.valueOf(a(string));
            if (s.a(objF) != null) {
                objF = Boolean.FALSE;
            }
            return ((Boolean) objF).booleanValue();
        }
        return false;
    }
}
