package j6;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import b5.n;
import java.lang.reflect.Field;
import kotlin.Unit;
import kotlin.collections.x;
import kotlin.jvm.internal.Intrinsics;
import l3.a0;
import l3.u;
import o0.a1;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public class b extends WebChromeClient {

    /* renamed from: a, reason: collision with root package name */
    public final e.c f3937a;

    /* renamed from: b, reason: collision with root package name */
    public final e.c f3938b;

    public b(e.c pickFileCallback, e.c videoPermissionCallback) {
        Intrinsics.checkNotNullParameter(pickFileCallback, "pickFileCallback");
        Intrinsics.checkNotNullParameter(videoPermissionCallback, "videoPermissionCallback");
        Intrinsics.checkNotNullParameter(pickFileCallback, "pickFileCallback");
        Intrinsics.checkNotNullParameter(videoPermissionCallback, "videoPermissionCallback");
        this.f3937a = pickFileCallback;
        this.f3938b = videoPermissionCallback;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onCreateWindow(WebView webView, boolean z5, boolean z10, Message message) {
        View decorView;
        if (webView == null || message == null) {
            return false;
        }
        webView.onPause();
        Context context = webView.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        e.c cVar = this.f3937a;
        e.c cVar2 = this.f3938b;
        final f fVar = new f(context, message, cVar, cVar2, webView);
        Dialog dialog = new Dialog(context, R.style.ThemeOverlay.Material.Dialog);
        final WebView webView2 = new WebView(context);
        i.e.e(webView2, true);
        webView2.setWebChromeClient(new e(dialog, cVar, cVar2));
        Context context2 = webView2.getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        webView2.setWebViewClient(new a(context2, new z8.c(23, dialog)));
        dialog.setContentView(webView2);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawable(new ColorDrawable(0));
            i.e.I(window, true);
            window.setStatusBarColor(0);
            window.setNavigationBarColor(0);
            View decorView2 = window.getDecorView();
            n nVar = new n(7, webView2);
            Field field = a0.f4845a;
            u.g(decorView2, nVar);
        }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: j6.c
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                webView2.destroy();
                WebView webView3 = fVar.f3945c;
                if (webView3 != null) {
                    webView3.onResume();
                }
            }
        });
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: j6.d
            @Override // android.content.DialogInterface.OnKeyListener
            public final boolean onKey(DialogInterface dialogInterface, int i8, KeyEvent keyEvent) {
                if (keyEvent.getAction() != 1 || i8 != 4) {
                    return false;
                }
                WebView webView3 = webView2;
                if (!webView3.canGoBack()) {
                    return false;
                }
                webView3.goBack();
                return true;
            }
        });
        dialog.show();
        Window window2 = dialog.getWindow();
        if (window2 != null && (decorView = window2.getDecorView()) != null) {
            decorView.requestApplyInsets();
        }
        Object obj = message.obj;
        Intrinsics.d(obj, "null cannot be cast to non-null type android.webkit.WebView.WebViewTransport");
        ((WebView.WebViewTransport) obj).setWebView(webView2);
        message.sendToTarget();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public final void onPermissionRequest(PermissionRequest it) {
        Intrinsics.checkNotNullParameter(it, "request");
        String[] resources = it.getResources();
        Intrinsics.checkNotNullExpressionValue(resources, "getResources(...)");
        if (!x.m(resources, "android.webkit.resource.VIDEO_CAPTURE")) {
            super.onPermissionRequest(it);
            return;
        }
        a1 a1Var = this.f3938b.f2143a;
        Intrinsics.checkNotNullParameter(it, "it");
        a1Var.setValue(it);
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onShowFileChooser(WebView webView, ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        this.f3937a.f2143a.setValue(valueCallback);
        Unit unit = Unit.f4213a;
        return true;
    }
}
