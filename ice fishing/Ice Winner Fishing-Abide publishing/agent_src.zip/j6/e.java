package j6;

import android.app.Dialog;
import android.webkit.WebView;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class e extends b {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Dialog f3942c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Dialog dialog, e.c cVar, e.c cVar2) {
        super(cVar, cVar2);
        this.f3942c = dialog;
    }

    @Override // android.webkit.WebChromeClient
    public final void onCloseWindow(WebView webView) {
        this.f3942c.dismiss();
        if (webView != null) {
            webView.destroy();
        }
    }
}
