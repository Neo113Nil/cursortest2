package r5;

import f4.k;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public interface e extends k {
    public static final a Companion = a.f6910a;
}
