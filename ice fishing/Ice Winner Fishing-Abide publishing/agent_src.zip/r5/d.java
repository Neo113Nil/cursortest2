package r5;

import uc.l;
import uc.m;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class d implements e {
    public static final d INSTANCE = new d();

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ Object f6913a = l.a(m.f7766d, new k4.a(22));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof d);
    }

    public final int hashCode() {
        return -843299786;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, uc.k] */
    public final be.a serializer() {
        return (be.a) f6913a.getValue();
    }

    public final String toString() {
        return "MenuScreen";
    }
}
