package r5;

import uc.l;
import uc.m;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@s5.c
@s5.a
@s5.b
/* loaded from: classes.dex */
public final class c implements e {
    public static final c INSTANCE = new c();

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ Object f6912a = l.a(m.f7766d, new k4.a(21));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof c);
    }

    public final int hashCode() {
        return -400471195;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, uc.k] */
    public final be.a serializer() {
        return (be.a) f6912a.getValue();
    }

    public final String toString() {
        return "InitialScreen";
    }
}
