package r5;

import fe.m0;
import id.d0;
import java.lang.annotation.Annotation;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ a f6910a = new a();

    public final be.a serializer() {
        return new be.d(d0.a(e.class), new od.b[]{d0.a(b.class), d0.a(c.class), d0.a(d.class)}, new be.a[]{new m0("com.devsisters.cook.core.navigation.AppScreen.GameScreen", b.INSTANCE, new Annotation[0]), new m0("com.devsisters.cook.core.navigation.AppScreen.InitialScreen", c.INSTANCE, new Annotation[0]), new m0("com.devsisters.cook.core.navigation.AppScreen.MenuScreen", d.INSTANCE, new Annotation[0])}, new Annotation[0]);
    }
}
