package k6;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public interface a {
    default void a() {
    }

    default void e() {
    }

    default void g() {
    }
}
