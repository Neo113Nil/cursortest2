package b5;

import a2.h2;
import android.app.job.JobParameters;
import android.graphics.Typeface;
import android.os.Process;
import android.os.StrictMode;
import android.util.LongSparseArray;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import com.appsflyer.attribution.RequestError;
import com.devsisters.cook.app.MainActivity;
import com.devsisters.cook.data.p000native.NativeStoreManager;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.y;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import java.util.List;
import java.util.concurrent.Callable;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import n.v;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final /* synthetic */ class f implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1072d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1073e;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f1074i;

    public /* synthetic */ f(int i8, Object obj, Object obj2) {
        this.f1072d = i8;
        this.f1073e = obj;
        this.f1074i = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() throws Exception {
        h2 h2Var;
        int i8 = 0;
        switch (this.f1072d) {
            case 0:
                ((h) this.f1073e).d((j5.j) this.f1074i, false);
                return;
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                t tVar = (t) this.f1073e;
                c8.a aVar = (c8.a) this.f1074i;
                if (tVar.f1144w.f5007d instanceof l5.a) {
                    aVar.cancel(true);
                    return;
                }
                return;
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                i.e.p((c1.c) this.f1073e, (LongSparseArray) this.f1074i);
                return;
            case 3:
                FirebaseMessaging firebaseMessaging = (FirebaseMessaging) this.f1073e;
                y7.g gVar = (y7.g) this.f1074i;
                y yVar = FirebaseMessaging.f1731l;
                try {
                    gVar.a(firebaseMessaging.a());
                    return;
                } catch (Exception e10) {
                    gVar.f9104a.l(e10);
                    return;
                }
            case 4:
                com.google.firebase.messaging.q qVar = (com.google.firebase.messaging.q) this.f1073e;
                y7.g gVar2 = (y7.g) this.f1074i;
                try {
                    gVar2.a(qVar.a());
                    return;
                } catch (Exception e11) {
                    gVar2.f9104a.l(e11);
                    return;
                }
            case 5:
                MainActivity mainActivity = (MainActivity) this.f1073e;
                mainActivity.f984d.a(new d.d(i8, (d.t) this.f1074i, mainActivity));
                return;
            case 6:
                ((v) this.f1073e).c((Typeface) this.f1074i);
                return;
            case 7:
                g8.p pVar = (g8.p) this.f1073e;
                r8.a aVar2 = (r8.a) this.f1074i;
                if (pVar.f2827b != g8.p.f2825d) {
                    throw new IllegalStateException("provide() can be called only once.");
                }
                synchronized (pVar) {
                    h2Var = pVar.f2826a;
                    pVar.f2826a = null;
                    pVar.f2827b = aVar2;
                }
                h2Var.getClass();
                return;
            case 8:
                g8.o oVar = (g8.o) this.f1073e;
                r8.a aVar3 = (r8.a) this.f1074i;
                synchronized (oVar) {
                    try {
                        if (oVar.f2823b == null) {
                            oVar.f2822a.add(aVar3);
                        } else {
                            oVar.f2823b.add(aVar3.get());
                        }
                    } finally {
                    }
                }
                return;
            case 9:
                List<g5.b> listenersList = (List) this.f1073e;
                h5.e this$0 = (h5.e) this.f1074i;
                Intrinsics.checkNotNullParameter(listenersList, "$listenersList");
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                for (g5.b bVar : listenersList) {
                    Object obj = this$0.f3008e;
                    bVar.f2767d = obj;
                    bVar.d(bVar.f2768e, obj);
                }
                return;
            case 10:
                h8.a aVar4 = (h8.a) this.f1073e;
                Runnable runnable = (Runnable) this.f1074i;
                Process.setThreadPriority(aVar4.f3198c);
                StrictMode.ThreadPolicy threadPolicy = aVar4.f3199d;
                if (threadPolicy != null) {
                    StrictMode.setThreadPolicy(threadPolicy);
                }
                runnable.run();
                return;
            case RequestError.STOP_TRACKING /* 11 */:
                Callable callable = (Callable) this.f1073e;
                z8.c cVar = (z8.c) this.f1074i;
                try {
                    Object objCall = callable.call();
                    h8.h hVar = (h8.h) cVar.f9573b;
                    if (objCall == null) {
                        objCall = z2.g.f9522m;
                    }
                    if (z2.g.f9521l.h(hVar, null, objCall)) {
                        z2.g.d(hVar);
                        return;
                    }
                    return;
                } catch (Exception e12) {
                    cVar.z(e12);
                    return;
                }
            case 12:
                j6.a aVar5 = (j6.a) this.f1073e;
                String str = (String) this.f1074i;
                if (aVar5.f3936h) {
                    return;
                }
                NativeStoreManager.INSTANCE.applyHardwareLayer(null, str);
                aVar5.f3935g = false;
                aVar5.f3930b.a();
                return;
            case 13:
                k5.q qVar2 = (k5.q) this.f1073e;
                l5.k kVar = (l5.k) this.f1074i;
                if (qVar2.f4172d.f5007d instanceof l5.a) {
                    kVar.cancel(true);
                    return;
                } else {
                    kVar.k(qVar2.f4175j.getForegroundInfoAsync());
                    return;
                }
            case 14:
                ConstraintTrackingWorker this$02 = (ConstraintTrackingWorker) this.f1073e;
                c8.a innerFuture = (c8.a) this.f1074i;
                Intrinsics.checkNotNullParameter(this$02, "this$0");
                Intrinsics.checkNotNullParameter(innerFuture, "$innerFuture");
                synchronized (this$02.f959e) {
                    try {
                        if (this$02.f960i) {
                            l5.k future = this$02.f961j;
                            Intrinsics.checkNotNullExpressionValue(future, "future");
                            String str2 = n5.a.f6095a;
                            future.i(new a5.n());
                        } else {
                            this$02.f961j.k(innerFuture);
                        }
                        Unit unit = Unit.f4213a;
                    } finally {
                    }
                }
                return;
            case 15:
                ((sd.g) this.f1073e).z((td.d) this.f1074i, Unit.f4213a);
                return;
            default:
                JobInfoSchedulerService jobInfoSchedulerService = (JobInfoSchedulerService) this.f1073e;
                JobParameters jobParameters = (JobParameters) this.f1074i;
                int i10 = JobInfoSchedulerService.f1676d;
                jobInfoSchedulerService.jobFinished(jobParameters, false);
                return;
        }
    }
}
