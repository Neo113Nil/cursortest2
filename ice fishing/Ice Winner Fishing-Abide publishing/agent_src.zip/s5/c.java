package s5;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@Retention(RetentionPolicy.RUNTIME)
/* loaded from: classes.dex */
public @interface c {
}
