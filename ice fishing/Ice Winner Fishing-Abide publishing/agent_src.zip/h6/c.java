package h6;

import r5.e;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class c extends ad.c {

    /* renamed from: d, reason: collision with root package name */
    public e f3022d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f3023e;

    /* renamed from: i, reason: collision with root package name */
    public /* synthetic */ Object f3024i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ d f3025j;
    public int k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(d dVar, ad.c cVar) {
        super(cVar);
        this.f3025j = dVar;
    }

    @Override // ad.a
    public final Object invokeSuspend(Object obj) {
        this.f3024i = obj;
        this.k |= Integer.MIN_VALUE;
        return this.f3025j.b(null, this);
    }
}
