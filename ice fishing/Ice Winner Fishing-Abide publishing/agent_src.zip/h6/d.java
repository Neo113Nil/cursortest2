package h6;

import ae.e;
import android.content.Context;
import com.devsisters.cook.data.p000native.NativeStoreManager;
import f4.h;
import java.util.Arrays;
import kotlin.Unit;
import kotlin.collections.x;
import kotlin.jvm.internal.Intrinsics;
import sd.h0;
import sd.m;
import sd.y;
import vd.a0;
import vd.n;
import vd.r;
import y0.p;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final p8.d f3026a;

    /* renamed from: b, reason: collision with root package name */
    public final Context f3027b;

    /* renamed from: c, reason: collision with root package name */
    public final h f3028c;

    /* renamed from: d, reason: collision with root package name */
    public final e f3029d;

    /* renamed from: e, reason: collision with root package name */
    public final a0 f3030e;

    /* renamed from: f, reason: collision with root package name */
    public final n f3031f;

    /* renamed from: g, reason: collision with root package name */
    public final a0 f3032g;

    /* renamed from: h, reason: collision with root package name */
    public final n f3033h;

    /* renamed from: i, reason: collision with root package name */
    public d4.a f3034i;

    /* renamed from: j, reason: collision with root package name */
    public m f3035j;

    public d(p8.d networkMonitor, Context context) {
        Intrinsics.checkNotNullParameter(networkMonitor, "networkMonitor");
        Intrinsics.checkNotNullParameter(context, "context");
        this.f3026a = networkMonitor;
        this.f3027b = context;
        r5.e[] eVarArr = {r5.c.INSTANCE};
        Object[] objArrCopyOf = Arrays.copyOf(eVarArr, eVarArr.length);
        p pVar = new p();
        pVar.addAll(x.t(objArrCopyOf));
        this.f3028c = new h(pVar);
        this.f3029d = new e();
        Boolean bool = Boolean.FALSE;
        a0 a0VarA = r.a(bool);
        this.f3030e = a0VarA;
        this.f3031f = new n(a0VarA);
        a0 a0VarA2 = r.a(bool);
        this.f3032g = a0VarA2;
        this.f3033h = new n(a0VarA2);
    }

    public final void a(r5.e screen) {
        Intrinsics.checkNotNullParameter(screen, "screen");
        h hVar = this.f3028c;
        hVar.f2390d.add(screen);
        if (hVar.f2390d.size() > 1) {
            Intrinsics.checkNotNullParameter(hVar, "<this>");
            if (hVar.isEmpty()) {
                return;
            }
            hVar.remove(0);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0054, code lost:
    
        if (r13 != false) goto L18;
     */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x008f -> B:18:0x0056). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object b(r5.e eVar, ad.c cVar) {
        c cVar2;
        boolean zIsAnnotationPresent;
        Object objY;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i8 = cVar2.k;
            if ((i8 & Integer.MIN_VALUE) != 0) {
                cVar2.k = i8 - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(this, cVar);
            }
        }
        Object obj = cVar2.f3024i;
        zc.a aVar = zc.a.f9574d;
        int i10 = cVar2.k;
        a0 a0Var = this.f3030e;
        yc.a aVar2 = null;
        if (i10 == 0) {
            r1.c.r(obj);
            zIsAnnotationPresent = eVar.getClass().isAnnotationPresent(s5.b.class);
        } else {
            if (i10 == 1) {
                boolean z5 = cVar2.f3023e;
                r5.e eVar2 = cVar2.f3022d;
                r1.c.r(obj);
                zIsAnnotationPresent = z5;
                eVar = eVar2;
                objY = obj;
                if (((Boolean) objY).booleanValue()) {
                    Boolean bool = Boolean.TRUE;
                    a0Var.getClass();
                    a0Var.j(null, bool);
                    m mVarA = y.a();
                    this.f3035j = mVarA;
                    cVar2.f3022d = eVar;
                    cVar2.f3023e = zIsAnnotationPresent;
                    cVar2.k = 2;
                    if (mVarA.c0(cVar2) != aVar) {
                    }
                    return aVar;
                }
                NativeStoreManager nativeStoreManager = NativeStoreManager.INSTANCE;
                Context context = this.f3027b;
                String absolutePath = context.getFilesDir().getAbsolutePath();
                Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
                nativeStoreManager.initNativeDatastore(context, absolutePath);
                Boolean bool2 = Boolean.FALSE;
                a0Var.getClass();
                a0Var.j(null, bool2);
                if (eVar.getClass().isAnnotationPresent(s5.c.class)) {
                    Boolean bool3 = Boolean.TRUE;
                    a0 a0Var2 = this.f3032g;
                    a0Var2.getClass();
                    a0Var2.j(null, bool3);
                } else {
                    a(eVar);
                }
                return Unit.f4213a;
            }
            if (i10 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            boolean z10 = cVar2.f3023e;
            r5.e eVar3 = cVar2.f3022d;
            r1.c.r(obj);
            zIsAnnotationPresent = z10;
            eVar = eVar3;
        }
        cVar2.f3022d = eVar;
        cVar2.f3023e = zIsAnnotationPresent;
        cVar2.k = 1;
        zd.e eVar4 = h0.f7142a;
        objY = y.y(zd.d.f9607i, new d6.d(this.f3026a, aVar2, 7), cVar2);
        if (objY != aVar) {
            if (((Boolean) objY).booleanValue()) {
            }
        }
        return aVar;
    }
}
