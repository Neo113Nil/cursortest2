package h6;

import ad.i;
import com.devsisters.cook.data.p000native.NativeStoreManager;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import r5.e;
import sd.v;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class b extends i implements Function2 {

    /* renamed from: d, reason: collision with root package name */
    public ae.a f3016d;

    /* renamed from: e, reason: collision with root package name */
    public d f3017e;

    /* renamed from: i, reason: collision with root package name */
    public e f3018i;

    /* renamed from: j, reason: collision with root package name */
    public int f3019j;
    public int k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ d f3020l;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ e f3021m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(d dVar, e eVar, yc.a aVar) {
        super(2, aVar);
        this.f3020l = dVar;
        this.f3021m = eVar;
    }

    @Override // ad.a
    public final yc.a create(Object obj, yc.a aVar) {
        return new b(this.f3020l, this.f3021m, aVar);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return ((b) create((v) obj, (yc.a) obj2)).invokeSuspend(Unit.f4213a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v1, types: [ae.a] */
    @Override // ad.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        d dVar;
        ae.e eVar;
        e eVar2;
        int i8;
        ae.a aVar;
        Throwable th;
        Object objB;
        zc.a aVar2 = zc.a.f9574d;
        int i10 = this.k;
        try {
            if (i10 == 0) {
                r1.c.r(obj);
                dVar = this.f3020l;
                eVar = dVar.f3029d;
                this.f3016d = eVar;
                this.f3017e = dVar;
                e eVar3 = this.f3021m;
                this.f3018i = eVar3;
                this.f3019j = 0;
                this.k = 1;
                if (eVar.d(this) != aVar2) {
                    eVar2 = eVar3;
                    i8 = 0;
                }
                return aVar2;
            }
            if (i10 != 1) {
                if (i10 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                aVar = this.f3016d;
                try {
                    r1.c.r(obj);
                    Unit unit = Unit.f4213a;
                    ((ae.e) aVar).f(null);
                    return Unit.f4213a;
                } catch (Throwable th2) {
                    th = th2;
                    ((ae.e) aVar).f(null);
                    throw th;
                }
            }
            i8 = this.f3019j;
            eVar2 = this.f3018i;
            dVar = this.f3017e;
            ?? r62 = this.f3016d;
            r1.c.r(obj);
            eVar = r62;
            this.f3016d = eVar;
            this.f3017e = null;
            this.f3018i = null;
            this.f3019j = i8;
            this.k = 2;
            dVar.getClass();
            boolean zIsAnnotationPresent = eVar2.getClass().isAnnotationPresent(s5.a.class);
            if (NativeStoreManager.INSTANCE.isDatastoreAvailable() && zIsAnnotationPresent) {
                dVar.a(r5.d.INSTANCE);
                objB = Unit.f4213a;
            } else {
                objB = dVar.b(eVar2, this);
                if (objB != aVar2) {
                    objB = Unit.f4213a;
                }
            }
            if (objB != aVar2) {
                aVar = eVar;
                Unit unit2 = Unit.f4213a;
                ((ae.e) aVar).f(null);
                return Unit.f4213a;
            }
            return aVar2;
        } catch (Throwable th3) {
            aVar = eVar;
            th = th3;
            ((ae.e) aVar).f(null);
            throw th;
        }
    }
}
