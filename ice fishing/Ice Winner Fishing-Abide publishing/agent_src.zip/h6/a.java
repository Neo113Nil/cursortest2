package h6;

import androidx.lifecycle.o0;
import androidx.lifecycle.v0;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class a extends v0 {

    /* renamed from: b, reason: collision with root package name */
    public final d f3015b;

    public a(d navigator) {
        Intrinsics.checkNotNullParameter(navigator, "navigator");
        this.f3015b = navigator;
        navigator.f3034i = o0.h(this);
    }
}
