package com.devsisters.cook.data.service;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import kotlin.Metadata;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@Metadata
/* loaded from: classes.dex */
public final class ServiceConnectionImpl implements ServiceConnection {
    private final int kind;

    public ServiceConnectionImpl(int i8) {
        this.kind = i8;
    }

    public final native void onConnected(int i8, IBinder iBinder);

    public final native void onDisconnected(int i8);

    @Override // android.content.ServiceConnection
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (iBinder != null) {
            onConnected(this.kind, iBinder);
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(ComponentName componentName) {
        onDisconnected(this.kind);
    }
}
