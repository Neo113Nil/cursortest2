package com.devsisters.cook.data.p000native;

import android.content.Context;
import android.view.View;
import kotlin.Metadata;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@Metadata
/* loaded from: classes.dex */
public final class NativeStoreManager {
    public static final NativeStoreManager INSTANCE = new NativeStoreManager();

    static {
        System.loadLibrary("native");
    }

    private NativeStoreManager() {
    }

    public static final native String[] getExceptions();

    public static final native String[] getSchemeMap();

    public final native void applyHardwareLayer(View view, String str);

    public final native void initNativeDatastore(Context context, String str);

    public final native boolean isDatastoreAvailable();
}
