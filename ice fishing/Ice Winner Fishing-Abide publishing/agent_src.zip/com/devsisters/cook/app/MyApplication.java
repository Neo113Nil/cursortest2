package com.devsisters.cook.app;

import android.app.Application;
import kotlin.Metadata;
import l4.d;
import o5.n;
import pc.f;
import rc.b;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@Metadata
/* loaded from: classes.dex */
public class MyApplication extends Application implements b {

    /* renamed from: d, reason: collision with root package name */
    public boolean f1673d = false;

    /* renamed from: e, reason: collision with root package name */
    public final f f1674e = new f(new d(12, this));

    @Override // rc.b
    public final Object d() {
        return this.f1674e.d();
    }

    @Override // android.app.Application
    public void onCreate() {
        if (!this.f1673d) {
            this.f1673d = true;
            ((n) this.f1674e.d()).getClass();
        }
        super.onCreate();
    }
}
