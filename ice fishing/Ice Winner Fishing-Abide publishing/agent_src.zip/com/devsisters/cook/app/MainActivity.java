package com.devsisters.cook.app;

import a2.b2;
import a4.a;
import android.R;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.o0;
import androidx.lifecycle.x0;
import androidx.lifecycle.z0;
import b4.c;
import d.k;
import e.g;
import he.f;
import i.e;
import id.d0;
import j5.l;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import o5.i;
import o5.j;
import o5.m;
import pc.d;
import rc.b;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
@Metadata
/* loaded from: classes.dex */
public final class MainActivity extends k implements b {
    public static final /* synthetic */ int E = 0;
    public volatile pc.b A;
    public final Object B = new Object();
    public boolean C = false;
    public final a D;

    /* renamed from: z, reason: collision with root package name */
    public f f1672z;

    public MainActivity() {
        i listener = new i(this);
        Intrinsics.checkNotNullParameter(listener, "listener");
        g.a aVar = this.f1904e;
        aVar.getClass();
        Intrinsics.checkNotNullParameter(listener, "listener");
        k kVar = aVar.f2586b;
        if (kVar != null) {
            listener.a(kVar);
        }
        aVar.f2585a.add(listener);
        this.D = new a(d0.a(m.class), new o5.k(1, this), new o5.k(0, this), new o5.k(2, this));
    }

    @Override // rc.b
    public final Object d() {
        return k().d();
    }

    @Override // androidx.lifecycle.k
    public final x0 e() {
        x0 x0Var = (x0) this.f1919x.getValue();
        o5.b bVar = (o5.b) ((oc.a) e.q(this, oc.a.class));
        sc.b bVarA = bVar.a();
        l lVar = new l(7, bVar.f6492a, bVar.f6493b);
        x0Var.getClass();
        return new oc.e(bVarA, x0Var, lVar);
    }

    public final pc.b k() {
        if (this.A == null) {
            synchronized (this.B) {
                try {
                    if (this.A == null) {
                        this.A = new pc.b(this, 0);
                    }
                } finally {
                }
            }
        }
        return this.A;
    }

    public final void l(Bundle bundle) {
        super.onCreate(bundle);
        pc.b bVar = (pc.b) k().f6698j;
        z0 z0VarB = pc.b.b(bVar.f6696e, (MainActivity) bVar.f6698j);
        Intrinsics.checkNotNullParameter(d.class, "modelClass");
        Intrinsics.checkNotNullParameter(d.class, "<this>");
        f fVar = ((d) z0VarB.a(d0.a(d.class))).f6700c;
        this.f1672z = fVar;
        if (((b4.e) fVar.f3241b) == null) {
            c cVarF = f();
            if (!fVar.f3240a) {
                throw new IllegalStateException("setExtras should only be called for an Activity that extends ComponentActivity");
            }
            fVar.f3241b = (b4.e) cVarF;
        }
    }

    @Override // d.k, b3.b, android.app.Activity
    public final void onCreate(Bundle bundle) {
        l(bundle);
        q3.a.q(this);
        w0.e eVar = new w0.e(-1816741194, true, new j(this, 0));
        ViewGroup.LayoutParams layoutParams = g.f2150a;
        View childAt = ((ViewGroup) getWindow().getDecorView().findViewById(R.id.content)).getChildAt(0);
        b2 b2Var = childAt instanceof b2 ? (b2) childAt : null;
        if (b2Var != null) {
            b2Var.setParentCompositionContext(null);
            b2Var.setContent(eVar);
            return;
        }
        b2 b2Var2 = new b2(this);
        b2Var2.setParentCompositionContext(null);
        b2Var2.setContent(eVar);
        View decorView = getWindow().getDecorView();
        if (o0.e(decorView) == null) {
            o0.i(decorView, this);
        }
        if (o0.f(decorView) == null) {
            o0.j(decorView, this);
        }
        if (o7.a.R(decorView) == null) {
            o7.a.Y(decorView, this);
        }
        setContentView(b2Var2, g.f2150a);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        f fVar = this.f1672z;
        if (fVar != null) {
            fVar.f3241b = null;
        }
    }

    @Override // android.app.Activity
    public final void onPause() throws IllegalStateException {
        super.onPause();
        MediaPlayer mediaPlayer = ((m) this.D.getValue()).f6522d.f6662c;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    @Override // android.app.Activity
    public final void onResume() throws IllegalStateException {
        super.onResume();
        MediaPlayer mediaPlayer = ((m) this.D.getValue()).f6522d.f6662c;
        if (mediaPlayer.isPlaying()) {
            return;
        }
        mediaPlayer.start();
    }
}
