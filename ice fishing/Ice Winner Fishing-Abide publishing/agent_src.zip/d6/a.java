package d6;

import android.app.Activity;
import android.os.Build;
import android.view.Window;
import be.f;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import de.j;
import e.h;
import fe.m0;
import ge.u;
import he.l;
import id.a0;
import id.c0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.i0;
import kotlin.collections.p0;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import l0.f3;
import l0.v1;
import l0.w1;
import l0.y0;
import l3.d1;
import l3.f1;
import m0.p;
import o0.b2;
import o0.e1;
import o0.e2;
import o0.f2;
import o0.h2;
import o0.q;
import o0.x;
import o0.z0;
import sd.v;
import sd.y;
import t.j0;
import ud.g;
import x1.k0;
import y.k;
import z0.i;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final /* synthetic */ class a implements Function0 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2050d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f2051e;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f2052i;

    public /* synthetic */ a(int i8, Object obj, Object obj2) {
        this.f2050d = i8;
        this.f2051e = obj;
        this.f2052i = obj2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x004d, code lost:
    
        r6 = new z0.i(r4.f3623d, null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0054, code lost:
    
        r3.c();
        r5 = r6;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:83:0x014b  */
    @Override // kotlin.jvm.functions.Function0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke() {
        String[] strArrNames;
        Collection collection;
        int i8;
        int i10 = this.f2050d;
        int i11 = 7;
        i iVar = null;
        Object[] objArr = 0;
        Object[] objArr2 = 0;
        int i12 = 0;
        Object obj = this.f2052i;
        Object obj2 = this.f2051e;
        switch (i10) {
            case 0:
                Activity activity = (Activity) obj2;
                e1 e1Var = (e1) obj;
                if (activity != null) {
                    Intrinsics.checkNotNullParameter(activity, "<this>");
                    Window window = activity.getWindow();
                    z8.c cVar = new z8.c(activity.getWindow().getDecorView());
                    int i13 = Build.VERSION.SDK_INT;
                    o7.a f1Var = i13 >= 35 ? new f1(window, cVar, 1) : i13 >= 30 ? new d1(window, cVar, 1) : i13 >= 26 ? new l3.e1(window, cVar, 0) : new d1(window, cVar, 0);
                    f1Var.d0();
                    f1Var.c0();
                }
                e1Var.i(1.0f);
                return Unit.f4213a;
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                ((h) obj2).f2153c = (Function0) obj;
                return Unit.f4213a;
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                return o7.a.L((String) obj2, j.f2134j, new de.e[0], new ae.c(5, (m0) obj));
            case 3:
                de.e eVar = (de.e) obj2;
                ge.c cVar2 = (ge.c) obj;
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                ge.j jVar = cVar2.f2836a;
                l.n(eVar, cVar2);
                int iD = eVar.d();
                for (int i14 = 0; i14 < iD; i14++) {
                    List listI = eVar.i(i14);
                    ArrayList arrayList = new ArrayList();
                    for (Object obj3 : listI) {
                        if (obj3 instanceof u) {
                            arrayList.add(obj3);
                        }
                    }
                    Intrinsics.checkNotNullParameter(arrayList, "<this>");
                    u uVar = (u) (arrayList.size() == 1 ? arrayList.get(0) : null);
                    if (uVar != null && (strArrNames = uVar.names()) != null) {
                        for (String str : strArrNames) {
                            String str2 = Intrinsics.b(eVar.c(), de.i.f2130g) ? "enum value" : "property";
                            if (linkedHashMap.containsKey(str)) {
                                throw new f("The suggested name '" + str + "' for " + str2 + ' ' + eVar.e(i14) + " is already one of the names for " + str2 + ' ' + eVar.e(((Number) p0.d(str, linkedHashMap)).intValue()) + " in " + eVar);
                            }
                            linkedHashMap.put(str, Integer.valueOf(i14));
                        }
                    }
                }
                return linkedHashMap.isEmpty() ? p0.c() : linkedHashMap;
            case 4:
                v1 v1Var = (v1) obj2;
                v vVar = (v) obj;
                if (((Boolean) v1Var.f4730c.f5205d.invoke(w1.f4750i)).booleanValue()) {
                    y.p(vVar, null, new y0(v1Var, objArr == true ? 1 : 0, i11), 3);
                }
                return Boolean.TRUE;
            case 5:
                y.p((v) obj2, null, new p((f3) obj, objArr2 == true ? 1 : 0, i12), 3);
                return Boolean.TRUE;
            case 6:
                z0 z0Var = (z0) obj;
                ((q) obj2).C(z0Var.f6426a, z0Var.f6432g, z0Var.f6427b, true);
                return Unit.f4213a;
            case 7:
                j0 j0Var = (j0) obj2;
                x xVar = (x) obj;
                Object[] objArr3 = j0Var.f7274b;
                long[] jArr = j0Var.f7273a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i15 = 0;
                    while (true) {
                        long j8 = jArr[i15];
                        if ((((~j8) << 7) & j8 & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i16 = 8 - ((~(i15 - length)) >>> 31);
                            for (int i17 = 0; i17 < i16; i17++) {
                                if ((255 & j8) < 128) {
                                    xVar.A(objArr3[(i15 << 3) + i17]);
                                }
                                j8 >>= 8;
                            }
                            if (i16 == 8) {
                                if (i15 != length) {
                                    i15++;
                                }
                            }
                        }
                    }
                }
                return Unit.f4213a;
            case 8:
                ((g) obj2).e((Float) obj);
                return Unit.f4213a;
            case 9:
                y.f fVar = (y.f) obj2;
                z1.j0 j0Var2 = (z1.j0) obj;
                fVar.A = fVar.f8810v.a(j0Var2.f9362d.y(), j0Var2.getLayoutDirection(), j0Var2);
                return Unit.f4213a;
            case 10:
                ((c0) obj2).f3627d = z1.g.h((k) obj, k0.f8552a);
                return Unit.f4213a;
            default:
                q qVar = ((z0.c) obj2).f9245d;
                f2 f2Var = qVar.f6297c;
                if (!qVar.C) {
                    return i0.f4227d;
                }
                e2 e2VarE = f2Var.e();
                try {
                    a0 a0Var = new a0();
                    while (true) {
                        int i18 = a0Var.f3623d;
                        if (i18 < f2Var.f6191e) {
                            if (e2VarE.l(i18)) {
                                Object objN = e2VarE.n(a0Var.f3623d);
                                if (objN == obj) {
                                    break;
                                } else {
                                    b2 b2Var = objN instanceof b2 ? (b2) objN : null;
                                    if ((b2Var != null ? b2Var.f6146a : null) == obj) {
                                        break;
                                    }
                                }
                            }
                            int i19 = a0Var.f3623d;
                            int[] iArr = e2VarE.f6174b;
                            int iC = h2.c(iArr, i19);
                            int i20 = i19 + 1;
                            int i21 = (i20 < e2VarE.f6175c ? iArr[(i20 * 5) + 4] : e2VarE.f6177e) - iC;
                            i8 = 0;
                            while (i8 < i21) {
                                Object objH = e2VarE.h(a0Var.f3623d, i8);
                                if (objH != obj) {
                                    b2 b2Var2 = objH instanceof b2 ? (b2) objH : null;
                                    if ((b2Var2 != null ? b2Var2.f6146a : null) != obj) {
                                        i8++;
                                    }
                                }
                            }
                            a0Var.f3623d++;
                        } else {
                            Unit unit = Unit.f4213a;
                        }
                    }
                    iVar = new i(a0Var.f3623d, Integer.valueOf(i8));
                    if (iVar == null) {
                        return i0.f4227d;
                    }
                    int i22 = iVar.f9250a;
                    Integer num = iVar.f9251b;
                    if (qVar.C) {
                        e2 e2VarE2 = f2Var.e();
                        try {
                            ArrayList arrayListU = q3.a.u(e2VarE2, i22, num);
                            e2VarE2.c();
                            collection = arrayListU;
                        } finally {
                        }
                    } else {
                        collection = i0.f4227d;
                    }
                    return CollectionsKt.z(collection, qVar.E());
                } finally {
                }
        }
    }
}
