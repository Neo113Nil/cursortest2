package d6;

import ad.i;
import android.os.Build;
import android.os.ext.SdkExtensions;
import android.provider.MediaStore;
import androidx.lifecycle.o0;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import e.l;
import e6.j;
import e6.k;
import h.f;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import l0.f3;
import sd.h0;
import sd.v;
import sd.y;
import y2.s;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final class d extends i implements Function2 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2059d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f2060e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(Object obj, yc.a aVar, int i8) {
        super(2, aVar);
        this.f2059d = i8;
        this.f2060e = obj;
    }

    @Override // ad.a
    public final yc.a create(Object obj, yc.a aVar) {
        switch (this.f2059d) {
            case 0:
                return new d((e) this.f2060e, aVar, 0);
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                return new d((k) this.f2060e, aVar, 1);
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                return new d((h6.d) this.f2060e, aVar, 2);
            case 3:
                return new d((n6.b) this.f2060e, aVar, 3);
            case 4:
                return new d((l) this.f2060e, aVar, 4);
            case 5:
                return new d((f3) this.f2060e, aVar, 5);
            case 6:
                return new d((s) this.f2060e, aVar, 6);
            default:
                return new d((p8.d) this.f2060e, aVar, 7);
        }
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        v vVar = (v) obj;
        yc.a aVar = (yc.a) obj2;
        switch (this.f2059d) {
        }
        return ((d) create(vVar, aVar)).invokeSuspend(Unit.f4213a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // ad.a
    public final Object invokeSuspend(Object obj) throws IOException {
        int i8 = this.f2059d;
        yc.a aVar = null;
        boolean z5 = false;
        Object[] objArr = 0;
        int i10 = 1;
        Object obj2 = this.f2060e;
        switch (i8) {
            case 0:
                zc.a aVar2 = zc.a.f9574d;
                r1.c.r(obj);
                ((e) obj2).f2061b.a(r5.d.INSTANCE);
                return Unit.f4213a;
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                zc.a aVar3 = zc.a.f9574d;
                r1.c.r(obj);
                k kVar = (k) obj2;
                d4.a aVarH = o0.h(kVar);
                zd.e eVar = h0.f7142a;
                zd.d dVar = zd.d.f9607i;
                y.p(aVarH, dVar, new j(kVar, aVar, i10), 2);
                y.p(o0.h(kVar), dVar, new j(kVar, aVar, objArr == true ? 1 : 0), 2);
                return Unit.f4213a;
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                zc.a aVar4 = zc.a.f9574d;
                r1.c.r(obj);
                h6.d dVar2 = (h6.d) obj2;
                r5.c screen = r5.c.INSTANCE;
                dVar2.getClass();
                Intrinsics.checkNotNullParameter(screen, "screen");
                d4.a aVar5 = dVar2.f3034i;
                if (aVar5 != null) {
                    y.p(aVar5, null, new h6.b(dVar2, screen, null), 3);
                }
                return Unit.f4213a;
            case 3:
                zc.a aVar6 = zc.a.f9574d;
                r1.c.r(obj);
                ((n6.b) obj2).a();
                return Unit.f4213a;
            case 4:
                zc.a aVar7 = zc.a.f9574d;
                r1.c.r(obj);
                l lVar = (l) obj2;
                int i11 = Build.VERSION.SDK_INT;
                if (i11 >= 33 || (i11 >= 30 && SdkExtensions.getExtensionVersion(30) >= 2)) {
                    MediaStore.getPickImagesMaxLimit();
                }
                i.c mediaType = i.c.f3300a;
                Intrinsics.checkNotNullParameter(mediaType, "mediaType");
                i.a defaultTab = i.a.f3298a;
                Intrinsics.checkNotNullParameter(defaultTab, "defaultTab");
                if (i11 >= 33 || (i11 >= 30 && SdkExtensions.getExtensionVersion(30) >= 2)) {
                    MediaStore.getPickImagesMaxLimit();
                }
                Intrinsics.checkNotNullParameter(mediaType, "mediaType");
                Intrinsics.checkNotNullParameter(defaultTab, "defaultTab");
                f fVar = new f();
                fVar.f2880a = i.b.f3299a;
                if (i11 >= 33 || (i11 >= 30 && SdkExtensions.getExtensionVersion(30) >= 2)) {
                    MediaStore.getPickImagesMaxLimit();
                }
                fVar.f2881b = defaultTab;
                Intrinsics.checkNotNullParameter(mediaType, "<set-?>");
                fVar.f2880a = mediaType;
                Intrinsics.checkNotNullParameter(defaultTab, "<set-?>");
                fVar.f2881b = defaultTab;
                lVar.u(fVar);
                return Unit.f4213a;
            case 5:
                zc.a aVar8 = zc.a.f9574d;
                r1.c.r(obj);
                ((f3) obj2).a();
                return Unit.f4213a;
            case 6:
                zc.a aVar9 = zc.a.f9574d;
                r1.c.r(obj);
                ((s) obj2).show();
                return Unit.f4213a;
            default:
                zc.a aVar10 = zc.a.f9574d;
                r1.c.r(obj);
                ((p8.d) obj2).getClass();
                try {
                    Socket socket = new Socket();
                    try {
                        socket.connect(new InetSocketAddress("8.8.8.8", 53), 1500);
                        socket.close();
                        z5 = true;
                    } finally {
                    }
                } catch (IOException unused) {
                }
                return Boolean.valueOf(z5);
        }
    }
}
