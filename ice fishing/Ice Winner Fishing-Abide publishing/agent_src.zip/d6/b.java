package d6;

import a5.f;
import android.app.Activity;
import android.webkit.PermissionRequest;
import androidx.lifecycle.o0;
import c6.k;
import com.onesignal.core.activities.PermissionsActivity;
import com.onesignal.inAppMessages.internal.display.impl.a;
import java.util.List;
import k4.h;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import l0.v1;
import l0.w1;
import l0.y0;
import m0.d0;
import o0.a1;
import o0.e1;
import o0.e2;
import o0.q;
import o0.z0;
import sd.v;
import sd.y;
import t.x;
import w.r0;
import w.w;

/* compiled from: r8-map-id-e0104c0970d8abe65ef3406b0938c09421e00224e14686ef1bd4466c5758c682 */
/* loaded from: classes.dex */
public final /* synthetic */ class b implements Function0 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2053d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f2054e;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f2055i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f2056j;
    public final /* synthetic */ Object k;

    public /* synthetic */ b(Object obj, Object obj2, Object obj3, Object obj4, int i8) {
        this.f2053d = i8;
        this.f2055i = obj;
        this.f2056j = obj2;
        this.k = obj3;
        this.f2054e = obj4;
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x00e9  */
    @Override // kotlin.jvm.functions.Function0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke() {
        int i8 = this.f2053d;
        yc.a aVar = null;
        int i10 = 0;
        int i11 = 1;
        Object obj = this.f2054e;
        Object obj2 = this.k;
        Object obj3 = this.f2056j;
        Object obj4 = this.f2055i;
        switch (i8) {
            case 0:
                Activity activity = (Activity) obj4;
                e eVar = (e) obj3;
                e1 e1Var = (e1) obj2;
                a1 a1Var = (a1) obj;
                if (activity != null) {
                    q3.a.q(activity);
                }
                e1Var.i(0.0f);
                a1Var.setValue(Boolean.FALSE);
                eVar.getClass();
                y.p(o0.h(eVar), null, new d(eVar, aVar, i10), 3);
                return Unit.f4213a;
            case a.b.DRAGGABLE_DIRECTION_DOWN /* 1 */:
                a1 a1Var2 = (a1) obj;
                a1 a1Var3 = (a1) obj4;
                a1 a1Var4 = (a1) obj3;
                a1 a1Var5 = (a1) obj2;
                if (((PermissionRequest) a1Var2.getValue()) == null) {
                    a1Var3.setValue(Boolean.TRUE);
                }
                a1Var2.setValue(null);
                a1Var4.setValue(Boolean.FALSE);
                a1Var5.setValue(null);
                return Unit.f4213a;
            case PermissionsActivity.ONESIGNAL_PERMISSION_REQUEST_CODE /* 2 */:
                h hVar = (h) obj4;
                hVar.f4140c.setValue((h4.d) obj3);
                hVar.f4139b.setValue((List) obj2);
                hVar.f4141d.setValue((List) obj);
                return Unit.f4213a;
            case 3:
                v1 v1Var = (v1) obj4;
                v vVar = (v) obj3;
                w.c cVar = (w.c) obj2;
                Function0 function0 = (Function0) obj;
                if (((w1) v1Var.f4730c.f5208g.getValue()) == w1.f4749e) {
                    d0 d0VarD = v1Var.f4730c.d();
                    if (d0VarD.f5177a.containsKey(w1.f4750i)) {
                        y.p(vVar, null, new f(cVar, aVar, 2), 3);
                        y.p(vVar, null, new y0(v1Var, aVar, i10), 3);
                    } else {
                        y.p(vVar, null, new y0(v1Var, aVar, i11), 3).g(new k(function0, 1));
                    }
                }
                return Unit.f4213a;
            case 4:
                v1 v1Var2 = (v1) obj4;
                v1Var2.f4731d = (r0) obj3;
                v1Var2.f4732e = (r0) obj2;
                v1Var2.f4729b = (r0) obj;
                return Unit.f4213a;
            case 5:
                return new v1((Function0) obj4, (Function0) obj3, (w1) obj2, (Function1) obj);
            case 6:
                q qVar = (q) obj4;
                p0.a aVar2 = (p0.a) obj3;
                e2 e2Var = (e2) obj2;
                z0 z0Var = (z0) obj;
                p0.b bVar = qVar.M;
                p0.a aVar3 = bVar.f6561b;
                try {
                    bVar.f6561b = aVar2;
                    e2 e2Var2 = qVar.G;
                    int[] iArr = qVar.f6308o;
                    x xVar = qVar.f6315v;
                    qVar.f6308o = null;
                    qVar.f6315v = null;
                    try {
                        qVar.G = e2Var;
                        boolean z5 = bVar.f6564e;
                        try {
                            bVar.f6564e = false;
                            qVar.C(z0Var.f6426a, z0Var.f6432g, z0Var.f6427b, true);
                            bVar.f6564e = z5;
                            Unit unit = Unit.f4213a;
                            bVar.f6561b = aVar3;
                            return Unit.f4213a;
                        } catch (Throwable th) {
                            bVar.f6564e = z5;
                            throw th;
                        }
                    } finally {
                        qVar.G = e2Var2;
                        qVar.f6308o = iArr;
                        qVar.f6315v = xVar;
                    }
                } catch (Throwable th2) {
                    bVar.f6561b = aVar3;
                    throw th2;
                }
            default:
                Number number = (Number) obj4;
                w wVar = (w) obj3;
                Number number2 = (Number) obj2;
                w.v vVar2 = (w.v) obj;
                if (!number.equals(wVar.f8307d) || !number2.equals(wVar.f8308e)) {
                    wVar.f8307d = number;
                    wVar.f8308e = number2;
                    wVar.k = new w.y0(vVar2, wVar.f8309i, number, number2, null);
                    wVar.f8314o.f8326b.setValue(Boolean.TRUE);
                    wVar.f8311l = false;
                    wVar.f8312m = true;
                }
                return Unit.f4213a;
        }
    }

    public /* synthetic */ b(a1 a1Var, a1 a1Var2, a1 a1Var3, a1 a1Var4) {
        this.f2053d = 1;
        this.f2054e = a1Var;
        this.f2055i = a1Var2;
        this.f2056j = a1Var3;
        this.k = a1Var4;
    }
}
