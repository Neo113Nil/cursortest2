package com.kolosta.rejin.tarlyons;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/kolosta/rejin/tarlyons/MainActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class MainActivity extends androidx.activity.ComponentActivity {
    public static final /* synthetic */ int HEMPdThLdw2U4SnnXcc = 0;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) {
        int i = 17;
        androidx.activity.EdgeToEdge.uMOFIbPk0BxLkjW3KR7(this, new androidx.activity.SystemBarStyle(new defpackage.w2(i)), new androidx.activity.SystemBarStyle(new defpackage.w2(i)));
        super.onCreate(bundle);
        android.content.Context applicationContext = getApplicationContext();
        applicationContext.getClass();
        androidx.compose.runtime.internal.ComposableLambdaImpl composableLambdaImpl = new androidx.compose.runtime.internal.ComposableLambdaImpl(1215078572, new defpackage.d1(new com.kolosta.rejin.tarlyons.data.Store(applicationContext)), true);
        android.view.ViewGroup.LayoutParams layoutParams = androidx.activity.compose.ComponentActivityKt.uMOFIbPk0BxLkjW3KR7;
        android.view.View childAt = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        androidx.compose.ui.platform.ComposeView composeView = childAt instanceof androidx.compose.ui.platform.ComposeView ? (androidx.compose.ui.platform.ComposeView) childAt : null;
        if (composeView != null) {
            composeView.setParentCompositionContext(null);
            composeView.setContent(composableLambdaImpl);
            return;
        }
        androidx.compose.ui.platform.ComposeView composeView2 = new androidx.compose.ui.platform.ComposeView(this);
        composeView2.setParentCompositionContext(null);
        composeView2.setContent(composableLambdaImpl);
        android.view.View decorView = getWindow().getDecorView();
        if (androidx.lifecycle.ViewTreeLifecycleOwner.uMOFIbPk0BxLkjW3KR7(decorView) == null) {
            decorView.setTag(com.kolosta.rejin.tarlyons.R.id.view_tree_lifecycle_owner, this);
        }
        if (androidx.lifecycle.ViewTreeViewModelStoreOwner.uMOFIbPk0BxLkjW3KR7(decorView) == null) {
            decorView.setTag(com.kolosta.rejin.tarlyons.R.id.view_tree_view_model_store_owner, this);
        }
        if (androidx.os.ViewTreeSavedStateRegistryOwner.uMOFIbPk0BxLkjW3KR7(decorView) == null) {
            decorView.setTag(com.kolosta.rejin.tarlyons.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(composeView2, androidx.activity.compose.ComponentActivityKt.uMOFIbPk0BxLkjW3KR7);
    }
}
