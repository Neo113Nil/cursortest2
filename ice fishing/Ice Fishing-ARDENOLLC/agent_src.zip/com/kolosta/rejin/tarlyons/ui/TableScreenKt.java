package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class TableScreenKt {
    public static final void iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Snapshot snapshot, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, kotlin.jvm.functions.Function0 function03, androidx.compose.runtime.Composer composer, int i) {
        function0.getClass();
        function02.getClass();
        function03.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-1200661372);
        int i2 = (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 4 : 2) | i | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function0) ? 32 : 16);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 1171) != 1170)) {
            com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(-1079885058, new defpackage.g4(function0, function02, function03, snapshot, 0), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 6);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.FX004kfxrsfllcl6Fp5(snapshot, function0, function02, function03, i, 4));
        }
    }

    public static final void uMOFIbPk0BxLkjW3KR7(java.lang.String str, java.lang.String str2, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.Composer composer2;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(635877282);
        int i2 = i | (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(str) ? 4 : 2);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 19) != 18)) {
            androidx.compose.foundation.layout.ColumnMeasurePolicy columnMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.ColumnKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.VddF2l9gapSy7l41Z9d, androidx.compose.ui.Alignment.Companion.wDaxnHzF6aHr1xEjAAF, composerBn6dcy3rRNTGfMyxjUW, 48);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getGerKUYaWR62lFxYixsm());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, columnMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(str, null, 0L, 0L, null, 0L, new androidx.compose.ui.text.style.TextAlign(3), 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.ui.KitKt.iCK2U69IDurvZVodhWo, com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(16), null, null, 0L, 0L, null, 16777212), composerBn6dcy3rRNTGfMyxjUW, i2 & 14, 0, 130046);
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(str2, null, 0L, 0L, null, 0L, new androidx.compose.ui.text.style.TextAlign(3), 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm, 0L, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(12), null, null, 0L, 0L, null, 16777213), composerBn6dcy3rRNTGfMyxjUW, 6, 0, 130046);
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.ToXgQAFEcwNMApTHMKw();
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.DE7Rhsvt8w1IRy6qh6p(i, 9, str, str2));
        }
    }
}
