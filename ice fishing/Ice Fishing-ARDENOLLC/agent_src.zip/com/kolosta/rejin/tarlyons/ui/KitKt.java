package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class KitKt {
    public static final androidx.compose.ui.graphics.ColorMatrixColorFilter A39SiWGux5Rbalqx5tb;
    public static final androidx.compose.ui.text.TextStyle GerKUYaWR62lFxYixsm;
    public static final androidx.compose.ui.text.TextStyle VddF2l9gapSy7l41Z9d;
    public static final androidx.compose.ui.text.TextStyle iCK2U69IDurvZVodhWo;
    public static final androidx.compose.ui.text.TextStyle uMOFIbPk0BxLkjW3KR7;

    static {
        androidx.compose.ui.text.font.FontWeight fontWeight = androidx.compose.ui.text.font.FontWeight.G069ZlNT3DZHrdUtBui;
        uMOFIbPk0BxLkjW3KR7 = new androidx.compose.ui.text.TextStyle(com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(30), fontWeight, 0L, 0, 0, 0L, 16777176);
        long j = com.kolosta.rejin.tarlyons.ui.Glaze.PMZrLoc0NF3euziS99o;
        iCK2U69IDurvZVodhWo = new androidx.compose.ui.text.TextStyle(j, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(18), fontWeight, 0L, 0, 0, 0L, 16777208);
        VddF2l9gapSy7l41Z9d = new androidx.compose.ui.text.TextStyle(j, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(15), null, 0L, 0, 0, 0L, 16777212);
        GerKUYaWR62lFxYixsm = new androidx.compose.ui.text.TextStyle(com.kolosta.rejin.tarlyons.ui.Glaze.EYwcyipzkILQreEEPxc, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(13), null, 0L, 0, 0, 0L, 16777212);
        float[] fArr = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f};
        fArr[0] = 1.0f;
        fArr[1] = 0.0f;
        fArr[2] = 0.0f;
        fArr[3] = 0.0f;
        fArr[4] = 0.0f;
        fArr[5] = 0.0f;
        fArr[6] = 1.0f;
        fArr[7] = 0.0f;
        fArr[8] = 0.0f;
        fArr[9] = 0.0f;
        fArr[10] = 0.0f;
        fArr[11] = 0.0f;
        fArr[12] = 1.0f;
        fArr[13] = 0.0f;
        fArr[14] = 0.0f;
        fArr[15] = 0.0f;
        fArr[16] = 0.0f;
        fArr[17] = 0.0f;
        fArr[18] = 1.0f;
        fArr[19] = 0.0f;
        fArr[0] = 0.213f;
        fArr[1] = 0.715f;
        fArr[2] = 0.072f;
        fArr[5] = 0.213f;
        fArr[6] = 0.715f;
        fArr[7] = 0.072f;
        fArr[10] = 0.213f;
        fArr[11] = 0.715f;
        fArr[12] = 0.072f;
        androidx.compose.ui.graphics.ColorMatrixColorFilter colorMatrixColorFilter = new androidx.compose.ui.graphics.ColorMatrixColorFilter(new android.graphics.ColorMatrixColorFilter(fArr));
        colorMatrixColorFilter.iCK2U69IDurvZVodhWo = fArr;
        A39SiWGux5Rbalqx5tb = colorMatrixColorFilter;
    }

    public static final void A39SiWGux5Rbalqx5tb(java.lang.String str, java.lang.String str2, androidx.compose.runtime.Composer composer, int i) {
        int i2;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-759736063);
        if ((i & 6) == 0) {
            i2 = (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(str) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(str2) ? 32 : 16;
        }
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 19) != 18)) {
            GerKUYaWR62lFxYixsm(androidx.compose.foundation.layout.PaddingKt.lVvt79Js7aeYnsjUe7L(androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm, 0.0f, 4.0f, 0.0f, 0.0f, 13), 0.0f, androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(-612209080, new defpackage.GJa23xugvNVM6O8amiG(3, str, str2), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 390, 2);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.l75NXPNn5idGpEzYK2S(i, 5, str, str2));
        }
    }

    public static final void GerKUYaWR62lFxYixsm(final androidx.compose.ui.Modifier modifier, float f, final androidx.compose.runtime.internal.ComposableLambdaImpl composableLambdaImpl, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(816823293);
        if ((i & 6) == 0) {
            i3 = (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(modifier) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            i3 |= composerBn6dcy3rRNTGfMyxjUW.JjLaFjoHTCoTSMjQa7q(f) ? 32 : 16;
        }
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i3 & 1, (i3 & 147) != 146)) {
            if (i4 != 0) {
                f = 14.0f;
            }
            androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7(16.0f);
            androidx.compose.ui.Modifier modifierPMZrLoc0NF3euziS99o = androidx.compose.foundation.layout.PaddingKt.PMZrLoc0NF3euziS99o(androidx.compose.foundation.BorderKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(androidx.compose.ui.draw.ClipKt.uMOFIbPk0BxLkjW3KR7(modifier, roundedCornerShapeUMOFIbPk0BxLkjW3KR7), androidx.compose.ui.graphics.Color.iCK2U69IDurvZVodhWo(0.97f, com.kolosta.rejin.tarlyons.ui.Glaze.VddF2l9gapSy7l41Z9d), androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7), 1.5f, com.kolosta.rejin.tarlyons.ui.Glaze.GerKUYaWR62lFxYixsm, roundedCornerShapeUMOFIbPk0BxLkjW3KR7), f);
            androidx.compose.foundation.layout.ColumnMeasurePolicy columnMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.ColumnKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.EYwcyipzkILQreEEPxc(8.0f), androidx.compose.ui.Alignment.Companion.wDaxnHzF6aHr1xEjAAF, composerBn6dcy3rRNTGfMyxjUW, 54);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierPMZrLoc0NF3euziS99o);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, columnMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            composableLambdaImpl.G069ZlNT3DZHrdUtBui(androidx.compose.foundation.layout.ColumnScopeInstance.uMOFIbPk0BxLkjW3KR7, composerBn6dcy3rRNTGfMyxjUW, 54);
            composerBn6dcy3rRNTGfMyxjUW.ToXgQAFEcwNMApTHMKw();
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        final float f2 = f;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2() { // from class: m0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm(modifier, f2, composableLambdaImpl, (androidx.compose.runtime.Composer) obj, androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(i | 1), i2);
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            });
        }
    }

    public static final androidx.compose.ui.graphics.LightingColorFilter PMZrLoc0NF3euziS99o(com.kolosta.rejin.tarlyons.data.Tint tint) {
        tint.getClass();
        if (tint == com.kolosta.rejin.tarlyons.data.Tint.GOLD) {
            return null;
        }
        long jGerKUYaWR62lFxYixsm = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(tint.getColor());
        return new androidx.compose.ui.graphics.LightingColorFilter(androidx.compose.ui.graphics.ColorKt.uMOFIbPk0BxLkjW3KR7((androidx.compose.ui.graphics.Color.j0yhOfa7n1b2lkVBAKt(jGerKUYaWR62lFxYixsm) * 0.5f) + 0.5f, (androidx.compose.ui.graphics.Color.EYwcyipzkILQreEEPxc(jGerKUYaWR62lFxYixsm) * 0.5f) + 0.5f, (androidx.compose.ui.graphics.Color.A39SiWGux5Rbalqx5tb(jGerKUYaWR62lFxYixsm) * 0.5f) + 0.5f, 1.0f, androidx.compose.ui.graphics.colorspace.ColorSpaces.A39SiWGux5Rbalqx5tb), androidx.compose.ui.graphics.Color.iCK2U69IDurvZVodhWo);
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0208  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0216  */
    /* JADX WARN: Removed duplicated region for block: B:94:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void VddF2l9gapSy7l41Z9d(final java.lang.String str, final kotlin.jvm.functions.Function0 function0, androidx.compose.ui.Modifier modifier, boolean z, boolean z2, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        java.lang.String str2;
        int i3;
        androidx.compose.ui.Modifier modifier2;
        int i4;
        boolean z3;
        int i5;
        boolean z4;
        int i6;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.Modifier modifier3;
        final boolean z5;
        final boolean z6;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv;
        function0.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-254148437);
        if ((i & 6) == 0) {
            str2 = str;
            i3 = (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(str2) ? 4 : 2) | i;
        } else {
            str2 = str;
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function0) ? 32 : 16;
        }
        int i7 = i2 & 4;
        if (i7 != 0) {
            i3 |= 384;
        } else {
            if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(modifier2) ? 256 : 128;
            }
            i4 = i2 & 8;
            if (i4 != 0) {
                if ((i & 3072) == 0) {
                    z3 = z;
                    i3 |= composerBn6dcy3rRNTGfMyxjUW.GerKUYaWR62lFxYixsm(z3) ? 2048 : 1024;
                }
                i5 = i2 & 16;
                if (i5 != 0) {
                    i6 = i3 | 24576;
                    z4 = z2;
                } else {
                    z4 = z2;
                    i6 = i3 | (composerBn6dcy3rRNTGfMyxjUW.GerKUYaWR62lFxYixsm(z4) ? 16384 : 8192);
                }
                if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i6 & 1, (i6 & 9363) != 9362)) {
                    androidx.compose.ui.Modifier modifier4 = i7 != 0 ? androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm : modifier2;
                    boolean z7 = i4 != 0 ? true : z3;
                    boolean z8 = i5 != 0 ? true : z4;
                    androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7(14.0f);
                    androidx.compose.ui.Modifier modifierEYwcyipzkILQreEEPxc = androidx.compose.foundation.layout.PaddingKt.EYwcyipzkILQreEEPxc(androidx.compose.foundation.ClickableKt.VddF2l9gapSy7l41Z9d(androidx.compose.foundation.BorderKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.ui.draw.ClipKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.SizeKt.A39SiWGux5Rbalqx5tb(modifier4, 50.0f, 0.0f, 2), roundedCornerShapeUMOFIbPk0BxLkjW3KR7), !z8 ? androidx.compose.ui.graphics.Brush.Companion.uMOFIbPk0BxLkjW3KR7(kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280430665L)), new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280101183L)))) : z7 ? androidx.compose.ui.graphics.Brush.Companion.uMOFIbPk0BxLkjW3KR7(kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4293970798L)), new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4291401519L)))) : androidx.compose.ui.graphics.Brush.Companion.uMOFIbPk0BxLkjW3KR7(kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280958300L)), new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280431180L))))), 1.5f, !z8 ? com.kolosta.rejin.tarlyons.ui.Glaze.GerKUYaWR62lFxYixsm : z7 ? androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4294961064L) : androidx.compose.ui.graphics.Color.iCK2U69IDurvZVodhWo(0.6f, com.kolosta.rejin.tarlyons.ui.Glaze.lVvt79Js7aeYnsjUe7L), roundedCornerShapeUMOFIbPk0BxLkjW3KR7), z8, null, function0, 14), 16.0f, 12.0f);
                    androidx.compose.ui.layout.MeasurePolicy measurePolicyGerKUYaWR62lFxYixsm = androidx.compose.foundation.layout.BoxKt.GerKUYaWR62lFxYixsm(androidx.compose.ui.Alignment.Companion.A39SiWGux5Rbalqx5tb, false);
                    int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
                    androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
                    androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierEYwcyipzkILQreEEPxc);
                    androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
                    kotlin.jvm.functions.Function0 function02 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
                    if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                        androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                        throw null;
                    }
                    composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
                    if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                        composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function02);
                    } else {
                        composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
                    }
                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, measurePolicyGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
                    androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
                    androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
                    androidx.compose.ui.text.font.FontWeight fontWeight = androidx.compose.ui.text.font.FontWeight.G069ZlNT3DZHrdUtBui;
                    composer2 = composerBn6dcy3rRNTGfMyxjUW;
                    androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(str2, null, !z8 ? com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt : z7 ? com.kolosta.rejin.tarlyons.ui.Glaze.iCK2U69IDurvZVodhWo : com.kolosta.rejin.tarlyons.ui.Glaze.PMZrLoc0NF3euziS99o, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(16), fontWeight, 0L, new androidx.compose.ui.text.style.TextAlign(3), 0L, 0, false, 0, 0, null, composer2, (i6 & 14) | 1597440, 0, 261034);
                    composer2.ToXgQAFEcwNMApTHMKw();
                    modifier3 = modifier4;
                    z5 = z7;
                    z6 = z8;
                } else {
                    composer2 = composerBn6dcy3rRNTGfMyxjUW;
                    composer2.PMZrLoc0NF3euziS99o();
                    modifier3 = modifier2;
                    z5 = z3;
                    z6 = z4;
                }
                scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
                if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
                    scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2() { // from class: n0
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                            ((java.lang.Integer) obj2).getClass();
                            com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d(str, function0, modifier3, z5, z6, (androidx.compose.runtime.Composer) obj, androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(i | 1), i2);
                            return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                        }
                    });
                    return;
                }
                return;
            }
            i3 |= 3072;
            z3 = z;
            i5 = i2 & 16;
            if (i5 != 0) {
            }
            if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i6 & 1, (i6 & 9363) != 9362)) {
            }
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
            if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            }
        }
        modifier2 = modifier;
        i4 = i2 & 8;
        if (i4 != 0) {
        }
        z3 = z;
        i5 = i2 & 16;
        if (i5 != 0) {
        }
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i6 & 1, (i6 & 9363) != 9362)) {
        }
        scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
        }
    }

    public static final void iCK2U69IDurvZVodhWo(final int i, final float f, long j, androidx.compose.runtime.Composer composer, final int i2, final int i3) {
        final long j2;
        int i4;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(513045018);
        int i5 = i2 | (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i) ? 4 : 2);
        int i6 = i3 & 4;
        if (i6 != 0) {
            i4 = i5 | 384;
            j2 = j;
        } else {
            j2 = j;
            i4 = i5 | (composerBn6dcy3rRNTGfMyxjUW.Dpa63RlwGiNbcDAIHuO(j2) ? 256 : 128);
        }
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i4 & 1, (i4 & 147) != 146)) {
            if (i6 != 0) {
                j2 = com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb;
            }
            androidx.compose.foundation.layout.RowMeasurePolicy rowMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.RowKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.EYwcyipzkILQreEEPxc(0.3f * f), androidx.compose.ui.Alignment.Companion.G069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 0);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm;
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, companion);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, rowMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(-431153272);
            for (final int i7 = 0; i7 < 3; i7++) {
                androidx.compose.ui.Modifier modifierG069ZlNT3DZHrdUtBui = androidx.compose.foundation.layout.SizeKt.G069ZlNT3DZHrdUtBui(companion, f);
                boolean zGzg71nUFKNF0JyxrFIK = composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i7) | ((i4 & 14) == 4) | ((i4 & 896) == 256);
                java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (zGzg71nUFKNF0JyxrFIK || objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                    objG069ZlNT3DZHrdUtBui = new kotlin.jvm.functions.Function1() { // from class: o0
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                            androidx.compose.ui.graphics.drawscope.DrawScope drawScope = (androidx.compose.ui.graphics.drawscope.DrawScope) obj;
                            androidx.compose.ui.text.TextStyle textStyle = com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7;
                            drawScope.getClass();
                            float fIntBitsToFloat = java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() >> 32));
                            float fIntBitsToFloat2 = java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() & 4294967295L));
                            androidx.compose.ui.graphics.AndroidPath androidPathUMOFIbPk0BxLkjW3KR7 = androidx.compose.ui.graphics.AndroidPath_androidKt.uMOFIbPk0BxLkjW3KR7();
                            float f2 = fIntBitsToFloat / 2.0f;
                            androidPathUMOFIbPk0BxLkjW3KR7.VddF2l9gapSy7l41Z9d(f2, 0.0f);
                            float f3 = fIntBitsToFloat2 * 0.45f;
                            float f4 = fIntBitsToFloat2 * 0.62f;
                            float f5 = fIntBitsToFloat2 * 0.8f;
                            androidPathUMOFIbPk0BxLkjW3KR7.GerKUYaWR62lFxYixsm(fIntBitsToFloat * 0.95f, f3, fIntBitsToFloat, f4, fIntBitsToFloat * 0.88f, f5);
                            float f6 = fIntBitsToFloat2 * 1.02f;
                            androidPathUMOFIbPk0BxLkjW3KR7.GerKUYaWR62lFxYixsm(fIntBitsToFloat * 0.7f, f6, fIntBitsToFloat * 0.3f, f6, fIntBitsToFloat * 0.12f, f5);
                            androidPathUMOFIbPk0BxLkjW3KR7.GerKUYaWR62lFxYixsm(0.0f, f4, fIntBitsToFloat * 0.05f, f3, f2, 0.0f);
                            androidPathUMOFIbPk0BxLkjW3KR7.close();
                            if (i7 < i) {
                                androidx.compose.ui.graphics.drawscope.DrawScope.rBFauuziN1541ugrs7h(drawScope, androidPathUMOFIbPk0BxLkjW3KR7, j2, 0.0f, null, 60);
                                androidx.compose.ui.graphics.drawscope.DrawScope.sC3avyxZw3CXKHdQYJZ(drawScope, androidx.compose.ui.graphics.Color.iCK2U69IDurvZVodhWo(0.55f, androidx.compose.ui.graphics.Color.VddF2l9gapSy7l41Z9d), 0.1f * fIntBitsToFloat, (java.lang.Float.floatToRawIntBits(fIntBitsToFloat * 0.38f) << 32) | (java.lang.Float.floatToRawIntBits(f4) & 4294967295L), 120);
                            } else {
                                androidx.compose.ui.graphics.drawscope.DrawScope.rBFauuziN1541ugrs7h(drawScope, androidPathUMOFIbPk0BxLkjW3KR7, com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt, 0.0f, new androidx.compose.ui.graphics.drawscope.Stroke(drawScope.FX004kfxrsfllcl6Fp5(1.6f), 0.0f, 0, 0, 30), 52);
                            }
                            return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
                }
                androidx.compose.foundation.CanvasKt.uMOFIbPk0BxLkjW3KR7(modifierG069ZlNT3DZHrdUtBui, (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 0);
            }
            composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
            composerBn6dcy3rRNTGfMyxjUW.ToXgQAFEcwNMApTHMKw();
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        final long j3 = j2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2(i, f, j3, i2, i3) { // from class: p0
                public final /* synthetic */ float A39SiWGux5Rbalqx5tb;
                public final /* synthetic */ int EYwcyipzkILQreEEPxc;
                public final /* synthetic */ int GerKUYaWR62lFxYixsm;
                public final /* synthetic */ long PMZrLoc0NF3euziS99o;

                {
                    this.EYwcyipzkILQreEEPxc = i3;
                }

                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iUMOFIbPk0BxLkjW3KR7 = androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(49);
                    com.kolosta.rejin.tarlyons.ui.KitKt.iCK2U69IDurvZVodhWo(this.GerKUYaWR62lFxYixsm, this.A39SiWGux5Rbalqx5tb, this.PMZrLoc0NF3euziS99o, (androidx.compose.runtime.Composer) obj, iUMOFIbPk0BxLkjW3KR7, this.EYwcyipzkILQreEEPxc);
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            });
        }
    }

    public static final void uMOFIbPk0BxLkjW3KR7(androidx.compose.runtime.internal.ComposableLambdaImpl composableLambdaImpl, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(103344580);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i & 1, (i & 3) != 2)) {
            androidx.compose.ui.Modifier modifierUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.BackgroundKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.SizeKt.VddF2l9gapSy7l41Z9d, androidx.compose.ui.graphics.Brush.Companion.uMOFIbPk0BxLkjW3KR7(kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(new androidx.compose.ui.graphics.Color(com.kolosta.rejin.tarlyons.ui.Glaze.iCK2U69IDurvZVodhWo), new androidx.compose.ui.graphics.Color(com.kolosta.rejin.tarlyons.ui.Glaze.uMOFIbPk0BxLkjW3KR7), new androidx.compose.ui.graphics.Color(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4279970368L)))));
            androidx.compose.ui.layout.MeasurePolicy measurePolicyGerKUYaWR62lFxYixsm = androidx.compose.foundation.layout.BoxKt.GerKUYaWR62lFxYixsm(androidx.compose.ui.Alignment.Companion.uMOFIbPk0BxLkjW3KR7, false);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierUMOFIbPk0BxLkjW3KR7);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, measurePolicyGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            composableLambdaImpl.G069ZlNT3DZHrdUtBui(androidx.compose.foundation.layout.BoxScopeInstance.uMOFIbPk0BxLkjW3KR7, composerBn6dcy3rRNTGfMyxjUW, 54);
            composerBn6dcy3rRNTGfMyxjUW.ToXgQAFEcwNMApTHMKw();
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.l0(composableLambdaImpl, i, 0));
        }
    }
}
