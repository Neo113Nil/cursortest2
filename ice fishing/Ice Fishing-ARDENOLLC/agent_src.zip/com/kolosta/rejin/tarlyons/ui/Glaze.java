package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/ui/Glaze;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Glaze {
    public static final long uMOFIbPk0BxLkjW3KR7 = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4279376942L);
    public static final long iCK2U69IDurvZVodhWo = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4278981410L);
    public static final long VddF2l9gapSy7l41Z9d = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280035906L);
    public static final long GerKUYaWR62lFxYixsm = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4282077811L);
    public static final long A39SiWGux5Rbalqx5tb = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4293047886L);
    public static final long PMZrLoc0NF3euziS99o = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4294112761L);
    public static final long EYwcyipzkILQreEEPxc = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4290430936L);
    public static final long j0yhOfa7n1b2lkVBAKt = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4287404976L);
    public static final long lVvt79Js7aeYnsjUe7L = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4290763246L);

    static {
        androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4294945440L);
    }
}
