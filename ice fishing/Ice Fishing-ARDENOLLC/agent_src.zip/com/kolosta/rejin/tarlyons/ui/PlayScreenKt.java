package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002¨\u0006\b²\u0006\u000e\u0010\u0001\u001a\u00020\u00008\n@\nX\u008a\u008e\u0002²\u0006\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u00028\n@\nX\u008a\u008e\u0002²\u0006\u0018\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u00048\nX\u008a\u0084\u0002"}, d2 = {"", "paused", "Lcom/kolosta/rejin/tarlyons/game/SeamView;", "view", "Lkotlin/Function1;", "Lcom/kolosta/rejin/tarlyons/game/RunResult;", "", "finished", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PlayScreenKt {
    public static final void uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.game.Tray tray, com.kolosta.rejin.tarlyons.data.Tint tint, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.Composer composer2;
        kotlin.jvm.functions.Function2 function2;
        androidx.compose.foundation.layout.FillElement fillElement;
        androidx.compose.runtime.MutableState mutableState;
        kotlin.jvm.functions.Function2 function22;
        kotlin.jvm.functions.Function0 function02;
        kotlin.jvm.functions.Function1 function12;
        kotlin.jvm.functions.Function2 function23;
        androidx.compose.runtime.MutableState mutableState2;
        kotlin.jvm.functions.Function0 function03 = function0;
        function1.getClass();
        function03.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(521869692);
        int i2 = i | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(tray) ? 4 : 2) | (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(tint.ordinal()) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function1) ? 256 : 128);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 1171) != 1170)) {
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            androidx.compose.runtime.Composer$Companion$Empty$1 composer$Companion$Empty$1 = androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7;
            if (objG069ZlNT3DZHrdUtBui == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui = androidx.compose.runtime.SnapshotStateKt.PMZrLoc0NF3euziS99o(java.lang.Boolean.FALSE);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            }
            androidx.compose.runtime.MutableState mutableState3 = (androidx.compose.runtime.MutableState) objG069ZlNT3DZHrdUtBui;
            java.lang.Object objG069ZlNT3DZHrdUtBui2 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui2 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui2 = androidx.compose.runtime.SnapshotStateKt.PMZrLoc0NF3euziS99o(null);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui2);
            }
            androidx.compose.runtime.MutableState mutableState4 = (androidx.compose.runtime.MutableState) objG069ZlNT3DZHrdUtBui2;
            androidx.compose.runtime.MutableState mutableStateG069ZlNT3DZHrdUtBui = androidx.compose.runtime.SnapshotStateKt.G069ZlNT3DZHrdUtBui(function1, composerBn6dcy3rRNTGfMyxjUW);
            androidx.compose.ui.unit.Density density = (androidx.compose.ui.unit.Density) composerBn6dcy3rRNTGfMyxjUW.j0yhOfa7n1b2lkVBAKt(androidx.compose.ui.platform.CompositionLocalsKt.j0yhOfa7n1b2lkVBAKt);
            final float fUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.WindowInsets_androidKt.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW).uMOFIbPk0BxLkjW3KR7(density);
            final float fICK2U69IDurvZVodhWo = androidx.compose.foundation.layout.WindowInsets_androidKt.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW).iCK2U69IDurvZVodhWo(density);
            java.lang.Object objG069ZlNT3DZHrdUtBui3 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui3 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui3 = new defpackage.p0GfW29syb65Z7G2oVR(function03, 1);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui3);
            }
            androidx.activity.compose.BackHandlerKt.uMOFIbPk0BxLkjW3KR7(false, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui3, composerBn6dcy3rRNTGfMyxjUW, 0, 1);
            androidx.compose.foundation.layout.FillElement fillElement2 = androidx.compose.foundation.layout.SizeKt.VddF2l9gapSy7l41Z9d;
            long j = com.kolosta.rejin.tarlyons.ui.Glaze.iCK2U69IDurvZVodhWo;
            androidx.compose.ui.graphics.RectangleShapeKt$RectangleShape$1 rectangleShapeKt$RectangleShape$1 = androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7;
            androidx.compose.ui.Modifier modifierICK2U69IDurvZVodhWo = androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(fillElement2, j, rectangleShapeKt$RectangleShape$1);
            androidx.compose.ui.layout.MeasurePolicy measurePolicyGerKUYaWR62lFxYixsm = androidx.compose.foundation.layout.BoxKt.GerKUYaWR62lFxYixsm(androidx.compose.ui.Alignment.Companion.uMOFIbPk0BxLkjW3KR7, false);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getGerKUYaWR62lFxYixsm());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierICK2U69IDurvZVodhWo);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function04 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function04);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            kotlin.jvm.functions.Function2 function24 = androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, measurePolicyGerKUYaWR62lFxYixsm, function24);
            kotlin.jvm.functions.Function2 function25 = androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, function25);
            java.lang.Integer numValueOf = java.lang.Integer.valueOf(iHashCode);
            kotlin.jvm.functions.Function2 function26 = androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc;
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, numValueOf, function26);
            kotlin.jvm.functions.Function1 function13 = androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt;
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, function13);
            kotlin.jvm.functions.Function2 function27 = androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, function27);
            boolean zH0jYF7Mc76EKIPcCXvq = composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(tray) | ((i2 & 112) == 32) | composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(mutableStateG069ZlNT3DZHrdUtBui);
            java.lang.Object objG069ZlNT3DZHrdUtBui4 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (zH0jYF7Mc76EKIPcCXvq || objG069ZlNT3DZHrdUtBui4 == composer$Companion$Empty$1) {
                function2 = function27;
                fillElement = fillElement2;
                mutableState = mutableState4;
                function22 = function25;
                function02 = function04;
                function12 = function13;
                function23 = function26;
                defpackage.JkKMrfloFo2xH4UTgso jkKMrfloFo2xH4UTgso = new defpackage.JkKMrfloFo2xH4UTgso(tray, tint, mutableState3, mutableStateG069ZlNT3DZHrdUtBui, mutableState, 2);
                mutableState2 = mutableState3;
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(jkKMrfloFo2xH4UTgso);
                objG069ZlNT3DZHrdUtBui4 = jkKMrfloFo2xH4UTgso;
            } else {
                function2 = function27;
                fillElement = fillElement2;
                mutableState = mutableState4;
                function22 = function25;
                mutableState2 = mutableState3;
                function02 = function04;
                function12 = function13;
                function23 = function26;
            }
            kotlin.jvm.functions.Function1 function14 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui4;
            java.lang.Object objG069ZlNT3DZHrdUtBui5 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui5 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui5 = new defpackage.r0(22);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui5);
            }
            kotlin.jvm.functions.Function1 function15 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui5;
            boolean zJjLaFjoHTCoTSMjQa7q = composerBn6dcy3rRNTGfMyxjUW.JjLaFjoHTCoTSMjQa7q(fUMOFIbPk0BxLkjW3KR7) | composerBn6dcy3rRNTGfMyxjUW.JjLaFjoHTCoTSMjQa7q(fICK2U69IDurvZVodhWo);
            java.lang.Object objG069ZlNT3DZHrdUtBui6 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (zJjLaFjoHTCoTSMjQa7q || objG069ZlNT3DZHrdUtBui6 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui6 = new kotlin.jvm.functions.Function1() { // from class: v1
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                        com.kolosta.rejin.tarlyons.game.SeamView seamView = (com.kolosta.rejin.tarlyons.game.SeamView) obj;
                        seamView.getClass();
                        seamView.setInsetTop(fUMOFIbPk0BxLkjW3KR7);
                        seamView.setInsetBottom(fICK2U69IDurvZVodhWo);
                        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                    }
                };
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui6);
            }
            kotlin.jvm.functions.Function1 function16 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui6;
            androidx.compose.runtime.MutableState mutableState5 = mutableState;
            androidx.compose.foundation.layout.FillElement fillElement3 = fillElement;
            androidx.compose.ui.viewinterop.AndroidView_androidKt.uMOFIbPk0BxLkjW3KR7(function14, fillElement3, function15, function16, composerBn6dcy3rRNTGfMyxjUW, 3120);
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            if (((java.lang.Boolean) mutableState2.getGerKUYaWR62lFxYixsm()).booleanValue()) {
                composer2.JnYgR1cE6e0Di97yUx9(-27018349);
                androidx.compose.ui.Modifier modifierICK2U69IDurvZVodhWo2 = androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(fillElement3, androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(3641447202L), rectangleShapeKt$RectangleShape$1);
                java.lang.Object objG069ZlNT3DZHrdUtBui7 = composer2.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui7 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui7 = androidx.compose.foundation.interaction.InteractionSourceKt.uMOFIbPk0BxLkjW3KR7();
                    composer2.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui7);
                }
                androidx.compose.foundation.interaction.MutableInteractionSource mutableInteractionSource = (androidx.compose.foundation.interaction.MutableInteractionSource) objG069ZlNT3DZHrdUtBui7;
                java.lang.Object objG069ZlNT3DZHrdUtBui8 = composer2.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui8 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui8 = new defpackage.Q9Nq566vXkbJ4Iw58qn(11);
                    composer2.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui8);
                }
                androidx.compose.ui.Modifier modifierICK2U69IDurvZVodhWo3 = androidx.compose.foundation.ClickableKt.iCK2U69IDurvZVodhWo(modifierICK2U69IDurvZVodhWo2, mutableInteractionSource, null, false, null, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui8, 28);
                androidx.compose.ui.layout.MeasurePolicy measurePolicyGerKUYaWR62lFxYixsm2 = androidx.compose.foundation.layout.BoxKt.GerKUYaWR62lFxYixsm(androidx.compose.ui.Alignment.Companion.A39SiWGux5Rbalqx5tb, false);
                int iHashCode2 = java.lang.Long.hashCode(composer2.getGerKUYaWR62lFxYixsm());
                androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2 = composer2.Q9Nq566vXkbJ4Iw58qn();
                androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm2 = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composer2, modifierICK2U69IDurvZVodhWo3);
                if (composer2.v5wzXFgUOh8fr6SrmDF() == null) {
                    androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                    throw null;
                }
                composer2.fjT7LSJoZG8JrehrlZO();
                if (composer2.getBo9jv9ivHpNCfjAX1nQ()) {
                    composer2.Bo9jv9ivHpNCfjAX1nQ(function02);
                } else {
                    composer2.X1I3PnLZJSbM9AFq8Rp();
                }
                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer2, measurePolicyGerKUYaWR62lFxYixsm2, function24);
                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer2, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2, function22);
                androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composer2, java.lang.Integer.valueOf(iHashCode2), function23);
                androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composer2, function12);
                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer2, modifierGerKUYaWR62lFxYixsm2, function2);
                function03 = function0;
                com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm(androidx.compose.foundation.layout.SizeKt.cwoLH2FPi4AIU5DJOyN(androidx.compose.foundation.layout.PaddingKt.PMZrLoc0NF3euziS99o(androidx.compose.foundation.layout.WindowInsetsPadding_androidKt.iCK2U69IDurvZVodhWo(androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm), 24.0f), 420.0f).D0JJE4YKDOyimkkLitC(androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7), 20.0f, androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(731667342, new defpackage.GJa23xugvNVM6O8amiG(4, function03, mutableState5), composer2), composer2, 432, 0);
                composer2.ToXgQAFEcwNMApTHMKw();
            } else {
                function03 = function0;
                composer2.JnYgR1cE6e0Di97yUx9(-29697524);
            }
            composer2.zw4zyD7jgFPVK81d6J1();
            composer2.ToXgQAFEcwNMApTHMKw();
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.FX004kfxrsfllcl6Fp5(tray, tint, function1, function03, i, 3));
        }
    }
}
