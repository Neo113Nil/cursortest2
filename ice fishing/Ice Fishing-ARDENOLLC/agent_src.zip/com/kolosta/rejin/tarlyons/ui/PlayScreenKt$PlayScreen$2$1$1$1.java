package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"com/kolosta/rejin/tarlyons/ui/PlayScreenKt$PlayScreen$2$1$1$1", "Lcom/kolosta/rejin/tarlyons/game/SeamView$Listener;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PlayScreenKt$PlayScreen$2$1$1$1 implements com.kolosta.rejin.tarlyons.game.SeamView.Listener {
    public final /* synthetic */ androidx.compose.runtime.MutableState iCK2U69IDurvZVodhWo;
    public final /* synthetic */ androidx.compose.runtime.MutableState uMOFIbPk0BxLkjW3KR7;

    public PlayScreenKt$PlayScreen$2$1$1$1(androidx.compose.runtime.MutableState mutableState, androidx.compose.runtime.MutableState mutableState2) {
        this.uMOFIbPk0BxLkjW3KR7 = mutableState;
        this.iCK2U69IDurvZVodhWo = mutableState2;
    }

    public final void uMOFIbPk0BxLkjW3KR7(boolean z) {
        this.uMOFIbPk0BxLkjW3KR7.setValue(java.lang.Boolean.valueOf(z));
    }
}
