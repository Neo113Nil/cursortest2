package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class StackScreenKt {
    public static final void iCK2U69IDurvZVodhWo(int i, com.kolosta.rejin.tarlyons.data.Snapshot snapshot, kotlin.jvm.functions.Function1 function1, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, int i2) {
        androidx.compose.runtime.Composer composer2;
        int i3 = snapshot.uMOFIbPk0BxLkjW3KR7;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(395543697);
        int i4 = i2 | (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i) ? 4 : 2) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function1) ? 256 : 128) | (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(modifier) ? 2048 : 1024);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i4 & 1, (i4 & 1171) != 1170)) {
            boolean z = i <= i3;
            java.lang.Integer num = (java.lang.Integer) snapshot.iCK2U69IDurvZVodhWo.get(java.lang.Integer.valueOf(i));
            int iIntValue = num != null ? num.intValue() : 0;
            androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7(10.0f);
            androidx.compose.ui.Modifier modifierUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.BorderKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(androidx.compose.ui.draw.ClipKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.SizeKt.VddF2l9gapSy7l41Z9d(modifier, 58.0f), roundedCornerShapeUMOFIbPk0BxLkjW3KR7), androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(z ? 4280958300L : 4279771962L), androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7), 1.5f, i == kotlin.ranges.RangesKt.VddF2l9gapSy7l41Z9d(i3, 0, 59) ? com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb : z ? com.kolosta.rejin.tarlyons.ui.Glaze.GerKUYaWR62lFxYixsm : androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280694096L), roundedCornerShapeUMOFIbPk0BxLkjW3KR7);
            boolean z2 = ((i4 & 896) == 256) | ((i4 & 14) == 4);
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (z2 || objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                objG069ZlNT3DZHrdUtBui = new defpackage.DZQeFaGqM5SEF6q1vC9(i, 1, function1);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            }
            androidx.compose.ui.Modifier modifierVddF2l9gapSy7l41Z9d = androidx.compose.foundation.ClickableKt.VddF2l9gapSy7l41Z9d(modifierUMOFIbPk0BxLkjW3KR7, z, null, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, 14);
            androidx.compose.foundation.layout.ColumnMeasurePolicy columnMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.ColumnKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.GerKUYaWR62lFxYixsm, androidx.compose.ui.Alignment.Companion.wDaxnHzF6aHr1xEjAAF, composerBn6dcy3rRNTGfMyxjUW, 54);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getGerKUYaWR62lFxYixsm());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierVddF2l9gapSy7l41Z9d);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, columnMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            boolean z3 = z;
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(java.lang.String.valueOf(i + 1), null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.ui.KitKt.iCK2U69IDurvZVodhWo, z ? com.kolosta.rejin.tarlyons.ui.Glaze.PMZrLoc0NF3euziS99o : com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(16), null, null, 0L, 0L, null, 16777212), composerBn6dcy3rRNTGfMyxjUW, 0, 0, 131070);
            if (z3) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1674351225);
                com.kolosta.rejin.tarlyons.ui.KitKt.iCK2U69IDurvZVodhWo(iIntValue, 9.0f, 0L, composerBn6dcy3rRNTGfMyxjUW, 48, 4);
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                composer2 = composerBn6dcy3rRNTGfMyxjUW;
            } else {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1674352051);
                composer2 = composerBn6dcy3rRNTGfMyxjUW;
                androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo("locked", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm, com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(10), null, null, 0L, 0L, null, 16777212), composer2, 6, 0, 131070);
                composer2.zw4zyD7jgFPVK81d6J1();
            }
            composer2.ToXgQAFEcwNMApTHMKw();
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.vVHoP5h8JAJblQyBM51(i, snapshot, function1, modifier, i2));
        }
    }

    public static final void uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.data.Snapshot snapshot, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        function1.getClass();
        function0.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-1101932817);
        int i2 = (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 4 : 2) | i;
        int i3 = 0;
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 147) != 146)) {
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                objG069ZlNT3DZHrdUtBui = new defpackage.p0GfW29syb65Z7G2oVR(function0, 3);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            }
            androidx.activity.compose.BackHandlerKt.uMOFIbPk0BxLkjW3KR7(false, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 0, 1);
            com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(-1618891287, new defpackage.w3(function0, snapshot, function1, i3), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 6);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.CCCL9UnzXF7r79Ss3yC(snapshot, function1, function0, i, 5));
        }
    }
}
