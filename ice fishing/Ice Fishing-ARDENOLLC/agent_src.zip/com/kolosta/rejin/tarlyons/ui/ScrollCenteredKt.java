package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class ScrollCenteredKt {
    public static final void uMOFIbPk0BxLkjW3KR7(androidx.compose.ui.Modifier modifier, float f, androidx.compose.foundation.layout.PaddingValues paddingValues, final androidx.compose.runtime.internal.ComposableLambdaImpl composableLambdaImpl, androidx.compose.runtime.Composer composer, final int i) {
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(267846362);
        int i2 = i | 438;
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 1171) != 1170)) {
            f = 12.0f;
            paddingValues = new androidx.compose.foundation.layout.PaddingValuesImpl(18.0f, 12.0f, 18.0f, 12.0f);
            androidx.compose.foundation.layout.BoxWithConstraintsKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.SizeKt.VddF2l9gapSy7l41Z9d, null, androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(49459524, new defpackage.m2(paddingValues, f, composableLambdaImpl), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 3072);
            modifier = androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm;
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        final androidx.compose.ui.Modifier modifier2 = modifier;
        final float f2 = f;
        final androidx.compose.foundation.layout.PaddingValues paddingValues2 = paddingValues;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2(f2, paddingValues2, composableLambdaImpl, i) { // from class: z2
                public final /* synthetic */ float A39SiWGux5Rbalqx5tb;
                public final /* synthetic */ androidx.compose.runtime.internal.ComposableLambdaImpl EYwcyipzkILQreEEPxc;
                public final /* synthetic */ androidx.compose.foundation.layout.PaddingValues PMZrLoc0NF3euziS99o;

                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iUMOFIbPk0BxLkjW3KR7 = androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(3073);
                    com.kolosta.rejin.tarlyons.ui.ScrollCenteredKt.uMOFIbPk0BxLkjW3KR7(this.GerKUYaWR62lFxYixsm, this.A39SiWGux5Rbalqx5tb, this.PMZrLoc0NF3euziS99o, this.EYwcyipzkILQreEEPxc, (androidx.compose.runtime.Composer) obj, iUMOFIbPk0BxLkjW3KR7);
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            });
        }
    }
}
