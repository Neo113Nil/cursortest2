package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class CabinetScreenKt {
    public static final java.util.List uMOFIbPk0BxLkjW3KR7 = kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl("I", "II", "III", "IV");

    public static final void VddF2l9gapSy7l41Z9d(com.kolosta.rejin.tarlyons.data.Tint tint, com.kolosta.rejin.tarlyons.data.Snapshot snapshot, kotlin.jvm.functions.Function1 function1, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.Composer composer2;
        kotlin.jvm.functions.Function2 function2;
        java.lang.Throwable th;
        long jICK2U69IDurvZVodhWo;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-1174143821);
        int i2 = i | (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(tint.ordinal()) ? 4 : 2) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function1) ? 256 : 128);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 147) != 146)) {
            boolean zContains = snapshot.GerKUYaWR62lFxYixsm.contains(tint);
            androidx.compose.foundation.layout.FillElement fillElement = androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7;
            androidx.compose.foundation.layout.RowMeasurePolicy rowMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.RowKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.EYwcyipzkILQreEEPxc(12.0f), androidx.compose.ui.Alignment.Companion.JjLaFjoHTCoTSMjQa7q, composerBn6dcy3rRNTGfMyxjUW, 54);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, fillElement);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            kotlin.jvm.functions.Function2 function22 = androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, rowMeasurePolicyUMOFIbPk0BxLkjW3KR7, function22);
            kotlin.jvm.functions.Function2 function23 = androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, function23);
            java.lang.Integer numValueOf = java.lang.Integer.valueOf(iHashCode);
            kotlin.jvm.functions.Function2 function24 = androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc;
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, numValueOf, function24);
            kotlin.jvm.functions.Function1 function12 = androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt;
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, function12);
            kotlin.jvm.functions.Function2 function25 = androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm;
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, function25);
            androidx.compose.ui.Modifier modifierG069ZlNT3DZHrdUtBui = androidx.compose.foundation.layout.SizeKt.G069ZlNT3DZHrdUtBui(androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm, 28.0f);
            androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShape = androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7;
            androidx.compose.ui.Modifier modifierUMOFIbPk0BxLkjW3KR7 = androidx.compose.ui.draw.ClipKt.uMOFIbPk0BxLkjW3KR7(modifierG069ZlNT3DZHrdUtBui, roundedCornerShape);
            androidx.compose.ui.text.TextStyle textStyle = com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7;
            if (zContains) {
                tint.getClass();
                function2 = function23;
                jICK2U69IDurvZVodhWo = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(tint.getColor());
                th = null;
            } else {
                tint.getClass();
                function2 = function23;
                th = null;
                jICK2U69IDurvZVodhWo = androidx.compose.ui.graphics.Color.iCK2U69IDurvZVodhWo(0.3f, androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(tint.getColor()));
            }
            androidx.compose.foundation.layout.BoxKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BorderKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(modifierUMOFIbPk0BxLkjW3KR7, jICK2U69IDurvZVodhWo, androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7), 1.5f, com.kolosta.rejin.tarlyons.ui.Glaze.GerKUYaWR62lFxYixsm, roundedCornerShape), composerBn6dcy3rRNTGfMyxjUW, 0);
            androidx.compose.ui.Modifier modifierUMOFIbPk0BxLkjW3KR72 = androidx.compose.foundation.layout.RowScopeInstance.uMOFIbPk0BxLkjW3KR7.uMOFIbPk0BxLkjW3KR7(1.0f);
            androidx.compose.foundation.layout.ColumnMeasurePolicy columnMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.ColumnKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.VddF2l9gapSy7l41Z9d, androidx.compose.ui.Alignment.Companion.Dpa63RlwGiNbcDAIHuO, composerBn6dcy3rRNTGfMyxjUW, 0);
            int iHashCode2 = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getOdQKMRXlTEGq7vZEcEs());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2 = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm2 = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, modifierUMOFIbPk0BxLkjW3KR72);
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw th;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, columnMeasurePolicyUMOFIbPk0BxLkjW3KR7, function22);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2, function2);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode2), function24);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, function12);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm2, function25);
            java.lang.String label = tint.getLabel();
            androidx.compose.ui.text.TextStyle textStyle2 = com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d;
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(label, null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(textStyle2, zContains ? com.kolosta.rejin.tarlyons.ui.Glaze.PMZrLoc0NF3euziS99o : com.kolosta.rejin.tarlyons.ui.Glaze.EYwcyipzkILQreEEPxc, 0L, null, null, 0L, 0L, null, 16777214), composerBn6dcy3rRNTGfMyxjUW, 0, 0, 131070);
            java.lang.String strJ0yhOfa7n1b2lkVBAKt = tint.getDrops() == 0 ? "Starter resin" : defpackage.cUEQzQeAqMKjdi9XsQN.j0yhOfa7n1b2lkVBAKt(tint.getDrops(), "Unlocks at ", " drops");
            androidx.compose.ui.text.TextStyle textStyle3 = com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm;
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(strJ0yhOfa7n1b2lkVBAKt, null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(textStyle3, 0L, androidx.compose.ui.unit.TextUnitKt.VddF2l9gapSy7l41Z9d(12), null, null, 0L, 0L, null, 16777213), composerBn6dcy3rRNTGfMyxjUW, 0, 0, 131070);
            composerBn6dcy3rRNTGfMyxjUW.ToXgQAFEcwNMApTHMKw();
            if (snapshot.A39SiWGux5Rbalqx5tb == tint) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(655820971);
                composer2 = composerBn6dcy3rRNTGfMyxjUW;
                androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo("Equipped", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(textStyle2, com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb, 0L, null, null, 0L, 0L, null, 16777214), composer2, 6, 0, 131070);
                composer2.zw4zyD7jgFPVK81d6J1();
            } else if (zContains) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(655823591);
                boolean z = ((i2 & 896) == 256) | ((i2 & 14) == 4);
                java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (z || objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                    objG069ZlNT3DZHrdUtBui = new defpackage.nzPs0JjNlt1GlTnrSis(2, function1, tint);
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
                }
                com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d("Equip", (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, null, false, false, composerBn6dcy3rRNTGfMyxjUW, 3078, 20);
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                composer2 = composerBn6dcy3rRNTGfMyxjUW;
            } else {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(655826057);
                composer2 = composerBn6dcy3rRNTGfMyxjUW;
                androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo("Locked", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(textStyle3, com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt, 0L, null, null, 0L, 0L, null, 16777214), composer2, 6, 0, 131070);
                composer2.zw4zyD7jgFPVK81d6J1();
            }
            composer2.ToXgQAFEcwNMApTHMKw();
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.CCCL9UnzXF7r79Ss3yC(tint, snapshot, function1, i, 2));
        }
    }

    public static final void iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Snapshot snapshot, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        function1.getClass();
        function12.getClass();
        function0.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-1736247294);
        int i2 = (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 4 : 2) | i | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function1) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function12) ? 256 : 128);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 1171) != 1170)) {
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                objG069ZlNT3DZHrdUtBui = new defpackage.p0GfW29syb65Z7G2oVR(function0, 0);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            }
            androidx.activity.compose.BackHandlerKt.uMOFIbPk0BxLkjW3KR7(false, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 0, 1);
            com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(1720324476, new defpackage.AtT97idLtpQzG58sGsp(function0, snapshot, function1, function12, 0), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 6);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.FX004kfxrsfllcl6Fp5(snapshot, function1, function12, function0, i, 1));
        }
    }

    public static final void uMOFIbPk0BxLkjW3KR7(final int i, final com.kolosta.rejin.tarlyons.data.Snapshot snapshot, final kotlin.jvm.functions.Function1 function1, androidx.compose.runtime.Composer composer, int i2) {
        androidx.compose.runtime.Composer composer2;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(165825492);
        int i3 = (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i) ? 4 : 2) | i2 | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function1) ? 256 : 128);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i3 & 1, (i3 & 147) != 146)) {
            final boolean zContains = snapshot.PMZrLoc0NF3euziS99o.contains(java.lang.Integer.valueOf(i));
            int i4 = 0;
            final int i5 = i * 15;
            java.lang.Iterable iterableJ0yhOfa7n1b2lkVBAKt = kotlin.ranges.RangesKt.j0yhOfa7n1b2lkVBAKt(i5, (i + 1) * 15);
            if (!(iterableJ0yhOfa7n1b2lkVBAKt instanceof java.util.Collection) || !((java.util.Collection) iterableJ0yhOfa7n1b2lkVBAKt).isEmpty()) {
                java.util.Iterator<java.lang.Integer> it = iterableJ0yhOfa7n1b2lkVBAKt.iterator();
                while (((kotlin.ranges.IntProgressionIterator) it).PMZrLoc0NF3euziS99o) {
                    if (snapshot.VddF2l9gapSy7l41Z9d.contains(java.lang.Integer.valueOf(((kotlin.collections.IntIterator) it).nextInt())) && (i4 = i4 + 1) < 0) {
                        throw new java.lang.ArithmeticException("Count overflow has happened.");
                    }
                }
            }
            final int i6 = i4;
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm(androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7, 0.0f, androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(-864449171, new kotlin.jvm.functions.Function3() { // from class: WZxbkUX29LsNkLY0Nl2
                @Override // kotlin.jvm.functions.Function3
                public final java.lang.Object G069ZlNT3DZHrdUtBui(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                    com.kolosta.rejin.tarlyons.data.Snapshot snapshot2 = snapshot;
                    com.kolosta.rejin.tarlyons.data.Tint tint = snapshot2.A39SiWGux5Rbalqx5tb;
                    androidx.compose.runtime.Composer composer3 = (androidx.compose.runtime.Composer) obj2;
                    int iIntValue = ((java.lang.Integer) obj3).intValue();
                    java.util.List list = com.kolosta.rejin.tarlyons.ui.CabinetScreenKt.uMOFIbPk0BxLkjW3KR7;
                    ((androidx.compose.foundation.layout.ColumnScope) obj).getClass();
                    int i7 = 0;
                    if (composer3.HEMPdThLdw2U4SnnXcc(iIntValue & 1, (iIntValue & 17) != 16)) {
                        androidx.compose.foundation.layout.FillElement fillElement = androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7;
                        androidx.compose.foundation.layout.RowMeasurePolicy rowMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.RowKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.PMZrLoc0NF3euziS99o, androidx.compose.ui.Alignment.Companion.JjLaFjoHTCoTSMjQa7q, composer3, 54);
                        int iHashCode = java.lang.Long.hashCode(composer3.getOdQKMRXlTEGq7vZEcEs());
                        androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composer3.Q9Nq566vXkbJ4Iw58qn();
                        androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composer3, fillElement);
                        androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
                        kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
                        if (composer3.v5wzXFgUOh8fr6SrmDF() == null) {
                            androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                            throw null;
                        }
                        composer3.fjT7LSJoZG8JrehrlZO();
                        if (composer3.getBo9jv9ivHpNCfjAX1nQ()) {
                            composer3.Bo9jv9ivHpNCfjAX1nQ(function0);
                        } else {
                            composer3.X1I3PnLZJSbM9AFq8Rp();
                        }
                        androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, rowMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
                        androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
                        androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composer3, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
                        androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composer3, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
                        androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
                        java.util.List list2 = com.kolosta.rejin.tarlyons.ui.CabinetScreenKt.uMOFIbPk0BxLkjW3KR7;
                        int i8 = i;
                        androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo("Board " + list2.get(i8), null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, com.kolosta.rejin.tarlyons.ui.KitKt.iCK2U69IDurvZVodhWo, composer3, 0, 12582912, 131070);
                        int i9 = i5;
                        java.lang.StringBuilder sb = new java.lang.StringBuilder("Trays ");
                        sb.append(i9 + 1);
                        sb.append("–");
                        sb.append(i9 + 15);
                        sb.append(" · ");
                        int i10 = i6;
                        sb.append(i10);
                        sb.append("/15 perfect");
                        androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(sb.toString(), null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, com.kolosta.rejin.tarlyons.ui.KitKt.GerKUYaWR62lFxYixsm, composer3, 0, 12582912, 131070);
                        composer3.ToXgQAFEcwNMApTHMKw();
                        androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.Companion.GerKUYaWR62lFxYixsm;
                        boolean z = zContains;
                        int i11 = com.kolosta.rejin.tarlyons.R.drawable.art_emblem;
                        if (z) {
                            composer3.JnYgR1cE6e0Di97yUx9(-181000793);
                            androidx.compose.foundation.ImageKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.ui.res.PainterResources_androidKt.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_emblem, composer3), "Assembled board", androidx.compose.foundation.layout.SizeKt.G069ZlNT3DZHrdUtBui(companion, 120.0f), null, null, 0.0f, com.kolosta.rejin.tarlyons.ui.KitKt.PMZrLoc0NF3euziS99o(tint), composer3, 440, 56);
                            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo("Assembled", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d, com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb, 0L, null, null, 0L, 0L, null, 16777214), composer3, 6, 0, 131070);
                            composer3.zw4zyD7jgFPVK81d6J1();
                        } else {
                            composer3.JnYgR1cE6e0Di97yUx9(-180693552);
                            composer3.JnYgR1cE6e0Di97yUx9(-1806942939);
                            int i12 = 15;
                            java.util.ArrayList arrayListGzg71nUFKNF0JyxrFIK = kotlin.collections.CollectionsKt.gzg71nUFKNF0JyxrFIK(kotlin.ranges.RangesKt.j0yhOfa7n1b2lkVBAKt(0, 15));
                            int size = arrayListGzg71nUFKNF0JyxrFIK.size();
                            int i13 = 0;
                            while (i13 < size) {
                                int i14 = i13 + 1;
                                java.util.List list3 = (java.util.List) arrayListGzg71nUFKNF0JyxrFIK.get(i13);
                                androidx.compose.foundation.layout.FillElement fillElement2 = androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7;
                                androidx.compose.foundation.layout.RowMeasurePolicy rowMeasurePolicyUMOFIbPk0BxLkjW3KR72 = androidx.compose.foundation.layout.RowKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.EYwcyipzkILQreEEPxc(6.0f), androidx.compose.ui.Alignment.Companion.G069ZlNT3DZHrdUtBui, composer3, 6);
                                int iHashCode2 = java.lang.Long.hashCode(composer3.getOdQKMRXlTEGq7vZEcEs());
                                androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2 = composer3.Q9Nq566vXkbJ4Iw58qn();
                                androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm2 = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composer3, fillElement2);
                                androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
                                kotlin.jvm.functions.Function0 function02 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
                                if (composer3.v5wzXFgUOh8fr6SrmDF() == null) {
                                    androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                                    throw null;
                                }
                                composer3.fjT7LSJoZG8JrehrlZO();
                                if (composer3.getBo9jv9ivHpNCfjAX1nQ()) {
                                    composer3.Bo9jv9ivHpNCfjAX1nQ(function02);
                                } else {
                                    composer3.X1I3PnLZJSbM9AFq8Rp();
                                }
                                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, rowMeasurePolicyUMOFIbPk0BxLkjW3KR72, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
                                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn2, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
                                androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composer3, java.lang.Integer.valueOf(iHashCode2), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
                                androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composer3, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
                                androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, modifierGerKUYaWR62lFxYixsm2, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
                                composer3.JnYgR1cE6e0Di97yUx9(418069046);
                                java.util.Iterator it2 = list3.iterator();
                                while (it2.hasNext()) {
                                    boolean zContains2 = snapshot2.VddF2l9gapSy7l41Z9d.contains(java.lang.Integer.valueOf(i9 + ((java.lang.Number) it2.next()).intValue()));
                                    androidx.compose.ui.Modifier modifierUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.BorderKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(androidx.compose.ui.draw.ClipKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.AspectRatioKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.RowScopeInstance.uMOFIbPk0BxLkjW3KR7.uMOFIbPk0BxLkjW3KR7(1.0f)), androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7(8.0f)), androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(zContains2 ? 4281616746L : 4279771962L), androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7), 1.0f, zContains2 ? com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb : androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4280694096L), androidx.compose.foundation.shape.RoundedCornerShapeKt.uMOFIbPk0BxLkjW3KR7(8.0f));
                                    androidx.compose.ui.layout.MeasurePolicy measurePolicyGerKUYaWR62lFxYixsm = androidx.compose.foundation.layout.BoxKt.GerKUYaWR62lFxYixsm(androidx.compose.ui.Alignment.Companion.A39SiWGux5Rbalqx5tb, false);
                                    int iHashCode3 = java.lang.Long.hashCode(composer3.getOdQKMRXlTEGq7vZEcEs());
                                    androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn3 = composer3.Q9Nq566vXkbJ4Iw58qn();
                                    androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm3 = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composer3, modifierUMOFIbPk0BxLkjW3KR7);
                                    androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
                                    kotlin.jvm.functions.Function0 function03 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
                                    if (composer3.v5wzXFgUOh8fr6SrmDF() == null) {
                                        androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                                        throw null;
                                    }
                                    composer3.fjT7LSJoZG8JrehrlZO();
                                    if (composer3.getBo9jv9ivHpNCfjAX1nQ()) {
                                        composer3.Bo9jv9ivHpNCfjAX1nQ(function03);
                                    } else {
                                        composer3.X1I3PnLZJSbM9AFq8Rp();
                                    }
                                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, measurePolicyGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
                                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn3, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
                                    androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composer3, java.lang.Integer.valueOf(iHashCode3), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
                                    androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composer3, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
                                    androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composer3, modifierGerKUYaWR62lFxYixsm3, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
                                    androidx.compose.foundation.ImageKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.ui.res.PainterResources_androidKt.uMOFIbPk0BxLkjW3KR7(i11, composer3), null, androidx.compose.ui.draw.AlphaKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.PaddingKt.PMZrLoc0NF3euziS99o(companion, 4.0f), zContains2 ? 1.0f : 0.25f), null, null, 0.0f, zContains2 ? com.kolosta.rejin.tarlyons.ui.KitKt.PMZrLoc0NF3euziS99o(tint) : com.kolosta.rejin.tarlyons.ui.KitKt.A39SiWGux5Rbalqx5tb, composer3, 56, 56);
                                    composer3.ToXgQAFEcwNMApTHMKw();
                                    i12 = 15;
                                    size = size;
                                    arrayListGzg71nUFKNF0JyxrFIK = arrayListGzg71nUFKNF0JyxrFIK;
                                    i11 = com.kolosta.rejin.tarlyons.R.drawable.art_emblem;
                                }
                                composer3.zw4zyD7jgFPVK81d6J1();
                                composer3.ToXgQAFEcwNMApTHMKw();
                                i13 = i14;
                                i11 = com.kolosta.rejin.tarlyons.R.drawable.art_emblem;
                            }
                            int i15 = i12;
                            composer3.zw4zyD7jgFPVK81d6J1();
                            java.lang.String strJ0yhOfa7n1b2lkVBAKt = i10 >= i15 ? "Assemble" : defpackage.cUEQzQeAqMKjdi9XsQN.j0yhOfa7n1b2lkVBAKt(15 - i10, "Perfect ", " more to assemble");
                            kotlin.jvm.functions.Function1 function12 = function1;
                            boolean zNWbn9nx4Jy3ZCUpsHES = composer3.NWbn9nx4Jy3ZCUpsHES(function12) | composer3.gzg71nUFKNF0JyxrFIK(i8);
                            java.lang.Object objG069ZlNT3DZHrdUtBui = composer3.G069ZlNT3DZHrdUtBui();
                            if (zNWbn9nx4Jy3ZCUpsHES || objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                                objG069ZlNT3DZHrdUtBui = new defpackage.DZQeFaGqM5SEF6q1vC9(i8, i7, function12);
                                composer3.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
                            }
                            com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d(strJ0yhOfa7n1b2lkVBAKt, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7, false, i10 >= i15, composer3, 384, 8);
                            composer3.zw4zyD7jgFPVK81d6J1();
                        }
                    } else {
                        composer3.PMZrLoc0NF3euziS99o();
                    }
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            }, composerBn6dcy3rRNTGfMyxjUW), composer2, 390, 2);
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.l75NXPNn5idGpEzYK2S(i, snapshot, function1, i2));
        }
    }
}
