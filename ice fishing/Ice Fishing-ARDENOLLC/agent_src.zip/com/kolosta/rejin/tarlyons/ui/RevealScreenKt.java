package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RevealScreenKt {
    public static final long GerKUYaWR62lFxYixsm(androidx.compose.ui.graphics.drawscope.DrawScope drawScope, float f, float f2, float f3, float f4, int i) {
        long jFloatToRawIntBits;
        long jFloatToRawIntBits2;
        if (i == 0) {
            float f5 = f * 0.6f;
            jFloatToRawIntBits = java.lang.Float.floatToRawIntBits(java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() >> 32)) / 2.0f) << 32;
            jFloatToRawIntBits2 = java.lang.Float.floatToRawIntBits((((f4 + f5) * 0.0f) + f3) - f5) & 4294967295L;
        } else {
            int i2 = i - 1;
            float f6 = (((i2 % 5) + 0.5f) * f) + f2;
            float fICK2U69IDurvZVodhWo = ((((i2 / 5) % 5) + 0.5f) * f) + (((0.6f * f) + f4) * com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(i)) + f3;
            long jFloatToRawIntBits3 = java.lang.Float.floatToRawIntBits(f6);
            long jFloatToRawIntBits4 = java.lang.Float.floatToRawIntBits(fICK2U69IDurvZVodhWo);
            jFloatToRawIntBits = jFloatToRawIntBits3 << 32;
            jFloatToRawIntBits2 = jFloatToRawIntBits4 & 4294967295L;
        }
        return jFloatToRawIntBits | jFloatToRawIntBits2;
    }

    public static final void VddF2l9gapSy7l41Z9d(final com.kolosta.rejin.tarlyons.game.RunResult runResult, final long j, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(894665359);
        int i2 = (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(runResult) ? 4 : 2) | i | (composerBn6dcy3rRNTGfMyxjUW.Dpa63RlwGiNbcDAIHuO(j) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(modifier) ? 256 : 128);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 147) != 146)) {
            final int i3 = runResult.uMOFIbPk0BxLkjW3KR7.iCK2U69IDurvZVodhWo;
            boolean zGzg71nUFKNF0JyxrFIK = composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i3) | composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(runResult) | ((i2 & 112) == 32);
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (zGzg71nUFKNF0JyxrFIK || objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                objG069ZlNT3DZHrdUtBui = new kotlin.jvm.functions.Function1() { // from class: n2
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                        float f;
                        float f2;
                        com.kolosta.rejin.tarlyons.game.RunResult runResult2 = runResult;
                        java.util.List list = runResult2.PMZrLoc0NF3euziS99o;
                        androidx.compose.ui.graphics.drawscope.DrawScope drawScope = (androidx.compose.ui.graphics.drawscope.DrawScope) obj;
                        drawScope.getClass();
                        int i4 = i3;
                        float f3 = 0.6f;
                        float f4 = ((i4 - 1) * 0.6f) + (i4 * 5) + 1.0f;
                        char c = ' ';
                        float fMin = java.lang.Math.min(java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() >> 32)) / 5.0f, java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() & 4294967295L)) / f4);
                        float f5 = fMin * 5.0f;
                        float fIntBitsToFloat = (java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() >> 32)) - f5) / 2.0f;
                        float fIntBitsToFloat2 = ((java.lang.Float.intBitsToFloat((int) (drawScope.GerKUYaWR62lFxYixsm() & 4294967295L)) - (f4 * fMin)) / 2.0f) + fMin;
                        int i5 = 0;
                        while (i5 < i4) {
                            float f6 = 0.3f * fMin;
                            char c2 = c;
                            drawScope.q1HLeYDh3JmJmh5OQQK(androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4292667377L), (java.lang.Float.floatToRawIntBits((((fMin * f3) + f5) * i5) + fIntBitsToFloat2) & 4294967295L) | (java.lang.Float.floatToRawIntBits(fIntBitsToFloat) << c), (java.lang.Float.floatToRawIntBits(f5) << c) | (java.lang.Float.floatToRawIntBits(f5) & 4294967295L), (java.lang.Float.floatToRawIntBits(f6) & 4294967295L) | (java.lang.Float.floatToRawIntBits(f6) << c2), androidx.compose.ui.graphics.drawscope.Fill.uMOFIbPk0BxLkjW3KR7);
                            i5++;
                            c = c2;
                            f3 = 0.6f;
                        }
                        java.util.Set setJkKMrfloFo2xH4UTgso = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(list);
                        float f7 = 0.07f * fMin;
                        float f8 = f7 < 2.0f ? 2.0f : f7;
                        java.util.Iterator it = runResult2.EYwcyipzkILQreEEPxc.iterator();
                        while (it.hasNext()) {
                            int iIntValue = ((java.lang.Number) it.next()).intValue();
                            if (setJkKMrfloFo2xH4UTgso.contains(java.lang.Integer.valueOf(iIntValue))) {
                                f = fMin;
                                f2 = f5;
                            } else {
                                long jGerKUYaWR62lFxYixsm = androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4282010726L);
                                int i6 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                                float f9 = fMin;
                                float f10 = f5;
                                float f11 = fIntBitsToFloat;
                                float f12 = fIntBitsToFloat2;
                                f = f9;
                                f2 = f10;
                                drawScope.UPlvLv1IJDlSD4sir4v(jGerKUYaWR62lFxYixsm, com.kolosta.rejin.tarlyons.ui.RevealScreenKt.GerKUYaWR62lFxYixsm(drawScope, f9, f11, f12, f10, iIntValue / 1000), com.kolosta.rejin.tarlyons.ui.RevealScreenKt.GerKUYaWR62lFxYixsm(drawScope, f9, f11, f12, f10, iIntValue % 1000), f8, (496 & 16) != 0 ? 0 : 1);
                                fIntBitsToFloat2 = f12;
                                fIntBitsToFloat = f11;
                            }
                            f5 = f2;
                            fMin = f;
                        }
                        float f13 = f8;
                        float f14 = fMin;
                        float f15 = f5;
                        float f16 = fIntBitsToFloat;
                        float f17 = fIntBitsToFloat2;
                        java.util.Iterator it2 = list.iterator();
                        while (it2.hasNext()) {
                            int iIntValue2 = ((java.lang.Number) it2.next()).intValue();
                            int i7 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                            drawScope.UPlvLv1IJDlSD4sir4v(j, com.kolosta.rejin.tarlyons.ui.RevealScreenKt.GerKUYaWR62lFxYixsm(drawScope, f14, f16, f17, f15, iIntValue2 / 1000), com.kolosta.rejin.tarlyons.ui.RevealScreenKt.GerKUYaWR62lFxYixsm(drawScope, f14, f16, f17, f15, iIntValue2 % 1000), f13 * 2.0f, (496 & 16) != 0 ? 0 : 1);
                        }
                        androidx.compose.ui.graphics.drawscope.DrawScope.sC3avyxZw3CXKHdQYJZ(drawScope, androidx.compose.ui.graphics.ColorKt.GerKUYaWR62lFxYixsm(4293047886L), 0.2f * f14, com.kolosta.rejin.tarlyons.ui.RevealScreenKt.GerKUYaWR62lFxYixsm(drawScope, f14, f16, f17, f15, 0), 120);
                        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                    }
                };
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            }
            androidx.compose.foundation.CanvasKt.uMOFIbPk0BxLkjW3KR7(modifier, (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, (i2 >> 6) & 14);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.OBWx8K2uSIyiwkjsL0N(runResult, j, modifier, i));
        }
    }

    public static final void iCK2U69IDurvZVodhWo(final com.kolosta.rejin.tarlyons.game.RunResult runResult, final com.kolosta.rejin.tarlyons.data.Reward reward, final com.kolosta.rejin.tarlyons.data.Tint tint, final kotlin.jvm.functions.Function0 function0, final kotlin.jvm.functions.Function0 function02, final kotlin.jvm.functions.Function0 function03, androidx.compose.runtime.Composer composer, final int i) {
        kotlin.jvm.functions.Function0 function04;
        function0.getClass();
        function03.getClass();
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(1670000714);
        int i2 = i | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(runResult) ? 4 : 2) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(reward) ? 32 : 16) | (composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(tint.ordinal()) ? 256 : 128) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function0) ? 2048 : 1024) | (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(function02) ? 16384 : 8192);
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (74899 & i2) != 74898)) {
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui == androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7) {
                function04 = function03;
                objG069ZlNT3DZHrdUtBui = new defpackage.p0GfW29syb65Z7G2oVR(function04, 2);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui);
            } else {
                function04 = function03;
            }
            androidx.activity.compose.BackHandlerKt.uMOFIbPk0BxLkjW3KR7(false, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 0, 1);
            com.kolosta.rejin.tarlyons.ui.KitKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.runtime.internal.ComposableLambdaKt.iCK2U69IDurvZVodhWo(1592936080, new defpackage.j2(0, reward, tint, runResult, function02, function0, function04), composerBn6dcy3rRNTGfMyxjUW), composerBn6dcy3rRNTGfMyxjUW, 6);
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2(i, reward, tint, runResult, function0, function02, function03) { // from class: k2
                public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Reward A39SiWGux5Rbalqx5tb;
                public final /* synthetic */ kotlin.jvm.functions.Function0 EYwcyipzkILQreEEPxc;
                public final /* synthetic */ com.kolosta.rejin.tarlyons.game.RunResult GerKUYaWR62lFxYixsm;
                public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Tint PMZrLoc0NF3euziS99o;
                public final /* synthetic */ kotlin.jvm.functions.Function0 j0yhOfa7n1b2lkVBAKt;
                public final /* synthetic */ kotlin.jvm.functions.Function0 lVvt79Js7aeYnsjUe7L;

                {
                    this.GerKUYaWR62lFxYixsm = runResult;
                    this.A39SiWGux5Rbalqx5tb = reward;
                    this.PMZrLoc0NF3euziS99o = tint;
                    this.EYwcyipzkILQreEEPxc = function0;
                    this.j0yhOfa7n1b2lkVBAKt = function02;
                    this.lVvt79Js7aeYnsjUe7L = function03;
                }

                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iUMOFIbPk0BxLkjW3KR7 = androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(196609);
                    com.kolosta.rejin.tarlyons.ui.RevealScreenKt.iCK2U69IDurvZVodhWo(this.GerKUYaWR62lFxYixsm, this.A39SiWGux5Rbalqx5tb, this.PMZrLoc0NF3euziS99o, this.EYwcyipzkILQreEEPxc, this.j0yhOfa7n1b2lkVBAKt, this.lVvt79Js7aeYnsjUe7L, (androidx.compose.runtime.Composer) obj, iUMOFIbPk0BxLkjW3KR7);
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            });
        }
    }

    public static final void uMOFIbPk0BxLkjW3KR7(final java.lang.String str, boolean z, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        androidx.compose.runtime.Composer composer2;
        final boolean z2 = z;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(-1278129978);
        if ((i & 6) == 0) {
            i2 = i | (composerBn6dcy3rRNTGfMyxjUW.NWbn9nx4Jy3ZCUpsHES(str) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerBn6dcy3rRNTGfMyxjUW.GerKUYaWR62lFxYixsm(z2) ? 32 : 16;
        }
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i2 & 1, (i2 & 19) != 18)) {
            androidx.compose.foundation.layout.FillElement fillElement = androidx.compose.foundation.layout.SizeKt.uMOFIbPk0BxLkjW3KR7;
            androidx.compose.foundation.layout.RowMeasurePolicy rowMeasurePolicyUMOFIbPk0BxLkjW3KR7 = androidx.compose.foundation.layout.RowKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.layout.Arrangement.PMZrLoc0NF3euziS99o, androidx.compose.ui.Alignment.Companion.G069ZlNT3DZHrdUtBui, composerBn6dcy3rRNTGfMyxjUW, 6);
            int iHashCode = java.lang.Long.hashCode(composerBn6dcy3rRNTGfMyxjUW.getGerKUYaWR62lFxYixsm());
            androidx.compose.runtime.PersistentCompositionLocalMap persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn = composerBn6dcy3rRNTGfMyxjUW.Q9Nq566vXkbJ4Iw58qn();
            androidx.compose.ui.Modifier modifierGerKUYaWR62lFxYixsm = androidx.compose.ui.ComposedModifierKt.GerKUYaWR62lFxYixsm(composerBn6dcy3rRNTGfMyxjUW, fillElement);
            androidx.compose.ui.node.ComposeUiNode.iCK2U69IDurvZVodhWo.getClass();
            kotlin.jvm.functions.Function0 function0 = androidx.compose.ui.node.ComposeUiNode.Companion.iCK2U69IDurvZVodhWo;
            if (composerBn6dcy3rRNTGfMyxjUW.v5wzXFgUOh8fr6SrmDF() == null) {
                androidx.compose.runtime.ComposablesKt.uMOFIbPk0BxLkjW3KR7();
                throw null;
            }
            composerBn6dcy3rRNTGfMyxjUW.fjT7LSJoZG8JrehrlZO();
            if (composerBn6dcy3rRNTGfMyxjUW.getBo9jv9ivHpNCfjAX1nQ()) {
                composerBn6dcy3rRNTGfMyxjUW.Bo9jv9ivHpNCfjAX1nQ(function0);
            } else {
                composerBn6dcy3rRNTGfMyxjUW.X1I3PnLZJSbM9AFq8Rp();
            }
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, rowMeasurePolicyUMOFIbPk0BxLkjW3KR7, androidx.compose.ui.node.ComposeUiNode.Companion.PMZrLoc0NF3euziS99o);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, persistentCompositionLocalMapQ9Nq566vXkbJ4Iw58qn, androidx.compose.ui.node.ComposeUiNode.Companion.A39SiWGux5Rbalqx5tb);
            androidx.compose.runtime.Updater.uMOFIbPk0BxLkjW3KR7(composerBn6dcy3rRNTGfMyxjUW, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.Companion.EYwcyipzkILQreEEPxc);
            androidx.compose.runtime.Updater.iCK2U69IDurvZVodhWo(composerBn6dcy3rRNTGfMyxjUW, androidx.compose.ui.node.ComposeUiNode.Companion.j0yhOfa7n1b2lkVBAKt);
            androidx.compose.runtime.Updater.VddF2l9gapSy7l41Z9d(composerBn6dcy3rRNTGfMyxjUW, modifierGerKUYaWR62lFxYixsm, androidx.compose.ui.node.ComposeUiNode.Companion.GerKUYaWR62lFxYixsm);
            androidx.compose.ui.text.TextStyle textStyle = com.kolosta.rejin.tarlyons.ui.KitKt.VddF2l9gapSy7l41Z9d;
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(str, null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, textStyle, composerBn6dcy3rRNTGfMyxjUW, i2 & 14, 12582912, 131070);
            z2 = z;
            androidx.compose.material3.TextKt.iCK2U69IDurvZVodhWo(z2 ? "✓" : "—", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, androidx.compose.ui.text.TextStyle.uMOFIbPk0BxLkjW3KR7(textStyle, z2 ? com.kolosta.rejin.tarlyons.ui.Glaze.A39SiWGux5Rbalqx5tb : com.kolosta.rejin.tarlyons.ui.Glaze.j0yhOfa7n1b2lkVBAKt, 0L, null, null, 0L, 0L, null, 16777214), composerBn6dcy3rRNTGfMyxjUW, 0, 0, 131070);
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.ToXgQAFEcwNMApTHMKw();
        } else {
            composer2 = composerBn6dcy3rRNTGfMyxjUW;
            composer2.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composer2.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new kotlin.jvm.functions.Function2() { // from class: o2
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
                    ((java.lang.Integer) obj2).getClass();
                    int iUMOFIbPk0BxLkjW3KR7 = androidx.compose.runtime.RecomposeScopeImplKt.uMOFIbPk0BxLkjW3KR7(i | 1);
                    com.kolosta.rejin.tarlyons.ui.RevealScreenKt.uMOFIbPk0BxLkjW3KR7(str, z2, (androidx.compose.runtime.Composer) obj, iUMOFIbPk0BxLkjW3KR7);
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            });
        }
    }
}
