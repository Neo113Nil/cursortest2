package com.kolosta.rejin.tarlyons.ui;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class ComposableSingletons$TableScreenKt {
    public static final androidx.compose.runtime.internal.ComposableLambdaImpl uMOFIbPk0BxLkjW3KR7 = new androidx.compose.runtime.internal.ComposableLambdaImpl(1824132714, new defpackage.Dpa63RlwGiNbcDAIHuO(7), false);
}
