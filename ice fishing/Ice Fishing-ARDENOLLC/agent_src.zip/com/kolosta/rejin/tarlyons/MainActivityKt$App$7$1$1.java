package com.kolosta.rejin.tarlyons;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.MainActivityKt$App$7$1$1", f = "MainActivity.kt", l = {81}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class MainActivityKt$App$7$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Tint G069ZlNT3DZHrdUtBui;
    public int j0yhOfa7n1b2lkVBAKt;
    public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Store lVvt79Js7aeYnsjUe7L;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivityKt$App$7$1$1(com.kolosta.rejin.tarlyons.data.Store store, com.kolosta.rejin.tarlyons.data.Tint tint, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.lVvt79Js7aeYnsjUe7L = store;
        this.G069ZlNT3DZHrdUtBui = tint;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
        return ((com.kolosta.rejin.tarlyons.MainActivityKt$App$7$1$1) OBWx8K2uSIyiwkjsL0N((kotlinx.coroutines.CoroutineScope) obj, (kotlin.coroutines.Continuation) obj2)).Q9Nq566vXkbJ4Iw58qn(kotlin.Unit.uMOFIbPk0BxLkjW3KR7);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation OBWx8K2uSIyiwkjsL0N(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        return new com.kolosta.rejin.tarlyons.MainActivityKt$App$7$1$1(this.lVvt79Js7aeYnsjUe7L, this.G069ZlNT3DZHrdUtBui, continuation);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        int i = this.j0yhOfa7n1b2lkVBAKt;
        if (i == 0) {
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
            this.j0yhOfa7n1b2lkVBAKt = 1;
            if (this.lVvt79Js7aeYnsjUe7L.iCK2U69IDurvZVodhWo(this.G069ZlNT3DZHrdUtBui, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.uMOFIbPk0BxLkjW3KR7.H0jYF7Mc76EKIPcCXvq("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        }
        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }
}
