package com.kolosta.rejin.tarlyons;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002¨\u0006\u000b²\u0006\u000e\u0010\u0001\u001a\u0004\u0018\u00010\u00008\nX\u008a\u0084\u0002²\u0006\u000e\u0010\u0003\u001a\u00020\u00028\n@\nX\u008a\u008e\u0002²\u0006\u000e\u0010\u0005\u001a\u00020\u00048\n@\nX\u008a\u008e\u0002²\u0006\u000e\u0010\u0006\u001a\u00020\u00048\n@\nX\u008a\u008e\u0002²\u0006\u0010\u0010\b\u001a\u0004\u0018\u00010\u00078\n@\nX\u008a\u008e\u0002²\u0006\u0010\u0010\n\u001a\u0004\u0018\u00010\t8\n@\nX\u008a\u008e\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Snapshot;", "snap", "Lcom/kolosta/rejin/tarlyons/Screen;", "screen", "", "trayId", "runId", "Lcom/kolosta/rejin/tarlyons/game/RunResult;", "result", "Lcom/kolosta/rejin/tarlyons/data/Reward;", "reward", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class MainActivityKt {

    /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
    @kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        static {
            int[] iArr = new int[com.kolosta.rejin.tarlyons.Screen.values().length];
            try {
                iArr[0] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                com.kolosta.rejin.tarlyons.Screen screen = com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm;
                iArr[1] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                com.kolosta.rejin.tarlyons.Screen screen2 = com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm;
                iArr[4] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
            try {
                com.kolosta.rejin.tarlyons.Screen screen3 = com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm;
                iArr[2] = 4;
            } catch (java.lang.NoSuchFieldError unused4) {
            }
            try {
                com.kolosta.rejin.tarlyons.Screen screen4 = com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm;
                iArr[3] = 5;
            } catch (java.lang.NoSuchFieldError unused5) {
            }
        }
    }

    public static final void iCK2U69IDurvZVodhWo(androidx.compose.runtime.MutableIntState mutableIntState, androidx.compose.runtime.MutableIntState mutableIntState2, androidx.compose.runtime.MutableState mutableState, int i) {
        mutableIntState.Dpa63RlwGiNbcDAIHuO(i);
        mutableIntState2.Dpa63RlwGiNbcDAIHuO(mutableIntState2.iCK2U69IDurvZVodhWo() + 1);
        mutableState.setValue(com.kolosta.rejin.tarlyons.Screen.PMZrLoc0NF3euziS99o);
    }

    public static final void uMOFIbPk0BxLkjW3KR7(final com.kolosta.rejin.tarlyons.data.Store store, androidx.compose.runtime.Composer composer, int i) {
        com.kolosta.rejin.tarlyons.data.Snapshot snapshot;
        com.kolosta.rejin.tarlyons.game.Tray tray;
        final androidx.compose.runtime.MutableState mutableState;
        final androidx.compose.runtime.MutableState mutableState2;
        androidx.compose.runtime.Composer composerBn6dcy3rRNTGfMyxjUW = composer.Bn6dcy3rRNTGfMyxjUW(1344014632);
        final int i2 = 4;
        final int i3 = 2;
        int i4 = (composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(store) ? 4 : 2) | i;
        final int i5 = 0;
        final int i6 = 1;
        if (composerBn6dcy3rRNTGfMyxjUW.HEMPdThLdw2U4SnnXcc(i4 & 1, (i4 & 3) != 2)) {
            androidx.compose.runtime.MutableState mutableStateUMOFIbPk0BxLkjW3KR7 = androidx.compose.runtime.SnapshotStateKt.uMOFIbPk0BxLkjW3KR7(store.iCK2U69IDurvZVodhWo, composerBn6dcy3rRNTGfMyxjUW);
            java.lang.Object objG069ZlNT3DZHrdUtBui = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            androidx.compose.runtime.Composer$Companion$Empty$1 composer$Companion$Empty$1 = androidx.compose.runtime.Composer.Companion.uMOFIbPk0BxLkjW3KR7;
            if (objG069ZlNT3DZHrdUtBui == composer$Companion$Empty$1) {
                androidx.compose.runtime.RememberedCoroutineScope rememberedCoroutineScope = new androidx.compose.runtime.RememberedCoroutineScope(composerBn6dcy3rRNTGfMyxjUW.getFxRXIWoAgaLNLQUc6Qv());
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(rememberedCoroutineScope);
                objG069ZlNT3DZHrdUtBui = rememberedCoroutineScope;
            }
            final kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) objG069ZlNT3DZHrdUtBui;
            java.lang.Object objG069ZlNT3DZHrdUtBui2 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui2 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui2 = androidx.compose.runtime.SnapshotStateKt.PMZrLoc0NF3euziS99o(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui2);
            }
            final androidx.compose.runtime.MutableState mutableState3 = (androidx.compose.runtime.MutableState) objG069ZlNT3DZHrdUtBui2;
            java.lang.Object objG069ZlNT3DZHrdUtBui3 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui3 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui3 = androidx.compose.runtime.SnapshotIntStateKt.uMOFIbPk0BxLkjW3KR7(0);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui3);
            }
            final androidx.compose.runtime.MutableIntState mutableIntState = (androidx.compose.runtime.MutableIntState) objG069ZlNT3DZHrdUtBui3;
            java.lang.Object objG069ZlNT3DZHrdUtBui4 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui4 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui4 = androidx.compose.runtime.SnapshotIntStateKt.uMOFIbPk0BxLkjW3KR7(0);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui4);
            }
            final androidx.compose.runtime.MutableIntState mutableIntState2 = (androidx.compose.runtime.MutableIntState) objG069ZlNT3DZHrdUtBui4;
            java.lang.Object objG069ZlNT3DZHrdUtBui5 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            kotlin.jvm.functions.Function0 function0 = null;
            if (objG069ZlNT3DZHrdUtBui5 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui5 = androidx.compose.runtime.SnapshotStateKt.PMZrLoc0NF3euziS99o(null);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui5);
            }
            final androidx.compose.runtime.MutableState mutableState4 = (androidx.compose.runtime.MutableState) objG069ZlNT3DZHrdUtBui5;
            java.lang.Object objG069ZlNT3DZHrdUtBui6 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
            if (objG069ZlNT3DZHrdUtBui6 == composer$Companion$Empty$1) {
                objG069ZlNT3DZHrdUtBui6 = androidx.compose.runtime.SnapshotStateKt.PMZrLoc0NF3euziS99o(null);
                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui6);
            }
            final androidx.compose.runtime.MutableState mutableState5 = (androidx.compose.runtime.MutableState) objG069ZlNT3DZHrdUtBui6;
            com.kolosta.rejin.tarlyons.data.Snapshot snapshot2 = (com.kolosta.rejin.tarlyons.data.Snapshot) mutableStateUMOFIbPk0BxLkjW3KR7.getGerKUYaWR62lFxYixsm();
            if (snapshot2 == null) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1855240484);
                androidx.compose.foundation.layout.BoxKt.uMOFIbPk0BxLkjW3KR7(androidx.compose.foundation.BackgroundKt.iCK2U69IDurvZVodhWo(androidx.compose.foundation.layout.SizeKt.VddF2l9gapSy7l41Z9d, com.kolosta.rejin.tarlyons.ui.Glaze.iCK2U69IDurvZVodhWo, androidx.compose.ui.graphics.RectangleShapeKt.uMOFIbPk0BxLkjW3KR7), composerBn6dcy3rRNTGfMyxjUW, 6);
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
                if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv != null) {
                    scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv.uMOFIbPk0BxLkjW3KR7(new defpackage.d1(store, i, 1));
                    return;
                }
                return;
            }
            composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1852946298);
            composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
            int iOrdinal = ((com.kolosta.rejin.tarlyons.Screen) mutableState3.getGerKUYaWR62lFxYixsm()).ordinal();
            if (iOrdinal == 0) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(-1187072126);
                boolean zH0jYF7Mc76EKIPcCXvq = composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(snapshot2);
                java.lang.Object objG069ZlNT3DZHrdUtBui7 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (zH0jYF7Mc76EKIPcCXvq || objG069ZlNT3DZHrdUtBui7 == composer$Companion$Empty$1) {
                    snapshot = snapshot2;
                    objG069ZlNT3DZHrdUtBui7 = new defpackage.r(snapshot, mutableIntState, mutableIntState2, mutableState3, 2);
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui7);
                } else {
                    snapshot = snapshot2;
                }
                kotlin.jvm.functions.Function0 function02 = (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui7;
                java.lang.Object objG069ZlNT3DZHrdUtBui8 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui8 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui8 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object iCK2U69IDurvZVodhWo() {
                            int i7 = i2;
                            kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                            androidx.compose.runtime.MutableState mutableState6 = mutableState3;
                            switch (i7) {
                                case 0:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 1:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 2:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 3:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 4:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                    break;
                                default:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                    break;
                            }
                            return unit;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui8);
                }
                kotlin.jvm.functions.Function0 function03 = (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui8;
                java.lang.Object objG069ZlNT3DZHrdUtBui9 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui9 == composer$Companion$Empty$1) {
                    final int i7 = 5;
                    objG069ZlNT3DZHrdUtBui9 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object iCK2U69IDurvZVodhWo() {
                            int i72 = i7;
                            kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                            androidx.compose.runtime.MutableState mutableState6 = mutableState3;
                            switch (i72) {
                                case 0:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 1:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 2:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 3:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 4:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                    break;
                                default:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                    break;
                            }
                            return unit;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui9);
                }
                com.kolosta.rejin.tarlyons.ui.TableScreenKt.iCK2U69IDurvZVodhWo(snapshot, function02, function03, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui9, composerBn6dcy3rRNTGfMyxjUW, 3456);
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
            } else if (iOrdinal == 1) {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(-1187065486);
                java.lang.Object objG069ZlNT3DZHrdUtBui10 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui10 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui10 = new defpackage.bVkUiXEQN4TlWscYzQQ(mutableIntState, mutableIntState2, mutableState3, 6);
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui10);
                }
                kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui10;
                java.lang.Object objG069ZlNT3DZHrdUtBui11 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui11 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui11 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object iCK2U69IDurvZVodhWo() {
                            int i72 = i5;
                            kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                            androidx.compose.runtime.MutableState mutableState6 = mutableState3;
                            switch (i72) {
                                case 0:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 1:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 2:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 3:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 4:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                    break;
                                default:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                    break;
                            }
                            return unit;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui11);
                }
                com.kolosta.rejin.tarlyons.ui.StackScreenKt.uMOFIbPk0BxLkjW3KR7(snapshot2, function1, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui11, composerBn6dcy3rRNTGfMyxjUW, 432);
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
            } else if (iOrdinal != 2) {
                final int i8 = 3;
                if (iOrdinal == 3) {
                    composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1856474067);
                    com.kolosta.rejin.tarlyons.game.RunResult runResult = (com.kolosta.rejin.tarlyons.game.RunResult) mutableState4.getGerKUYaWR62lFxYixsm();
                    if (runResult == null) {
                        composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1856517157);
                        composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                        mutableState3.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                    } else {
                        composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1856584272);
                        final int i9 = runResult.uMOFIbPk0BxLkjW3KR7.uMOFIbPk0BxLkjW3KR7;
                        com.kolosta.rejin.tarlyons.data.Reward reward = (com.kolosta.rejin.tarlyons.data.Reward) mutableState5.getGerKUYaWR62lFxYixsm();
                        com.kolosta.rejin.tarlyons.data.Tint tint = snapshot2.A39SiWGux5Rbalqx5tb;
                        boolean zGzg71nUFKNF0JyxrFIK = composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i9);
                        java.lang.Object objG069ZlNT3DZHrdUtBui12 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                        if (zGzg71nUFKNF0JyxrFIK || objG069ZlNT3DZHrdUtBui12 == composer$Companion$Empty$1) {
                            final int i10 = 0;
                            mutableState = mutableState3;
                            objG069ZlNT3DZHrdUtBui12 = new kotlin.jvm.functions.Function0() { // from class: e1
                                @Override // kotlin.jvm.functions.Function0
                                public final java.lang.Object iCK2U69IDurvZVodhWo() {
                                    int i11 = i10;
                                    kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                    androidx.compose.runtime.MutableState mutableState6 = mutableState;
                                    androidx.compose.runtime.MutableIntState mutableIntState3 = mutableIntState2;
                                    androidx.compose.runtime.MutableIntState mutableIntState4 = mutableIntState;
                                    int i12 = i9;
                                    switch (i11) {
                                        case 0:
                                            com.kolosta.rejin.tarlyons.MainActivityKt.iCK2U69IDurvZVodhWo(mutableIntState4, mutableIntState3, mutableState6, i12);
                                            break;
                                        default:
                                            com.kolosta.rejin.tarlyons.MainActivityKt.iCK2U69IDurvZVodhWo(mutableIntState4, mutableIntState3, mutableState6, i12 + 1);
                                            break;
                                    }
                                    return unit;
                                }
                            };
                            composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui12);
                        } else {
                            mutableState = mutableState3;
                        }
                        kotlin.jvm.functions.Function0 function04 = (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui12;
                        if (!runResult.uMOFIbPk0BxLkjW3KR7() || i9 + 1 >= 60) {
                            mutableState2 = mutableState;
                            composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1856808277);
                        } else {
                            composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1856785834);
                            boolean zGzg71nUFKNF0JyxrFIK2 = composerBn6dcy3rRNTGfMyxjUW.gzg71nUFKNF0JyxrFIK(i9);
                            java.lang.Object objG069ZlNT3DZHrdUtBui13 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                            if (zGzg71nUFKNF0JyxrFIK2 || objG069ZlNT3DZHrdUtBui13 == composer$Companion$Empty$1) {
                                final int i11 = 1;
                                objG069ZlNT3DZHrdUtBui13 = new kotlin.jvm.functions.Function0() { // from class: e1
                                    @Override // kotlin.jvm.functions.Function0
                                    public final java.lang.Object iCK2U69IDurvZVodhWo() {
                                        int i112 = i11;
                                        kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                        androidx.compose.runtime.MutableState mutableState6 = mutableState;
                                        androidx.compose.runtime.MutableIntState mutableIntState3 = mutableIntState2;
                                        androidx.compose.runtime.MutableIntState mutableIntState4 = mutableIntState;
                                        int i12 = i9;
                                        switch (i112) {
                                            case 0:
                                                com.kolosta.rejin.tarlyons.MainActivityKt.iCK2U69IDurvZVodhWo(mutableIntState4, mutableIntState3, mutableState6, i12);
                                                break;
                                            default:
                                                com.kolosta.rejin.tarlyons.MainActivityKt.iCK2U69IDurvZVodhWo(mutableIntState4, mutableIntState3, mutableState6, i12 + 1);
                                                break;
                                        }
                                        return unit;
                                    }
                                };
                                mutableState2 = mutableState;
                                composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui13);
                            } else {
                                mutableState2 = mutableState;
                            }
                            function0 = (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui13;
                        }
                        composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                        java.lang.Object objG069ZlNT3DZHrdUtBui14 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                        if (objG069ZlNT3DZHrdUtBui14 == composer$Companion$Empty$1) {
                            objG069ZlNT3DZHrdUtBui14 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                                @Override // kotlin.jvm.functions.Function0
                                public final java.lang.Object iCK2U69IDurvZVodhWo() {
                                    int i72 = i8;
                                    kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                    androidx.compose.runtime.MutableState mutableState6 = mutableState2;
                                    switch (i72) {
                                        case 0:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                            break;
                                        case 1:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                            break;
                                        case 2:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                            break;
                                        case 3:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                            break;
                                        case 4:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                            break;
                                        default:
                                            mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                            break;
                                    }
                                    return unit;
                                }
                            };
                            composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui14);
                        }
                        com.kolosta.rejin.tarlyons.ui.RevealScreenKt.iCK2U69IDurvZVodhWo(runResult, reward, tint, function04, function0, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui14, composerBn6dcy3rRNTGfMyxjUW, 196608);
                        composerBn6dcy3rRNTGfMyxjUW = composerBn6dcy3rRNTGfMyxjUW;
                        composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                    }
                    composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                } else {
                    if (iOrdinal != 4) {
                        composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(-1187072087);
                        composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                        defpackage.uMOFIbPk0BxLkjW3KR7.cwoLH2FPi4AIU5DJOyN();
                        return;
                    }
                    composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(-1187062114);
                    boolean zH0jYF7Mc76EKIPcCXvq2 = composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(coroutineScope) | composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(store);
                    java.lang.Object objG069ZlNT3DZHrdUtBui15 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                    if (zH0jYF7Mc76EKIPcCXvq2 || objG069ZlNT3DZHrdUtBui15 == composer$Companion$Empty$1) {
                        objG069ZlNT3DZHrdUtBui15 = new kotlin.jvm.functions.Function1() { // from class: com.kolosta.rejin.tarlyons.iCK2U69IDurvZVodhWo
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                                int i12 = i5;
                                kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                com.kolosta.rejin.tarlyons.data.Store store2 = store;
                                kotlinx.coroutines.CoroutineScope coroutineScope2 = coroutineScope;
                                switch (i12) {
                                    case 0:
                                        com.kolosta.rejin.tarlyons.data.Tint tint2 = (com.kolosta.rejin.tarlyons.data.Tint) obj;
                                        tint2.getClass();
                                        kotlinx.coroutines.BuildersKt.iCK2U69IDurvZVodhWo(coroutineScope2, null, null, new com.kolosta.rejin.tarlyons.MainActivityKt$App$7$1$1(store2, tint2, null), 3);
                                        break;
                                    default:
                                        kotlinx.coroutines.BuildersKt.iCK2U69IDurvZVodhWo(coroutineScope2, null, null, new com.kolosta.rejin.tarlyons.MainActivityKt$App$8$1$1(store2, ((java.lang.Integer) obj).intValue(), null), 3);
                                        break;
                                }
                                return unit;
                            }
                        };
                        composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui15);
                    }
                    kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui15;
                    boolean zH0jYF7Mc76EKIPcCXvq3 = composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(coroutineScope) | composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(store);
                    java.lang.Object objG069ZlNT3DZHrdUtBui16 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                    if (zH0jYF7Mc76EKIPcCXvq3 || objG069ZlNT3DZHrdUtBui16 == composer$Companion$Empty$1) {
                        objG069ZlNT3DZHrdUtBui16 = new kotlin.jvm.functions.Function1() { // from class: com.kolosta.rejin.tarlyons.iCK2U69IDurvZVodhWo
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                                int i12 = i6;
                                kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                com.kolosta.rejin.tarlyons.data.Store store2 = store;
                                kotlinx.coroutines.CoroutineScope coroutineScope2 = coroutineScope;
                                switch (i12) {
                                    case 0:
                                        com.kolosta.rejin.tarlyons.data.Tint tint2 = (com.kolosta.rejin.tarlyons.data.Tint) obj;
                                        tint2.getClass();
                                        kotlinx.coroutines.BuildersKt.iCK2U69IDurvZVodhWo(coroutineScope2, null, null, new com.kolosta.rejin.tarlyons.MainActivityKt$App$7$1$1(store2, tint2, null), 3);
                                        break;
                                    default:
                                        kotlinx.coroutines.BuildersKt.iCK2U69IDurvZVodhWo(coroutineScope2, null, null, new com.kolosta.rejin.tarlyons.MainActivityKt$App$8$1$1(store2, ((java.lang.Integer) obj).intValue(), null), 3);
                                        break;
                                }
                                return unit;
                            }
                        };
                        composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui16);
                    }
                    kotlin.jvm.functions.Function1 function13 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui16;
                    java.lang.Object objG069ZlNT3DZHrdUtBui17 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                    if (objG069ZlNT3DZHrdUtBui17 == composer$Companion$Empty$1) {
                        objG069ZlNT3DZHrdUtBui17 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object iCK2U69IDurvZVodhWo() {
                                int i72 = i6;
                                kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                                androidx.compose.runtime.MutableState mutableState6 = mutableState3;
                                switch (i72) {
                                    case 0:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                        break;
                                    case 1:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                        break;
                                    case 2:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                        break;
                                    case 3:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                        break;
                                    case 4:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                        break;
                                    default:
                                        mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                        break;
                                }
                                return unit;
                            }
                        };
                        composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui17);
                    }
                    com.kolosta.rejin.tarlyons.ui.CabinetScreenKt.iCK2U69IDurvZVodhWo(snapshot2, function12, function13, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui17, composerBn6dcy3rRNTGfMyxjUW, 3072);
                    composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
                }
            } else {
                composerBn6dcy3rRNTGfMyxjUW.JnYgR1cE6e0Di97yUx9(1852946298);
                composerBn6dcy3rRNTGfMyxjUW.GRDgDa6Vavh8ZfltzLU(-1187054284, java.lang.Integer.valueOf(mutableIntState2.iCK2U69IDurvZVodhWo()));
                java.util.List list = com.kolosta.rejin.tarlyons.game.Trays.uMOFIbPk0BxLkjW3KR7;
                int iICK2U69IDurvZVodhWo = mutableIntState.iCK2U69IDurvZVodhWo();
                java.util.HashMap map = com.kolosta.rejin.tarlyons.game.Trays.iCK2U69IDurvZVodhWo;
                synchronized (map) {
                    try {
                        java.lang.Integer numValueOf = java.lang.Integer.valueOf(iICK2U69IDurvZVodhWo);
                        java.lang.Object objUMOFIbPk0BxLkjW3KR7 = map.get(numValueOf);
                        if (objUMOFIbPk0BxLkjW3KR7 == null) {
                            objUMOFIbPk0BxLkjW3KR7 = com.kolosta.rejin.tarlyons.game.Trays.uMOFIbPk0BxLkjW3KR7(iICK2U69IDurvZVodhWo);
                            map.put(numValueOf, objUMOFIbPk0BxLkjW3KR7);
                        }
                        tray = (com.kolosta.rejin.tarlyons.game.Tray) objUMOFIbPk0BxLkjW3KR7;
                    } catch (java.lang.Throwable th) {
                        throw th;
                    }
                }
                com.kolosta.rejin.tarlyons.data.Tint tint2 = snapshot2.A39SiWGux5Rbalqx5tb;
                boolean zH0jYF7Mc76EKIPcCXvq4 = composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(coroutineScope) | composerBn6dcy3rRNTGfMyxjUW.H0jYF7Mc76EKIPcCXvq(store);
                java.lang.Object objG069ZlNT3DZHrdUtBui18 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (zH0jYF7Mc76EKIPcCXvq4 || objG069ZlNT3DZHrdUtBui18 == composer$Companion$Empty$1) {
                    kotlin.jvm.functions.Function1 function14 = new kotlin.jvm.functions.Function1() { // from class: com.kolosta.rejin.tarlyons.VddF2l9gapSy7l41Z9d
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object gzg71nUFKNF0JyxrFIK(java.lang.Object obj) {
                            com.kolosta.rejin.tarlyons.game.RunResult runResult2 = (com.kolosta.rejin.tarlyons.game.RunResult) obj;
                            runResult2.getClass();
                            mutableState4.setValue(runResult2);
                            androidx.compose.runtime.MutableState mutableState6 = mutableState5;
                            mutableState6.setValue(null);
                            if (runResult2.uMOFIbPk0BxLkjW3KR7()) {
                                kotlinx.coroutines.BuildersKt.iCK2U69IDurvZVodhWo(coroutineScope, null, null, new com.kolosta.rejin.tarlyons.MainActivityKt$App$10$1$1(store, runResult2, mutableState6, null), 3);
                            }
                            mutableState3.setValue(com.kolosta.rejin.tarlyons.Screen.EYwcyipzkILQreEEPxc);
                            return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(function14);
                    objG069ZlNT3DZHrdUtBui18 = function14;
                }
                kotlin.jvm.functions.Function1 function15 = (kotlin.jvm.functions.Function1) objG069ZlNT3DZHrdUtBui18;
                java.lang.Object objG069ZlNT3DZHrdUtBui19 = composerBn6dcy3rRNTGfMyxjUW.G069ZlNT3DZHrdUtBui();
                if (objG069ZlNT3DZHrdUtBui19 == composer$Companion$Empty$1) {
                    objG069ZlNT3DZHrdUtBui19 = new kotlin.jvm.functions.Function0() { // from class: com.kolosta.rejin.tarlyons.uMOFIbPk0BxLkjW3KR7
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object iCK2U69IDurvZVodhWo() {
                            int i72 = i3;
                            kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                            androidx.compose.runtime.MutableState mutableState6 = mutableState3;
                            switch (i72) {
                                case 0:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 1:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 2:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 3:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.GerKUYaWR62lFxYixsm);
                                    break;
                                case 4:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.A39SiWGux5Rbalqx5tb);
                                    break;
                                default:
                                    mutableState6.setValue(com.kolosta.rejin.tarlyons.Screen.j0yhOfa7n1b2lkVBAKt);
                                    break;
                            }
                            return unit;
                        }
                    };
                    composerBn6dcy3rRNTGfMyxjUW.jyQgYr7taKJMPwY9vWQ(objG069ZlNT3DZHrdUtBui19);
                }
                com.kolosta.rejin.tarlyons.ui.PlayScreenKt.uMOFIbPk0BxLkjW3KR7(tray, tint2, function15, (kotlin.jvm.functions.Function0) objG069ZlNT3DZHrdUtBui19, composerBn6dcy3rRNTGfMyxjUW, 3072);
                composerBn6dcy3rRNTGfMyxjUW.pRCzcKHbTdhACOvA8KQ();
                composerBn6dcy3rRNTGfMyxjUW.zw4zyD7jgFPVK81d6J1();
            }
        } else {
            composerBn6dcy3rRNTGfMyxjUW.PMZrLoc0NF3euziS99o();
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv2 = composerBn6dcy3rRNTGfMyxjUW.FxRXIWoAgaLNLQUc6Qv();
        if (scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv2 != null) {
            scopeUpdateScopeFxRXIWoAgaLNLQUc6Qv2.uMOFIbPk0BxLkjW3KR7(new defpackage.d1(store, i, 2));
        }
    }
}
