package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Snapshot;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final /* data */ class Snapshot {
    public final com.kolosta.rejin.tarlyons.data.Tint A39SiWGux5Rbalqx5tb;
    public final java.util.LinkedHashSet GerKUYaWR62lFxYixsm;
    public final java.util.Set PMZrLoc0NF3euziS99o;
    public final java.util.Set VddF2l9gapSy7l41Z9d;
    public final java.util.Map iCK2U69IDurvZVodhWo;
    public final int uMOFIbPk0BxLkjW3KR7;

    public Snapshot(int i, java.util.Map map, java.util.Set set, java.util.LinkedHashSet linkedHashSet, com.kolosta.rejin.tarlyons.data.Tint tint, java.util.Set set2) {
        this.uMOFIbPk0BxLkjW3KR7 = i;
        this.iCK2U69IDurvZVodhWo = map;
        this.VddF2l9gapSy7l41Z9d = set;
        this.GerKUYaWR62lFxYixsm = linkedHashSet;
        this.A39SiWGux5Rbalqx5tb = tint;
        this.PMZrLoc0NF3euziS99o = set2;
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com.kolosta.rejin.tarlyons.data.Snapshot)) {
            return false;
        }
        com.kolosta.rejin.tarlyons.data.Snapshot snapshot = (com.kolosta.rejin.tarlyons.data.Snapshot) obj;
        return this.uMOFIbPk0BxLkjW3KR7 == snapshot.uMOFIbPk0BxLkjW3KR7 && this.iCK2U69IDurvZVodhWo.equals(snapshot.iCK2U69IDurvZVodhWo) && this.VddF2l9gapSy7l41Z9d.equals(snapshot.VddF2l9gapSy7l41Z9d) && this.GerKUYaWR62lFxYixsm.equals(snapshot.GerKUYaWR62lFxYixsm) && this.A39SiWGux5Rbalqx5tb == snapshot.A39SiWGux5Rbalqx5tb && this.PMZrLoc0NF3euziS99o.equals(snapshot.PMZrLoc0NF3euziS99o);
    }

    public final int hashCode() {
        return this.PMZrLoc0NF3euziS99o.hashCode() + ((this.A39SiWGux5Rbalqx5tb.hashCode() + ((this.GerKUYaWR62lFxYixsm.hashCode() + ((this.VddF2l9gapSy7l41Z9d.hashCode() + ((this.iCK2U69IDurvZVodhWo.hashCode() + (java.lang.Integer.hashCode(this.uMOFIbPk0BxLkjW3KR7) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final java.lang.String toString() {
        return "Snapshot(unlocked=" + this.uMOFIbPk0BxLkjW3KR7 + ", drops=" + this.iCK2U69IDurvZVodhWo + ", perfect=" + this.VddF2l9gapSy7l41Z9d + ", tints=" + this.GerKUYaWR62lFxYixsm + ", equipped=" + this.A39SiWGux5Rbalqx5tb + ", boards=" + this.PMZrLoc0NF3euziS99o + ")";
    }
}
