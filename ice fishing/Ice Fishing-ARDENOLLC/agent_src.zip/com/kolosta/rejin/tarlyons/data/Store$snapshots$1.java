package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\u0010\u0000\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010\u0004\u001a\u00020\u0005H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/flow/FlowCollector;", "Landroidx/datastore/preferences/core/Preferences;", "it", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store$snapshots$1", f = "Store.kt", l = {54}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class Store$snapshots$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function3<kotlinx.coroutines.flow.FlowCollector<? super androidx.datastore.preferences.core.Preferences>, java.lang.Throwable, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    public /* synthetic */ java.lang.Throwable G069ZlNT3DZHrdUtBui;
    public int j0yhOfa7n1b2lkVBAKt;
    public /* synthetic */ kotlinx.coroutines.flow.FlowCollector lVvt79Js7aeYnsjUe7L;

    @Override // kotlin.jvm.functions.Function3
    public final java.lang.Object G069ZlNT3DZHrdUtBui(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
        com.kolosta.rejin.tarlyons.data.Store$snapshots$1 store$snapshots$1 = new com.kolosta.rejin.tarlyons.data.Store$snapshots$1(3, (kotlin.coroutines.Continuation) obj3);
        store$snapshots$1.lVvt79Js7aeYnsjUe7L = (kotlinx.coroutines.flow.FlowCollector) obj;
        store$snapshots$1.G069ZlNT3DZHrdUtBui = (java.lang.Throwable) obj2;
        return store$snapshots$1.Q9Nq566vXkbJ4Iw58qn(kotlin.Unit.uMOFIbPk0BxLkjW3KR7);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) throws java.lang.Throwable {
        kotlinx.coroutines.flow.FlowCollector flowCollector = this.lVvt79Js7aeYnsjUe7L;
        java.lang.Throwable th = this.G069ZlNT3DZHrdUtBui;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        int i = this.j0yhOfa7n1b2lkVBAKt;
        boolean z = true;
        if (i == 0) {
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
            if (!(th instanceof java.io.IOException)) {
                throw th;
            }
            androidx.datastore.preferences.core.MutablePreferences mutablePreferences = new androidx.datastore.preferences.core.MutablePreferences(z);
            this.lVvt79Js7aeYnsjUe7L = null;
            this.G069ZlNT3DZHrdUtBui = null;
            this.j0yhOfa7n1b2lkVBAKt = 1;
            if (flowCollector.VddF2l9gapSy7l41Z9d(mutablePreferences, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (i != 1) {
                defpackage.uMOFIbPk0BxLkjW3KR7.H0jYF7Mc76EKIPcCXvq("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        }
        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }
}
