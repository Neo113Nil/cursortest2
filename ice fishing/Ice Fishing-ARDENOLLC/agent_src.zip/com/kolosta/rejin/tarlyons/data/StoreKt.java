package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class StoreKt {
    public static final androidx.datastore.preferences.PreferenceDataStoreSingletonDelegate iCK2U69IDurvZVodhWo;
    public static final /* synthetic */ kotlin.reflect.KProperty[] uMOFIbPk0BxLkjW3KR7;

    static {
        kotlin.jvm.internal.PropertyReference1Impl propertyReference1Impl = new kotlin.jvm.internal.PropertyReference1Impl(com.kolosta.rejin.tarlyons.data.StoreKt.class, "kintsugiStore", "getKintsugiStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;");
        kotlin.jvm.internal.Reflection.uMOFIbPk0BxLkjW3KR7.getClass();
        uMOFIbPk0BxLkjW3KR7 = new kotlin.reflect.KProperty[]{propertyReference1Impl};
        iCK2U69IDurvZVodhWo = androidx.datastore.preferences.PreferenceDataStoreDelegateKt.uMOFIbPk0BxLkjW3KR7();
    }
}
