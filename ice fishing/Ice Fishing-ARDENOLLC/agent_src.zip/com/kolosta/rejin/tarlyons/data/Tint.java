package com.kolosta.rejin.tarlyons.data;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u000f\b\u0087\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B!\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015¨\u0006\u0016"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Tint;", "", "label", "", "drops", "", "color", "", "<init>", "(Ljava/lang/String;ILjava/lang/String;IJ)V", "getLabel", "()Ljava/lang/String;", "getDrops", "()I", "getColor", "()J", "GOLD", "ROSE", "SILVER", "COPPER", "JADE", "LILAC", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Tint {
    private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
    private static final /* synthetic */ com.kolosta.rejin.tarlyons.data.Tint[] $VALUES;
    private final long color;
    private final int drops;
    private final java.lang.String label;
    public static final com.kolosta.rejin.tarlyons.data.Tint GOLD = new com.kolosta.rejin.tarlyons.data.Tint("GOLD", 0, "Lake Gold", 0, 4293047886L);
    public static final com.kolosta.rejin.tarlyons.data.Tint ROSE = new com.kolosta.rejin.tarlyons.data.Tint("ROSE", 1, "Rose Gold", 12, 4293502351L);
    public static final com.kolosta.rejin.tarlyons.data.Tint SILVER = new com.kolosta.rejin.tarlyons.data.Tint("SILVER", 2, "Moon Silver", 36, 4292074984L);
    public static final com.kolosta.rejin.tarlyons.data.Tint COPPER = new com.kolosta.rejin.tarlyons.data.Tint("COPPER", 3, "Ember Copper", 70, 4292577870L);
    public static final com.kolosta.rejin.tarlyons.data.Tint JADE = new com.kolosta.rejin.tarlyons.data.Tint("JADE", 4, "Pale Jade", 110, 4288600504L);
    public static final com.kolosta.rejin.tarlyons.data.Tint LILAC = new com.kolosta.rejin.tarlyons.data.Tint("LILAC", 5, "Aurora Lilac", 150, 4291209970L);

    private static final /* synthetic */ com.kolosta.rejin.tarlyons.data.Tint[] $values() {
        return new com.kolosta.rejin.tarlyons.data.Tint[]{GOLD, ROSE, SILVER, COPPER, JADE, LILAC};
    }

    static {
        com.kolosta.rejin.tarlyons.data.Tint[] tintArr$values = $values();
        $VALUES = tintArr$values;
        $ENTRIES = kotlin.enums.EnumEntriesKt.uMOFIbPk0BxLkjW3KR7(tintArr$values);
    }

    private Tint(java.lang.String str, int i, java.lang.String str2, int i2, long j) {
        this.label = str2;
        this.drops = i2;
        this.color = j;
    }

    public static kotlin.enums.EnumEntries<com.kolosta.rejin.tarlyons.data.Tint> getEntries() {
        return $ENTRIES;
    }

    public static com.kolosta.rejin.tarlyons.data.Tint valueOf(java.lang.String str) {
        return (com.kolosta.rejin.tarlyons.data.Tint) java.lang.Enum.valueOf(com.kolosta.rejin.tarlyons.data.Tint.class, str);
    }

    public static com.kolosta.rejin.tarlyons.data.Tint[] values() {
        return (com.kolosta.rejin.tarlyons.data.Tint[]) $VALUES.clone();
    }

    public final long getColor() {
        return this.color;
    }

    public final int getDrops() {
        return this.drops;
    }

    public final java.lang.String getLabel() {
        return this.label;
    }
}
