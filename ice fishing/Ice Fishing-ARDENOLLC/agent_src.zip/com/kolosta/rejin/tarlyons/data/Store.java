package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Store;", "", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Store {
    public final com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1 iCK2U69IDurvZVodhWo;
    public final androidx.datastore.core.DataStore uMOFIbPk0BxLkjW3KR7;
    public static final androidx.datastore.preferences.core.Preferences.Key VddF2l9gapSy7l41Z9d = new androidx.datastore.preferences.core.Preferences.Key("unlocked_tray");
    public static final androidx.datastore.preferences.core.Preferences.Key GerKUYaWR62lFxYixsm = new androidx.datastore.preferences.core.Preferences.Key("lacquer_drops");
    public static final androidx.datastore.preferences.core.Preferences.Key A39SiWGux5Rbalqx5tb = new androidx.datastore.preferences.core.Preferences.Key("perfect_trays");
    public static final androidx.datastore.preferences.core.Preferences.Key PMZrLoc0NF3euziS99o = new androidx.datastore.preferences.core.Preferences.Key("resin_tints");
    public static final androidx.datastore.preferences.core.Preferences.Key EYwcyipzkILQreEEPxc = new androidx.datastore.preferences.core.Preferences.Key("equipped_tint");
    public static final androidx.datastore.preferences.core.Preferences.Key j0yhOfa7n1b2lkVBAKt = new androidx.datastore.preferences.core.Preferences.Key("cabinet_boards");

    /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0082\u0003\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Store$Companion;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1] */
    public Store(android.content.Context context) {
        android.content.Context applicationContext = context.getApplicationContext();
        applicationContext.getClass();
        androidx.datastore.core.DataStore dataStore = (androidx.datastore.core.DataStore) com.kolosta.rejin.tarlyons.data.StoreKt.iCK2U69IDurvZVodhWo.uMOFIbPk0BxLkjW3KR7(applicationContext, com.kolosta.rejin.tarlyons.data.StoreKt.uMOFIbPk0BxLkjW3KR7[0]);
        this.uMOFIbPk0BxLkjW3KR7 = dataStore;
        final kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1 flowKt__ErrorsKt$catch$$inlined$unsafeFlow$1 = new kotlinx.coroutines.flow.FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1(dataStore.iCK2U69IDurvZVodhWo(), new com.kolosta.rejin.tarlyons.data.Store$snapshots$1(3, null));
        this.iCK2U69IDurvZVodhWo = new kotlinx.coroutines.flow.Flow<com.kolosta.rejin.tarlyons.data.Snapshot>() { // from class: com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1

            /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
            @kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            /* renamed from: com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1$2, reason: invalid class name */
            public final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                public final /* synthetic */ kotlinx.coroutines.flow.FlowCollector GerKUYaWR62lFxYixsm;

                @kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1$2", f = "Store.kt", l = {50}, m = "emit")
                /* renamed from: com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1$2$1, reason: invalid class name */
                public final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    public /* synthetic */ java.lang.Object EYwcyipzkILQreEEPxc;
                    public int j0yhOfa7n1b2lkVBAKt;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
                        this.EYwcyipzkILQreEEPxc = obj;
                        this.j0yhOfa7n1b2lkVBAKt |= Integer.MIN_VALUE;
                        return com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2.this.VddF2l9gapSy7l41Z9d(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.GerKUYaWR62lFxYixsm = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object VddF2l9gapSy7l41Z9d(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    if (continuation instanceof com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        int i = anonymousClass1.j0yhOfa7n1b2lkVBAKt;
                        if ((i & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.j0yhOfa7n1b2lkVBAKt = i - Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                        }
                    }
                    java.lang.Object obj2 = anonymousClass1.EYwcyipzkILQreEEPxc;
                    kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
                    int i2 = anonymousClass1.j0yhOfa7n1b2lkVBAKt;
                    com.kolosta.rejin.tarlyons.data.Tint tint = null;
                    if (i2 == 0) {
                        kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj2);
                        androidx.datastore.preferences.core.Preferences preferences = (androidx.datastore.preferences.core.Preferences) obj;
                        java.lang.Integer num = (java.lang.Integer) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.VddF2l9gapSy7l41Z9d);
                        int iIntValue = num != null ? num.intValue() : 0;
                        java.util.Map mapICK2U69IDurvZVodhWo = com.kolosta.rejin.tarlyons.data.CodecKt.iCK2U69IDurvZVodhWo((java.lang.String) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.GerKUYaWR62lFxYixsm));
                        java.util.Set setJkKMrfloFo2xH4UTgso = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(com.kolosta.rejin.tarlyons.data.CodecKt.VddF2l9gapSy7l41Z9d((java.lang.String) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.A39SiWGux5Rbalqx5tb)));
                        java.util.LinkedHashSet linkedHashSetUMOFIbPk0BxLkjW3KR7 = com.kolosta.rejin.tarlyons.data.CodecKt.uMOFIbPk0BxLkjW3KR7((java.lang.String) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.PMZrLoc0NF3euziS99o), com.kolosta.rejin.tarlyons.data.Tint.getEntries());
                        com.kolosta.rejin.tarlyons.data.Tint tint2 = com.kolosta.rejin.tarlyons.data.Tint.GOLD;
                        java.util.LinkedHashSet linkedHashSetUMOFIbPk0BxLkjW3KR72 = kotlin.collections.SetsKt.uMOFIbPk0BxLkjW3KR7(linkedHashSetUMOFIbPk0BxLkjW3KR7, tint2);
                        java.lang.String str = (java.lang.String) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.EYwcyipzkILQreEEPxc);
                        kotlin.enums.EnumEntries<com.kolosta.rejin.tarlyons.data.Tint> entries = com.kolosta.rejin.tarlyons.data.Tint.getEntries();
                        entries.getClass();
                        tint2.getClass();
                        java.util.Iterator<com.kolosta.rejin.tarlyons.data.Tint> it = entries.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                break;
                            }
                            com.kolosta.rejin.tarlyons.data.Tint next = it.next();
                            if (kotlin.jvm.internal.Intrinsics.uMOFIbPk0BxLkjW3KR7(next.name(), str)) {
                                tint = next;
                                break;
                            }
                        }
                        com.kolosta.rejin.tarlyons.data.Tint tint3 = tint;
                        if (tint3 != null) {
                            tint2 = tint3;
                        }
                        com.kolosta.rejin.tarlyons.data.Snapshot snapshot = new com.kolosta.rejin.tarlyons.data.Snapshot(iIntValue, mapICK2U69IDurvZVodhWo, setJkKMrfloFo2xH4UTgso, linkedHashSetUMOFIbPk0BxLkjW3KR72, tint2, kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(com.kolosta.rejin.tarlyons.data.CodecKt.VddF2l9gapSy7l41Z9d((java.lang.String) preferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.j0yhOfa7n1b2lkVBAKt))));
                        anonymousClass1.j0yhOfa7n1b2lkVBAKt = 1;
                        if (this.GerKUYaWR62lFxYixsm.VddF2l9gapSy7l41Z9d(snapshot, anonymousClass1) == coroutineSingletons) {
                            return coroutineSingletons;
                        }
                    } else {
                        if (i2 != 1) {
                            defpackage.uMOFIbPk0BxLkjW3KR7.H0jYF7Mc76EKIPcCXvq("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj2);
                    }
                    return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public final java.lang.Object uMOFIbPk0BxLkjW3KR7(kotlinx.coroutines.flow.FlowCollector flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object objUMOFIbPk0BxLkjW3KR7 = flowKt__ErrorsKt$catch$$inlined$unsafeFlow$1.uMOFIbPk0BxLkjW3KR7(new com.kolosta.rejin.tarlyons.data.Store$special$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return objUMOFIbPk0BxLkjW3KR7 == kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm ? objUMOFIbPk0BxLkjW3KR7 : kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
            }
        };
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object VddF2l9gapSy7l41Z9d(int i, int i2, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        com.kolosta.rejin.tarlyons.data.Store$recordTray$1 store$recordTray$1;
        kotlin.jvm.internal.Ref.ObjectRef objectRef;
        if (continuationImpl instanceof com.kolosta.rejin.tarlyons.data.Store$recordTray$1) {
            store$recordTray$1 = (com.kolosta.rejin.tarlyons.data.Store$recordTray$1) continuationImpl;
            int i3 = store$recordTray$1.G069ZlNT3DZHrdUtBui;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                store$recordTray$1.G069ZlNT3DZHrdUtBui = i3 - Integer.MIN_VALUE;
            } else {
                store$recordTray$1 = new com.kolosta.rejin.tarlyons.data.Store$recordTray$1(this, continuationImpl);
            }
        }
        java.lang.Object obj = store$recordTray$1.j0yhOfa7n1b2lkVBAKt;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        int i4 = store$recordTray$1.G069ZlNT3DZHrdUtBui;
        if (i4 == 0) {
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
            kotlin.jvm.internal.Ref.ObjectRef objectRef2 = new kotlin.jvm.internal.Ref.ObjectRef();
            objectRef2.GerKUYaWR62lFxYixsm = new com.kolosta.rejin.tarlyons.data.Reward(0, i2, kotlin.collections.EmptyList.GerKUYaWR62lFxYixsm);
            com.kolosta.rejin.tarlyons.data.Store$recordTray$2 store$recordTray$2 = new com.kolosta.rejin.tarlyons.data.Store$recordTray$2(i, i2, objectRef2, null);
            store$recordTray$1.EYwcyipzkILQreEEPxc = objectRef2;
            store$recordTray$1.G069ZlNT3DZHrdUtBui = 1;
            if (androidx.datastore.preferences.core.PreferencesKt.uMOFIbPk0BxLkjW3KR7(this.uMOFIbPk0BxLkjW3KR7, store$recordTray$2, store$recordTray$1) == coroutineSingletons) {
                return coroutineSingletons;
            }
            objectRef = objectRef2;
        } else {
            if (i4 != 1) {
                defpackage.uMOFIbPk0BxLkjW3KR7.H0jYF7Mc76EKIPcCXvq("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            objectRef = store$recordTray$1.EYwcyipzkILQreEEPxc;
            kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        }
        return objectRef.GerKUYaWR62lFxYixsm;
    }

    public final java.lang.Object iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Tint tint, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objUMOFIbPk0BxLkjW3KR7 = androidx.datastore.preferences.core.PreferencesKt.uMOFIbPk0BxLkjW3KR7(this.uMOFIbPk0BxLkjW3KR7, new com.kolosta.rejin.tarlyons.data.Store$equip$2(tint, null), (kotlin.coroutines.jvm.internal.ContinuationImpl) continuation);
        return objUMOFIbPk0BxLkjW3KR7 == kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm ? objUMOFIbPk0BxLkjW3KR7 : kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }

    public final java.lang.Object uMOFIbPk0BxLkjW3KR7(int i, kotlin.coroutines.Continuation continuation) {
        java.lang.Object objUMOFIbPk0BxLkjW3KR7 = androidx.datastore.preferences.core.PreferencesKt.uMOFIbPk0BxLkjW3KR7(this.uMOFIbPk0BxLkjW3KR7, new com.kolosta.rejin.tarlyons.data.Store$assemble$2(i, null), (kotlin.coroutines.jvm.internal.ContinuationImpl) continuation);
        return objUMOFIbPk0BxLkjW3KR7 == kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm ? objUMOFIbPk0BxLkjW3KR7 : kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }
}
