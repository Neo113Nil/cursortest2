package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/data/Reward;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Reward {
    public final int VddF2l9gapSy7l41Z9d;
    public final java.util.List iCK2U69IDurvZVodhWo;
    public final int uMOFIbPk0BxLkjW3KR7;

    public Reward(int i, int i2, java.util.List list) {
        this.uMOFIbPk0BxLkjW3KR7 = i;
        this.iCK2U69IDurvZVodhWo = list;
        this.VddF2l9gapSy7l41Z9d = i2;
    }
}
