package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "p", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store$assemble$2", f = "Store.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class Store$assemble$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    public /* synthetic */ java.lang.Object j0yhOfa7n1b2lkVBAKt;
    public final /* synthetic */ int lVvt79Js7aeYnsjUe7L;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Store$assemble$2(int i, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.lVvt79Js7aeYnsjUe7L = i;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
        com.kolosta.rejin.tarlyons.data.Store$assemble$2 store$assemble$2 = (com.kolosta.rejin.tarlyons.data.Store$assemble$2) OBWx8K2uSIyiwkjsL0N((androidx.datastore.preferences.core.MutablePreferences) obj, (kotlin.coroutines.Continuation) obj2);
        kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
        store$assemble$2.Q9Nq566vXkbJ4Iw58qn(unit);
        return unit;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation OBWx8K2uSIyiwkjsL0N(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        com.kolosta.rejin.tarlyons.data.Store$assemble$2 store$assemble$2 = new com.kolosta.rejin.tarlyons.data.Store$assemble$2(this.lVvt79Js7aeYnsjUe7L, continuation);
        store$assemble$2.j0yhOfa7n1b2lkVBAKt = obj;
        return store$assemble$2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
        androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.j0yhOfa7n1b2lkVBAKt;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        java.util.Set setJkKMrfloFo2xH4UTgso = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(com.kolosta.rejin.tarlyons.data.CodecKt.VddF2l9gapSy7l41Z9d((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.A39SiWGux5Rbalqx5tb)));
        java.util.Set setJkKMrfloFo2xH4UTgso2 = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(com.kolosta.rejin.tarlyons.data.CodecKt.VddF2l9gapSy7l41Z9d((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.j0yhOfa7n1b2lkVBAKt)));
        int i = this.lVvt79Js7aeYnsjUe7L;
        java.lang.Iterable iterableJ0yhOfa7n1b2lkVBAKt = kotlin.ranges.RangesKt.j0yhOfa7n1b2lkVBAKt(i * 15, (i + 1) * 15);
        kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
        if (i >= 0 && i < 4 && !setJkKMrfloFo2xH4UTgso2.contains(new java.lang.Integer(i))) {
            if ((iterableJ0yhOfa7n1b2lkVBAKt instanceof java.util.Collection) && ((java.util.Collection) iterableJ0yhOfa7n1b2lkVBAKt).isEmpty()) {
                mutablePreferences.GerKUYaWR62lFxYixsm(com.kolosta.rejin.tarlyons.data.Store.j0yhOfa7n1b2lkVBAKt, kotlin.collections.CollectionsKt.rPUzDQKbYL6WgvU9ySs(kotlin.collections.CollectionsKt.cu4Sb8NChS0DjnyJZJl(kotlin.collections.SetsKt.uMOFIbPk0BxLkjW3KR7(setJkKMrfloFo2xH4UTgso2, new java.lang.Integer(i))), ",", null, null, null, 62));
            } else {
                java.util.Iterator<java.lang.Integer> it = iterableJ0yhOfa7n1b2lkVBAKt.iterator();
                while (((kotlin.ranges.IntProgressionIterator) it).PMZrLoc0NF3euziS99o) {
                    if (!setJkKMrfloFo2xH4UTgso.contains(new java.lang.Integer(((kotlin.collections.IntIterator) it).nextInt()))) {
                        break;
                    }
                }
                mutablePreferences.GerKUYaWR62lFxYixsm(com.kolosta.rejin.tarlyons.data.Store.j0yhOfa7n1b2lkVBAKt, kotlin.collections.CollectionsKt.rPUzDQKbYL6WgvU9ySs(kotlin.collections.CollectionsKt.cu4Sb8NChS0DjnyJZJl(kotlin.collections.SetsKt.uMOFIbPk0BxLkjW3KR7(setJkKMrfloFo2xH4UTgso2, new java.lang.Integer(i))), ",", null, null, null, 62));
            }
        }
        return unit;
    }
}
