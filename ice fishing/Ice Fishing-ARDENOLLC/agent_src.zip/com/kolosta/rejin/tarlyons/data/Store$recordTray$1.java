package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store", f = "Store.kt", l = {69}, m = "recordTray")
/* loaded from: classes.dex */
final class Store$recordTray$1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
    public kotlin.jvm.internal.Ref.ObjectRef EYwcyipzkILQreEEPxc;
    public int G069ZlNT3DZHrdUtBui;
    public /* synthetic */ java.lang.Object j0yhOfa7n1b2lkVBAKt;
    public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Store lVvt79Js7aeYnsjUe7L;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Store$recordTray$1(com.kolosta.rejin.tarlyons.data.Store store, kotlin.coroutines.jvm.internal.ContinuationImpl continuationImpl) {
        super(continuationImpl);
        this.lVvt79Js7aeYnsjUe7L = store;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
        this.j0yhOfa7n1b2lkVBAKt = obj;
        this.G069ZlNT3DZHrdUtBui |= Integer.MIN_VALUE;
        return this.lVvt79Js7aeYnsjUe7L.VddF2l9gapSy7l41Z9d(0, 0, this);
    }
}
