package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "p", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store$equip$2", f = "Store.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class Store$equip$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    public /* synthetic */ java.lang.Object j0yhOfa7n1b2lkVBAKt;
    public final /* synthetic */ com.kolosta.rejin.tarlyons.data.Tint lVvt79Js7aeYnsjUe7L;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Store$equip$2(com.kolosta.rejin.tarlyons.data.Tint tint, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.lVvt79Js7aeYnsjUe7L = tint;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
        com.kolosta.rejin.tarlyons.data.Store$equip$2 store$equip$2 = (com.kolosta.rejin.tarlyons.data.Store$equip$2) OBWx8K2uSIyiwkjsL0N((androidx.datastore.preferences.core.MutablePreferences) obj, (kotlin.coroutines.Continuation) obj2);
        kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
        store$equip$2.Q9Nq566vXkbJ4Iw58qn(unit);
        return unit;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation OBWx8K2uSIyiwkjsL0N(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        com.kolosta.rejin.tarlyons.data.Store$equip$2 store$equip$2 = new com.kolosta.rejin.tarlyons.data.Store$equip$2(this.lVvt79Js7aeYnsjUe7L, continuation);
        store$equip$2.j0yhOfa7n1b2lkVBAKt = obj;
        return store$equip$2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
        androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.j0yhOfa7n1b2lkVBAKt;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        com.kolosta.rejin.tarlyons.data.Tint tint = com.kolosta.rejin.tarlyons.data.Tint.GOLD;
        com.kolosta.rejin.tarlyons.data.Tint tint2 = this.lVvt79Js7aeYnsjUe7L;
        if (tint2 == tint || com.kolosta.rejin.tarlyons.data.CodecKt.uMOFIbPk0BxLkjW3KR7((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.PMZrLoc0NF3euziS99o), com.kolosta.rejin.tarlyons.data.Tint.getEntries()).contains(tint2)) {
            mutablePreferences.GerKUYaWR62lFxYixsm(com.kolosta.rejin.tarlyons.data.Store.EYwcyipzkILQreEEPxc, tint2.name());
        }
        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }
}
