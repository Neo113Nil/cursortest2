package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class CodecKt {
    public static final java.util.ArrayList VddF2l9gapSy7l41Z9d(java.lang.String str) {
        if (str == null) {
            str = "";
        }
        java.util.List listRPUzDQKbYL6WgvU9ySs = kotlin.text.StringsKt.rPUzDQKbYL6WgvU9ySs(str, new char[]{','});
        java.util.ArrayList arrayList = new java.util.ArrayList();
        java.util.Iterator it = listRPUzDQKbYL6WgvU9ySs.iterator();
        while (it.hasNext()) {
            java.lang.Integer numHEMPdThLdw2U4SnnXcc = kotlin.text.StringsKt.HEMPdThLdw2U4SnnXcc((java.lang.String) it.next());
            if (numHEMPdThLdw2U4SnnXcc != null) {
                arrayList.add(numHEMPdThLdw2U4SnnXcc);
            }
        }
        return arrayList;
    }

    public static final java.util.Map iCK2U69IDurvZVodhWo(java.lang.String str) {
        java.lang.Integer numHEMPdThLdw2U4SnnXcc;
        java.lang.Integer numHEMPdThLdw2U4SnnXcc2;
        if (str == null) {
            str = "";
        }
        java.util.List listRPUzDQKbYL6WgvU9ySs = kotlin.text.StringsKt.rPUzDQKbYL6WgvU9ySs(str, new char[]{';'});
        java.util.ArrayList arrayList = new java.util.ArrayList();
        java.util.Iterator it = listRPUzDQKbYL6WgvU9ySs.iterator();
        while (it.hasNext()) {
            java.util.List listRPUzDQKbYL6WgvU9ySs2 = kotlin.text.StringsKt.rPUzDQKbYL6WgvU9ySs((java.lang.String) it.next(), new char[]{':'});
            kotlin.Pair pair = null;
            if (listRPUzDQKbYL6WgvU9ySs2.size() == 2 && (numHEMPdThLdw2U4SnnXcc = kotlin.text.StringsKt.HEMPdThLdw2U4SnnXcc((java.lang.String) listRPUzDQKbYL6WgvU9ySs2.get(0))) != null && (numHEMPdThLdw2U4SnnXcc2 = kotlin.text.StringsKt.HEMPdThLdw2U4SnnXcc((java.lang.String) listRPUzDQKbYL6WgvU9ySs2.get(1))) != null) {
                pair = new kotlin.Pair(numHEMPdThLdw2U4SnnXcc, numHEMPdThLdw2U4SnnXcc2);
            }
            if (pair != null) {
                arrayList.add(pair);
            }
        }
        return kotlin.collections.MapsKt.j0yhOfa7n1b2lkVBAKt(arrayList);
    }

    public static final java.util.LinkedHashSet uMOFIbPk0BxLkjW3KR7(java.lang.String str, kotlin.enums.EnumEntries enumEntries) {
        enumEntries.getClass();
        if (str == null) {
            str = "";
        }
        java.util.Set setJkKMrfloFo2xH4UTgso = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(kotlin.text.StringsKt.rPUzDQKbYL6WgvU9ySs(str, new char[]{','}));
        java.util.LinkedHashSet linkedHashSet = new java.util.LinkedHashSet();
        for (java.lang.Object obj : enumEntries) {
            if (setJkKMrfloFo2xH4UTgso.contains(((java.lang.Enum) obj).name())) {
                linkedHashSet.add(obj);
            }
        }
        return linkedHashSet;
    }
}
