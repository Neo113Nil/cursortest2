package com.kolosta.rejin.tarlyons.data;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "p", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "com.kolosta.rejin.tarlyons.data.Store$recordTray$2", f = "Store.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
final class Store$recordTray$2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    public final /* synthetic */ int G069ZlNT3DZHrdUtBui;
    public final /* synthetic */ kotlin.jvm.internal.Ref.ObjectRef JjLaFjoHTCoTSMjQa7q;
    public /* synthetic */ java.lang.Object j0yhOfa7n1b2lkVBAKt;
    public final /* synthetic */ int lVvt79Js7aeYnsjUe7L;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Store$recordTray$2(int i, int i2, kotlin.jvm.internal.Ref.ObjectRef objectRef, kotlin.coroutines.Continuation continuation) {
        super(2, continuation);
        this.lVvt79Js7aeYnsjUe7L = i;
        this.G069ZlNT3DZHrdUtBui = i2;
        this.JjLaFjoHTCoTSMjQa7q = objectRef;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object JjLaFjoHTCoTSMjQa7q(java.lang.Object obj, java.lang.Object obj2) {
        com.kolosta.rejin.tarlyons.data.Store$recordTray$2 store$recordTray$2 = (com.kolosta.rejin.tarlyons.data.Store$recordTray$2) OBWx8K2uSIyiwkjsL0N((androidx.datastore.preferences.core.MutablePreferences) obj, (kotlin.coroutines.Continuation) obj2);
        kotlin.Unit unit = kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
        store$recordTray$2.Q9Nq566vXkbJ4Iw58qn(unit);
        return unit;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation OBWx8K2uSIyiwkjsL0N(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
        com.kolosta.rejin.tarlyons.data.Store$recordTray$2 store$recordTray$2 = new com.kolosta.rejin.tarlyons.data.Store$recordTray$2(this.lVvt79Js7aeYnsjUe7L, this.G069ZlNT3DZHrdUtBui, this.JjLaFjoHTCoTSMjQa7q, continuation);
        store$recordTray$2.j0yhOfa7n1b2lkVBAKt = obj;
        return store$recordTray$2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object Q9Nq566vXkbJ4Iw58qn(java.lang.Object obj) {
        androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.j0yhOfa7n1b2lkVBAKt;
        kotlin.coroutines.intrinsics.CoroutineSingletons coroutineSingletons = kotlin.coroutines.intrinsics.CoroutineSingletons.GerKUYaWR62lFxYixsm;
        kotlin.ResultKt.iCK2U69IDurvZVodhWo(obj);
        androidx.datastore.preferences.core.Preferences.Key key = com.kolosta.rejin.tarlyons.data.Store.GerKUYaWR62lFxYixsm;
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap(com.kolosta.rejin.tarlyons.data.CodecKt.iCK2U69IDurvZVodhWo((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(key)));
        int i = this.lVvt79Js7aeYnsjUe7L;
        java.lang.Integer num = (java.lang.Integer) linkedHashMap.get(new java.lang.Integer(i));
        int iIntValue = 0;
        int iIntValue2 = num != null ? num.intValue() : 0;
        int i2 = this.G069ZlNT3DZHrdUtBui;
        int i3 = i2 - iIntValue2;
        if (i3 < 0) {
            i3 = 0;
        }
        if (i3 > 0) {
            linkedHashMap.put(new java.lang.Integer(i), new java.lang.Integer(i2));
        }
        mutablePreferences.A39SiWGux5Rbalqx5tb(key, kotlin.collections.CollectionsKt.rPUzDQKbYL6WgvU9ySs(kotlin.collections.CollectionsKt.pRCzcKHbTdhACOvA8KQ(linkedHashMap.entrySet(), new com.kolosta.rejin.tarlyons.data.CodecKt$encodeIntMap$$inlined$sortedBy$1()), ";", null, null, new defpackage.wDaxnHzF6aHr1xEjAAF(17), 30));
        if (i2 >= 3) {
            androidx.datastore.preferences.core.Preferences.Key key2 = com.kolosta.rejin.tarlyons.data.Store.A39SiWGux5Rbalqx5tb;
            mutablePreferences.A39SiWGux5Rbalqx5tb(key2, kotlin.collections.CollectionsKt.rPUzDQKbYL6WgvU9ySs(kotlin.collections.CollectionsKt.cu4Sb8NChS0DjnyJZJl(kotlin.collections.SetsKt.uMOFIbPk0BxLkjW3KR7(kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(com.kolosta.rejin.tarlyons.data.CodecKt.VddF2l9gapSy7l41Z9d((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(key2))), new java.lang.Integer(i))), ",", null, null, null, 62));
        }
        androidx.datastore.preferences.core.Preferences.Key key3 = com.kolosta.rejin.tarlyons.data.Store.VddF2l9gapSy7l41Z9d;
        java.lang.Integer num2 = (java.lang.Integer) mutablePreferences.iCK2U69IDurvZVodhWo(key3);
        mutablePreferences.A39SiWGux5Rbalqx5tb(key3, new java.lang.Integer(java.lang.Math.max(num2 != null ? num2.intValue() : 0, java.lang.Math.min(i + 1, 59))));
        java.util.Collection collectionValues = linkedHashMap.values();
        collectionValues.getClass();
        java.util.Iterator it = collectionValues.iterator();
        while (it.hasNext()) {
            iIntValue += ((java.lang.Number) it.next()).intValue();
        }
        java.util.LinkedHashSet linkedHashSetUMOFIbPk0BxLkjW3KR7 = kotlin.collections.SetsKt.uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.data.CodecKt.uMOFIbPk0BxLkjW3KR7((java.lang.String) mutablePreferences.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.data.Store.PMZrLoc0NF3euziS99o), com.kolosta.rejin.tarlyons.data.Tint.getEntries()), com.kolosta.rejin.tarlyons.data.Tint.GOLD);
        kotlin.enums.EnumEntries<com.kolosta.rejin.tarlyons.data.Tint> entries = com.kolosta.rejin.tarlyons.data.Tint.getEntries();
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (com.kolosta.rejin.tarlyons.data.Tint tint : entries) {
            com.kolosta.rejin.tarlyons.data.Tint tint2 = tint;
            if (tint2.getDrops() <= iIntValue && !linkedHashSetUMOFIbPk0BxLkjW3KR7.contains(tint2)) {
                arrayList.add(tint);
            }
        }
        androidx.datastore.preferences.core.Preferences.Key key4 = com.kolosta.rejin.tarlyons.data.Store.PMZrLoc0NF3euziS99o;
        java.util.LinkedHashSet linkedHashSet = new java.util.LinkedHashSet(kotlin.collections.MapsKt.A39SiWGux5Rbalqx5tb(linkedHashSetUMOFIbPk0BxLkjW3KR7.size() + arrayList.size()));
        linkedHashSet.addAll(linkedHashSetUMOFIbPk0BxLkjW3KR7);
        kotlin.collections.CollectionsKt.EYwcyipzkILQreEEPxc(arrayList, linkedHashSet);
        mutablePreferences.GerKUYaWR62lFxYixsm(key4, kotlin.collections.CollectionsKt.rPUzDQKbYL6WgvU9ySs(linkedHashSet, ",", null, null, new defpackage.wDaxnHzF6aHr1xEjAAF(18), 30));
        this.JjLaFjoHTCoTSMjQa7q.GerKUYaWR62lFxYixsm = new com.kolosta.rejin.tarlyons.data.Reward(i3, java.lang.Math.max(iIntValue2, i2), arrayList);
        return kotlin.Unit.uMOFIbPk0BxLkjW3KR7;
    }
}
