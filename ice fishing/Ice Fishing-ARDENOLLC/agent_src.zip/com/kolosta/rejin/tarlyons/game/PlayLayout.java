package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/PlayLayout;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class PlayLayout {
    public final float A39SiWGux5Rbalqx5tb;
    public final float Dpa63RlwGiNbcDAIHuO;
    public final float EYwcyipzkILQreEEPxc;
    public final float G069ZlNT3DZHrdUtBui;
    public final float GerKUYaWR62lFxYixsm;
    public final float H0jYF7Mc76EKIPcCXvq;
    public final float JjLaFjoHTCoTSMjQa7q;
    public final float PMZrLoc0NF3euziS99o;
    public final float VddF2l9gapSy7l41Z9d;
    public final float gzg71nUFKNF0JyxrFIK;
    public final float iCK2U69IDurvZVodhWo;
    public final float j0yhOfa7n1b2lkVBAKt;
    public final float lVvt79Js7aeYnsjUe7L;
    public final int uMOFIbPk0BxLkjW3KR7;
    public final float wDaxnHzF6aHr1xEjAAF;

    public PlayLayout(float f, float f2, float f3, int i, float f4, float f5) {
        this.uMOFIbPk0BxLkjW3KR7 = i;
        float f6 = (8.0f * f3) + f4;
        this.iCK2U69IDurvZVodhWo = f6;
        float f7 = 22.0f * f3;
        this.VddF2l9gapSy7l41Z9d = f7;
        this.GerKUYaWR62lFxYixsm = (16.0f * f3) + f7;
        this.A39SiWGux5Rbalqx5tb = f6 + f7;
        this.PMZrLoc0NF3euziS99o = 36.0f * f3;
        float f8 = f / 2.0f;
        this.EYwcyipzkILQreEEPxc = f8;
        float fMin = java.lang.Math.min(0.9f * f2, (f2 - f5) - (44.0f * f3));
        this.j0yhOfa7n1b2lkVBAKt = fMin;
        float fMax = java.lang.Math.max(0.17f * f2, (84.0f * f3) + f4);
        float f9 = ((i - 1) * 0.6f) + (i * 5) + 1.0f;
        float fMin2 = java.lang.Math.min(f2 * 0.82f, fMin - (86.0f * f3)) - fMax;
        float fMin3 = java.lang.Math.min((f - (f3 * 40.0f)) / 5.0f, fMin2 / f9);
        this.lVvt79Js7aeYnsjUe7L = fMin3;
        float f10 = 5.0f * fMin3;
        this.G069ZlNT3DZHrdUtBui = f10;
        this.JjLaFjoHTCoTSMjQa7q = (f - f10) / 2.0f;
        this.gzg71nUFKNF0JyxrFIK = ((fMin2 - (f9 * fMin3)) / 2.0f) + fMax;
        this.Dpa63RlwGiNbcDAIHuO = 0.36f * fMin3;
        this.wDaxnHzF6aHr1xEjAAF = f8;
        this.H0jYF7Mc76EKIPcCXvq = GerKUYaWR62lFxYixsm(0) - (fMin3 * 0.6f);
    }

    public final float GerKUYaWR62lFxYixsm(int i) {
        float f = this.gzg71nUFKNF0JyxrFIK;
        float f2 = this.lVvt79Js7aeYnsjUe7L;
        return (((f2 * 0.6f) + this.G069ZlNT3DZHrdUtBui) * i) + f + f2;
    }

    public final int VddF2l9gapSy7l41Z9d(float f, float f2) {
        float f3 = this.JjLaFjoHTCoTSMjQa7q;
        if (f >= f3) {
            float f4 = this.G069ZlNT3DZHrdUtBui;
            if (f <= f3 + f4) {
                for (int i = 0; i < this.uMOFIbPk0BxLkjW3KR7; i++) {
                    if (f2 >= GerKUYaWR62lFxYixsm(i) && f2 <= GerKUYaWR62lFxYixsm(i) + f4) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }

    public final float iCK2U69IDurvZVodhWo(int i) {
        if (i == 0) {
            return this.H0jYF7Mc76EKIPcCXvq;
        }
        return (((((i - 1) / 5) % 5) + 0.5f) * this.lVvt79Js7aeYnsjUe7L) + GerKUYaWR62lFxYixsm(com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(i));
    }

    public final float uMOFIbPk0BxLkjW3KR7(int i) {
        return i == 0 ? this.wDaxnHzF6aHr1xEjAAF : ((((i - 1) % 5) + 0.5f) * this.lVvt79Js7aeYnsjUe7L) + this.JjLaFjoHTCoTSMjQa7q;
    }
}
