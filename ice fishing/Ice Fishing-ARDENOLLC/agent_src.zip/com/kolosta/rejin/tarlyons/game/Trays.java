package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Trays;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Trays {
    public static final java.util.List uMOFIbPk0BxLkjW3KR7 = kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl("New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous", "Full Moon", "Waning Moon");
    public static final java.util.HashMap iCK2U69IDurvZVodhWo = new java.util.HashMap();

    public static kotlin.collections.builders.ListBuilder iCK2U69IDurvZVodhWo(int i) {
        int i2 = i % 5;
        int i3 = i / 5;
        kotlin.collections.builders.ListBuilder listBuilderH0jYF7Mc76EKIPcCXvq = kotlin.collections.CollectionsKt.H0jYF7Mc76EKIPcCXvq();
        if (i2 > 0) {
            listBuilderH0jYF7Mc76EKIPcCXvq.add(java.lang.Integer.valueOf(i - 1));
        }
        if (i2 < 4) {
            listBuilderH0jYF7Mc76EKIPcCXvq.add(java.lang.Integer.valueOf(i + 1));
        }
        if (i3 > 0) {
            listBuilderH0jYF7Mc76EKIPcCXvq.add(java.lang.Integer.valueOf(i - 5));
        }
        if (i3 < 4) {
            listBuilderH0jYF7Mc76EKIPcCXvq.add(java.lang.Integer.valueOf(i + 5));
        }
        return kotlin.collections.CollectionsKt.JjLaFjoHTCoTSMjQa7q(listBuilderH0jYF7Mc76EKIPcCXvq);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:128:0x041e  */
    /* JADX WARN: Removed duplicated region for block: B:234:0x07d3 A[LOOP:3: B:24:0x0134->B:234:0x07d3, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:244:0x07d2 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x01c9 A[LOOP:4: B:43:0x01c7->B:44:0x01c9, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x01d9  */
    /* JADX WARN: Type inference failed for: r1v63, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r1v64, types: [java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r1v67 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static com.kolosta.rejin.tarlyons.game.Tray uMOFIbPk0BxLkjW3KR7(int i) {
        kotlin.Pair pair;
        kotlin.Pair pair2;
        int i2;
        int i3;
        java.lang.Integer num;
        int i4;
        java.lang.Integer num2;
        int i5;
        kotlin.random.XorWowRandom xorWowRandom;
        com.kolosta.rejin.tarlyons.game.Tray tray;
        int i6;
        int i7;
        int i8;
        java.util.Iterator<java.lang.Integer> it;
        int i9;
        int i10;
        int i11;
        java.util.List listFjT7LSJoZG8JrehrlZO;
        java.lang.Object obj;
        int iIntValue;
        ?? arrayList;
        int i12 = i;
        int i13 = 2;
        java.lang.Integer num3 = 2;
        int i14 = 0;
        java.lang.Integer num4 = 0;
        int i15 = 3;
        kotlin.collections.EmptyList emptyList = kotlin.collections.EmptyList.GerKUYaWR62lFxYixsm;
        int i16 = 5;
        int i17 = 10;
        int i18 = 4;
        int i19 = 1;
        if (i12 == 0) {
            java.util.List<kotlin.Pair> listXhdqaKiVAaC0WPwNNnl = kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(new kotlin.Pair(num3, num4), new kotlin.Pair(num3, 1), new kotlin.Pair(num3, num3), new kotlin.Pair(3, num3), new kotlin.Pair(3, 3), new kotlin.Pair(num3, 3), new kotlin.Pair(num3, 4));
            java.util.List listHEMPdThLdw2U4SnnXcc = kotlin.collections.CollectionsKt.HEMPdThLdw2U4SnnXcc(num4);
            java.util.ArrayList arrayList2 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(listXhdqaKiVAaC0WPwNNnl, 10));
            for (kotlin.Pair pair3 : listXhdqaKiVAaC0WPwNNnl) {
                arrayList2.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(0, ((java.lang.Number) pair3.GerKUYaWR62lFxYixsm).intValue(), ((java.lang.Number) pair3.A39SiWGux5Rbalqx5tb).intValue())));
            }
            java.util.ArrayList arrayListZw4zyD7jgFPVK81d6J1 = kotlin.collections.CollectionsKt.zw4zyD7jgFPVK81d6J1(listHEMPdThLdw2U4SnnXcc, arrayList2);
            java.util.Iterator it2 = listXhdqaKiVAaC0WPwNNnl.iterator();
            if (it2.hasNext()) {
                arrayList = new java.util.ArrayList();
                java.lang.Object next = it2.next();
                while (it2.hasNext()) {
                    java.lang.Object next2 = it2.next();
                    kotlin.Pair pair4 = (kotlin.Pair) next2;
                    kotlin.Pair pair5 = (kotlin.Pair) next;
                    arrayList.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(((java.lang.Number) pair5.GerKUYaWR62lFxYixsm).intValue() + (((java.lang.Number) pair5.A39SiWGux5Rbalqx5tb).intValue() * 5), ((java.lang.Number) pair4.GerKUYaWR62lFxYixsm).intValue() + (((java.lang.Number) pair4.A39SiWGux5Rbalqx5tb).intValue() * 5))));
                    next = next2;
                }
            } else {
                arrayList = emptyList;
            }
            return new com.kolosta.rejin.tarlyons.game.Tray(0, 1, kotlin.collections.CollectionsKt.HEMPdThLdw2U4SnnXcc(kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(arrayList)), emptyList, emptyList, new int[]{0}, arrayListZw4zyD7jgFPVK81d6J1);
        }
        int i20 = (i12 * 7919) + 2058;
        int i21 = i20 >> 31;
        int i22 = ~i20;
        kotlin.random.XorWowRandom xorWowRandom2 = new kotlin.random.XorWowRandom();
        xorWowRandom2.A39SiWGux5Rbalqx5tb = i20;
        xorWowRandom2.PMZrLoc0NF3euziS99o = i21;
        xorWowRandom2.EYwcyipzkILQreEEPxc = 0;
        xorWowRandom2.j0yhOfa7n1b2lkVBAKt = 0;
        xorWowRandom2.lVvt79Js7aeYnsjUe7L = i22;
        xorWowRandom2.G069ZlNT3DZHrdUtBui = (i20 << 10) ^ (i21 >>> 4);
        if ((i20 | i21 | i22) == 0) {
            defpackage.uMOFIbPk0BxLkjW3KR7.j0yhOfa7n1b2lkVBAKt("Initial state must have at least one non-zero element.");
            return null;
        }
        for (int i23 = 0; i23 < 64; i23++) {
            xorWowRandom2.iCK2U69IDurvZVodhWo();
        }
        int i24 = 0;
        while (i24 < 400) {
            java.lang.Integer numValueOf = java.lang.Integer.valueOf(i17);
            int i25 = i12 / 10;
            int i26 = i16;
            int i27 = i25 < i13 ? i19 : i13;
            if (i25 == 0) {
                int i28 = i12 / 3;
                pair = new kotlin.Pair(java.lang.Integer.valueOf(i28 + 4), java.lang.Integer.valueOf(i28 + 5));
            } else if (i25 == i19) {
                pair = new kotlin.Pair(9, 12);
            } else if (i25 != i13) {
                if (i25 == i15) {
                    pair2 = new kotlin.Pair(8, numValueOf);
                } else if (i25 != i18) {
                    pair2 = new kotlin.Pair(numValueOf, 13);
                } else {
                    pair = new kotlin.Pair(9, 11);
                }
                int iIntValue2 = ((java.lang.Number) pair2.GerKUYaWR62lFxYixsm).intValue();
                int iIntValue3 = ((java.lang.Number) pair2.A39SiWGux5Rbalqx5tb).intValue();
                java.util.ArrayList arrayListBn6dcy3rRNTGfMyxjUW = kotlin.collections.CollectionsKt.Bn6dcy3rRNTGfMyxjUW(num4);
                int i29 = i18;
                java.util.ArrayList arrayList3 = new java.util.ArrayList(i27);
                int i30 = i19;
                for (i2 = i14; i2 < i27; i2++) {
                    arrayList3.add(new java.util.LinkedHashSet());
                }
                i3 = i14;
                while (i3 < i27) {
                    java.util.Set set = (java.util.Set) arrayList3.get(i3);
                    int iVddF2l9gapSy7l41Z9d = xorWowRandom2.VddF2l9gapSy7l41Z9d(iIntValue2, iIntValue3 + 1);
                    java.util.ArrayList arrayListBn6dcy3rRNTGfMyxjUW2 = kotlin.collections.CollectionsKt.Bn6dcy3rRNTGfMyxjUW(num3);
                    int i31 = -1;
                    int i32 = 2;
                    int i33 = -1;
                    while (true) {
                        i9 = i3;
                        if (arrayListBn6dcy3rRNTGfMyxjUW2.size() - 1 >= iVddF2l9gapSy7l41Z9d) {
                            i10 = iIntValue2;
                            i11 = iIntValue3;
                            break;
                        }
                        kotlin.collections.builders.ListBuilder listBuilderICK2U69IDurvZVodhWo = iCK2U69IDurvZVodhWo(i32);
                        java.util.ArrayList arrayList4 = new java.util.ArrayList();
                        i10 = iIntValue2;
                        java.util.ListIterator listIterator = listBuilderICK2U69IDurvZVodhWo.listIterator(0);
                        while (listIterator.hasNext()) {
                            java.lang.Object next3 = listIterator.next();
                            java.util.ListIterator listIterator2 = listIterator;
                            int i34 = iIntValue3;
                            int i35 = i32;
                            if (!set.contains(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i35, ((java.lang.Number) next3).intValue())))) {
                                arrayList4.add(next3);
                            }
                            i32 = i35;
                            iIntValue3 = i34;
                            listIterator = listIterator2;
                        }
                        i11 = iIntValue3;
                        int i36 = i32;
                        if (arrayList4.isEmpty()) {
                            break;
                        }
                        int size = arrayList4.size();
                        int i37 = 0;
                        while (true) {
                            if (i37 >= size) {
                                obj = null;
                                break;
                            }
                            obj = arrayList4.get(i37);
                            int i38 = i37 + 1;
                            int i39 = size;
                            if (((java.lang.Number) obj).intValue() - i36 != i31 && xorWowRandom2.VddF2l9gapSy7l41Z9d(0, 3) != 0) {
                                break;
                            }
                            i37 = i38;
                            size = i39;
                        }
                        java.lang.Integer num5 = (java.lang.Integer) obj;
                        if (num5 != null) {
                            iIntValue = num5.intValue();
                        } else {
                            if (arrayList4.isEmpty()) {
                                defpackage.f3.PMZrLoc0NF3euziS99o("Collection is empty.");
                                return null;
                            }
                            iIntValue = ((java.lang.Number) arrayList4.get(xorWowRandom2.VddF2l9gapSy7l41Z9d(0, arrayList4.size()))).intValue();
                        }
                        set.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i36, iIntValue)));
                        i31 = iIntValue - i36;
                        arrayListBn6dcy3rRNTGfMyxjUW2.add(java.lang.Integer.valueOf(iIntValue));
                        i32 = iIntValue;
                        iIntValue2 = i10;
                        i3 = i9;
                        iIntValue3 = i11;
                    }
                    if (arrayListBn6dcy3rRNTGfMyxjUW2.size() - 1 < (iVddF2l9gapSy7l41Z9d * 3) / 4) {
                        arrayListBn6dcy3rRNTGfMyxjUW2 = null;
                    }
                    if (arrayListBn6dcy3rRNTGfMyxjUW2 == null) {
                        i5 = i24;
                        xorWowRandom = xorWowRandom2;
                        num = num3;
                    } else {
                        if (i9 == 0 && i27 == 2) {
                            int iIntValue4 = ((java.lang.Number) kotlin.collections.CollectionsKt.ZViMB9XTL2001TkWoQp(arrayListBn6dcy3rRNTGfMyxjUW2)).intValue();
                            if (iIntValue4 != 22) {
                                int[] iArr = new int[25];
                                int i40 = 0;
                                for (int i41 = 25; i40 < i41; i41 = 25) {
                                    iArr[i40] = -1;
                                    i40++;
                                }
                                iArr[iIntValue4] = iIntValue4;
                                kotlin.collections.ArrayDeque arrayDeque = new kotlin.collections.ArrayDeque(kotlin.collections.CollectionsKt.HEMPdThLdw2U4SnnXcc(java.lang.Integer.valueOf(iIntValue4)));
                                while (true) {
                                    if (arrayDeque.isEmpty()) {
                                        num = num3;
                                        listFjT7LSJoZG8JrehrlZO = null;
                                        break;
                                    }
                                    int iIntValue5 = ((java.lang.Number) arrayDeque.removeFirst()).intValue();
                                    java.util.ListIterator listIterator3 = iCK2U69IDurvZVodhWo(iIntValue5).listIterator(0);
                                    while (listIterator3.hasNext()) {
                                        int iIntValue6 = ((java.lang.Number) listIterator3.next()).intValue();
                                        int[] iArr2 = iArr;
                                        num = num3;
                                        int i42 = i33;
                                        if (iArr2[iIntValue6] == i42 && !set.contains(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(iIntValue5, iIntValue6)))) {
                                            iArr2[iIntValue6] = iIntValue5;
                                            if (iIntValue6 == 22) {
                                                java.util.ArrayList arrayListBn6dcy3rRNTGfMyxjUW3 = kotlin.collections.CollectionsKt.Bn6dcy3rRNTGfMyxjUW(java.lang.Integer.valueOf(iIntValue6));
                                                while (iIntValue5 != iIntValue4) {
                                                    arrayListBn6dcy3rRNTGfMyxjUW3.add(java.lang.Integer.valueOf(iIntValue5));
                                                    iIntValue5 = iArr2[iIntValue5];
                                                }
                                                listFjT7LSJoZG8JrehrlZO = kotlin.collections.CollectionsKt.fjT7LSJoZG8JrehrlZO(arrayListBn6dcy3rRNTGfMyxjUW3);
                                            } else {
                                                arrayDeque.addLast(java.lang.Integer.valueOf(iIntValue6));
                                            }
                                        }
                                        i33 = i42;
                                        iArr = iArr2;
                                        num3 = num;
                                    }
                                }
                            } else {
                                num = num3;
                                listFjT7LSJoZG8JrehrlZO = emptyList;
                            }
                            if (listFjT7LSJoZG8JrehrlZO == null) {
                                i5 = i24;
                                xorWowRandom = xorWowRandom2;
                            } else {
                                java.util.Iterator it3 = listFjT7LSJoZG8JrehrlZO.iterator();
                                while (it3.hasNext()) {
                                    int iIntValue7 = ((java.lang.Number) it3.next()).intValue();
                                    set.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(((java.lang.Number) kotlin.collections.CollectionsKt.ZViMB9XTL2001TkWoQp(arrayListBn6dcy3rRNTGfMyxjUW2)).intValue(), iIntValue7)));
                                    arrayListBn6dcy3rRNTGfMyxjUW2.add(java.lang.Integer.valueOf(iIntValue7));
                                }
                            }
                        } else {
                            num = num3;
                        }
                        java.util.ArrayList arrayList5 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(arrayListBn6dcy3rRNTGfMyxjUW2, 10));
                        int size2 = arrayListBn6dcy3rRNTGfMyxjUW2.size();
                        int i43 = 0;
                        while (i43 < size2) {
                            java.lang.Object obj2 = arrayListBn6dcy3rRNTGfMyxjUW2.get(i43);
                            i43++;
                            arrayList5.add(java.lang.Integer.valueOf((i9 * 25) + 1 + ((java.lang.Number) obj2).intValue()));
                        }
                        kotlin.collections.CollectionsKt.EYwcyipzkILQreEEPxc(arrayList5, arrayListBn6dcy3rRNTGfMyxjUW);
                        i3 = i9 + 1;
                        iIntValue2 = i10;
                        iIntValue3 = i11;
                        num3 = num;
                    }
                    num2 = num4;
                    tray = null;
                    i6 = 10;
                    break;
                }
                num = num3;
                java.util.ArrayList arrayList6 = new java.util.ArrayList();
                i4 = 0;
                while (i4 < i27) {
                    kotlin.ranges.IntRange intRangeJ0yhOfa7n1b2lkVBAKt = kotlin.ranges.RangesKt.j0yhOfa7n1b2lkVBAKt(0, 16);
                    java.util.ArrayList arrayList7 = new java.util.ArrayList();
                    java.util.Iterator<java.lang.Integer> it4 = intRangeJ0yhOfa7n1b2lkVBAKt.iterator();
                    while (((kotlin.ranges.IntProgressionIterator) it4).PMZrLoc0NF3euziS99o) {
                        java.lang.Object next4 = ((kotlin.collections.IntIterator) it4).next();
                        int iIntValue8 = ((java.lang.Number) next4).intValue();
                        int i44 = ((iIntValue8 / 4) * 5) + (iIntValue8 % 4);
                        int i45 = i44 + 1;
                        int i46 = i44 + 5;
                        java.util.Iterator<java.lang.Integer> it5 = it4;
                        int i47 = i44 + 6;
                        java.lang.Integer num6 = num4;
                        java.util.List listXhdqaKiVAaC0WPwNNnl2 = kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i44, i45)), java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i46, i47)), java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i44, i46)), java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(i45, i47)));
                        if (listXhdqaKiVAaC0WPwNNnl2.isEmpty()) {
                            arrayList7.add(next4);
                        } else {
                            java.util.Iterator it6 = listXhdqaKiVAaC0WPwNNnl2.iterator();
                            while (it6.hasNext()) {
                                if (!((java.util.Set) arrayList3.get(i4)).contains(java.lang.Integer.valueOf(((java.lang.Number) it6.next()).intValue()))) {
                                    break;
                                }
                            }
                            arrayList7.add(next4);
                        }
                        it4 = it5;
                        num4 = num6;
                    }
                    java.lang.Integer num7 = num4;
                    java.util.Iterator it7 = kotlin.collections.CollectionsKt.NgCDV6MKlbRA4vspgL6(2, kotlin.collections.CollectionsKt.VI2W3ke12Vku4BIAUkB(arrayList7, xorWowRandom2)).iterator();
                    while (it7.hasNext()) {
                        arrayList6.add(new com.kolosta.rejin.tarlyons.game.Emblem(i4, ((java.lang.Number) it7.next()).intValue()));
                    }
                    i4++;
                    num4 = num7;
                }
                num2 = num4;
                if ((i25 < 3 || (i25 == i30 && i24 < 120)) && arrayList6.isEmpty()) {
                    i5 = i24;
                    xorWowRandom = xorWowRandom2;
                    tray = null;
                    i6 = 10;
                } else {
                    int i48 = i25 != i29 ? i25 != i26 ? 0 : 2 : 1;
                    java.util.ArrayList arrayList8 = new java.util.ArrayList();
                    if (i48 > 0) {
                        kotlin.ranges.IntRange intRangeJ0yhOfa7n1b2lkVBAKt2 = kotlin.ranges.RangesKt.j0yhOfa7n1b2lkVBAKt(3, arrayListBn6dcy3rRNTGfMyxjUW.size() - 1);
                        java.util.ArrayList arrayList9 = new java.util.ArrayList();
                        java.util.Iterator<java.lang.Integer> it8 = intRangeJ0yhOfa7n1b2lkVBAKt2.iterator();
                        while (((kotlin.ranges.IntProgressionIterator) it8).PMZrLoc0NF3euziS99o) {
                            java.lang.Object next5 = ((kotlin.collections.IntIterator) it8).next();
                            int iIntValue9 = ((java.lang.Number) next5).intValue();
                            int iIntValue10 = ((java.lang.Number) arrayListBn6dcy3rRNTGfMyxjUW.get(iIntValue9)).intValue();
                            int iIntValue11 = ((java.lang.Number) arrayListBn6dcy3rRNTGfMyxjUW.get(iIntValue9 + 1)).intValue();
                            if (iIntValue10 == 0 || com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(iIntValue10) != com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(iIntValue11)) {
                                i8 = i24;
                                it = it8;
                            } else if (arrayList6.isEmpty()) {
                                i8 = i24;
                                it = it8;
                                arrayList9.add(next5);
                            } else {
                                int size3 = arrayList6.size();
                                int i49 = 0;
                                while (i49 < size3) {
                                    java.lang.Object obj3 = arrayList6.get(i49);
                                    i49++;
                                    i8 = i24;
                                    com.kolosta.rejin.tarlyons.game.Emblem emblem = (com.kolosta.rejin.tarlyons.game.Emblem) obj3;
                                    it = it8;
                                    if (com.kolosta.rejin.tarlyons.game.TraysKt.iCK2U69IDurvZVodhWo(emblem.uMOFIbPk0BxLkjW3KR7, emblem.iCK2U69IDurvZVodhWo).contains(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7(iIntValue10, iIntValue11)))) {
                                        break;
                                    }
                                    it8 = it;
                                    i24 = i8;
                                }
                                i8 = i24;
                                it = it8;
                                arrayList9.add(next5);
                            }
                            it8 = it;
                            i24 = i8;
                        }
                        i5 = i24;
                        java.util.List listVI2W3ke12Vku4BIAUkB = kotlin.collections.CollectionsKt.VI2W3ke12Vku4BIAUkB(arrayList9, xorWowRandom2);
                        if (((java.util.ArrayList) listVI2W3ke12Vku4BIAUkB).size() < i48) {
                            xorWowRandom = xorWowRandom2;
                            tray = null;
                            i6 = 10;
                            i29 = 4;
                        } else {
                            java.util.Iterator it9 = kotlin.collections.CollectionsKt.NgCDV6MKlbRA4vspgL6(i48, listVI2W3ke12Vku4BIAUkB).iterator();
                            while (it9.hasNext()) {
                                int iIntValue12 = ((java.lang.Number) it9.next()).intValue();
                                arrayList8.add(new kotlin.Pair(java.lang.Integer.valueOf(iIntValue12), java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7(((java.lang.Number) arrayListBn6dcy3rRNTGfMyxjUW.get(iIntValue12)).intValue(), ((java.lang.Number) arrayListBn6dcy3rRNTGfMyxjUW.get(iIntValue12 + 1)).intValue()))));
                            }
                        }
                    } else {
                        i5 = i24;
                    }
                    int[] iArr3 = new int[i27];
                    for (int i50 = 0; i50 < i27; i50++) {
                        iArr3[i50] = i25 == 0 ? 0 : xorWowRandom2.VddF2l9gapSy7l41Z9d(0, 4);
                    }
                    if (i25 > 0) {
                        int i51 = 0;
                        while (true) {
                            if (i51 >= i27) {
                                iArr3[xorWowRandom2.VddF2l9gapSy7l41Z9d(0, i27)] = xorWowRandom2.VddF2l9gapSy7l41Z9d(0, 3) + 1;
                                break;
                            }
                            if (iArr3[i51] != 0) {
                                break;
                            }
                            i51++;
                        }
                    }
                    java.util.ArrayList arrayList10 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(arrayList8, 10));
                    int size4 = arrayList8.size();
                    int i52 = 0;
                    while (i52 < size4) {
                        java.lang.Object obj4 = arrayList8.get(i52);
                        i52++;
                        arrayList10.add(java.lang.Integer.valueOf(((java.lang.Number) ((kotlin.Pair) obj4).A39SiWGux5Rbalqx5tb).intValue()));
                    }
                    java.util.Set setJkKMrfloFo2xH4UTgso = kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(arrayList10);
                    java.util.ArrayList arrayList11 = new java.util.ArrayList(i27);
                    int i53 = 0;
                    while (i53 < i27) {
                        java.lang.Iterable iterable = (java.lang.Iterable) arrayList3.get(i53);
                        java.util.ArrayList arrayList12 = new java.util.ArrayList();
                        for (java.lang.Object obj5 : iterable) {
                            if (!setJkKMrfloFo2xH4UTgso.contains(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.A39SiWGux5Rbalqx5tb(i53, ((java.lang.Number) obj5).intValue(), 0)))) {
                                arrayList12.add(obj5);
                            }
                        }
                        java.util.ArrayList arrayList13 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(arrayList12, 10));
                        int size5 = arrayList12.size();
                        int i54 = 0;
                        while (i54 < size5) {
                            java.lang.Object obj6 = arrayList12.get(i54);
                            i54++;
                            int iIntValue13 = ((java.lang.Number) obj6).intValue();
                            int i55 = (4 - iArr3[i53]) & 3;
                            arrayList13.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(com.kolosta.rejin.tarlyons.game.TraysKt.GerKUYaWR62lFxYixsm(iIntValue13 / 100, i55), com.kolosta.rejin.tarlyons.game.TraysKt.GerKUYaWR62lFxYixsm(iIntValue13 % 100, i55))));
                            setJkKMrfloFo2xH4UTgso = setJkKMrfloFo2xH4UTgso;
                        }
                        arrayList11.add(kotlin.collections.CollectionsKt.JkKMrfloFo2xH4UTgso(arrayList13));
                        i53++;
                        setJkKMrfloFo2xH4UTgso = setJkKMrfloFo2xH4UTgso;
                    }
                    java.util.ArrayList arrayList14 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(arrayList8, 10));
                    int size6 = arrayList8.size();
                    int i56 = 0;
                    while (i56 < size6) {
                        java.lang.Object obj7 = arrayList8.get(i56);
                        i56++;
                        kotlin.Pair pair6 = (kotlin.Pair) obj7;
                        int iIntValue14 = ((java.lang.Number) pair6.GerKUYaWR62lFxYixsm).intValue();
                        int iIntValue15 = ((java.lang.Number) pair6.A39SiWGux5Rbalqx5tb).intValue();
                        int i57 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                        int i58 = iIntValue15 / 1000;
                        int iICK2U69IDurvZVodhWo = com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(i58);
                        int iVddF2l9gapSy7l41Z9d2 = com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d((i58 - 1) % 25, ((iIntValue15 % 1000) - 1) % 25);
                        int i59 = (4 - iArr3[iICK2U69IDurvZVodhWo]) & 3;
                        arrayList14.add(new com.kolosta.rejin.tarlyons.game.Spread(iICK2U69IDurvZVodhWo, com.kolosta.rejin.tarlyons.game.TraysKt.VddF2l9gapSy7l41Z9d(com.kolosta.rejin.tarlyons.game.TraysKt.GerKUYaWR62lFxYixsm(iVddF2l9gapSy7l41Z9d2 / 100, i59), com.kolosta.rejin.tarlyons.game.TraysKt.GerKUYaWR62lFxYixsm(iVddF2l9gapSy7l41Z9d2 % 100, i59)), xorWowRandom2.VddF2l9gapSy7l41Z9d(java.lang.Math.max(1, iIntValue14 - 4), iIntValue14 + 1)));
                    }
                    i6 = 10;
                    java.util.ArrayList arrayList15 = new java.util.ArrayList(kotlin.collections.CollectionsKt.Dpa63RlwGiNbcDAIHuO(arrayList6, 10));
                    int size7 = arrayList6.size();
                    int i60 = 0;
                    while (i60 < size7) {
                        java.lang.Object obj8 = arrayList6.get(i60);
                        i60++;
                        com.kolosta.rejin.tarlyons.game.Emblem emblem2 = (com.kolosta.rejin.tarlyons.game.Emblem) obj8;
                        int i61 = emblem2.uMOFIbPk0BxLkjW3KR7;
                        int i62 = emblem2.iCK2U69IDurvZVodhWo;
                        int i63 = 4 - iArr3[i61];
                        int i64 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                        int i65 = i62 % 4;
                        int i66 = i62 / 4;
                        int i67 = 0;
                        while (i67 < (i63 & 3)) {
                            i67++;
                            int i68 = i65;
                            i65 = 3 - i66;
                            i66 = i68;
                        }
                        arrayList15.add(new com.kolosta.rejin.tarlyons.game.Emblem(i61, (i66 * 4) + i65));
                    }
                    i29 = 4;
                    i7 = 3;
                    xorWowRandom = xorWowRandom2;
                    i30 = 1;
                    i12 = i;
                    tray = new com.kolosta.rejin.tarlyons.game.Tray(i12, i27, arrayList11, arrayList14, arrayList15, iArr3, arrayListBn6dcy3rRNTGfMyxjUW);
                    if (tray != null) {
                        return tray;
                    }
                    i24 = i5 + 1;
                    xorWowRandom2 = xorWowRandom;
                    i17 = i6;
                    i18 = i29;
                    i19 = i30;
                    i15 = i7;
                    num4 = num2;
                    num3 = num;
                    i13 = 2;
                    i14 = 0;
                    i16 = 5;
                }
                i30 = 1;
                i7 = 3;
                i12 = i;
                if (tray != null) {
                }
            } else {
                pair = new kotlin.Pair(6, 8);
            }
            pair2 = pair;
            int iIntValue22 = ((java.lang.Number) pair2.GerKUYaWR62lFxYixsm).intValue();
            int iIntValue32 = ((java.lang.Number) pair2.A39SiWGux5Rbalqx5tb).intValue();
            java.util.ArrayList arrayListBn6dcy3rRNTGfMyxjUW4 = kotlin.collections.CollectionsKt.Bn6dcy3rRNTGfMyxjUW(num4);
            int i292 = i18;
            java.util.ArrayList arrayList32 = new java.util.ArrayList(i27);
            int i302 = i19;
            while (i2 < i27) {
            }
            i3 = i14;
            while (i3 < i27) {
            }
            num = num3;
            java.util.ArrayList arrayList62 = new java.util.ArrayList();
            i4 = 0;
            while (i4 < i27) {
            }
            num2 = num4;
            if (i25 < 3) {
                i5 = i24;
                xorWowRandom = xorWowRandom2;
                tray = null;
                i6 = 10;
                i302 = 1;
                i7 = 3;
                i12 = i;
            } else {
                i5 = i24;
                xorWowRandom = xorWowRandom2;
                tray = null;
                i6 = 10;
                i302 = 1;
                i7 = 3;
                i12 = i;
            }
            if (tray != null) {
            }
        }
        defpackage.f3.EYwcyipzkILQreEEPxc("tray ", i12, " could not be generated");
        return null;
    }
}
