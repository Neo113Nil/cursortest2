package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\u0006\b'\u0018\u00002\u00020\u00012\u00020\u0002R\u001a\u0010\b\u001a\u00020\u00038\u0004X\u0084\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0006\u0010\u0007¨\u0006\t"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/GameLoopView;", "Landroid/view/View;", "Landroid/view/Choreographer$FrameCallback;", "", "EYwcyipzkILQreEEPxc", "F", "getDp", "()F", "dp", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public abstract class GameLoopView extends android.view.View implements android.view.Choreographer.FrameCallback {
    public boolean A39SiWGux5Rbalqx5tb;

    /* renamed from: EYwcyipzkILQreEEPxc, reason: from kotlin metadata */
    public final float dp;
    public boolean GerKUYaWR62lFxYixsm;
    public long PMZrLoc0NF3euziS99o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GameLoopView(android.content.Context context) {
        super(context);
        context.getClass();
        this.dp = getResources().getDisplayMetrics().density;
    }

    public abstract void VddF2l9gapSy7l41Z9d(float f);

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j) {
        if (this.GerKUYaWR62lFxYixsm) {
            float fICK2U69IDurvZVodhWo = this.PMZrLoc0NF3euziS99o != 0 ? kotlin.ranges.RangesKt.iCK2U69IDurvZVodhWo((j - r0) / 1.0E9f, 0.0f, 0.05f) : 0.0f;
            this.PMZrLoc0NF3euziS99o = j;
            VddF2l9gapSy7l41Z9d(fICK2U69IDurvZVodhWo);
            invalidate();
            if (this.GerKUYaWR62lFxYixsm) {
                android.view.Choreographer.getInstance().postFrameCallback(this);
            }
        }
    }

    public final float getDp() {
        return this.dp;
    }

    public abstract void iCK2U69IDurvZVodhWo();

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.GerKUYaWR62lFxYixsm || this.A39SiWGux5Rbalqx5tb) {
            return;
        }
        this.GerKUYaWR62lFxYixsm = true;
        this.PMZrLoc0NF3euziS99o = 0L;
        android.view.Choreographer.getInstance().postFrameCallback(this);
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        this.GerKUYaWR62lFxYixsm = false;
        android.view.Choreographer.getInstance().removeFrameCallback(this);
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        if (z) {
            return;
        }
        iCK2U69IDurvZVodhWo();
    }

    public final android.graphics.Bitmap uMOFIbPk0BxLkjW3KR7(int i) {
        android.content.res.Resources resources = getResources();
        android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
        options.inScaled = false;
        android.graphics.Bitmap bitmapDecodeResource = android.graphics.BitmapFactory.decodeResource(resources, i, options);
        bitmapDecodeResource.setDensity(0);
        return bitmapDecodeResource;
    }
}
