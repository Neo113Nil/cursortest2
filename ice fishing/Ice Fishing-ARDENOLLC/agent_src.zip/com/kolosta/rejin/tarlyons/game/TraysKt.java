package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0002\n\u0000¨\u0006\u0000"}, d2 = {"app"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class TraysKt {
    public static final int uMOFIbPk0BxLkjW3KR7 = uMOFIbPk0BxLkjW3KR7(0, com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(0, 2, 0));
    public static final int iCK2U69IDurvZVodhWo = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(0, 2, 4), com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(1, 2, 0));

    public static final int A39SiWGux5Rbalqx5tb(int i, int i2, int i3) {
        int i4 = (i * 25) + 1;
        return uMOFIbPk0BxLkjW3KR7(GerKUYaWR62lFxYixsm(i2 / 100, i3) + i4, GerKUYaWR62lFxYixsm(i2 % 100, i3) + i4);
    }

    public static final int GerKUYaWR62lFxYixsm(int i, int i2) {
        int i3 = i % 5;
        int i4 = i / 5;
        int i5 = 0;
        while (i5 < (i2 & 3)) {
            i5++;
            int i6 = i3;
            i3 = 4 - i4;
            i4 = i6;
        }
        return (i4 * 5) + i3;
    }

    public static final int VddF2l9gapSy7l41Z9d(int i, int i2) {
        return i < i2 ? (i * 100) + i2 : (i2 * 100) + i;
    }

    public static final java.util.List iCK2U69IDurvZVodhWo(int i, int i2) {
        int i3 = i2 % 4;
        int i4 = i2 / 4;
        int iUMOFIbPk0BxLkjW3KR7 = com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(i, i3, i4);
        int i5 = i3 + 1;
        int iUMOFIbPk0BxLkjW3KR72 = com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(i, i5, i4);
        int i6 = i4 + 1;
        int iUMOFIbPk0BxLkjW3KR73 = com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(i, i3, i6);
        int iUMOFIbPk0BxLkjW3KR74 = com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(i, i5, i6);
        return kotlin.collections.CollectionsKt.XhdqaKiVAaC0WPwNNnl(java.lang.Integer.valueOf(uMOFIbPk0BxLkjW3KR7(iUMOFIbPk0BxLkjW3KR7, iUMOFIbPk0BxLkjW3KR72)), java.lang.Integer.valueOf(uMOFIbPk0BxLkjW3KR7(iUMOFIbPk0BxLkjW3KR73, iUMOFIbPk0BxLkjW3KR74)), java.lang.Integer.valueOf(uMOFIbPk0BxLkjW3KR7(iUMOFIbPk0BxLkjW3KR7, iUMOFIbPk0BxLkjW3KR73)), java.lang.Integer.valueOf(uMOFIbPk0BxLkjW3KR7(iUMOFIbPk0BxLkjW3KR72, iUMOFIbPk0BxLkjW3KR74)));
    }

    public static final int uMOFIbPk0BxLkjW3KR7(int i, int i2) {
        return i < i2 ? (i * 1000) + i2 : (i2 * 1000) + i;
    }
}
