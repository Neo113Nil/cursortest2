package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\u000e\b\u0007\u0018\u00002\u00020\u0001:\u0001\u000fR*\u0010\n\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00028\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR*\u0010\u000e\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00028\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b\u000b\u0010\u0005\u001a\u0004\b\f\u0010\u0007\"\u0004\b\r\u0010\t¨\u0006\u0010"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/SeamView;", "Lcom/kolosta/rejin/tarlyons/game/GameLoopView;", "", "v", "JjLaFjoHTCoTSMjQa7q", "F", "getInsetTop", "()F", "setInsetTop", "(F)V", "insetTop", "gzg71nUFKNF0JyxrFIK", "getInsetBottom", "setInsetBottom", "insetBottom", "Listener", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class SeamView extends com.kolosta.rejin.tarlyons.game.GameLoopView {
    public boolean Bn6dcy3rRNTGfMyxjUW;
    public final com.kolosta.rejin.tarlyons.game.Repair Dpa63RlwGiNbcDAIHuO;
    public com.kolosta.rejin.tarlyons.ui.PlayScreenKt$PlayScreen$2$1$1$1 G069ZlNT3DZHrdUtBui;
    public final float[] GRDgDa6Vavh8ZfltzLU;
    public final android.graphics.Bitmap H0jYF7Mc76EKIPcCXvq;
    public final android.graphics.ColorMatrixColorFilter HEMPdThLdw2U4SnnXcc;

    /* renamed from: JjLaFjoHTCoTSMjQa7q, reason: from kotlin metadata */
    public float insetTop;
    public float JkKMrfloFo2xH4UTgso;
    public boolean NWbn9nx4Jy3ZCUpsHES;
    public float NgCDV6MKlbRA4vspgL6;
    public final android.graphics.Bitmap OBWx8K2uSIyiwkjsL0N;
    public final android.graphics.Bitmap Q9Nq566vXkbJ4Iw58qn;
    public float ToXgQAFEcwNMApTHMKw;
    public float VI2W3ke12Vku4BIAUkB;
    public final android.graphics.Paint X1I3PnLZJSbM9AFq8Rp;
    public float XhdqaKiVAaC0WPwNNnl;
    public final android.graphics.Path ZViMB9XTL2001TkWoQp;
    public final android.graphics.Bitmap cUEQzQeAqMKjdi9XsQN;
    public int cu4Sb8NChS0DjnyJZJl;
    public final android.graphics.Bitmap cwoLH2FPi4AIU5DJOyN;
    public final android.graphics.RectF ff2srofHOoq4tmBBMPV;
    public boolean fjT7LSJoZG8JrehrlZO;

    /* renamed from: gzg71nUFKNF0JyxrFIK, reason: from kotlin metadata */
    public float insetBottom;
    public boolean ibR49E9wGBSot7bvPza;
    public final com.kolosta.rejin.tarlyons.game.Tray j0yhOfa7n1b2lkVBAKt;
    public final boolean[] jyQgYr7taKJMPwY9vWQ;
    public final int lVvt79Js7aeYnsjUe7L;
    public final android.graphics.Bitmap mRZ5RjxkdVcb8tC2wM6;
    public float nt8i71cb0KrXpdctesw;
    public float pRCzcKHbTdhACOvA8KQ;
    public float rBFauuziN1541ugrs7h;
    public final android.graphics.Path rPUzDQKbYL6WgvU9ySs;
    public float v5wzXFgUOh8fr6SrmDF;
    public com.kolosta.rejin.tarlyons.game.PlayLayout wDaxnHzF6aHr1xEjAAF;
    public final float[] zw4zyD7jgFPVK81d6J1;

    /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bf\u0018\u00002\u00020\u0001¨\u0006\u0002À\u0006\u0003"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/SeamView$Listener;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface Listener {
    }

    /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
    @kotlin.Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        static {
            int[] iArr = new int[com.kolosta.rejin.tarlyons.game.Step.values().length];
            try {
                iArr[2] = 1;
            } catch (java.lang.NoSuchFieldError unused) {
            }
            try {
                com.kolosta.rejin.tarlyons.game.Step step = com.kolosta.rejin.tarlyons.game.Step.GerKUYaWR62lFxYixsm;
                iArr[1] = 2;
            } catch (java.lang.NoSuchFieldError unused2) {
            }
            try {
                com.kolosta.rejin.tarlyons.game.Step step2 = com.kolosta.rejin.tarlyons.game.Step.GerKUYaWR62lFxYixsm;
                iArr[0] = 3;
            } catch (java.lang.NoSuchFieldError unused3) {
            }
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SeamView(android.content.Context context, com.kolosta.rejin.tarlyons.game.Tray tray, int i, com.kolosta.rejin.tarlyons.ui.PlayScreenKt$PlayScreen$2$1$1$1 playScreenKt$PlayScreen$2$1$1$1) {
        super(context);
        context.getClass();
        this.j0yhOfa7n1b2lkVBAKt = tray;
        this.lVvt79Js7aeYnsjUe7L = i;
        this.G069ZlNT3DZHrdUtBui = playScreenKt$PlayScreen$2$1$1$1;
        this.Dpa63RlwGiNbcDAIHuO = new com.kolosta.rejin.tarlyons.game.Repair(tray);
        this.H0jYF7Mc76EKIPcCXvq = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_plate);
        this.cwoLH2FPi4AIU5DJOyN = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_emblem);
        this.OBWx8K2uSIyiwkjsL0N = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_token);
        this.mRZ5RjxkdVcb8tC2wM6 = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_hand);
        this.Q9Nq566vXkbJ4Iw58qn = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_brush);
        this.cUEQzQeAqMKjdi9XsQN = uMOFIbPk0BxLkjW3KR7(com.kolosta.rejin.tarlyons.R.drawable.art_crack);
        this.X1I3PnLZJSbM9AFq8Rp = new android.graphics.Paint();
        this.rPUzDQKbYL6WgvU9ySs = new android.graphics.Path();
        this.ZViMB9XTL2001TkWoQp = new android.graphics.Path();
        this.ff2srofHOoq4tmBBMPV = new android.graphics.RectF();
        android.graphics.ColorMatrix colorMatrix = new android.graphics.ColorMatrix();
        colorMatrix.setSaturation(0.0f);
        this.HEMPdThLdw2U4SnnXcc = new android.graphics.ColorMatrixColorFilter(colorMatrix);
        this.GRDgDa6Vavh8ZfltzLU = new float[tray.iCK2U69IDurvZVodhWo];
        java.util.List list = tray.GerKUYaWR62lFxYixsm;
        this.zw4zyD7jgFPVK81d6J1 = new float[list.size()];
        this.jyQgYr7taKJMPwY9vWQ = new boolean[list.size()];
        this.cu4Sb8NChS0DjnyJZJl = -1;
    }

    public final com.kolosta.rejin.tarlyons.game.PlayLayout A39SiWGux5Rbalqx5tb() {
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayout = this.wDaxnHzF6aHr1xEjAAF;
        if (playLayout != null) {
            return playLayout;
        }
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayout2 = new com.kolosta.rejin.tarlyons.game.PlayLayout(getWidth(), getHeight(), getDp(), this.j0yhOfa7n1b2lkVBAKt.iCK2U69IDurvZVodhWo, this.insetTop, this.insetBottom);
        this.wDaxnHzF6aHr1xEjAAF = playLayout2;
        return playLayout2;
    }

    public final void EYwcyipzkILQreEEPxc() {
        if (this.Bn6dcy3rRNTGfMyxjUW) {
            return;
        }
        com.kolosta.rejin.tarlyons.game.Repair repair = this.Dpa63RlwGiNbcDAIHuO;
        if (repair.G069ZlNT3DZHrdUtBui != com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm) {
            return;
        }
        if (this.fjT7LSJoZG8JrehrlZO) {
            repair.wDaxnHzF6aHr1xEjAAF = false;
            this.fjT7LSJoZG8JrehrlZO = false;
        }
        this.Bn6dcy3rRNTGfMyxjUW = true;
        com.kolosta.rejin.tarlyons.ui.PlayScreenKt$PlayScreen$2$1$1$1 playScreenKt$PlayScreen$2$1$1$1 = this.G069ZlNT3DZHrdUtBui;
        if (playScreenKt$PlayScreen$2$1$1$1 != null) {
            playScreenKt$PlayScreen$2$1$1$1.uMOFIbPk0BxLkjW3KR7(true);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0064  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void G069ZlNT3DZHrdUtBui(com.kolosta.rejin.tarlyons.game.PlayLayout playLayout, float f, float f2) {
        boolean z;
        com.kolosta.rejin.tarlyons.game.Step step;
        boolean z2 = true;
        int iMax = java.lang.Math.max(1, (int) (((float) java.lang.Math.hypot(f - this.VI2W3ke12Vku4BIAUkB, f2 - this.nt8i71cb0KrXpdctesw)) / (playLayout.lVvt79Js7aeYnsjUe7L * 0.12f)));
        if (1 <= iMax) {
            int i = 1;
            while (true) {
                float f3 = this.VI2W3ke12Vku4BIAUkB;
                float f4 = i;
                float f5 = iMax;
                float f6 = (((f - f3) * f4) / f5) + f3;
                float f7 = this.nt8i71cb0KrXpdctesw;
                float f8 = (((f2 - f7) * f4) / f5) + f7;
                float f9 = playLayout.Dpa63RlwGiNbcDAIHuO;
                float f10 = f9 * f9;
                int i2 = playLayout.uMOFIbPk0BxLkjW3KR7 * 25;
                int i3 = -1;
                if (i2 >= 0) {
                    int i4 = 0;
                    while (true) {
                        float fUMOFIbPk0BxLkjW3KR7 = playLayout.uMOFIbPk0BxLkjW3KR7(i4) - f6;
                        float fICK2U69IDurvZVodhWo = playLayout.iCK2U69IDurvZVodhWo(i4) - f8;
                        float f11 = (fICK2U69IDurvZVodhWo * fICK2U69IDurvZVodhWo) + (fUMOFIbPk0BxLkjW3KR7 * fUMOFIbPk0BxLkjW3KR7);
                        if (f11 <= f10) {
                            i3 = i4;
                            f10 = f11;
                        }
                        if (i4 == i2) {
                            break;
                        } else {
                            i4++;
                        }
                    }
                }
                if (i3 >= 0) {
                    com.kolosta.rejin.tarlyons.game.Repair repair = this.Dpa63RlwGiNbcDAIHuO;
                    if (i3 == repair.VddF2l9gapSy7l41Z9d()) {
                        z = z2;
                    } else {
                        com.kolosta.rejin.tarlyons.game.Tray tray = repair.uMOFIbPk0BxLkjW3KR7;
                        java.util.List list = tray.GerKUYaWR62lFxYixsm;
                        java.util.ArrayList arrayList = repair.GerKUYaWR62lFxYixsm;
                        java.util.ArrayList arrayList2 = repair.PMZrLoc0NF3euziS99o;
                        boolean[] zArr = repair.VddF2l9gapSy7l41Z9d;
                        java.util.HashSet hashSet = repair.A39SiWGux5Rbalqx5tb;
                        if (repair.wDaxnHzF6aHr1xEjAAF && repair.G069ZlNT3DZHrdUtBui == com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm && i3 != repair.VddF2l9gapSy7l41Z9d()) {
                            int iUMOFIbPk0BxLkjW3KR7 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7(repair.VddF2l9gapSy7l41Z9d(), i3);
                            if (!((kotlin.collections.builders.SetBuilder) repair.uMOFIbPk0BxLkjW3KR7()).GerKUYaWR62lFxYixsm.containsKey(java.lang.Integer.valueOf(iUMOFIbPk0BxLkjW3KR7)) || hashSet.contains(java.lang.Integer.valueOf(iUMOFIbPk0BxLkjW3KR7))) {
                                if (!repair.j0yhOfa7n1b2lkVBAKt) {
                                    repair.gzg71nUFKNF0JyxrFIK++;
                                }
                                int i5 = repair.JjLaFjoHTCoTSMjQa7q + 1;
                                repair.JjLaFjoHTCoTSMjQa7q = i5;
                                repair.wDaxnHzF6aHr1xEjAAF = false;
                                if (i5 >= 3) {
                                    repair.G069ZlNT3DZHrdUtBui = com.kolosta.rejin.tarlyons.game.Outcome.PMZrLoc0NF3euziS99o;
                                }
                                step = com.kolosta.rejin.tarlyons.game.Step.PMZrLoc0NF3euziS99o;
                            } else {
                                if (!repair.j0yhOfa7n1b2lkVBAKt) {
                                    repair.j0yhOfa7n1b2lkVBAKt = true;
                                    repair.gzg71nUFKNF0JyxrFIK++;
                                    repair.EYwcyipzkILQreEEPxc.add(java.lang.Integer.valueOf(arrayList2.size()));
                                }
                                arrayList.add(java.lang.Integer.valueOf(iUMOFIbPk0BxLkjW3KR7));
                                hashSet.add(java.lang.Integer.valueOf(iUMOFIbPk0BxLkjW3KR7));
                                arrayList2.add(java.lang.Integer.valueOf(i3));
                                java.util.Iterator it = list.iterator();
                                int i6 = 0;
                                while (it.hasNext()) {
                                    java.lang.Object next = it.next();
                                    int i7 = i6 + 1;
                                    java.util.Iterator it2 = it;
                                    if (i6 < 0) {
                                        kotlin.collections.CollectionsKt.ibR49E9wGBSot7bvPza();
                                        throw null;
                                    }
                                    com.kolosta.rejin.tarlyons.game.Spread spread = (com.kolosta.rejin.tarlyons.game.Spread) next;
                                    if (!zArr[i6] && arrayList.size() >= spread.VddF2l9gapSy7l41Z9d) {
                                        zArr[i6] = true;
                                        repair.lVvt79Js7aeYnsjUe7L = null;
                                    }
                                    i6 = i7;
                                    it = it2;
                                }
                                int size = hashSet.size();
                                int i8 = tray.iCK2U69IDurvZVodhWo;
                                java.util.Iterator it3 = tray.VddF2l9gapSy7l41Z9d.iterator();
                                int size2 = 0;
                                while (it3.hasNext()) {
                                    size2 += ((java.util.Set) it3.next()).size();
                                }
                                if (size == list.size() + i8 + size2) {
                                    for (boolean z3 : zArr) {
                                        if (!z3) {
                                            if (repair.iCK2U69IDurvZVodhWo() && !repair.A39SiWGux5Rbalqx5tb() && repair.Dpa63RlwGiNbcDAIHuO) {
                                                repair.G069ZlNT3DZHrdUtBui = com.kolosta.rejin.tarlyons.game.Outcome.EYwcyipzkILQreEEPxc;
                                                repair.wDaxnHzF6aHr1xEjAAF = false;
                                            }
                                            step = com.kolosta.rejin.tarlyons.game.Step.A39SiWGux5Rbalqx5tb;
                                        }
                                    }
                                    repair.G069ZlNT3DZHrdUtBui = com.kolosta.rejin.tarlyons.game.Outcome.A39SiWGux5Rbalqx5tb;
                                    repair.wDaxnHzF6aHr1xEjAAF = false;
                                    step = com.kolosta.rejin.tarlyons.game.Step.A39SiWGux5Rbalqx5tb;
                                } else {
                                    if (repair.iCK2U69IDurvZVodhWo()) {
                                        repair.G069ZlNT3DZHrdUtBui = com.kolosta.rejin.tarlyons.game.Outcome.EYwcyipzkILQreEEPxc;
                                        repair.wDaxnHzF6aHr1xEjAAF = false;
                                    }
                                    step = com.kolosta.rejin.tarlyons.game.Step.A39SiWGux5Rbalqx5tb;
                                }
                            }
                        } else {
                            step = com.kolosta.rejin.tarlyons.game.Step.GerKUYaWR62lFxYixsm;
                        }
                        int iOrdinal = step.ordinal();
                        if (iOrdinal != 0) {
                            z = true;
                            if (iOrdinal != 1) {
                                if (iOrdinal != 2) {
                                    defpackage.uMOFIbPk0BxLkjW3KR7.cwoLH2FPi4AIU5DJOyN();
                                    return;
                                }
                                this.fjT7LSJoZG8JrehrlZO = false;
                                this.ToXgQAFEcwNMApTHMKw = 0.9f;
                                this.rBFauuziN1541ugrs7h = playLayout.uMOFIbPk0BxLkjW3KR7(i3);
                                this.JkKMrfloFo2xH4UTgso = playLayout.iCK2U69IDurvZVodhWo(i3);
                                return;
                            }
                            if (repair.G069ZlNT3DZHrdUtBui != com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm) {
                                this.fjT7LSJoZG8JrehrlZO = false;
                                return;
                            }
                        } else {
                            z = true;
                        }
                    }
                    if (i == iMax) {
                        break;
                    }
                    i++;
                    z2 = z;
                }
            }
        }
        this.VI2W3ke12Vku4BIAUkB = f;
        this.nt8i71cb0KrXpdctesw = f2;
    }

    public final void GerKUYaWR62lFxYixsm(android.graphics.Canvas canvas, com.kolosta.rejin.tarlyons.game.PlayLayout playLayout, int i, boolean z, float f) {
        int i2 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
        int i3 = i / 1000;
        float fUMOFIbPk0BxLkjW3KR7 = playLayout.uMOFIbPk0BxLkjW3KR7(i3);
        float fICK2U69IDurvZVodhWo = playLayout.iCK2U69IDurvZVodhWo(i3);
        int i4 = i % 1000;
        float fUMOFIbPk0BxLkjW3KR72 = playLayout.uMOFIbPk0BxLkjW3KR7(i4);
        float fICK2U69IDurvZVodhWo2 = playLayout.iCK2U69IDurvZVodhWo(i4);
        float fUMOFIbPk0BxLkjW3KR73 = defpackage.cUEQzQeAqMKjdi9XsQN.uMOFIbPk0BxLkjW3KR7(fUMOFIbPk0BxLkjW3KR72, fUMOFIbPk0BxLkjW3KR7, f, fUMOFIbPk0BxLkjW3KR7);
        float fUMOFIbPk0BxLkjW3KR74 = defpackage.cUEQzQeAqMKjdi9XsQN.uMOFIbPk0BxLkjW3KR7(fICK2U69IDurvZVodhWo2, fICK2U69IDurvZVodhWo, f, fICK2U69IDurvZVodhWo);
        float f2 = ((((i * 2654435761L) >>> 16) & 255) / 255.0f) - 0.5f;
        float f3 = ((fUMOFIbPk0BxLkjW3KR74 - fICK2U69IDurvZVodhWo) * 0.09f * f2) + ((fUMOFIbPk0BxLkjW3KR7 + fUMOFIbPk0BxLkjW3KR73) / 2.0f);
        float f4 = ((fICK2U69IDurvZVodhWo + fUMOFIbPk0BxLkjW3KR74) / 2.0f) - (((fUMOFIbPk0BxLkjW3KR73 - fUMOFIbPk0BxLkjW3KR7) * 0.09f) * f2);
        android.graphics.Path path = this.rPUzDQKbYL6WgvU9ySs;
        path.reset();
        path.moveTo(fUMOFIbPk0BxLkjW3KR7, fICK2U69IDurvZVodhWo);
        path.lineTo(f3, f4);
        path.lineTo(fUMOFIbPk0BxLkjW3KR73, fUMOFIbPk0BxLkjW3KR74);
        android.graphics.Paint paint = this.X1I3PnLZJSbM9AFq8Rp;
        if (!z) {
            j0yhOfa7n1b2lkVBAKt(canvas, android.graphics.Color.rgb(58, 76, 102), 255, 3.0f);
            PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.rgb(58, 76, 102));
            canvas.drawCircle(fUMOFIbPk0BxLkjW3KR7, fICK2U69IDurvZVodhWo, getDp() * 3.0f, paint);
            canvas.drawCircle(fUMOFIbPk0BxLkjW3KR73, fUMOFIbPk0BxLkjW3KR74, getDp() * 3.0f, paint);
            return;
        }
        int i5 = this.lVvt79Js7aeYnsjUe7L;
        j0yhOfa7n1b2lkVBAKt(canvas, i5, 70, 10.0f);
        j0yhOfa7n1b2lkVBAKt(canvas, i5, 255, 5.0f);
        j0yhOfa7n1b2lkVBAKt(canvas, android.graphics.Color.rgb(255, 244, 205), 170, 1.6f);
        PMZrLoc0NF3euziS99o().setColor(i5);
        canvas.drawCircle(fUMOFIbPk0BxLkjW3KR7, fICK2U69IDurvZVodhWo, getDp() * 4.0f, paint);
        canvas.drawCircle(fUMOFIbPk0BxLkjW3KR73, fUMOFIbPk0BxLkjW3KR74, getDp() * 4.0f, paint);
    }

    public final android.graphics.Paint PMZrLoc0NF3euziS99o() {
        android.graphics.Paint paint = this.X1I3PnLZJSbM9AFq8Rp;
        paint.reset();
        paint.setAntiAlias(true);
        return paint;
    }

    @Override // com.kolosta.rejin.tarlyons.game.GameLoopView
    public final void VddF2l9gapSy7l41Z9d(float f) {
        com.kolosta.rejin.tarlyons.game.Repair repair;
        com.kolosta.rejin.tarlyons.ui.PlayScreenKt$PlayScreen$2$1$1$1 playScreenKt$PlayScreen$2$1$1$1;
        this.XhdqaKiVAaC0WPwNNnl += f;
        float[] fArr = this.GRDgDa6Vavh8ZfltzLU;
        int length = fArr.length;
        int i = 0;
        while (true) {
            float fMin = 0.0f;
            if (i >= length) {
                break;
            }
            float f2 = fArr[i];
            if (f2 < 0.0f) {
                fMin = java.lang.Math.min(0.0f, (480.0f * f) + f2);
            }
            fArr[i] = fMin;
            i++;
        }
        float[] fArr2 = this.zw4zyD7jgFPVK81d6J1;
        int length2 = fArr2.length;
        int i2 = 0;
        while (true) {
            repair = this.Dpa63RlwGiNbcDAIHuO;
            if (i2 >= length2) {
                break;
            }
            if (repair.VddF2l9gapSy7l41Z9d[i2]) {
                boolean[] zArr = this.jyQgYr7taKJMPwY9vWQ;
                if (!zArr[i2]) {
                    zArr[i2] = true;
                    fArr2[i2] = 0.001f;
                }
            }
            float f3 = fArr2[i2];
            if (1.0E-4f <= f3 && f3 <= 0.999f) {
                fArr2[i2] = java.lang.Math.min(1.0f, (2.0f * f) + f3);
            }
            i2++;
        }
        float f4 = this.ToXgQAFEcwNMApTHMKw;
        if (f4 > 0.0f) {
            this.ToXgQAFEcwNMApTHMKw = java.lang.Math.max(0.0f, f4 - f);
        }
        com.kolosta.rejin.tarlyons.game.Outcome outcome = repair.G069ZlNT3DZHrdUtBui;
        if (outcome == com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm || this.NWbn9nx4Jy3ZCUpsHES) {
            return;
        }
        float f5 = this.v5wzXFgUOh8fr6SrmDF + f;
        this.v5wzXFgUOh8fr6SrmDF = f5;
        com.kolosta.rejin.tarlyons.game.Outcome outcome2 = com.kolosta.rejin.tarlyons.game.Outcome.A39SiWGux5Rbalqx5tb;
        if (f5 >= (outcome == outcome2 ? 1.5f : 1.1f)) {
            this.NWbn9nx4Jy3ZCUpsHES = true;
            this.GerKUYaWR62lFxYixsm = false;
            android.view.Choreographer.getInstance().removeFrameCallback(this);
            if (this.A39SiWGux5Rbalqx5tb || (playScreenKt$PlayScreen$2$1$1$1 = this.G069ZlNT3DZHrdUtBui) == null) {
                return;
            }
            com.kolosta.rejin.tarlyons.game.Tray tray = repair.uMOFIbPk0BxLkjW3KR7;
            com.kolosta.rejin.tarlyons.game.Outcome outcome3 = repair.G069ZlNT3DZHrdUtBui;
            if (outcome3 == outcome2) {
                i = (repair.gzg71nUFKNF0JyxrFIK == 1 ? 1 : 0) + 1 + (!repair.Dpa63RlwGiNbcDAIHuO ? 1 : 0);
            }
            int i3 = repair.gzg71nUFKNF0JyxrFIK;
            boolean z = repair.Dpa63RlwGiNbcDAIHuO;
            int[] iArr = repair.iCK2U69IDurvZVodhWo;
            ((kotlin.jvm.functions.Function1) playScreenKt$PlayScreen$2$1$1$1.iCK2U69IDurvZVodhWo.getGerKUYaWR62lFxYixsm()).gzg71nUFKNF0JyxrFIK(new com.kolosta.rejin.tarlyons.game.RunResult(tray, outcome3, i, i3, z, java.util.Arrays.copyOf(iArr, iArr.length), kotlin.collections.CollectionsKt.rBFauuziN1541ugrs7h(repair.GerKUYaWR62lFxYixsm), repair.uMOFIbPk0BxLkjW3KR7()));
        }
    }

    public final float getInsetBottom() {
        return this.insetBottom;
    }

    public final float getInsetTop() {
        return this.insetTop;
    }

    @Override // com.kolosta.rejin.tarlyons.game.GameLoopView
    public final void iCK2U69IDurvZVodhWo() {
        EYwcyipzkILQreEEPxc();
    }

    public final void j0yhOfa7n1b2lkVBAKt(android.graphics.Canvas canvas, int i, int i2, float f) {
        PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
        android.graphics.Paint paint = this.X1I3PnLZJSbM9AFq8Rp;
        paint.setColor(i);
        paint.setAlpha(i2);
        paint.setStrokeWidth(getDp() * f);
        paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        paint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        canvas.drawPath(this.rPUzDQKbYL6WgvU9ySs, paint);
    }

    public final void lVvt79Js7aeYnsjUe7L(android.graphics.Canvas canvas, java.lang.String str, float f, float f2, float f3, int i, boolean z) {
        PMZrLoc0NF3euziS99o().setColor(i);
        float dp = getDp() * f3;
        android.graphics.Paint paint = this.X1I3PnLZJSbM9AFq8Rp;
        paint.setTextSize(dp);
        paint.setTextAlign(android.graphics.Paint.Align.CENTER);
        if (z) {
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        canvas.drawText(str, f, f2, paint);
    }

    @Override // android.view.View
    public final void onDraw(android.graphics.Canvas canvas) {
        com.kolosta.rejin.tarlyons.game.SeamView seamView;
        android.graphics.Canvas canvas2;
        int i;
        android.graphics.Paint paint;
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayout;
        float f;
        float f2;
        java.lang.String str;
        float f3;
        float f4;
        int iVddF2l9gapSy7l41Z9d;
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayout2;
        java.util.Iterator it;
        int i2;
        com.kolosta.rejin.tarlyons.game.Repair repair;
        java.lang.Object next;
        float f5;
        float f6;
        java.util.Iterator it2;
        char c;
        com.kolosta.rejin.tarlyons.game.Repair repair2;
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayout3;
        java.util.HashSet hashSet;
        boolean z;
        canvas.getClass();
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayoutA39SiWGux5Rbalqx5tb = A39SiWGux5Rbalqx5tb();
        float f7 = playLayoutA39SiWGux5Rbalqx5tb.H0jYF7Mc76EKIPcCXvq;
        float f8 = playLayoutA39SiWGux5Rbalqx5tb.lVvt79Js7aeYnsjUe7L;
        float width = getWidth();
        float height = getHeight();
        android.graphics.Paint paintPMZrLoc0NF3euziS99o = PMZrLoc0NF3euziS99o();
        int iRgb = android.graphics.Color.rgb(12, 19, 34);
        int iRgb2 = android.graphics.Color.rgb(27, 42, 64);
        android.graphics.Shader.TileMode tileMode = android.graphics.Shader.TileMode.CLAMP;
        paintPMZrLoc0NF3euziS99o.setShader(new android.graphics.LinearGradient(0.0f, 0.0f, 0.0f, height, iRgb, iRgb2, tileMode));
        android.graphics.Paint paint2 = this.X1I3PnLZJSbM9AFq8Rp;
        paint2.setAlpha(255);
        canvas.drawRect(0.0f, 0.0f, width, height, paint2);
        PMZrLoc0NF3euziS99o().setShader(new android.graphics.RadialGradient(width * 0.82f, height * 0.1f, width * 0.5f, android.graphics.Color.argb(60, 214, 228, 245), 0, tileMode));
        canvas.drawRect(0.0f, 0.0f, width, height * 0.5f, paint2);
        PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.rgb(28, 42, 66));
        float f9 = playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm;
        float f10 = playLayoutA39SiWGux5Rbalqx5tb.A39SiWGux5Rbalqx5tb;
        float f11 = playLayoutA39SiWGux5Rbalqx5tb.VddF2l9gapSy7l41Z9d;
        canvas.drawCircle(f9, f10, f11, paint2);
        PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
        paint2.setStrokeWidth(getDp() * 1.5f);
        paint2.setColor(android.graphics.Color.rgb(90, 118, 150));
        float f12 = playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm;
        canvas.drawCircle(f12, f10, f11, paint2);
        PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.rgb(242, 245, 249));
        float dp = getDp() * 4.0f;
        float f13 = dp * 1.6f;
        float dp2 = (getDp() * 14.0f) / 2.0f;
        float f14 = f10 - dp2;
        float f15 = dp * 0.6f;
        float f16 = f10 + dp2;
        canvas.drawRoundRect(f12 - f13, f14, f12 - f15, f16, getDp() * 2.0f, getDp() * 2.0f, paint2);
        canvas.drawRoundRect(f12 + f15, f14, f12 + f13, f16, getDp() * 2.0f, getDp() * 2.0f, paint2);
        float width2 = getWidth() / 2.0f;
        com.kolosta.rejin.tarlyons.game.Tray tray = this.j0yhOfa7n1b2lkVBAKt;
        int i3 = tray.uMOFIbPk0BxLkjW3KR7;
        java.util.List list = tray.GerKUYaWR62lFxYixsm;
        int i4 = tray.iCK2U69IDurvZVodhWo;
        java.lang.String strEYwcyipzkILQreEEPxc = defpackage.cUEQzQeAqMKjdi9XsQN.EYwcyipzkILQreEEPxc(i3 + 1, "Tray ");
        float f17 = playLayoutA39SiWGux5Rbalqx5tb.iCK2U69IDurvZVodhWo;
        int i5 = i4;
        lVvt79Js7aeYnsjUe7L(canvas, strEYwcyipzkILQreEEPxc, width2, (getDp() * 20.0f) + f17, 21.0f, android.graphics.Color.rgb(242, 245, 249), true);
        java.util.List list2 = com.kolosta.rejin.tarlyons.game.Trays.uMOFIbPk0BxLkjW3KR7;
        int i6 = tray.uMOFIbPk0BxLkjW3KR7;
        lVvt79Js7aeYnsjUe7L(canvas, (java.lang.String) com.kolosta.rejin.tarlyons.game.Trays.uMOFIbPk0BxLkjW3KR7.get(i6 / 10), width2, (getDp() * 40.0f) + f17, 13.0f, android.graphics.Color.rgb(226, 182, 78), false);
        com.kolosta.rejin.tarlyons.game.Repair repair3 = this.Dpa63RlwGiNbcDAIHuO;
        int i7 = repair3.gzg71nUFKNF0JyxrFIK;
        boolean[] zArr = repair3.VddF2l9gapSy7l41Z9d;
        com.kolosta.rejin.tarlyons.game.Tray tray2 = repair3.uMOFIbPk0BxLkjW3KR7;
        java.util.ArrayList arrayList = repair3.GerKUYaWR62lFxYixsm;
        java.util.HashSet hashSet2 = repair3.A39SiWGux5Rbalqx5tb;
        java.lang.String str2 = "Strokes " + i7 + "   ·   Breaks " + repair3.JjLaFjoHTCoTSMjQa7q + "/3";
        float dp3 = (getDp() * 64.0f) + f17;
        int iRgb3 = repair3.JjLaFjoHTCoTSMjQa7q > 0 ? android.graphics.Color.rgb(255, 170, 160) : android.graphics.Color.rgb(186, 199, 216);
        com.kolosta.rejin.tarlyons.game.Repair repair4 = repair3;
        java.util.HashSet hashSet3 = hashSet2;
        com.kolosta.rejin.tarlyons.game.Tray tray3 = tray2;
        android.graphics.Canvas canvas3 = canvas;
        int i8 = iRgb3;
        com.kolosta.rejin.tarlyons.game.SeamView seamView2 = this;
        seamView2.lVvt79Js7aeYnsjUe7L(canvas3, str2, width2, dp3, 14.0f, i8, false);
        java.util.Set setUMOFIbPk0BxLkjW3KR7 = repair4.uMOFIbPk0BxLkjW3KR7();
        int i9 = 0;
        while (true) {
            android.graphics.ColorMatrixColorFilter colorMatrixColorFilter = seamView2.HEMPdThLdw2U4SnnXcc;
            int i10 = seamView2.lVvt79Js7aeYnsjUe7L;
            android.graphics.RectF rectF = seamView2.ff2srofHOoq4tmBBMPV;
            if (i9 >= i5) {
                com.kolosta.rejin.tarlyons.game.PlayLayout playLayout4 = playLayoutA39SiWGux5Rbalqx5tb;
                float f18 = f7;
                java.util.HashSet hashSet4 = hashSet3;
                int i11 = i5;
                com.kolosta.rejin.tarlyons.game.Repair repair5 = repair4;
                int i12 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                GerKUYaWR62lFxYixsm(canvas, playLayout4, i12, hashSet4.contains(java.lang.Integer.valueOf(i12)), 1.0f);
                if (i11 == 2) {
                    int i13 = com.kolosta.rejin.tarlyons.game.TraysKt.iCK2U69IDurvZVodhWo;
                    canvas2 = canvas;
                    i = i11;
                    GerKUYaWR62lFxYixsm(canvas2, playLayout4, i13, hashSet4.contains(java.lang.Integer.valueOf(i13)), 1.0f);
                    seamView = this;
                } else {
                    seamView = this;
                    canvas2 = canvas;
                    i = i11;
                }
                float f19 = 0.26f * f8;
                android.graphics.Paint paintPMZrLoc0NF3euziS99o2 = seamView.PMZrLoc0NF3euziS99o();
                float f20 = playLayout4.wDaxnHzF6aHr1xEjAAF;
                float f21 = 0.3f * f19;
                int iRgb4 = android.graphics.Color.rgb(255, 226, 140);
                int iRgb5 = android.graphics.Color.rgb(170, 120, 32);
                android.graphics.Shader.TileMode tileMode2 = android.graphics.Shader.TileMode.CLAMP;
                paintPMZrLoc0NF3euziS99o2.setShader(new android.graphics.RadialGradient(f20 - f21, f18 - f21, f19 * 1.4f, iRgb4, iRgb5, tileMode2));
                paint2.setAlpha(255);
                canvas2.drawCircle(f20, f18, f19, paint2);
                seamView.PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.rgb(40, 30, 14));
                canvas2.drawCircle(f20, f18, f19 * 0.45f, paint2);
                if (seamView.fjT7LSJoZG8JrehrlZO) {
                    seamView.PMZrLoc0NF3euziS99o().setColor(i10);
                    paint2.setAlpha(130);
                    paint2.setStrokeWidth(seamView.getDp() * 4.0f);
                    paint2.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                    paint2.setStyle(android.graphics.Paint.Style.STROKE);
                    paint = paint2;
                    playLayout = playLayout4;
                    canvas.drawLine(playLayout4.uMOFIbPk0BxLkjW3KR7(repair5.VddF2l9gapSy7l41Z9d()), playLayout4.iCK2U69IDurvZVodhWo(repair5.VddF2l9gapSy7l41Z9d()), seamView.VI2W3ke12Vku4BIAUkB, seamView.nt8i71cb0KrXpdctesw, paint);
                    canvas2 = canvas;
                } else {
                    paint = paint2;
                    playLayout = playLayout4;
                }
                if (seamView.ToXgQAFEcwNMApTHMKw > 0.0f) {
                    seamView.PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
                    paint.setStrokeWidth(seamView.getDp() * 4.0f);
                    paint.setColor(android.graphics.Color.rgb(255, 120, 120));
                    paint.setAlpha((int) ((seamView.ToXgQAFEcwNMApTHMKw * 255.0f) / 0.9f));
                    canvas2.drawCircle(seamView.rBFauuziN1541ugrs7h, seamView.JkKMrfloFo2xH4UTgso, playLayout.Dpa63RlwGiNbcDAIHuO * (1.6f - (seamView.ToXgQAFEcwNMApTHMKw * 0.6f)), paint);
                }
                com.kolosta.rejin.tarlyons.game.Outcome outcome = repair5.G069ZlNT3DZHrdUtBui;
                com.kolosta.rejin.tarlyons.game.Outcome outcome2 = com.kolosta.rejin.tarlyons.game.Outcome.A39SiWGux5Rbalqx5tb;
                if (outcome == outcome2) {
                    float fICK2U69IDurvZVodhWo = kotlin.ranges.RangesKt.iCK2U69IDurvZVodhWo(seamView.v5wzXFgUOh8fr6SrmDF / 1.3f, 0.0f, 1.0f);
                    float fGerKUYaWR62lFxYixsm = playLayout.GerKUYaWR62lFxYixsm(0);
                    float fGerKUYaWR62lFxYixsm2 = playLayout.GerKUYaWR62lFxYixsm(i - 1);
                    float f22 = playLayout.G069ZlNT3DZHrdUtBui;
                    float f23 = 0.35f * f22;
                    float f24 = (((f23 * 2.0f) + f22) * fICK2U69IDurvZVodhWo) + (playLayout.JjLaFjoHTCoTSMjQa7q - f23);
                    float f25 = f24 - f23;
                    float f26 = f24 + f23;
                    f = 255.0f;
                    seamView.PMZrLoc0NF3euziS99o().setShader(new android.graphics.LinearGradient(f25, 0.0f, f26, 0.0f, new int[]{0, android.graphics.Color.argb(150, 255, 250, 230), 0}, (float[]) null, tileMode2));
                    paint.setAlpha(255);
                    float f27 = playLayout.JjLaFjoHTCoTSMjQa7q;
                    canvas.drawRect(f27, fGerKUYaWR62lFxYixsm, f22 + f27, fGerKUYaWR62lFxYixsm2 + f22, paint);
                    canvas2 = canvas;
                } else {
                    f = 255.0f;
                }
                android.graphics.Paint paint3 = paint;
                float fUMOFIbPk0BxLkjW3KR7 = seamView.fjT7LSJoZG8JrehrlZO ? seamView.VI2W3ke12Vku4BIAUkB : playLayout.uMOFIbPk0BxLkjW3KR7(repair5.VddF2l9gapSy7l41Z9d());
                float fICK2U69IDurvZVodhWo2 = seamView.fjT7LSJoZG8JrehrlZO ? seamView.nt8i71cb0KrXpdctesw : playLayout.iCK2U69IDurvZVodhWo(repair5.VddF2l9gapSy7l41Z9d());
                if (!seamView.fjT7LSJoZG8JrehrlZO && repair5.G069ZlNT3DZHrdUtBui == com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm) {
                    float fSin = (((float) java.lang.Math.sin(seamView.XhdqaKiVAaC0WPwNNnl * 4.0f)) + 1.0f) / 2.0f;
                    seamView.PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
                    paint3.setStrokeWidth(seamView.getDp() * 2.5f);
                    paint3.setColor(i10);
                    paint3.setAlpha((int) ((120.0f * fSin) + 90.0f));
                    canvas2.drawCircle(fUMOFIbPk0BxLkjW3KR7, fICK2U69IDurvZVodhWo2, ((fSin * 0.25f) + 0.85f) * playLayout.Dpa63RlwGiNbcDAIHuO, paint3);
                }
                float f28 = f8 * 1.5f;
                android.graphics.Bitmap bitmap = seamView.Q9Nq566vXkbJ4Iw58qn;
                float width3 = (bitmap.getWidth() * f28) / bitmap.getHeight();
                canvas2.save();
                canvas2.translate(fUMOFIbPk0BxLkjW3KR7, fICK2U69IDurvZVodhWo2);
                canvas2.rotate(210.0f);
                rectF.set((-width3) / 2.0f, 0.0f, width3 / 2.0f, f28);
                seamView.PMZrLoc0NF3euziS99o().setAlpha(255);
                canvas2.drawBitmap(bitmap, (android.graphics.Rect) null, rectF, paint3);
                canvas2.restore();
                if (i6 == 0 && arrayList.size() == 0 && !seamView.fjT7LSJoZG8JrehrlZO && repair5.G069ZlNT3DZHrdUtBui == com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm) {
                    float f29 = (seamView.XhdqaKiVAaC0WPwNNnl % 2.4f) / 1.8f;
                    float fICK2U69IDurvZVodhWo3 = kotlin.ranges.RangesKt.iCK2U69IDurvZVodhWo(f29, 0.0f, 1.0f);
                    float f30 = playLayout.wDaxnHzF6aHr1xEjAAF;
                    float fICK2U69IDurvZVodhWo4 = ((playLayout.iCK2U69IDurvZVodhWo(com.kolosta.rejin.tarlyons.game.Nodes.uMOFIbPk0BxLkjW3KR7(0, 2, 2)) - f18) * fICK2U69IDurvZVodhWo3) + f18;
                    float f31 = f8 * 1.3f;
                    android.graphics.Bitmap bitmap2 = seamView.mRZ5RjxkdVcb8tC2wM6;
                    float height2 = (bitmap2.getHeight() * f31) / bitmap2.getWidth();
                    android.graphics.Paint paintPMZrLoc0NF3euziS99o3 = seamView.PMZrLoc0NF3euziS99o();
                    if (f29 > 1.0f) {
                        int i14 = (int) ((1.0f - ((f29 - 1.0f) * 3.0f)) * f);
                        f3 = f30;
                        f4 = fICK2U69IDurvZVodhWo4;
                        iVddF2l9gapSy7l41Z9d = kotlin.ranges.RangesKt.VddF2l9gapSy7l41Z9d(i14, 0, 255);
                    } else {
                        f3 = f30;
                        f4 = fICK2U69IDurvZVodhWo4;
                        iVddF2l9gapSy7l41Z9d = 230;
                    }
                    paintPMZrLoc0NF3euziS99o3.setAlpha(iVddF2l9gapSy7l41Z9d);
                    rectF.set(f3 - (0.05f * f31), f4 - (0.9f * height2), (f31 * 0.95f) + f3, (height2 * 0.1f) + f4);
                    canvas2.drawBitmap(bitmap2, (android.graphics.Rect) null, rectF, paint3);
                }
                float f32 = playLayout.PMZrLoc0NF3euziS99o;
                float f33 = playLayout.EYwcyipzkILQreEEPxc;
                float f34 = playLayout.j0yhOfa7n1b2lkVBAKt;
                float f35 = f33 + f32;
                rectF.set(f33 - f32, f34 - f32, f35, f34 + f32);
                if (repair5.GerKUYaWR62lFxYixsm() && repair5.iCK2U69IDurvZVodhWo() && !repair5.A39SiWGux5Rbalqx5tb()) {
                    f2 = f35;
                    float fSin2 = (((float) java.lang.Math.sin(seamView.XhdqaKiVAaC0WPwNNnl * 5.0f)) + 1.0f) / 2.0f;
                    seamView.PMZrLoc0NF3euziS99o().setColor(i10);
                    paint3.setAlpha((int) ((90.0f * fSin2) + 60.0f));
                    canvas2.drawCircle(f33, f34, f32 * 1.25f, paint3);
                } else {
                    f2 = f35;
                }
                seamView.PMZrLoc0NF3euziS99o();
                if (repair5.Dpa63RlwGiNbcDAIHuO) {
                    paint3.setColorFilter(colorMatrixColorFilter);
                    paint3.setAlpha(90);
                } else if (!repair5.GerKUYaWR62lFxYixsm()) {
                    paint3.setAlpha(170);
                }
                canvas2.drawBitmap(seamView.OBWx8K2uSIyiwkjsL0N, (android.graphics.Rect) null, rectF, paint3);
                com.kolosta.rejin.tarlyons.game.SeamView seamView3 = seamView;
                seamView3.lVvt79Js7aeYnsjUe7L(canvas2, repair5.Dpa63RlwGiNbcDAIHuO ? "Token spent" : "Undo token", (seamView.getDp() * 50.0f) + f2, f34 + (seamView.getDp() * 5.0f), 14.0f, repair5.Dpa63RlwGiNbcDAIHuO ? android.graphics.Color.rgb(135, 150, 171) : android.graphics.Color.rgb(242, 245, 249), false);
                com.kolosta.rejin.tarlyons.game.Outcome outcome3 = repair5.G069ZlNT3DZHrdUtBui;
                if (outcome3 == outcome2) {
                    str = "Seam frozen — emblem restored";
                } else if (outcome3 == com.kolosta.rejin.tarlyons.game.Outcome.PMZrLoc0NF3euziS99o) {
                    str = "Three broken strokes";
                } else if (outcome3 == com.kolosta.rejin.tarlyons.game.Outcome.EYwcyipzkILQreEEPxc) {
                    str = "No crack leads onward";
                } else if (seamView3.ToXgQAFEcwNMApTHMKw > 0.0f) {
                    str = "Seam broke — drag again from the brush";
                } else if (repair5.iCK2U69IDurvZVodhWo() && !repair5.A39SiWGux5Rbalqx5tb()) {
                    str = "Dead end — tap the token to undo";
                } else if (repair5.iCK2U69IDurvZVodhWo()) {
                    str = "Tap the plate until a crack meets the brush";
                } else if (arrayList.size() == 0 && i6 / 10 > 0) {
                    str = "Tap a plate to turn it, then drag from the inlet";
                } else if (arrayList.size() == 0) {
                    str = "Drag the brush from the gold inlet along the cracks";
                } else {
                    java.lang.Iterable iterableMRZ5RjxkdVcb8tC2wM6 = kotlin.collections.CollectionsKt.mRZ5RjxkdVcb8tC2wM6(list);
                    if ((iterableMRZ5RjxkdVcb8tC2wM6 instanceof java.util.Collection) && ((java.util.Collection) iterableMRZ5RjxkdVcb8tC2wM6).isEmpty()) {
                        str = "Cover every crack without lifting";
                    } else {
                        java.util.Iterator<java.lang.Integer> it3 = iterableMRZ5RjxkdVcb8tC2wM6.iterator();
                        while (((kotlin.ranges.IntProgressionIterator) it3).PMZrLoc0NF3euziS99o) {
                            if (!zArr[((kotlin.collections.IntIterator) it3).nextInt()]) {
                                str = "A crack will spread — plan your stroke";
                                break;
                            }
                        }
                        str = "Cover every crack without lifting";
                    }
                }
                float dp4 = (playLayout.j0yhOfa7n1b2lkVBAKt - playLayout.PMZrLoc0NF3euziS99o) - (seamView3.getDp() * 26.0f);
                seamView3.PMZrLoc0NF3euziS99o().setTextSize(seamView3.getDp() * 14.0f);
                float fMeasureText = paint3.measureText(str) / 2.0f;
                rectF.set(((seamView3.getWidth() / 2.0f) - fMeasureText) - (seamView3.getDp() * 14.0f), dp4 - (seamView3.getDp() * 20.0f), (seamView3.getDp() * 14.0f) + (seamView3.getWidth() / 2.0f) + fMeasureText, (seamView3.getDp() * 10.0f) + dp4);
                seamView3.PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.argb(215, 12, 19, 34));
                canvas2.drawRoundRect(rectF, seamView3.getDp() * 15.0f, seamView3.getDp() * 15.0f, paint3);
                seamView3.lVvt79Js7aeYnsjUe7L(canvas2, str, seamView3.getWidth() / 2.0f, dp4, 14.0f, android.graphics.Color.rgb(242, 245, 249), false);
                return;
            }
            float f36 = 1.0f;
            float fGerKUYaWR62lFxYixsm3 = playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm(i9);
            float f37 = playLayoutA39SiWGux5Rbalqx5tb.JjLaFjoHTCoTSMjQa7q;
            float f38 = playLayoutA39SiWGux5Rbalqx5tb.G069ZlNT3DZHrdUtBui;
            float f39 = f38 / 2.0f;
            float fGerKUYaWR62lFxYixsm4 = playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm(i9) + f39;
            float f40 = f7;
            float f41 = f8 * 0.35f;
            canvas3.save();
            int i15 = i5;
            canvas3.rotate(seamView2.GRDgDa6Vavh8ZfltzLU[i9], f39 + f37, fGerKUYaWR62lFxYixsm4);
            float f42 = f37 + f38;
            java.util.HashSet hashSet5 = hashSet3;
            com.kolosta.rejin.tarlyons.game.Tray tray4 = tray3;
            float f43 = fGerKUYaWR62lFxYixsm3 + f38;
            int i16 = i9;
            rectF.set((seamView2.getDp() * 3.0f) + f37, (seamView2.getDp() * 6.0f) + fGerKUYaWR62lFxYixsm3, (seamView2.getDp() * 3.0f) + f42, (seamView2.getDp() * 6.0f) + f43);
            char c2 = 'n';
            seamView2.PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.argb(110, 0, 0, 0));
            canvas3.drawRoundRect(rectF, f41, f41, paint2);
            rectF.set(f37, fGerKUYaWR62lFxYixsm3, f42, f43);
            seamView2.PMZrLoc0NF3euziS99o().setShader(new android.graphics.LinearGradient(0.0f, fGerKUYaWR62lFxYixsm3, 0.0f, f43, android.graphics.Color.rgb(236, 242, 248), android.graphics.Color.rgb(196, 216, 233), android.graphics.Shader.TileMode.CLAMP));
            paint2.setAlpha(255);
            canvas3.drawRoundRect(rectF, f41, f41, paint2);
            canvas3.save();
            android.graphics.Path path = seamView2.ZViMB9XTL2001TkWoQp;
            path.reset();
            path.addRoundRect(rectF, f41, f41, android.graphics.Path.Direction.CW);
            canvas3.clipPath(path);
            seamView2.PMZrLoc0NF3euziS99o().setColorFilter(colorMatrixColorFilter);
            paint2.setAlpha(60);
            canvas3.drawBitmap(seamView2.H0jYF7Mc76EKIPcCXvq, (android.graphics.Rect) null, rectF, paint2);
            canvas3.restore();
            seamView2.PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
            paint2.setStrokeWidth(seamView2.getDp() * 2.0f);
            paint2.setColor(android.graphics.Color.rgb(140, 166, 192));
            canvas3.drawRoundRect(rectF, f41, f41, paint2);
            seamView2.PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.argb(70, 40, 60, 90));
            for (int i17 = 0; i17 < 25; i17++) {
                int i18 = (i16 * 25) + 1 + i17;
                canvas3.drawCircle(playLayoutA39SiWGux5Rbalqx5tb.uMOFIbPk0BxLkjW3KR7(i18), playLayoutA39SiWGux5Rbalqx5tb.iCK2U69IDurvZVodhWo(i18), seamView2.getDp() * 2.0f, paint2);
            }
            java.util.Iterator it4 = tray.A39SiWGux5Rbalqx5tb.iterator();
            int i19 = 0;
            while (it4.hasNext()) {
                java.lang.Object next2 = it4.next();
                int i20 = i19 + 1;
                if (i19 < 0) {
                    kotlin.collections.CollectionsKt.ibR49E9wGBSot7bvPza();
                    throw null;
                }
                int i21 = i16;
                if (((com.kolosta.rejin.tarlyons.game.Emblem) next2).uMOFIbPk0BxLkjW3KR7 == i21) {
                    com.kolosta.rejin.tarlyons.game.Tray tray5 = tray4;
                    com.kolosta.rejin.tarlyons.game.Emblem emblem = (com.kolosta.rejin.tarlyons.game.Emblem) tray5.A39SiWGux5Rbalqx5tb.get(i19);
                    int i22 = emblem.iCK2U69IDurvZVodhWo;
                    repair2 = repair4;
                    it2 = it4;
                    int i23 = repair2.iCK2U69IDurvZVodhWo[emblem.uMOFIbPk0BxLkjW3KR7];
                    int i24 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                    int i25 = i22 % 4;
                    int i26 = i22 / 4;
                    int i27 = 0;
                    while (i27 < (i23 & 3)) {
                        int i28 = 3 - i26;
                        i27++;
                        i26 = i25;
                        i25 = i28;
                    }
                    int i29 = (i26 * 4) + i25;
                    float f44 = (((i29 % 4) + 1.0f) * f8) + f37;
                    float fGerKUYaWR62lFxYixsm5 = (((i29 / 4) + 1.0f) * f8) + playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm(i21);
                    float f45 = 0.4f * f8;
                    int i30 = ((com.kolosta.rejin.tarlyons.game.Emblem) tray5.A39SiWGux5Rbalqx5tb.get(i19)).uMOFIbPk0BxLkjW3KR7;
                    com.kolosta.rejin.tarlyons.game.Emblem emblem2 = (com.kolosta.rejin.tarlyons.game.Emblem) tray5.A39SiWGux5Rbalqx5tb.get(i19);
                    int i31 = emblem2.iCK2U69IDurvZVodhWo;
                    int i32 = repair2.iCK2U69IDurvZVodhWo[emblem2.uMOFIbPk0BxLkjW3KR7];
                    int i33 = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                    int i34 = i31 % 4;
                    int i35 = i31 / 4;
                    int i36 = i34;
                    int i37 = 0;
                    while (i37 < (i32 & 3)) {
                        i37++;
                        int i38 = i36;
                        i36 = 3 - i35;
                        i35 = i38;
                    }
                    java.util.List listICK2U69IDurvZVodhWo = com.kolosta.rejin.tarlyons.game.TraysKt.iCK2U69IDurvZVodhWo(i30, (i35 * 4) + i36);
                    if (!listICK2U69IDurvZVodhWo.isEmpty()) {
                        java.util.Iterator it5 = listICK2U69IDurvZVodhWo.iterator();
                        while (true) {
                            if (!it5.hasNext()) {
                                hashSet = hashSet5;
                                z = true;
                                break;
                            } else {
                                hashSet = hashSet5;
                                if (!hashSet.contains(java.lang.Integer.valueOf(((java.lang.Number) it5.next()).intValue()))) {
                                    z = false;
                                    break;
                                }
                                hashSet5 = hashSet;
                            }
                        }
                    } else {
                        z = true;
                        hashSet = hashSet5;
                    }
                    boolean z2 = z;
                    tray4 = tray5;
                    rectF.set(f44 - f45, fGerKUYaWR62lFxYixsm5 - f45, f44 + f45, fGerKUYaWR62lFxYixsm5 + f45);
                    if (z2) {
                        float f46 = f45 * 1.3f;
                        playLayout3 = playLayoutA39SiWGux5Rbalqx5tb;
                        seamView2.PMZrLoc0NF3euziS99o().setShader(new android.graphics.RadialGradient(f44, fGerKUYaWR62lFxYixsm5, f46, android.graphics.Color.argb(170, android.graphics.Color.red(i10), android.graphics.Color.green(i10), android.graphics.Color.blue(i10)), 0, android.graphics.Shader.TileMode.CLAMP));
                        paint2.setAlpha(255);
                        canvas3.drawCircle(f44, fGerKUYaWR62lFxYixsm5, f46, paint2);
                        seamView2.PMZrLoc0NF3euziS99o();
                        c = 'n';
                    } else {
                        playLayout3 = playLayoutA39SiWGux5Rbalqx5tb;
                        seamView2.PMZrLoc0NF3euziS99o().setColorFilter(colorMatrixColorFilter);
                        c = 'n';
                        paint2.setAlpha(110);
                    }
                    canvas3.drawBitmap(seamView2.cwoLH2FPi4AIU5DJOyN, (android.graphics.Rect) null, rectF, paint2);
                } else {
                    com.kolosta.rejin.tarlyons.game.Repair repair6 = repair4;
                    it2 = it4;
                    c = c2;
                    repair2 = repair6;
                    playLayout3 = playLayoutA39SiWGux5Rbalqx5tb;
                    hashSet = hashSet5;
                }
                com.kolosta.rejin.tarlyons.game.Repair repair7 = repair2;
                c2 = c;
                it4 = it2;
                repair4 = repair7;
                i19 = i20;
                i16 = i21;
                hashSet5 = hashSet;
                playLayoutA39SiWGux5Rbalqx5tb = playLayout3;
            }
            com.kolosta.rejin.tarlyons.game.PlayLayout playLayout5 = playLayoutA39SiWGux5Rbalqx5tb;
            com.kolosta.rejin.tarlyons.game.Repair repair8 = repair4;
            java.util.HashSet hashSet6 = hashSet5;
            int i39 = i16;
            java.util.Iterator it6 = ((kotlin.collections.builders.SetBuilder) setUMOFIbPk0BxLkjW3KR7).iterator();
            while (it6.hasNext()) {
                int iIntValue = ((java.lang.Number) it6.next()).intValue();
                if (iIntValue == com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7 || iIntValue == com.kolosta.rejin.tarlyons.game.TraysKt.iCK2U69IDurvZVodhWo) {
                    canvas3 = canvas;
                } else if (com.kolosta.rejin.tarlyons.game.Nodes.iCK2U69IDurvZVodhWo(iIntValue / 1000) == i39) {
                    java.util.Iterator<java.lang.Integer> it7 = kotlin.collections.CollectionsKt.mRZ5RjxkdVcb8tC2wM6(list).iterator();
                    while (true) {
                        if (!((kotlin.ranges.IntProgressionIterator) it7).PMZrLoc0NF3euziS99o) {
                            next = null;
                            break;
                        }
                        next = ((kotlin.collections.IntIterator) it7).next();
                        int iIntValue2 = ((java.lang.Number) next).intValue();
                        if (zArr[iIntValue2] && repair8.PMZrLoc0NF3euziS99o(iIntValue2) == iIntValue) {
                            break;
                        }
                    }
                    java.lang.Integer num = (java.lang.Integer) next;
                    boolean zContains = hashSet6.contains(java.lang.Integer.valueOf(iIntValue));
                    if (num != null) {
                        f5 = seamView2.zw4zyD7jgFPVK81d6J1[num.intValue()];
                        f6 = f36;
                    } else {
                        f5 = f36;
                        f6 = f5;
                    }
                    android.graphics.RectF rectF2 = rectF;
                    com.kolosta.rejin.tarlyons.game.PlayLayout playLayout6 = playLayout5;
                    seamView2.GerKUYaWR62lFxYixsm(canvas3, playLayout6, iIntValue, zContains, f5);
                    canvas3 = canvas;
                    playLayout5 = playLayout6;
                    rectF = rectF2;
                    f36 = f6;
                }
            }
            com.kolosta.rejin.tarlyons.game.SeamView seamView4 = seamView2;
            android.graphics.RectF rectF3 = rectF;
            com.kolosta.rejin.tarlyons.game.PlayLayout playLayout7 = playLayout5;
            java.util.Iterator it8 = list.iterator();
            int i40 = 0;
            while (it8.hasNext()) {
                java.lang.Object next3 = it8.next();
                int i41 = i40 + 1;
                if (i40 < 0) {
                    kotlin.collections.CollectionsKt.ibR49E9wGBSot7bvPza();
                    throw null;
                }
                com.kolosta.rejin.tarlyons.game.Spread spread = (com.kolosta.rejin.tarlyons.game.Spread) next3;
                if (spread.uMOFIbPk0BxLkjW3KR7 != i39 || zArr[i40]) {
                    playLayout2 = playLayout7;
                    it = it8;
                    i2 = i39;
                    repair = repair8;
                } else {
                    int iPMZrLoc0NF3euziS99o = repair8.PMZrLoc0NF3euziS99o(i40);
                    int i42 = iPMZrLoc0NF3euziS99o / 1000;
                    float fUMOFIbPk0BxLkjW3KR72 = playLayout7.uMOFIbPk0BxLkjW3KR7(i42);
                    float fICK2U69IDurvZVodhWo5 = playLayout7.iCK2U69IDurvZVodhWo(i42);
                    int i43 = iPMZrLoc0NF3euziS99o % 1000;
                    float fUMOFIbPk0BxLkjW3KR73 = playLayout7.uMOFIbPk0BxLkjW3KR7(i43);
                    float fICK2U69IDurvZVodhWo6 = playLayout7.iCK2U69IDurvZVodhWo(i43);
                    seamView4.PMZrLoc0NF3euziS99o().setStyle(android.graphics.Paint.Style.STROKE);
                    paint2.setStrokeWidth(seamView4.getDp() * 2.0f);
                    playLayout2 = playLayout7;
                    paint2.setColor(android.graphics.Color.rgb(70, 92, 120));
                    paint2.setAlpha(150);
                    paint2.setPathEffect(new android.graphics.DashPathEffect(new float[]{seamView4.getDp() * 5.0f, seamView4.getDp() * 5.0f}, 0.0f));
                    canvas.drawLine(fUMOFIbPk0BxLkjW3KR72, fICK2U69IDurvZVodhWo5, fUMOFIbPk0BxLkjW3KR73, fICK2U69IDurvZVodhWo6, paint2);
                    float f47 = (fUMOFIbPk0BxLkjW3KR73 + fUMOFIbPk0BxLkjW3KR72) / 2.0f;
                    float f48 = (fICK2U69IDurvZVodhWo5 + fICK2U69IDurvZVodhWo6) / 2.0f;
                    float f49 = 0.24f * f8;
                    float f50 = f47 - f49;
                    float f51 = f48 - f49;
                    float f52 = f47 + f49;
                    rectF3.set(f50, f51, f52, f48 + f49);
                    seamView4.PMZrLoc0NF3euziS99o().setAlpha(235);
                    canvas.drawBitmap(seamView4.cUEQzQeAqMKjdi9XsQN, (android.graphics.Rect) null, rectF3, paint2);
                    int iMax = java.lang.Math.max(0, spread.VddF2l9gapSy7l41Z9d - arrayList.size());
                    it = it8;
                    seamView4.PMZrLoc0NF3euziS99o().setColor(android.graphics.Color.rgb(28, 42, 66));
                    canvas.drawCircle(f52, f51, seamView4.getDp() * 9.0f, paint2);
                    i2 = i39;
                    repair = repair8;
                    seamView4.lVvt79Js7aeYnsjUe7L(canvas, java.lang.String.valueOf(iMax), f52, (seamView4.getDp() * 4.5f) + f51, 12.0f, android.graphics.Color.rgb(242, 245, 249), true);
                }
                seamView4 = this;
                repair8 = repair;
                it8 = it;
                i40 = i41;
                playLayout7 = playLayout2;
                i39 = i2;
            }
            com.kolosta.rejin.tarlyons.game.PlayLayout playLayout8 = playLayout7;
            canvas.restore();
            i9 = i39 + 1;
            seamView2 = this;
            canvas3 = canvas;
            repair4 = repair8;
            hashSet3 = hashSet6;
            playLayoutA39SiWGux5Rbalqx5tb = playLayout8;
            f7 = f40;
            i5 = i15;
            tray3 = tray4;
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.wDaxnHzF6aHr1xEjAAF = null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0034, code lost:
    
        if (r10 != 3) goto L81;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        motionEvent.getClass();
        com.kolosta.rejin.tarlyons.game.PlayLayout playLayoutA39SiWGux5Rbalqx5tb = A39SiWGux5Rbalqx5tb();
        float f = playLayoutA39SiWGux5Rbalqx5tb.PMZrLoc0NF3euziS99o;
        float f2 = playLayoutA39SiWGux5Rbalqx5tb.j0yhOfa7n1b2lkVBAKt;
        float f3 = playLayoutA39SiWGux5Rbalqx5tb.EYwcyipzkILQreEEPxc;
        if (!this.Bn6dcy3rRNTGfMyxjUW) {
            com.kolosta.rejin.tarlyons.game.Repair repair = this.Dpa63RlwGiNbcDAIHuO;
            com.kolosta.rejin.tarlyons.game.Outcome outcome = repair.G069ZlNT3DZHrdUtBui;
            com.kolosta.rejin.tarlyons.game.Outcome outcome2 = com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm;
            if (outcome == outcome2) {
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                int actionMasked = motionEvent.getActionMasked();
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked == 2) {
                            if (this.fjT7LSJoZG8JrehrlZO) {
                                G069ZlNT3DZHrdUtBui(playLayoutA39SiWGux5Rbalqx5tb, x, y);
                                return true;
                            }
                        }
                    }
                    boolean z = motionEvent.getActionMasked() == 1;
                    if (this.fjT7LSJoZG8JrehrlZO) {
                        if (z) {
                            G069ZlNT3DZHrdUtBui(playLayoutA39SiWGux5Rbalqx5tb, x, y);
                        }
                        if (this.fjT7LSJoZG8JrehrlZO) {
                            repair.wDaxnHzF6aHr1xEjAAF = false;
                        }
                        this.fjT7LSJoZG8JrehrlZO = false;
                    } else if (this.ibR49E9wGBSot7bvPza && z && ((float) java.lang.Math.hypot(x - f3, y - f2)) <= f * 1.3f) {
                        java.util.ArrayList arrayList = repair.PMZrLoc0NF3euziS99o;
                        if (repair.GerKUYaWR62lFxYixsm()) {
                            java.util.ArrayList arrayList2 = repair.EYwcyipzkILQreEEPxc;
                            java.lang.Object objRemove = arrayList2.remove(arrayList2.size() - 1);
                            objRemove.getClass();
                            int iIntValue = ((java.lang.Number) objRemove).intValue();
                            while (arrayList.size() > iIntValue) {
                                arrayList.remove(arrayList.size() - 1);
                                java.util.HashSet hashSet = repair.A39SiWGux5Rbalqx5tb;
                                java.util.ArrayList arrayList3 = repair.GerKUYaWR62lFxYixsm;
                                hashSet.remove(arrayList3.remove(arrayList3.size() - 1));
                            }
                            repair.Dpa63RlwGiNbcDAIHuO = true;
                        }
                    } else if (z && this.cu4Sb8NChS0DjnyJZJl >= 0 && ((float) java.lang.Math.hypot(x - this.pRCzcKHbTdhACOvA8KQ, y - this.NgCDV6MKlbRA4vspgL6)) < getDp() * 14.0f) {
                        int iVddF2l9gapSy7l41Z9d = playLayoutA39SiWGux5Rbalqx5tb.VddF2l9gapSy7l41Z9d(x, y);
                        int i = this.cu4Sb8NChS0DjnyJZJl;
                        if (iVddF2l9gapSy7l41Z9d == i && repair.G069ZlNT3DZHrdUtBui == outcome2 && repair.A39SiWGux5Rbalqx5tb() && !repair.wDaxnHzF6aHr1xEjAAF && i >= 0 && i < repair.uMOFIbPk0BxLkjW3KR7.iCK2U69IDurvZVodhWo) {
                            int[] iArr = repair.iCK2U69IDurvZVodhWo;
                            iArr[i] = (iArr[i] + 1) & 3;
                            repair.lVvt79Js7aeYnsjUe7L = null;
                            int i2 = this.cu4Sb8NChS0DjnyJZJl;
                            float[] fArr = this.GRDgDa6Vavh8ZfltzLU;
                            fArr[i2] = fArr[i2] - 90.0f;
                        }
                    }
                    this.ibR49E9wGBSot7bvPza = false;
                    this.cu4Sb8NChS0DjnyJZJl = -1;
                    return true;
                }
                this.cu4Sb8NChS0DjnyJZJl = -1;
                this.ibR49E9wGBSot7bvPza = false;
                if (((float) java.lang.Math.hypot(x - playLayoutA39SiWGux5Rbalqx5tb.GerKUYaWR62lFxYixsm, y - playLayoutA39SiWGux5Rbalqx5tb.A39SiWGux5Rbalqx5tb)) <= playLayoutA39SiWGux5Rbalqx5tb.VddF2l9gapSy7l41Z9d * 1.4f) {
                    EYwcyipzkILQreEEPxc();
                    return true;
                }
                if (((float) java.lang.Math.hypot(x - f3, y - f2)) <= f * 1.15f) {
                    this.ibR49E9wGBSot7bvPza = true;
                    return true;
                }
                if (((float) java.lang.Math.hypot(x - playLayoutA39SiWGux5Rbalqx5tb.uMOFIbPk0BxLkjW3KR7(repair.VddF2l9gapSy7l41Z9d()), y - playLayoutA39SiWGux5Rbalqx5tb.iCK2U69IDurvZVodhWo(repair.VddF2l9gapSy7l41Z9d()))) <= java.lang.Math.max(playLayoutA39SiWGux5Rbalqx5tb.Dpa63RlwGiNbcDAIHuO * 1.25f, getDp() * 24.0f) && repair.G069ZlNT3DZHrdUtBui == outcome2 && !repair.wDaxnHzF6aHr1xEjAAF) {
                    repair.wDaxnHzF6aHr1xEjAAF = true;
                    repair.j0yhOfa7n1b2lkVBAKt = false;
                    this.fjT7LSJoZG8JrehrlZO = true;
                    this.VI2W3ke12Vku4BIAUkB = x;
                    this.nt8i71cb0KrXpdctesw = y;
                    return true;
                }
                this.cu4Sb8NChS0DjnyJZJl = playLayoutA39SiWGux5Rbalqx5tb.VddF2l9gapSy7l41Z9d(x, y);
                this.pRCzcKHbTdhACOvA8KQ = x;
                this.NgCDV6MKlbRA4vspgL6 = y;
            }
        }
        return true;
    }

    public final void setInsetBottom(float f) {
        this.insetBottom = f;
        this.wDaxnHzF6aHr1xEjAAF = null;
    }

    public final void setInsetTop(float f) {
        this.insetTop = f;
        this.wDaxnHzF6aHr1xEjAAF = null;
    }
}
