package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Nodes;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Nodes {
    public static int iCK2U69IDurvZVodhWo(int i) {
        return (i - 1) / 25;
    }

    public static int uMOFIbPk0BxLkjW3KR7(int i, int i2, int i3) {
        return (i3 * 5) + (i * 25) + 1 + i2;
    }
}
