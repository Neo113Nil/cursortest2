package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Repair;", "", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Repair {
    public boolean Dpa63RlwGiNbcDAIHuO;
    public int JjLaFjoHTCoTSMjQa7q;
    public final boolean[] VddF2l9gapSy7l41Z9d;
    public int gzg71nUFKNF0JyxrFIK;
    public final int[] iCK2U69IDurvZVodhWo;
    public boolean j0yhOfa7n1b2lkVBAKt;
    public kotlin.collections.builders.SetBuilder lVvt79Js7aeYnsjUe7L;
    public final com.kolosta.rejin.tarlyons.game.Tray uMOFIbPk0BxLkjW3KR7;
    public boolean wDaxnHzF6aHr1xEjAAF;
    public final java.util.ArrayList GerKUYaWR62lFxYixsm = new java.util.ArrayList();
    public final java.util.HashSet A39SiWGux5Rbalqx5tb = new java.util.HashSet();
    public final java.util.ArrayList PMZrLoc0NF3euziS99o = kotlin.collections.CollectionsKt.j0yhOfa7n1b2lkVBAKt(0);
    public final java.util.ArrayList EYwcyipzkILQreEEPxc = new java.util.ArrayList();
    public com.kolosta.rejin.tarlyons.game.Outcome G069ZlNT3DZHrdUtBui = com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm;

    /* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
    @kotlin.Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001R\u0014\u0010\u0003\u001a\u00020\u00028\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Repair$Companion;", "", "", "MAX_BREAKS", "I", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
    }

    public Repair(com.kolosta.rejin.tarlyons.game.Tray tray) {
        this.uMOFIbPk0BxLkjW3KR7 = tray;
        this.iCK2U69IDurvZVodhWo = new int[tray.iCK2U69IDurvZVodhWo];
        this.VddF2l9gapSy7l41Z9d = new boolean[tray.GerKUYaWR62lFxYixsm.size()];
    }

    public final boolean A39SiWGux5Rbalqx5tb() {
        java.util.ArrayList arrayList = this.GerKUYaWR62lFxYixsm;
        if (arrayList != null && arrayList.isEmpty()) {
            return true;
        }
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            java.lang.Object obj = arrayList.get(i);
            i++;
            if (((java.lang.Number) obj).intValue() != com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7) {
                return false;
            }
        }
        return true;
    }

    public final boolean GerKUYaWR62lFxYixsm() {
        return (this.Dpa63RlwGiNbcDAIHuO || this.wDaxnHzF6aHr1xEjAAF || this.G069ZlNT3DZHrdUtBui != com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm || this.EYwcyipzkILQreEEPxc.isEmpty()) ? false : true;
    }

    public final int PMZrLoc0NF3euziS99o(int i) {
        com.kolosta.rejin.tarlyons.game.Spread spread = (com.kolosta.rejin.tarlyons.game.Spread) this.uMOFIbPk0BxLkjW3KR7.GerKUYaWR62lFxYixsm.get(i);
        int i2 = spread.uMOFIbPk0BxLkjW3KR7;
        return com.kolosta.rejin.tarlyons.game.TraysKt.A39SiWGux5Rbalqx5tb(i2, spread.iCK2U69IDurvZVodhWo, this.iCK2U69IDurvZVodhWo[i2]);
    }

    public final int VddF2l9gapSy7l41Z9d() {
        return ((java.lang.Number) kotlin.collections.CollectionsKt.ZViMB9XTL2001TkWoQp(this.PMZrLoc0NF3euziS99o)).intValue();
    }

    public final boolean iCK2U69IDurvZVodhWo() {
        if (this.G069ZlNT3DZHrdUtBui != com.kolosta.rejin.tarlyons.game.Outcome.GerKUYaWR62lFxYixsm) {
            return false;
        }
        java.util.Set setUMOFIbPk0BxLkjW3KR7 = uMOFIbPk0BxLkjW3KR7();
        if (setUMOFIbPk0BxLkjW3KR7 != null && setUMOFIbPk0BxLkjW3KR7.isEmpty()) {
            return true;
        }
        java.util.Iterator it = setUMOFIbPk0BxLkjW3KR7.iterator();
        while (it.hasNext()) {
            int iIntValue = ((java.lang.Number) it.next()).intValue();
            if (!this.A39SiWGux5Rbalqx5tb.contains(java.lang.Integer.valueOf(iIntValue))) {
                int i = com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7;
                if (iIntValue / 1000 == VddF2l9gapSy7l41Z9d() || iIntValue % 1000 == VddF2l9gapSy7l41Z9d()) {
                    return false;
                }
            }
        }
        return true;
    }

    public final java.util.Set uMOFIbPk0BxLkjW3KR7() {
        com.kolosta.rejin.tarlyons.game.Tray tray = this.uMOFIbPk0BxLkjW3KR7;
        int i = tray.iCK2U69IDurvZVodhWo;
        kotlin.collections.builders.SetBuilder setBuilder = this.lVvt79Js7aeYnsjUe7L;
        if (setBuilder == null) {
            setBuilder = new kotlin.collections.builders.SetBuilder();
            setBuilder.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.uMOFIbPk0BxLkjW3KR7));
            if (i == 2) {
                setBuilder.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.iCK2U69IDurvZVodhWo));
            }
            int i2 = 0;
            for (int i3 = 0; i3 < i; i3++) {
                java.util.Iterator it = ((java.lang.Iterable) tray.VddF2l9gapSy7l41Z9d.get(i3)).iterator();
                while (it.hasNext()) {
                    setBuilder.add(java.lang.Integer.valueOf(com.kolosta.rejin.tarlyons.game.TraysKt.A39SiWGux5Rbalqx5tb(i3, ((java.lang.Number) it.next()).intValue(), this.iCK2U69IDurvZVodhWo[i3])));
                }
            }
            kotlin.ranges.IntRange intRangeMRZ5RjxkdVcb8tC2wM6 = kotlin.collections.CollectionsKt.mRZ5RjxkdVcb8tC2wM6(tray.GerKUYaWR62lFxYixsm);
            java.util.ArrayList arrayList = new java.util.ArrayList();
            java.util.Iterator<java.lang.Integer> it2 = intRangeMRZ5RjxkdVcb8tC2wM6.iterator();
            while (((kotlin.ranges.IntProgressionIterator) it2).PMZrLoc0NF3euziS99o) {
                java.lang.Object next = ((kotlin.collections.IntIterator) it2).next();
                if (this.VddF2l9gapSy7l41Z9d[((java.lang.Number) next).intValue()]) {
                    arrayList.add(next);
                }
            }
            int size = arrayList.size();
            while (i2 < size) {
                java.lang.Object obj = arrayList.get(i2);
                i2++;
                setBuilder.add(java.lang.Integer.valueOf(PMZrLoc0NF3euziS99o(((java.lang.Number) obj).intValue())));
            }
            kotlin.collections.builders.MapBuilder mapBuilder = setBuilder.GerKUYaWR62lFxYixsm;
            mapBuilder.VddF2l9gapSy7l41Z9d();
            if (mapBuilder.gzg71nUFKNF0JyxrFIK <= 0) {
                setBuilder = kotlin.collections.builders.SetBuilder.A39SiWGux5Rbalqx5tb;
            }
            this.lVvt79Js7aeYnsjUe7L = setBuilder;
        }
        return setBuilder;
    }
}
