package com.kolosta.rejin.tarlyons.game;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Outcome;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Outcome {
    public static final com.kolosta.rejin.tarlyons.game.Outcome A39SiWGux5Rbalqx5tb;
    public static final com.kolosta.rejin.tarlyons.game.Outcome EYwcyipzkILQreEEPxc;
    public static final com.kolosta.rejin.tarlyons.game.Outcome GerKUYaWR62lFxYixsm;
    public static final com.kolosta.rejin.tarlyons.game.Outcome PMZrLoc0NF3euziS99o;
    public static final /* synthetic */ com.kolosta.rejin.tarlyons.game.Outcome[] j0yhOfa7n1b2lkVBAKt;
    public static final /* synthetic */ kotlin.enums.EnumEntries lVvt79Js7aeYnsjUe7L;

    static {
        com.kolosta.rejin.tarlyons.game.Outcome outcome = new com.kolosta.rejin.tarlyons.game.Outcome("PLAYING", 0);
        GerKUYaWR62lFxYixsm = outcome;
        com.kolosta.rejin.tarlyons.game.Outcome outcome2 = new com.kolosta.rejin.tarlyons.game.Outcome("WON", 1);
        A39SiWGux5Rbalqx5tb = outcome2;
        com.kolosta.rejin.tarlyons.game.Outcome outcome3 = new com.kolosta.rejin.tarlyons.game.Outcome("BROKEN", 2);
        PMZrLoc0NF3euziS99o = outcome3;
        com.kolosta.rejin.tarlyons.game.Outcome outcome4 = new com.kolosta.rejin.tarlyons.game.Outcome("STUCK", 3);
        EYwcyipzkILQreEEPxc = outcome4;
        com.kolosta.rejin.tarlyons.game.Outcome[] outcomeArr = {outcome, outcome2, outcome3, outcome4};
        j0yhOfa7n1b2lkVBAKt = outcomeArr;
        lVvt79Js7aeYnsjUe7L = kotlin.enums.EnumEntriesKt.uMOFIbPk0BxLkjW3KR7(outcomeArr);
    }

    public static com.kolosta.rejin.tarlyons.game.Outcome valueOf(java.lang.String str) {
        return (com.kolosta.rejin.tarlyons.game.Outcome) java.lang.Enum.valueOf(com.kolosta.rejin.tarlyons.game.Outcome.class, str);
    }

    public static com.kolosta.rejin.tarlyons.game.Outcome[] values() {
        return (com.kolosta.rejin.tarlyons.game.Outcome[]) j0yhOfa7n1b2lkVBAKt.clone();
    }
}
