package com.kolosta.rejin.tarlyons.game;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Step;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Step {
    public static final com.kolosta.rejin.tarlyons.game.Step A39SiWGux5Rbalqx5tb;
    public static final /* synthetic */ com.kolosta.rejin.tarlyons.game.Step[] EYwcyipzkILQreEEPxc;
    public static final com.kolosta.rejin.tarlyons.game.Step GerKUYaWR62lFxYixsm;
    public static final com.kolosta.rejin.tarlyons.game.Step PMZrLoc0NF3euziS99o;
    public static final /* synthetic */ kotlin.enums.EnumEntries j0yhOfa7n1b2lkVBAKt;

    static {
        com.kolosta.rejin.tarlyons.game.Step step = new com.kolosta.rejin.tarlyons.game.Step("NONE", 0);
        GerKUYaWR62lFxYixsm = step;
        com.kolosta.rejin.tarlyons.game.Step step2 = new com.kolosta.rejin.tarlyons.game.Step("MOVED", 1);
        A39SiWGux5Rbalqx5tb = step2;
        com.kolosta.rejin.tarlyons.game.Step step3 = new com.kolosta.rejin.tarlyons.game.Step("BROKE", 2);
        PMZrLoc0NF3euziS99o = step3;
        com.kolosta.rejin.tarlyons.game.Step[] stepArr = {step, step2, step3};
        EYwcyipzkILQreEEPxc = stepArr;
        j0yhOfa7n1b2lkVBAKt = kotlin.enums.EnumEntriesKt.uMOFIbPk0BxLkjW3KR7(stepArr);
    }

    public static com.kolosta.rejin.tarlyons.game.Step valueOf(java.lang.String str) {
        return (com.kolosta.rejin.tarlyons.game.Step) java.lang.Enum.valueOf(com.kolosta.rejin.tarlyons.game.Step.class, str);
    }

    public static com.kolosta.rejin.tarlyons.game.Step[] values() {
        return (com.kolosta.rejin.tarlyons.game.Step[]) EYwcyipzkILQreEEPxc.clone();
    }
}
