package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/RunResult;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class RunResult {
    public final boolean A39SiWGux5Rbalqx5tb;
    public final java.util.Set EYwcyipzkILQreEEPxc;
    public final int GerKUYaWR62lFxYixsm;
    public final java.util.List PMZrLoc0NF3euziS99o;
    public final int VddF2l9gapSy7l41Z9d;
    public final com.kolosta.rejin.tarlyons.game.Outcome iCK2U69IDurvZVodhWo;
    public final com.kolosta.rejin.tarlyons.game.Tray uMOFIbPk0BxLkjW3KR7;

    public RunResult(com.kolosta.rejin.tarlyons.game.Tray tray, com.kolosta.rejin.tarlyons.game.Outcome outcome, int i, int i2, boolean z, int[] iArr, java.util.List list, java.util.Set set) {
        outcome.getClass();
        set.getClass();
        this.uMOFIbPk0BxLkjW3KR7 = tray;
        this.iCK2U69IDurvZVodhWo = outcome;
        this.VddF2l9gapSy7l41Z9d = i;
        this.GerKUYaWR62lFxYixsm = i2;
        this.A39SiWGux5Rbalqx5tb = z;
        this.PMZrLoc0NF3euziS99o = list;
        this.EYwcyipzkILQreEEPxc = set;
    }

    public final boolean uMOFIbPk0BxLkjW3KR7() {
        return this.iCK2U69IDurvZVodhWo == com.kolosta.rejin.tarlyons.game.Outcome.A39SiWGux5Rbalqx5tb;
    }
}
