package com.kolosta.rejin.tarlyons.game;

/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/game/Emblem;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class Emblem {
    public final int iCK2U69IDurvZVodhWo;
    public final int uMOFIbPk0BxLkjW3KR7;

    public Emblem(int i, int i2) {
        this.uMOFIbPk0BxLkjW3KR7 = i;
        this.iCK2U69IDurvZVodhWo = i2;
    }
}
