package com.kolosta.rejin.tarlyons;

/* loaded from: classes.dex */
public final class R {

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f010002;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f01000e;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f01000f;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f010010;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f010011;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f010012;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f010013;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f010014;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f010015;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f010016;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f010017;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f010018;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f010019;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f01001b;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f01002f;
    }

    public static final class color {

        /* JADX INFO: Added by JADX */
        public static final int color_background = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int color_primary = 0x7f020005;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_background = 0x7f020007;
    }

    public static final class drawable {

        /* JADX INFO: Added by JADX */
        public static final int art_brush = 0x7f040000;

        /* JADX INFO: Added by JADX */
        public static final int art_crack = 0x7f040001;

        /* JADX INFO: Added by JADX */
        public static final int art_emblem = 0x7f040002;

        /* JADX INFO: Added by JADX */
        public static final int art_hand = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int art_plate = 0x7f040004;

        /* JADX INFO: Added by JADX */
        public static final int art_table = 0x7f040005;

        /* JADX INFO: Added by JADX */
        public static final int art_token = 0x7f040006;
    }

    /* JADX INFO: Added by JADX */
    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f050002;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f050003;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f050007;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f050008;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f050009;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f05000a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f05000b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f05000c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f05000d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f05000e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f05000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f050010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f050011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f050012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f050013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f050014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f050015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f050016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f050017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f050018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f050019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f05001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f05001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f05001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f05001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f05001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f05001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f050020;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f050021;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f050022;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f050023;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f050024;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f050025;

        /* JADX INFO: Added by JADX */
        public static final int adjacent = 0x7f050026;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f050027;

        /* JADX INFO: Added by JADX */
        public static final int alwaysAllow = 0x7f050028;

        /* JADX INFO: Added by JADX */
        public static final int alwaysDisallow = 0x7f050029;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_composition_context = 0x7f05002a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_window_activity_scope = 0x7f05002b;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f05002c;

        /* JADX INFO: Added by JADX */
        public static final int auto_clear_focus_behavior_tag = 0x7f05002d;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f05002e;

        /* JADX INFO: Added by JADX */
        public static final int bottomToTop = 0x7f05002f;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f050030;

        /* JADX INFO: Added by JADX */
        public static final int compose_prefetch_scheduler = 0x7f050031;

        /* JADX INFO: Added by JADX */
        public static final int compose_view_saveable_id_tag = 0x7f050032;

        /* JADX INFO: Added by JADX */
        public static final int consume_window_insets_tag = 0x7f050033;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f050034;

        /* JADX INFO: Added by JADX */
        public static final int draggable = 0x7f050035;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f050036;

        /* JADX INFO: Added by JADX */
        public static final int fixed = 0x7f050037;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f050038;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view = 0x7f050039;

        /* JADX INFO: Added by JADX */
        public static final int ghost_view_holder = 0x7f05003a;

        /* JADX INFO: Added by JADX */
        public static final int hide_graphics_layer_in_inspector_tag = 0x7f05003b;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f05003c;

        /* JADX INFO: Added by JADX */
        public static final int hide_in_inspector_tag = 0x7f05003d;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f05003e;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f05003f;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f050040;

        /* JADX INFO: Added by JADX */
        public static final int inspection_slot_table_set = 0x7f050041;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f050042;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f050043;

        /* JADX INFO: Added by JADX */
        public static final int jumpCut = 0x7f050044;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f050045;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f050046;

        /* JADX INFO: Added by JADX */
        public static final int locale = 0x7f050047;

        /* JADX INFO: Added by JADX */
        public static final int ltr = 0x7f050048;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f050049;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f05004a;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f05004b;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f05004c;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f05004d;

        /* JADX INFO: Added by JADX */
        public static final int parent_matrix = 0x7f05004e;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f05004f;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f050050;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f050051;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f050052;

        /* JADX INFO: Added by JADX */
        public static final int rtl = 0x7f050053;

        /* JADX INFO: Added by JADX */
        public static final int save_non_transition_alpha = 0x7f050054;

        /* JADX INFO: Added by JADX */
        public static final int save_overlay_view = 0x7f050055;

        /* JADX INFO: Added by JADX */
        public static final int systemDefault = 0x7f050056;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f050057;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f050058;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f050059;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f05005a;

        /* JADX INFO: Added by JADX */
        public static final int tag_compat_insets_dispatch = 0x7f05005b;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f05005c;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f05005d;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f05005e;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f05005f;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f050060;

        /* JADX INFO: Added by JADX */
        public static final int tag_system_bar_state_monitor = 0x7f050061;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f050062;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f050063;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f050064;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f050065;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f050066;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f050067;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f050068;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f050069;

        /* JADX INFO: Added by JADX */
        public static final int topToBottom = 0x7f05006a;

        /* JADX INFO: Added by JADX */
        public static final int transition_clip = 0x7f05006b;

        /* JADX INFO: Added by JADX */
        public static final int transition_current_scene = 0x7f05006c;

        /* JADX INFO: Added by JADX */
        public static final int transition_image_transform = 0x7f05006d;

        /* JADX INFO: Added by JADX */
        public static final int transition_layout_save = 0x7f05006e;

        /* JADX INFO: Added by JADX */
        public static final int transition_pause_alpha = 0x7f05006f;

        /* JADX INFO: Added by JADX */
        public static final int transition_position = 0x7f050070;

        /* JADX INFO: Added by JADX */
        public static final int transition_scene_layoutid_cache = 0x7f050071;

        /* JADX INFO: Added by JADX */
        public static final int transition_transform = 0x7f050072;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_disjoint_parent = 0x7f050073;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f050074;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_navigation_event_dispatcher_owner = 0x7f050075;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f050076;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f050077;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f050078;

        /* JADX INFO: Added by JADX */
        public static final int wrapped_composition_tag = 0x7f050079;
    }

    public static final class mipmap {

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_foreground = 0x7f080001;

        /* JADX INFO: Added by JADX */
        public static final int ic_launcher_round = 0x7f080002;
    }

    public static final class string {

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_foundation_autofill = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_autofill = 0x7f090001;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f090002;

        /* JADX INFO: Added by JADX */
        public static final int app_name = 0x7f090003;

        /* JADX INFO: Added by JADX */
        public static final int default_error_message = 0x7f09000d;

        /* JADX INFO: Added by JADX */
        public static final int default_popup_window_title = 0x7f09000e;

        /* JADX INFO: Added by JADX */
        public static final int in_progress = 0x7f090010;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f090011;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_drag_handle_description = 0x7f090014;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_day_selection = 0x7f090026;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_next_month = 0x7f090028;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_previous_month = 0x7f090029;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_year_selection = 0x7f09002a;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_year_picker_pane_title = 0x7f09002d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dialog = 0x7f090036;

        /* JADX INFO: Added by JADX */
        public static final int m3c_snackbar_dismiss = 0x7f09003d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_am = 0x7f090041;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_pm = 0x7f09004d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_toggle_touch = 0x7f09004f;

        /* JADX INFO: Added by JADX */
        public static final int not_selected = 0x7f090055;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f090058;

        /* JADX INFO: Added by JADX */
        public static final int state_empty = 0x7f09005a;

        /* JADX INFO: Added by JADX */
        public static final int state_off = 0x7f09005b;

        /* JADX INFO: Added by JADX */
        public static final int state_on = 0x7f09005c;

        /* JADX INFO: Added by JADX */
        public static final int switch_role = 0x7f09005e;

        /* JADX INFO: Added by JADX */
        public static final int tab = 0x7f09005f;

        /* JADX INFO: Added by JADX */
        public static final int template_percent = 0x7f090060;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_description = 0x7f090061;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_label = 0x7f090062;
    }

    public static final class style {

        /* JADX INFO: Added by JADX */
        public static final int Theme_App = 0x7f0a0009;
    }

    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int backup_rules = 0x7f0c0000;

        /* JADX INFO: Added by JADX */
        public static final int data_extraction_rules = 0x7f0c0001;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f0c0002;
    }
}
