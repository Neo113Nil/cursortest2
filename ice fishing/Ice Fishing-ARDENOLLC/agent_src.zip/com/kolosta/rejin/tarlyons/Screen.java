package com.kolosta.rejin.tarlyons;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-4f3a778684672a5bd23d896c176678fe5ab0c81d7a077a28ae1a199a78996b16 */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/kolosta/rejin/tarlyons/Screen;", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
final class Screen {
    public static final com.kolosta.rejin.tarlyons.Screen A39SiWGux5Rbalqx5tb;
    public static final com.kolosta.rejin.tarlyons.Screen EYwcyipzkILQreEEPxc;
    public static final /* synthetic */ kotlin.enums.EnumEntries G069ZlNT3DZHrdUtBui;
    public static final com.kolosta.rejin.tarlyons.Screen GerKUYaWR62lFxYixsm;
    public static final com.kolosta.rejin.tarlyons.Screen PMZrLoc0NF3euziS99o;
    public static final com.kolosta.rejin.tarlyons.Screen j0yhOfa7n1b2lkVBAKt;
    public static final /* synthetic */ com.kolosta.rejin.tarlyons.Screen[] lVvt79Js7aeYnsjUe7L;

    static {
        com.kolosta.rejin.tarlyons.Screen screen = new com.kolosta.rejin.tarlyons.Screen("TABLE", 0);
        GerKUYaWR62lFxYixsm = screen;
        com.kolosta.rejin.tarlyons.Screen screen2 = new com.kolosta.rejin.tarlyons.Screen("STACK", 1);
        A39SiWGux5Rbalqx5tb = screen2;
        com.kolosta.rejin.tarlyons.Screen screen3 = new com.kolosta.rejin.tarlyons.Screen("PLAY", 2);
        PMZrLoc0NF3euziS99o = screen3;
        com.kolosta.rejin.tarlyons.Screen screen4 = new com.kolosta.rejin.tarlyons.Screen("REVEAL", 3);
        EYwcyipzkILQreEEPxc = screen4;
        com.kolosta.rejin.tarlyons.Screen screen5 = new com.kolosta.rejin.tarlyons.Screen("CABINET", 4);
        j0yhOfa7n1b2lkVBAKt = screen5;
        com.kolosta.rejin.tarlyons.Screen[] screenArr = {screen, screen2, screen3, screen4, screen5};
        lVvt79Js7aeYnsjUe7L = screenArr;
        G069ZlNT3DZHrdUtBui = kotlin.enums.EnumEntriesKt.uMOFIbPk0BxLkjW3KR7(screenArr);
    }

    public static com.kolosta.rejin.tarlyons.Screen valueOf(java.lang.String str) {
        return (com.kolosta.rejin.tarlyons.Screen) java.lang.Enum.valueOf(com.kolosta.rejin.tarlyons.Screen.class, str);
    }

    public static com.kolosta.rejin.tarlyons.Screen[] values() {
        return (com.kolosta.rejin.tarlyons.Screen[]) lVvt79Js7aeYnsjUe7L.clone();
    }
}
