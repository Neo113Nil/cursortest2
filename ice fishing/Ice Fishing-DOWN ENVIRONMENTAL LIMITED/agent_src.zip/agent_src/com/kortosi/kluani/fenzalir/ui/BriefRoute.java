package com.kortosi.kluani.fenzalir.ui;

import defpackage.hj0;
import defpackage.i2;
import defpackage.so1;
import defpackage.uv0;
import defpackage.wf;
import defpackage.wo1;
import defpackage.xf;
import java.util.ArrayList;

@wo1
/* loaded from: classes.dex */
public final class BriefRoute {
    public static final xf Companion = new xf();
    public final String a;

    public BriefRoute(String str, int i) {
        String str2;
        if (1 == (i & 1)) {
            this.a = str;
            return;
        }
        so1 so1VarD = wf.a.d();
        so1VarD.getClass();
        ArrayList arrayList = new ArrayList();
        int i2 = (~i) & 1;
        int i3 = 0;
        while (i3 < 32) {
            if ((i2 & 1) != 0) {
                arrayList.add(so1VarD.d(i3));
            }
            i3++;
            i2 = 0;
        }
        String strA = so1VarD.a();
        strA.getClass();
        if (arrayList.size() == 1) {
            str2 = "Field '" + ((String) arrayList.get(0)) + "' is required for type with serial name '" + strA + "', but it was missing";
        } else {
            str2 = "Fields " + arrayList + " are required for type with serial name '" + strA + "', but they were missing";
        }
        throw new uv0(str2, null);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof BriefRoute) && hj0.k(this.a, ((BriefRoute) obj).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return i2.k("BriefRoute(gameId=", this.a, ")");
    }

    public BriefRoute(String str) {
        this.a = str;
    }
}
