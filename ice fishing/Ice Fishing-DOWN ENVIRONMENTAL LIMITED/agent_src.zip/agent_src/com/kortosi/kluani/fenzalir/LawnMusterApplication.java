package com.kortosi.kluani.fenzalir;

import android.app.Application;
import defpackage.iv1;
import defpackage.u6;

/* loaded from: classes.dex */
public final class LawnMusterApplication extends Application {
    public static final /* synthetic */ int g = 0;
    public final iv1 f = new iv1(new u6(18, this));
}
