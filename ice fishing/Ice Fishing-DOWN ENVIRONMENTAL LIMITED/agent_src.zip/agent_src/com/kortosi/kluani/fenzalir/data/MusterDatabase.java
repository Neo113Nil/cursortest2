package com.kortosi.kluani.fenzalir.data;

import defpackage.gx0;
import defpackage.ji1;

/* loaded from: classes.dex */
public abstract class MusterDatabase extends ji1 {
    public abstract gx0 m();
}
