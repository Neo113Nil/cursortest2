package com.kortosi.kluani.fenzalir.ui;

import defpackage.bn0;
import defpackage.fr;
import defpackage.lk0;
import defpackage.mq0;
import defpackage.rs0;
import defpackage.wo1;

@wo1
/* loaded from: classes.dex */
public final class PennantRoute {
    public static final PennantRoute INSTANCE = new PennantRoute();
    public static final /* synthetic */ bn0 a = fr.K(mq0.f, new rs0(9));

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof PennantRoute);
    }

    public final int hashCode() {
        return -736129652;
    }

    public final lk0 serializer() {
        return (lk0) a.getValue();
    }

    public final String toString() {
        return "PennantRoute";
    }
}
