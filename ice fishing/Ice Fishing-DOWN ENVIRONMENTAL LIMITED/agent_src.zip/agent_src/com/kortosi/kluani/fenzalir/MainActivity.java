package com.kortosi.kluani.fenzalir;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.ar1;
import defpackage.cr1;
import defpackage.h30;
import defpackage.hr1;
import defpackage.i30;
import defpackage.j30;
import defpackage.jv1;
import defpackage.k30;
import defpackage.l30;
import defpackage.m30;
import defpackage.n30;
import defpackage.nn;
import defpackage.o30;
import defpackage.on;
import defpackage.qk1;
import defpackage.ql;
import defpackage.tn;
import defpackage.zo;

/* loaded from: classes.dex */
public final class MainActivity extends nn {
    @Override // defpackage.nn, defpackage.mn, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        jv1 jv1Var = new jv1(0, 0, new qk1(14));
        jv1 jv1Var2 = new jv1(j30.a, j30.b, new qk1(14));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        k30 o30Var = j30.c;
        if (o30Var == null) {
            int i = Build.VERSION.SDK_INT;
            o30Var = i >= 35 ? new o30() : i >= 30 ? new n30() : i >= 29 ? new m30() : i >= 28 ? new l30() : new k30();
            j30.c = o30Var;
        }
        k30 k30Var = o30Var;
        h30 h30Var = new h30(k30Var, jv1Var, jv1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                i30 i30Var = new i30(h30Var, viewGroup.getContext());
                i30Var.setTag(k30Var);
                i30Var.setVisibility(8);
                i30Var.setWillNotDraw(true);
                viewGroup.addView(i30Var);
                break;
            }
            int i3 = i2 + 1;
            View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof k30) {
                break;
            } else {
                i2 = i3;
            }
        }
        h30Var.run();
        Window window = getWindow();
        window.getClass();
        k30Var.a(window);
        tn tnVar = ql.c;
        ViewGroup.LayoutParams layoutParams = on.a;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        zo zoVar = childAt2 instanceof zo ? (zo) childAt2 : null;
        if (zoVar != null) {
            zoVar.setParentCompositionContext(null);
            zoVar.setContent(tnVar);
            return;
        }
        zo zoVar2 = new zo(this);
        zoVar2.setParentCompositionContext(null);
        zoVar2.setContent(tnVar);
        View decorView2 = getWindow().getDecorView();
        if (ar1.g(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (hr1.d(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (cr1.f(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(zoVar2, on.a);
    }
}
