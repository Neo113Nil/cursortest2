package com.kortosi.kluani.fenzalir.data;

import defpackage.gx0;
import defpackage.hx0;
import defpackage.iv1;
import defpackage.jg1;
import defpackage.q40;
import defpackage.rj0;
import defpackage.u6;
import defpackage.v30;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
public final class MusterDatabase_Impl extends MusterDatabase {
    public final iv1 l = new iv1(new u6(26, this));

    @Override // defpackage.ji1
    public final List b(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // defpackage.ji1
    public final rj0 c() {
        return new rj0(this, new LinkedHashMap(), new LinkedHashMap(), "game_records", "player_profile");
    }

    @Override // defpackage.ji1
    public final v30 d() {
        return new hx0(this);
    }

    @Override // defpackage.ji1
    public final Set g() {
        return new LinkedHashSet();
    }

    @Override // defpackage.ji1
    public final LinkedHashMap h() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(jg1.a(gx0.class), q40.f);
        return linkedHashMap;
    }

    @Override // com.kortosi.kluani.fenzalir.data.MusterDatabase
    public final gx0 m() {
        return (gx0) this.l.getValue();
    }
}
