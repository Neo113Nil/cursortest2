package h;

import P.W;
import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.C0112w;
import androidx.lifecycle.EnumC0103m;
import androidx.lifecycle.EnumC0104n;
import androidx.lifecycle.T;
import androidx.lifecycle.d0;
import androidx.navigation.fragment.NavHostFragment;
import b0.AbstractComponentCallbacksC0141w;
import b0.C0143y;
import b0.P;
import b0.S;
import b0.Z;
import com.general.melcan.fizorysam.MainActivity;
import f0.C0167a;
import h.AbstractActivityC0194i;
import h0.C0201a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import l.C0247c;
import n.C0315t;
import n.O0;
import n.i1;
import s.C0407h;
import s.C0410k;
import u1.C0447a;

/* renamed from: h.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0194i extends b.k implements InterfaceC0195j {

    /* renamed from: u, reason: collision with root package name */
    public boolean f3498u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f3499v;

    /* renamed from: x, reason: collision with root package name */
    public LayoutInflaterFactory2C0178C f3501x;

    /* renamed from: s, reason: collision with root package name */
    public final C.b f3496s = new C.b(18, new C0143y(this));

    /* renamed from: t, reason: collision with root package name */
    public final C0112w f3497t = new C0112w(this);

    /* renamed from: w, reason: collision with root package name */
    public boolean f3500w = true;

    public AbstractActivityC0194i() {
        ((A.i) this.f2228f.f94d).M("android:support:lifecycle", new b.d(this, 1));
        final int i = 0;
        g(new O.a(this) { // from class: b0.x

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ AbstractActivityC0194i f2527b;

            {
                this.f2527b = this;
            }

            @Override // O.a
            public final void a(Object obj) {
                switch (i) {
                    case 0:
                        this.f2527b.f3496s.B();
                        break;
                    default:
                        this.f2527b.f3496s.B();
                        break;
                }
            }
        });
        final int i2 = 1;
        this.f2235n.add(new O.a(this) { // from class: b0.x

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ AbstractActivityC0194i f2527b;

            {
                this.f2527b = this;
            }

            @Override // O.a
            public final void a(Object obj) {
                switch (i2) {
                    case 0:
                        this.f2527b.f3496s.B();
                        break;
                    default:
                        this.f2527b.f3496s.B();
                        break;
                }
            }
        });
        h(new b.e(this, 1));
    }

    public static boolean n(P p2) {
        EnumC0104n enumC0104n = EnumC0104n.f2050d;
        boolean z2 = false;
        for (AbstractComponentCallbacksC0141w abstractComponentCallbacksC0141w : p2.f2313c.k()) {
            if (abstractComponentCallbacksC0141w != null) {
                C0143y c0143y = abstractComponentCallbacksC0141w.f2522w;
                if ((c0143y == null ? null : c0143y.f2531f) != null) {
                    z2 |= n(abstractComponentCallbacksC0141w.g());
                }
                Z z3 = abstractComponentCallbacksC0141w.f2498R;
                EnumC0104n enumC0104n2 = EnumC0104n.e;
                if (z3 != null) {
                    z3.e();
                    if (z3.e.f2063d.compareTo(enumC0104n2) >= 0) {
                        abstractComponentCallbacksC0141w.f2498R.e.g(enumC0104n);
                        z2 = true;
                    }
                }
                if (abstractComponentCallbacksC0141w.f2497Q.f2063d.compareTo(enumC0104n2) >= 0) {
                    abstractComponentCallbacksC0141w.f2497Q.g(enumC0104n);
                    z2 = true;
                }
            }
        }
        return z2;
    }

    @Override // android.app.Activity
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m();
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.w();
        ((ViewGroup) layoutInflaterFactory2C0178C.f3346B.findViewById(R.id.content)).addView(view, layoutParams);
        layoutInflaterFactory2C0178C.f3379n.a(layoutInflaterFactory2C0178C.f3378m.getCallback());
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        Configuration configuration;
        int i = 0;
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.f3358P = true;
        int i2 = layoutInflaterFactory2C0178C.f3362T;
        if (i2 == -100) {
            i2 = p.f3509c;
        }
        int C2 = layoutInflaterFactory2C0178C.C(context, i2);
        if (p.c(context) && p.c(context)) {
            if (Build.VERSION.SDK_INT < 33) {
                synchronized (p.f3514j) {
                    try {
                        L.b bVar = p.f3510d;
                        if (bVar == null) {
                            if (p.e == null) {
                                p.e = L.b.a(E.e.e(context));
                            }
                            if (!p.e.f721a.f722a.isEmpty()) {
                                p.f3510d = p.e;
                            }
                        } else if (!bVar.equals(p.e)) {
                            L.b bVar2 = p.f3510d;
                            p.e = bVar2;
                            E.e.d(context, bVar2.f721a.f722a.toLanguageTags());
                        }
                    } finally {
                    }
                }
            } else if (!p.f3512g) {
                p.f3508b.execute(new RunnableC0196k(context, i));
            }
        }
        L.b n2 = LayoutInflaterFactory2C0178C.n(context);
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(LayoutInflaterFactory2C0178C.s(context, C2, n2, null, false));
            } catch (IllegalStateException unused) {
            }
            super.attachBaseContext(context);
        }
        if (context instanceof C0247c) {
            try {
                ((C0247c) context).a(LayoutInflaterFactory2C0178C.s(context, C2, n2, null, false));
            } catch (IllegalStateException unused2) {
            }
            super.attachBaseContext(context);
        }
        if (LayoutInflaterFactory2C0178C.f3344k0) {
            Configuration configuration2 = new Configuration();
            configuration2.uiMode = -1;
            configuration2.fontScale = 0.0f;
            Configuration configuration3 = context.createConfigurationContext(configuration2).getResources().getConfiguration();
            Configuration configuration4 = context.getResources().getConfiguration();
            configuration3.uiMode = configuration4.uiMode;
            if (configuration3.equals(configuration4)) {
                configuration = null;
            } else {
                configuration = new Configuration();
                configuration.fontScale = 0.0f;
                if (configuration3.diff(configuration4) != 0) {
                    float f2 = configuration3.fontScale;
                    float f3 = configuration4.fontScale;
                    if (f2 != f3) {
                        configuration.fontScale = f3;
                    }
                    int i3 = configuration3.mcc;
                    int i4 = configuration4.mcc;
                    if (i3 != i4) {
                        configuration.mcc = i4;
                    }
                    int i5 = configuration3.mnc;
                    int i6 = configuration4.mnc;
                    if (i5 != i6) {
                        configuration.mnc = i6;
                    }
                    u.a(configuration3, configuration4, configuration);
                    int i7 = configuration3.touchscreen;
                    int i8 = configuration4.touchscreen;
                    if (i7 != i8) {
                        configuration.touchscreen = i8;
                    }
                    int i9 = configuration3.keyboard;
                    int i10 = configuration4.keyboard;
                    if (i9 != i10) {
                        configuration.keyboard = i10;
                    }
                    int i11 = configuration3.keyboardHidden;
                    int i12 = configuration4.keyboardHidden;
                    if (i11 != i12) {
                        configuration.keyboardHidden = i12;
                    }
                    int i13 = configuration3.navigation;
                    int i14 = configuration4.navigation;
                    if (i13 != i14) {
                        configuration.navigation = i14;
                    }
                    int i15 = configuration3.navigationHidden;
                    int i16 = configuration4.navigationHidden;
                    if (i15 != i16) {
                        configuration.navigationHidden = i16;
                    }
                    int i17 = configuration3.orientation;
                    int i18 = configuration4.orientation;
                    if (i17 != i18) {
                        configuration.orientation = i18;
                    }
                    int i19 = configuration3.screenLayout & 15;
                    int i20 = configuration4.screenLayout & 15;
                    if (i19 != i20) {
                        configuration.screenLayout |= i20;
                    }
                    int i21 = configuration3.screenLayout & 192;
                    int i22 = configuration4.screenLayout & 192;
                    if (i21 != i22) {
                        configuration.screenLayout |= i22;
                    }
                    int i23 = configuration3.screenLayout & 48;
                    int i24 = configuration4.screenLayout & 48;
                    if (i23 != i24) {
                        configuration.screenLayout |= i24;
                    }
                    int i25 = configuration3.screenLayout & 768;
                    int i26 = configuration4.screenLayout & 768;
                    if (i25 != i26) {
                        configuration.screenLayout |= i26;
                    }
                    int i27 = configuration3.colorMode & 3;
                    int i28 = configuration4.colorMode & 3;
                    if (i27 != i28) {
                        configuration.colorMode |= i28;
                    }
                    int i29 = configuration3.colorMode & 12;
                    int i30 = configuration4.colorMode & 12;
                    if (i29 != i30) {
                        configuration.colorMode |= i30;
                    }
                    int i31 = configuration3.uiMode & 15;
                    int i32 = configuration4.uiMode & 15;
                    if (i31 != i32) {
                        configuration.uiMode |= i32;
                    }
                    int i33 = configuration3.uiMode & 48;
                    int i34 = configuration4.uiMode & 48;
                    if (i33 != i34) {
                        configuration.uiMode |= i34;
                    }
                    int i35 = configuration3.screenWidthDp;
                    int i36 = configuration4.screenWidthDp;
                    if (i35 != i36) {
                        configuration.screenWidthDp = i36;
                    }
                    int i37 = configuration3.screenHeightDp;
                    int i38 = configuration4.screenHeightDp;
                    if (i37 != i38) {
                        configuration.screenHeightDp = i38;
                    }
                    int i39 = configuration3.smallestScreenWidthDp;
                    int i40 = configuration4.smallestScreenWidthDp;
                    if (i39 != i40) {
                        configuration.smallestScreenWidthDp = i40;
                    }
                    int i41 = configuration3.densityDpi;
                    int i42 = configuration4.densityDpi;
                    if (i41 != i42) {
                        configuration.densityDpi = i42;
                    }
                }
            }
            Configuration s2 = LayoutInflaterFactory2C0178C.s(context, C2, n2, configuration, true);
            C0247c c0247c = new C0247c(context, com.general.melcan.fizorysam.R.style.Theme_AppCompat_Empty);
            c0247c.a(s2);
            try {
                if (context.getTheme() != null) {
                    Resources.Theme theme = c0247c.getTheme();
                    if (Build.VERSION.SDK_INT >= 29) {
                        G.m.a(theme);
                    } else {
                        synchronized (G.b.e) {
                            if (!G.b.f540g) {
                                try {
                                    Method declaredMethod = Resources.Theme.class.getDeclaredMethod("rebase", null);
                                    G.b.f539f = declaredMethod;
                                    declaredMethod.setAccessible(true);
                                } catch (NoSuchMethodException e) {
                                    Log.i("ResourcesCompat", "Failed to retrieve rebase() method", e);
                                }
                                G.b.f540g = true;
                            }
                            Method method = G.b.f539f;
                            if (method != null) {
                                try {
                                    method.invoke(theme, null);
                                } catch (IllegalAccessException | InvocationTargetException e3) {
                                    Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", e3);
                                    G.b.f539f = null;
                                }
                            }
                        }
                    }
                }
            } catch (NullPointerException unused3) {
            }
            context = c0247c;
        }
        super.attachBaseContext(context);
    }

    @Override // android.app.Activity
    public final void closeOptionsMenu() {
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (getWindow().hasFeature(0)) {
            if (bVar == null || !bVar.e()) {
                super.closeOptionsMenu();
            }
        }
    }

    @Override // b.k, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (keyCode == 82 && bVar != null && bVar.X(keyEvent)) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0033, code lost:
    
        if (r1.equals("--list-dumpables") == false) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0043, code lost:
    
        if (android.os.Build.VERSION.SDK_INT < 33) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x003c, code lost:
    
        if (r1.equals("--dump-dumpable") == false) goto L34;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                        return;
                    }
                    break;
                case 100470631:
                    break;
                case 472614934:
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                        return;
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill")) {
                        return;
                    }
                    break;
            }
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.f3498u);
        printWriter.print(" mResumed=");
        printWriter.print(this.f3499v);
        printWriter.print(" mStopped=");
        printWriter.print(this.f3500w);
        if (getApplication() != null) {
            d0 c2 = c();
            S s2 = C0201a.f3531c;
            N1.i.e(c2, "store");
            C0167a c0167a = C0167a.f3206b;
            N1.i.e(c0167a, "defaultCreationExtras");
            C.l lVar = new C.l(c2, s2, c0167a);
            N1.e a3 = N1.o.a(C0201a.class);
            String b3 = a3.b();
            if (b3 == null) {
                throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
            }
            C0410k c0410k = ((C0201a) lVar.m(a3, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(b3))).f3532b;
            if (c0410k.e() > 0) {
                printWriter.print(str3);
                printWriter.println("Loaders:");
                if (c0410k.e() > 0) {
                    if (c0410k.f(0) != null) {
                        throw new ClassCastException();
                    }
                    printWriter.print(str3);
                    printWriter.print("  #");
                    printWriter.print(c0410k.c(0));
                    printWriter.print(": ");
                    throw null;
                }
            }
        }
        ((C0143y) this.f3496s.f283c).e.w(str, fileDescriptor, printWriter, strArr);
    }

    @Override // android.app.Activity
    public final View findViewById(int i) {
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.w();
        return layoutInflaterFactory2C0178C.f3378m.findViewById(i);
    }

    @Override // android.app.Activity
    public final MenuInflater getMenuInflater() {
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        if (layoutInflaterFactory2C0178C.f3382q == null) {
            layoutInflaterFactory2C0178C.A();
            g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
            layoutInflaterFactory2C0178C.f3382q = new l.h(bVar != null ? bVar.H() : layoutInflaterFactory2C0178C.f3377l);
        }
        return layoutInflaterFactory2C0178C.f3382q;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        int i = i1.f4323a;
        return super.getResources();
    }

    @Override // android.app.Activity
    public final void invalidateOptionsMenu() {
        l().b();
    }

    public final p l() {
        if (this.f3501x == null) {
            ExecutorC0199n executorC0199n = p.f3508b;
            this.f3501x = new LayoutInflaterFactory2C0178C(this, null, this, this);
        }
        return this.f3501x;
    }

    public final void m() {
        T.j(getWindow().getDecorView(), this);
        View decorView = getWindow().getDecorView();
        N1.i.e(decorView, "<this>");
        decorView.setTag(com.general.melcan.fizorysam.R.id.view_tree_view_model_store_owner, this);
        C0447a.v(getWindow().getDecorView(), this);
        W.R(getWindow().getDecorView(), this);
    }

    public final void o() {
        super.onDestroy();
        ((C0143y) this.f3496s.f283c).e.l();
        this.f3497t.d(EnumC0103m.ON_DESTROY);
    }

    @Override // b.k, android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        this.f3496s.B();
        super.onActivityResult(i, i2, intent);
    }

    @Override // b.k, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        if (layoutInflaterFactory2C0178C.f3350G && layoutInflaterFactory2C0178C.f3345A) {
            layoutInflaterFactory2C0178C.A();
            g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
            if (bVar != null) {
                bVar.R();
            }
        }
        C0315t a3 = C0315t.a();
        Context context = layoutInflaterFactory2C0178C.f3377l;
        synchronized (a3) {
            O0 o02 = a3.f4386a;
            synchronized (o02) {
                C0407h c0407h = (C0407h) o02.f4184b.get(context);
                if (c0407h != null) {
                    c0407h.a();
                }
            }
        }
        layoutInflaterFactory2C0178C.f3361S = new Configuration(layoutInflaterFactory2C0178C.f3377l.getResources().getConfiguration());
        layoutInflaterFactory2C0178C.l(false, false);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onContentChanged() {
    }

    @Override // b.k, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f3497t.d(EnumC0103m.ON_CREATE);
        P p2 = ((C0143y) this.f3496s.f283c).e;
        p2.f2303H = false;
        p2.f2304I = false;
        p2.f2309O.f2347g = false;
        p2.u(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View onCreateView = ((C0143y) this.f3496s.f283c).e.f2315f.onCreateView(view, str, context, attributeSet);
        return onCreateView == null ? super.onCreateView(view, str, context, attributeSet) : onCreateView;
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        o();
        l().e();
    }

    @Override // b.k, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (p(i, menuItem)) {
            return true;
        }
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (menuItem.getItemId() != 16908332 || bVar == null || (bVar.C() & 4) == 0) {
            return false;
        }
        MainActivity mainActivity = (MainActivity) this;
        AbstractComponentCallbacksC0141w E2 = ((C0143y) mainActivity.f3496s.f283c).e.E(com.general.melcan.fizorysam.R.id.navHostFragment);
        N1.i.c(E2, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        if (((NavHostFragment) E2).O().n()) {
            return true;
        }
        Intent b3 = E.e.b(mainActivity);
        if (b3 == null) {
            return false;
        }
        if (!mainActivity.shouldUpRecreateTask(b3)) {
            mainActivity.navigateUpTo(b3);
            return true;
        }
        E.i iVar = new E.i(mainActivity);
        Intent b4 = E.e.b(mainActivity);
        if (b4 == null) {
            b4 = E.e.b(mainActivity);
        }
        if (b4 != null) {
            ComponentName component = b4.getComponent();
            if (component == null) {
                component = b4.resolveActivity(iVar.f437c.getPackageManager());
            }
            iVar.a(component);
            iVar.f436b.add(b4);
        }
        iVar.b();
        try {
            mainActivity.finishAffinity();
            return true;
        } catch (IllegalStateException unused) {
            mainActivity.finish();
            return true;
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.f3499v = false;
        ((C0143y) this.f3496s.f283c).e.u(5);
        this.f3497t.d(EnumC0103m.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((LayoutInflaterFactory2C0178C) l()).w();
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        q();
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (bVar != null) {
            bVar.j0(true);
        }
    }

    @Override // b.k, android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f3496s.B();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // android.app.Activity
    public final void onResume() {
        C.b bVar = this.f3496s;
        bVar.B();
        super.onResume();
        this.f3499v = true;
        ((C0143y) bVar.f283c).e.A(true);
    }

    @Override // android.app.Activity
    public final void onStart() {
        r();
        ((LayoutInflaterFactory2C0178C) l()).l(true, false);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f3496s.B();
    }

    @Override // android.app.Activity
    public final void onStop() {
        s();
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (bVar != null) {
            bVar.j0(false);
        }
    }

    @Override // android.app.Activity
    public final void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        l().k(charSequence);
    }

    @Override // android.app.Activity
    public final void openOptionsMenu() {
        LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
        layoutInflaterFactory2C0178C.A();
        g0.b bVar = layoutInflaterFactory2C0178C.f3381p;
        if (getWindow().hasFeature(0)) {
            if (bVar == null || !bVar.Y()) {
                super.openOptionsMenu();
            }
        }
    }

    public final boolean p(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 6) {
            return ((C0143y) this.f3496s.f283c).e.j();
        }
        return false;
    }

    public final void q() {
        super.onPostResume();
        this.f3497t.d(EnumC0103m.ON_RESUME);
        P p2 = ((C0143y) this.f3496s.f283c).e;
        p2.f2303H = false;
        p2.f2304I = false;
        p2.f2309O.f2347g = false;
        p2.u(7);
    }

    public final void r() {
        C.b bVar = this.f3496s;
        bVar.B();
        super.onStart();
        this.f3500w = false;
        boolean z2 = this.f3498u;
        C0143y c0143y = (C0143y) bVar.f283c;
        if (!z2) {
            this.f3498u = true;
            P p2 = c0143y.e;
            p2.f2303H = false;
            p2.f2304I = false;
            p2.f2309O.f2347g = false;
            p2.u(4);
        }
        c0143y.e.A(true);
        this.f3497t.d(EnumC0103m.ON_START);
        P p3 = c0143y.e;
        p3.f2303H = false;
        p3.f2304I = false;
        p3.f2309O.f2347g = false;
        p3.u(5);
    }

    public final void s() {
        C.b bVar;
        super.onStop();
        this.f3500w = true;
        do {
            bVar = this.f3496s;
        } while (n(((C0143y) bVar.f283c).e));
        P p2 = ((C0143y) bVar.f283c).e;
        p2.f2304I = true;
        p2.f2309O.f2347g = true;
        p2.u(4);
        this.f3497t.d(EnumC0103m.ON_STOP);
    }

    @Override // android.app.Activity
    public final void setContentView(int i) {
        m();
        l().h(i);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i) {
        super.setTheme(i);
        ((LayoutInflaterFactory2C0178C) l()).f3363U = i;
    }

    @Override // b.k, android.app.Activity
    public void setContentView(View view) {
        m();
        l().i(view);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View onCreateView = ((C0143y) this.f3496s.f283c).e.f2315f.onCreateView(null, str, context, attributeSet);
        return onCreateView == null ? super.onCreateView(str, context, attributeSet) : onCreateView;
    }

    @Override // android.app.Activity
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m();
        l().j(view, layoutParams);
    }
}
