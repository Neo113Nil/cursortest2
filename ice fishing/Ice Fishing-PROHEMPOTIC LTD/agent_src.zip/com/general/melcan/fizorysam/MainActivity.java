package com.general.melcan.fizorysam;

import A.i;
import C.b;
import H0.a;
import a.AbstractC0078a;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.navigation.fragment.NavHostFragment;
import b0.AbstractComponentCallbacksC0141w;
import b0.C0143y;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import h.AbstractActivityC0194i;
import h.C0185J;
import h.C0192g;
import h.C0193h;
import h.LayoutInflaterFactory2C0178C;
import h.O;
import i0.C0205D;
import i0.C0224i;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import l0.C0249a;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0194i {

    /* renamed from: y, reason: collision with root package name */
    public b f2637y;

    public MainActivity() {
        ((i) this.f2228f.f94d).M("androidx:appcompat", new C0192g(this));
        h(new C0193h(this));
    }

    @Override // h.AbstractActivityC0194i, b.k, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View inflate = getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
        int i = R.id.appBarLayout;
        if (((AppBarLayout) AbstractC0078a.C(inflate, R.id.appBarLayout)) != null) {
            i = R.id.navHostFragment;
            if (((FragmentContainerView) AbstractC0078a.C(inflate, R.id.navHostFragment)) != null) {
                MaterialToolbar materialToolbar = (MaterialToolbar) AbstractC0078a.C(inflate, R.id.toolbar);
                if (materialToolbar != null) {
                    CoordinatorLayout coordinatorLayout = (CoordinatorLayout) inflate;
                    this.f2637y = new b(coordinatorLayout, materialToolbar);
                    setContentView(coordinatorLayout);
                    b bVar = this.f2637y;
                    if (bVar == null) {
                        N1.i.g("binding");
                        throw null;
                    }
                    LayoutInflaterFactory2C0178C layoutInflaterFactory2C0178C = (LayoutInflaterFactory2C0178C) l();
                    if (layoutInflaterFactory2C0178C.f3376k instanceof Activity) {
                        layoutInflaterFactory2C0178C.A();
                        g0.b bVar2 = layoutInflaterFactory2C0178C.f3381p;
                        if (bVar2 instanceof O) {
                            throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
                        }
                        layoutInflaterFactory2C0178C.f3382q = null;
                        if (bVar2 != null) {
                            bVar2.T();
                        }
                        layoutInflaterFactory2C0178C.f3381p = null;
                        MaterialToolbar materialToolbar2 = (MaterialToolbar) bVar.f283c;
                        Object obj = layoutInflaterFactory2C0178C.f3376k;
                        C0185J c0185j = new C0185J(materialToolbar2, obj instanceof Activity ? ((Activity) obj).getTitle() : layoutInflaterFactory2C0178C.f3383r, layoutInflaterFactory2C0178C.f3379n);
                        layoutInflaterFactory2C0178C.f3381p = c0185j;
                        layoutInflaterFactory2C0178C.f3379n.f3522c = c0185j.f3407c;
                        materialToolbar2.setBackInvokedCallbackEnabled(true);
                        layoutInflaterFactory2C0178C.b();
                    }
                    AbstractComponentCallbacksC0141w E2 = ((C0143y) this.f3496s.f283c).e.E(R.id.navHostFragment);
                    N1.i.c(E2, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
                    C0205D O2 = ((NavHostFragment) E2).O();
                    Set singleton = Collections.singleton(Integer.valueOf(R.id.signalDeckFragment));
                    N1.i.d(singleton, "singleton(...)");
                    HashSet hashSet = new HashSet();
                    hashSet.addAll(singleton);
                    b bVar3 = new b(hashSet, new a());
                    b bVar4 = this.f2637y;
                    if (bVar4 == null) {
                        N1.i.g("binding");
                        throw null;
                    }
                    MaterialToolbar materialToolbar3 = (MaterialToolbar) bVar4.f283c;
                    N1.i.e(O2, "navController");
                    C0249a c0249a = new C0249a(materialToolbar3, bVar3);
                    O2.f3557p.add(c0249a);
                    A1.i iVar = O2.f3549g;
                    if (!iVar.isEmpty()) {
                        C0224i c0224i = (C0224i) iVar.g();
                        c0249a.a(O2, c0224i.f3646c, c0224i.d());
                    }
                    materialToolbar3.setNavigationOnClickListener(new V0.a(O2, bVar3));
                    return;
                }
                i = R.id.toolbar;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }
}
