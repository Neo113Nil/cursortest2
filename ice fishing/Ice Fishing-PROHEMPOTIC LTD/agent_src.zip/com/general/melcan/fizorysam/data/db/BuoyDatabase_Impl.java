package com.general.melcan.fizorysam.data.db;

import A1.u;
import I0.f;
import I0.h;
import I0.m;
import M1.a;
import N1.e;
import N1.o;
import X.g;
import com.general.melcan.fizorysam.data.db.BuoyDatabase_Impl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import p0.C0377i;
import z1.C0519i;

/* loaded from: classes.dex */
public final class BuoyDatabase_Impl extends BuoyDatabase {

    /* renamed from: k, reason: collision with root package name */
    public final C0519i f2638k;

    /* renamed from: l, reason: collision with root package name */
    public final C0519i f2639l;

    public BuoyDatabase_Impl() {
        final int i = 0;
        this.f2638k = new C0519i(new a(this) { // from class: I0.g

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ BuoyDatabase_Impl f616c;

            {
                this.f616c = this;
            }

            @Override // M1.a
            public final Object a() {
                switch (i) {
                    case 0:
                        return new f(this.f616c);
                    default:
                        return new m(this.f616c);
                }
            }
        });
        final int i2 = 1;
        this.f2639l = new C0519i(new a(this) { // from class: I0.g

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ BuoyDatabase_Impl f616c;

            {
                this.f616c = this;
            }

            @Override // M1.a
            public final Object a() {
                switch (i2) {
                    case 0:
                        return new f(this.f616c);
                    default:
                        return new m(this.f616c);
                }
            }
        });
    }

    @Override // p0.AbstractC0368A
    public final List a(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // p0.AbstractC0368A
    public final C0377i b() {
        return new C0377i(this, new LinkedHashMap(), new LinkedHashMap(), "buoys", "watch_score");
    }

    @Override // p0.AbstractC0368A
    public final g c() {
        return new h(this);
    }

    @Override // p0.AbstractC0368A
    public final Set e() {
        return new LinkedHashSet();
    }

    @Override // p0.AbstractC0368A
    public final LinkedHashMap f() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        e a3 = o.a(f.class);
        u uVar = u.f236b;
        linkedHashMap.put(a3, uVar);
        linkedHashMap.put(o.a(m.class), uVar);
        return linkedHashMap;
    }

    @Override // com.general.melcan.fizorysam.data.db.BuoyDatabase
    public final f j() {
        return (f) this.f2638k.getValue();
    }

    @Override // com.general.melcan.fizorysam.data.db.BuoyDatabase
    public final m k() {
        return (m) this.f2639l.getValue();
    }
}
