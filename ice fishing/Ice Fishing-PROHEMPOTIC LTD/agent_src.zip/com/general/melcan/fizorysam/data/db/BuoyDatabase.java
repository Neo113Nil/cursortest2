package com.general.melcan.fizorysam.data.db;

import I0.f;
import I0.m;
import p0.AbstractC0368A;

/* loaded from: classes.dex */
public abstract class BuoyDatabase extends AbstractC0368A {
    public abstract f j();

    public abstract m k();
}
