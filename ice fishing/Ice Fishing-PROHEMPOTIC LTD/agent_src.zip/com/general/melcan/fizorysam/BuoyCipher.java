package com.general.melcan.fizorysam;

import I0.a;
import L0.b;
import N1.e;
import N1.i;
import N1.o;
import U1.h;
import W1.AbstractC0057t;
import W1.AbstractC0062y;
import W1.C0058u;
import W1.E;
import W1.F;
import W1.Q;
import W1.S;
import W1.Y;
import W1.o0;
import X.g;
import a.AbstractC0078a;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import com.general.melcan.fizorysam.data.db.BuoyDatabase;
import h.ExecutorC0199n;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import m0.d;
import o.C0330a;
import p0.AbstractC0368A;
import p0.C0369a;
import p0.C0377i;
import p0.C0382n;
import p0.H;
import p0.InterfaceC0370b;
import p0.x;
import p0.y;
import p0.z;
import t0.AbstractC0421a;
import t0.AbstractC0422b;
import y0.InterfaceC0505b;
import z1.C0514d;

/* loaded from: classes.dex */
public class BuoyCipher extends Application {

    /* renamed from: b, reason: collision with root package name */
    public b f2636b;

    public final b a() {
        b bVar = this.f2636b;
        if (bVar != null) {
            return bVar;
        }
        i.g("container");
        throw null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:71:0x01ec, code lost:
    
        throw new java.lang.IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.");
     */
    /* JADX WARN: Removed duplicated region for block: B:129:0x03a9  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x03c9  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0458  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x0542  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x025a A[LOOP:5: B:79:0x022b->B:91:0x025a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:92:0x026e A[SYNTHETIC] */
    @Override // android.app.Application
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate() {
        String str;
        g gVar;
        InterfaceC0505b interfaceC0505b;
        x xVar;
        InterfaceC0505b interfaceC0505b2;
        Intent intent;
        List list;
        Executor e;
        D1.i iVar;
        super.onCreate();
        b bVar = new b();
        Context applicationContext = getApplicationContext();
        bVar.f728a = applicationContext;
        bVar.f729b = AbstractC0062y.a(AbstractC0078a.P(AbstractC0062y.b(), F.f1304a));
        i.d(applicationContext, "appContext");
        if (h.p0("buoy_cipher.db")) {
            throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        z zVar = new z(0);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        ArrayList arrayList3 = new ArrayList();
        e a3 = o.a(BuoyDatabase.class);
        d dVar = C0330a.f4439c;
        if (!linkedHashSet2.isEmpty()) {
            Iterator it = linkedHashSet2.iterator();
            while (it.hasNext()) {
                int intValue = ((Number) it.next()).intValue();
                if (linkedHashSet.contains(Integer.valueOf(intValue))) {
                    throw new IllegalArgumentException(H.e.f("Inconsistency detected. A Migration was supplied to addMigration() that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(). Start version is: ", intValue).toString());
                }
            }
        }
        H h2 = new H();
        Object systemService = applicationContext.getSystemService("activity");
        ActivityManager activityManager = systemService instanceof ActivityManager ? (ActivityManager) systemService : null;
        C0369a c0369a = new C0369a(applicationContext, "buoy_cipher.db", h2, zVar, arrayList, false, (activityManager == null || activityManager.isLowRamDevice()) ? y.f4986b : y.f4987c, dVar, dVar, null, true, false, linkedHashSet, null, null, null, arrayList2, arrayList3, false, null, null);
        Class F = AbstractC0078a.F(a3);
        Package r5 = F.getPackage();
        if (r5 == null || (str = r5.getName()) == null) {
            str = "";
        }
        String canonicalName = F.getCanonicalName();
        i.b(canonicalName);
        if (str.length() != 0) {
            canonicalName = canonicalName.substring(str.length() + 1);
            i.d(canonicalName, "substring(...)");
        }
        String replace = canonicalName.replace('.', '_');
        i.d(replace, "replace(...)");
        String concat = replace.concat("_Impl");
        try {
            Class<?> cls = Class.forName(str.length() == 0 ? concat : str + '.' + concat, true, F.getClassLoader());
            i.c(cls, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.util.KClassUtil.findAndInstantiateDatabaseImpl>");
            AbstractC0368A abstractC0368A = (AbstractC0368A) cls.getDeclaredConstructor(null).newInstance(null);
            abstractC0368A.getClass();
            abstractC0368A.f4834j = true;
            try {
                gVar = abstractC0368A.c();
                i.c(gVar, "null cannot be cast to non-null type androidx.room.RoomOpenDelegate");
            } catch (C0514d unused) {
                gVar = null;
            }
            if (gVar == null) {
                new x(c0369a, new a(abstractC0368A));
                throw null;
            }
            abstractC0368A.e = new x(c0369a, gVar);
            abstractC0368A.f4831f = abstractC0368A.b();
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Set<S1.b> e3 = abstractC0368A.e();
            List list2 = c0369a.f4927r;
            int size = list2.size();
            boolean[] zArr = new boolean[size];
            for (S1.b bVar2 : e3) {
                int size2 = list2.size() - 1;
                if (size2 >= 0) {
                    while (true) {
                        int i = size2 - 1;
                        if (((e) bVar2).c(list2.get(size2))) {
                            zArr[size2] = true;
                            break;
                        } else if (i < 0) {
                            break;
                        } else {
                            size2 = i;
                        }
                    }
                }
                size2 = -1;
                if (size2 < 0) {
                    throw new IllegalArgumentException(("A required auto migration spec (" + ((e) bVar2).b() + ") is missing in the database configuration.").toString());
                }
                linkedHashMap.put(bVar2, list2.get(size2));
            }
            int size3 = list2.size() - 1;
            if (size3 >= 0) {
                while (true) {
                    int i2 = size3 - 1;
                    if (size3 >= size || !zArr[size3]) {
                        break;
                    } else if (i2 < 0) {
                        break;
                    } else {
                        size3 = i2;
                    }
                }
            }
            Iterator it2 = abstractC0368A.a(linkedHashMap).iterator();
            if (it2.hasNext()) {
                it2.next().getClass();
                throw new ClassCastException();
            }
            LinkedHashMap f2 = abstractC0368A.f();
            List list3 = c0369a.f4926q;
            boolean[] zArr2 = new boolean[list3.size()];
            for (Map.Entry entry : f2.entrySet()) {
                S1.b bVar3 = (S1.b) entry.getKey();
                for (S1.b bVar4 : (List) entry.getValue()) {
                    int size4 = list3.size() - 1;
                    if (size4 >= 0) {
                        while (true) {
                            int i3 = size4 - 1;
                            if (((e) bVar4).c(list3.get(size4))) {
                                zArr2[size4] = true;
                                break;
                            } else if (i3 < 0) {
                                break;
                            } else {
                                size4 = i3;
                            }
                        }
                        if (size4 >= 0) {
                            throw new IllegalArgumentException(("A required type converter (" + ((e) bVar4).b() + ") for " + ((e) bVar3).b() + " is missing in the database configuration.").toString());
                        }
                        Object obj = list3.get(size4);
                        i.e(bVar4, "kclass");
                        i.e(obj, "converter");
                        abstractC0368A.i.put(bVar4, obj);
                    }
                    size4 = -1;
                    if (size4 >= 0) {
                    }
                }
            }
            int size5 = list3.size() - 1;
            if (size5 >= 0) {
                while (true) {
                    int i4 = size5 - 1;
                    if (!zArr2[size5]) {
                        throw new IllegalArgumentException("Unexpected type converter " + list3.get(size5) + ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                    }
                    if (i4 < 0) {
                        break;
                    } else {
                        size5 = i4;
                    }
                }
            }
            D1.i iVar2 = c0369a.f4930u;
            if (iVar2 != null) {
                D1.g D2 = iVar2.D(D1.e.f415b);
                i.c(D2, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
                AbstractC0057t abstractC0057t = (AbstractC0057t) D2;
                Q q2 = abstractC0057t instanceof Q ? (Q) abstractC0057t : null;
                if (q2 == null || (e = q2.L()) == null) {
                    e = new E(abstractC0057t);
                }
                abstractC0368A.f4829c = e;
                abstractC0368A.f4830d = new ExecutorC0199n(e);
                abstractC0368A.f4827a = AbstractC0062y.a(iVar2.j(new o0((Y) iVar2.D(C0058u.f1373c))));
                if (abstractC0368A.g()) {
                    b2.e eVar = abstractC0368A.f4827a;
                    if (eVar == null) {
                        i.g("coroutineScope");
                        throw null;
                    }
                    iVar = eVar.f2566b.j(abstractC0057t.K(1));
                } else {
                    b2.e eVar2 = abstractC0368A.f4827a;
                    if (eVar2 == null) {
                        i.g("coroutineScope");
                        throw null;
                    }
                    iVar = eVar2.f2566b;
                }
                abstractC0368A.f4828b = iVar;
            } else {
                abstractC0368A.f4829c = c0369a.f4918h;
                abstractC0368A.f4830d = new ExecutorC0199n(c0369a.i);
                Executor executor = abstractC0368A.f4829c;
                if (executor == null) {
                    i.g("internalQueryExecutor");
                    throw null;
                }
                E e4 = executor instanceof E ? (E) executor : null;
                b2.e a4 = AbstractC0062y.a(AbstractC0078a.P(e4 != null ? e4.f1303b : new S(executor), AbstractC0062y.b()));
                abstractC0368A.f4827a = a4;
                ExecutorC0199n executorC0199n = abstractC0368A.f4830d;
                if (executorC0199n == null) {
                    i.g("internalTransactionExecutor");
                    throw null;
                }
                abstractC0368A.f4828b = a4.f2566b.j(new S(executorC0199n));
            }
            x xVar2 = abstractC0368A.e;
            if (xVar2 == null) {
                i.g("connectionManager");
                throw null;
            }
            InterfaceC0505b c2 = xVar2.c();
            if (c2 != null) {
                interfaceC0505b = c2;
                while (!(interfaceC0505b instanceof AbstractC0422b)) {
                    if (interfaceC0505b instanceof InterfaceC0370b) {
                        interfaceC0505b = ((InterfaceC0370b) interfaceC0505b).a();
                    }
                }
                xVar = abstractC0368A.e;
                if (xVar != null) {
                    i.g("connectionManager");
                    throw null;
                }
                InterfaceC0505b c3 = xVar.c();
                if (c3 != null) {
                    interfaceC0505b2 = c3;
                    while (!(interfaceC0505b2 instanceof AbstractC0421a)) {
                        if (interfaceC0505b2 instanceof InterfaceC0370b) {
                            interfaceC0505b2 = ((InterfaceC0370b) interfaceC0505b2).a();
                        }
                    }
                    intent = c0369a.f4919j;
                    if (intent != null) {
                        String str2 = c0369a.f4913b;
                        if (str2 == null) {
                            throw new IllegalArgumentException("Required value was null.");
                        }
                        C0377i d3 = abstractC0368A.d();
                        Context context = c0369a.f4912a;
                        d3.f4945h = intent;
                        d3.i = new C0382n(context, str2, d3);
                    }
                    BuoyDatabase buoyDatabase = (BuoyDatabase) abstractC0368A;
                    A.i iVar3 = new A.i(buoyDatabase.j(), buoyDatabase.k());
                    bVar.f730c = iVar3;
                    bVar.f731d = new O0.a(iVar3);
                    bVar.e = new O0.a(iVar3);
                    bVar.f732f = new O0.a(iVar3);
                    bVar.f733g = new O0.a(iVar3);
                    bVar.f734h = new O0.a(iVar3);
                    bVar.i = new O0.a(iVar3);
                    bVar.f735j = new O0.a(iVar3);
                    bVar.f736k = new O0.a(iVar3);
                    bVar.f737l = new O0.a(iVar3);
                    Resources resources = ((Context) bVar.f728a).getResources();
                    i.d(resources, "getResources(...)");
                    String[] stringArray = resources.getStringArray(R.array.buoy_seed_rows);
                    i.d(stringArray, "getStringArray(...)");
                    ArrayList arrayList4 = new ArrayList(stringArray.length);
                    for (String str3 : stringArray) {
                        i.b(str3);
                        String valueOf = String.valueOf(new char[]{'|'}[0]);
                        h.r0(0);
                        int n02 = h.n0(0, str3, valueOf, false);
                        if (n02 != -1) {
                            ArrayList arrayList5 = new ArrayList(10);
                            int i5 = 0;
                            while (true) {
                                arrayList5.add(str3.subSequence(i5, n02).toString());
                                i5 = valueOf.length() + n02;
                                int n03 = h.n0(i5, str3, valueOf, false);
                                if (n03 == -1) {
                                    break;
                                } else {
                                    n02 = n03;
                                }
                            }
                            arrayList5.add(str3.subSequence(i5, str3.length()).toString());
                            list = arrayList5;
                        } else {
                            list = AbstractC0078a.M(str3.toString());
                        }
                        if (list.size() != 10) {
                            throw new IllegalArgumentException("Seed row must contain 10 fields");
                        }
                        arrayList4.add(new I0.i((String) list.get(0), (String) list.get(1), (String) list.get(2), (String) list.get(3), (String) list.get(4), (String) list.get(5), (String) list.get(6), (String) list.get(7), (String) list.get(8), Integer.parseInt((String) list.get(9)), false, false, 0L, ""));
                    }
                    AbstractC0062y.n((b2.e) bVar.f729b, F.f1305b, 0, new L0.a(bVar, arrayList4, null), 2);
                    this.f2636b = bVar;
                    return;
                }
                interfaceC0505b2 = null;
                intent = c0369a.f4919j;
                if (intent != null) {
                }
                BuoyDatabase buoyDatabase2 = (BuoyDatabase) abstractC0368A;
                A.i iVar32 = new A.i(buoyDatabase2.j(), buoyDatabase2.k());
                bVar.f730c = iVar32;
                bVar.f731d = new O0.a(iVar32);
                bVar.e = new O0.a(iVar32);
                bVar.f732f = new O0.a(iVar32);
                bVar.f733g = new O0.a(iVar32);
                bVar.f734h = new O0.a(iVar32);
                bVar.i = new O0.a(iVar32);
                bVar.f735j = new O0.a(iVar32);
                bVar.f736k = new O0.a(iVar32);
                bVar.f737l = new O0.a(iVar32);
                Resources resources2 = ((Context) bVar.f728a).getResources();
                i.d(resources2, "getResources(...)");
                String[] stringArray2 = resources2.getStringArray(R.array.buoy_seed_rows);
                i.d(stringArray2, "getStringArray(...)");
                ArrayList arrayList42 = new ArrayList(stringArray2.length);
                while (r6 < r5) {
                }
                AbstractC0062y.n((b2.e) bVar.f729b, F.f1305b, 0, new L0.a(bVar, arrayList42, null), 2);
                this.f2636b = bVar;
                return;
            }
            interfaceC0505b = null;
            xVar = abstractC0368A.e;
            if (xVar != null) {
            }
        } catch (ClassNotFoundException e5) {
            throw new RuntimeException("Cannot find implementation for " + F.getCanonicalName() + ". " + concat + " does not exist. Is Room annotation processor correctly configured?", e5);
        } catch (IllegalAccessException e6) {
            throw new RuntimeException("Cannot access the constructor " + F.getCanonicalName(), e6);
        } catch (InstantiationException e7) {
            throw new RuntimeException("Failed to create an instance of " + F.getCanonicalName(), e7);
        }
    }
}
