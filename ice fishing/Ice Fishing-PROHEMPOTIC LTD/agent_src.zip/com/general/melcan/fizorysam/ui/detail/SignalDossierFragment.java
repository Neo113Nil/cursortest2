package com.general.melcan.fizorysam.ui.detail;

import A1.C0000a;
import F1.f;
import K0.d;
import N1.i;
import N1.o;
import Q0.e;
import Q0.n;
import S0.g;
import S0.j;
import S0.k;
import S0.v;
import W1.AbstractC0062y;
import a.AbstractC0078a;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0141w;
import com.general.melcan.fizorysam.R;
import com.general.melcan.fizorysam.ui.detail.SignalDossierFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.datepicker.A;
import com.google.android.material.datepicker.C0156a;
import com.google.android.material.datepicker.C0157b;
import com.google.android.material.datepicker.x;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.snackbar.SnackbarContentLayout;
import com.google.android.material.textfield.TextInputEditText;
import u1.C0447a;
import z1.EnumC0513c;
import z1.InterfaceC0512b;

/* loaded from: classes.dex */
public final class SignalDossierFragment extends AbstractComponentCallbacksC0141w {

    /* renamed from: X, reason: collision with root package name */
    public d f2644X;

    /* renamed from: Y, reason: collision with root package name */
    public final f f2645Y = new f(o.a(k.class), 5, new j(this, 0));

    /* renamed from: Z, reason: collision with root package name */
    public final Z f2646Z;

    public SignalDossierFragment() {
        e eVar = new e(1, this);
        InterfaceC0512b q2 = C0447a.q(EnumC0513c.f5781b, new n(2, new j(this, 1)));
        this.f2646Z = new Z(o.a(v.class), new Q0.o(q2, 2), eVar, new Q0.o(q2, 3));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void F(View view) {
        i.e(view, "view");
        d O2 = O();
        final int i = 0;
        O2.f712t.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this) { // from class: S0.d

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ SignalDossierFragment f1052b;

            {
                this.f1052b = this;
            }

            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                switch (i) {
                    case 0:
                        N1.i.e(compoundButton, "<unused var>");
                        SignalDossierFragment signalDossierFragment = this.f1052b;
                        K0.d O3 = signalDossierFragment.O();
                        TransitionManager.beginDelayedTransition(O3.f706n, new AutoTransition());
                        v P2 = signalDossierFragment.P();
                        AbstractC0062y.n(T.h(P2), null, 0, new r(P2, z2, null), 3);
                        break;
                    default:
                        N1.i.e(compoundButton, "<unused var>");
                        SignalDossierFragment signalDossierFragment2 = this.f1052b;
                        K0.d O4 = signalDossierFragment2.O();
                        TransitionManager.beginDelayedTransition(O4.f706n, new AutoTransition());
                        v P3 = signalDossierFragment2.P();
                        AbstractC0062y.n(T.h(P3), null, 0, new p(P3, z2, null), 3);
                        break;
                }
            }
        });
        d O3 = O();
        final int i2 = 1;
        O3.f709q.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this) { // from class: S0.d

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ SignalDossierFragment f1052b;

            {
                this.f1052b = this;
            }

            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                switch (i2) {
                    case 0:
                        N1.i.e(compoundButton, "<unused var>");
                        SignalDossierFragment signalDossierFragment = this.f1052b;
                        K0.d O32 = signalDossierFragment.O();
                        TransitionManager.beginDelayedTransition(O32.f706n, new AutoTransition());
                        v P2 = signalDossierFragment.P();
                        AbstractC0062y.n(T.h(P2), null, 0, new r(P2, z2, null), 3);
                        break;
                    default:
                        N1.i.e(compoundButton, "<unused var>");
                        SignalDossierFragment signalDossierFragment2 = this.f1052b;
                        K0.d O4 = signalDossierFragment2.O();
                        TransitionManager.beginDelayedTransition(O4.f706n, new AutoTransition());
                        v P3 = signalDossierFragment2.P();
                        AbstractC0062y.n(T.h(P3), null, 0, new p(P3, z2, null), 3);
                        break;
                }
            }
        });
        O().f705m.addTextChangedListener(new g(this));
        d O4 = O();
        final int i3 = 0;
        O4.f697c.setOnClickListener(new View.OnClickListener(this) { // from class: S0.e

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDossierFragment f1054c;

            {
                this.f1054c = this;
            }

            /* JADX WARN: Code restructure failed: missing block: B:80:0x0174, code lost:
            
                if (r4.compareTo(r5) <= 0) goto L79;
             */
            @Override // android.view.View.OnClickListener
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final void onClick(View view2) {
                com.google.android.material.datepicker.q qVar;
                ViewGroup viewGroup;
                boolean z2 = false;
                switch (i3) {
                    case 0:
                        SignalDossierFragment signalDossierFragment = this.f1054c;
                        signalDossierFragment.getClass();
                        x xVar = new x();
                        C0156a c0156a = new C0156a();
                        c0156a.f2829a = C0156a.f2827f;
                        c0156a.f2830b = C0156a.f2828g;
                        c0156a.e = new com.google.android.material.datepicker.e(Long.MIN_VALUE);
                        C0157b a3 = c0156a.a();
                        if (a3.e == null) {
                            boolean isEmpty = xVar.a().isEmpty();
                            com.google.android.material.datepicker.q qVar2 = a3.f2834c;
                            com.google.android.material.datepicker.q qVar3 = a3.f2833b;
                            if (!isEmpty) {
                                qVar = com.google.android.material.datepicker.q.c(((Long) xVar.a().iterator().next()).longValue());
                                if (qVar.compareTo(qVar3) >= 0) {
                                    break;
                                }
                            }
                            com.google.android.material.datepicker.q qVar4 = new com.google.android.material.datepicker.q(A.d());
                            if (qVar4.compareTo(qVar3) >= 0 && qVar4.compareTo(qVar2) <= 0) {
                                qVar3 = qVar4;
                            }
                            qVar = qVar3;
                            a3.e = qVar;
                        }
                        com.google.android.material.datepicker.o oVar = new com.google.android.material.datepicker.o();
                        Bundle bundle = new Bundle();
                        bundle.putInt("OVERRIDE_THEME_RES_ID", 0);
                        bundle.putParcelable("DATE_SELECTOR_KEY", xVar);
                        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", a3);
                        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", null);
                        bundle.putInt("TITLE_TEXT_RES_ID_KEY", R.string.log_sighting_date);
                        bundle.putCharSequence("TITLE_TEXT_KEY", null);
                        bundle.putInt("INPUT_MODE_KEY", 0);
                        bundle.putInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        oVar.N(bundle);
                        oVar.f2891n0.add(new f(new C0000a(2, signalDossierFragment)));
                        oVar.R(signalDossierFragment.j(), "sighting-date-picker");
                        return;
                    case 1:
                        SignalDossierFragment signalDossierFragment2 = this.f1054c;
                        v P2 = signalDossierFragment2.P();
                        AbstractC0062y.n(T.h(P2), null, 0, new o(P2, null), 3);
                        View view3 = signalDossierFragment2.O().f695a;
                        int[] iArr = v1.j.f5415B;
                        CharSequence text = view3.getResources().getText(R.string.notes_saved);
                        ViewGroup viewGroup2 = null;
                        while (true) {
                            if (view3 instanceof CoordinatorLayout) {
                                viewGroup = (ViewGroup) view3;
                            } else {
                                if (view3 instanceof FrameLayout) {
                                    if (view3.getId() == 16908290) {
                                        viewGroup = (ViewGroup) view3;
                                    } else {
                                        viewGroup2 = (ViewGroup) view3;
                                    }
                                }
                                Object parent = view3.getParent();
                                view3 = parent instanceof View ? (View) parent : null;
                                if (view3 == null) {
                                    viewGroup = viewGroup2;
                                }
                            }
                        }
                        if (viewGroup == null) {
                            throw new IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.");
                        }
                        Context context = viewGroup.getContext();
                        LayoutInflater from = LayoutInflater.from(context);
                        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(v1.j.f5415B);
                        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
                        int resourceId2 = obtainStyledAttributes.getResourceId(1, -1);
                        obtainStyledAttributes.recycle();
                        SnackbarContentLayout snackbarContentLayout = (SnackbarContentLayout) from.inflate((resourceId == -1 || resourceId2 == -1) ? R.layout.design_layout_snackbar_include : R.layout.mtrl_layout_snackbar_include, viewGroup, false);
                        v1.j jVar = new v1.j(context, viewGroup, snackbarContentLayout, snackbarContentLayout);
                        ((SnackbarContentLayout) jVar.i.getChildAt(0)).getMessageView().setText(text);
                        jVar.f5405k = -1;
                        C.l l2 = C.l.l();
                        int i4 = jVar.f5405k;
                        if (i4 == -2) {
                            i4 = -2;
                        } else if (Build.VERSION.SDK_INT >= 29) {
                            i4 = jVar.f5416A.getRecommendedTimeoutMillis(i4, 3);
                        }
                        v1.f fVar = jVar.f5414t;
                        synchronized (l2.f303a) {
                            try {
                                if (l2.n(fVar)) {
                                    v1.l lVar = (v1.l) l2.f305c;
                                    lVar.f5419b = i4;
                                    ((Handler) l2.f304b).removeCallbacksAndMessages(lVar);
                                    l2.u((v1.l) l2.f305c);
                                    return;
                                }
                                v1.l lVar2 = (v1.l) l2.f306d;
                                if (lVar2 != null && lVar2.f5418a.get() == fVar) {
                                    z2 = true;
                                }
                                if (z2) {
                                    ((v1.l) l2.f306d).f5419b = i4;
                                } else {
                                    l2.f306d = new v1.l(i4, fVar);
                                }
                                v1.l lVar3 = (v1.l) l2.f305c;
                                if (lVar3 == null || !l2.b(lVar3, 4)) {
                                    l2.f305c = null;
                                    l2.w();
                                    return;
                                }
                                return;
                            } finally {
                            }
                        }
                    default:
                        g0.b.q(this.f1054c).n();
                        return;
                }
            }
        });
        d O5 = O();
        final int i4 = 1;
        O5.f708p.setOnClickListener(new View.OnClickListener(this) { // from class: S0.e

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDossierFragment f1054c;

            {
                this.f1054c = this;
            }

            /* JADX WARN: Code restructure failed: missing block: B:80:0x0174, code lost:
            
                if (r4.compareTo(r5) <= 0) goto L79;
             */
            @Override // android.view.View.OnClickListener
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final void onClick(View view2) {
                com.google.android.material.datepicker.q qVar;
                ViewGroup viewGroup;
                boolean z2 = false;
                switch (i4) {
                    case 0:
                        SignalDossierFragment signalDossierFragment = this.f1054c;
                        signalDossierFragment.getClass();
                        x xVar = new x();
                        C0156a c0156a = new C0156a();
                        c0156a.f2829a = C0156a.f2827f;
                        c0156a.f2830b = C0156a.f2828g;
                        c0156a.e = new com.google.android.material.datepicker.e(Long.MIN_VALUE);
                        C0157b a3 = c0156a.a();
                        if (a3.e == null) {
                            boolean isEmpty = xVar.a().isEmpty();
                            com.google.android.material.datepicker.q qVar2 = a3.f2834c;
                            com.google.android.material.datepicker.q qVar3 = a3.f2833b;
                            if (!isEmpty) {
                                qVar = com.google.android.material.datepicker.q.c(((Long) xVar.a().iterator().next()).longValue());
                                if (qVar.compareTo(qVar3) >= 0) {
                                    break;
                                }
                            }
                            com.google.android.material.datepicker.q qVar4 = new com.google.android.material.datepicker.q(A.d());
                            if (qVar4.compareTo(qVar3) >= 0 && qVar4.compareTo(qVar2) <= 0) {
                                qVar3 = qVar4;
                            }
                            qVar = qVar3;
                            a3.e = qVar;
                        }
                        com.google.android.material.datepicker.o oVar = new com.google.android.material.datepicker.o();
                        Bundle bundle = new Bundle();
                        bundle.putInt("OVERRIDE_THEME_RES_ID", 0);
                        bundle.putParcelable("DATE_SELECTOR_KEY", xVar);
                        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", a3);
                        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", null);
                        bundle.putInt("TITLE_TEXT_RES_ID_KEY", R.string.log_sighting_date);
                        bundle.putCharSequence("TITLE_TEXT_KEY", null);
                        bundle.putInt("INPUT_MODE_KEY", 0);
                        bundle.putInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        oVar.N(bundle);
                        oVar.f2891n0.add(new f(new C0000a(2, signalDossierFragment)));
                        oVar.R(signalDossierFragment.j(), "sighting-date-picker");
                        return;
                    case 1:
                        SignalDossierFragment signalDossierFragment2 = this.f1054c;
                        v P2 = signalDossierFragment2.P();
                        AbstractC0062y.n(T.h(P2), null, 0, new o(P2, null), 3);
                        View view3 = signalDossierFragment2.O().f695a;
                        int[] iArr = v1.j.f5415B;
                        CharSequence text = view3.getResources().getText(R.string.notes_saved);
                        ViewGroup viewGroup2 = null;
                        while (true) {
                            if (view3 instanceof CoordinatorLayout) {
                                viewGroup = (ViewGroup) view3;
                            } else {
                                if (view3 instanceof FrameLayout) {
                                    if (view3.getId() == 16908290) {
                                        viewGroup = (ViewGroup) view3;
                                    } else {
                                        viewGroup2 = (ViewGroup) view3;
                                    }
                                }
                                Object parent = view3.getParent();
                                view3 = parent instanceof View ? (View) parent : null;
                                if (view3 == null) {
                                    viewGroup = viewGroup2;
                                }
                            }
                        }
                        if (viewGroup == null) {
                            throw new IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.");
                        }
                        Context context = viewGroup.getContext();
                        LayoutInflater from = LayoutInflater.from(context);
                        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(v1.j.f5415B);
                        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
                        int resourceId2 = obtainStyledAttributes.getResourceId(1, -1);
                        obtainStyledAttributes.recycle();
                        SnackbarContentLayout snackbarContentLayout = (SnackbarContentLayout) from.inflate((resourceId == -1 || resourceId2 == -1) ? R.layout.design_layout_snackbar_include : R.layout.mtrl_layout_snackbar_include, viewGroup, false);
                        v1.j jVar = new v1.j(context, viewGroup, snackbarContentLayout, snackbarContentLayout);
                        ((SnackbarContentLayout) jVar.i.getChildAt(0)).getMessageView().setText(text);
                        jVar.f5405k = -1;
                        C.l l2 = C.l.l();
                        int i42 = jVar.f5405k;
                        if (i42 == -2) {
                            i42 = -2;
                        } else if (Build.VERSION.SDK_INT >= 29) {
                            i42 = jVar.f5416A.getRecommendedTimeoutMillis(i42, 3);
                        }
                        v1.f fVar = jVar.f5414t;
                        synchronized (l2.f303a) {
                            try {
                                if (l2.n(fVar)) {
                                    v1.l lVar = (v1.l) l2.f305c;
                                    lVar.f5419b = i42;
                                    ((Handler) l2.f304b).removeCallbacksAndMessages(lVar);
                                    l2.u((v1.l) l2.f305c);
                                    return;
                                }
                                v1.l lVar2 = (v1.l) l2.f306d;
                                if (lVar2 != null && lVar2.f5418a.get() == fVar) {
                                    z2 = true;
                                }
                                if (z2) {
                                    ((v1.l) l2.f306d).f5419b = i42;
                                } else {
                                    l2.f306d = new v1.l(i42, fVar);
                                }
                                v1.l lVar3 = (v1.l) l2.f305c;
                                if (lVar3 == null || !l2.b(lVar3, 4)) {
                                    l2.f305c = null;
                                    l2.w();
                                    return;
                                }
                                return;
                            } finally {
                            }
                        }
                    default:
                        g0.b.q(this.f1054c).n();
                        return;
                }
            }
        });
        d O6 = O();
        final int i5 = 2;
        O6.f707o.setOnClickListener(new View.OnClickListener(this) { // from class: S0.e

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDossierFragment f1054c;

            {
                this.f1054c = this;
            }

            /* JADX WARN: Code restructure failed: missing block: B:80:0x0174, code lost:
            
                if (r4.compareTo(r5) <= 0) goto L79;
             */
            @Override // android.view.View.OnClickListener
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final void onClick(View view2) {
                com.google.android.material.datepicker.q qVar;
                ViewGroup viewGroup;
                boolean z2 = false;
                switch (i5) {
                    case 0:
                        SignalDossierFragment signalDossierFragment = this.f1054c;
                        signalDossierFragment.getClass();
                        x xVar = new x();
                        C0156a c0156a = new C0156a();
                        c0156a.f2829a = C0156a.f2827f;
                        c0156a.f2830b = C0156a.f2828g;
                        c0156a.e = new com.google.android.material.datepicker.e(Long.MIN_VALUE);
                        C0157b a3 = c0156a.a();
                        if (a3.e == null) {
                            boolean isEmpty = xVar.a().isEmpty();
                            com.google.android.material.datepicker.q qVar2 = a3.f2834c;
                            com.google.android.material.datepicker.q qVar3 = a3.f2833b;
                            if (!isEmpty) {
                                qVar = com.google.android.material.datepicker.q.c(((Long) xVar.a().iterator().next()).longValue());
                                if (qVar.compareTo(qVar3) >= 0) {
                                    break;
                                }
                            }
                            com.google.android.material.datepicker.q qVar4 = new com.google.android.material.datepicker.q(A.d());
                            if (qVar4.compareTo(qVar3) >= 0 && qVar4.compareTo(qVar2) <= 0) {
                                qVar3 = qVar4;
                            }
                            qVar = qVar3;
                            a3.e = qVar;
                        }
                        com.google.android.material.datepicker.o oVar = new com.google.android.material.datepicker.o();
                        Bundle bundle = new Bundle();
                        bundle.putInt("OVERRIDE_THEME_RES_ID", 0);
                        bundle.putParcelable("DATE_SELECTOR_KEY", xVar);
                        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", a3);
                        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", null);
                        bundle.putInt("TITLE_TEXT_RES_ID_KEY", R.string.log_sighting_date);
                        bundle.putCharSequence("TITLE_TEXT_KEY", null);
                        bundle.putInt("INPUT_MODE_KEY", 0);
                        bundle.putInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_TEXT_KEY", null);
                        bundle.putInt("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", 0);
                        bundle.putCharSequence("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY", null);
                        oVar.N(bundle);
                        oVar.f2891n0.add(new f(new C0000a(2, signalDossierFragment)));
                        oVar.R(signalDossierFragment.j(), "sighting-date-picker");
                        return;
                    case 1:
                        SignalDossierFragment signalDossierFragment2 = this.f1054c;
                        v P2 = signalDossierFragment2.P();
                        AbstractC0062y.n(T.h(P2), null, 0, new o(P2, null), 3);
                        View view3 = signalDossierFragment2.O().f695a;
                        int[] iArr = v1.j.f5415B;
                        CharSequence text = view3.getResources().getText(R.string.notes_saved);
                        ViewGroup viewGroup2 = null;
                        while (true) {
                            if (view3 instanceof CoordinatorLayout) {
                                viewGroup = (ViewGroup) view3;
                            } else {
                                if (view3 instanceof FrameLayout) {
                                    if (view3.getId() == 16908290) {
                                        viewGroup = (ViewGroup) view3;
                                    } else {
                                        viewGroup2 = (ViewGroup) view3;
                                    }
                                }
                                Object parent = view3.getParent();
                                view3 = parent instanceof View ? (View) parent : null;
                                if (view3 == null) {
                                    viewGroup = viewGroup2;
                                }
                            }
                        }
                        if (viewGroup == null) {
                            throw new IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.");
                        }
                        Context context = viewGroup.getContext();
                        LayoutInflater from = LayoutInflater.from(context);
                        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(v1.j.f5415B);
                        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
                        int resourceId2 = obtainStyledAttributes.getResourceId(1, -1);
                        obtainStyledAttributes.recycle();
                        SnackbarContentLayout snackbarContentLayout = (SnackbarContentLayout) from.inflate((resourceId == -1 || resourceId2 == -1) ? R.layout.design_layout_snackbar_include : R.layout.mtrl_layout_snackbar_include, viewGroup, false);
                        v1.j jVar = new v1.j(context, viewGroup, snackbarContentLayout, snackbarContentLayout);
                        ((SnackbarContentLayout) jVar.i.getChildAt(0)).getMessageView().setText(text);
                        jVar.f5405k = -1;
                        C.l l2 = C.l.l();
                        int i42 = jVar.f5405k;
                        if (i42 == -2) {
                            i42 = -2;
                        } else if (Build.VERSION.SDK_INT >= 29) {
                            i42 = jVar.f5416A.getRecommendedTimeoutMillis(i42, 3);
                        }
                        v1.f fVar = jVar.f5414t;
                        synchronized (l2.f303a) {
                            try {
                                if (l2.n(fVar)) {
                                    v1.l lVar = (v1.l) l2.f305c;
                                    lVar.f5419b = i42;
                                    ((Handler) l2.f304b).removeCallbacksAndMessages(lVar);
                                    l2.u((v1.l) l2.f305c);
                                    return;
                                }
                                v1.l lVar2 = (v1.l) l2.f306d;
                                if (lVar2 != null && lVar2.f5418a.get() == fVar) {
                                    z2 = true;
                                }
                                if (z2) {
                                    ((v1.l) l2.f306d).f5419b = i42;
                                } else {
                                    l2.f306d = new v1.l(i42, fVar);
                                }
                                v1.l lVar3 = (v1.l) l2.f305c;
                                if (lVar3 == null || !l2.b(lVar3, 4)) {
                                    l2.f305c = null;
                                    l2.w();
                                    return;
                                }
                                return;
                            } finally {
                            }
                        }
                    default:
                        g0.b.q(this.f1054c).n();
                        return;
                }
            }
        });
        AbstractC0062y.n(T.f(n()), null, 0, new S0.i(this, null), 3);
    }

    public final d O() {
        d dVar = this.f2644X;
        if (dVar != null) {
            return dVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final v P() {
        return (v) this.f2646Z.getValue();
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_signal_dossier, viewGroup, false);
        int i = R.id.colourValue;
        TextView textView = (TextView) AbstractC0078a.C(inflate, R.id.colourValue);
        if (textView != null) {
            i = R.id.dateButton;
            MaterialButton materialButton = (MaterialButton) AbstractC0078a.C(inflate, R.id.dateButton);
            if (materialButton != null) {
                i = R.id.dossierScroll;
                NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0078a.C(inflate, R.id.dossierScroll);
                if (nestedScrollView != null) {
                    i = R.id.heroEmoji;
                    TextView textView2 = (TextView) AbstractC0078a.C(inflate, R.id.heroEmoji);
                    if (textView2 != null) {
                        i = R.id.heroTile;
                        FrameLayout frameLayout = (FrameLayout) AbstractC0078a.C(inflate, R.id.heroTile);
                        if (frameLayout != null) {
                            i = R.id.lightValue;
                            TextView textView3 = (TextView) AbstractC0078a.C(inflate, R.id.lightValue);
                            if (textView3 != null) {
                                i = R.id.loadingIndicator;
                                ProgressBar progressBar = (ProgressBar) AbstractC0078a.C(inflate, R.id.loadingIndicator);
                                if (progressBar != null) {
                                    i = R.id.markerFamily;
                                    TextView textView4 = (TextView) AbstractC0078a.C(inflate, R.id.markerFamily);
                                    if (textView4 != null) {
                                        i = R.id.markerName;
                                        TextView textView5 = (TextView) AbstractC0078a.C(inflate, R.id.markerName);
                                        if (textView5 != null) {
                                            i = R.id.meaningValue;
                                            TextView textView6 = (TextView) AbstractC0078a.C(inflate, R.id.meaningValue);
                                            if (textView6 != null) {
                                                i = R.id.missingState;
                                                LinearLayout linearLayout = (LinearLayout) AbstractC0078a.C(inflate, R.id.missingState);
                                                if (linearLayout != null) {
                                                    i = R.id.notesInput;
                                                    TextInputEditText textInputEditText = (TextInputEditText) AbstractC0078a.C(inflate, R.id.notesInput);
                                                    if (textInputEditText != null) {
                                                        i = R.id.recordCard;
                                                        MaterialCardView materialCardView = (MaterialCardView) AbstractC0078a.C(inflate, R.id.recordCard);
                                                        if (materialCardView != null) {
                                                            i = R.id.returnToAtlasButton;
                                                            MaterialButton materialButton2 = (MaterialButton) AbstractC0078a.C(inflate, R.id.returnToAtlasButton);
                                                            if (materialButton2 != null) {
                                                                i = R.id.saveNotesButton;
                                                                MaterialButton materialButton3 = (MaterialButton) AbstractC0078a.C(inflate, R.id.saveNotesButton);
                                                                if (materialButton3 != null) {
                                                                    i = R.id.seenSwitch;
                                                                    MaterialSwitch materialSwitch = (MaterialSwitch) AbstractC0078a.C(inflate, R.id.seenSwitch);
                                                                    if (materialSwitch != null) {
                                                                        i = R.id.shapeValue;
                                                                        TextView textView7 = (TextView) AbstractC0078a.C(inflate, R.id.shapeValue);
                                                                        if (textView7 != null) {
                                                                            i = R.id.sightingValue;
                                                                            TextView textView8 = (TextView) AbstractC0078a.C(inflate, R.id.sightingValue);
                                                                            if (textView8 != null) {
                                                                                i = R.id.starSwitch;
                                                                                MaterialSwitch materialSwitch2 = (MaterialSwitch) AbstractC0078a.C(inflate, R.id.starSwitch);
                                                                                if (materialSwitch2 != null) {
                                                                                    i = R.id.waterwayValue;
                                                                                    TextView textView9 = (TextView) AbstractC0078a.C(inflate, R.id.waterwayValue);
                                                                                    if (textView9 != null) {
                                                                                        this.f2644X = new d((FrameLayout) inflate, textView, materialButton, nestedScrollView, textView2, frameLayout, textView3, progressBar, textView4, textView5, textView6, linearLayout, textInputEditText, materialCardView, materialButton2, materialButton3, materialSwitch, textView7, textView8, materialSwitch2, textView9);
                                                                                        FrameLayout frameLayout2 = O().f695a;
                                                                                        i.d(frameLayout2, "getRoot(...)");
                                                                                        return frameLayout2;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void y() {
        this.f2488G = true;
        this.f2644X = null;
    }
}
