package com.general.melcan.fizorysam.ui.home;

import K0.c;
import N1.i;
import N1.o;
import P0.a;
import Q0.e;
import Q0.n;
import T0.g;
import W1.AbstractC0062y;
import Z1.L;
import a.AbstractC0078a;
import android.os.SystemClock;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0141w;
import com.general.melcan.fizorysam.R;
import com.general.melcan.fizorysam.ui.home.SignalDeckFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import i0.C0205D;
import i0.C0216a;
import u1.C0447a;
import z1.EnumC0513c;
import z1.InterfaceC0512b;

/* loaded from: classes.dex */
public final class SignalDeckFragment extends AbstractComponentCallbacksC0141w {

    /* renamed from: X, reason: collision with root package name */
    public c f2647X;

    /* renamed from: Y, reason: collision with root package name */
    public final a f2648Y = new a();

    /* renamed from: Z, reason: collision with root package name */
    public final Z f2649Z;

    public SignalDeckFragment() {
        e eVar = new e(2, this);
        InterfaceC0512b q2 = C0447a.q(EnumC0513c.f5781b, new n(4, new n(3, this)));
        this.f2649Z = new Z(o.a(g.class), new Q0.o(q2, 4), eVar, new Q0.o(q2, 5));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void F(View view) {
        i.e(view, "view");
        c O2 = O();
        final int i = 0;
        O2.f686d.setOnClickListener(new View.OnClickListener(this) { // from class: T0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDeckFragment f1096c;

            {
                this.f1096c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i) {
                    case 0:
                        SignalDeckFragment signalDeckFragment = this.f1096c;
                        K0.c O3 = signalDeckFragment.O();
                        TransitionManager.beginDelayedTransition(O3.e, new AutoTransition());
                        L l2 = ((g) signalDeckFragment.f2649Z.getValue()).f1108b;
                        l2.k(null, Integer.valueOf(((Number) l2.i()).intValue() + 7));
                        break;
                    case 1:
                        SignalDeckFragment signalDeckFragment2 = this.f1096c;
                        N0.a aVar = ((e) ((L) ((g) signalDeckFragment2.f2649Z.getValue()).f1109c.f1643b).i()).f1103b;
                        if (aVar != null) {
                            P0.a aVar2 = signalDeckFragment2.f2648Y;
                            aVar2.getClass();
                            long elapsedRealtime = SystemClock.elapsedRealtime();
                            if (elapsedRealtime - aVar2.f943a >= 600) {
                                aVar2.f943a = elapsedRealtime;
                                C0205D q2 = g0.b.q(signalDeckFragment2);
                                String str = aVar.f793a;
                                i.e(str, "buoyId");
                                q2.m(new d(str));
                                break;
                            }
                        }
                        break;
                    case 2:
                        SignalDeckFragment signalDeckFragment3 = this.f1096c;
                        P0.a aVar3 = signalDeckFragment3.f2648Y;
                        aVar3.getClass();
                        long elapsedRealtime2 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime2 - aVar3.f943a >= 600) {
                            aVar3.f943a = elapsedRealtime2;
                            g0.b.q(signalDeckFragment3).m(new C0216a(R.id.action_signalDeck_to_markerAtlas));
                            break;
                        }
                        break;
                    case 3:
                        SignalDeckFragment signalDeckFragment4 = this.f1096c;
                        P0.a aVar4 = signalDeckFragment4.f2648Y;
                        aVar4.getClass();
                        long elapsedRealtime3 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime3 - aVar4.f943a >= 600) {
                            aVar4.f943a = elapsedRealtime3;
                            g0.b.q(signalDeckFragment4).m(new C0216a(R.id.action_signalDeck_to_channelRush));
                            break;
                        }
                        break;
                    default:
                        SignalDeckFragment signalDeckFragment5 = this.f1096c;
                        P0.a aVar5 = signalDeckFragment5.f2648Y;
                        aVar5.getClass();
                        long elapsedRealtime4 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime4 - aVar5.f943a >= 600) {
                            aVar5.f943a = elapsedRealtime4;
                            g0.b.q(signalDeckFragment5).m(new C0216a(R.id.action_signalDeck_to_watchkeeperLog));
                            break;
                        }
                        break;
                }
            }
        });
        c O3 = O();
        final int i2 = 1;
        O3.f693m.setOnClickListener(new View.OnClickListener(this) { // from class: T0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDeckFragment f1096c;

            {
                this.f1096c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i2) {
                    case 0:
                        SignalDeckFragment signalDeckFragment = this.f1096c;
                        K0.c O32 = signalDeckFragment.O();
                        TransitionManager.beginDelayedTransition(O32.e, new AutoTransition());
                        L l2 = ((g) signalDeckFragment.f2649Z.getValue()).f1108b;
                        l2.k(null, Integer.valueOf(((Number) l2.i()).intValue() + 7));
                        break;
                    case 1:
                        SignalDeckFragment signalDeckFragment2 = this.f1096c;
                        N0.a aVar = ((e) ((L) ((g) signalDeckFragment2.f2649Z.getValue()).f1109c.f1643b).i()).f1103b;
                        if (aVar != null) {
                            P0.a aVar2 = signalDeckFragment2.f2648Y;
                            aVar2.getClass();
                            long elapsedRealtime = SystemClock.elapsedRealtime();
                            if (elapsedRealtime - aVar2.f943a >= 600) {
                                aVar2.f943a = elapsedRealtime;
                                C0205D q2 = g0.b.q(signalDeckFragment2);
                                String str = aVar.f793a;
                                i.e(str, "buoyId");
                                q2.m(new d(str));
                                break;
                            }
                        }
                        break;
                    case 2:
                        SignalDeckFragment signalDeckFragment3 = this.f1096c;
                        P0.a aVar3 = signalDeckFragment3.f2648Y;
                        aVar3.getClass();
                        long elapsedRealtime2 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime2 - aVar3.f943a >= 600) {
                            aVar3.f943a = elapsedRealtime2;
                            g0.b.q(signalDeckFragment3).m(new C0216a(R.id.action_signalDeck_to_markerAtlas));
                            break;
                        }
                        break;
                    case 3:
                        SignalDeckFragment signalDeckFragment4 = this.f1096c;
                        P0.a aVar4 = signalDeckFragment4.f2648Y;
                        aVar4.getClass();
                        long elapsedRealtime3 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime3 - aVar4.f943a >= 600) {
                            aVar4.f943a = elapsedRealtime3;
                            g0.b.q(signalDeckFragment4).m(new C0216a(R.id.action_signalDeck_to_channelRush));
                            break;
                        }
                        break;
                    default:
                        SignalDeckFragment signalDeckFragment5 = this.f1096c;
                        P0.a aVar5 = signalDeckFragment5.f2648Y;
                        aVar5.getClass();
                        long elapsedRealtime4 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime4 - aVar5.f943a >= 600) {
                            aVar5.f943a = elapsedRealtime4;
                            g0.b.q(signalDeckFragment5).m(new C0216a(R.id.action_signalDeck_to_watchkeeperLog));
                            break;
                        }
                        break;
                }
            }
        });
        c O4 = O();
        final int i3 = 2;
        O4.f684b.setOnClickListener(new View.OnClickListener(this) { // from class: T0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDeckFragment f1096c;

            {
                this.f1096c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i3) {
                    case 0:
                        SignalDeckFragment signalDeckFragment = this.f1096c;
                        K0.c O32 = signalDeckFragment.O();
                        TransitionManager.beginDelayedTransition(O32.e, new AutoTransition());
                        L l2 = ((g) signalDeckFragment.f2649Z.getValue()).f1108b;
                        l2.k(null, Integer.valueOf(((Number) l2.i()).intValue() + 7));
                        break;
                    case 1:
                        SignalDeckFragment signalDeckFragment2 = this.f1096c;
                        N0.a aVar = ((e) ((L) ((g) signalDeckFragment2.f2649Z.getValue()).f1109c.f1643b).i()).f1103b;
                        if (aVar != null) {
                            P0.a aVar2 = signalDeckFragment2.f2648Y;
                            aVar2.getClass();
                            long elapsedRealtime = SystemClock.elapsedRealtime();
                            if (elapsedRealtime - aVar2.f943a >= 600) {
                                aVar2.f943a = elapsedRealtime;
                                C0205D q2 = g0.b.q(signalDeckFragment2);
                                String str = aVar.f793a;
                                i.e(str, "buoyId");
                                q2.m(new d(str));
                                break;
                            }
                        }
                        break;
                    case 2:
                        SignalDeckFragment signalDeckFragment3 = this.f1096c;
                        P0.a aVar3 = signalDeckFragment3.f2648Y;
                        aVar3.getClass();
                        long elapsedRealtime2 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime2 - aVar3.f943a >= 600) {
                            aVar3.f943a = elapsedRealtime2;
                            g0.b.q(signalDeckFragment3).m(new C0216a(R.id.action_signalDeck_to_markerAtlas));
                            break;
                        }
                        break;
                    case 3:
                        SignalDeckFragment signalDeckFragment4 = this.f1096c;
                        P0.a aVar4 = signalDeckFragment4.f2648Y;
                        aVar4.getClass();
                        long elapsedRealtime3 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime3 - aVar4.f943a >= 600) {
                            aVar4.f943a = elapsedRealtime3;
                            g0.b.q(signalDeckFragment4).m(new C0216a(R.id.action_signalDeck_to_channelRush));
                            break;
                        }
                        break;
                    default:
                        SignalDeckFragment signalDeckFragment5 = this.f1096c;
                        P0.a aVar5 = signalDeckFragment5.f2648Y;
                        aVar5.getClass();
                        long elapsedRealtime4 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime4 - aVar5.f943a >= 600) {
                            aVar5.f943a = elapsedRealtime4;
                            g0.b.q(signalDeckFragment5).m(new C0216a(R.id.action_signalDeck_to_watchkeeperLog));
                            break;
                        }
                        break;
                }
            }
        });
        c O5 = O();
        final int i4 = 3;
        O5.f694n.setOnClickListener(new View.OnClickListener(this) { // from class: T0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDeckFragment f1096c;

            {
                this.f1096c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i4) {
                    case 0:
                        SignalDeckFragment signalDeckFragment = this.f1096c;
                        K0.c O32 = signalDeckFragment.O();
                        TransitionManager.beginDelayedTransition(O32.e, new AutoTransition());
                        L l2 = ((g) signalDeckFragment.f2649Z.getValue()).f1108b;
                        l2.k(null, Integer.valueOf(((Number) l2.i()).intValue() + 7));
                        break;
                    case 1:
                        SignalDeckFragment signalDeckFragment2 = this.f1096c;
                        N0.a aVar = ((e) ((L) ((g) signalDeckFragment2.f2649Z.getValue()).f1109c.f1643b).i()).f1103b;
                        if (aVar != null) {
                            P0.a aVar2 = signalDeckFragment2.f2648Y;
                            aVar2.getClass();
                            long elapsedRealtime = SystemClock.elapsedRealtime();
                            if (elapsedRealtime - aVar2.f943a >= 600) {
                                aVar2.f943a = elapsedRealtime;
                                C0205D q2 = g0.b.q(signalDeckFragment2);
                                String str = aVar.f793a;
                                i.e(str, "buoyId");
                                q2.m(new d(str));
                                break;
                            }
                        }
                        break;
                    case 2:
                        SignalDeckFragment signalDeckFragment3 = this.f1096c;
                        P0.a aVar3 = signalDeckFragment3.f2648Y;
                        aVar3.getClass();
                        long elapsedRealtime2 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime2 - aVar3.f943a >= 600) {
                            aVar3.f943a = elapsedRealtime2;
                            g0.b.q(signalDeckFragment3).m(new C0216a(R.id.action_signalDeck_to_markerAtlas));
                            break;
                        }
                        break;
                    case 3:
                        SignalDeckFragment signalDeckFragment4 = this.f1096c;
                        P0.a aVar4 = signalDeckFragment4.f2648Y;
                        aVar4.getClass();
                        long elapsedRealtime3 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime3 - aVar4.f943a >= 600) {
                            aVar4.f943a = elapsedRealtime3;
                            g0.b.q(signalDeckFragment4).m(new C0216a(R.id.action_signalDeck_to_channelRush));
                            break;
                        }
                        break;
                    default:
                        SignalDeckFragment signalDeckFragment5 = this.f1096c;
                        P0.a aVar5 = signalDeckFragment5.f2648Y;
                        aVar5.getClass();
                        long elapsedRealtime4 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime4 - aVar5.f943a >= 600) {
                            aVar5.f943a = elapsedRealtime4;
                            g0.b.q(signalDeckFragment5).m(new C0216a(R.id.action_signalDeck_to_watchkeeperLog));
                            break;
                        }
                        break;
                }
            }
        });
        c O6 = O();
        final int i5 = 4;
        O6.f692l.setOnClickListener(new View.OnClickListener(this) { // from class: T0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ SignalDeckFragment f1096c;

            {
                this.f1096c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i5) {
                    case 0:
                        SignalDeckFragment signalDeckFragment = this.f1096c;
                        K0.c O32 = signalDeckFragment.O();
                        TransitionManager.beginDelayedTransition(O32.e, new AutoTransition());
                        L l2 = ((g) signalDeckFragment.f2649Z.getValue()).f1108b;
                        l2.k(null, Integer.valueOf(((Number) l2.i()).intValue() + 7));
                        break;
                    case 1:
                        SignalDeckFragment signalDeckFragment2 = this.f1096c;
                        N0.a aVar = ((e) ((L) ((g) signalDeckFragment2.f2649Z.getValue()).f1109c.f1643b).i()).f1103b;
                        if (aVar != null) {
                            P0.a aVar2 = signalDeckFragment2.f2648Y;
                            aVar2.getClass();
                            long elapsedRealtime = SystemClock.elapsedRealtime();
                            if (elapsedRealtime - aVar2.f943a >= 600) {
                                aVar2.f943a = elapsedRealtime;
                                C0205D q2 = g0.b.q(signalDeckFragment2);
                                String str = aVar.f793a;
                                i.e(str, "buoyId");
                                q2.m(new d(str));
                                break;
                            }
                        }
                        break;
                    case 2:
                        SignalDeckFragment signalDeckFragment3 = this.f1096c;
                        P0.a aVar3 = signalDeckFragment3.f2648Y;
                        aVar3.getClass();
                        long elapsedRealtime2 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime2 - aVar3.f943a >= 600) {
                            aVar3.f943a = elapsedRealtime2;
                            g0.b.q(signalDeckFragment3).m(new C0216a(R.id.action_signalDeck_to_markerAtlas));
                            break;
                        }
                        break;
                    case 3:
                        SignalDeckFragment signalDeckFragment4 = this.f1096c;
                        P0.a aVar4 = signalDeckFragment4.f2648Y;
                        aVar4.getClass();
                        long elapsedRealtime3 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime3 - aVar4.f943a >= 600) {
                            aVar4.f943a = elapsedRealtime3;
                            g0.b.q(signalDeckFragment4).m(new C0216a(R.id.action_signalDeck_to_channelRush));
                            break;
                        }
                        break;
                    default:
                        SignalDeckFragment signalDeckFragment5 = this.f1096c;
                        P0.a aVar5 = signalDeckFragment5.f2648Y;
                        aVar5.getClass();
                        long elapsedRealtime4 = SystemClock.elapsedRealtime();
                        if (elapsedRealtime4 - aVar5.f943a >= 600) {
                            aVar5.f943a = elapsedRealtime4;
                            g0.b.q(signalDeckFragment5).m(new C0216a(R.id.action_signalDeck_to_watchkeeperLog));
                            break;
                        }
                        break;
                }
            }
        });
        AbstractC0062y.n(T.f(n()), null, 0, new T0.c(this, null), 3);
    }

    public final c O() {
        c cVar = this.f2647X;
        if (cVar != null) {
            return cVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_signal_deck, viewGroup, false);
        int i = R.id.atlasCard;
        MaterialCardView materialCardView = (MaterialCardView) AbstractC0078a.C(inflate, R.id.atlasCard);
        if (materialCardView != null) {
            i = R.id.contentGroup;
            NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0078a.C(inflate, R.id.contentGroup);
            if (nestedScrollView != null) {
                i = R.id.drawAnotherButton;
                MaterialButton materialButton = (MaterialButton) AbstractC0078a.C(inflate, R.id.drawAnotherButton);
                if (materialButton != null) {
                    i = R.id.featuredCard;
                    MaterialCardView materialCardView2 = (MaterialCardView) AbstractC0078a.C(inflate, R.id.featuredCard);
                    if (materialCardView2 != null) {
                        i = R.id.featuredEmoji;
                        TextView textView = (TextView) AbstractC0078a.C(inflate, R.id.featuredEmoji);
                        if (textView != null) {
                            i = R.id.featuredFamily;
                            TextView textView2 = (TextView) AbstractC0078a.C(inflate, R.id.featuredFamily);
                            if (textView2 != null) {
                                i = R.id.featuredMeaning;
                                TextView textView3 = (TextView) AbstractC0078a.C(inflate, R.id.featuredMeaning);
                                if (textView3 != null) {
                                    i = R.id.featuredName;
                                    TextView textView4 = (TextView) AbstractC0078a.C(inflate, R.id.featuredName);
                                    if (textView4 != null) {
                                        i = R.id.featuredTile;
                                        FrameLayout frameLayout = (FrameLayout) AbstractC0078a.C(inflate, R.id.featuredTile);
                                        if (frameLayout != null) {
                                            i = R.id.loadingIndicator;
                                            ProgressBar progressBar = (ProgressBar) AbstractC0078a.C(inflate, R.id.loadingIndicator);
                                            if (progressBar != null) {
                                                i = R.id.logCard;
                                                MaterialCardView materialCardView3 = (MaterialCardView) AbstractC0078a.C(inflate, R.id.logCard);
                                                if (materialCardView3 != null) {
                                                    i = R.id.openFeaturedButton;
                                                    MaterialButton materialButton2 = (MaterialButton) AbstractC0078a.C(inflate, R.id.openFeaturedButton);
                                                    if (materialButton2 != null) {
                                                        i = R.id.rushCard;
                                                        MaterialCardView materialCardView4 = (MaterialCardView) AbstractC0078a.C(inflate, R.id.rushCard);
                                                        if (materialCardView4 != null) {
                                                            this.f2647X = new c((FrameLayout) inflate, materialCardView, nestedScrollView, materialButton, materialCardView2, textView, textView2, textView3, textView4, frameLayout, progressBar, materialCardView3, materialButton2, materialCardView4);
                                                            FrameLayout frameLayout2 = O().f683a;
                                                            i.d(frameLayout2, "getRoot(...)");
                                                            return frameLayout2;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void y() {
        this.f2488G = true;
        this.f2647X = null;
    }
}
