package com.general.melcan.fizorysam.ui.minigame;

import K0.a;
import N1.i;
import N1.o;
import Q0.e;
import Q0.n;
import U0.d;
import U0.l;
import U0.m;
import W1.AbstractC0062y;
import a.AbstractC0078a;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0141w;
import com.general.melcan.fizorysam.R;
import com.general.melcan.fizorysam.ui.minigame.ChannelRushFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import u1.C0447a;
import z1.EnumC0513c;
import z1.InterfaceC0512b;

/* loaded from: classes.dex */
public final class ChannelRushFragment extends AbstractComponentCallbacksC0141w {

    /* renamed from: X, reason: collision with root package name */
    public a f2650X;

    /* renamed from: Y, reason: collision with root package name */
    public m f2651Y;

    /* renamed from: Z, reason: collision with root package name */
    public String f2652Z;

    /* renamed from: a0, reason: collision with root package name */
    public int f2653a0 = Integer.MAX_VALUE;

    /* renamed from: b0, reason: collision with root package name */
    public final Z f2654b0;

    public ChannelRushFragment() {
        e eVar = new e(4, this);
        InterfaceC0512b q2 = C0447a.q(EnumC0513c.f5781b, new n(6, new n(5, this)));
        this.f2654b0 = new Z(o.a(l.class), new Q0.o(q2, 6), eVar, new Q0.o(q2, 7));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void F(View view) {
        i.e(view, "view");
        a O2 = O();
        final int i = 0;
        O2.f673r.setOnClickListener(new View.OnClickListener(this) { // from class: U0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ ChannelRushFragment f1128c;

            {
                this.f1128c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i) {
                    case 0:
                        this.f1128c.P().g();
                        break;
                    case 1:
                        this.f1128c.P().e(N0.b.f805b);
                        break;
                    case 2:
                        this.f1128c.P().e(N0.b.f806c);
                        break;
                    case 3:
                        this.f1128c.P().e(N0.b.f807d);
                        break;
                    default:
                        this.f1128c.P().g();
                        break;
                }
            }
        });
        a O3 = O();
        final int i2 = 1;
        O3.f671p.setOnClickListener(new View.OnClickListener(this) { // from class: U0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ ChannelRushFragment f1128c;

            {
                this.f1128c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i2) {
                    case 0:
                        this.f1128c.P().g();
                        break;
                    case 1:
                        this.f1128c.P().e(N0.b.f805b);
                        break;
                    case 2:
                        this.f1128c.P().e(N0.b.f806c);
                        break;
                    case 3:
                        this.f1128c.P().e(N0.b.f807d);
                        break;
                    default:
                        this.f1128c.P().g();
                        break;
                }
            }
        });
        a O4 = O();
        final int i3 = 2;
        O4.f665j.setOnClickListener(new View.OnClickListener(this) { // from class: U0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ ChannelRushFragment f1128c;

            {
                this.f1128c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i3) {
                    case 0:
                        this.f1128c.P().g();
                        break;
                    case 1:
                        this.f1128c.P().e(N0.b.f805b);
                        break;
                    case 2:
                        this.f1128c.P().e(N0.b.f806c);
                        break;
                    case 3:
                        this.f1128c.P().e(N0.b.f807d);
                        break;
                    default:
                        this.f1128c.P().g();
                        break;
                }
            }
        });
        a O5 = O();
        final int i4 = 3;
        O5.f672q.setOnClickListener(new View.OnClickListener(this) { // from class: U0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ ChannelRushFragment f1128c;

            {
                this.f1128c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i4) {
                    case 0:
                        this.f1128c.P().g();
                        break;
                    case 1:
                        this.f1128c.P().e(N0.b.f805b);
                        break;
                    case 2:
                        this.f1128c.P().e(N0.b.f806c);
                        break;
                    case 3:
                        this.f1128c.P().e(N0.b.f807d);
                        break;
                    default:
                        this.f1128c.P().g();
                        break;
                }
            }
        });
        a O6 = O();
        final int i5 = 4;
        O6.f670o.setOnClickListener(new View.OnClickListener(this) { // from class: U0.a

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ ChannelRushFragment f1128c;

            {
                this.f1128c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i5) {
                    case 0:
                        this.f1128c.P().g();
                        break;
                    case 1:
                        this.f1128c.P().e(N0.b.f805b);
                        break;
                    case 2:
                        this.f1128c.P().e(N0.b.f806c);
                        break;
                    case 3:
                        this.f1128c.P().e(N0.b.f807d);
                        break;
                    default:
                        this.f1128c.P().g();
                        break;
                }
            }
        });
        AbstractC0062y.n(T.f(n()), null, 0, new d(this, null), 3);
    }

    public final a O() {
        a aVar = this.f2650X;
        if (aVar != null) {
            return aVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final l P() {
        return (l) this.f2654b0.getValue();
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_channel_rush, viewGroup, false);
        int i = R.id.bestWatchValue;
        TextView textView = (TextView) AbstractC0078a.C(inflate, R.id.bestWatchValue);
        if (textView != null) {
            i = R.id.callFeedback;
            TextView textView2 = (TextView) AbstractC0078a.C(inflate, R.id.callFeedback);
            if (textView2 != null) {
                i = R.id.currentRunValue;
                TextView textView3 = (TextView) AbstractC0078a.C(inflate, R.id.currentRunValue);
                if (textView3 != null) {
                    i = R.id.finalScoreValue;
                    TextView textView4 = (TextView) AbstractC0078a.C(inflate, R.id.finalScoreValue);
                    if (textView4 != null) {
                        i = R.id.finishedState;
                        LinearLayout linearLayout = (LinearLayout) AbstractC0078a.C(inflate, R.id.finishedState);
                        if (linearLayout != null) {
                            i = R.id.gameEmoji;
                            TextView textView5 = (TextView) AbstractC0078a.C(inflate, R.id.gameEmoji);
                            if (textView5 != null) {
                                i = R.id.gameMarkerName;
                                TextView textView6 = (TextView) AbstractC0078a.C(inflate, R.id.gameMarkerName);
                                if (textView6 != null) {
                                    i = R.id.gameTile;
                                    FrameLayout frameLayout = (FrameLayout) AbstractC0078a.C(inflate, R.id.gameTile);
                                    if (frameLayout != null) {
                                        i = R.id.hazardButton;
                                        MaterialButton materialButton = (MaterialButton) AbstractC0078a.C(inflate, R.id.hazardButton);
                                        if (materialButton != null) {
                                            i = R.id.idleState;
                                            NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0078a.C(inflate, R.id.idleState);
                                            if (nestedScrollView != null) {
                                                i = R.id.markerPanel;
                                                LinearLayout linearLayout2 = (LinearLayout) AbstractC0078a.C(inflate, R.id.markerPanel);
                                                if (linearLayout2 != null) {
                                                    i = R.id.newRecordLabel;
                                                    TextView textView7 = (TextView) AbstractC0078a.C(inflate, R.id.newRecordLabel);
                                                    if (textView7 != null) {
                                                        i = R.id.playState;
                                                        NestedScrollView nestedScrollView2 = (NestedScrollView) AbstractC0078a.C(inflate, R.id.playState);
                                                        if (nestedScrollView2 != null) {
                                                            i = R.id.replayButton;
                                                            MaterialButton materialButton2 = (MaterialButton) AbstractC0078a.C(inflate, R.id.replayButton);
                                                            if (materialButton2 != null) {
                                                                i = R.id.routeButton;
                                                                MaterialButton materialButton3 = (MaterialButton) AbstractC0078a.C(inflate, R.id.routeButton);
                                                                if (materialButton3 != null) {
                                                                    i = R.id.specialButton;
                                                                    MaterialButton materialButton4 = (MaterialButton) AbstractC0078a.C(inflate, R.id.specialButton);
                                                                    if (materialButton4 != null) {
                                                                        i = R.id.startButton;
                                                                        MaterialButton materialButton5 = (MaterialButton) AbstractC0078a.C(inflate, R.id.startButton);
                                                                        if (materialButton5 != null) {
                                                                            i = R.id.timeValue;
                                                                            TextView textView8 = (TextView) AbstractC0078a.C(inflate, R.id.timeValue);
                                                                            if (textView8 != null) {
                                                                                i = R.id.timerProgress;
                                                                                LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) AbstractC0078a.C(inflate, R.id.timerProgress);
                                                                                if (linearProgressIndicator != null) {
                                                                                    this.f2650X = new a((FrameLayout) inflate, textView, textView2, textView3, textView4, linearLayout, textView5, textView6, frameLayout, materialButton, nestedScrollView, linearLayout2, textView7, nestedScrollView2, materialButton2, materialButton3, materialButton4, materialButton5, textView8, linearProgressIndicator);
                                                                                    FrameLayout frameLayout2 = O().f658a;
                                                                                    i.d(frameLayout2, "getRoot(...)");
                                                                                    return frameLayout2;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void y() {
        this.f2488G = true;
        this.f2650X = null;
    }
}
