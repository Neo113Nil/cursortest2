package com.general.melcan.fizorysam.ui.catalog;

import A1.m;
import K0.b;
import N1.i;
import N1.o;
import P0.a;
import Q0.c;
import Q0.e;
import Q0.g;
import Q0.j;
import Q0.n;
import Q0.t;
import W1.AbstractC0062y;
import Z1.L;
import a.AbstractC0078a;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b0.AbstractComponentCallbacksC0141w;
import com.general.melcan.fizorysam.R;
import com.general.melcan.fizorysam.ui.catalog.MarkerAtlasFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import java.util.List;
import u1.C0447a;
import z1.EnumC0513c;
import z1.InterfaceC0512b;

/* loaded from: classes.dex */
public final class MarkerAtlasFragment extends AbstractComponentCallbacksC0141w {

    /* renamed from: X, reason: collision with root package name */
    public b f2640X;

    /* renamed from: Y, reason: collision with root package name */
    public final a f2641Y = new a();

    /* renamed from: Z, reason: collision with root package name */
    public final c f2642Z = new c(new j(1, this, MarkerAtlasFragment.class, "openMarker", "openMarker(Lcom/general/melcan/fizorysam/domain/model/BuoyMarker;)V", 0, 0));

    /* renamed from: a0, reason: collision with root package name */
    public final Z f2643a0;

    public MarkerAtlasFragment() {
        e eVar = new e(0, this);
        InterfaceC0512b q2 = C0447a.q(EnumC0513c.f5781b, new n(1, new n(0, this)));
        this.f2643a0 = new Z(o.a(t.class), new Q0.o(q2, 0), eVar, new Q0.o(q2, 1));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void F(View view) {
        i.e(view, "view");
        List Y2 = m.Y(l(R.string.sort_name), l(R.string.sort_family), l(R.string.sort_urgency));
        b O2 = O();
        ((MaterialAutoCompleteTextView) O2.f681g).setAdapter(new ArrayAdapter(J(), android.R.layout.simple_list_item_1, Y2));
        b O3 = O();
        ((MaterialAutoCompleteTextView) O3.f681g).setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: Q0.f
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view2, int i, long j2) {
                MarkerAtlasFragment markerAtlasFragment = MarkerAtlasFragment.this;
                markerAtlasFragment.P();
                t tVar = (t) markerAtlasFragment.f2643a0.getValue();
                d dVar = (d) d.f973d.get(i);
                N1.i.e(dVar, "sort");
                L l2 = tVar.f1004b;
                l2.getClass();
                l2.k(null, dVar);
            }
        });
        b O4 = O();
        final int i = 0;
        ((MaterialSwitch) O4.f682h).setOnCheckedChangeListener(new g(i, this));
        b O5 = O();
        ((MaterialButton) O5.e).setOnClickListener(new View.OnClickListener(this) { // from class: Q0.h

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ MarkerAtlasFragment f980c;

            {
                this.f980c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i) {
                    case 0:
                        MarkerAtlasFragment markerAtlasFragment = this.f980c;
                        markerAtlasFragment.P();
                        t tVar = (t) markerAtlasFragment.f2643a0.getValue();
                        d dVar = d.f971b;
                        L l2 = tVar.f1004b;
                        l2.getClass();
                        l2.k(null, dVar);
                        Boolean bool = Boolean.FALSE;
                        L l3 = tVar.f1005c;
                        l3.getClass();
                        l3.k(null, bool);
                        break;
                    default:
                        MarkerAtlasFragment markerAtlasFragment2 = this.f980c;
                        markerAtlasFragment2.P();
                        t tVar2 = (t) markerAtlasFragment2.f2643a0.getValue();
                        d dVar2 = d.f971b;
                        L l4 = tVar2.f1004b;
                        l4.getClass();
                        l4.k(null, dVar2);
                        Boolean bool2 = Boolean.FALSE;
                        L l5 = tVar2.f1005c;
                        l5.getClass();
                        l5.k(null, bool2);
                        break;
                }
            }
        });
        b O6 = O();
        final int i2 = 1;
        ((MaterialButton) O6.f680f).setOnClickListener(new View.OnClickListener(this) { // from class: Q0.h

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ MarkerAtlasFragment f980c;

            {
                this.f980c = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                switch (i2) {
                    case 0:
                        MarkerAtlasFragment markerAtlasFragment = this.f980c;
                        markerAtlasFragment.P();
                        t tVar = (t) markerAtlasFragment.f2643a0.getValue();
                        d dVar = d.f971b;
                        L l2 = tVar.f1004b;
                        l2.getClass();
                        l2.k(null, dVar);
                        Boolean bool = Boolean.FALSE;
                        L l3 = tVar.f1005c;
                        l3.getClass();
                        l3.k(null, bool);
                        break;
                    default:
                        MarkerAtlasFragment markerAtlasFragment2 = this.f980c;
                        markerAtlasFragment2.P();
                        t tVar2 = (t) markerAtlasFragment2.f2643a0.getValue();
                        d dVar2 = d.f971b;
                        L l4 = tVar2.f1004b;
                        l4.getClass();
                        l4.k(null, dVar2);
                        Boolean bool2 = Boolean.FALSE;
                        L l5 = tVar2.f1005c;
                        l5.getClass();
                        l5.k(null, bool2);
                        break;
                }
            }
        });
        b O7 = O();
        J();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(1);
        RecyclerView recyclerView = (RecyclerView) O7.f679d;
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.f2642Z);
        recyclerView.setLayoutAnimation(AnimationUtils.loadLayoutAnimation(J(), R.anim.list_layout_controller));
        AbstractC0062y.n(T.f(n()), null, 0, new Q0.m(this, null), 3);
    }

    public final b O() {
        b bVar = this.f2640X;
        if (bVar != null) {
            return bVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final void P() {
        b O2 = O();
        TransitionManager.beginDelayedTransition((FrameLayout) O2.f676a, new AutoTransition());
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_marker_atlas, viewGroup, false);
        int i = R.id.emptyState;
        LinearLayout linearLayout = (LinearLayout) AbstractC0078a.C(inflate, R.id.emptyState);
        if (linearLayout != null) {
            i = R.id.loadingIndicator;
            ProgressBar progressBar = (ProgressBar) AbstractC0078a.C(inflate, R.id.loadingIndicator);
            if (progressBar != null) {
                i = R.id.markerList;
                RecyclerView recyclerView = (RecyclerView) AbstractC0078a.C(inflate, R.id.markerList);
                if (recyclerView != null) {
                    i = R.id.restoreButton;
                    MaterialButton materialButton = (MaterialButton) AbstractC0078a.C(inflate, R.id.restoreButton);
                    if (materialButton != null) {
                        i = R.id.showEveryButton;
                        MaterialButton materialButton2 = (MaterialButton) AbstractC0078a.C(inflate, R.id.showEveryButton);
                        if (materialButton2 != null) {
                            i = R.id.sortDropdown;
                            MaterialAutoCompleteTextView materialAutoCompleteTextView = (MaterialAutoCompleteTextView) AbstractC0078a.C(inflate, R.id.sortDropdown);
                            if (materialAutoCompleteTextView != null) {
                                i = R.id.starredSwitch;
                                MaterialSwitch materialSwitch = (MaterialSwitch) AbstractC0078a.C(inflate, R.id.starredSwitch);
                                if (materialSwitch != null) {
                                    this.f2640X = new b((FrameLayout) inflate, linearLayout, progressBar, recyclerView, materialButton, materialButton2, materialAutoCompleteTextView, materialSwitch);
                                    FrameLayout frameLayout = (FrameLayout) O().f676a;
                                    i.d(frameLayout, "getRoot(...)");
                                    return frameLayout;
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void y() {
        ((RecyclerView) O().f679d).setAdapter(null);
        this.f2488G = true;
        this.f2640X = null;
    }
}
