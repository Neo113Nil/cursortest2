package com.general.melcan.fizorysam.ui.profile;

import K0.e;
import N1.i;
import N1.o;
import Q0.n;
import V0.a;
import V0.d;
import V0.h;
import W1.AbstractC0062y;
import a.AbstractC0078a;
import android.animation.ValueAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0141w;
import com.general.melcan.fizorysam.R;
import com.google.android.material.button.MaterialButton;
import u1.C0447a;
import z1.EnumC0513c;
import z1.InterfaceC0512b;

/* loaded from: classes.dex */
public final class WatchkeeperLogFragment extends AbstractComponentCallbacksC0141w {

    /* renamed from: X, reason: collision with root package name */
    public e f2655X;

    /* renamed from: Y, reason: collision with root package name */
    public int f2656Y;

    /* renamed from: Z, reason: collision with root package name */
    public ValueAnimator f2657Z;

    /* renamed from: a0, reason: collision with root package name */
    public final Z f2658a0;

    public WatchkeeperLogFragment() {
        Q0.e eVar = new Q0.e(5, this);
        InterfaceC0512b q2 = C0447a.q(EnumC0513c.f5781b, new n(8, new n(7, this)));
        this.f2658a0 = new Z(o.a(h.class), new Q0.o(q2, 8), eVar, new Q0.o(q2, 9));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void F(View view) {
        i.e(view, "view");
        e O2 = O();
        ((MaterialButton) O2.f715b).setOnClickListener(new a(0, this));
        AbstractC0062y.n(T.f(n()), null, 0, new d(this, null), 3);
    }

    public final e O() {
        e eVar = this.f2655X;
        if (eVar != null) {
            return eVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_watchkeeper_log, viewGroup, false);
        int i = R.id.clearHistoryButton;
        MaterialButton materialButton = (MaterialButton) AbstractC0078a.C(inflate, R.id.clearHistoryButton);
        if (materialButton != null) {
            i = R.id.emptyState;
            LinearLayout linearLayout = (LinearLayout) AbstractC0078a.C(inflate, R.id.emptyState);
            if (linearLayout != null) {
                i = R.id.loadingIndicator;
                ProgressBar progressBar = (ProgressBar) AbstractC0078a.C(inflate, R.id.loadingIndicator);
                if (progressBar != null) {
                    i = R.id.populatedState;
                    LinearLayout linearLayout2 = (LinearLayout) AbstractC0078a.C(inflate, R.id.populatedState);
                    if (linearLayout2 != null) {
                        i = R.id.scoreValue;
                        TextView textView = (TextView) AbstractC0078a.C(inflate, R.id.scoreValue);
                        if (textView != null) {
                            this.f2655X = new e((FrameLayout) inflate, materialButton, linearLayout, progressBar, linearLayout2, textView);
                            FrameLayout frameLayout = (FrameLayout) O().f714a;
                            i.d(frameLayout, "getRoot(...)");
                            return frameLayout;
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(inflate.getResources().getResourceName(i)));
    }

    @Override // b0.AbstractComponentCallbacksC0141w
    public final void y() {
        ValueAnimator valueAnimator = this.f2657Z;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.f2488G = true;
        this.f2655X = null;
    }
}
