package com.pairip.application;

import android.content.Context;
import com.general.melcan.fizorysam.BuoyCipher;
import com.pairip.licensecheck.LicenseClient;

/* loaded from: classes.dex */
public class Application extends BuoyCipher {
    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        LicenseClient.checkLicense(context);
        super.attachBaseContext(context);
    }
}
