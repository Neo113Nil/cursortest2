package p0;

import android.os.IInterface;
import android.os.RemoteCallbackList;
import androidx.room.MultiInstanceInvalidationService;

/* renamed from: p0.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RemoteCallbackListC0384p extends RemoteCallbackList {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MultiInstanceInvalidationService f4965a;

    public RemoteCallbackListC0384p(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f4965a = multiInstanceInvalidationService;
    }

    @Override // android.os.RemoteCallbackList
    public final void onCallbackDied(IInterface iInterface, Object obj) {
        N1.i.e((InterfaceC0372d) iInterface, "callback");
        N1.i.e(obj, "cookie");
        this.f4965a.f2201c.remove((Integer) obj);
    }
}
