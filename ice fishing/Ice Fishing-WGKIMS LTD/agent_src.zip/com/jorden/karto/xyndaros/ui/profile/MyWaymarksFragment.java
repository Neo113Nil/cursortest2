package com.jorden.karto.xyndaros.ui.profile;

import A1.e;
import A1.k;
import C1.b;
import C1.c;
import D1.u;
import P1.l;
import Q1.i;
import Q1.p;
import R.a;
import Z1.AbstractC0063y;
import a.AbstractC0065a;
import android.content.DialogInterface;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b0.AbstractComponentCallbacksC0117w;
import c2.M;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.jorden.karto.xyndaros.R;
import com.jorden.karto.xyndaros.ui.profile.MyWaymarksFragment;
import h.C0189b;
import h.DialogInterfaceC0193f;
import h1.j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import q1.C0417c;
import w1.AbstractC0470b;
import z1.C0502d;
import z1.C0511m;
import z1.C0518t;
import z1.C0522x;

public final class MyWaymarksFragment extends AbstractComponentCallbacksC0117w {

    public j f3172X;

    public final Z f3173Y;

    public final C0502d f3174Z;

    public final C0502d f3175a0;

    public boolean f3176b0;

    public boolean f3177c0;

    public Object f3178d0;

    public MyWaymarksFragment() {
        e eVar = new e(11, this);
        b bVarN = AbstractC0065a.N(c.f293b, new A1.j(12, new A1.j(11, this)));
        this.f3173Y = new Z(p.a(C0518t.class), new k(bVarN, 8), eVar, new k(bVarN, 9));
        this.f3174Z = new C0502d(C0502d.f5932f, 0);
        this.f3175a0 = new C0502d(C0502d.f5933g, 1);
        this.f3178d0 = u.f429b;
    }

    @Override
    public final void E(View view) {
        i.e(view, "view");
        j jVarN = N();
        I();
        GridLayoutManager gridLayoutManager = new GridLayoutManager();
        RecyclerView recyclerView = (RecyclerView) jVarN.f3670c;
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(this.f3174Z);
        recyclerView.setNestedScrollingEnabled(false);
        j jVarN2 = N();
        I();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(1);
        RecyclerView recyclerView2 = (RecyclerView) jVarN2.f3677l;
        recyclerView2.setLayoutManager(linearLayoutManager);
        recyclerView2.setAdapter(this.f3175a0);
        recyclerView2.setNestedScrollingEnabled(false);
        recyclerView2.i(new C0522x(I()));
        final int i = 0;
        AbstractC0470b.a((MaterialButton) N().f3672f, new l(this) {

            public final MyWaymarksFragment f5935c;

            {
                this.f5935c = this;
            }

            @Override
            public final Object j(Object obj) {
                View view2 = (View) obj;
                switch (i) {
                    case 0:
                        Q1.i.e(view2, "it");
                        MyWaymarksFragment myWaymarksFragment = this.f5935c;
                        C0518t c0518tO = myWaymarksFragment.O();
                        Editable text = ((TextInputEditText) myWaymarksFragment.N().f3676k).getText();
                        String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        AbstractC0063y.m(T.h(c0518tO), null, 0, new C0515q(c0518tO, string, null), 3);
                        ((TextInputEditText) myWaymarksFragment.N().f3676k).clearFocus();
                        return C1.k.f305a;
                    case 1:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment2 = this.f5935c;
                        final List list = ((C0512n) ((M) myWaymarksFragment2.O().f5976f.f2719b).i()).f5958f;
                        if (!list.isEmpty()) {
                            final Q1.m mVar = new Q1.m();
                            mVar.f1072b = -1;
                            final Q1.o oVar = new Q1.o();
                            V0.b bVar = new V0.b(myWaymarksFragment2.I());
                            C0189b c0189b = (C0189b) bVar.f823c;
                            c0189b.f3546d = c0189b.f3543a.getText(R.string.profile_visit_dialog_title);
                            ArrayList arrayList = new ArrayList(D1.n.c0(list, 10));
                            Iterator it = list.iterator();
                            while (it.hasNext()) {
                                arrayList.add(((C0417c) it.next()).f5280b);
                            }
                            CharSequence[] charSequenceArr = (CharSequence[]) arrayList.toArray(new String[0]);
                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
                                @Override
                                public final void onClick(DialogInterface dialogInterface, int i2) {
                                    mVar.f1072b = i2;
                                    Object obj2 = oVar.f1074b;
                                    if (obj2 != null) {
                                        ((DialogInterfaceC0193f) obj2).f3586g.f3566g.setEnabled(true);
                                    } else {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                }
                            };
                            c0189b.f3551k = charSequenceArr;
                            c0189b.f3553m = onClickListener;
                            c0189b.f3555o = -1;
                            c0189b.f3554n = true;
                            c0189b.f3548g = c0189b.f3543a.getText(R.string.profile_stamp_confirm);
                            c0189b.f3549h = null;
                            c0189b.i = c0189b.f3543a.getText(R.string.profile_cancel);
                            DialogInterfaceC0193f dialogInterfaceC0193fA = bVar.a();
                            oVar.f1074b = dialogInterfaceC0193fA;
                            dialogInterfaceC0193fA.setOnShowListener(new DialogInterface.OnShowListener() {
                                @Override
                                public final void onShow(DialogInterface dialogInterface) {
                                    final Q1.o oVar2 = oVar;
                                    Object obj2 = oVar2.f1074b;
                                    if (obj2 == null) {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                    Button button = ((DialogInterfaceC0193f) obj2).f3586g.f3566g;
                                    button.setEnabled(false);
                                    final Q1.m mVar2 = mVar;
                                    final MyWaymarksFragment myWaymarksFragment3 = myWaymarksFragment2;
                                    final List list2 = list;
                                    button.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public final void onClick(View view3) {
                                            Q1.m mVar3 = mVar2;
                                            if (mVar3.f1072b != -1) {
                                                C0518t c0518tO2 = myWaymarksFragment3.O();
                                                String str = ((C0417c) list2.get(mVar3.f1072b)).f5279a;
                                                List list3 = ((C0512n) ((M) c0518tO2.f5976f.f2719b).i()).f5958f;
                                                if (list3 == null || !list3.isEmpty()) {
                                                    Iterator it2 = list3.iterator();
                                                    while (true) {
                                                        if (!it2.hasNext()) {
                                                            break;
                                                        } else if (((C0417c) it2.next()).f5279a.equals(str)) {
                                                            AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0516r(c0518tO2, str, null), 3);
                                                            break;
                                                        }
                                                    }
                                                }
                                                Object obj3 = oVar2.f1074b;
                                                if (obj3 != null) {
                                                    ((DialogInterfaceC0193f) obj3).dismiss();
                                                } else {
                                                    Q1.i.g("dialog");
                                                    throw null;
                                                }
                                            }
                                        }
                                    });
                                }
                            });
                            Object obj2 = oVar.f1074b;
                            if (obj2 == null) {
                                Q1.i.g("dialog");
                                throw null;
                            }
                            ((DialogInterfaceC0193f) obj2).show();
                        }
                        return C1.k.f305a;
                    default:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment3 = this.f5935c;
                        V0.b bVar2 = new V0.b(myWaymarksFragment3.I());
                        C0189b c0189b2 = (C0189b) bVar2.f823c;
                        c0189b2.f3546d = c0189b2.f3543a.getText(R.string.profile_reset_dialog_title);
                        c0189b2.f3547f = c0189b2.f3543a.getText(R.string.profile_reset_dialog_body);
                        ?? r2 = new DialogInterface.OnClickListener() {
                            @Override
                            public final void onClick(DialogInterface dialogInterface, int i2) {
                                MyWaymarksFragment myWaymarksFragment4 = myWaymarksFragment3;
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).clearFocus();
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).setText("");
                                C0518t c0518tO2 = myWaymarksFragment4.O();
                                AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0514p(c0518tO2, null), 3);
                            }
                        };
                        c0189b2.f3548g = c0189b2.f3543a.getText(R.string.profile_reset_confirm);
                        c0189b2.f3549h = r2;
                        c0189b2.i = c0189b2.f3543a.getText(R.string.profile_reset_cancel);
                        bVar2.a().show();
                        return C1.k.f305a;
                }
            }
        });
        j jVarN3 = N();
        ((ChipGroup) jVarN3.f3669b).setOnCheckedStateChangeListener(new a(this));
        final int i2 = 1;
        AbstractC0470b.a((MaterialButton) N().f3675j, new l(this) {

            public final MyWaymarksFragment f5935c;

            {
                this.f5935c = this;
            }

            @Override
            public final Object j(Object obj) {
                View view2 = (View) obj;
                switch (i2) {
                    case 0:
                        Q1.i.e(view2, "it");
                        MyWaymarksFragment myWaymarksFragment = this.f5935c;
                        C0518t c0518tO = myWaymarksFragment.O();
                        Editable text = ((TextInputEditText) myWaymarksFragment.N().f3676k).getText();
                        String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        AbstractC0063y.m(T.h(c0518tO), null, 0, new C0515q(c0518tO, string, null), 3);
                        ((TextInputEditText) myWaymarksFragment.N().f3676k).clearFocus();
                        return C1.k.f305a;
                    case 1:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment2 = this.f5935c;
                        final List list = ((C0512n) ((M) myWaymarksFragment2.O().f5976f.f2719b).i()).f5958f;
                        if (!list.isEmpty()) {
                            final Q1.m mVar = new Q1.m();
                            mVar.f1072b = -1;
                            final Q1.o oVar = new Q1.o();
                            V0.b bVar = new V0.b(myWaymarksFragment2.I());
                            C0189b c0189b = (C0189b) bVar.f823c;
                            c0189b.f3546d = c0189b.f3543a.getText(R.string.profile_visit_dialog_title);
                            ArrayList arrayList = new ArrayList(D1.n.c0(list, 10));
                            Iterator it = list.iterator();
                            while (it.hasNext()) {
                                arrayList.add(((C0417c) it.next()).f5280b);
                            }
                            CharSequence[] charSequenceArr = (CharSequence[]) arrayList.toArray(new String[0]);
                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
                                @Override
                                public final void onClick(DialogInterface dialogInterface, int i22) {
                                    mVar.f1072b = i22;
                                    Object obj2 = oVar.f1074b;
                                    if (obj2 != null) {
                                        ((DialogInterfaceC0193f) obj2).f3586g.f3566g.setEnabled(true);
                                    } else {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                }
                            };
                            c0189b.f3551k = charSequenceArr;
                            c0189b.f3553m = onClickListener;
                            c0189b.f3555o = -1;
                            c0189b.f3554n = true;
                            c0189b.f3548g = c0189b.f3543a.getText(R.string.profile_stamp_confirm);
                            c0189b.f3549h = null;
                            c0189b.i = c0189b.f3543a.getText(R.string.profile_cancel);
                            DialogInterfaceC0193f dialogInterfaceC0193fA = bVar.a();
                            oVar.f1074b = dialogInterfaceC0193fA;
                            dialogInterfaceC0193fA.setOnShowListener(new DialogInterface.OnShowListener() {
                                @Override
                                public final void onShow(DialogInterface dialogInterface) {
                                    final Q1.o oVar2 = oVar;
                                    Object obj2 = oVar2.f1074b;
                                    if (obj2 == null) {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                    Button button = ((DialogInterfaceC0193f) obj2).f3586g.f3566g;
                                    button.setEnabled(false);
                                    final Q1.m mVar2 = mVar;
                                    final MyWaymarksFragment myWaymarksFragment3 = myWaymarksFragment2;
                                    final List list2 = list;
                                    button.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public final void onClick(View view3) {
                                            Q1.m mVar3 = mVar2;
                                            if (mVar3.f1072b != -1) {
                                                C0518t c0518tO2 = myWaymarksFragment3.O();
                                                String str = ((C0417c) list2.get(mVar3.f1072b)).f5279a;
                                                List list3 = ((C0512n) ((M) c0518tO2.f5976f.f2719b).i()).f5958f;
                                                if (list3 == null || !list3.isEmpty()) {
                                                    Iterator it2 = list3.iterator();
                                                    while (true) {
                                                        if (!it2.hasNext()) {
                                                            break;
                                                        } else if (((C0417c) it2.next()).f5279a.equals(str)) {
                                                            AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0516r(c0518tO2, str, null), 3);
                                                            break;
                                                        }
                                                    }
                                                }
                                                Object obj3 = oVar2.f1074b;
                                                if (obj3 != null) {
                                                    ((DialogInterfaceC0193f) obj3).dismiss();
                                                } else {
                                                    Q1.i.g("dialog");
                                                    throw null;
                                                }
                                            }
                                        }
                                    });
                                }
                            });
                            Object obj2 = oVar.f1074b;
                            if (obj2 == null) {
                                Q1.i.g("dialog");
                                throw null;
                            }
                            ((DialogInterfaceC0193f) obj2).show();
                        }
                        return C1.k.f305a;
                    default:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment3 = this.f5935c;
                        V0.b bVar2 = new V0.b(myWaymarksFragment3.I());
                        C0189b c0189b2 = (C0189b) bVar2.f823c;
                        c0189b2.f3546d = c0189b2.f3543a.getText(R.string.profile_reset_dialog_title);
                        c0189b2.f3547f = c0189b2.f3543a.getText(R.string.profile_reset_dialog_body);
                        ?? r2 = new DialogInterface.OnClickListener() {
                            @Override
                            public final void onClick(DialogInterface dialogInterface, int i22) {
                                MyWaymarksFragment myWaymarksFragment4 = myWaymarksFragment3;
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).clearFocus();
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).setText("");
                                C0518t c0518tO2 = myWaymarksFragment4.O();
                                AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0514p(c0518tO2, null), 3);
                            }
                        };
                        c0189b2.f3548g = c0189b2.f3543a.getText(R.string.profile_reset_confirm);
                        c0189b2.f3549h = r2;
                        c0189b2.i = c0189b2.f3543a.getText(R.string.profile_reset_cancel);
                        bVar2.a().show();
                        return C1.k.f305a;
                }
            }
        });
        final int i3 = 2;
        AbstractC0470b.a((MaterialButton) N().f3671d, new l(this) {

            public final MyWaymarksFragment f5935c;

            {
                this.f5935c = this;
            }

            @Override
            public final Object j(Object obj) {
                View view2 = (View) obj;
                switch (i3) {
                    case 0:
                        Q1.i.e(view2, "it");
                        MyWaymarksFragment myWaymarksFragment = this.f5935c;
                        C0518t c0518tO = myWaymarksFragment.O();
                        Editable text = ((TextInputEditText) myWaymarksFragment.N().f3676k).getText();
                        String string = text != null ? text.toString() : null;
                        if (string == null) {
                            string = "";
                        }
                        AbstractC0063y.m(T.h(c0518tO), null, 0, new C0515q(c0518tO, string, null), 3);
                        ((TextInputEditText) myWaymarksFragment.N().f3676k).clearFocus();
                        return C1.k.f305a;
                    case 1:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment2 = this.f5935c;
                        final List list = ((C0512n) ((M) myWaymarksFragment2.O().f5976f.f2719b).i()).f5958f;
                        if (!list.isEmpty()) {
                            final Q1.m mVar = new Q1.m();
                            mVar.f1072b = -1;
                            final Q1.o oVar = new Q1.o();
                            V0.b bVar = new V0.b(myWaymarksFragment2.I());
                            C0189b c0189b = (C0189b) bVar.f823c;
                            c0189b.f3546d = c0189b.f3543a.getText(R.string.profile_visit_dialog_title);
                            ArrayList arrayList = new ArrayList(D1.n.c0(list, 10));
                            Iterator it = list.iterator();
                            while (it.hasNext()) {
                                arrayList.add(((C0417c) it.next()).f5280b);
                            }
                            CharSequence[] charSequenceArr = (CharSequence[]) arrayList.toArray(new String[0]);
                            DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
                                @Override
                                public final void onClick(DialogInterface dialogInterface, int i22) {
                                    mVar.f1072b = i22;
                                    Object obj2 = oVar.f1074b;
                                    if (obj2 != null) {
                                        ((DialogInterfaceC0193f) obj2).f3586g.f3566g.setEnabled(true);
                                    } else {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                }
                            };
                            c0189b.f3551k = charSequenceArr;
                            c0189b.f3553m = onClickListener;
                            c0189b.f3555o = -1;
                            c0189b.f3554n = true;
                            c0189b.f3548g = c0189b.f3543a.getText(R.string.profile_stamp_confirm);
                            c0189b.f3549h = null;
                            c0189b.i = c0189b.f3543a.getText(R.string.profile_cancel);
                            DialogInterfaceC0193f dialogInterfaceC0193fA = bVar.a();
                            oVar.f1074b = dialogInterfaceC0193fA;
                            dialogInterfaceC0193fA.setOnShowListener(new DialogInterface.OnShowListener() {
                                @Override
                                public final void onShow(DialogInterface dialogInterface) {
                                    final Q1.o oVar2 = oVar;
                                    Object obj2 = oVar2.f1074b;
                                    if (obj2 == null) {
                                        Q1.i.g("dialog");
                                        throw null;
                                    }
                                    Button button = ((DialogInterfaceC0193f) obj2).f3586g.f3566g;
                                    button.setEnabled(false);
                                    final Q1.m mVar2 = mVar;
                                    final MyWaymarksFragment myWaymarksFragment3 = myWaymarksFragment2;
                                    final List list2 = list;
                                    button.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public final void onClick(View view3) {
                                            Q1.m mVar3 = mVar2;
                                            if (mVar3.f1072b != -1) {
                                                C0518t c0518tO2 = myWaymarksFragment3.O();
                                                String str = ((C0417c) list2.get(mVar3.f1072b)).f5279a;
                                                List list3 = ((C0512n) ((M) c0518tO2.f5976f.f2719b).i()).f5958f;
                                                if (list3 == null || !list3.isEmpty()) {
                                                    Iterator it2 = list3.iterator();
                                                    while (true) {
                                                        if (!it2.hasNext()) {
                                                            break;
                                                        } else if (((C0417c) it2.next()).f5279a.equals(str)) {
                                                            AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0516r(c0518tO2, str, null), 3);
                                                            break;
                                                        }
                                                    }
                                                }
                                                Object obj3 = oVar2.f1074b;
                                                if (obj3 != null) {
                                                    ((DialogInterfaceC0193f) obj3).dismiss();
                                                } else {
                                                    Q1.i.g("dialog");
                                                    throw null;
                                                }
                                            }
                                        }
                                    });
                                }
                            });
                            Object obj2 = oVar.f1074b;
                            if (obj2 == null) {
                                Q1.i.g("dialog");
                                throw null;
                            }
                            ((DialogInterfaceC0193f) obj2).show();
                        }
                        return C1.k.f305a;
                    default:
                        Q1.i.e(view2, "it");
                        final MyWaymarksFragment myWaymarksFragment3 = this.f5935c;
                        V0.b bVar2 = new V0.b(myWaymarksFragment3.I());
                        C0189b c0189b2 = (C0189b) bVar2.f823c;
                        c0189b2.f3546d = c0189b2.f3543a.getText(R.string.profile_reset_dialog_title);
                        c0189b2.f3547f = c0189b2.f3543a.getText(R.string.profile_reset_dialog_body);
                        ?? r2 = new DialogInterface.OnClickListener() {
                            @Override
                            public final void onClick(DialogInterface dialogInterface, int i22) {
                                MyWaymarksFragment myWaymarksFragment4 = myWaymarksFragment3;
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).clearFocus();
                                ((TextInputEditText) myWaymarksFragment4.N().f3676k).setText("");
                                C0518t c0518tO2 = myWaymarksFragment4.O();
                                AbstractC0063y.m(T.h(c0518tO2), null, 0, new C0514p(c0518tO2, null), 3);
                            }
                        };
                        c0189b2.f3548g = c0189b2.f3543a.getText(R.string.profile_reset_confirm);
                        c0189b2.f3549h = r2;
                        c0189b2.i = c0189b2.f3543a.getText(R.string.profile_reset_cancel);
                        bVar2.a().show();
                        return C1.k.f305a;
                }
            }
        });
        AbstractC0063y.m(T.f(m()), null, 0, new C0511m(this, null), 3);
    }

    public final j N() {
        j jVar = this.f3172X;
        if (jVar != null) {
            return jVar;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final C0518t O() {
        return (C0518t) this.f3173Y.getValue();
    }

    @Override
    public final View w(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(R.layout.fragment_profile, viewGroup, false);
        int i = R.id.avatarHighWindow;
        if (((Chip) AbstractC0065a.E(viewInflate, R.id.avatarHighWindow)) != null) {
            i = R.id.avatarPicker;
            ChipGroup chipGroup = (ChipGroup) AbstractC0065a.E(viewInflate, R.id.avatarPicker);
            if (chipGroup != null) {
                i = R.id.avatarSeaArch;
                if (((Chip) AbstractC0065a.E(viewInflate, R.id.avatarSeaArch)) != null) {
                    i = R.id.avatarStoneKey;
                    if (((Chip) AbstractC0065a.E(viewInflate, R.id.avatarStoneKey)) != null) {
                        i = R.id.avatarSunGate;
                        if (((Chip) AbstractC0065a.E(viewInflate, R.id.avatarSunGate)) != null) {
                            i = R.id.badgeList;
                            RecyclerView recyclerView = (RecyclerView) AbstractC0065a.E(viewInflate, R.id.badgeList);
                            if (recyclerView != null) {
                                i = R.id.clearEveryWaymarkButton;
                                MaterialButton materialButton = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.clearEveryWaymarkButton);
                                if (materialButton != null) {
                                    i = R.id.emptyVisits;
                                    TextView textView = (TextView) AbstractC0065a.E(viewInflate, R.id.emptyVisits);
                                    if (textView != null) {
                                        i = R.id.keepTrailNameButton;
                                        MaterialButton materialButton2 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.keepTrailNameButton);
                                        if (materialButton2 != null) {
                                            i = R.id.loadingIndicator;
                                            CircularProgressIndicator circularProgressIndicator = (CircularProgressIndicator) AbstractC0065a.E(viewInflate, R.id.loadingIndicator);
                                            if (circularProgressIndicator != null) {
                                                i = R.id.profileContent;
                                                LinearLayout linearLayout = (LinearLayout) AbstractC0065a.E(viewInflate, R.id.profileContent);
                                                if (linearLayout != null) {
                                                    i = R.id.profileScroll;
                                                    NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0065a.E(viewInflate, R.id.profileScroll);
                                                    if (nestedScrollView != null) {
                                                        i = R.id.stampVisitButton;
                                                        MaterialButton materialButton3 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.stampVisitButton);
                                                        if (materialButton3 != null) {
                                                            i = R.id.trailNameInput;
                                                            TextInputEditText textInputEditText = (TextInputEditText) AbstractC0065a.E(viewInflate, R.id.trailNameInput);
                                                            if (textInputEditText != null) {
                                                                i = R.id.trailNameLayout;
                                                                if (((TextInputLayout) AbstractC0065a.E(viewInflate, R.id.trailNameLayout)) != null) {
                                                                    i = R.id.visitList;
                                                                    RecyclerView recyclerView2 = (RecyclerView) AbstractC0065a.E(viewInflate, R.id.visitList);
                                                                    if (recyclerView2 != null) {
                                                                        j jVar = new j();
                                                                        jVar.f3668a = (FrameLayout) viewInflate;
                                                                        jVar.f3669b = chipGroup;
                                                                        jVar.f3670c = recyclerView;
                                                                        jVar.f3671d = materialButton;
                                                                        jVar.e = textView;
                                                                        jVar.f3672f = materialButton2;
                                                                        jVar.f3673g = circularProgressIndicator;
                                                                        jVar.f3674h = linearLayout;
                                                                        jVar.i = nestedScrollView;
                                                                        jVar.f3675j = materialButton3;
                                                                        jVar.f3676k = textInputEditText;
                                                                        jVar.f3677l = recyclerView2;
                                                                        this.f3172X = jVar;
                                                                        FrameLayout frameLayout = (FrameLayout) N().f3668a;
                                                                        i.d(frameLayout, "getRoot(...)");
                                                                        return frameLayout;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override
    public final void x() {
        ((RecyclerView) N().f3670c).setAdapter(null);
        ((RecyclerView) N().f3677l).setAdapter(null);
        this.f3178d0 = u.f429b;
        this.f3172X = null;
        this.f2363G = true;
    }
}
