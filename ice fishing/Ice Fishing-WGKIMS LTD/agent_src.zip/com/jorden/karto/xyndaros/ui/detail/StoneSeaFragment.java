package com.jorden.karto.xyndaros.ui.detail;

import A1.e;
import A1.j;
import A1.k;
import C1.b;
import C1.c;
import I1.f;
import P1.l;
import Q1.p;
import Z1.AbstractC0063y;
import a.AbstractC0065a;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0117w;
import c2.M;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.jorden.karto.xyndaros.R;
import com.jorden.karto.xyndaros.ui.common.VillageMarkView;
import com.jorden.karto.xyndaros.ui.detail.StoneSeaFragment;
import q1.C0417c;
import q1.C0418d;
import s1.C0446b;
import w1.AbstractC0470b;
import x1.C0484c;
import x1.C0485d;
import x1.C0486e;
import x1.i;

public final class StoneSeaFragment extends AbstractComponentCallbacksC0117w {

    public C0446b f3164X;

    public final f f3165Y = new f(p.a(C0486e.class), 5, new C0485d(this, 0));

    public final Z f3166Z;

    public C0418d f3167a0;

    public StoneSeaFragment() {
        e eVar = new e(8, this);
        b bVarN = AbstractC0065a.N(c.f293b, new j(8, new C0485d(this, 1)));
        this.f3166Z = new Z(p.a(i.class), new k(bVarN, 4), eVar, new k(bVarN, 5));
    }

    @Override
    public final void E(View view) {
        Q1.i.e(view, "view");
        final int i = 0;
        AbstractC0470b.a(N().e, new l(this) {

            public final StoneSeaFragment f5823c;

            {
                this.f5823c = this;
            }

            @Override
            public final Object j(Object obj) {
                View view2 = (View) obj;
                switch (i) {
                    case 0:
                        Q1.i.e(view2, "it");
                        i iVar = (i) this.f5823c.f3166Z.getValue();
                        C0418d c0418d = ((C0487f) ((M) iVar.f5840d.f2719b).i()).f5832b;
                        if (c0418d != null) {
                            AbstractC0063y.m(T.h(iVar), null, 0, new C0489h(iVar, c0418d, null), 3);
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        StoneSeaFragment stoneSeaFragment = this.f5823c;
                        C0418d c0418d2 = stoneSeaFragment.f3167a0;
                        if (c0418d2 != null) {
                            C0417c c0417c = c0418d2.f5288a;
                            Integer numValueOf = Integer.valueOf(c0417c.f5283f);
                            String strL = stoneSeaFragment.l(R.string.clipboard_village_card, c0417c.f5280b, c0417c.f5282d, c0417c.e, numValueOf, c0417c.f5286j);
                            Q1.i.d(strL, "getString(...)");
                            Object systemService = stoneSeaFragment.I().getSystemService("clipboard");
                            Q1.i.c(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                            ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText(stoneSeaFragment.k().getString(R.string.clipboard_label), strL));
                            Toast.makeText(stoneSeaFragment.I(), R.string.detail_copied, 0).show();
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i2 = 1;
        AbstractC0470b.a(N().f5454c, new l(this) {

            public final StoneSeaFragment f5823c;

            {
                this.f5823c = this;
            }

            @Override
            public final Object j(Object obj) {
                View view2 = (View) obj;
                switch (i2) {
                    case 0:
                        Q1.i.e(view2, "it");
                        i iVar = (i) this.f5823c.f3166Z.getValue();
                        C0418d c0418d = ((C0487f) ((M) iVar.f5840d.f2719b).i()).f5832b;
                        if (c0418d != null) {
                            AbstractC0063y.m(T.h(iVar), null, 0, new C0489h(iVar, c0418d, null), 3);
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        StoneSeaFragment stoneSeaFragment = this.f5823c;
                        C0418d c0418d2 = stoneSeaFragment.f3167a0;
                        if (c0418d2 != null) {
                            C0417c c0417c = c0418d2.f5288a;
                            Integer numValueOf = Integer.valueOf(c0417c.f5283f);
                            String strL = stoneSeaFragment.l(R.string.clipboard_village_card, c0417c.f5280b, c0417c.f5282d, c0417c.e, numValueOf, c0417c.f5286j);
                            Q1.i.d(strL, "getString(...)");
                            Object systemService = stoneSeaFragment.I().getSystemService("clipboard");
                            Q1.i.c(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                            ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText(stoneSeaFragment.k().getString(R.string.clipboard_label), strL));
                            Toast.makeText(stoneSeaFragment.I(), R.string.detail_copied, 0).show();
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        AbstractC0063y.m(T.f(m()), null, 0, new C0484c(this, null), 3);
    }

    public final C0446b N() {
        C0446b c0446b = this.f3164X;
        if (c0446b != null) {
            return c0446b;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    @Override
    public final View w(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        Q1.i.e(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(R.layout.fragment_detail, viewGroup, false);
        int i = R.id.content;
        LinearLayout linearLayout = (LinearLayout) AbstractC0065a.E(viewInflate, R.id.content);
        if (linearLayout != null) {
            i = R.id.copyButton;
            MaterialButton materialButton = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.copyButton);
            if (materialButton != null) {
                i = R.id.elevationValue;
                TextView textView = (TextView) AbstractC0065a.E(viewInflate, R.id.elevationValue);
                if (textView != null) {
                    i = R.id.favoriteButton;
                    MaterialButton materialButton2 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.favoriteButton);
                    if (materialButton2 != null) {
                        i = R.id.originValue;
                        TextView textView2 = (TextView) AbstractC0065a.E(viewInflate, R.id.originValue);
                        if (textView2 != null) {
                            i = R.id.perchValue;
                            TextView textView3 = (TextView) AbstractC0065a.E(viewInflate, R.id.perchValue);
                            if (textView3 != null) {
                                i = R.id.progress;
                                ProgressBar progressBar = (ProgressBar) AbstractC0065a.E(viewInflate, R.id.progress);
                                if (progressBar != null) {
                                    i = R.id.regionValue;
                                    TextView textView4 = (TextView) AbstractC0065a.E(viewInflate, R.id.regionValue);
                                    if (textView4 != null) {
                                        i = R.id.traits;
                                        ChipGroup chipGroup = (ChipGroup) AbstractC0065a.E(viewInflate, R.id.traits);
                                        if (chipGroup != null) {
                                            i = R.id.villageMark;
                                            VillageMarkView villageMarkView = (VillageMarkView) AbstractC0065a.E(viewInflate, R.id.villageMark);
                                            if (villageMarkView != null) {
                                                i = R.id.villageName;
                                                TextView textView5 = (TextView) AbstractC0065a.E(viewInflate, R.id.villageName);
                                                if (textView5 != null) {
                                                    i = R.id.villagePlace;
                                                    TextView textView6 = (TextView) AbstractC0065a.E(viewInflate, R.id.villagePlace);
                                                    if (textView6 != null) {
                                                        i = R.id.villageSummary;
                                                        TextView textView7 = (TextView) AbstractC0065a.E(viewInflate, R.id.villageSummary);
                                                        if (textView7 != null) {
                                                            this.f3164X = new C0446b((FrameLayout) viewInflate, linearLayout, materialButton, textView, materialButton2, textView2, textView3, progressBar, textView4, chipGroup, villageMarkView, textView5, textView6, textView7);
                                                            FrameLayout frameLayout = N().f5452a;
                                                            Q1.i.d(frameLayout, "getRoot(...)");
                                                            return frameLayout;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override
    public final void x() {
        N().f5453b.animate().cancel();
        N().e.animate().cancel();
        this.f3167a0 = null;
        this.f3164X = null;
        this.f2363G = true;
    }
}
