package com.jorden.karto.xyndaros.ui.common;

import Q1.i;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import com.jorden.karto.xyndaros.R;

public final class HorizonTerraceView extends View {

    public final Paint f3155b;

    public final Path f3156c;

    public float f3157d;

    public HorizonTerraceView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        i.e(context, "context");
        this.f3155b = new Paint(1);
        this.f3156c = new Path();
        this.f3157d = 0.45f;
    }

    @Override
    public final void onDraw(Canvas canvas) {
        i.e(canvas, "canvas");
        super.onDraw(canvas);
        Paint paint = this.f3155b;
        paint.setColor(getContext().getColor(R.color.tile_tint_0));
        canvas.drawRoundRect(0.0f, 0.0f, getWidth(), getHeight(), getResources().getDimension(R.dimen.corner_card), getResources().getDimension(R.dimen.corner_card), paint);
        paint.setColor(getContext().getColor(R.color.brand_primary));
        canvas.drawRect(0.0f, getHeight() * 0.72f, getWidth(), getHeight(), paint);
        float height = (0.68f - (this.f3157d * 0.42f)) * getHeight();
        Path path = this.f3156c;
        path.reset();
        path.moveTo(getWidth() * 0.05f, getHeight() * 0.72f);
        path.lineTo(getWidth() * 0.24f, getHeight() * 0.6f);
        path.lineTo(getWidth() * 0.42f, height);
        path.lineTo(getWidth() * 0.62f, getHeight() * 0.48f);
        path.lineTo(getWidth() * 0.82f, getHeight() * 0.64f);
        path.lineTo(getWidth() * 0.95f, getHeight() * 0.72f);
        path.close();
        paint.setColor(getContext().getColor(R.color.brand_secondary));
        canvas.drawPath(path, paint);
        paint.setColor(getContext().getColor(R.color.brand_surface));
        float width = getWidth() * 0.12f;
        for (int i = 0; i < 4; i++) {
            float f2 = i;
            float width2 = ((0.1f * f2) + 0.31f) * getWidth();
            float fMin = Math.min((f2 * 0.06f * getHeight()) + height, getHeight() * 0.56f);
            canvas.drawRoundRect(width2, fMin, width2 + width, (getHeight() * 0.16f) + fMin, getResources().getDimension(R.dimen.corner_tile), getResources().getDimension(R.dimen.corner_tile), paint);
        }
    }
}
