package com.jorden.karto.xyndaros.ui.catalog;

import A1.e;
import A1.j;
import A1.k;
import C1.b;
import C1.c;
import P1.l;
import Q1.p;
import T0.a;
import Z1.AbstractC0063y;
import a.AbstractC0065a;
import android.R;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b0.AbstractComponentCallbacksC0117w;
import c2.M;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.jorden.karto.xyndaros.ui.catalog.TerraceAtlasFragment;
import com.jorden.karto.xyndaros.ui.common.VillageMarkView;
import java.lang.reflect.InvocationTargetException;
import p0.C0383i;
import s1.C0445a;
import v1.i;
import v1.m;
import w1.AbstractC0470b;

public final class TerraceAtlasFragment extends AbstractComponentCallbacksC0117w {

    public C0445a f3146X;

    public final Z f3147Y;

    public m f3148Z;

    public boolean f3149a0;

    public TerraceAtlasFragment() {
        e eVar = new e(7, this);
        b bVarN = AbstractC0065a.N(c.f293b, new j(7, new j(6, this)));
        this.f3147Y = new Z(p.a(i.class), new k(bVarN, 2), eVar, new k(bVarN, 3));
    }

    @Override
    public final void E(View view) {
        Q1.i.e(view, "view");
        this.f3148Z = new m(new C0383i(1, this, TerraceAtlasFragment.class, "openVillage", "openVillage(Ljava/lang/String;)V", 0, 1), new C0383i(1, O(), i.class, "toggleFavorite", "toggleFavorite(Lcom/jorden/karto/xyndaros/data/model/VillageCard;)V", 0, 2));
        C0445a c0445aN = N();
        I();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(1);
        RecyclerView recyclerView = c0445aN.f5451k;
        recyclerView.setLayoutManager(linearLayoutManager);
        m mVar = this.f3148Z;
        if (mVar == null) {
            Q1.i.g("villageAdapter");
            throw null;
        }
        recyclerView.setAdapter(mVar);
        recyclerView.setHasFixedSize(false);
        int[][] iArr = {new int[]{R.attr.state_checked}, new int[0]};
        C0445a c0445aN2 = N();
        c0445aN2.f5449h.setThumbTintList(new ColorStateList(iArr, new int[]{I().getColor(com.jorden.karto.xyndaros.R.color.brand_on_primary), I().getColor(com.jorden.karto.xyndaros.R.color.brand_on_background)}));
        C0445a c0445aN3 = N();
        c0445aN3.f5449h.setTrackTintList(new ColorStateList(iArr, new int[]{I().getColor(com.jorden.karto.xyndaros.R.color.brand_secondary_accessible), I().getColor(com.jorden.karto.xyndaros.R.color.brand_card_stroke)}));
        N().i.addTextChangedListener(new v1.c(this));
        C0445a c0445aN4 = N();
        c0445aN4.f5449h.setOnCheckedChangeListener(new a(1, this));
        final int i = 0;
        AbstractC0470b.a(N().f5444b, new l(this) {

            public final TerraceAtlasFragment f5615c;

            {
                this.f5615c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                View view2 = (View) obj;
                switch (i) {
                    case 0:
                        Q1.i.e(view2, "it");
                        i iVarO = this.f5615c.O();
                        C0465a c0465a = new C0465a();
                        M m2 = iVarO.f5631c;
                        m2.getClass();
                        m2.k(null, c0465a);
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        i iVarO2 = this.f5615c.O();
                        C0465a c0465a2 = new C0465a();
                        M m3 = iVarO2.f5631c;
                        m3.getClass();
                        m3.k(null, c0465a2);
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i2 = 1;
        AbstractC0470b.a(N().f5450j, new l(this) {

            public final TerraceAtlasFragment f5615c;

            {
                this.f5615c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                View view2 = (View) obj;
                switch (i2) {
                    case 0:
                        Q1.i.e(view2, "it");
                        i iVarO = this.f5615c.O();
                        C0465a c0465a = new C0465a();
                        M m2 = iVarO.f5631c;
                        m2.getClass();
                        m2.k(null, c0465a);
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        i iVarO2 = this.f5615c.O();
                        C0465a c0465a2 = new C0465a();
                        M m3 = iVarO2.f5631c;
                        m3.getClass();
                        m3.k(null, c0465a2);
                        break;
                }
                return C1.k.f305a;
            }
        });
        AbstractC0063y.m(T.f(m()), null, 0, new v1.e(this, null), 3);
    }

    public final C0445a N() {
        C0445a c0445a = this.f3146X;
        if (c0445a != null) {
            return c0445a;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final i O() {
        return (i) this.f3147Y.getValue();
    }

    @Override
    public final View w(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        Q1.i.e(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(com.jorden.karto.xyndaros.R.layout.fragment_catalog, viewGroup, false);
        int i = com.jorden.karto.xyndaros.R.id.catalogClearRouteButton;
        MaterialButton materialButton = (MaterialButton) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogClearRouteButton);
        if (materialButton != null) {
            i = com.jorden.karto.xyndaros.R.id.catalogCount;
            TextView textView = (TextView) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogCount);
            if (textView != null) {
                i = com.jorden.karto.xyndaros.R.id.catalogEmptyMark;
                VillageMarkView villageMarkView = (VillageMarkView) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogEmptyMark);
                if (villageMarkView != null) {
                    i = com.jorden.karto.xyndaros.R.id.catalogEmptyState;
                    LinearLayout linearLayout = (LinearLayout) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogEmptyState);
                    if (linearLayout != null) {
                        i = com.jorden.karto.xyndaros.R.id.catalogLoadedGroup;
                        LinearLayout linearLayout2 = (LinearLayout) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogLoadedGroup);
                        if (linearLayout2 != null) {
                            i = com.jorden.karto.xyndaros.R.id.catalogLoading;
                            ProgressBar progressBar = (ProgressBar) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogLoading);
                            if (progressBar != null) {
                                i = com.jorden.karto.xyndaros.R.id.catalogPinnedSwitch;
                                MaterialSwitch materialSwitch = (MaterialSwitch) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogPinnedSwitch);
                                if (materialSwitch != null) {
                                    i = com.jorden.karto.xyndaros.R.id.catalogSearchEditText;
                                    TextInputEditText textInputEditText = (TextInputEditText) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogSearchEditText);
                                    if (textInputEditText != null) {
                                        i = com.jorden.karto.xyndaros.R.id.catalogSearchLayout;
                                        if (((TextInputLayout) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogSearchLayout)) != null) {
                                            i = com.jorden.karto.xyndaros.R.id.catalogShowEveryButton;
                                            MaterialButton materialButton2 = (MaterialButton) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.catalogShowEveryButton);
                                            if (materialButton2 != null) {
                                                i = com.jorden.karto.xyndaros.R.id.villageList;
                                                RecyclerView recyclerView = (RecyclerView) AbstractC0065a.E(viewInflate, com.jorden.karto.xyndaros.R.id.villageList);
                                                if (recyclerView != null) {
                                                    this.f3146X = new C0445a((FrameLayout) viewInflate, materialButton, textView, villageMarkView, linearLayout, linearLayout2, progressBar, materialSwitch, textInputEditText, materialButton2, recyclerView);
                                                    FrameLayout frameLayout = N().f5443a;
                                                    Q1.i.d(frameLayout, "getRoot(...)");
                                                    return frameLayout;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override
    public final void x() {
        N().f5451k.setAdapter(null);
        this.f3146X = null;
        this.f2363G = true;
    }
}
