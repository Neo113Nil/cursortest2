package com.jorden.karto.xyndaros.ui.home;

import A1.e;
import A1.j;
import A1.k;
import C1.b;
import C1.c;
import P1.l;
import Q1.i;
import Q1.p;
import Z1.AbstractC0063y;
import a.AbstractC0065a;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import b0.AbstractComponentCallbacksC0117w;
import c2.M;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.jorden.karto.xyndaros.R;
import com.jorden.karto.xyndaros.ui.common.HorizonTerraceView;
import com.jorden.karto.xyndaros.ui.home.ClifftopCompassFragment;
import i0.C0207D;
import i0.C0208a;
import i0.z;
import q1.C0418d;
import s1.C0447c;
import w1.AbstractC0470b;
import y1.C0497c;
import y1.f;

public final class ClifftopCompassFragment extends AbstractComponentCallbacksC0117w {

    public C0447c f3168X;

    public final Z f3169Y;

    public C0418d f3170Z;

    public String f3171a0;

    public ClifftopCompassFragment() {
        e eVar = new e(9, this);
        b bVarN = AbstractC0065a.N(c.f293b, new j(10, new j(9, this)));
        this.f3169Y = new Z(p.a(f.class), new k(bVarN, 6), eVar, new k(bVarN, 7));
    }

    @Override
    public final void E(View view) {
        i.e(view, "view");
        final int i = 0;
        AbstractC0470b.a(N().f5473l, new l(this) {

            public final ClifftopCompassFragment f5889c;

            {
                this.f5889c = this;
            }

            @Override
            public final Object j(Object obj) {
                M m2;
                Object objI;
                View view2 = (View) obj;
                switch (i) {
                    case 0:
                        i.e(view2, "it");
                        f fVar = (f) this.f5889c.f3169Y.getValue();
                        int size = ((d) ((M) fVar.f5900c.f2719b).i()).f5895b.size();
                        if (size > 1) {
                            do {
                                m2 = fVar.f5899b;
                                objI = m2.i();
                            } while (!m2.h(objI, Integer.valueOf((((Number) objI).intValue() + 1) % size)));
                        }
                        break;
                    case 1:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment = this.f5889c;
                        clifftopCompassFragment.getClass();
                        Bundle bundle = new Bundle();
                        C0207D c0207dM = b2.i.m(clifftopCompassFragment);
                        z zVarG = c0207dM.g();
                        if (zVarG != null && zVarG.i == R.id.clifftopCompassFragment) {
                            c0207dM.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle, null);
                        }
                        break;
                    case 2:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment2 = this.f5889c;
                        clifftopCompassFragment2.getClass();
                        Bundle bundle2 = new Bundle();
                        C0207D c0207dM2 = b2.i.m(clifftopCompassFragment2);
                        z zVarG2 = c0207dM2.g();
                        if (zVarG2 != null && zVarG2.i == R.id.clifftopCompassFragment) {
                            c0207dM2.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle2, null);
                        }
                        break;
                    case 3:
                        i.e(view2, "it");
                        C0208a c0208a = new C0208a(R.id.action_clifftopCompassFragment_to_higherHorizonFragment);
                        ClifftopCompassFragment clifftopCompassFragment3 = this.f5889c;
                        clifftopCompassFragment3.getClass();
                        C0207D c0207dM3 = b2.i.m(clifftopCompassFragment3);
                        z zVarG3 = c0207dM3.g();
                        if (zVarG3 != null && zVarG3.i == R.id.clifftopCompassFragment) {
                            c0207dM3.m(c0208a.f3827a, c0208a.f3828b, null);
                        }
                        break;
                    default:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment4 = this.f5889c;
                        C0418d c0418d = clifftopCompassFragment4.f3170Z;
                        if (c0418d != null) {
                            String str = c0418d.f5288a.f5279a;
                            C0207D c0207dM4 = b2.i.m(clifftopCompassFragment4);
                            z zVarG4 = c0207dM4.g();
                            if (zVarG4 != null && zVarG4.i == R.id.clifftopCompassFragment) {
                                Bundle bundle3 = new Bundle();
                                bundle3.putString("villageId", str);
                                c0207dM4.m(R.id.action_clifftopCompassFragment_to_stoneSeaFragment, bundle3, null);
                            }
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i2 = 1;
        AbstractC0470b.a(N().i, new l(this) {

            public final ClifftopCompassFragment f5889c;

            {
                this.f5889c = this;
            }

            @Override
            public final Object j(Object obj) {
                M m2;
                Object objI;
                View view2 = (View) obj;
                switch (i2) {
                    case 0:
                        i.e(view2, "it");
                        f fVar = (f) this.f5889c.f3169Y.getValue();
                        int size = ((d) ((M) fVar.f5900c.f2719b).i()).f5895b.size();
                        if (size > 1) {
                            do {
                                m2 = fVar.f5899b;
                                objI = m2.i();
                            } while (!m2.h(objI, Integer.valueOf((((Number) objI).intValue() + 1) % size)));
                        }
                        break;
                    case 1:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment = this.f5889c;
                        clifftopCompassFragment.getClass();
                        Bundle bundle = new Bundle();
                        C0207D c0207dM = b2.i.m(clifftopCompassFragment);
                        z zVarG = c0207dM.g();
                        if (zVarG != null && zVarG.i == R.id.clifftopCompassFragment) {
                            c0207dM.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle, null);
                        }
                        break;
                    case 2:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment2 = this.f5889c;
                        clifftopCompassFragment2.getClass();
                        Bundle bundle2 = new Bundle();
                        C0207D c0207dM2 = b2.i.m(clifftopCompassFragment2);
                        z zVarG2 = c0207dM2.g();
                        if (zVarG2 != null && zVarG2.i == R.id.clifftopCompassFragment) {
                            c0207dM2.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle2, null);
                        }
                        break;
                    case 3:
                        i.e(view2, "it");
                        C0208a c0208a = new C0208a(R.id.action_clifftopCompassFragment_to_higherHorizonFragment);
                        ClifftopCompassFragment clifftopCompassFragment3 = this.f5889c;
                        clifftopCompassFragment3.getClass();
                        C0207D c0207dM3 = b2.i.m(clifftopCompassFragment3);
                        z zVarG3 = c0207dM3.g();
                        if (zVarG3 != null && zVarG3.i == R.id.clifftopCompassFragment) {
                            c0207dM3.m(c0208a.f3827a, c0208a.f3828b, null);
                        }
                        break;
                    default:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment4 = this.f5889c;
                        C0418d c0418d = clifftopCompassFragment4.f3170Z;
                        if (c0418d != null) {
                            String str = c0418d.f5288a.f5279a;
                            C0207D c0207dM4 = b2.i.m(clifftopCompassFragment4);
                            z zVarG4 = c0207dM4.g();
                            if (zVarG4 != null && zVarG4.i == R.id.clifftopCompassFragment) {
                                Bundle bundle3 = new Bundle();
                                bundle3.putString("villageId", str);
                                c0207dM4.m(R.id.action_clifftopCompassFragment_to_stoneSeaFragment, bundle3, null);
                            }
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i3 = 2;
        AbstractC0470b.a(N().f5468f, new l(this) {

            public final ClifftopCompassFragment f5889c;

            {
                this.f5889c = this;
            }

            @Override
            public final Object j(Object obj) {
                M m2;
                Object objI;
                View view2 = (View) obj;
                switch (i3) {
                    case 0:
                        i.e(view2, "it");
                        f fVar = (f) this.f5889c.f3169Y.getValue();
                        int size = ((d) ((M) fVar.f5900c.f2719b).i()).f5895b.size();
                        if (size > 1) {
                            do {
                                m2 = fVar.f5899b;
                                objI = m2.i();
                            } while (!m2.h(objI, Integer.valueOf((((Number) objI).intValue() + 1) % size)));
                        }
                        break;
                    case 1:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment = this.f5889c;
                        clifftopCompassFragment.getClass();
                        Bundle bundle = new Bundle();
                        C0207D c0207dM = b2.i.m(clifftopCompassFragment);
                        z zVarG = c0207dM.g();
                        if (zVarG != null && zVarG.i == R.id.clifftopCompassFragment) {
                            c0207dM.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle, null);
                        }
                        break;
                    case 2:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment2 = this.f5889c;
                        clifftopCompassFragment2.getClass();
                        Bundle bundle2 = new Bundle();
                        C0207D c0207dM2 = b2.i.m(clifftopCompassFragment2);
                        z zVarG2 = c0207dM2.g();
                        if (zVarG2 != null && zVarG2.i == R.id.clifftopCompassFragment) {
                            c0207dM2.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle2, null);
                        }
                        break;
                    case 3:
                        i.e(view2, "it");
                        C0208a c0208a = new C0208a(R.id.action_clifftopCompassFragment_to_higherHorizonFragment);
                        ClifftopCompassFragment clifftopCompassFragment3 = this.f5889c;
                        clifftopCompassFragment3.getClass();
                        C0207D c0207dM3 = b2.i.m(clifftopCompassFragment3);
                        z zVarG3 = c0207dM3.g();
                        if (zVarG3 != null && zVarG3.i == R.id.clifftopCompassFragment) {
                            c0207dM3.m(c0208a.f3827a, c0208a.f3828b, null);
                        }
                        break;
                    default:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment4 = this.f5889c;
                        C0418d c0418d = clifftopCompassFragment4.f3170Z;
                        if (c0418d != null) {
                            String str = c0418d.f5288a.f5279a;
                            C0207D c0207dM4 = b2.i.m(clifftopCompassFragment4);
                            z zVarG4 = c0207dM4.g();
                            if (zVarG4 != null && zVarG4.i == R.id.clifftopCompassFragment) {
                                Bundle bundle3 = new Bundle();
                                bundle3.putString("villageId", str);
                                c0207dM4.m(R.id.action_clifftopCompassFragment_to_stoneSeaFragment, bundle3, null);
                            }
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i4 = 3;
        AbstractC0470b.a(N().e, new l(this) {

            public final ClifftopCompassFragment f5889c;

            {
                this.f5889c = this;
            }

            @Override
            public final Object j(Object obj) {
                M m2;
                Object objI;
                View view2 = (View) obj;
                switch (i4) {
                    case 0:
                        i.e(view2, "it");
                        f fVar = (f) this.f5889c.f3169Y.getValue();
                        int size = ((d) ((M) fVar.f5900c.f2719b).i()).f5895b.size();
                        if (size > 1) {
                            do {
                                m2 = fVar.f5899b;
                                objI = m2.i();
                            } while (!m2.h(objI, Integer.valueOf((((Number) objI).intValue() + 1) % size)));
                        }
                        break;
                    case 1:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment = this.f5889c;
                        clifftopCompassFragment.getClass();
                        Bundle bundle = new Bundle();
                        C0207D c0207dM = b2.i.m(clifftopCompassFragment);
                        z zVarG = c0207dM.g();
                        if (zVarG != null && zVarG.i == R.id.clifftopCompassFragment) {
                            c0207dM.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle, null);
                        }
                        break;
                    case 2:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment2 = this.f5889c;
                        clifftopCompassFragment2.getClass();
                        Bundle bundle2 = new Bundle();
                        C0207D c0207dM2 = b2.i.m(clifftopCompassFragment2);
                        z zVarG2 = c0207dM2.g();
                        if (zVarG2 != null && zVarG2.i == R.id.clifftopCompassFragment) {
                            c0207dM2.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle2, null);
                        }
                        break;
                    case 3:
                        i.e(view2, "it");
                        C0208a c0208a = new C0208a(R.id.action_clifftopCompassFragment_to_higherHorizonFragment);
                        ClifftopCompassFragment clifftopCompassFragment3 = this.f5889c;
                        clifftopCompassFragment3.getClass();
                        C0207D c0207dM3 = b2.i.m(clifftopCompassFragment3);
                        z zVarG3 = c0207dM3.g();
                        if (zVarG3 != null && zVarG3.i == R.id.clifftopCompassFragment) {
                            c0207dM3.m(c0208a.f3827a, c0208a.f3828b, null);
                        }
                        break;
                    default:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment4 = this.f5889c;
                        C0418d c0418d = clifftopCompassFragment4.f3170Z;
                        if (c0418d != null) {
                            String str = c0418d.f5288a.f5279a;
                            C0207D c0207dM4 = b2.i.m(clifftopCompassFragment4);
                            z zVarG4 = c0207dM4.g();
                            if (zVarG4 != null && zVarG4.i == R.id.clifftopCompassFragment) {
                                Bundle bundle3 = new Bundle();
                                bundle3.putString("villageId", str);
                                c0207dM4.m(R.id.action_clifftopCompassFragment_to_stoneSeaFragment, bundle3, null);
                            }
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i5 = 4;
        AbstractC0470b.a(N().f5466c, new l(this) {

            public final ClifftopCompassFragment f5889c;

            {
                this.f5889c = this;
            }

            @Override
            public final Object j(Object obj) {
                M m2;
                Object objI;
                View view2 = (View) obj;
                switch (i5) {
                    case 0:
                        i.e(view2, "it");
                        f fVar = (f) this.f5889c.f3169Y.getValue();
                        int size = ((d) ((M) fVar.f5900c.f2719b).i()).f5895b.size();
                        if (size > 1) {
                            do {
                                m2 = fVar.f5899b;
                                objI = m2.i();
                            } while (!m2.h(objI, Integer.valueOf((((Number) objI).intValue() + 1) % size)));
                        }
                        break;
                    case 1:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment = this.f5889c;
                        clifftopCompassFragment.getClass();
                        Bundle bundle = new Bundle();
                        C0207D c0207dM = b2.i.m(clifftopCompassFragment);
                        z zVarG = c0207dM.g();
                        if (zVarG != null && zVarG.i == R.id.clifftopCompassFragment) {
                            c0207dM.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle, null);
                        }
                        break;
                    case 2:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment2 = this.f5889c;
                        clifftopCompassFragment2.getClass();
                        Bundle bundle2 = new Bundle();
                        C0207D c0207dM2 = b2.i.m(clifftopCompassFragment2);
                        z zVarG2 = c0207dM2.g();
                        if (zVarG2 != null && zVarG2.i == R.id.clifftopCompassFragment) {
                            c0207dM2.m(R.id.action_clifftopCompassFragment_to_terraceAtlasFragment, bundle2, null);
                        }
                        break;
                    case 3:
                        i.e(view2, "it");
                        C0208a c0208a = new C0208a(R.id.action_clifftopCompassFragment_to_higherHorizonFragment);
                        ClifftopCompassFragment clifftopCompassFragment3 = this.f5889c;
                        clifftopCompassFragment3.getClass();
                        C0207D c0207dM3 = b2.i.m(clifftopCompassFragment3);
                        z zVarG3 = c0207dM3.g();
                        if (zVarG3 != null && zVarG3.i == R.id.clifftopCompassFragment) {
                            c0207dM3.m(c0208a.f3827a, c0208a.f3828b, null);
                        }
                        break;
                    default:
                        i.e(view2, "it");
                        ClifftopCompassFragment clifftopCompassFragment4 = this.f5889c;
                        C0418d c0418d = clifftopCompassFragment4.f3170Z;
                        if (c0418d != null) {
                            String str = c0418d.f5288a.f5279a;
                            C0207D c0207dM4 = b2.i.m(clifftopCompassFragment4);
                            z zVarG4 = c0207dM4.g();
                            if (zVarG4 != null && zVarG4.i == R.id.clifftopCompassFragment) {
                                Bundle bundle3 = new Bundle();
                                bundle3.putString("villageId", str);
                                c0207dM4.m(R.id.action_clifftopCompassFragment_to_stoneSeaFragment, bundle3, null);
                            }
                        }
                        break;
                }
                return C1.k.f305a;
            }
        });
        AbstractC0063y.m(T.f(m()), null, 0, new C0497c(this, null), 3);
    }

    public final C0447c N() {
        C0447c c0447c = this.f3168X;
        if (c0447c != null) {
            return c0447c;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    @Override
    public final View w(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(R.layout.fragment_home, viewGroup, false);
        int i = R.id.enterHorizonButton;
        MaterialButton materialButton = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.enterHorizonButton);
        if (materialButton != null) {
            i = R.id.featuredCard;
            MaterialCardView materialCardView = (MaterialCardView) AbstractC0065a.E(viewInflate, R.id.featuredCard);
            if (materialCardView != null) {
                i = R.id.featuredElevation;
                TextView textView = (TextView) AbstractC0065a.E(viewInflate, R.id.featuredElevation);
                if (textView != null) {
                    i = R.id.featuredName;
                    TextView textView2 = (TextView) AbstractC0065a.E(viewInflate, R.id.featuredName);
                    if (textView2 != null) {
                        i = R.id.featuredPerch;
                        TextView textView3 = (TextView) AbstractC0065a.E(viewInflate, R.id.featuredPerch);
                        if (textView3 != null) {
                            i = R.id.featuredPlace;
                            TextView textView4 = (TextView) AbstractC0065a.E(viewInflate, R.id.featuredPlace);
                            if (textView4 != null) {
                                i = R.id.homeAltitudeProgress;
                                LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) AbstractC0065a.E(viewInflate, R.id.homeAltitudeProgress);
                                if (linearProgressIndicator != null) {
                                    i = R.id.homeContent;
                                    NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0065a.E(viewInflate, R.id.homeContent);
                                    if (nestedScrollView != null) {
                                        i = R.id.homeEmptyOpenAtlasButton;
                                        MaterialButton materialButton2 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.homeEmptyOpenAtlasButton);
                                        if (materialButton2 != null) {
                                            i = R.id.homeEmptyState;
                                            LinearLayout linearLayout = (LinearLayout) AbstractC0065a.E(viewInflate, R.id.homeEmptyState);
                                            if (linearLayout != null) {
                                                i = R.id.homeHeaderLine;
                                                if (((TextView) AbstractC0065a.E(viewInflate, R.id.homeHeaderLine)) != null) {
                                                    i = R.id.homeHighestElevation;
                                                    TextView textView5 = (TextView) AbstractC0065a.E(viewInflate, R.id.homeHighestElevation);
                                                    if (textView5 != null) {
                                                        i = R.id.homeHorizon;
                                                        HorizonTerraceView horizonTerraceView = (HorizonTerraceView) AbstractC0065a.E(viewInflate, R.id.homeHorizon);
                                                        if (horizonTerraceView != null) {
                                                            i = R.id.homeLoading;
                                                            ProgressBar progressBar = (ProgressBar) AbstractC0065a.E(viewInflate, R.id.homeLoading);
                                                            if (progressBar != null) {
                                                                i = R.id.homeLowestElevation;
                                                                TextView textView6 = (TextView) AbstractC0065a.E(viewInflate, R.id.homeLowestElevation);
                                                                if (textView6 != null) {
                                                                    i = R.id.openAtlasButton;
                                                                    MaterialButton materialButton3 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.openAtlasButton);
                                                                    if (materialButton3 != null) {
                                                                        i = R.id.turnCompassButton;
                                                                        MaterialButton materialButton4 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.turnCompassButton);
                                                                        if (materialButton4 != null) {
                                                                            this.f3168X = new C0447c((FrameLayout) viewInflate, materialButton, materialCardView, textView, textView2, textView3, textView4, linearProgressIndicator, nestedScrollView, materialButton2, linearLayout, textView5, horizonTerraceView, progressBar, textView6, materialButton3, materialButton4);
                                                                            FrameLayout frameLayout = N().f5464a;
                                                                            i.d(frameLayout, "getRoot(...)");
                                                                            return frameLayout;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override
    public final void x() {
        ((HorizonTerraceView) N().f5477p).animate().cancel();
        N().f5466c.animate().cancel();
        this.f3170Z = null;
        this.f3171a0 = null;
        this.f3168X = null;
        this.f2363G = true;
    }
}
