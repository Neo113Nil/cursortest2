package com.jorden.karto.xyndaros.ui.quiz;

import A1.d;
import A1.e;
import A1.j;
import A1.k;
import C1.b;
import C1.c;
import P1.l;
import Q1.i;
import Q1.p;
import Z1.AbstractC0063y;
import Z1.n0;
import a.AbstractC0065a;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.T;
import androidx.lifecycle.Z;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b0.AbstractComponentCallbacksC0117w;
import c2.M;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.jorden.karto.xyndaros.R;
import com.jorden.karto.xyndaros.ui.common.ElevationDuelView;
import com.jorden.karto.xyndaros.ui.quiz.HigherHorizonFragment;
import java.lang.reflect.InvocationTargetException;
import q1.C0419e;
import s1.C0447c;
import w1.AbstractC0470b;

public final class HigherHorizonFragment extends AbstractComponentCallbacksC0117w {

    public C0447c f3179X;

    public final Z f3180Y;

    public final d f3181Z;

    public int f3182a0;

    public HigherHorizonFragment() {
        e eVar = new e(0, this);
        b bVarN = AbstractC0065a.N(c.f293b, new j(1, new j(0, this)));
        this.f3180Y = new Z(p.a(A1.p.class), new k(bVarN, 0), eVar, new k(bVarN, 1));
        this.f3181Z = new d(A1.b.f219d);
        this.f3182a0 = -1;
    }

    @Override
    public final void E(View view) {
        i.e(view, "view");
        C0447c c0447cN = N();
        I();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(1);
        RecyclerView recyclerView = (RecyclerView) c0447cN.f5476o;
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.f3181Z);
        final int i = 0;
        AbstractC0470b.a((MaterialButton) N().f5477p, new l(this) {

            public final HigherHorizonFragment f224c;

            {
                this.f224c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                Object objI;
                l lVar;
                Object objI2;
                View view2 = (View) obj;
                switch (i) {
                    case 0:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                    case 1:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment = this.f224c;
                        l lVar2 = (l) ((M) higherHorizonFragment.O().e.f2719b).i();
                        C0419e c0419e = (C0419e) D1.l.j0(lVar2.f236b, lVar2.f237c);
                        if (c0419e != null) {
                            higherHorizonFragment.O().e(c0419e.f5290a.f5279a);
                        }
                        break;
                    case 2:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment2 = this.f224c;
                        l lVar3 = (l) ((M) higherHorizonFragment2.O().e.f2719b).i();
                        C0419e c0419e2 = (C0419e) D1.l.j0(lVar3.f236b, lVar3.f237c);
                        if (c0419e2 != null) {
                            higherHorizonFragment2.O().e(c0419e2.f5291b.f5279a);
                        }
                        break;
                    case 3:
                        Q1.i.e(view2, "it");
                        p pVarO = this.f224c.O();
                        M m2 = pVarO.f251d;
                        l lVar4 = (l) m2.i();
                        if (lVar4.f235a == q.f255c && lVar4.e) {
                            if (lVar4.f237c >= D1.m.Y(lVar4.f236b)) {
                                do {
                                    objI2 = m2.i();
                                } while (!m2.h(objI2, l.a((l) objI2, q.f256d, 0, 0, false, null, null, 126)));
                                n0 n0Var = pVarO.f253g;
                                if (n0Var != null) {
                                    n0Var.a(null);
                                }
                                pVarO.f253g = AbstractC0063y.m(T.h(pVarO), null, 0, new o(pVarO, lVar4, null), 3);
                            } else {
                                do {
                                    objI = m2.i();
                                    lVar = (l) objI;
                                } while (!m2.h(objI, l.a(lVar, null, lVar.f237c + 1, 0, false, null, null, 75)));
                            }
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i2 = 1;
        AbstractC0470b.a(N().e, new l(this) {

            public final HigherHorizonFragment f224c;

            {
                this.f224c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                Object objI;
                l lVar;
                Object objI2;
                View view2 = (View) obj;
                switch (i2) {
                    case 0:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                    case 1:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment = this.f224c;
                        l lVar2 = (l) ((M) higherHorizonFragment.O().e.f2719b).i();
                        C0419e c0419e = (C0419e) D1.l.j0(lVar2.f236b, lVar2.f237c);
                        if (c0419e != null) {
                            higherHorizonFragment.O().e(c0419e.f5290a.f5279a);
                        }
                        break;
                    case 2:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment2 = this.f224c;
                        l lVar3 = (l) ((M) higherHorizonFragment2.O().e.f2719b).i();
                        C0419e c0419e2 = (C0419e) D1.l.j0(lVar3.f236b, lVar3.f237c);
                        if (c0419e2 != null) {
                            higherHorizonFragment2.O().e(c0419e2.f5291b.f5279a);
                        }
                        break;
                    case 3:
                        Q1.i.e(view2, "it");
                        p pVarO = this.f224c.O();
                        M m2 = pVarO.f251d;
                        l lVar4 = (l) m2.i();
                        if (lVar4.f235a == q.f255c && lVar4.e) {
                            if (lVar4.f237c >= D1.m.Y(lVar4.f236b)) {
                                do {
                                    objI2 = m2.i();
                                } while (!m2.h(objI2, l.a((l) objI2, q.f256d, 0, 0, false, null, null, 126)));
                                n0 n0Var = pVarO.f253g;
                                if (n0Var != null) {
                                    n0Var.a(null);
                                }
                                pVarO.f253g = AbstractC0063y.m(T.h(pVarO), null, 0, new o(pVarO, lVar4, null), 3);
                            } else {
                                do {
                                    objI = m2.i();
                                    lVar = (l) objI;
                                } while (!m2.h(objI, l.a(lVar, null, lVar.f237c + 1, 0, false, null, null, 75)));
                            }
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i3 = 2;
        AbstractC0470b.a(N().f5473l, new l(this) {

            public final HigherHorizonFragment f224c;

            {
                this.f224c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                Object objI;
                l lVar;
                Object objI2;
                View view2 = (View) obj;
                switch (i3) {
                    case 0:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                    case 1:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment = this.f224c;
                        l lVar2 = (l) ((M) higherHorizonFragment.O().e.f2719b).i();
                        C0419e c0419e = (C0419e) D1.l.j0(lVar2.f236b, lVar2.f237c);
                        if (c0419e != null) {
                            higherHorizonFragment.O().e(c0419e.f5290a.f5279a);
                        }
                        break;
                    case 2:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment2 = this.f224c;
                        l lVar3 = (l) ((M) higherHorizonFragment2.O().e.f2719b).i();
                        C0419e c0419e2 = (C0419e) D1.l.j0(lVar3.f236b, lVar3.f237c);
                        if (c0419e2 != null) {
                            higherHorizonFragment2.O().e(c0419e2.f5291b.f5279a);
                        }
                        break;
                    case 3:
                        Q1.i.e(view2, "it");
                        p pVarO = this.f224c.O();
                        M m2 = pVarO.f251d;
                        l lVar4 = (l) m2.i();
                        if (lVar4.f235a == q.f255c && lVar4.e) {
                            if (lVar4.f237c >= D1.m.Y(lVar4.f236b)) {
                                do {
                                    objI2 = m2.i();
                                } while (!m2.h(objI2, l.a((l) objI2, q.f256d, 0, 0, false, null, null, 126)));
                                n0 n0Var = pVarO.f253g;
                                if (n0Var != null) {
                                    n0Var.a(null);
                                }
                                pVarO.f253g = AbstractC0063y.m(T.h(pVarO), null, 0, new o(pVarO, lVar4, null), 3);
                            } else {
                                do {
                                    objI = m2.i();
                                    lVar = (l) objI;
                                } while (!m2.h(objI, l.a(lVar, null, lVar.f237c + 1, 0, false, null, null, 75)));
                            }
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i4 = 3;
        AbstractC0470b.a(N().f5468f, new l(this) {

            public final HigherHorizonFragment f224c;

            {
                this.f224c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                Object objI;
                l lVar;
                Object objI2;
                View view2 = (View) obj;
                switch (i4) {
                    case 0:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                    case 1:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment = this.f224c;
                        l lVar2 = (l) ((M) higherHorizonFragment.O().e.f2719b).i();
                        C0419e c0419e = (C0419e) D1.l.j0(lVar2.f236b, lVar2.f237c);
                        if (c0419e != null) {
                            higherHorizonFragment.O().e(c0419e.f5290a.f5279a);
                        }
                        break;
                    case 2:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment2 = this.f224c;
                        l lVar3 = (l) ((M) higherHorizonFragment2.O().e.f2719b).i();
                        C0419e c0419e2 = (C0419e) D1.l.j0(lVar3.f236b, lVar3.f237c);
                        if (c0419e2 != null) {
                            higherHorizonFragment2.O().e(c0419e2.f5291b.f5279a);
                        }
                        break;
                    case 3:
                        Q1.i.e(view2, "it");
                        p pVarO = this.f224c.O();
                        M m2 = pVarO.f251d;
                        l lVar4 = (l) m2.i();
                        if (lVar4.f235a == q.f255c && lVar4.e) {
                            if (lVar4.f237c >= D1.m.Y(lVar4.f236b)) {
                                do {
                                    objI2 = m2.i();
                                } while (!m2.h(objI2, l.a((l) objI2, q.f256d, 0, 0, false, null, null, 126)));
                                n0 n0Var = pVarO.f253g;
                                if (n0Var != null) {
                                    n0Var.a(null);
                                }
                                pVarO.f253g = AbstractC0063y.m(T.h(pVarO), null, 0, new o(pVarO, lVar4, null), 3);
                            } else {
                                do {
                                    objI = m2.i();
                                    lVar = (l) objI;
                                } while (!m2.h(objI, l.a(lVar, null, lVar.f237c + 1, 0, false, null, null, 75)));
                            }
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                }
                return C1.k.f305a;
            }
        });
        final int i5 = 4;
        AbstractC0470b.a(N().i, new l(this) {

            public final HigherHorizonFragment f224c;

            {
                this.f224c = this;
            }

            @Override
            public final Object j(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                Object objI;
                l lVar;
                Object objI2;
                View view2 = (View) obj;
                switch (i5) {
                    case 0:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                    case 1:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment = this.f224c;
                        l lVar2 = (l) ((M) higherHorizonFragment.O().e.f2719b).i();
                        C0419e c0419e = (C0419e) D1.l.j0(lVar2.f236b, lVar2.f237c);
                        if (c0419e != null) {
                            higherHorizonFragment.O().e(c0419e.f5290a.f5279a);
                        }
                        break;
                    case 2:
                        Q1.i.e(view2, "it");
                        HigherHorizonFragment higherHorizonFragment2 = this.f224c;
                        l lVar3 = (l) ((M) higherHorizonFragment2.O().e.f2719b).i();
                        C0419e c0419e2 = (C0419e) D1.l.j0(lVar3.f236b, lVar3.f237c);
                        if (c0419e2 != null) {
                            higherHorizonFragment2.O().e(c0419e2.f5291b.f5279a);
                        }
                        break;
                    case 3:
                        Q1.i.e(view2, "it");
                        p pVarO = this.f224c.O();
                        M m2 = pVarO.f251d;
                        l lVar4 = (l) m2.i();
                        if (lVar4.f235a == q.f255c && lVar4.e) {
                            if (lVar4.f237c >= D1.m.Y(lVar4.f236b)) {
                                do {
                                    objI2 = m2.i();
                                } while (!m2.h(objI2, l.a((l) objI2, q.f256d, 0, 0, false, null, null, 126)));
                                n0 n0Var = pVarO.f253g;
                                if (n0Var != null) {
                                    n0Var.a(null);
                                }
                                pVarO.f253g = AbstractC0063y.m(T.h(pVarO), null, 0, new o(pVarO, lVar4, null), 3);
                            } else {
                                do {
                                    objI = m2.i();
                                    lVar = (l) objI;
                                } while (!m2.h(objI, l.a(lVar, null, lVar.f237c + 1, 0, false, null, null, 75)));
                            }
                        }
                        break;
                    default:
                        Q1.i.e(view2, "it");
                        this.f224c.O().f();
                        break;
                }
                return C1.k.f305a;
            }
        });
        AbstractC0063y.m(T.f(m()), null, 0, new A1.i(this, null), 3);
    }

    public final C0447c N() {
        C0447c c0447c = this.f3179X;
        if (c0447c != null) {
            return c0447c;
        }
        throw new IllegalArgumentException("Required value was null.");
    }

    public final A1.p O() {
        return (A1.p) this.f3180Y.getValue();
    }

    @Override
    public final View w(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        i.e(layoutInflater, "inflater");
        View viewInflate = layoutInflater.inflate(R.layout.fragment_quiz, viewGroup, false);
        int i = R.id.duelProfile;
        ElevationDuelView elevationDuelView = (ElevationDuelView) AbstractC0065a.E(viewInflate, R.id.duelProfile);
        if (elevationDuelView != null) {
            i = R.id.feedbackDetail;
            TextView textView = (TextView) AbstractC0065a.E(viewInflate, R.id.feedbackDetail);
            if (textView != null) {
                i = R.id.feedbackPanel;
                MaterialCardView materialCardView = (MaterialCardView) AbstractC0065a.E(viewInflate, R.id.feedbackPanel);
                if (materialCardView != null) {
                    i = R.id.feedbackTitle;
                    TextView textView2 = (TextView) AbstractC0065a.E(viewInflate, R.id.feedbackTitle);
                    if (textView2 != null) {
                        i = R.id.leftChoice;
                        MaterialButton materialButton = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.leftChoice);
                        if (materialButton != null) {
                            i = R.id.nextButton;
                            MaterialButton materialButton2 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.nextButton);
                            if (materialButton2 != null) {
                                i = R.id.playState;
                                NestedScrollView nestedScrollView = (NestedScrollView) AbstractC0065a.E(viewInflate, R.id.playState);
                                if (nestedScrollView != null) {
                                    i = R.id.progressIndicator;
                                    LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) AbstractC0065a.E(viewInflate, R.id.progressIndicator);
                                    if (linearProgressIndicator != null) {
                                        i = R.id.restartButton;
                                        MaterialButton materialButton3 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.restartButton);
                                        if (materialButton3 != null) {
                                            i = R.id.resultList;
                                            RecyclerView recyclerView = (RecyclerView) AbstractC0065a.E(viewInflate, R.id.resultList);
                                            if (recyclerView != null) {
                                                i = R.id.resultScore;
                                                TextView textView3 = (TextView) AbstractC0065a.E(viewInflate, R.id.resultScore);
                                                if (textView3 != null) {
                                                    i = R.id.resultsState;
                                                    LinearLayout linearLayout = (LinearLayout) AbstractC0065a.E(viewInflate, R.id.resultsState);
                                                    if (linearLayout != null) {
                                                        i = R.id.rightChoice;
                                                        MaterialButton materialButton4 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.rightChoice);
                                                        if (materialButton4 != null) {
                                                            i = R.id.roundProgress;
                                                            TextView textView4 = (TextView) AbstractC0065a.E(viewInflate, R.id.roundProgress);
                                                            if (textView4 != null) {
                                                                i = R.id.startButton;
                                                                MaterialButton materialButton5 = (MaterialButton) AbstractC0065a.E(viewInflate, R.id.startButton);
                                                                if (materialButton5 != null) {
                                                                    i = R.id.startState;
                                                                    LinearLayout linearLayout2 = (LinearLayout) AbstractC0065a.E(viewInflate, R.id.startState);
                                                                    if (linearLayout2 != null) {
                                                                        this.f3179X = new C0447c((FrameLayout) viewInflate, elevationDuelView, textView, materialCardView, textView2, materialButton, materialButton2, nestedScrollView, linearProgressIndicator, materialButton3, recyclerView, textView3, linearLayout, materialButton4, textView4, materialButton5, linearLayout2);
                                                                        FrameLayout frameLayout = N().f5464a;
                                                                        i.d(frameLayout, "getRoot(...)");
                                                                        return frameLayout;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    @Override
    public final void x() {
        ((RecyclerView) N().f5476o).setAdapter(null);
        this.f3182a0 = -1;
        this.f3179X = null;
        this.f2363G = true;
    }
}
