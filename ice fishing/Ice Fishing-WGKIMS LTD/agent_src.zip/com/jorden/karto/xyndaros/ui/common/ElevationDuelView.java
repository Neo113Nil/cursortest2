package com.jorden.karto.xyndaros.ui.common;

import P.AbstractC0024k;
import Q1.i;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import com.jorden.karto.xyndaros.R;

public final class ElevationDuelView extends View {

    public static final int f3150g = 0;

    public final Paint f3151b;

    public float f3152c;

    public float f3153d;
    public float e;

    public ValueAnimator f3154f;

    public ElevationDuelView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        i.e(context, "context");
        this.f3151b = new Paint(1);
        this.f3152c = 0.5f;
        this.f3153d = 0.5f;
    }

    public final float getRevealProgress() {
        return this.e;
    }

    @Override
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.f3154f;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.f3154f = null;
        super.onDetachedFromWindow();
    }

    @Override
    public final void onDraw(Canvas canvas) {
        i.e(canvas, "canvas");
        super.onDraw(canvas);
        Paint paint = this.f3151b;
        paint.setColor(getContext().getColor(R.color.tile_tint_4));
        canvas.drawRoundRect(0.0f, 0.0f, getWidth(), getHeight(), getResources().getDimension(R.dimen.corner_card), getResources().getDimension(R.dimen.corner_card), paint);
        float height = getHeight() * 0.86f;
        float f2 = this.f3152c - 0.42f;
        float f3 = this.e;
        float f4 = ((this.f3153d - 0.42f) * f3) + 0.42f;
        paint.setColor(getContext().getColor(R.color.brand_primary));
        canvas.drawRoundRect(getWidth() * 0.13f, height - ((getHeight() * ((f2 * f3) + 0.42f)) * 0.64f), 0.43f * getWidth(), height, getResources().getDimension(R.dimen.corner_tile), getResources().getDimension(R.dimen.corner_tile), paint);
        paint.setColor(getContext().getColor(R.color.brand_secondary));
        canvas.drawRoundRect(0.57f * getWidth(), height - ((getHeight() * f4) * 0.64f), 0.87f * getWidth(), height, getResources().getDimension(R.dimen.corner_tile), getResources().getDimension(R.dimen.corner_tile), paint);
        paint.setColor(getContext().getColor(R.color.brand_on_background));
        paint.setStrokeWidth(getResources().getDimension(R.dimen.stroke_hairline));
        canvas.drawLine(0.08f * getWidth(), height, getWidth() * 0.92f, height, paint);
    }

    public final void setRevealProgress(float f2) {
        this.e = AbstractC0024k.p(f2, 0.0f);
        invalidate();
    }
}
