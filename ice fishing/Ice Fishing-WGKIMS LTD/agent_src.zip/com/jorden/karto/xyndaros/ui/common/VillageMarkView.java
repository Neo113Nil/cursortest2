package com.jorden.karto.xyndaros.ui.common;

import Q1.i;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import com.jorden.karto.xyndaros.R;
import q1.C0417c;
import w1.AbstractC0470b;

public final class VillageMarkView extends View {

    public final Paint f3158b;

    public final Paint f3159c;

    public final Path f3160d;
    public final Path e;

    public final RectF f3161f;

    public String f3162g;

    public String f3163h;
    public int i;

    public VillageMarkView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        i.e(context, "context");
        this.f3158b = new Paint(1);
        Paint paint = new Paint(1);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
        this.f3159c = paint;
        this.f3160d = new Path();
        this.e = new Path();
        this.f3161f = new RectF();
        this.f3162g = "PA";
        this.f3163h = "perched-atlas";
    }

    public final void a(C0417c c0417c) {
        i.e(c0417c, "village");
        this.f3162g = c0417c.f5281c;
        this.f3163h = c0417c.f5279a;
        this.i = c0417c.f5287k;
        setContentDescription(getContext().getString(R.string.cd_village_mark, c0417c.f5280b));
        invalidate();
    }

    @Override
    public final void onDraw(Canvas canvas) throws Resources.NotFoundException {
        i.e(canvas, "canvas");
        super.onDraw(canvas);
        RectF rectF = this.f3161f;
        rectF.set(0.0f, 0.0f, getWidth(), getHeight());
        float dimension = getResources().getDimension(R.dimen.corner_tile);
        Path path = this.f3160d;
        path.reset();
        path.addRoundRect(rectF, dimension, dimension, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(path);
        Context context = getContext();
        i.d(context, "getContext(...)");
        String str = this.f3163h;
        i.e(str, "stableKey");
        canvas.drawColor(context.getColor(AbstractC0470b.f5654a[(str.hashCode() & Integer.MAX_VALUE) % 6]));
        Paint paint = this.f3158b;
        paint.setColor(getContext().getColor(R.color.brand_secondary));
        float width = getWidth() * 0.12f;
        int i = this.i % 6;
        Path path2 = this.e;
        if (i == 0) {
            canvas.drawRect(0.0f, 0.0f, width, getHeight(), paint);
        } else if (i == 1) {
            canvas.drawRect(getWidth() - width, 0.0f, getWidth(), getHeight(), paint);
        } else if (i == 2) {
            canvas.drawRect(0.0f, 0.0f, getWidth(), width, paint);
        } else if (i == 3) {
            canvas.drawRect(0.0f, getHeight() - width, getWidth(), getHeight(), paint);
        } else if (i != 4) {
            canvas.drawRect(getWidth() * 0.44f, 0.0f, getWidth() * 0.56f, getHeight(), paint);
        } else {
            path2.reset();
            path2.moveTo(0.0f, getHeight() * 0.18f);
            path2.lineTo(getWidth() * 0.12f, 0.0f);
            path2.lineTo(getWidth(), getHeight() * 0.82f);
            path2.lineTo(getWidth() * 0.88f, getHeight());
            path2.close();
            canvas.drawPath(path2, paint);
        }
        paint.setColor(getContext().getColor(R.color.brand_surface));
        float width2 = getWidth() * 0.24f;
        path2.reset();
        int i2 = this.i % 6;
        if (i2 == 0) {
            path2.moveTo(getWidth() - width2, 0.0f);
            path2.lineTo(getWidth(), 0.0f);
            path2.lineTo(getWidth(), width2);
        } else if (i2 == 1) {
            path2.moveTo(0.0f, getHeight() - width2);
            path2.lineTo(0.0f, getHeight());
            path2.lineTo(width2, getHeight());
        } else if (i2 == 2) {
            path2.moveTo(getWidth() - width2, getHeight());
            path2.lineTo(getWidth(), getHeight());
            path2.lineTo(getWidth(), getHeight() - width2);
        } else if (i2 != 4) {
            if (i2 != 5) {
                path2.moveTo(0.0f, 0.0f);
                path2.lineTo(width2, 0.0f);
                path2.lineTo(0.0f, width2);
            }
        }
        path2.close();
        canvas.drawPath(path2, paint);
        Paint paint2 = this.f3159c;
        paint2.setColor(getContext().getColor(R.color.brand_on_background));
        paint2.setTextSize(getHeight() * 0.34f);
        canvas.drawText(this.f3162g, getWidth() / 2.0f, (getHeight() / 2.0f) - ((paint2.ascent() + paint2.descent()) / 2.0f), paint2);
        canvas.restore();
    }
}
