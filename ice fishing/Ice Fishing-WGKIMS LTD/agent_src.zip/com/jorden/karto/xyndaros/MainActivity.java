package com.jorden.karto.xyndaros;

import A.i;
import C.b;
import D0.q;
import D1.j;
import R.a;
import a.AbstractC0065a;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.navigation.fragment.NavHostFragment;
import b0.AbstractComponentCallbacksC0117w;
import b0.C0119y;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.jorden.karto.xyndaros.MainActivity;
import com.jorden.karto.xyndaros.R;
import h.AbstractActivityC0196i;
import h.C0186I;
import h.C0194g;
import h.C0195h;
import h.LayoutInflaterFactory2C0179B;
import h.N;
import i0.C0207D;
import i0.InterfaceC0220m;
import i0.z;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Set;
import l0.C0244a;
import l0.C0245b;

public final class MainActivity extends AbstractActivityC0196i {

    public static final int f3142z = 0;

    public i f3143y;

    public MainActivity() {
        ((i) this.f2103f.f94d).O("androidx:appcompat", new C0194g(this));
        h(new C0195h(this));
    }

    @Override
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
        int i = R.id.appBarLayout;
        if (((AppBarLayout) AbstractC0065a.E(viewInflate, R.id.appBarLayout)) != null) {
            i = R.id.bottomNav;
            BottomNavigationView bottomNavigationView = (BottomNavigationView) AbstractC0065a.E(viewInflate, R.id.bottomNav);
            if (bottomNavigationView != null) {
                i = R.id.navHostFragment;
                if (((FragmentContainerView) AbstractC0065a.E(viewInflate, R.id.navHostFragment)) != null) {
                    MaterialToolbar materialToolbar = (MaterialToolbar) AbstractC0065a.E(viewInflate, R.id.toolbar);
                    if (materialToolbar != null) {
                        ConstraintLayout constraintLayout = (ConstraintLayout) viewInflate;
                        this.f3143y = new i(constraintLayout, bottomNavigationView, materialToolbar);
                        setContentView(constraintLayout);
                        i iVar = this.f3143y;
                        if (iVar == null) {
                            Q1.i.g("binding");
                            throw null;
                        }
                        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
                        if (layoutInflaterFactory2C0179B.f3469k instanceof Activity) {
                            layoutInflaterFactory2C0179B.B();
                            b2.i iVar2 = layoutInflaterFactory2C0179B.f3474p;
                            if (iVar2 instanceof N) {
                                throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
                            }
                            layoutInflaterFactory2C0179B.f3475q = null;
                            if (iVar2 != null) {
                                iVar2.S();
                            }
                            layoutInflaterFactory2C0179B.f3474p = null;
                            MaterialToolbar materialToolbar2 = (MaterialToolbar) iVar.f94d;
                            Object obj = layoutInflaterFactory2C0179B.f3469k;
                            C0186I c0186i = new C0186I(materialToolbar2, obj instanceof Activity ? ((Activity) obj).getTitle() : layoutInflaterFactory2C0179B.f3476r, layoutInflaterFactory2C0179B.f3472n);
                            layoutInflaterFactory2C0179B.f3474p = c0186i;
                            layoutInflaterFactory2C0179B.f3472n.f3616c = c0186i.f3500c;
                            materialToolbar2.setBackInvokedCallbackEnabled(true);
                            layoutInflaterFactory2C0179B.b();
                        }
                        AbstractComponentCallbacksC0117w abstractComponentCallbacksC0117wC = ((C0119y) this.f3590s.f267c).e.C(R.id.navHostFragment);
                        Q1.i.c(abstractComponentCallbacksC0117wC, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
                        C0207D c0207dN = ((NavHostFragment) abstractComponentCallbacksC0117wC).N();
                        Set setF0 = j.f0(new Integer[]{Integer.valueOf(R.id.clifftopCompassFragment), Integer.valueOf(R.id.terraceAtlasFragment), Integer.valueOf(R.id.higherHorizonFragment), Integer.valueOf(R.id.myWaymarksFragment)});
                        HashSet hashSet = new HashSet();
                        hashSet.addAll(setF0);
                        b bVar = new b(26, hashSet);
                        Q1.i.e(c0207dN, "navController");
                        c0207dN.b(new C0244a(this, bVar));
                        i iVar3 = this.f3143y;
                        if (iVar3 == null) {
                            Q1.i.g("binding");
                            throw null;
                        }
                        BottomNavigationView bottomNavigationView2 = (BottomNavigationView) iVar3.f93c;
                        bottomNavigationView2.setOnItemSelectedListener(new a(c0207dN));
                        c0207dN.b(new C0245b(new WeakReference(bottomNavigationView2), c0207dN));
                        i iVar4 = this.f3143y;
                        if (iVar4 == null) {
                            Q1.i.g("binding");
                            throw null;
                        }
                        ((BottomNavigationView) iVar4.f93c).setOnItemReselectedListener(new q(8));
                        c0207dN.b(new InterfaceC0220m() {
                            @Override
                            public final void a(C0207D c0207d, z zVar, Bundle bundle2) {
                                int i2 = MainActivity.f3142z;
                                Q1.i.e(c0207d, "<unused var>");
                                Q1.i.e(zVar, "destination");
                                i iVar5 = this.f4743a.f3143y;
                                if (iVar5 == null) {
                                    Q1.i.g("binding");
                                    throw null;
                                }
                                BottomNavigationView bottomNavigationView3 = (BottomNavigationView) iVar5.f93c;
                                Q1.i.d(bottomNavigationView3, "bottomNav");
                                bottomNavigationView3.setVisibility(zVar.i != R.id.stoneSeaFragment ? 0 : 8);
                            }
                        });
                        return;
                    }
                    i = R.id.toolbar;
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }
}
