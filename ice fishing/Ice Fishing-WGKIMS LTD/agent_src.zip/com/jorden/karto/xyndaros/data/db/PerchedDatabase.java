package com.jorden.karto.xyndaros.data.db;

import p0.AbstractC0371C;
import p1.C0407j;

public abstract class PerchedDatabase extends AbstractC0371C {
    public abstract C0407j j();
}
