package com.jorden.karto.xyndaros.data.db;

import A1.e;
import C1.i;
import D1.u;
import Q1.p;
import X.g;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import p0.C0385k;
import p1.C0407j;
import p1.C0408k;

public final class PerchedDatabase_Impl extends PerchedDatabase {

    public final i f3145k = new i(new e(4, this));

    @Override
    public final List a(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override
    public final C0385k b() {
        return new C0385k(this, new LinkedHashMap(), new LinkedHashMap(), "village_state", "visits", "profile", "quiz_record");
    }

    @Override
    public final g c() {
        return new C0408k(this);
    }

    @Override
    public final Set e() {
        return new LinkedHashSet();
    }

    @Override
    public final LinkedHashMap f() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(p.a(C0407j.class), u.f429b);
        return linkedHashMap;
    }

    @Override
    public final C0407j j() {
        return (C0407j) this.f3145k.getValue();
    }
}
