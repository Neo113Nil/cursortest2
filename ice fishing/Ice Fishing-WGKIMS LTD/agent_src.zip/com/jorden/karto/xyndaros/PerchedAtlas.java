package com.jorden.karto.xyndaros;

import A.i;
import B1.a;
import android.app.Application;
import n.C0296k;
import u1.d;

public final class PerchedAtlas extends Application {

    public i f3144b;

    @Override
    public final void onCreate() {
        super.onCreate();
        C0296k c0296k = new C0296k(9, this);
        i iVar = new i(24, false);
        iVar.f93c = a.a(new C0296k(c0296k, new C0296k(c0296k, a.a(new C0296k(11, c0296k)), 10), 12));
        iVar.f94d = a.a(d.f5568a);
        this.f3144b = iVar;
    }
}
