package h;

import P.AbstractC0024k;
import a.AbstractC0065a;
import android.R;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.C0088w;
import androidx.lifecycle.EnumC0079m;
import androidx.lifecycle.EnumC0080n;
import androidx.lifecycle.T;
import androidx.lifecycle.d0;
import androidx.navigation.fragment.NavHostFragment;
import b0.AbstractComponentCallbacksC0117w;
import b0.C0119y;
import b0.P;
import b0.S;
import b0.Z;
import com.jorden.karto.xyndaros.MainActivity;
import f0.C0172a;
import h.AbstractActivityC0196i;
import h0.C0202a;
import i0.C0205B;
import i0.C0207D;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import l.C0242c;
import n.C0321x;
import n.R0;
import n.l1;
import p0.AbstractC0377c;
import s.C0439h;
import s.C0442k;

public abstract class AbstractActivityC0196i extends b.k implements InterfaceC0197j {

    public boolean f3592u;

    public boolean f3593v;

    public LayoutInflaterFactory2C0179B f3595x;

    public final C.b f3590s = new C.b(20, new C0119y(this));

    public final C0088w f3591t = new C0088w(this);

    public boolean f3594w = true;

    public AbstractActivityC0196i() {
        ((A.i) this.f2103f.f94d).O("android:support:lifecycle", new b.d(this, 1));
        final int i = 0;
        g(new O.a(this) {

            public final AbstractActivityC0196i f2402b;

            {
                this.f2402b = this;
            }

            @Override
            public final void a(Object obj) {
                switch (i) {
                    case 0:
                        this.f2402b.f3590s.w();
                        break;
                    default:
                        this.f2402b.f3590s.w();
                        break;
                }
            }
        });
        final int i2 = 1;
        this.f2110n.add(new O.a(this) {

            public final AbstractActivityC0196i f2402b;

            {
                this.f2402b = this;
            }

            @Override
            public final void a(Object obj) {
                switch (i2) {
                    case 0:
                        this.f2402b.f3590s.w();
                        break;
                    default:
                        this.f2402b.f3590s.w();
                        break;
                }
            }
        });
        h(new b.e(this, 1));
    }

    public static boolean o(P p2) {
        EnumC0080n enumC0080n = EnumC0080n.f1925d;
        boolean zO = false;
        for (AbstractComponentCallbacksC0117w abstractComponentCallbacksC0117w : p2.f2188c.k()) {
            if (abstractComponentCallbacksC0117w != null) {
                C0119y c0119y = abstractComponentCallbacksC0117w.f2397w;
                if ((c0119y == null ? null : c0119y.f2406f) != null) {
                    zO |= o(abstractComponentCallbacksC0117w.g());
                }
                Z z2 = abstractComponentCallbacksC0117w.f2373R;
                EnumC0080n enumC0080n2 = EnumC0080n.e;
                if (z2 != null && z2.f().f1938d.compareTo(enumC0080n2) >= 0) {
                    abstractComponentCallbacksC0117w.f2373R.e.g(enumC0080n);
                    zO = true;
                }
                if (abstractComponentCallbacksC0117w.f2372Q.f1938d.compareTo(enumC0080n2) >= 0) {
                    abstractComponentCallbacksC0117w.f2372Q.g(enumC0080n);
                    zO = true;
                }
            }
        }
        return zO;
    }

    @Override
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        n();
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.w();
        ((ViewGroup) layoutInflaterFactory2C0179B.f3439C.findViewById(R.id.content)).addView(view, layoutParams);
        layoutInflaterFactory2C0179B.f3472n.a(layoutInflaterFactory2C0179B.f3471m.getCallback());
    }

    @Override
    public final void attachBaseContext(Context context) {
        Configuration configuration;
        Method method;
        int i = 0;
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.f3451Q = true;
        int i2 = layoutInflaterFactory2C0179B.f3455U;
        if (i2 == -100) {
            i2 = p.f3603c;
        }
        int iD = layoutInflaterFactory2C0179B.D(context, i2);
        if (p.c(context) && p.c(context)) {
            if (Build.VERSION.SDK_INT < 33) {
                synchronized (p.f3608j) {
                    try {
                        L.b bVar = p.f3604d;
                        if (bVar == null) {
                            if (p.e == null) {
                                p.e = L.b.a(E.e.e(context));
                            }
                            if (!p.e.f787a.f788a.isEmpty()) {
                                p.f3604d = p.e;
                            }
                        } else if (!bVar.equals(p.e)) {
                            L.b bVar2 = p.f3604d;
                            p.e = bVar2;
                            E.e.d(context, bVar2.f787a.f788a.toLanguageTags());
                        }
                    } finally {
                    }
                }
            } else if (!p.f3606g) {
                p.f3602b.execute(new RunnableC0198k(context, i));
            }
        }
        L.b bVarO = LayoutInflaterFactory2C0179B.o(context);
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(LayoutInflaterFactory2C0179B.t(context, iD, bVarO, null, false));
            } catch (IllegalStateException unused) {
            }
        } else if (context instanceof C0242c) {
            try {
                ((C0242c) context).a(LayoutInflaterFactory2C0179B.t(context, iD, bVarO, null, false));
            } catch (IllegalStateException unused2) {
            }
        } else if (LayoutInflaterFactory2C0179B.f3436l0) {
            Configuration configuration2 = new Configuration();
            configuration2.uiMode = -1;
            configuration2.fontScale = 0.0f;
            Configuration configuration3 = context.createConfigurationContext(configuration2).getResources().getConfiguration();
            Configuration configuration4 = context.getResources().getConfiguration();
            configuration3.uiMode = configuration4.uiMode;
            if (configuration3.equals(configuration4)) {
                configuration = null;
            } else {
                configuration = new Configuration();
                configuration.fontScale = 0.0f;
                if (configuration3.diff(configuration4) != 0) {
                    float f2 = configuration3.fontScale;
                    float f3 = configuration4.fontScale;
                    if (f2 != f3) {
                        configuration.fontScale = f3;
                    }
                    int i3 = configuration3.mcc;
                    int i4 = configuration4.mcc;
                    if (i3 != i4) {
                        configuration.mcc = i4;
                    }
                    int i5 = configuration3.mnc;
                    int i6 = configuration4.mnc;
                    if (i5 != i6) {
                        configuration.mnc = i6;
                    }
                    u.a(configuration3, configuration4, configuration);
                    int i7 = configuration3.touchscreen;
                    int i8 = configuration4.touchscreen;
                    if (i7 != i8) {
                        configuration.touchscreen = i8;
                    }
                    int i9 = configuration3.keyboard;
                    int i10 = configuration4.keyboard;
                    if (i9 != i10) {
                        configuration.keyboard = i10;
                    }
                    int i11 = configuration3.keyboardHidden;
                    int i12 = configuration4.keyboardHidden;
                    if (i11 != i12) {
                        configuration.keyboardHidden = i12;
                    }
                    int i13 = configuration3.navigation;
                    int i14 = configuration4.navigation;
                    if (i13 != i14) {
                        configuration.navigation = i14;
                    }
                    int i15 = configuration3.navigationHidden;
                    int i16 = configuration4.navigationHidden;
                    if (i15 != i16) {
                        configuration.navigationHidden = i16;
                    }
                    int i17 = configuration3.orientation;
                    int i18 = configuration4.orientation;
                    if (i17 != i18) {
                        configuration.orientation = i18;
                    }
                    int i19 = configuration3.screenLayout & 15;
                    int i20 = configuration4.screenLayout & 15;
                    if (i19 != i20) {
                        configuration.screenLayout |= i20;
                    }
                    int i21 = configuration3.screenLayout & 192;
                    int i22 = configuration4.screenLayout & 192;
                    if (i21 != i22) {
                        configuration.screenLayout |= i22;
                    }
                    int i23 = configuration3.screenLayout & 48;
                    int i24 = configuration4.screenLayout & 48;
                    if (i23 != i24) {
                        configuration.screenLayout |= i24;
                    }
                    int i25 = configuration3.screenLayout & 768;
                    int i26 = configuration4.screenLayout & 768;
                    if (i25 != i26) {
                        configuration.screenLayout |= i26;
                    }
                    int i27 = configuration3.colorMode & 3;
                    int i28 = configuration4.colorMode & 3;
                    if (i27 != i28) {
                        configuration.colorMode |= i28;
                    }
                    int i29 = configuration3.colorMode & 12;
                    int i30 = configuration4.colorMode & 12;
                    if (i29 != i30) {
                        configuration.colorMode |= i30;
                    }
                    int i31 = configuration3.uiMode & 15;
                    int i32 = configuration4.uiMode & 15;
                    if (i31 != i32) {
                        configuration.uiMode |= i32;
                    }
                    int i33 = configuration3.uiMode & 48;
                    int i34 = configuration4.uiMode & 48;
                    if (i33 != i34) {
                        configuration.uiMode |= i34;
                    }
                    int i35 = configuration3.screenWidthDp;
                    int i36 = configuration4.screenWidthDp;
                    if (i35 != i36) {
                        configuration.screenWidthDp = i36;
                    }
                    int i37 = configuration3.screenHeightDp;
                    int i38 = configuration4.screenHeightDp;
                    if (i37 != i38) {
                        configuration.screenHeightDp = i38;
                    }
                    int i39 = configuration3.smallestScreenWidthDp;
                    int i40 = configuration4.smallestScreenWidthDp;
                    if (i39 != i40) {
                        configuration.smallestScreenWidthDp = i40;
                    }
                    int i41 = configuration3.densityDpi;
                    int i42 = configuration4.densityDpi;
                    if (i41 != i42) {
                        configuration.densityDpi = i42;
                    }
                }
            }
            Configuration configurationT = LayoutInflaterFactory2C0179B.t(context, iD, bVarO, configuration, true);
            C0242c c0242c = new C0242c(context, com.jorden.karto.xyndaros.R.style.Theme_AppCompat_Empty);
            c0242c.a(configurationT);
            try {
                if (context.getTheme() != null) {
                    Resources.Theme theme = c0242c.getTheme();
                    if (Build.VERSION.SDK_INT >= 29) {
                        G.m.a(theme);
                    } else {
                        synchronized (G.b.e) {
                            if (G.b.f580g) {
                                method = G.b.f579f;
                                if (method != null) {
                                }
                            } else {
                                try {
                                    Method declaredMethod = Resources.Theme.class.getDeclaredMethod("rebase", null);
                                    G.b.f579f = declaredMethod;
                                    declaredMethod.setAccessible(true);
                                } catch (NoSuchMethodException e) {
                                    Log.i("ResourcesCompat", "Failed to retrieve rebase() method", e);
                                }
                                G.b.f580g = true;
                                method = G.b.f579f;
                                if (method != null) {
                                    try {
                                        method.invoke(theme, null);
                                    } catch (IllegalAccessException | InvocationTargetException e3) {
                                        Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", e3);
                                        G.b.f579f = null;
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (NullPointerException unused3) {
            }
            context = c0242c;
        }
        super.attachBaseContext(context);
    }

    @Override
    public final void closeOptionsMenu() {
        b2.i iVarM = m();
        if (getWindow().hasFeature(0)) {
            if (iVarM == null || !iVarM.f()) {
                super.closeOptionsMenu();
            }
        }
    }

    @Override
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        b2.i iVarM = m();
        if (keyCode == 82 && iVarM != null && iVarM.W(keyEvent)) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                        return;
                    }
                    break;
                case 100470631:
                    if (str2.equals("--dump-dumpable")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            return;
                        }
                    }
                    break;
                case 472614934:
                    if (str2.equals("--list-dumpables")) {
                    }
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                        return;
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill")) {
                        return;
                    }
                    break;
            }
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.f3592u);
        printWriter.print(" mResumed=");
        printWriter.print(this.f3593v);
        printWriter.print(" mStopped=");
        printWriter.print(this.f3594w);
        if (getApplication() != null) {
            d0 d0VarC = c();
            S s2 = C0202a.f3624c;
            Q1.i.e(d0VarC, "store");
            C0172a c0172a = C0172a.f3335b;
            Q1.i.e(c0172a, "defaultCreationExtras");
            C.l lVar = new C.l(d0VarC, s2, c0172a);
            Q1.e eVarA = Q1.p.a(C0202a.class);
            String strB = eVarA.b();
            if (strB == null) {
                throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
            }
            C0442k c0442k = ((C0202a) lVar.m(eVarA, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB))).f3625b;
            if (c0442k.e() > 0) {
                printWriter.print(str3);
                printWriter.println("Loaders:");
                if (c0442k.e() > 0) {
                    if (c0442k.f(0) != null) {
                        throw new ClassCastException();
                    }
                    printWriter.print(str3);
                    printWriter.print("  #");
                    printWriter.print(c0442k.c(0));
                    printWriter.print(": ");
                    throw null;
                }
            }
        }
        ((C0119y) this.f3590s.f267c).e.v(str, fileDescriptor, printWriter, strArr);
    }

    @Override
    public final View findViewById(int i) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.w();
        return layoutInflaterFactory2C0179B.f3471m.findViewById(i);
    }

    @Override
    public final MenuInflater getMenuInflater() {
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        if (layoutInflaterFactory2C0179B.f3475q == null) {
            layoutInflaterFactory2C0179B.B();
            b2.i iVar = layoutInflaterFactory2C0179B.f3474p;
            layoutInflaterFactory2C0179B.f3475q = new l.h(iVar != null ? iVar.F() : layoutInflaterFactory2C0179B.f3470l);
        }
        return layoutInflaterFactory2C0179B.f3475q;
    }

    @Override
    public final Resources getResources() {
        int i = l1.f4647a;
        return super.getResources();
    }

    @Override
    public final void invalidateOptionsMenu() {
        l().b();
    }

    public final p l() {
        if (this.f3595x == null) {
            ExecutorC0201n executorC0201n = p.f3602b;
            this.f3595x = new LayoutInflaterFactory2C0179B(this, null, this, this);
        }
        return this.f3595x;
    }

    public final b2.i m() {
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.B();
        return layoutInflaterFactory2C0179B.f3474p;
    }

    public final void n() {
        T.j(getWindow().getDecorView(), this);
        View decorView = getWindow().getDecorView();
        Q1.i.e(decorView, "<this>");
        decorView.setTag(com.jorden.karto.xyndaros.R.id.view_tree_view_model_store_owner, this);
        AbstractC0377c.B(getWindow().getDecorView(), this);
        AbstractC0024k.e0(getWindow().getDecorView(), this);
    }

    @Override
    public final void onActivityResult(int i, int i2, Intent intent) {
        this.f3590s.w();
        super.onActivityResult(i, i2, intent);
    }

    @Override
    public final void onConfigurationChanged(Configuration configuration) throws PackageManager.NameNotFoundException {
        super.onConfigurationChanged(configuration);
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        if (layoutInflaterFactory2C0179B.f3443H && layoutInflaterFactory2C0179B.f3438B) {
            layoutInflaterFactory2C0179B.B();
            b2.i iVar = layoutInflaterFactory2C0179B.f3474p;
            if (iVar != null) {
                iVar.Q();
            }
        }
        C0321x c0321xA = C0321x.a();
        Context context = layoutInflaterFactory2C0179B.f3470l;
        synchronized (c0321xA) {
            R0 r02 = c0321xA.f4723a;
            synchronized (r02) {
                C0439h c0439h = (C0439h) r02.f4504b.get(context);
                if (c0439h != null) {
                    c0439h.a();
                }
            }
        }
        layoutInflaterFactory2C0179B.f3454T = new Configuration(layoutInflaterFactory2C0179B.f3470l.getResources().getConfiguration());
        layoutInflaterFactory2C0179B.m(false, false);
    }

    @Override
    public final void onContentChanged() {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f3591t.d(EnumC0079m.ON_CREATE);
        P p2 = ((C0119y) this.f3590s.f267c).e;
        p2.f2178H = false;
        p2.f2179I = false;
        p2.f2184O.f2222g = false;
        p2.u(1);
    }

    @Override
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((C0119y) this.f3590s.f267c).e.f2190f.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    @Override
    public final void onDestroy() {
        p();
        l().e();
    }

    @Override
    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        Intent intent;
        if (q(i, menuItem)) {
            return true;
        }
        b2.i iVarM = m();
        int i2 = 0;
        if (menuItem.getItemId() != 16908332 || iVarM == null || (iVarM.t() & 4) == 0) {
            return false;
        }
        MainActivity mainActivity = (MainActivity) this;
        AbstractComponentCallbacksC0117w abstractComponentCallbacksC0117wC = ((C0119y) mainActivity.f3590s.f267c).e.C(com.jorden.karto.xyndaros.R.id.navHostFragment);
        Q1.i.c(abstractComponentCallbacksC0117wC, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
        C0207D c0207dN = ((NavHostFragment) abstractComponentCallbacksC0117wC).N();
        int iH = c0207dN.h();
        D1.i iVar = c0207dN.f3758g;
        if (iH == 1) {
            Activity activity = c0207dN.f3754b;
            Bundle extras = (activity == null || (intent = activity.getIntent()) == null) ? null : intent.getExtras();
            if ((extras != null ? extras.getIntArray("android-support-nav:controller:deepLinkIds") : null) == null) {
                i0.z zVarG = c0207dN.g();
                Q1.i.b(zVarG);
                int i3 = zVarG.i;
                for (C0205B c0205b = zVarG.f3927c; c0205b != null; c0205b = c0205b.f3927c) {
                    if (c0205b.f3747m != i3) {
                        Bundle bundle = new Bundle();
                        if (activity != null && activity.getIntent() != null && activity.getIntent().getData() != null) {
                            bundle.putParcelable("android-support-nav:controller:deepLinkIntent", activity.getIntent());
                            C0205B c0205bK = c0207dN.k(iVar);
                            Intent intent2 = activity.getIntent();
                            Q1.i.d(intent2, "activity!!.intent");
                            i0.x xVarH = c0205bK.h(new I1.f(intent2), true, c0205bK);
                            if ((xVarH != null ? xVarH.f3919c : null) != null) {
                                bundle.putAll(xVarH.f3918b.a(xVarH.f3919c));
                            }
                        }
                        C.l lVar = new C.l(c0207dN);
                        int i4 = c0205b.i;
                        ArrayList arrayList = (ArrayList) lVar.f289c;
                        arrayList.clear();
                        arrayList.add(new i0.w(i4, null));
                        if (((C0205B) lVar.f290d) != null) {
                            lVar.x();
                        }
                        ((Intent) lVar.f288b).putExtra("android-support-nav:controller:deepLinkExtras", bundle);
                        lVar.c().b();
                        if (activity == null) {
                            return true;
                        }
                        activity.finish();
                        return true;
                    }
                    i3 = c0205b.i;
                }
            } else if (c0207dN.f3757f) {
                Q1.i.b(activity);
                Intent intent3 = activity.getIntent();
                Bundle extras2 = intent3.getExtras();
                Q1.i.b(extras2);
                int[] intArray = extras2.getIntArray("android-support-nav:controller:deepLinkIds");
                Q1.i.b(intArray);
                ArrayList arrayListE0 = D1.j.e0(intArray);
                ArrayList parcelableArrayList = extras2.getParcelableArrayList("android-support-nav:controller:deepLinkArgs");
                if (arrayListE0.size() >= 2) {
                    int iIntValue = ((Number) D1.r.e0(arrayListE0)).intValue();
                    if (parcelableArrayList != null) {
                    }
                    i0.z zVarE = C0207D.e(iIntValue, c0207dN.i(), null, false);
                    if (zVarE instanceof C0205B) {
                        int i5 = C0205B.f3745o;
                        iIntValue = b2.i.n((C0205B) zVarE).i;
                    }
                    i0.z zVarG2 = c0207dN.g();
                    if (zVarG2 != null && iIntValue == zVarG2.i) {
                        C.l lVar2 = new C.l(c0207dN);
                        Bundle bundleG = AbstractC0065a.g(new C1.e("android-support-nav:controller:deepLinkIntent", intent3));
                        Bundle bundle2 = extras2.getBundle("android-support-nav:controller:deepLinkExtras");
                        if (bundle2 != null) {
                            bundleG.putAll(bundle2);
                        }
                        ((Intent) lVar2.f288b).putExtra("android-support-nav:controller:deepLinkExtras", bundleG);
                        Iterator it = arrayListE0.iterator();
                        while (it.hasNext()) {
                            Object next = it.next();
                            int i6 = i2 + 1;
                            if (i2 < 0) {
                                D1.m.b0();
                                throw null;
                            }
                            ((ArrayList) lVar2.f289c).add(new i0.w(((Number) next).intValue(), parcelableArrayList != null ? (Bundle) parcelableArrayList.get(i2) : null));
                            if (((C0205B) lVar2.f290d) != null) {
                                lVar2.x();
                            }
                            i2 = i6;
                        }
                        lVar2.c().b();
                        activity.finish();
                        return true;
                    }
                }
            }
        } else if (!iVar.isEmpty()) {
            i0.z zVarG3 = c0207dN.g();
            Q1.i.b(zVarG3);
            if (c0207dN.o(zVarG3.i, true, false) && c0207dN.c()) {
                return true;
            }
        }
        Intent intentB = E.e.b(mainActivity);
        if (intentB == null) {
            return false;
        }
        if (!mainActivity.shouldUpRecreateTask(intentB)) {
            mainActivity.navigateUpTo(intentB);
            return true;
        }
        E.i iVar2 = new E.i(mainActivity);
        Intent intentB2 = E.e.b(mainActivity);
        if (intentB2 == null) {
            intentB2 = E.e.b(mainActivity);
        }
        if (intentB2 != null) {
            ComponentName component = intentB2.getComponent();
            if (component == null) {
                component = intentB2.resolveActivity(iVar2.f454c.getPackageManager());
            }
            iVar2.a(component);
            iVar2.f453b.add(intentB2);
        }
        iVar2.b();
        try {
            mainActivity.finishAffinity();
            return true;
        } catch (IllegalStateException unused) {
            mainActivity.finish();
            return true;
        }
    }

    @Override
    public final void onPause() {
        super.onPause();
        this.f3593v = false;
        ((C0119y) this.f3590s.f267c).e.u(5);
        this.f3591t.d(EnumC0079m.ON_PAUSE);
    }

    @Override
    public final void onPostCreate(Bundle bundle) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        super.onPostCreate(bundle);
        ((LayoutInflaterFactory2C0179B) l()).w();
    }

    @Override
    public final void onPostResume() {
        r();
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.B();
        b2.i iVar = layoutInflaterFactory2C0179B.f3474p;
        if (iVar != null) {
            iVar.j0(true);
        }
    }

    @Override
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f3590s.w();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override
    public final void onResume() {
        C.b bVar = this.f3590s;
        bVar.w();
        super.onResume();
        this.f3593v = true;
        ((C0119y) bVar.f267c).e.z(true);
    }

    @Override
    public final void onStart() throws PackageManager.NameNotFoundException {
        s();
        ((LayoutInflaterFactory2C0179B) l()).m(true, false);
    }

    @Override
    public final void onStateNotSaved() {
        this.f3590s.w();
    }

    @Override
    public final void onStop() {
        t();
        LayoutInflaterFactory2C0179B layoutInflaterFactory2C0179B = (LayoutInflaterFactory2C0179B) l();
        layoutInflaterFactory2C0179B.B();
        b2.i iVar = layoutInflaterFactory2C0179B.f3474p;
        if (iVar != null) {
            iVar.j0(false);
        }
    }

    @Override
    public final void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        l().l(charSequence);
    }

    @Override
    public final void openOptionsMenu() {
        b2.i iVarM = m();
        if (getWindow().hasFeature(0)) {
            if (iVarM == null || !iVarM.X()) {
                super.openOptionsMenu();
            }
        }
    }

    public final void p() {
        super.onDestroy();
        ((C0119y) this.f3590s.f267c).e.l();
        this.f3591t.d(EnumC0079m.ON_DESTROY);
    }

    public final boolean q(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 6) {
            return ((C0119y) this.f3590s.f267c).e.j();
        }
        return false;
    }

    public final void r() {
        super.onPostResume();
        this.f3591t.d(EnumC0079m.ON_RESUME);
        P p2 = ((C0119y) this.f3590s.f267c).e;
        p2.f2178H = false;
        p2.f2179I = false;
        p2.f2184O.f2222g = false;
        p2.u(7);
    }

    public final void s() {
        C.b bVar = this.f3590s;
        bVar.w();
        super.onStart();
        this.f3594w = false;
        boolean z2 = this.f3592u;
        C0119y c0119y = (C0119y) bVar.f267c;
        if (!z2) {
            this.f3592u = true;
            P p2 = c0119y.e;
            p2.f2178H = false;
            p2.f2179I = false;
            p2.f2184O.f2222g = false;
            p2.u(4);
        }
        c0119y.e.z(true);
        this.f3591t.d(EnumC0079m.ON_START);
        P p3 = c0119y.e;
        p3.f2178H = false;
        p3.f2179I = false;
        p3.f2184O.f2222g = false;
        p3.u(5);
    }

    @Override
    public final void setContentView(int i) {
        n();
        l().h(i);
    }

    @Override
    public final void setTheme(int i) {
        super.setTheme(i);
        ((LayoutInflaterFactory2C0179B) l()).f3456V = i;
    }

    public final void t() {
        C.b bVar;
        super.onStop();
        this.f3594w = true;
        do {
            bVar = this.f3590s;
        } while (o(((C0119y) bVar.f267c).e));
        P p2 = ((C0119y) bVar.f267c).e;
        p2.f2179I = true;
        p2.f2184O.f2222g = true;
        p2.u(4);
        this.f3591t.d(EnumC0079m.ON_STOP);
    }

    @Override
    public void setContentView(View view) {
        n();
        l().i(view);
    }

    @Override
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((C0119y) this.f3590s.f267c).e.f2190f.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    @Override
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        n();
        l().j(view, layoutParams);
    }
}
