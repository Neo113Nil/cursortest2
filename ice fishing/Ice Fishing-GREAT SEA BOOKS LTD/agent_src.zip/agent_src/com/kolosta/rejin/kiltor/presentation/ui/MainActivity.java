package com.kolosta.rejin.kiltor.presentation.ui;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.navigation.fragment.NavHostFragment;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;
import com.kolosta.rejin.kiltor.R;
import defpackage.ZB6EwfQgURM;
import defpackage.ab0;
import defpackage.af;
import defpackage.bj;
import defpackage.bn;
import defpackage.cj;
import defpackage.cl0;
import defpackage.dc;
import defpackage.dj;
import defpackage.dn;
import defpackage.dt;
import defpackage.ej;
import defpackage.el0;
import defpackage.es;
import defpackage.fj;
import defpackage.fy;
import defpackage.g90;
import defpackage.h00;
import defpackage.hh0;
import defpackage.hk0;
import defpackage.i;
import defpackage.in;
import defpackage.j4;
import defpackage.jr;
import defpackage.jz;
import defpackage.k;
import defpackage.k30;
import defpackage.l0;
import defpackage.lhOeDqVB8Ye;
import defpackage.m;
import defpackage.m0;
import defpackage.n0;
import defpackage.n4;
import defpackage.n80;
import defpackage.od;
import defpackage.ov;
import defpackage.pf0;
import defpackage.pn;
import defpackage.pv;
import defpackage.qe;
import defpackage.qk0;
import defpackage.rq;
import defpackage.u90;
import defpackage.v7;
import defpackage.vi0;
import defpackage.w1;
import defpackage.y60;
import defpackage.z0;
import defpackage.z3;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class MainActivity extends n0 implements rq {
    public static final /* synthetic */ int XB6ioTeWZY2 = 0;
    public ZB6EwfQgURM OcCEV0cN9EJ;
    public final Object RD9v7iCsyVj;
    public volatile lhOeDqVB8Ye ZNZD85DkjoE;
    public boolean rAQLLnQzyBa;
    public jz yOSzBmjeOMj;

    public MainActivity() {
        ((k30) this.ocrRjEg1xWE.iQvCvXTWXYz).H8bE8XWjtoS("androidx:appcompat", new l0(this));
        ykVrBoeh7sI(new m0(this, 0));
        this.RD9v7iCsyVj = new Object();
        this.rAQLLnQzyBa = false;
        ykVrBoeh7sI(new m0(this, 1));
    }

    @Override // defpackage.s9, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        ab0 ab0Var = this.Oby7UOJk982;
        if (ab0Var == null) {
            ab0Var = new ab0(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
            this.Oby7UOJk982 = ab0Var;
        }
        w1 w1VarHgCgyIrsRhc = ((od) ((af) vi0.miDHqavGimy(this, af.class))).HgCgyIrsRhc();
        return new jr((dt) w1VarHgCgyIrsRhc.Ndt5adT1n2F, ab0Var, (w1) w1VarHgCgyIrsRhc.iQvCvXTWXYz);
    }

    public final void g0egR5i1XsF(Bundle bundle) {
        super.onCreate(bundle);
        lhOeDqVB8Ye lhoedqvb8yeN7QsYWNZtSU = n7QsYWNZtSU();
        m mVar = lhoedqvb8yeN7QsYWNZtSU.ykVrBoeh7sI;
        MainActivity mainActivity = mVar.wJXRvW1l9At;
        i iVar = new i(0, mVar.Ndt5adT1n2F);
        el0 el0VarMarFYthBr4b = mainActivity.MarFYthBr4b();
        dc dcVarOcrRjEg1xWE = u90.ocrRjEg1xWE(mainActivity);
        el0VarMarFYthBr4b.getClass();
        dcVarOcrRjEg1xWE.getClass();
        in inVar = new in(el0VarMarFYthBr4b, iVar, dcVarOcrRjEg1xWE);
        v7 v7VarHgCgyIrsRhc = y60.HgCgyIrsRhc(k.class);
        String strNDGTvOUPAhx = v7VarHgCgyIrsRhc.nDGTvOUPAhx();
        if (strNDGTvOUPAhx == null) {
            n4.Ndt5adT1n2F("Local and anonymous classes can not be ViewModels");
            return;
        }
        n80 n80Var = ((k) inVar.Ndt5adT1n2F(v7VarHgCgyIrsRhc, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strNDGTvOUPAhx))).kheiy7RMk6s;
        lhoedqvb8yeN7QsYWNZtSU.ocrRjEg1xWE = n80Var;
        if (((fy) n80Var.nDGTvOUPAhx) == null) {
            fy fyVarBrBhnf7Rph0 = lhoedqvb8yeN7QsYWNZtSU.iQvCvXTWXYz.brBhnf7Rph0();
            es.iQvCvXTWXYz(n80Var.HgCgyIrsRhc, "setExtras should only be called for an Activity that extends ComponentActivity", new Object[0]);
            n80Var.nDGTvOUPAhx = fyVarBrBhnf7Rph0;
        }
    }

    public final lhOeDqVB8Ye n7QsYWNZtSU() {
        if (this.ZNZD85DkjoE == null) {
            synchronized (this.RD9v7iCsyVj) {
                try {
                    if (this.ZNZD85DkjoE == null) {
                        this.ZNZD85DkjoE = new lhOeDqVB8Ye(this);
                    }
                } finally {
                }
            }
        }
        return this.ZNZD85DkjoE;
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        return n7QsYWNZtSU().nDGTvOUPAhx();
    }

    @Override // defpackage.n0, defpackage.s9, defpackage.r9, android.app.Activity
    public final void onCreate(Bundle bundle) {
        z0.ocrRjEg1xWE();
        pf0 pf0Var = new pf0();
        pf0 pf0Var2 = new pf0();
        int i = bj.HgCgyIrsRhc;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.getResources().getClass();
        decorView.getResources().getClass();
        int i2 = Build.VERSION.SDK_INT;
        fj ejVar = i2 >= 29 ? new ej() : i2 >= 26 ? new dj() : new cj();
        Window window = getWindow();
        window.getClass();
        ejVar.HgCgyIrsRhc(pf0Var, pf0Var2, window, decorView, false, false);
        g0egR5i1XsF(bundle);
        int i3 = 0;
        View viewInflate = getLayoutInflater().inflate(R.layout.activity_main, (ViewGroup) null, false);
        int i4 = R.id.content_root;
        LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.content_root);
        if (linearLayout != null) {
            DrawerLayout drawerLayout = (DrawerLayout) viewInflate;
            i4 = R.id.nav_host_fragment;
            if (((FragmentContainerView) g90.kheiy7RMk6s(viewInflate, R.id.nav_host_fragment)) != null) {
                int i5 = R.id.nav_view;
                NavigationView navigationView = (NavigationView) g90.kheiy7RMk6s(viewInflate, R.id.nav_view);
                if (navigationView != null) {
                    i5 = R.id.toolbar;
                    MaterialToolbar materialToolbar = (MaterialToolbar) g90.kheiy7RMk6s(viewInflate, R.id.toolbar);
                    if (materialToolbar != null) {
                        i5 = R.id.toolbar_divider;
                        if (g90.kheiy7RMk6s(viewInflate, R.id.toolbar_divider) != null) {
                            this.OcCEV0cN9EJ = new ZB6EwfQgURM(drawerLayout, linearLayout, drawerLayout, navigationView, materialToolbar);
                            setContentView(drawerLayout);
                            ZB6EwfQgURM zB6EwfQgURM = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            ((DrawerLayout) zB6EwfQgURM.Ndt5adT1n2F).setBackgroundColor(-1);
                            bn bnVarMYvwaIfm0QL = ((dn) this.fVTKpwokKnY.Ndt5adT1n2F).yOSzBmjeOMj.mYvwaIfm0QL(R.id.nav_host_fragment);
                            bnVarMYvwaIfm0QL.getClass();
                            this.yOSzBmjeOMj = ((NavHostFragment) bnVarMYvwaIfm0QL).D5vWTmG37B7();
                            Set setMJqr3p14w78 = z3.MJqr3p14w78(new Integer[]{Integer.valueOf(R.id.fragment_curry_board), Integer.valueOf(R.id.fragment_spice_menu), Integer.valueOf(R.id.fragment_flavor_imposter), Integer.valueOf(R.id.fragment_curry_passport)});
                            ZB6EwfQgURM zB6EwfQgURM2 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM2 == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            DrawerLayout drawerLayout2 = (DrawerLayout) zB6EwfQgURM2.iQvCvXTWXYz;
                            HashSet hashSet = new HashSet();
                            hashSet.addAll(setMJqr3p14w78);
                            w1 w1Var = new w1(hashSet, drawerLayout2, new ov());
                            ZB6EwfQgURM zB6EwfQgURM3 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM3 == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            MaterialToolbar materialToolbar2 = (MaterialToolbar) zB6EwfQgURM3.ocrRjEg1xWE;
                            jz jzVar = this.yOSzBmjeOMj;
                            if (jzVar == null) {
                                es.wBZqWeQU8tl("navController");
                                throw null;
                            }
                            jzVar.HgCgyIrsRhc(new hh0(materialToolbar2, w1Var));
                            materialToolbar2.setNavigationOnClickListener(new j4(jzVar, 9, w1Var));
                            ZB6EwfQgURM zB6EwfQgURM4 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM4 == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            NavigationView navigationView2 = (NavigationView) zB6EwfQgURM4.ykVrBoeh7sI;
                            jz jzVar2 = this.yOSzBmjeOMj;
                            if (jzVar2 == null) {
                                es.wBZqWeQU8tl("navController");
                                throw null;
                            }
                            navigationView2.setNavigationItemSelectedListener(new qe(jzVar2, navigationView2));
                            jzVar2.HgCgyIrsRhc(new h00(new WeakReference(navigationView2), jzVar2));
                            pn pnVar = new pn(1, this);
                            ocrRjEg1xWE().HgCgyIrsRhc(this, pnVar);
                            ZB6EwfQgURM zB6EwfQgURM5 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM5 == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            ((DrawerLayout) zB6EwfQgURM5.iQvCvXTWXYz).HgCgyIrsRhc(new pv(i3, pnVar));
                            ZB6EwfQgURM zB6EwfQgURM6 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM6 == null) {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                            LinearLayout linearLayout2 = (LinearLayout) zB6EwfQgURM6.wJXRvW1l9At;
                            n4 n4Var = new n4(10);
                            WeakHashMap weakHashMap = qk0.HgCgyIrsRhc;
                            hk0.kheiy7RMk6s(linearLayout2, n4Var);
                            ZB6EwfQgURM zB6EwfQgURM7 = this.OcCEV0cN9EJ;
                            if (zB6EwfQgURM7 != null) {
                                hk0.kheiy7RMk6s((NavigationView) zB6EwfQgURM7.ykVrBoeh7sI, new n4(11));
                                return;
                            } else {
                                es.wBZqWeQU8tl("binding");
                                throw null;
                            }
                        }
                    }
                }
                i4 = i5;
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i4)));
    }

    @Override // defpackage.n0, android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        n80 n80Var = n7QsYWNZtSU().ocrRjEg1xWE;
        if (n80Var != null) {
            n80Var.nDGTvOUPAhx = null;
        }
    }
}
