package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.kolosta.rejin.kiltor.R;
import com.kolosta.rejin.kiltor.presentation.ui.RoundResultFragment;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.es;
import defpackage.fx;
import defpackage.g3;
import defpackage.g90;
import defpackage.j3;
import defpackage.l80;
import defpackage.m1;
import defpackage.n4;
import defpackage.n90;
import defpackage.o90;
import defpackage.p90;
import defpackage.q30;
import defpackage.q90;
import defpackage.rk0;
import defpackage.rq;
import defpackage.t90;
import defpackage.vi0;
import defpackage.wJXRvW1l9At;
import defpackage.y60;
import defpackage.zc0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class RoundResultFragment extends bn implements rq {
    public m1 Aj3vze09p9a;
    public rk0 RM9erU4r8X4;
    public volatile j3 jUlElzv2pxm;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;
    public final g3 E5JQlYunlmp = new g3(y60.HgCgyIrsRhc(p90.class), new o90(this));
    public final ZB6EwfQgURM hTxQJAhmo4j = new ZB6EwfQgURM(y60.HgCgyIrsRhc(t90.class), new n90(this, 0), new n90(this, 2), new n90(this, 1));
    public final fx XHl2g3c24mc = new fx(new zc0(new q30(12), false), 5);

    public final void D5vWTmG37B7() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_round_result, viewGroup, false);
        int i = R.id.result_back;
        MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.result_back);
        if (materialButton != null) {
            i = R.id.result_caption;
            TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.result_caption);
            if (textView != null) {
                i = R.id.result_retry;
                MaterialButton materialButton2 = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.result_retry);
                if (materialButton2 != null) {
                    i = R.id.result_review;
                    RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.result_review);
                    if (recyclerView != null) {
                        i = R.id.result_review_empty;
                        LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.result_review_empty);
                        if (linearLayout != null) {
                            i = R.id.result_score;
                            TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.result_score);
                            if (textView2 != null) {
                                i = R.id.result_scroll;
                                if (((NestedScrollView) g90.kheiy7RMk6s(viewInflate, R.id.result_scroll)) != null) {
                                    LinearLayout linearLayout2 = (LinearLayout) viewInflate;
                                    this.Aj3vze09p9a = new m1(linearLayout2, materialButton, textView, materialButton2, recyclerView, linearLayout, textView2);
                                    linearLayout2.getClass();
                                    return linearLayout2;
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        m1 m1Var = this.Aj3vze09p9a;
        m1Var.getClass();
        TextView textView = (TextView) m1Var.MarFYthBr4b;
        g3 g3Var = this.E5JQlYunlmp;
        textView.setText(String.valueOf(((p90) g3Var.getValue()).HgCgyIrsRhc));
        m1 m1Var2 = this.Aj3vze09p9a;
        m1Var2.getClass();
        ((TextView) m1Var2.nDGTvOUPAhx).setText(Oby7UOJk982(R.string.result_score_format, Integer.valueOf(((p90) g3Var.getValue()).HgCgyIrsRhc), Integer.valueOf(((p90) g3Var.getValue()).nDGTvOUPAhx)));
        m1 m1Var3 = this.Aj3vze09p9a;
        m1Var3.getClass();
        ((RecyclerView) m1Var3.aBUhIZ95pth).setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        m1 m1Var4 = this.Aj3vze09p9a;
        m1Var4.getClass();
        ((RecyclerView) m1Var4.aBUhIZ95pth).setItemAnimator(null);
        m1 m1Var5 = this.Aj3vze09p9a;
        m1Var5.getClass();
        ((RecyclerView) m1Var5.aBUhIZ95pth).setAdapter(this.XHl2g3c24mc);
        m1 m1Var6 = this.Aj3vze09p9a;
        m1Var6.getClass();
        final int i = 0;
        ((MaterialButton) m1Var6.kheiy7RMk6s).setOnClickListener(new View.OnClickListener(this) { // from class: m90
            public final /* synthetic */ RoundResultFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2 = i;
                RoundResultFragment roundResultFragment = this.Ndt5adT1n2F;
                switch (i2) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(roundResultFragment);
                        int i3 = ((p90) roundResultFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", i3);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_round_result_to_round_play, bundle, null);
                        break;
                    default:
                        es.P56qh5C3eoK(vi0.ocrRjEg1xWE(roundResultFragment));
                        break;
                }
            }
        });
        m1 m1Var7 = this.Aj3vze09p9a;
        m1Var7.getClass();
        final int i2 = 1;
        ((MaterialButton) m1Var7.HgCgyIrsRhc).setOnClickListener(new View.OnClickListener(this) { // from class: m90
            public final /* synthetic */ RoundResultFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i2;
                RoundResultFragment roundResultFragment = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(roundResultFragment);
                        int i3 = ((p90) roundResultFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", i3);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_round_result_to_round_play, bundle, null);
                        break;
                    default:
                        es.P56qh5C3eoK(vi0.ocrRjEg1xWE(roundResultFragment));
                        break;
                }
            }
        });
        vi0.MarFYthBr4b(this, ((t90) this.hTxQJAhmo4j.getValue()).kheiy7RMk6s, new wJXRvW1l9At(6, this));
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        D5vWTmG37B7();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((q90) nDGTvOUPAhx()).getClass();
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        D5vWTmG37B7();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        D5vWTmG37B7();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((q90) nDGTvOUPAhx()).getClass();
    }
}
