package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.kolosta.rejin.kiltor.R;
import com.kolosta.rejin.kiltor.presentation.ui.CurryBoardFragment;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.ec;
import defpackage.es;
import defpackage.ft;
import defpackage.g90;
import defpackage.gn;
import defpackage.ic;
import defpackage.j3;
import defpackage.jc;
import defpackage.kc;
import defpackage.l4;
import defpackage.l80;
import defpackage.lc;
import defpackage.mc;
import defpackage.n4;
import defpackage.rk0;
import defpackage.rq;
import defpackage.vi0;
import defpackage.x8;
import defpackage.y50;
import defpackage.y60;
import defpackage.yc;
import defpackage.yf0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class CurryBoardFragment extends bn implements rq {
    public gn Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public x8 XHl2g3c24mc;
    public final l4 Ypoyc6CSuwk;
    public final l4 cVDN2FegiBA;
    public final ZB6EwfQgURM hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public final l4 pDfwYwzMf5H;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public CurryBoardFragment() {
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(0, new ic(3, this)));
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(yc.class), new kc(ctVarC48z5w8gjNK, 0), new lc(this, ctVarC48z5w8gjNK, 0), new kc(ctVarC48z5w8gjNK, 1));
        this.hTxQJAhmo4j = new ZB6EwfQgURM(y60.HgCgyIrsRhc(yf0.class), new ic(0, this), new ic(2, this), new ic(1, this));
        this.cVDN2FegiBA = new l4(new ec(0, this));
        this.pDfwYwzMf5H = new l4(new ec(2, this), (byte) 0);
        this.Ypoyc6CSuwk = new l4(new ec(3, this), (char) 0);
    }

    public final yc D5vWTmG37B7() {
        return (yc) this.E5JQlYunlmp.getValue();
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_curry_board, viewGroup, false);
        NestedScrollView nestedScrollView = (NestedScrollView) viewInflate;
        int i = R.id.chefs_pick_list;
        RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.chefs_pick_list);
        if (recyclerView != null) {
            i = R.id.continue_action;
            MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.continue_action);
            if (materialButton != null) {
                i = R.id.continue_caption;
                TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.continue_caption);
                if (textView != null) {
                    i = R.id.continue_card;
                    if (((MaterialCardView) g90.kheiy7RMk6s(viewInflate, R.id.continue_card)) != null) {
                        i = R.id.forgotten_empty;
                        LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.forgotten_empty);
                        if (linearLayout != null) {
                            i = R.id.forgotten_list;
                            RecyclerView recyclerView2 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.forgotten_list);
                            if (recyclerView2 != null) {
                                i = R.id.forgotten_see_all;
                                TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.forgotten_see_all);
                                if (textView2 != null) {
                                    i = R.id.milestone_card;
                                    if (((MaterialCardView) g90.kheiy7RMk6s(viewInflate, R.id.milestone_card)) != null) {
                                        i = R.id.milestone_value;
                                        TextView textView3 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.milestone_value);
                                        if (textView3 != null) {
                                            i = R.id.popular_empty;
                                            LinearLayout linearLayout2 = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.popular_empty);
                                            if (linearLayout2 != null) {
                                                i = R.id.popular_list;
                                                RecyclerView recyclerView3 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.popular_list);
                                                if (recyclerView3 != null) {
                                                    i = R.id.popular_see_all;
                                                    TextView textView4 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.popular_see_all);
                                                    if (textView4 != null) {
                                                        i = R.id.streak_card;
                                                        MaterialCardView materialCardView = (MaterialCardView) g90.kheiy7RMk6s(viewInflate, R.id.streak_card);
                                                        if (materialCardView != null) {
                                                            i = R.id.streak_check_in;
                                                            MaterialButton materialButton2 = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.streak_check_in);
                                                            if (materialButton2 != null) {
                                                                i = R.id.streak_value;
                                                                TextView textView5 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.streak_value);
                                                                if (textView5 != null) {
                                                                    this.Aj3vze09p9a = new gn(nestedScrollView, recyclerView, materialButton, textView, linearLayout, recyclerView2, textView2, textView3, linearLayout2, recyclerView3, textView4, materialCardView, materialButton2, textView5);
                                                                    nestedScrollView.getClass();
                                                                    return nestedScrollView;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        gn gnVar = this.Aj3vze09p9a;
        gnVar.getClass();
        V73zDzxkiRf(gnVar.HgCgyIrsRhc, this.cVDN2FegiBA);
        gn gnVar2 = this.Aj3vze09p9a;
        gnVar2.getClass();
        V73zDzxkiRf(gnVar2.brBhnf7Rph0, this.pDfwYwzMf5H);
        gn gnVar3 = this.Aj3vze09p9a;
        gnVar3.getClass();
        V73zDzxkiRf(gnVar3.iQvCvXTWXYz, this.Ypoyc6CSuwk);
        gn gnVar4 = this.Aj3vze09p9a;
        gnVar4.getClass();
        final int i = 0;
        gnVar4.ocrRjEg1xWE.setOnClickListener(new View.OnClickListener() { // from class: fc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2 = i;
                CurryBoardFragment curryBoardFragment = this;
                switch (i2) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).aBUhIZ95pth;
                        Boolean bool = Boolean.TRUE;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, bool);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_curry_passport);
                        break;
                    case 1:
                        yc ycVarD5vWTmG37B7 = curryBoardFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ycVarD5vWTmG37B7), null, new oc(ycVarD5vWTmG37B7, null, 1), 3);
                        break;
                    case 2:
                        ke0 ke0Var2 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, p6.Ndt5adT1n2F);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                    default:
                        ke0 ke0Var3 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var3.getClass();
                        ke0Var3.ocrRjEg1xWE(null, p6.iQvCvXTWXYz);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                }
            }
        });
        gn gnVar5 = this.Aj3vze09p9a;
        gnVar5.getClass();
        final int i2 = 1;
        gnVar5.kLF8MllXouM.setOnClickListener(new View.OnClickListener() { // from class: fc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i2;
                CurryBoardFragment curryBoardFragment = this;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).aBUhIZ95pth;
                        Boolean bool = Boolean.TRUE;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, bool);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_curry_passport);
                        break;
                    case 1:
                        yc ycVarD5vWTmG37B7 = curryBoardFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ycVarD5vWTmG37B7), null, new oc(ycVarD5vWTmG37B7, null, 1), 3);
                        break;
                    case 2:
                        ke0 ke0Var2 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, p6.Ndt5adT1n2F);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                    default:
                        ke0 ke0Var3 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var3.getClass();
                        ke0Var3.ocrRjEg1xWE(null, p6.iQvCvXTWXYz);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                }
            }
        });
        gn gnVar6 = this.Aj3vze09p9a;
        gnVar6.getClass();
        final int i3 = 2;
        gnVar6.MarFYthBr4b.setOnClickListener(new View.OnClickListener() { // from class: fc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i3;
                CurryBoardFragment curryBoardFragment = this;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).aBUhIZ95pth;
                        Boolean bool = Boolean.TRUE;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, bool);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_curry_passport);
                        break;
                    case 1:
                        yc ycVarD5vWTmG37B7 = curryBoardFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ycVarD5vWTmG37B7), null, new oc(ycVarD5vWTmG37B7, null, 1), 3);
                        break;
                    case 2:
                        ke0 ke0Var2 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, p6.Ndt5adT1n2F);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                    default:
                        ke0 ke0Var3 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var3.getClass();
                        ke0Var3.ocrRjEg1xWE(null, p6.iQvCvXTWXYz);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                }
            }
        });
        gn gnVar7 = this.Aj3vze09p9a;
        gnVar7.getClass();
        final int i4 = 3;
        gnVar7.ykVrBoeh7sI.setOnClickListener(new View.OnClickListener() { // from class: fc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i4;
                CurryBoardFragment curryBoardFragment = this;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).aBUhIZ95pth;
                        Boolean bool = Boolean.TRUE;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, bool);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_curry_passport);
                        break;
                    case 1:
                        yc ycVarD5vWTmG37B7 = curryBoardFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ycVarD5vWTmG37B7), null, new oc(ycVarD5vWTmG37B7, null, 1), 3);
                        break;
                    case 2:
                        ke0 ke0Var2 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, p6.Ndt5adT1n2F);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                    default:
                        ke0 ke0Var3 = ((yf0) curryBoardFragment.hTxQJAhmo4j.getValue()).nDGTvOUPAhx;
                        ke0Var3.getClass();
                        ke0Var3.ocrRjEg1xWE(null, p6.iQvCvXTWXYz);
                        es.fVTKpwokKnY(vi0.ocrRjEg1xWE(curryBoardFragment), R.id.fragment_spice_menu);
                        break;
                }
            }
        });
        vi0.MarFYthBr4b(this, D5vWTmG37B7().brBhnf7Rph0, new ec(4, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().iQvCvXTWXYz, new ec(5, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ykVrBoeh7sI, new ec(6, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().kLF8MllXouM, new ec(7, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ocrRjEg1xWE, new ec(8, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().Oby7UOJk982, new ec(9, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().miDHqavGimy, new ec(10, this));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().wJXRvW1l9At, new ec(1, this));
    }

    public final void V73zDzxkiRf(RecyclerView recyclerView, y50 y50Var) {
        recyclerView.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2(), 0, false));
        recyclerView.setItemAnimator(null);
        recyclerView.setAdapter(y50Var);
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        x8 x8Var = this.XHl2g3c24mc;
        if (x8Var != null) {
            x8Var.dismiss();
        }
        this.XHl2g3c24mc = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((mc) nDGTvOUPAhx()).getClass();
    }

    public final void hSdjhQTBcYv() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        hSdjhQTBcYv();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((mc) nDGTvOUPAhx()).getClass();
    }
}
