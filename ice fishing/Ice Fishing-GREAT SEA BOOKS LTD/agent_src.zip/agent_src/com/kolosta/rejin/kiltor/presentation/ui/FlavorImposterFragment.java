package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import com.google.android.material.button.MaterialButton;
import com.kolosta.rejin.kiltor.R;
import com.kolosta.rejin.kiltor.presentation.ui.FlavorImposterFragment;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.es;
import defpackage.ft;
import defpackage.g90;
import defpackage.in;
import defpackage.j3;
import defpackage.jc;
import defpackage.kc;
import defpackage.l80;
import defpackage.lc;
import defpackage.n4;
import defpackage.nl;
import defpackage.ol;
import defpackage.rk0;
import defpackage.rq;
import defpackage.vi0;
import defpackage.wJXRvW1l9At;
import defpackage.x8;
import defpackage.y60;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class FlavorImposterFragment extends bn implements rq {
    public in Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public x8 hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public FlavorImposterFragment() {
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(3, new jc(2, this)));
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(ol.class), new kc(ctVarC48z5w8gjNK, 4), new lc(this, ctVarC48z5w8gjNK, 2), new kc(ctVarC48z5w8gjNK, 5));
    }

    public final void D5vWTmG37B7() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_flavor_imposter, viewGroup, false);
        int i = R.id.imposter_how;
        MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.imposter_how);
        if (materialButton != null) {
            i = R.id.imposter_length_long;
            TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.imposter_length_long);
            if (textView != null) {
                i = R.id.imposter_length_short;
                TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.imposter_length_short);
                if (textView2 != null) {
                    NestedScrollView nestedScrollView = (NestedScrollView) viewInflate;
                    i = R.id.imposter_start;
                    MaterialButton materialButton2 = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.imposter_start);
                    if (materialButton2 != null) {
                        this.Aj3vze09p9a = new in(nestedScrollView, materialButton, textView, textView2, materialButton2);
                        nestedScrollView.getClass();
                        return nestedScrollView;
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        in inVar = this.Aj3vze09p9a;
        inVar.getClass();
        final int i = 0;
        ((TextView) inVar.aBUhIZ95pth).setOnClickListener(new View.OnClickListener(this) { // from class: ml
            public final /* synthetic */ FlavorImposterFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2 = i;
                FlavorImposterFragment flavorImposterFragment = this.Ndt5adT1n2F;
                switch (i2) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, 6);
                        break;
                    case 1:
                        ke0 ke0Var2 = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, 15);
                        break;
                    case 2:
                        x8 x8Var = flavorImposterFragment.hTxQJAhmo4j;
                        if (x8Var == null || !x8Var.isShowing()) {
                            x8 x8Var2 = new x8(flavorImposterFragment.XB6ioTeWZY2());
                            View viewInflate = x8Var2.getLayoutInflater().inflate(R.layout.dialog_how_it_works, (ViewGroup) null, false);
                            MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.how_it_works_close);
                            if (materialButton == null) {
                                n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.how_it_works_close)));
                                break;
                            } else {
                                x8Var2.setContentView((LinearLayout) viewInflate);
                                zd.MarFYthBr4b(x8Var2);
                                materialButton.setOnClickListener(new w8(x8Var2, 3));
                                x8Var2.show();
                                flavorImposterFragment.hTxQJAhmo4j = x8Var2;
                                break;
                            }
                        }
                        break;
                    default:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(flavorImposterFragment);
                        int iIntValue = ((Number) ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).kheiy7RMk6s.wJXRvW1l9At.Ndt5adT1n2F()).intValue();
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", iIntValue);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_flavor_imposter_to_round_play, bundle, null);
                        break;
                }
            }
        });
        in inVar2 = this.Aj3vze09p9a;
        inVar2.getClass();
        final int i2 = 1;
        ((TextView) inVar2.kheiy7RMk6s).setOnClickListener(new View.OnClickListener(this) { // from class: ml
            public final /* synthetic */ FlavorImposterFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i2;
                FlavorImposterFragment flavorImposterFragment = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, 6);
                        break;
                    case 1:
                        ke0 ke0Var2 = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, 15);
                        break;
                    case 2:
                        x8 x8Var = flavorImposterFragment.hTxQJAhmo4j;
                        if (x8Var == null || !x8Var.isShowing()) {
                            x8 x8Var2 = new x8(flavorImposterFragment.XB6ioTeWZY2());
                            View viewInflate = x8Var2.getLayoutInflater().inflate(R.layout.dialog_how_it_works, (ViewGroup) null, false);
                            MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.how_it_works_close);
                            if (materialButton == null) {
                                n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.how_it_works_close)));
                                break;
                            } else {
                                x8Var2.setContentView((LinearLayout) viewInflate);
                                zd.MarFYthBr4b(x8Var2);
                                materialButton.setOnClickListener(new w8(x8Var2, 3));
                                x8Var2.show();
                                flavorImposterFragment.hTxQJAhmo4j = x8Var2;
                                break;
                            }
                        }
                        break;
                    default:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(flavorImposterFragment);
                        int iIntValue = ((Number) ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).kheiy7RMk6s.wJXRvW1l9At.Ndt5adT1n2F()).intValue();
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", iIntValue);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_flavor_imposter_to_round_play, bundle, null);
                        break;
                }
            }
        });
        in inVar3 = this.Aj3vze09p9a;
        inVar3.getClass();
        final int i3 = 2;
        ((MaterialButton) inVar3.HgCgyIrsRhc).setOnClickListener(new View.OnClickListener(this) { // from class: ml
            public final /* synthetic */ FlavorImposterFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i3;
                FlavorImposterFragment flavorImposterFragment = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, 6);
                        break;
                    case 1:
                        ke0 ke0Var2 = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, 15);
                        break;
                    case 2:
                        x8 x8Var = flavorImposterFragment.hTxQJAhmo4j;
                        if (x8Var == null || !x8Var.isShowing()) {
                            x8 x8Var2 = new x8(flavorImposterFragment.XB6ioTeWZY2());
                            View viewInflate = x8Var2.getLayoutInflater().inflate(R.layout.dialog_how_it_works, (ViewGroup) null, false);
                            MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.how_it_works_close);
                            if (materialButton == null) {
                                n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.how_it_works_close)));
                                break;
                            } else {
                                x8Var2.setContentView((LinearLayout) viewInflate);
                                zd.MarFYthBr4b(x8Var2);
                                materialButton.setOnClickListener(new w8(x8Var2, 3));
                                x8Var2.show();
                                flavorImposterFragment.hTxQJAhmo4j = x8Var2;
                                break;
                            }
                        }
                        break;
                    default:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(flavorImposterFragment);
                        int iIntValue = ((Number) ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).kheiy7RMk6s.wJXRvW1l9At.Ndt5adT1n2F()).intValue();
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", iIntValue);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_flavor_imposter_to_round_play, bundle, null);
                        break;
                }
            }
        });
        in inVar4 = this.Aj3vze09p9a;
        inVar4.getClass();
        final int i4 = 3;
        ((MaterialButton) inVar4.nDGTvOUPAhx).setOnClickListener(new View.OnClickListener(this) { // from class: ml
            public final /* synthetic */ FlavorImposterFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i4;
                FlavorImposterFragment flavorImposterFragment = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ke0 ke0Var = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var.getClass();
                        ke0Var.ocrRjEg1xWE(null, 6);
                        break;
                    case 1:
                        ke0 ke0Var2 = ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).nDGTvOUPAhx;
                        ke0Var2.getClass();
                        ke0Var2.ocrRjEg1xWE(null, 15);
                        break;
                    case 2:
                        x8 x8Var = flavorImposterFragment.hTxQJAhmo4j;
                        if (x8Var == null || !x8Var.isShowing()) {
                            x8 x8Var2 = new x8(flavorImposterFragment.XB6ioTeWZY2());
                            View viewInflate = x8Var2.getLayoutInflater().inflate(R.layout.dialog_how_it_works, (ViewGroup) null, false);
                            MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.how_it_works_close);
                            if (materialButton == null) {
                                n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(R.id.how_it_works_close)));
                                break;
                            } else {
                                x8Var2.setContentView((LinearLayout) viewInflate);
                                zd.MarFYthBr4b(x8Var2);
                                materialButton.setOnClickListener(new w8(x8Var2, 3));
                                x8Var2.show();
                                flavorImposterFragment.hTxQJAhmo4j = x8Var2;
                                break;
                            }
                        }
                        break;
                    default:
                        jz jzVarOcrRjEg1xWE = vi0.ocrRjEg1xWE(flavorImposterFragment);
                        int iIntValue = ((Number) ((ol) flavorImposterFragment.E5JQlYunlmp.getValue()).kheiy7RMk6s.wJXRvW1l9At.Ndt5adT1n2F()).intValue();
                        jzVarOcrRjEg1xWE.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putInt("roundCount", iIntValue);
                        jzVarOcrRjEg1xWE.kheiy7RMk6s(R.id.action_flavor_imposter_to_round_play, bundle, null);
                        break;
                }
            }
        });
        vi0.MarFYthBr4b(this, ((ol) this.E5JQlYunlmp.getValue()).kheiy7RMk6s, new wJXRvW1l9At(1, this));
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        x8 x8Var = this.hTxQJAhmo4j;
        if (x8Var != null) {
            x8Var.dismiss();
        }
        this.hTxQJAhmo4j = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        D5vWTmG37B7();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((nl) nDGTvOUPAhx()).getClass();
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        D5vWTmG37B7();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        D5vWTmG37B7();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((nl) nDGTvOUPAhx()).getClass();
    }
}
