package com.kolosta.rejin.kiltor.data.local;

import defpackage.b9;
import defpackage.hh;
import defpackage.k80;
import defpackage.p80;
import defpackage.pg;
import defpackage.r30;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public abstract class AppDatabase extends k80 {
    public abstract p80 H8bE8XWjtoS();

    public abstract hh Oby7UOJk982();

    public abstract pg kLF8MllXouM();

    public abstract r30 miDHqavGimy();

    public abstract b9 ocrRjEg1xWE();
}
