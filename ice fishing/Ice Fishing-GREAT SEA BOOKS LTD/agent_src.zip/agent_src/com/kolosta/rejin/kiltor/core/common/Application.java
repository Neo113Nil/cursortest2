package com.kolosta.rejin.kiltor.core.common;

import defpackage.X0MyC8YR7bY;
import defpackage.j3;
import defpackage.l3;
import defpackage.rq;
import defpackage.z0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class Application extends android.app.Application implements rq {
    public boolean wJXRvW1l9At = false;
    public final j3 Ndt5adT1n2F = new j3(new X0MyC8YR7bY(19, this));

    public final void HgCgyIrsRhc() {
        if (!this.wJXRvW1l9At) {
            this.wJXRvW1l9At = true;
            ((l3) this.Ndt5adT1n2F.nDGTvOUPAhx()).getClass();
        }
        super.onCreate();
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        return this.Ndt5adT1n2F.nDGTvOUPAhx();
    }

    @Override // android.app.Application
    public final void onCreate() {
        HgCgyIrsRhc();
        z0.ocrRjEg1xWE();
    }
}
