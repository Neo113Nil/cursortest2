package com.kolosta.rejin.kiltor.data.local;

import com.kolosta.rejin.kiltor.data.local.AppDatabase_Impl;
import defpackage.b9;
import defpackage.f3;
import defpackage.gs;
import defpackage.hh;
import defpackage.jp;
import defpackage.lk;
import defpackage.mj;
import defpackage.of0;
import defpackage.p80;
import defpackage.pg;
import defpackage.r30;
import defpackage.v7;
import defpackage.y60;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {
    public final of0 H8bE8XWjtoS;
    public final of0 Oby7UOJk982;
    public final of0 kLF8MllXouM;
    public final of0 miDHqavGimy;
    public final of0 ocrRjEg1xWE;

    public AppDatabase_Impl() {
        final int i = 0;
        this.ocrRjEg1xWE = new of0(new jp(this) { // from class: e3
            public final /* synthetic */ AppDatabase_Impl Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // defpackage.jp
            public final Object HgCgyIrsRhc() {
                int i2 = i;
                AppDatabase_Impl appDatabase_Impl = this.Ndt5adT1n2F;
                switch (i2) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        return new pg(appDatabase_Impl);
                    case 1:
                        return new hh(appDatabase_Impl);
                    case 2:
                        return new b9(appDatabase_Impl);
                    case 3:
                        return new p80(appDatabase_Impl);
                    default:
                        return new r30(appDatabase_Impl);
                }
            }
        });
        final int i2 = 1;
        this.kLF8MllXouM = new of0(new jp(this) { // from class: e3
            public final /* synthetic */ AppDatabase_Impl Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // defpackage.jp
            public final Object HgCgyIrsRhc() {
                int i22 = i2;
                AppDatabase_Impl appDatabase_Impl = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        return new pg(appDatabase_Impl);
                    case 1:
                        return new hh(appDatabase_Impl);
                    case 2:
                        return new b9(appDatabase_Impl);
                    case 3:
                        return new p80(appDatabase_Impl);
                    default:
                        return new r30(appDatabase_Impl);
                }
            }
        });
        final int i3 = 2;
        this.Oby7UOJk982 = new of0(new jp(this) { // from class: e3
            public final /* synthetic */ AppDatabase_Impl Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // defpackage.jp
            public final Object HgCgyIrsRhc() {
                int i22 = i3;
                AppDatabase_Impl appDatabase_Impl = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        return new pg(appDatabase_Impl);
                    case 1:
                        return new hh(appDatabase_Impl);
                    case 2:
                        return new b9(appDatabase_Impl);
                    case 3:
                        return new p80(appDatabase_Impl);
                    default:
                        return new r30(appDatabase_Impl);
                }
            }
        });
        final int i4 = 3;
        this.miDHqavGimy = new of0(new jp(this) { // from class: e3
            public final /* synthetic */ AppDatabase_Impl Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // defpackage.jp
            public final Object HgCgyIrsRhc() {
                int i22 = i4;
                AppDatabase_Impl appDatabase_Impl = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        return new pg(appDatabase_Impl);
                    case 1:
                        return new hh(appDatabase_Impl);
                    case 2:
                        return new b9(appDatabase_Impl);
                    case 3:
                        return new p80(appDatabase_Impl);
                    default:
                        return new r30(appDatabase_Impl);
                }
            }
        });
        final int i5 = 4;
        this.H8bE8XWjtoS = new of0(new jp(this) { // from class: e3
            public final /* synthetic */ AppDatabase_Impl Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // defpackage.jp
            public final Object HgCgyIrsRhc() {
                int i22 = i5;
                AppDatabase_Impl appDatabase_Impl = this.Ndt5adT1n2F;
                switch (i22) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        return new pg(appDatabase_Impl);
                    case 1:
                        return new hh(appDatabase_Impl);
                    case 2:
                        return new b9(appDatabase_Impl);
                    case 3:
                        return new p80(appDatabase_Impl);
                    default:
                        return new r30(appDatabase_Impl);
                }
            }
        });
    }

    @Override // com.kolosta.rejin.kiltor.data.local.AppDatabase
    public final p80 H8bE8XWjtoS() {
        return (p80) this.miDHqavGimy.getValue();
    }

    @Override // defpackage.k80
    public final List HgCgyIrsRhc(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }

    @Override // defpackage.k80
    public final LinkedHashMap MarFYthBr4b() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        v7 v7VarHgCgyIrsRhc = y60.HgCgyIrsRhc(pg.class);
        lk lkVar = lk.wJXRvW1l9At;
        linkedHashMap.put(v7VarHgCgyIrsRhc, lkVar);
        linkedHashMap.put(y60.HgCgyIrsRhc(hh.class), lkVar);
        linkedHashMap.put(y60.HgCgyIrsRhc(b9.class), lkVar);
        linkedHashMap.put(y60.HgCgyIrsRhc(p80.class), lkVar);
        linkedHashMap.put(y60.HgCgyIrsRhc(r30.class), lkVar);
        return linkedHashMap;
    }

    @Override // com.kolosta.rejin.kiltor.data.local.AppDatabase
    public final hh Oby7UOJk982() {
        return (hh) this.kLF8MllXouM.getValue();
    }

    @Override // defpackage.k80
    public final Set brBhnf7Rph0() {
        return new LinkedHashSet();
    }

    @Override // com.kolosta.rejin.kiltor.data.local.AppDatabase
    public final pg kLF8MllXouM() {
        return (pg) this.ocrRjEg1xWE.getValue();
    }

    @Override // defpackage.k80
    public final mj kheiy7RMk6s() {
        return new f3(this);
    }

    @Override // com.kolosta.rejin.kiltor.data.local.AppDatabase
    public final r30 miDHqavGimy() {
        return (r30) this.H8bE8XWjtoS.getValue();
    }

    @Override // defpackage.k80
    public final gs nDGTvOUPAhx() {
        return new gs(this, new LinkedHashMap(), new LinkedHashMap(), "dishes", "dish_states", "compare_pairs", "rounds", "profile");
    }

    @Override // com.kolosta.rejin.kiltor.data.local.AppDatabase
    public final b9 ocrRjEg1xWE() {
        return (b9) this.Oby7UOJk982.getValue();
    }
}
