package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.kolosta.rejin.kiltor.R;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.es;
import defpackage.ft;
import defpackage.fx;
import defpackage.g90;
import defpackage.i50;
import defpackage.j3;
import defpackage.j50;
import defpackage.jc;
import defpackage.kc;
import defpackage.l4;
import defpackage.l80;
import defpackage.lc;
import defpackage.mo;
import defpackage.n4;
import defpackage.q30;
import defpackage.r50;
import defpackage.rk0;
import defpackage.rq;
import defpackage.vi0;
import defpackage.y50;
import defpackage.y60;
import defpackage.zc0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class RecipeCardFragment extends bn implements rq {
    public mo Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public final fx XHl2g3c24mc;
    public final l4 Ypoyc6CSuwk;
    public final fx cVDN2FegiBA;
    public Dialog hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public final l4 pDfwYwzMf5H;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public RecipeCardFragment() {
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(5, new jc(4, this)));
        int i = 6;
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(r50.class), new kc(ctVarC48z5w8gjNK, 6), new lc(this, ctVarC48z5w8gjNK, 3), new kc(ctVarC48z5w8gjNK, 7));
        this.XHl2g3c24mc = new fx(new zc0(new q30(14), false), i);
        this.cVDN2FegiBA = new fx(new zc0(new q30(4), false), 3);
        this.pDfwYwzMf5H = new l4(new i50(this, i));
        this.Ypoyc6CSuwk = new l4(new i50(this, 7), (byte) 0);
    }

    public final r50 D5vWTmG37B7() {
        return (r50) this.E5JQlYunlmp.getValue();
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_recipe_card, viewGroup, false);
        int i = R.id.recipe_emoji;
        TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_emoji);
        if (textView != null) {
            i = R.id.recipe_pairing_emoji;
            TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_pairing_emoji);
            if (textView2 != null) {
                i = R.id.recipe_pairing_name;
                TextView textView3 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_pairing_name);
                if (textView3 != null) {
                    i = R.id.recipe_pairing_note;
                    TextView textView4 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_pairing_note);
                    if (textView4 != null) {
                        i = R.id.recipe_rarity_note;
                        TextView textView5 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_rarity_note);
                        if (textView5 != null) {
                            i = R.id.recipe_rarity_value;
                            TextView textView6 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_rarity_value);
                            if (textView6 != null) {
                                i = R.id.recipe_region;
                                TextView textView7 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_region);
                                if (textView7 != null) {
                                    i = R.id.recipe_related;
                                    RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_related);
                                    if (recyclerView != null) {
                                        i = R.id.recipe_related_empty;
                                        LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.recipe_related_empty);
                                        if (linearLayout != null) {
                                            NestedScrollView nestedScrollView = (NestedScrollView) viewInflate;
                                            i = R.id.recipe_steps;
                                            RecyclerView recyclerView2 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_steps);
                                            if (recyclerView2 != null) {
                                                i = R.id.recipe_time;
                                                TextView textView8 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_time);
                                                if (textView8 != null) {
                                                    i = R.id.recipe_timeline;
                                                    RecyclerView recyclerView3 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_timeline);
                                                    if (recyclerView3 != null) {
                                                        i = R.id.recipe_title;
                                                        TextView textView9 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_title);
                                                        if (textView9 != null) {
                                                            i = R.id.recipe_twins;
                                                            RecyclerView recyclerView4 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.recipe_twins);
                                                            if (recyclerView4 != null) {
                                                                i = R.id.recipe_twins_empty;
                                                                LinearLayout linearLayout2 = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.recipe_twins_empty);
                                                                if (linearLayout2 != null) {
                                                                    this.Aj3vze09p9a = new mo(nestedScrollView, textView, textView2, textView3, textView4, textView5, textView6, textView7, recyclerView, linearLayout, recyclerView2, textView8, recyclerView3, textView9, recyclerView4, linearLayout2);
                                                                    nestedScrollView.getClass();
                                                                    return nestedScrollView;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        mo moVar = this.Aj3vze09p9a;
        moVar.getClass();
        V73zDzxkiRf(moVar.kLF8MllXouM, this.XHl2g3c24mc);
        mo moVar2 = this.Aj3vze09p9a;
        moVar2.getClass();
        V73zDzxkiRf(moVar2.ykVrBoeh7sI, this.cVDN2FegiBA);
        mo moVar3 = this.Aj3vze09p9a;
        moVar3.getClass();
        V73zDzxkiRf(moVar3.Ndt5adT1n2F, this.Ypoyc6CSuwk);
        mo moVar4 = this.Aj3vze09p9a;
        moVar4.getClass();
        moVar4.miDHqavGimy.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2(), 0, false));
        mo moVar5 = this.Aj3vze09p9a;
        moVar5.getClass();
        moVar5.miDHqavGimy.setItemAnimator(null);
        mo moVar6 = this.Aj3vze09p9a;
        moVar6.getClass();
        moVar6.miDHqavGimy.setAdapter(this.pDfwYwzMf5H);
        vi0.MarFYthBr4b(this, D5vWTmG37B7().wJXRvW1l9At, new i50(this, 0));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().Ndt5adT1n2F, new i50(this, 1));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().iQvCvXTWXYz, new i50(this, 2));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ykVrBoeh7sI, new i50(this, 3));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ocrRjEg1xWE, new i50(this, 4));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().MarFYthBr4b, new i50(this, 5));
    }

    public final void V73zDzxkiRf(RecyclerView recyclerView, y50 y50Var) {
        recyclerView.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        recyclerView.setItemAnimator(null);
        recyclerView.setAdapter(y50Var);
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        Dialog dialog = this.hTxQJAhmo4j;
        if (dialog != null) {
            dialog.dismiss();
        }
        this.hTxQJAhmo4j = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((j50) nDGTvOUPAhx()).getClass();
    }

    public final void hSdjhQTBcYv() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        hSdjhQTBcYv();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((j50) nDGTvOUPAhx()).getClass();
    }
}
