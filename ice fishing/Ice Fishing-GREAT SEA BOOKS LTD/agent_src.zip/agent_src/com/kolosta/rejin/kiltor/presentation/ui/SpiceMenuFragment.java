package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.tabs.TabLayout;
import com.kolosta.rejin.kiltor.R;
import com.kolosta.rejin.kiltor.presentation.ui.SpiceMenuFragment;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.ee0;
import defpackage.es;
import defpackage.ft;
import defpackage.g90;
import defpackage.j3;
import defpackage.jb;
import defpackage.jc;
import defpackage.kc;
import defpackage.kd0;
import defpackage.ke0;
import defpackage.l4;
import defpackage.l80;
import defpackage.lc;
import defpackage.md0;
import defpackage.mg;
import defpackage.mn0;
import defpackage.n4;
import defpackage.nd0;
import defpackage.o6;
import defpackage.od0;
import defpackage.oo;
import defpackage.p6;
import defpackage.pd0;
import defpackage.rk0;
import defpackage.rq;
import defpackage.ud0;
import defpackage.vi0;
import defpackage.vr;
import defpackage.x8;
import defpackage.y60;
import defpackage.yf0;
import defpackage.z80;
import java.util.ArrayList;
import java.util.Calendar;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class SpiceMenuFragment extends bn implements rq {
    public oo Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public x8 XHl2g3c24mc;
    public boolean Ypoyc6CSuwk;
    public ee0 cVDN2FegiBA;
    public final l4 calZpeugLr2;
    public final ZB6EwfQgURM hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public final l4 pB1RnrFzSW0;
    public boolean pDfwYwzMf5H;
    public final mg tzA8uRWBsm9;
    public final l4 wkJt4McXhrl;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public SpiceMenuFragment() {
        int i = 0;
        int i2 = 7;
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(i2, new od0(this, 3)));
        int i3 = 5;
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(ud0.class), new kc(ctVarC48z5w8gjNK, 10), new lc(this, ctVarC48z5w8gjNK, i3), new kc(ctVarC48z5w8gjNK, 11));
        this.hTxQJAhmo4j = new ZB6EwfQgURM(y60.HgCgyIrsRhc(yf0.class), new od0(this, i), new od0(this, 2), new od0(this, 1));
        this.tzA8uRWBsm9 = new mg(new kd0(this, i), new kd0(this, i3));
        this.calZpeugLr2 = new l4(new kd0(this, 6), (byte) 0);
        this.wkJt4McXhrl = new l4(new kd0(this, i2));
        this.pB1RnrFzSW0 = new l4(new kd0(this, 8), (char) 0);
    }

    public final ud0 D5vWTmG37B7() {
        return (ud0) this.E5JQlYunlmp.getValue();
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_spice_menu, viewGroup, false);
        int i = R.id.menu_clear_filters;
        TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.menu_clear_filters);
        if (textView != null) {
            i = R.id.menu_compared_empty;
            LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.menu_compared_empty);
            if (linearLayout != null) {
                i = R.id.menu_compared_list;
                RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.menu_compared_list);
                if (recyclerView != null) {
                    i = R.id.menu_dish_list;
                    RecyclerView recyclerView2 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.menu_dish_list);
                    if (recyclerView2 != null) {
                        i = R.id.menu_filters;
                        RecyclerView recyclerView3 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.menu_filters);
                        if (recyclerView3 != null) {
                            i = R.id.menu_filters_active;
                            TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.menu_filters_active);
                            if (textView2 != null) {
                                i = R.id.menu_filters_active_row;
                                LinearLayout linearLayout2 = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.menu_filters_active_row);
                                if (linearLayout2 != null) {
                                    i = R.id.menu_hide_cooked;
                                    TextView textView3 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.menu_hide_cooked);
                                    if (textView3 != null) {
                                        i = R.id.menu_letter_index;
                                        RecyclerView recyclerView4 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.menu_letter_index);
                                        if (recyclerView4 != null) {
                                            i = R.id.menu_list_empty;
                                            LinearLayout linearLayout3 = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.menu_list_empty);
                                            if (linearLayout3 != null) {
                                                i = R.id.menu_results_count;
                                                TextView textView4 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.menu_results_count);
                                                if (textView4 != null) {
                                                    i = R.id.menu_scroll;
                                                    NestedScrollView nestedScrollView = (NestedScrollView) g90.kheiy7RMk6s(viewInflate, R.id.menu_scroll);
                                                    if (nestedScrollView != null) {
                                                        i = R.id.menu_search;
                                                        EditText editText = (EditText) g90.kheiy7RMk6s(viewInflate, R.id.menu_search);
                                                        if (editText != null) {
                                                            i = R.id.menu_search_clear;
                                                            ImageView imageView = (ImageView) g90.kheiy7RMk6s(viewInflate, R.id.menu_search_clear);
                                                            if (imageView != null) {
                                                                i = R.id.menu_shuffle;
                                                                MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.menu_shuffle);
                                                                if (materialButton != null) {
                                                                    i = R.id.menu_tabs;
                                                                    TabLayout tabLayout = (TabLayout) g90.kheiy7RMk6s(viewInflate, R.id.menu_tabs);
                                                                    if (tabLayout != null) {
                                                                        i = R.id.menu_total_count;
                                                                        TextView textView5 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.menu_total_count);
                                                                        if (textView5 != null) {
                                                                            FrameLayout frameLayout = (FrameLayout) viewInflate;
                                                                            this.Aj3vze09p9a = new oo(frameLayout, textView, linearLayout, recyclerView, recyclerView2, recyclerView3, textView2, linearLayout2, textView3, recyclerView4, linearLayout3, textView4, nestedScrollView, editText, imageView, materialButton, tabLayout, textView5);
                                                                            frameLayout.getClass();
                                                                            return frameLayout;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        oo ooVar = this.Aj3vze09p9a;
        ooVar.getClass();
        ooVar.aBUhIZ95pth.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        oo ooVar2 = this.Aj3vze09p9a;
        ooVar2.getClass();
        jb jbVar = null;
        ooVar2.aBUhIZ95pth.setItemAnimator(null);
        oo ooVar3 = this.Aj3vze09p9a;
        ooVar3.getClass();
        ooVar3.aBUhIZ95pth.setAdapter(this.tzA8uRWBsm9);
        oo ooVar4 = this.Aj3vze09p9a;
        ooVar4.getClass();
        final int i = 0;
        ooVar4.brBhnf7Rph0.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2(), 0, false));
        oo ooVar5 = this.Aj3vze09p9a;
        ooVar5.getClass();
        ooVar5.brBhnf7Rph0.setItemAnimator(null);
        oo ooVar6 = this.Aj3vze09p9a;
        ooVar6.getClass();
        ooVar6.brBhnf7Rph0.setAdapter(this.calZpeugLr2);
        oo ooVar7 = this.Aj3vze09p9a;
        ooVar7.getClass();
        ooVar7.kheiy7RMk6s.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2(), 0, false));
        oo ooVar8 = this.Aj3vze09p9a;
        ooVar8.getClass();
        ooVar8.kheiy7RMk6s.setItemAnimator(null);
        oo ooVar9 = this.Aj3vze09p9a;
        ooVar9.getClass();
        ooVar9.kheiy7RMk6s.setAdapter(this.wkJt4McXhrl);
        oo ooVar10 = this.Aj3vze09p9a;
        ooVar10.getClass();
        ooVar10.iQvCvXTWXYz.setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        oo ooVar11 = this.Aj3vze09p9a;
        ooVar11.getClass();
        ooVar11.iQvCvXTWXYz.setItemAnimator(null);
        oo ooVar12 = this.Aj3vze09p9a;
        ooVar12.getClass();
        ooVar12.iQvCvXTWXYz.setAdapter(this.pB1RnrFzSW0);
        oo ooVar13 = this.Aj3vze09p9a;
        ooVar13.getClass();
        ooVar13.Oby7UOJk982.addTextChangedListener(new md0(this));
        oo ooVar14 = this.Aj3vze09p9a;
        ooVar14.getClass();
        final int i2 = 3;
        ooVar14.miDHqavGimy.setOnClickListener(new View.OnClickListener(this) { // from class: ld0
            public final /* synthetic */ SpiceMenuFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i3 = i2;
                jb jbVar2 = null;
                SpiceMenuFragment spiceMenuFragment = this.Ndt5adT1n2F;
                switch (i3) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ud0 ud0VarD5vWTmG37B7 = spiceMenuFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ud0VarD5vWTmG37B7), null, new k50(ud0VarD5vWTmG37B7, jbVar2, 2), 3);
                        break;
                    case 1:
                        ke0 ke0Var = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var.Ndt5adT1n2F(), null, null, !((o6) ke0Var.Ndt5adT1n2F()).kheiy7RMk6s, null, null, 27));
                        break;
                    case 2:
                        ke0 ke0Var2 = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var2.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var2.Ndt5adT1n2F(), null, ok.wJXRvW1l9At, false, null, p6.wJXRvW1l9At, 9));
                        break;
                    default:
                        oo ooVar15 = spiceMenuFragment.Aj3vze09p9a;
                        ooVar15.getClass();
                        ooVar15.Oby7UOJk982.setText("");
                        break;
                }
            }
        });
        oo ooVar15 = this.Aj3vze09p9a;
        ooVar15.getClass();
        TabLayout tabLayout = ooVar15.uCRx9YCOc24;
        nd0 nd0Var = new nd0(this);
        ArrayList arrayList = tabLayout.IYi9Twa3Yjg;
        if (!arrayList.contains(nd0Var)) {
            arrayList.add(nd0Var);
        }
        oo ooVar16 = this.Aj3vze09p9a;
        ooVar16.getClass();
        ooVar16.H8bE8XWjtoS.setOnClickListener(new View.OnClickListener(this) { // from class: ld0
            public final /* synthetic */ SpiceMenuFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i3 = i;
                jb jbVar2 = null;
                SpiceMenuFragment spiceMenuFragment = this.Ndt5adT1n2F;
                switch (i3) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ud0 ud0VarD5vWTmG37B7 = spiceMenuFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ud0VarD5vWTmG37B7), null, new k50(ud0VarD5vWTmG37B7, jbVar2, 2), 3);
                        break;
                    case 1:
                        ke0 ke0Var = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var.Ndt5adT1n2F(), null, null, !((o6) ke0Var.Ndt5adT1n2F()).kheiy7RMk6s, null, null, 27));
                        break;
                    case 2:
                        ke0 ke0Var2 = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var2.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var2.Ndt5adT1n2F(), null, ok.wJXRvW1l9At, false, null, p6.wJXRvW1l9At, 9));
                        break;
                    default:
                        oo ooVar152 = spiceMenuFragment.Aj3vze09p9a;
                        ooVar152.getClass();
                        ooVar152.Oby7UOJk982.setText("");
                        break;
                }
            }
        });
        oo ooVar17 = this.Aj3vze09p9a;
        ooVar17.getClass();
        final int i3 = 1;
        ooVar17.Ndt5adT1n2F.setOnClickListener(new View.OnClickListener(this) { // from class: ld0
            public final /* synthetic */ SpiceMenuFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i32 = i3;
                jb jbVar2 = null;
                SpiceMenuFragment spiceMenuFragment = this.Ndt5adT1n2F;
                switch (i32) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ud0 ud0VarD5vWTmG37B7 = spiceMenuFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ud0VarD5vWTmG37B7), null, new k50(ud0VarD5vWTmG37B7, jbVar2, 2), 3);
                        break;
                    case 1:
                        ke0 ke0Var = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var.Ndt5adT1n2F(), null, null, !((o6) ke0Var.Ndt5adT1n2F()).kheiy7RMk6s, null, null, 27));
                        break;
                    case 2:
                        ke0 ke0Var2 = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var2.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var2.Ndt5adT1n2F(), null, ok.wJXRvW1l9At, false, null, p6.wJXRvW1l9At, 9));
                        break;
                    default:
                        oo ooVar152 = spiceMenuFragment.Aj3vze09p9a;
                        ooVar152.getClass();
                        ooVar152.Oby7UOJk982.setText("");
                        break;
                }
            }
        });
        oo ooVar18 = this.Aj3vze09p9a;
        ooVar18.getClass();
        final int i4 = 2;
        ooVar18.HgCgyIrsRhc.setOnClickListener(new View.OnClickListener(this) { // from class: ld0
            public final /* synthetic */ SpiceMenuFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i32 = i4;
                jb jbVar2 = null;
                SpiceMenuFragment spiceMenuFragment = this.Ndt5adT1n2F;
                switch (i32) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        ud0 ud0VarD5vWTmG37B7 = spiceMenuFragment.D5vWTmG37B7();
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ud0VarD5vWTmG37B7), null, new k50(ud0VarD5vWTmG37B7, jbVar2, 2), 3);
                        break;
                    case 1:
                        ke0 ke0Var = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var.Ndt5adT1n2F(), null, null, !((o6) ke0Var.Ndt5adT1n2F()).kheiy7RMk6s, null, null, 27));
                        break;
                    case 2:
                        ke0 ke0Var2 = spiceMenuFragment.D5vWTmG37B7().wJXRvW1l9At;
                        ke0Var2.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var2.Ndt5adT1n2F(), null, ok.wJXRvW1l9At, false, null, p6.wJXRvW1l9At, 9));
                        break;
                    default:
                        oo ooVar152 = spiceMenuFragment.Aj3vze09p9a;
                        ooVar152.getClass();
                        ooVar152.Oby7UOJk982.setText("");
                        break;
                }
            }
        });
        oo ooVar19 = this.Aj3vze09p9a;
        ooVar19.getClass();
        ooVar19.kLF8MllXouM.setOnScrollChangeListener(new vr(this));
        ZB6EwfQgURM zB6EwfQgURM = this.hTxQJAhmo4j;
        ke0 ke0Var = ((yf0) zB6EwfQgURM.getValue()).nDGTvOUPAhx;
        p6 p6Var = (p6) ke0Var.Ndt5adT1n2F();
        ke0Var.iQvCvXTWXYz(null);
        if (p6Var != null) {
            ke0 ke0Var2 = D5vWTmG37B7().wJXRvW1l9At;
            ke0Var2.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var2.Ndt5adT1n2F(), null, null, false, null, p6Var, 15));
        }
        ke0 ke0Var3 = ((yf0) zB6EwfQgURM.getValue()).kheiy7RMk6s;
        String str = (String) ke0Var3.Ndt5adT1n2F();
        ke0Var3.iQvCvXTWXYz(null);
        if (str != null) {
            ke0 ke0Var4 = D5vWTmG37B7().wJXRvW1l9At;
            ke0Var4.ocrRjEg1xWE(null, o6.HgCgyIrsRhc((o6) ke0Var4.Ndt5adT1n2F(), str, null, false, null, null, 30));
        }
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ocrRjEg1xWE, new kd0(this, 9));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().kLF8MllXouM, new kd0(this, 10));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().miDHqavGimy, new kd0(this, 11));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().Oby7UOJk982, new kd0(this, i3));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().H8bE8XWjtoS, new kd0(this, i4));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().Ndt5adT1n2F, new kd0(this, i2));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().ykVrBoeh7sI, new kd0(this, 4));
        ud0 ud0VarD5vWTmG37B7 = D5vWTmG37B7();
        vi0.I538XrPZXnv(mn0.I538XrPZXnv(ud0VarD5vWTmG37B7), null, new z80(ud0VarD5vWTmG37B7, Calendar.getInstance().get(11), jbVar, i3), 3);
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        ee0 ee0Var = this.cVDN2FegiBA;
        if (ee0Var != null) {
            ee0Var.wJXRvW1l9At(null);
        }
        this.cVDN2FegiBA = null;
        x8 x8Var = this.XHl2g3c24mc;
        if (x8Var != null) {
            x8Var.dismiss();
        }
        this.XHl2g3c24mc = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((pd0) nDGTvOUPAhx()).getClass();
    }

    public final void hSdjhQTBcYv() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        hSdjhQTBcYv();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((pd0) nDGTvOUPAhx()).getClass();
    }
}
