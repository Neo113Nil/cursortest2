package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.kolosta.rejin.kiltor.R;
import com.kolosta.rejin.kiltor.presentation.ui.RoundPlayFragment;
import defpackage.ZB6EwfQgURM;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.es;
import defpackage.f90;
import defpackage.ft;
import defpackage.g90;
import defpackage.j3;
import defpackage.jc;
import defpackage.kc;
import defpackage.l4;
import defpackage.l80;
import defpackage.lc;
import defpackage.n4;
import defpackage.nh0;
import defpackage.pn;
import defpackage.rk0;
import defpackage.rq;
import defpackage.t80;
import defpackage.t90;
import defpackage.vi0;
import defpackage.w80;
import defpackage.x8;
import defpackage.x80;
import defpackage.y60;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class RoundPlayFragment extends bn implements rq {
    public nh0 Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public x8 XHl2g3c24mc;
    public final l4 cVDN2FegiBA;
    public final ZB6EwfQgURM hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public RoundPlayFragment() {
        int i = 0;
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(6, new w80(this, 3)));
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(f90.class), new kc(ctVarC48z5w8gjNK, 8), new lc(this, ctVarC48z5w8gjNK, 4), new kc(ctVarC48z5w8gjNK, 9));
        this.hTxQJAhmo4j = new ZB6EwfQgURM(y60.HgCgyIrsRhc(t90.class), new w80(this, i), new w80(this, 2), new w80(this, 1));
        this.cVDN2FegiBA = new l4(new t80(this, i));
    }

    public final void D5vWTmG37B7() {
        int iIntValue = ((Number) hSdjhQTBcYv().H8bE8XWjtoS.wJXRvW1l9At.Ndt5adT1n2F()).intValue();
        if (iIntValue == 0) {
            return;
        }
        int iIntValue2 = ((Number) hSdjhQTBcYv().kLF8MllXouM.wJXRvW1l9At.Ndt5adT1n2F()).intValue() + 1;
        nh0 nh0Var = this.Aj3vze09p9a;
        nh0Var.getClass();
        nh0Var.HgCgyIrsRhc.setText(Oby7UOJk982(R.string.play_counter_format, Integer.valueOf(iIntValue2), Integer.valueOf(iIntValue)));
        nh0 nh0Var2 = this.Aj3vze09p9a;
        nh0Var2.getClass();
        ((LinearProgressIndicator) nh0Var2.MarFYthBr4b).setMax(iIntValue);
        nh0 nh0Var3 = this.Aj3vze09p9a;
        nh0Var3.getClass();
        ((LinearProgressIndicator) nh0Var3.MarFYthBr4b).setProgress(iIntValue2);
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_round_play, viewGroup, false);
        int i = R.id.play_back;
        MaterialButton materialButton = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.play_back);
        if (materialButton != null) {
            i = R.id.play_confirm;
            MaterialButton materialButton2 = (MaterialButton) g90.kheiy7RMk6s(viewInflate, R.id.play_confirm);
            if (materialButton2 != null) {
                i = R.id.play_counter;
                TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.play_counter);
                if (textView != null) {
                    i = R.id.play_dish_emoji;
                    TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.play_dish_emoji);
                    if (textView2 != null) {
                        i = R.id.play_dish_title;
                        TextView textView3 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.play_dish_title);
                        if (textView3 != null) {
                            i = R.id.play_progress;
                            LinearProgressIndicator linearProgressIndicator = (LinearProgressIndicator) g90.kheiy7RMk6s(viewInflate, R.id.play_progress);
                            if (linearProgressIndicator != null) {
                                i = R.id.play_scroll;
                                if (((NestedScrollView) g90.kheiy7RMk6s(viewInflate, R.id.play_scroll)) != null) {
                                    i = R.id.play_traits;
                                    RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.play_traits);
                                    if (recyclerView != null) {
                                        LinearLayout linearLayout = (LinearLayout) viewInflate;
                                        this.Aj3vze09p9a = new nh0(linearLayout, materialButton, materialButton2, textView, textView2, textView3, linearProgressIndicator, recyclerView);
                                        linearLayout.getClass();
                                        return linearLayout;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        nh0 nh0Var = this.Aj3vze09p9a;
        nh0Var.getClass();
        ((RecyclerView) nh0Var.wJXRvW1l9At).setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        nh0 nh0Var2 = this.Aj3vze09p9a;
        nh0Var2.getClass();
        ((RecyclerView) nh0Var2.wJXRvW1l9At).setItemAnimator(null);
        nh0 nh0Var3 = this.Aj3vze09p9a;
        nh0Var3.getClass();
        ((RecyclerView) nh0Var3.wJXRvW1l9At).setAdapter(this.cVDN2FegiBA);
        nh0 nh0Var4 = this.Aj3vze09p9a;
        nh0Var4.getClass();
        final int i = 1;
        ((MaterialButton) nh0Var4.kheiy7RMk6s).setOnClickListener(new View.OnClickListener(this) { // from class: u80
            public final /* synthetic */ RoundPlayFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2;
                int i3 = i;
                RoundPlayFragment roundPlayFragment = this.Ndt5adT1n2F;
                switch (i3) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        f90 f90VarHSdjhQTBcYv = roundPlayFragment.hSdjhQTBcYv();
                        ke0 ke0Var = f90VarHSdjhQTBcYv.ocrRjEg1xWE;
                        if (((Number) ke0Var.Ndt5adT1n2F()).intValue() == 0) {
                            return;
                        }
                        ke0Var.ocrRjEg1xWE(null, Integer.valueOf(((Number) ke0Var.Ndt5adT1n2F()).intValue() - 1));
                        f90VarHSdjhQTBcYv.wJXRvW1l9At();
                        return;
                    default:
                        f90 f90VarHSdjhQTBcYv2 = roundPlayFragment.hSdjhQTBcYv();
                        LinkedHashMap linkedHashMap = f90VarHSdjhQTBcYv2.Ndt5adT1n2F;
                        ke0 ke0Var2 = f90VarHSdjhQTBcYv2.wJXRvW1l9At;
                        List list = (List) ke0Var2.Ndt5adT1n2F();
                        ke0 ke0Var3 = f90VarHSdjhQTBcYv2.ocrRjEg1xWE;
                        i90 i90Var = (i90) d8.E5JQlYunlmp(list, ((Number) ke0Var3.Ndt5adT1n2F()).intValue());
                        if (i90Var == null) {
                            return;
                        }
                        List list2 = i90Var.kheiy7RMk6s;
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : list2) {
                            if (((w90) obj).kheiy7RMk6s) {
                                arrayList.add(obj);
                            }
                        }
                        ArrayList arrayList2 = new ArrayList(f8.oMjM3NKsTUI(arrayList, 10));
                        int size = arrayList.size();
                        int i4 = 0;
                        while (i4 < size) {
                            Object obj2 = arrayList.get(i4);
                            i4++;
                            arrayList2.add(Integer.valueOf(f90.MarFYthBr4b(((w90) obj2).HgCgyIrsRhc)));
                        }
                        Set setC = d8.c(arrayList2);
                        Set set = (Set) f90VarHSdjhQTBcYv2.ykVrBoeh7sI.Ndt5adT1n2F();
                        Object objNdt5adT1n2F = ke0Var3.Ndt5adT1n2F();
                        ArrayList arrayList3 = new ArrayList();
                        for (Object obj3 : list2) {
                            if (set.contains(Integer.valueOf(f90.MarFYthBr4b(((w90) obj3).HgCgyIrsRhc)))) {
                                arrayList3.add(obj3);
                            }
                        }
                        ArrayList arrayList4 = new ArrayList(f8.oMjM3NKsTUI(arrayList3, 10));
                        int size2 = arrayList3.size();
                        int i5 = 0;
                        while (i5 < size2) {
                            Object obj4 = arrayList3.get(i5);
                            i5++;
                            arrayList4.add(((w90) obj4).nDGTvOUPAhx);
                        }
                        ArrayList arrayList5 = new ArrayList();
                        for (Object obj5 : list2) {
                            if (((w90) obj5).kheiy7RMk6s) {
                                arrayList5.add(obj5);
                            }
                        }
                        ArrayList arrayList6 = new ArrayList(f8.oMjM3NKsTUI(arrayList5, 10));
                        int size3 = arrayList5.size();
                        int i6 = 0;
                        while (i6 < size3) {
                            Object obj6 = arrayList5.get(i6);
                            i6++;
                            arrayList6.add(((w90) obj6).nDGTvOUPAhx);
                        }
                        linkedHashMap.put(objNdt5adT1n2F, new o80(arrayList4, arrayList6, es.kheiy7RMk6s(set, setC)));
                        f90VarHSdjhQTBcYv2.iQvCvXTWXYz.put(ke0Var3.Ndt5adT1n2F(), set);
                        int iIntValue = ((Number) ke0Var3.Ndt5adT1n2F()).intValue();
                        ((List) ke0Var2.Ndt5adT1n2F()).getClass();
                        if (iIntValue != r1.size() - 1) {
                            ke0Var3.ocrRjEg1xWE(null, Integer.valueOf(((Number) ke0Var3.Ndt5adT1n2F()).intValue() + 1));
                            f90VarHSdjhQTBcYv2.wJXRvW1l9At();
                            return;
                        }
                        Collection collectionValues = linkedHashMap.values();
                        if (collectionValues == null || !collectionValues.isEmpty()) {
                            Iterator it = collectionValues.iterator();
                            i2 = 0;
                            while (it.hasNext()) {
                                if (((o80) it.next()).kheiy7RMk6s && (i2 = i2 + 1) < 0) {
                                    throw new ArithmeticException("Count overflow has happened.");
                                }
                            }
                        } else {
                            i2 = 0;
                        }
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(f90VarHSdjhQTBcYv2), null, new z80(f90VarHSdjhQTBcYv2, i2, null, 0), 3);
                        return;
                }
            }
        });
        nh0 nh0Var5 = this.Aj3vze09p9a;
        nh0Var5.getClass();
        final int i2 = 0;
        ((MaterialButton) nh0Var5.nDGTvOUPAhx).setOnClickListener(new View.OnClickListener(this) { // from class: u80
            public final /* synthetic */ RoundPlayFragment Ndt5adT1n2F;

            {
                this.Ndt5adT1n2F = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22;
                int i3 = i2;
                RoundPlayFragment roundPlayFragment = this.Ndt5adT1n2F;
                switch (i3) {
                    case h90.HgCgyIrsRhc /* 0 */:
                        f90 f90VarHSdjhQTBcYv = roundPlayFragment.hSdjhQTBcYv();
                        ke0 ke0Var = f90VarHSdjhQTBcYv.ocrRjEg1xWE;
                        if (((Number) ke0Var.Ndt5adT1n2F()).intValue() == 0) {
                            return;
                        }
                        ke0Var.ocrRjEg1xWE(null, Integer.valueOf(((Number) ke0Var.Ndt5adT1n2F()).intValue() - 1));
                        f90VarHSdjhQTBcYv.wJXRvW1l9At();
                        return;
                    default:
                        f90 f90VarHSdjhQTBcYv2 = roundPlayFragment.hSdjhQTBcYv();
                        LinkedHashMap linkedHashMap = f90VarHSdjhQTBcYv2.Ndt5adT1n2F;
                        ke0 ke0Var2 = f90VarHSdjhQTBcYv2.wJXRvW1l9At;
                        List list = (List) ke0Var2.Ndt5adT1n2F();
                        ke0 ke0Var3 = f90VarHSdjhQTBcYv2.ocrRjEg1xWE;
                        i90 i90Var = (i90) d8.E5JQlYunlmp(list, ((Number) ke0Var3.Ndt5adT1n2F()).intValue());
                        if (i90Var == null) {
                            return;
                        }
                        List list2 = i90Var.kheiy7RMk6s;
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : list2) {
                            if (((w90) obj).kheiy7RMk6s) {
                                arrayList.add(obj);
                            }
                        }
                        ArrayList arrayList2 = new ArrayList(f8.oMjM3NKsTUI(arrayList, 10));
                        int size = arrayList.size();
                        int i4 = 0;
                        while (i4 < size) {
                            Object obj2 = arrayList.get(i4);
                            i4++;
                            arrayList2.add(Integer.valueOf(f90.MarFYthBr4b(((w90) obj2).HgCgyIrsRhc)));
                        }
                        Set setC = d8.c(arrayList2);
                        Set set = (Set) f90VarHSdjhQTBcYv2.ykVrBoeh7sI.Ndt5adT1n2F();
                        Object objNdt5adT1n2F = ke0Var3.Ndt5adT1n2F();
                        ArrayList arrayList3 = new ArrayList();
                        for (Object obj3 : list2) {
                            if (set.contains(Integer.valueOf(f90.MarFYthBr4b(((w90) obj3).HgCgyIrsRhc)))) {
                                arrayList3.add(obj3);
                            }
                        }
                        ArrayList arrayList4 = new ArrayList(f8.oMjM3NKsTUI(arrayList3, 10));
                        int size2 = arrayList3.size();
                        int i5 = 0;
                        while (i5 < size2) {
                            Object obj4 = arrayList3.get(i5);
                            i5++;
                            arrayList4.add(((w90) obj4).nDGTvOUPAhx);
                        }
                        ArrayList arrayList5 = new ArrayList();
                        for (Object obj5 : list2) {
                            if (((w90) obj5).kheiy7RMk6s) {
                                arrayList5.add(obj5);
                            }
                        }
                        ArrayList arrayList6 = new ArrayList(f8.oMjM3NKsTUI(arrayList5, 10));
                        int size3 = arrayList5.size();
                        int i6 = 0;
                        while (i6 < size3) {
                            Object obj6 = arrayList5.get(i6);
                            i6++;
                            arrayList6.add(((w90) obj6).nDGTvOUPAhx);
                        }
                        linkedHashMap.put(objNdt5adT1n2F, new o80(arrayList4, arrayList6, es.kheiy7RMk6s(set, setC)));
                        f90VarHSdjhQTBcYv2.iQvCvXTWXYz.put(ke0Var3.Ndt5adT1n2F(), set);
                        int iIntValue = ((Number) ke0Var3.Ndt5adT1n2F()).intValue();
                        ((List) ke0Var2.Ndt5adT1n2F()).getClass();
                        if (iIntValue != r1.size() - 1) {
                            ke0Var3.ocrRjEg1xWE(null, Integer.valueOf(((Number) ke0Var3.Ndt5adT1n2F()).intValue() + 1));
                            f90VarHSdjhQTBcYv2.wJXRvW1l9At();
                            return;
                        }
                        Collection collectionValues = linkedHashMap.values();
                        if (collectionValues == null || !collectionValues.isEmpty()) {
                            Iterator it = collectionValues.iterator();
                            i22 = 0;
                            while (it.hasNext()) {
                                if (((o80) it.next()).kheiy7RMk6s && (i22 = i22 + 1) < 0) {
                                    throw new ArithmeticException("Count overflow has happened.");
                                }
                            }
                        } else {
                            i22 = 0;
                        }
                        vi0.I538XrPZXnv(mn0.I538XrPZXnv(f90VarHSdjhQTBcYv2), null, new z80(f90VarHSdjhQTBcYv2, i22, null, 0), 3);
                        return;
                }
            }
        });
        yOSzBmjeOMj().ocrRjEg1xWE().HgCgyIrsRhc(miDHqavGimy(), new pn(this));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().WGVIMf7e7f9, new t80(this, i));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().uCRx9YCOc24, new t80(this, 2));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().Zrl8J6Z2Dje, new t80(this, 3));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().lJCHxZXkFBB, new t80(this, 4));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().n7QsYWNZtSU, new t80(this, 5));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().kLF8MllXouM, new t80(this, 6));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().H8bE8XWjtoS, new t80(this, 7));
        vi0.MarFYthBr4b(this, hSdjhQTBcYv().miDHqavGimy, new t80(this, 8));
    }

    public final void V73zDzxkiRf() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        x8 x8Var = this.XHl2g3c24mc;
        if (x8Var != null) {
            x8Var.dismiss();
        }
        this.XHl2g3c24mc = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        V73zDzxkiRf();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((x80) nDGTvOUPAhx()).getClass();
    }

    public final f90 hSdjhQTBcYv() {
        return (f90) this.E5JQlYunlmp.getValue();
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        V73zDzxkiRf();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        V73zDzxkiRf();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((x80) nDGTvOUPAhx()).getClass();
    }
}
