package com.kolosta.rejin.kiltor.presentation.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.kolosta.rejin.kiltor.R;
import defpackage.SO78vOEPH7q;
import defpackage.ZB6EwfQgURM;
import defpackage.a;
import defpackage.ad;
import defpackage.bd;
import defpackage.bn;
import defpackage.cl0;
import defpackage.ct;
import defpackage.es;
import defpackage.ft;
import defpackage.fx;
import defpackage.g90;
import defpackage.hn;
import defpackage.id;
import defpackage.j3;
import defpackage.jc;
import defpackage.kc;
import defpackage.ke0;
import defpackage.l4;
import defpackage.l80;
import defpackage.lc;
import defpackage.n4;
import defpackage.q30;
import defpackage.rk0;
import defpackage.rq;
import defpackage.vi0;
import defpackage.w8;
import defpackage.x8;
import defpackage.y60;
import defpackage.yf0;
import defpackage.zc;
import defpackage.zc0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public final class CurryPassportFragment extends bn implements rq {
    public hn Aj3vze09p9a;
    public final ZB6EwfQgURM E5JQlYunlmp;
    public rk0 RM9erU4r8X4;
    public x8 XHl2g3c24mc;
    public final fx Ypoyc6CSuwk;
    public final fx cVDN2FegiBA;
    public final ZB6EwfQgURM hTxQJAhmo4j;
    public volatile j3 jUlElzv2pxm;
    public final fx pDfwYwzMf5H;
    public final l4 tzA8uRWBsm9;
    public boolean EIfOZATD9S5 = false;
    public final Object LmIqotBJiHb = new Object();
    public boolean bAzqD1FiMET = false;

    public CurryPassportFragment() {
        ct ctVarC48z5w8gjNK = es.C48z5w8gjNK(ft.Ndt5adT1n2F, new jc(1, new ad(this, 3)));
        this.E5JQlYunlmp = new ZB6EwfQgURM(y60.HgCgyIrsRhc(id.class), new kc(ctVarC48z5w8gjNK, 2), new lc(this, ctVarC48z5w8gjNK, 1), new kc(ctVarC48z5w8gjNK, 3));
        this.hTxQJAhmo4j = new ZB6EwfQgURM(y60.HgCgyIrsRhc(yf0.class), new ad(this, 0), new ad(this, 2), new ad(this, 1));
        this.cVDN2FegiBA = new fx(new zc0(new a(18), false), 0);
        this.pDfwYwzMf5H = new fx(new zc0(new q30(2), false), 1);
        this.Ypoyc6CSuwk = new fx(new zc0(new q30(9), false), 4);
        this.tzA8uRWBsm9 = new l4(new zc(this, 0));
    }

    public final id D5vWTmG37B7() {
        return (id) this.E5JQlYunlmp.getValue();
    }

    @Override // defpackage.bn
    public final LayoutInflater I538XrPZXnv(Bundle bundle) {
        LayoutInflater layoutInflaterI538XrPZXnv = super.I538XrPZXnv(bundle);
        return layoutInflaterI538XrPZXnv.cloneInContext(new rk0(layoutInflaterI538XrPZXnv, this));
    }

    @Override // defpackage.bn
    public final View P56qh5C3eoK(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        layoutInflater.getClass();
        View viewInflate = layoutInflater.inflate(R.layout.fragment_curry_passport, viewGroup, false);
        int i = R.id.passport_afternoon;
        TextView textView = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.passport_afternoon);
        if (textView != null) {
            i = R.id.passport_avatar;
            TextView textView2 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.passport_avatar);
            if (textView2 != null) {
                i = R.id.passport_evening;
                TextView textView3 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.passport_evening);
                if (textView3 != null) {
                    i = R.id.passport_habits;
                    RecyclerView recyclerView = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.passport_habits);
                    if (recyclerView != null) {
                        i = R.id.passport_habits_empty;
                        LinearLayout linearLayout = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.passport_habits_empty);
                        if (linearLayout != null) {
                            i = R.id.passport_history;
                            RecyclerView recyclerView2 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.passport_history);
                            if (recyclerView2 != null) {
                                i = R.id.passport_history_empty;
                                LinearLayout linearLayout2 = (LinearLayout) g90.kheiy7RMk6s(viewInflate, R.id.passport_history_empty);
                                if (linearLayout2 != null) {
                                    i = R.id.passport_morning;
                                    TextView textView4 = (TextView) g90.kheiy7RMk6s(viewInflate, R.id.passport_morning);
                                    if (textView4 != null) {
                                        i = R.id.passport_quests;
                                        RecyclerView recyclerView3 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.passport_quests);
                                        if (recyclerView3 != null) {
                                            i = R.id.passport_regions;
                                            RecyclerView recyclerView4 = (RecyclerView) g90.kheiy7RMk6s(viewInflate, R.id.passport_regions);
                                            if (recyclerView4 != null) {
                                                NestedScrollView nestedScrollView = (NestedScrollView) viewInflate;
                                                this.Aj3vze09p9a = new hn(nestedScrollView, textView, textView2, textView3, recyclerView, linearLayout, recyclerView2, linearLayout2, textView4, recyclerView3, recyclerView4, nestedScrollView);
                                                nestedScrollView.getClass();
                                                return nestedScrollView;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        n4.WGVIMf7e7f9("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    @Override // defpackage.bn
    public final void RD9v7iCsyVj(View view) {
        view.getClass();
        hn hnVar = this.Aj3vze09p9a;
        hnVar.getClass();
        ((RecyclerView) hnVar.brBhnf7Rph0).setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        hn hnVar2 = this.Aj3vze09p9a;
        hnVar2.getClass();
        ((RecyclerView) hnVar2.brBhnf7Rph0).setItemAnimator(null);
        hn hnVar3 = this.Aj3vze09p9a;
        hnVar3.getClass();
        ((RecyclerView) hnVar3.brBhnf7Rph0).setAdapter(this.cVDN2FegiBA);
        hn hnVar4 = this.Aj3vze09p9a;
        hnVar4.getClass();
        ((RecyclerView) hnVar4.Ndt5adT1n2F).setLayoutManager(new GridLayoutManager(XB6ioTeWZY2(), 4));
        hn hnVar5 = this.Aj3vze09p9a;
        hnVar5.getClass();
        ((RecyclerView) hnVar5.Ndt5adT1n2F).setItemAnimator(null);
        hn hnVar6 = this.Aj3vze09p9a;
        hnVar6.getClass();
        ((RecyclerView) hnVar6.Ndt5adT1n2F).setAdapter(this.tzA8uRWBsm9);
        hn hnVar7 = this.Aj3vze09p9a;
        hnVar7.getClass();
        ((RecyclerView) hnVar7.MarFYthBr4b).setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        hn hnVar8 = this.Aj3vze09p9a;
        hnVar8.getClass();
        ((RecyclerView) hnVar8.MarFYthBr4b).setItemAnimator(null);
        hn hnVar9 = this.Aj3vze09p9a;
        hnVar9.getClass();
        ((RecyclerView) hnVar9.MarFYthBr4b).setAdapter(this.Ypoyc6CSuwk);
        hn hnVar10 = this.Aj3vze09p9a;
        hnVar10.getClass();
        ((RecyclerView) hnVar10.wJXRvW1l9At).setLayoutManager(new LinearLayoutManager(XB6ioTeWZY2()));
        hn hnVar11 = this.Aj3vze09p9a;
        hnVar11.getClass();
        ((RecyclerView) hnVar11.wJXRvW1l9At).setItemAnimator(null);
        hn hnVar12 = this.Aj3vze09p9a;
        hnVar12.getClass();
        ((RecyclerView) hnVar12.wJXRvW1l9At).setAdapter(this.pDfwYwzMf5H);
        hn hnVar13 = this.Aj3vze09p9a;
        hnVar13.getClass();
        ((TextView) hnVar13.nDGTvOUPAhx).setOnClickListener(new w8(this, 2));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().aBUhIZ95pth, new zc(this, 2));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().brBhnf7Rph0, new zc(this, 3));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().MarFYthBr4b, new zc(this, 4));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().wJXRvW1l9At, new zc(this, 5));
        vi0.MarFYthBr4b(this, D5vWTmG37B7().Ndt5adT1n2F, new zc(this, 6));
        ke0 ke0Var = ((yf0) this.hTxQJAhmo4j.getValue()).aBUhIZ95pth;
        Boolean bool = (Boolean) ke0Var.Ndt5adT1n2F();
        bool.getClass();
        ke0Var.ocrRjEg1xWE(null, Boolean.FALSE);
        if (bool.booleanValue()) {
            hn hnVar14 = this.Aj3vze09p9a;
            hnVar14.getClass();
            ((NestedScrollView) hnVar14.ocrRjEg1xWE).post(new SO78vOEPH7q(6, this));
        }
    }

    @Override // defpackage.bn, defpackage.fr
    public final cl0 aBUhIZ95pth() {
        return vi0.lJCHxZXkFBB(this, super.aBUhIZ95pth());
    }

    @Override // defpackage.bn
    public final void fVTKpwokKnY() {
        this.XB6ioTeWZY2 = true;
        x8 x8Var = this.XHl2g3c24mc;
        if (x8Var != null) {
            x8Var.dismiss();
        }
        this.XHl2g3c24mc = null;
        this.Aj3vze09p9a = null;
    }

    @Override // defpackage.bn
    public final void g0egR5i1XsF(Activity activity) {
        this.XB6ioTeWZY2 = true;
        rk0 rk0Var = this.RM9erU4r8X4;
        es.iQvCvXTWXYz(rk0Var == null || j3.kheiy7RMk6s(rk0Var) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((bd) nDGTvOUPAhx()).getClass();
    }

    public final void hSdjhQTBcYv() {
        if (this.RM9erU4r8X4 == null) {
            this.RM9erU4r8X4 = new rk0(super.ykVrBoeh7sI(), this);
            this.EIfOZATD9S5 = l80.I538XrPZXnv(super.ykVrBoeh7sI());
        }
    }

    @Override // defpackage.qq
    public final Object nDGTvOUPAhx() {
        if (this.jUlElzv2pxm == null) {
            synchronized (this.LmIqotBJiHb) {
                try {
                    if (this.jUlElzv2pxm == null) {
                        this.jUlElzv2pxm = new j3(this);
                    }
                } finally {
                }
            }
        }
        return this.jUlElzv2pxm.nDGTvOUPAhx();
    }

    @Override // defpackage.bn
    public final Context ykVrBoeh7sI() {
        if (super.ykVrBoeh7sI() == null && !this.EIfOZATD9S5) {
            return null;
        }
        hSdjhQTBcYv();
        return this.RM9erU4r8X4;
    }

    @Override // defpackage.bn
    public final void z7hVgGhB3r5(Context context) {
        super.z7hVgGhB3r5(context);
        hSdjhQTBcYv();
        if (this.bAzqD1FiMET) {
            return;
        }
        this.bAzqD1FiMET = true;
        ((bd) nDGTvOUPAhx()).getClass();
    }
}
