package com.google.android.material.navigation;

import android.R;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Pair;
import android.util.Property;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.focus.FocusRingDrawable;
import com.google.android.material.internal.NavigationMenuView;
import defpackage.MarFYthBr4b;
import defpackage.bc0;
import defpackage.c00;
import defpackage.c2;
import defpackage.cc0;
import defpackage.e80;
import defpackage.eb0;
import defpackage.ef0;
import defpackage.el;
import defpackage.es;
import defpackage.ew;
import defpackage.f00;
import defpackage.fw;
import defpackage.g3;
import defpackage.hk0;
import defpackage.i0;
import defpackage.i00;
import defpackage.ii;
import defpackage.ix;
import defpackage.j00;
import defpackage.k00;
import defpackage.l00;
import defpackage.lf;
import defpackage.m4;
import defpackage.mi;
import defpackage.mn0;
import defpackage.n4;
import defpackage.nc0;
import defpackage.ni;
import defpackage.pc0;
import defpackage.pv;
import defpackage.qc0;
import defpackage.qk0;
import defpackage.s40;
import defpackage.tx;
import defpackage.uz;
import defpackage.vi0;
import defpackage.vw;
import defpackage.ww;
import defpackage.xw;
import defpackage.xz;
import defpackage.zd;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class NavigationView extends eb0 implements ew {
    public static final int[] OcCEV0cN9EJ = {R.attr.state_checked};
    public static final int[] yOSzBmjeOMj = {-16842910};
    public boolean C48z5w8gjNK;
    public final boolean D57UaHJBpF2;
    public final f00 H8bE8XWjtoS;
    public final int I538XrPZXnv;
    public final xw IVXw3Dlz2AG;
    public cc0 JyMrFevGyEE;
    public boolean P56qh5C3eoK;
    public final pv RD9v7iCsyVj;
    public final int[] WGVIMf7e7f9;
    public final g3 ZNZD85DkjoE;
    public final int Zrl8J6Z2Dje;
    public int fVTKpwokKnY;
    public boolean g0egR5i1XsF;
    public ef0 lJCHxZXkFBB;
    public final nc0 mYvwaIfm0QL;
    public final uz miDHqavGimy;
    public final c2 n7QsYWNZtSU;
    public final j00 rAQLLnQzyBa;
    public k00 uCRx9YCOc24;
    public boolean z7hVgGhB3r5;

    /* JADX WARN: Illegal instructions before constructor call */
    /* JADX WARN: Removed duplicated region for block: B:65:0x01d7 A[PHI: r11
      0x01d7: PHI (r11v3 android.graphics.drawable.Drawable) = 
      (r11v2 android.graphics.drawable.Drawable)
      (r11v6 android.graphics.drawable.Drawable)
      (r11v2 android.graphics.drawable.Drawable)
     binds: [B:54:0x018e, B:60:0x01b4, B:58:0x019e] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public NavigationView(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        g3 g3Var;
        int i;
        Context contextWBZqWeQU8tl = vi0.wBZqWeQU8tl(context, attributeSet, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_NavigationView);
        super(contextWBZqWeQU8tl, attributeSet, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle);
        this.iQvCvXTWXYz = new Rect();
        int i2 = 1;
        this.ykVrBoeh7sI = true;
        this.ocrRjEg1xWE = true;
        this.kLF8MllXouM = true;
        this.Oby7UOJk982 = true;
        TypedArray typedArrayD57UaHJBpF2 = es.D57UaHJBpF2(contextWBZqWeQU8tl, attributeSet, s40.g0egR5i1XsF, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_ScrimInsetsFrameLayout, new int[0]);
        this.wJXRvW1l9At = typedArrayD57UaHJBpF2.getDrawable(0);
        typedArrayD57UaHJBpF2.recycle();
        setWillNotDraw(true);
        i00 i00Var = new i00(this);
        WeakHashMap weakHashMap = qk0.HgCgyIrsRhc;
        hk0.kheiy7RMk6s(this, i00Var);
        f00 f00Var = new f00();
        this.H8bE8XWjtoS = f00Var;
        this.WGVIMf7e7f9 = new int[2];
        this.g0egR5i1XsF = true;
        this.z7hVgGhB3r5 = true;
        this.C48z5w8gjNK = true;
        this.P56qh5C3eoK = true;
        this.fVTKpwokKnY = 0;
        this.mYvwaIfm0QL = Build.VERSION.SDK_INT >= 33 ? new qc0(this) : new pc0(this);
        this.IVXw3Dlz2AG = new xw(this);
        this.ZNZD85DkjoE = new g3(this);
        this.RD9v7iCsyVj = new pv(i2, this);
        this.rAQLLnQzyBa = new j00(this);
        Context context2 = getContext();
        uz uzVar = new uz(context2);
        this.miDHqavGimy = uzVar;
        es.brBhnf7Rph0(context2, attributeSet, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_NavigationView);
        int[] iArr = s40.n7QsYWNZtSU;
        es.ykVrBoeh7sI(context2, attributeSet, iArr, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_NavigationView, new int[0]);
        TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, iArr, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_NavigationView);
        g3 g3Var2 = new g3(context2, typedArrayObtainStyledAttributes);
        if (typedArrayObtainStyledAttributes.hasValue(1)) {
            setBackground(g3Var2.Zrl8J6Z2Dje(1));
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(7, 0);
        this.fVTKpwokKnY = dimensionPixelSize;
        this.D57UaHJBpF2 = dimensionPixelSize == 0;
        this.I538XrPZXnv = getResources().getDimensionPixelSize(com.kolosta.rejin.kiltor.R.dimen.m3_navigation_drawer_layout_corner_size);
        Drawable background = getBackground();
        ColorStateList colorStateListZrl8J6Z2Dje = vi0.Zrl8J6Z2Dje(background);
        if (background == null || colorStateListZrl8J6Z2Dje != null) {
            vw vwVar = new vw(cc0.MarFYthBr4b(context2, attributeSet, com.kolosta.rejin.kiltor.R.attr.navigationViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_Design_NavigationView).HgCgyIrsRhc());
            if (colorStateListZrl8J6Z2Dje != null) {
                vwVar.miDHqavGimy(colorStateListZrl8J6Z2Dje);
            }
            vwVar.ykVrBoeh7sI(context2);
            setBackground(vwVar);
        }
        if (typedArrayObtainStyledAttributes.hasValue(8)) {
            setElevation(typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0));
        }
        setFitsSystemWindows(typedArrayObtainStyledAttributes.getBoolean(2, false));
        this.Zrl8J6Z2Dje = typedArrayObtainStyledAttributes.getDimensionPixelSize(3, 0);
        ColorStateList colorStateListUCRx9YCOc24 = typedArrayObtainStyledAttributes.hasValue(33) ? g3Var2.uCRx9YCOc24(33) : null;
        int resourceId = typedArrayObtainStyledAttributes.hasValue(36) ? typedArrayObtainStyledAttributes.getResourceId(36, 0) : 0;
        if (resourceId == 0 && colorStateListUCRx9YCOc24 == null) {
            colorStateListUCRx9YCOc24 = brBhnf7Rph0(R.attr.textColorSecondary);
        }
        ColorStateList colorStateListUCRx9YCOc242 = typedArrayObtainStyledAttributes.hasValue(15) ? g3Var2.uCRx9YCOc24(15) : brBhnf7Rph0(R.attr.textColorSecondary);
        int resourceId2 = typedArrayObtainStyledAttributes.hasValue(25) ? typedArrayObtainStyledAttributes.getResourceId(25, 0) : 0;
        boolean z = typedArrayObtainStyledAttributes.getBoolean(26, true);
        if (typedArrayObtainStyledAttributes.hasValue(14)) {
            setItemIconSize(typedArrayObtainStyledAttributes.getDimensionPixelSize(14, 0));
        }
        ColorStateList colorStateListUCRx9YCOc243 = typedArrayObtainStyledAttributes.hasValue(27) ? g3Var2.uCRx9YCOc24(27) : null;
        if (resourceId2 == 0 && colorStateListUCRx9YCOc243 == null) {
            colorStateListUCRx9YCOc243 = brBhnf7Rph0(R.attr.textColorPrimary);
        }
        Drawable drawableZrl8J6Z2Dje = g3Var2.Zrl8J6Z2Dje(11);
        if (drawableZrl8J6Z2Dje == null && (typedArrayObtainStyledAttributes.hasValue(18) || typedArrayObtainStyledAttributes.hasValue(19))) {
            drawableZrl8J6Z2Dje = MarFYthBr4b(g3Var2, mn0.g0egR5i1XsF(getContext(), g3Var2, 20));
            ColorStateList colorStateListG0egR5i1XsF = mn0.g0egR5i1XsF(context2, g3Var2, 17);
            if (colorStateListG0egR5i1XsF != null) {
                g3Var = g3Var2;
                RippleDrawable rippleDrawable = new RippleDrawable(e80.nDGTvOUPAhx(colorStateListG0egR5i1XsF), null, MarFYthBr4b(g3Var2, null));
                FocusRingDrawable focusRingDrawableBrBhnf7Rph0 = FocusRingDrawable.brBhnf7Rph0(context2, rippleDrawable, null);
                if (focusRingDrawableBrBhnf7Rph0 != null) {
                    focusRingDrawableBrBhnf7Rph0.g0egR5i1XsF.n7QsYWNZtSU = this.JyMrFevGyEE;
                }
                f00Var.n7QsYWNZtSU = rippleDrawable;
                f00Var.iQvCvXTWXYz();
            }
        } else {
            g3Var = g3Var2;
        }
        if (typedArrayObtainStyledAttributes.hasValue(12)) {
            i = 0;
            setItemHorizontalPadding(typedArrayObtainStyledAttributes.getDimensionPixelSize(12, 0));
        } else {
            i = 0;
        }
        if (typedArrayObtainStyledAttributes.hasValue(28)) {
            setItemVerticalPadding(typedArrayObtainStyledAttributes.getDimensionPixelSize(28, i));
        }
        setDividerInsetStart(typedArrayObtainStyledAttributes.getDimensionPixelSize(6, i));
        setDividerInsetEnd(typedArrayObtainStyledAttributes.getDimensionPixelSize(5, i));
        setSubheaderInsetStart(typedArrayObtainStyledAttributes.getDimensionPixelSize(35, i));
        setSubheaderInsetEnd(typedArrayObtainStyledAttributes.getDimensionPixelSize(34, i));
        setTopInsetScrimEnabled(typedArrayObtainStyledAttributes.getBoolean(37, this.g0egR5i1XsF));
        setBottomInsetScrimEnabled(typedArrayObtainStyledAttributes.getBoolean(4, this.z7hVgGhB3r5));
        setStartInsetScrimEnabled(typedArrayObtainStyledAttributes.getBoolean(32, this.C48z5w8gjNK));
        setEndInsetScrimEnabled(typedArrayObtainStyledAttributes.getBoolean(9, this.P56qh5C3eoK));
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, 0);
        setItemMaxLines(typedArrayObtainStyledAttributes.getInt(16, 1));
        uzVar.brBhnf7Rph0 = new i00(this);
        f00Var.ykVrBoeh7sI = 1;
        f00Var.ykVrBoeh7sI(context2, uzVar);
        if (resourceId != 0) {
            f00Var.Oby7UOJk982 = resourceId;
            f00Var.aBUhIZ95pth();
        }
        f00Var.miDHqavGimy = colorStateListUCRx9YCOc24;
        f00Var.aBUhIZ95pth();
        f00Var.WGVIMf7e7f9 = colorStateListUCRx9YCOc242;
        f00Var.iQvCvXTWXYz();
        int overScrollMode = getOverScrollMode();
        f00Var.OcCEV0cN9EJ = overScrollMode;
        NavigationMenuView navigationMenuView = f00Var.wJXRvW1l9At;
        if (navigationMenuView != null) {
            navigationMenuView.setOverScrollMode(overScrollMode);
        }
        if (resourceId2 != 0) {
            f00Var.H8bE8XWjtoS = resourceId2;
            f00Var.iQvCvXTWXYz();
        }
        f00Var.uCRx9YCOc24 = z;
        f00Var.iQvCvXTWXYz();
        f00Var.Zrl8J6Z2Dje = colorStateListUCRx9YCOc243;
        f00Var.iQvCvXTWXYz();
        f00Var.lJCHxZXkFBB = drawableZrl8J6Z2Dje;
        f00Var.iQvCvXTWXYz();
        f00Var.C48z5w8gjNK = dimensionPixelSize2;
        f00Var.iQvCvXTWXYz();
        uzVar.nDGTvOUPAhx(f00Var, uzVar.HgCgyIrsRhc);
        if (f00Var.wJXRvW1l9At == null) {
            NavigationMenuView navigationMenuView2 = (NavigationMenuView) f00Var.kLF8MllXouM.inflate(com.kolosta.rejin.kiltor.R.layout.design_navigation_menu, (ViewGroup) this, false);
            f00Var.wJXRvW1l9At = navigationMenuView2;
            navigationMenuView2.setAccessibilityDelegateCompat(new c00(f00Var, f00Var.wJXRvW1l9At));
            if (f00Var.ocrRjEg1xWE == null) {
                xz xzVar = new xz(f00Var);
                f00Var.ocrRjEg1xWE = xzVar;
                if (xzVar.HgCgyIrsRhc.HgCgyIrsRhc()) {
                    n4.C48z5w8gjNK("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
                    throw null;
                }
                xzVar.nDGTvOUPAhx = true;
            }
            int i3 = f00Var.OcCEV0cN9EJ;
            if (i3 != -1) {
                f00Var.wJXRvW1l9At.setOverScrollMode(i3);
            }
            LinearLayout linearLayout = (LinearLayout) f00Var.kLF8MllXouM.inflate(com.kolosta.rejin.kiltor.R.layout.design_navigation_item_header, (ViewGroup) f00Var.wJXRvW1l9At, false);
            f00Var.Ndt5adT1n2F = linearLayout;
            linearLayout.setImportantForAccessibility(2);
            f00Var.wJXRvW1l9At.setAdapter(f00Var.ocrRjEg1xWE);
        }
        addView(f00Var.wJXRvW1l9At);
        if (typedArrayObtainStyledAttributes.hasValue(29)) {
            int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(29, 0);
            xz xzVar2 = f00Var.ocrRjEg1xWE;
            if (xzVar2 != null) {
                xzVar2.brBhnf7Rph0 = true;
            }
            getMenuInflater().inflate(resourceId3, uzVar);
            xz xzVar3 = f00Var.ocrRjEg1xWE;
            if (xzVar3 != null) {
                xzVar3.brBhnf7Rph0 = false;
            }
            f00Var.Ndt5adT1n2F();
        }
        if (typedArrayObtainStyledAttributes.hasValue(10)) {
            f00Var.Ndt5adT1n2F.addView(f00Var.kLF8MllXouM.inflate(typedArrayObtainStyledAttributes.getResourceId(10, 0), (ViewGroup) f00Var.Ndt5adT1n2F, false));
            NavigationMenuView navigationMenuView3 = f00Var.wJXRvW1l9At;
            navigationMenuView3.setPadding(0, 0, 0, navigationMenuView3.getPaddingBottom());
        }
        g3Var.RD9v7iCsyVj();
        this.n7QsYWNZtSU = new c2(3, this);
        getViewTreeObserver().addOnGlobalLayoutListener(this.n7QsYWNZtSU);
    }

    private MenuInflater getMenuInflater() {
        ef0 ef0Var = this.lJCHxZXkFBB;
        if (ef0Var != null) {
            return ef0Var;
        }
        ef0 ef0Var2 = new ef0(getContext());
        this.lJCHxZXkFBB = ef0Var2;
        return ef0Var2;
    }

    @Override // defpackage.ew
    public final void HgCgyIrsRhc() {
        int i;
        Pair pairNdt5adT1n2F = Ndt5adT1n2F();
        DrawerLayout drawerLayout = (DrawerLayout) pairNdt5adT1n2F.first;
        xw xwVar = this.IVXw3Dlz2AG;
        m4 m4Var = xwVar.MarFYthBr4b;
        xwVar.MarFYthBr4b = null;
        int i2 = 1;
        if (m4Var == null || Build.VERSION.SDK_INT < 34) {
            drawerLayout.kheiy7RMk6s(this, true);
            return;
        }
        int i3 = ((ii) pairNdt5adT1n2F.second).HgCgyIrsRhc;
        int i4 = ni.HgCgyIrsRhc;
        mi miVar = new mi(drawerLayout, this);
        lf lfVar = new lf(i2, drawerLayout);
        NavigationView navigationView = xwVar.nDGTvOUPAhx;
        boolean z = m4Var.aBUhIZ95pth == 0;
        boolean z2 = (Gravity.getAbsoluteGravity(i3, navigationView.getLayoutDirection()) & 3) == 3;
        float scaleX = navigationView.getScaleX() * navigationView.getWidth();
        ViewGroup.LayoutParams layoutParams = navigationView.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            i = z2 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
        } else {
            i = 0;
        }
        float f = scaleX + i;
        if (z2) {
            f = -f;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(navigationView, (Property<NavigationView, Float>) View.TRANSLATION_X, f);
        objectAnimatorOfFloat.addUpdateListener(lfVar);
        objectAnimatorOfFloat.setInterpolator(new el());
        objectAnimatorOfFloat.setDuration(i0.kheiy7RMk6s(xwVar.kheiy7RMk6s, xwVar.aBUhIZ95pth, m4Var.kheiy7RMk6s));
        objectAnimatorOfFloat.addListener(new ww(xwVar, z, i3));
        objectAnimatorOfFloat.addListener(miVar);
        objectAnimatorOfFloat.start();
    }

    public final InsetDrawable MarFYthBr4b(g3 g3Var, ColorStateList colorStateList) {
        TypedArray typedArray = (TypedArray) g3Var.Ndt5adT1n2F;
        int resourceId = typedArray.getResourceId(18, 0);
        int resourceId2 = typedArray.getResourceId(19, 0);
        Context context = getContext();
        MarFYthBr4b marFYthBr4b = new MarFYthBr4b(0.0f);
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, resourceId);
        if (resourceId2 != 0) {
            contextThemeWrapper.getTheme().applyStyle(resourceId2, true);
        }
        this.JyMrFevGyEE = cc0.wJXRvW1l9At(contextThemeWrapper.obtainStyledAttributes(s40.C48z5w8gjNK), marFYthBr4b).HgCgyIrsRhc();
        vw vwVar = new vw(this.JyMrFevGyEE);
        vwVar.miDHqavGimy(colorStateList);
        return new InsetDrawable((Drawable) vwVar, typedArray.getDimensionPixelSize(23, 0), typedArray.getDimensionPixelSize(24, 0), typedArray.getDimensionPixelSize(22, 0), typedArray.getDimensionPixelSize(21, 0));
    }

    public final Pair Ndt5adT1n2F() {
        ViewParent parent = getParent();
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if ((parent instanceof DrawerLayout) && (layoutParams instanceof ii)) {
            return new Pair((DrawerLayout) parent, (ii) layoutParams);
        }
        n4.C48z5w8gjNK("NavigationView back progress requires the direct parent view to be a DrawerLayout.");
        return null;
    }

    @Override // defpackage.ew
    public final void aBUhIZ95pth() {
        Ndt5adT1n2F();
        xw xwVar = this.IVXw3Dlz2AG;
        NavigationView navigationView = xwVar.nDGTvOUPAhx;
        if (xwVar.MarFYthBr4b == null) {
            Log.w("MaterialBackHelper", "Must call startBackProgress() and updateBackProgress() before cancelBackProgress()");
        }
        m4 m4Var = xwVar.MarFYthBr4b;
        xwVar.MarFYthBr4b = null;
        if (m4Var != null) {
            AnimatorSet animatorSet = new AnimatorSet();
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(navigationView, (Property<NavigationView, Float>) View.SCALE_X, 1.0f);
            Property property = View.SCALE_Y;
            animatorSet.playTogether(objectAnimatorOfFloat, ObjectAnimator.ofFloat(navigationView, (Property<NavigationView, Float>) property, 1.0f));
            if (navigationView != null) {
                for (int i = 0; i < navigationView.getChildCount(); i++) {
                    animatorSet.playTogether(ObjectAnimator.ofFloat(navigationView.getChildAt(i), (Property<View, Float>) property, 1.0f));
                }
            }
            animatorSet.setDuration(xwVar.brBhnf7Rph0);
            animatorSet.start();
        }
        if (!this.D57UaHJBpF2 || this.fVTKpwokKnY == 0) {
            return;
        }
        this.fVTKpwokKnY = 0;
        wJXRvW1l9At(getWidth(), getHeight());
    }

    public final ColorStateList brBhnf7Rph0(int i) throws Resources.NotFoundException {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(i, typedValue, true)) {
            return null;
        }
        ColorStateList colorStateListN7QsYWNZtSU = mn0.n7QsYWNZtSU(getContext(), typedValue.resourceId);
        if (!getContext().getTheme().resolveAttribute(com.kolosta.rejin.kiltor.R.attr.colorPrimary, typedValue, true)) {
            return null;
        }
        int i2 = typedValue.data;
        int defaultColor = colorStateListN7QsYWNZtSU.getDefaultColor();
        int[] iArr = OcCEV0cN9EJ;
        int[] iArr2 = FrameLayout.EMPTY_STATE_SET;
        int[] iArr3 = yOSzBmjeOMj;
        return new ColorStateList(new int[][]{iArr3, iArr, iArr2}, new int[]{colorStateListN7QsYWNZtSU.getColorForState(iArr3, defaultColor), i2, defaultColor});
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        nc0 nc0Var = this.mYvwaIfm0QL;
        Path path = nc0Var.brBhnf7Rph0;
        if (!nc0Var.nDGTvOUPAhx() || path.isEmpty()) {
            super.dispatchDraw(canvas);
            return;
        }
        canvas.save();
        canvas.clipPath(path);
        super.dispatchDraw(canvas);
        canvas.restore();
    }

    public xw getBackHelper() {
        return this.IVXw3Dlz2AG;
    }

    public MenuItem getCheckedItem() {
        return this.H8bE8XWjtoS.ocrRjEg1xWE.aBUhIZ95pth;
    }

    public int getDividerInsetEnd() {
        return this.H8bE8XWjtoS.D57UaHJBpF2;
    }

    public int getDividerInsetStart() {
        return this.H8bE8XWjtoS.fVTKpwokKnY;
    }

    public int getHeaderCount() {
        return this.H8bE8XWjtoS.Ndt5adT1n2F.getChildCount();
    }

    public Drawable getItemBackground() {
        return this.H8bE8XWjtoS.lJCHxZXkFBB;
    }

    public int getItemHorizontalPadding() {
        return this.H8bE8XWjtoS.g0egR5i1XsF;
    }

    public int getItemIconPadding() {
        return this.H8bE8XWjtoS.C48z5w8gjNK;
    }

    public ColorStateList getItemIconTintList() {
        return this.H8bE8XWjtoS.WGVIMf7e7f9;
    }

    public int getItemMaxLines() {
        return this.H8bE8XWjtoS.ZNZD85DkjoE;
    }

    public ColorStateList getItemTextColor() {
        return this.H8bE8XWjtoS.Zrl8J6Z2Dje;
    }

    public int getItemVerticalPadding() {
        return this.H8bE8XWjtoS.z7hVgGhB3r5;
    }

    public Menu getMenu() {
        return this.miDHqavGimy;
    }

    public int getSubheaderInsetEnd() {
        return this.H8bE8XWjtoS.mYvwaIfm0QL;
    }

    public int getSubheaderInsetStart() {
        return this.H8bE8XWjtoS.I538XrPZXnv;
    }

    @Override // defpackage.ew
    public final void kheiy7RMk6s(m4 m4Var) {
        Ndt5adT1n2F();
        this.IVXw3Dlz2AG.MarFYthBr4b = m4Var;
    }

    @Override // defpackage.ew
    public final void nDGTvOUPAhx(m4 m4Var) {
        float f = m4Var.kheiy7RMk6s;
        int i = ((ii) Ndt5adT1n2F().second).HgCgyIrsRhc;
        xw xwVar = this.IVXw3Dlz2AG;
        if (xwVar.MarFYthBr4b == null) {
            Log.w("MaterialBackHelper", "Must call startBackProgress() before updateBackProgress()");
        }
        m4 m4Var2 = xwVar.MarFYthBr4b;
        xwVar.MarFYthBr4b = m4Var;
        if (m4Var2 != null) {
            xwVar.HgCgyIrsRhc(f, m4Var.aBUhIZ95pth == 0, i);
        }
        if (this.D57UaHJBpF2) {
            this.fVTKpwokKnY = i0.kheiy7RMk6s(0, this.I538XrPZXnv, xwVar.HgCgyIrsRhc.getInterpolation(f));
            wJXRvW1l9At(getWidth(), getHeight());
        }
    }

    @Override // defpackage.eb0, android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        fw fwVar;
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof vw) {
            zd.ZNZD85DkjoE(this, (vw) background);
        }
        ViewParent parent = getParent();
        if (parent instanceof DrawerLayout) {
            DrawerLayout drawerLayout = (DrawerLayout) parent;
            j00 j00Var = this.rAQLLnQzyBa;
            j00Var.HgCgyIrsRhc = null;
            drawerLayout.H8bE8XWjtoS(j00Var);
            drawerLayout.HgCgyIrsRhc(j00Var);
            g3 g3Var = this.ZNZD85DkjoE;
            if (((fw) g3Var.Ndt5adT1n2F) != null) {
                pv pvVar = this.RD9v7iCsyVj;
                drawerLayout.H8bE8XWjtoS(pvVar);
                drawerLayout.HgCgyIrsRhc(pvVar);
                if (!DrawerLayout.kLF8MllXouM(this) || (fwVar = (fw) g3Var.Ndt5adT1n2F) == null) {
                    return;
                }
                fwVar.nDGTvOUPAhx((NavigationView) g3Var.iQvCvXTWXYz, (NavigationView) g3Var.ykVrBoeh7sI, true);
            }
        }
    }

    @Override // defpackage.eb0, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalLayoutListener(this.n7QsYWNZtSU);
        ViewParent parent = getParent();
        if (parent instanceof DrawerLayout) {
            DrawerLayout drawerLayout = (DrawerLayout) parent;
            drawerLayout.H8bE8XWjtoS(this.RD9v7iCsyVj);
            drawerLayout.H8bE8XWjtoS(this.rAQLLnQzyBa);
        }
        g3 g3Var = this.ZNZD85DkjoE;
        fw fwVar = (fw) g3Var.Ndt5adT1n2F;
        if (fwVar != null) {
            fwVar.kheiy7RMk6s((NavigationView) g3Var.ykVrBoeh7sI);
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int i3 = this.Zrl8J6Z2Dje;
        if (mode == Integer.MIN_VALUE) {
            i = View.MeasureSpec.makeMeasureSpec(Math.min(View.MeasureSpec.getSize(i), i3), 1073741824);
        } else if (mode == 0) {
            i = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
        }
        super.onMeasure(i, i2);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof l00)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        l00 l00Var = (l00) parcelable;
        super.onRestoreInstanceState(l00Var.wJXRvW1l9At);
        Bundle bundle = l00Var.iQvCvXTWXYz;
        CopyOnWriteArrayList copyOnWriteArrayList = this.miDHqavGimy.g0egR5i1XsF;
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:presenters");
        if (sparseParcelableArray == null || copyOnWriteArrayList.isEmpty()) {
            return;
        }
        Iterator it = copyOnWriteArrayList.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            tx txVar = (tx) weakReference.get();
            if (txVar == null) {
                copyOnWriteArrayList.remove(weakReference);
            } else {
                int id = txVar.getId();
                if (id > 0 && (parcelable2 = (Parcelable) sparseParcelableArray.get(id)) != null) {
                    txVar.brBhnf7Rph0(parcelable2);
                }
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableOby7UOJk982;
        l00 l00Var = new l00(super.onSaveInstanceState());
        Bundle bundle = new Bundle();
        l00Var.iQvCvXTWXYz = bundle;
        CopyOnWriteArrayList copyOnWriteArrayList = this.miDHqavGimy.g0egR5i1XsF;
        if (copyOnWriteArrayList.isEmpty()) {
            return l00Var;
        }
        SparseArray<? extends Parcelable> sparseArray = new SparseArray<>();
        Iterator it = copyOnWriteArrayList.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            tx txVar = (tx) weakReference.get();
            if (txVar == null) {
                copyOnWriteArrayList.remove(weakReference);
            } else {
                int id = txVar.getId();
                if (id > 0 && (parcelableOby7UOJk982 = txVar.Oby7UOJk982()) != null) {
                    sparseArray.put(id, parcelableOby7UOJk982);
                }
            }
        }
        bundle.putSparseParcelableArray("android:menu:presenters", sparseArray);
        return l00Var;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        wJXRvW1l9At(i, i2);
    }

    public void setBottomInsetScrimEnabled(boolean z) {
        this.z7hVgGhB3r5 = z;
    }

    public void setCheckedItem(MenuItem menuItem) {
        MenuItem menuItemFindItem = this.miDHqavGimy.findItem(menuItem.getItemId());
        if (menuItemFindItem == null) {
            n4.Ndt5adT1n2F("Called setCheckedItem(MenuItem) with an item that is not in the current menu.");
        } else {
            this.H8bE8XWjtoS.ocrRjEg1xWE.Ndt5adT1n2F((ix) menuItemFindItem);
        }
    }

    public void setDividerInsetEnd(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.D57UaHJBpF2 = i;
        f00Var.nDGTvOUPAhx();
    }

    public void setDividerInsetStart(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.fVTKpwokKnY = i;
        f00Var.nDGTvOUPAhx();
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        Drawable background = getBackground();
        if (background instanceof vw) {
            ((vw) background).Oby7UOJk982(f);
        }
    }

    public void setEndInsetScrimEnabled(boolean z) {
        this.P56qh5C3eoK = z;
    }

    public void setForceCompatClippingEnabled(boolean z) {
        nc0 nc0Var = this.mYvwaIfm0QL;
        if (z != nc0Var.HgCgyIrsRhc) {
            nc0Var.HgCgyIrsRhc = z;
            nc0Var.HgCgyIrsRhc(this);
        }
    }

    public void setItemBackground(Drawable drawable) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.lJCHxZXkFBB = drawable;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemBackgroundResource(int i) {
        setItemBackground(getContext().getDrawable(i));
    }

    public void setItemHorizontalPadding(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.g0egR5i1XsF = i;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemHorizontalPaddingResource(int i) throws Resources.NotFoundException {
        int dimensionPixelSize = getResources().getDimensionPixelSize(i);
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.g0egR5i1XsF = dimensionPixelSize;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemIconPadding(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.C48z5w8gjNK = i;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemIconPaddingResource(int i) throws Resources.NotFoundException {
        int dimensionPixelSize = getResources().getDimensionPixelSize(i);
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.C48z5w8gjNK = dimensionPixelSize;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemIconSize(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        if (f00Var.P56qh5C3eoK != i) {
            f00Var.P56qh5C3eoK = i;
            f00Var.JyMrFevGyEE = true;
            f00Var.iQvCvXTWXYz();
        }
    }

    public void setItemIconTintList(ColorStateList colorStateList) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.WGVIMf7e7f9 = colorStateList;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemMaxLines(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.ZNZD85DkjoE = i;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemTextAppearance(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.H8bE8XWjtoS = i;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemTextAppearanceActiveBoldEnabled(boolean z) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.uCRx9YCOc24 = z;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemTextColor(ColorStateList colorStateList) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.Zrl8J6Z2Dje = colorStateList;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemVerticalPadding(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.z7hVgGhB3r5 = i;
        f00Var.iQvCvXTWXYz();
    }

    public void setItemVerticalPaddingResource(int i) throws Resources.NotFoundException {
        int dimensionPixelSize = getResources().getDimensionPixelSize(i);
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.z7hVgGhB3r5 = dimensionPixelSize;
        f00Var.iQvCvXTWXYz();
    }

    public void setNavigationItemSelectedListener(k00 k00Var) {
        this.uCRx9YCOc24 = k00Var;
    }

    @Override // android.view.View
    public void setOverScrollMode(int i) {
        super.setOverScrollMode(i);
        f00 f00Var = this.H8bE8XWjtoS;
        if (f00Var != null) {
            f00Var.OcCEV0cN9EJ = i;
            NavigationMenuView navigationMenuView = f00Var.wJXRvW1l9At;
            if (navigationMenuView != null) {
                navigationMenuView.setOverScrollMode(i);
            }
        }
    }

    public void setStartInsetScrimEnabled(boolean z) {
        this.C48z5w8gjNK = z;
    }

    public void setSubheaderInsetEnd(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.mYvwaIfm0QL = i;
        f00Var.aBUhIZ95pth();
    }

    public void setSubheaderInsetStart(int i) {
        f00 f00Var = this.H8bE8XWjtoS;
        f00Var.I538XrPZXnv = i;
        f00Var.aBUhIZ95pth();
    }

    public void setTopInsetScrimEnabled(boolean z) {
        this.g0egR5i1XsF = z;
    }

    public final void wJXRvW1l9At(int i, int i2) {
        if ((getParent() instanceof DrawerLayout) && (getLayoutParams() instanceof ii)) {
            if ((this.fVTKpwokKnY > 0 || this.D57UaHJBpF2) && (getBackground() instanceof vw)) {
                boolean z = Gravity.getAbsoluteGravity(((ii) getLayoutParams()).HgCgyIrsRhc, getLayoutDirection()) == 3;
                vw vwVar = (vw) getBackground();
                bc0 bc0VarYkVrBoeh7sI = vwVar.MarFYthBr4b().ykVrBoeh7sI();
                bc0VarYkVrBoeh7sI.nDGTvOUPAhx(this.fVTKpwokKnY);
                if (z) {
                    bc0VarYkVrBoeh7sI.brBhnf7Rph0 = new MarFYthBr4b(0.0f);
                    bc0VarYkVrBoeh7sI.Ndt5adT1n2F = new MarFYthBr4b(0.0f);
                } else {
                    bc0VarYkVrBoeh7sI.MarFYthBr4b = new MarFYthBr4b(0.0f);
                    bc0VarYkVrBoeh7sI.wJXRvW1l9At = new MarFYthBr4b(0.0f);
                }
                cc0 cc0VarHgCgyIrsRhc = bc0VarYkVrBoeh7sI.HgCgyIrsRhc();
                vwVar.setShapeAppearanceModel(cc0VarHgCgyIrsRhc);
                nc0 nc0Var = this.mYvwaIfm0QL;
                nc0Var.kheiy7RMk6s = cc0VarHgCgyIrsRhc;
                nc0Var.kheiy7RMk6s();
                nc0Var.HgCgyIrsRhc(this);
                nc0Var.aBUhIZ95pth = new RectF(0.0f, 0.0f, i, i2);
                nc0Var.kheiy7RMk6s();
                nc0Var.HgCgyIrsRhc(this);
                nc0Var.nDGTvOUPAhx = true;
                nc0Var.HgCgyIrsRhc(this);
            }
        }
    }

    public void setCheckedItem(int i) {
        MenuItem menuItemFindItem = this.miDHqavGimy.findItem(i);
        if (menuItemFindItem != null) {
            this.H8bE8XWjtoS.ocrRjEg1xWE.Ndt5adT1n2F((ix) menuItemFindItem);
        }
    }

    public NavigationView(Context context) {
        this(context, null);
    }
}
