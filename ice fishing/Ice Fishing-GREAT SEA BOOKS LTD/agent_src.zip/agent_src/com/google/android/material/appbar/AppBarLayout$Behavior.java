package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class AppBarLayout$Behavior extends AppBarLayout$BaseBehavior<Object> {
    public AppBarLayout$Behavior() {
    }

    public AppBarLayout$Behavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
