package com.google.android.material.tabs;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.kolosta.rejin.kiltor.R;
import defpackage.c50;
import defpackage.es;
import defpackage.f20;
import defpackage.f30;
import defpackage.g30;
import defpackage.h5;
import defpackage.i0;
import defpackage.ij;
import defpackage.jl0;
import defpackage.l80;
import defpackage.mn0;
import defpackage.n4;
import defpackage.rf0;
import defpackage.s40;
import defpackage.sa0;
import defpackage.sf0;
import defpackage.uf0;
import defpackage.v90;
import defpackage.vf0;
import defpackage.vi0;
import defpackage.vw;
import defpackage.xf0;
import defpackage.zd;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class TabLayout extends HorizontalScrollView {
    public static final g30 cFNknbO9KWg = new g30();
    public final PorterDuff.Mode C48z5w8gjNK;
    public final float D57UaHJBpF2;
    public int D5vWTmG37B7;
    public final int H8bE8XWjtoS;
    public final int I538XrPZXnv;
    public final int IVXw3Dlz2AG;
    public final ArrayList IYi9Twa3Yjg;
    public final int JyMrFevGyEE;
    public final ArrayList Ndt5adT1n2F;
    public final int Oby7UOJk982;
    public final int OcCEV0cN9EJ;
    public final float P56qh5C3eoK;
    public final int RD9v7iCsyVj;
    public sa0 V73zDzxkiRf;
    public ColorStateList WGVIMf7e7f9;
    public rf0 X0MyC8YR7bY;
    public int XB6ioTeWZY2;
    public final int ZNZD85DkjoE;
    public final int Zrl8J6Z2Dje;
    public final float fVTKpwokKnY;
    public Drawable g0egR5i1XsF;
    public int gVHumS1PT2O;
    public final TimeInterpolator gfMrr7pMNlA;
    public boolean hSdjhQTBcYv;
    public final f30 iFM7bRXghng;
    public vf0 iQvCvXTWXYz;
    public final int kLF8MllXouM;
    public boolean kMJtaEXWLpZ;
    public ColorStateList lJCHxZXkFBB;
    public int mYvwaIfm0QL;
    public final int miDHqavGimy;
    public ColorStateList n7QsYWNZtSU;
    public final int ocrRjEg1xWE;
    public int rAQLLnQzyBa;
    public final int uCRx9YCOc24;
    public ValueAnimator uHy5z3aH4qy;
    public boolean wBZqWeQU8tl;
    public int wJXRvW1l9At;
    public int yOSzBmjeOMj;
    public final uf0 ykVrBoeh7sI;
    public int z7hVgGhB3r5;

    public TabLayout(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        int resourceId;
        super(vi0.wBZqWeQU8tl(context, attributeSet, R.attr.tabStyle, R.style.Widget_Design_TabLayout), attributeSet, R.attr.tabStyle);
        this.wJXRvW1l9At = -1;
        this.Ndt5adT1n2F = new ArrayList();
        this.Zrl8J6Z2Dje = -1;
        this.z7hVgGhB3r5 = 0;
        this.mYvwaIfm0QL = Integer.MAX_VALUE;
        this.gVHumS1PT2O = -1;
        this.IYi9Twa3Yjg = new ArrayList();
        this.iFM7bRXghng = new f30(12);
        Context context2 = getContext();
        setHorizontalScrollBarEnabled(false);
        uf0 uf0Var = new uf0(this, context2);
        this.ykVrBoeh7sI = uf0Var;
        super.addView(uf0Var, 0, new FrameLayout.LayoutParams(-2, -1));
        TypedArray typedArrayD57UaHJBpF2 = es.D57UaHJBpF2(context2, attributeSet, s40.D57UaHJBpF2, R.attr.tabStyle, R.style.Widget_Design_TabLayout, 24);
        ColorStateList colorStateListZrl8J6Z2Dje = vi0.Zrl8J6Z2Dje(getBackground());
        if (colorStateListZrl8J6Z2Dje != null) {
            vw vwVar = new vw();
            vwVar.miDHqavGimy(colorStateListZrl8J6Z2Dje);
            vwVar.ykVrBoeh7sI(context2);
            vwVar.Oby7UOJk982(getElevation());
            setBackground(vwVar);
        }
        setSelectedTabIndicator(mn0.fVTKpwokKnY(context2, typedArrayD57UaHJBpF2, 5));
        setSelectedTabIndicatorColor(typedArrayD57UaHJBpF2.getColor(8, 0));
        uf0Var.nDGTvOUPAhx(typedArrayD57UaHJBpF2.getDimensionPixelSize(11, -1));
        setSelectedTabIndicatorGravity(typedArrayD57UaHJBpF2.getInt(10, 0));
        setTabIndicatorAnimationMode(typedArrayD57UaHJBpF2.getInt(7, 0));
        setTabIndicatorFullWidth(typedArrayD57UaHJBpF2.getBoolean(9, true));
        int dimensionPixelSize = typedArrayD57UaHJBpF2.getDimensionPixelSize(16, 0);
        this.miDHqavGimy = dimensionPixelSize;
        this.Oby7UOJk982 = dimensionPixelSize;
        this.kLF8MllXouM = dimensionPixelSize;
        this.ocrRjEg1xWE = dimensionPixelSize;
        this.ocrRjEg1xWE = typedArrayD57UaHJBpF2.getDimensionPixelSize(19, dimensionPixelSize);
        this.kLF8MllXouM = typedArrayD57UaHJBpF2.getDimensionPixelSize(20, dimensionPixelSize);
        this.Oby7UOJk982 = typedArrayD57UaHJBpF2.getDimensionPixelSize(18, dimensionPixelSize);
        this.miDHqavGimy = typedArrayD57UaHJBpF2.getDimensionPixelSize(17, dimensionPixelSize);
        if (l80.hSdjhQTBcYv(context2.getTheme(), R.attr.isMaterial3Theme, false)) {
            this.H8bE8XWjtoS = R.attr.textAppearanceTitleSmall;
        } else {
            this.H8bE8XWjtoS = R.attr.textAppearanceButton;
        }
        int resourceId2 = typedArrayD57UaHJBpF2.getResourceId(24, R.style.TextAppearance_Design_Tab);
        this.uCRx9YCOc24 = resourceId2;
        int[] iArr = c50.C48z5w8gjNK;
        TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(resourceId2, iArr);
        try {
            this.P56qh5C3eoK = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
            this.WGVIMf7e7f9 = mn0.z7hVgGhB3r5(context2, typedArrayObtainStyledAttributes, 3);
            typedArrayObtainStyledAttributes.recycle();
            if (typedArrayD57UaHJBpF2.hasValue(22)) {
                resourceId = typedArrayD57UaHJBpF2.getResourceId(22, resourceId2);
                this.Zrl8J6Z2Dje = resourceId;
            } else {
                resourceId = -1;
            }
            int[] iArr2 = HorizontalScrollView.EMPTY_STATE_SET;
            int[] iArr3 = HorizontalScrollView.SELECTED_STATE_SET;
            if (resourceId != -1) {
                typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(resourceId, iArr);
                try {
                    this.fVTKpwokKnY = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, (int) r6);
                    ColorStateList colorStateListZ7hVgGhB3r5 = mn0.z7hVgGhB3r5(context2, typedArrayObtainStyledAttributes, 3);
                    if (colorStateListZ7hVgGhB3r5 != null) {
                        this.WGVIMf7e7f9 = new ColorStateList(new int[][]{iArr3, iArr2}, new int[]{colorStateListZ7hVgGhB3r5.getColorForState(new int[]{android.R.attr.state_selected}, colorStateListZ7hVgGhB3r5.getDefaultColor()), this.WGVIMf7e7f9.getDefaultColor()});
                    }
                } finally {
                }
            }
            if (typedArrayD57UaHJBpF2.hasValue(25)) {
                this.WGVIMf7e7f9 = mn0.z7hVgGhB3r5(context2, typedArrayD57UaHJBpF2, 25);
            }
            if (typedArrayD57UaHJBpF2.hasValue(23)) {
                this.WGVIMf7e7f9 = new ColorStateList(new int[][]{iArr3, iArr2}, new int[]{typedArrayD57UaHJBpF2.getColor(23, 0), this.WGVIMf7e7f9.getDefaultColor()});
            }
            this.lJCHxZXkFBB = mn0.z7hVgGhB3r5(context2, typedArrayD57UaHJBpF2, 3);
            this.C48z5w8gjNK = v90.kLF8MllXouM(typedArrayD57UaHJBpF2.getInt(4, -1), null);
            this.n7QsYWNZtSU = mn0.z7hVgGhB3r5(context2, typedArrayD57UaHJBpF2, 21);
            this.OcCEV0cN9EJ = typedArrayD57UaHJBpF2.getInt(6, 300);
            this.gfMrr7pMNlA = mn0.IYi9Twa3Yjg(context2, R.attr.motionEasingEmphasizedInterpolator, i0.nDGTvOUPAhx);
            this.JyMrFevGyEE = typedArrayD57UaHJBpF2.getDimensionPixelSize(14, -1);
            this.IVXw3Dlz2AG = typedArrayD57UaHJBpF2.getDimensionPixelSize(13, -1);
            this.I538XrPZXnv = typedArrayD57UaHJBpF2.getResourceId(0, 0);
            this.RD9v7iCsyVj = typedArrayD57UaHJBpF2.getDimensionPixelSize(1, 0);
            this.XB6ioTeWZY2 = typedArrayD57UaHJBpF2.getInt(15, 1);
            this.rAQLLnQzyBa = typedArrayD57UaHJBpF2.getInt(2, 0);
            this.kMJtaEXWLpZ = typedArrayD57UaHJBpF2.getBoolean(12, false);
            this.hSdjhQTBcYv = typedArrayD57UaHJBpF2.getBoolean(26, false);
            typedArrayD57UaHJBpF2.recycle();
            Resources resources = getResources();
            this.D57UaHJBpF2 = resources.getDimensionPixelSize(R.dimen.design_tab_text_size_2line);
            this.ZNZD85DkjoE = resources.getDimensionPixelSize(R.dimen.design_tab_scrollable_min_width);
            kheiy7RMk6s();
        } finally {
        }
    }

    private int getDefaultHeight() {
        ArrayList arrayList = this.Ndt5adT1n2F;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            vf0 vf0Var = (vf0) arrayList.get(i);
            if (vf0Var != null && vf0Var.HgCgyIrsRhc != null && !TextUtils.isEmpty(vf0Var.nDGTvOUPAhx)) {
                return !this.kMJtaEXWLpZ ? 72 : 48;
            }
        }
        return 48;
    }

    private int getTabMinWidth() {
        int i = this.JyMrFevGyEE;
        if (i != -1) {
            return i;
        }
        int i2 = this.XB6ioTeWZY2;
        if (i2 == 0 || i2 == 2) {
            return this.ZNZD85DkjoE;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.ykVrBoeh7sI.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    private void setSelectedTabView(int i) {
        uf0 uf0Var = this.ykVrBoeh7sI;
        int childCount = uf0Var.getChildCount();
        if (i < childCount) {
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = uf0Var.getChildAt(i2);
                if ((i2 != i || childAt.isSelected()) && (i2 == i || !childAt.isSelected())) {
                    childAt.setSelected(i2 == i);
                    childAt.setActivated(i2 == i);
                } else {
                    childAt.setSelected(i2 == i);
                    childAt.setActivated(i2 == i);
                    if (childAt instanceof xf0) {
                        ((xf0) childAt).wJXRvW1l9At();
                    }
                }
                i2++;
            }
        }
    }

    public final void HgCgyIrsRhc(View view) {
        if (!(view instanceof TabItem)) {
            n4.Ndt5adT1n2F("Only TabItem instances can be added to TabLayout");
            return;
        }
        TabItem tabItem = (TabItem) view;
        vf0 vf0Var = (vf0) cFNknbO9KWg.HgCgyIrsRhc();
        if (vf0Var == null) {
            vf0Var = new vf0();
            vf0Var.aBUhIZ95pth = -1;
        }
        vf0Var.MarFYthBr4b = this;
        f30 f30Var = this.iFM7bRXghng;
        xf0 xf0Var = f30Var != null ? (xf0) f30Var.HgCgyIrsRhc() : null;
        if (xf0Var == null) {
            xf0Var = new xf0(this, getContext());
        }
        xf0Var.setTab(vf0Var);
        xf0Var.setFocusable(true);
        xf0Var.setMinimumWidth(getTabMinWidth());
        if (TextUtils.isEmpty(vf0Var.kheiy7RMk6s)) {
            xf0Var.setContentDescription(vf0Var.nDGTvOUPAhx);
        } else {
            xf0Var.setContentDescription(vf0Var.kheiy7RMk6s);
        }
        vf0Var.wJXRvW1l9At = xf0Var;
        CharSequence charSequence = tabItem.wJXRvW1l9At;
        if (charSequence != null) {
            if (TextUtils.isEmpty(vf0Var.kheiy7RMk6s) && !TextUtils.isEmpty(charSequence)) {
                vf0Var.wJXRvW1l9At.setContentDescription(charSequence);
            }
            vf0Var.nDGTvOUPAhx = charSequence;
            xf0 xf0Var2 = vf0Var.wJXRvW1l9At;
            if (xf0Var2 != null) {
                xf0Var2.brBhnf7Rph0();
            }
        }
        Drawable drawable = tabItem.Ndt5adT1n2F;
        if (drawable != null) {
            vf0Var.HgCgyIrsRhc = drawable;
            TabLayout tabLayout = vf0Var.MarFYthBr4b;
            if (tabLayout.rAQLLnQzyBa == 1 || tabLayout.XB6ioTeWZY2 == 2) {
                tabLayout.iQvCvXTWXYz(true);
            }
            xf0 xf0Var3 = vf0Var.wJXRvW1l9At;
            if (xf0Var3 != null) {
                xf0Var3.brBhnf7Rph0();
            }
        }
        int i = tabItem.iQvCvXTWXYz;
        if (i != 0) {
            vf0Var.brBhnf7Rph0 = LayoutInflater.from(vf0Var.wJXRvW1l9At.getContext()).inflate(i, (ViewGroup) vf0Var.wJXRvW1l9At, false);
            xf0 xf0Var4 = vf0Var.wJXRvW1l9At;
            if (xf0Var4 != null) {
                xf0Var4.brBhnf7Rph0();
            }
        }
        if (!TextUtils.isEmpty(tabItem.getContentDescription())) {
            vf0Var.kheiy7RMk6s = tabItem.getContentDescription();
            xf0 xf0Var5 = vf0Var.wJXRvW1l9At;
            if (xf0Var5 != null) {
                xf0Var5.brBhnf7Rph0();
            }
        }
        ArrayList arrayList = this.Ndt5adT1n2F;
        boolean zIsEmpty = arrayList.isEmpty();
        int size = arrayList.size();
        if (vf0Var.MarFYthBr4b != this) {
            n4.Ndt5adT1n2F("Tab belongs to a different TabLayout.");
            return;
        }
        vf0Var.aBUhIZ95pth = size;
        arrayList.add(size, vf0Var);
        int size2 = arrayList.size();
        int i2 = -1;
        for (int i3 = size + 1; i3 < size2; i3++) {
            if (((vf0) arrayList.get(i3)).aBUhIZ95pth == this.wJXRvW1l9At) {
                i2 = i3;
            }
            ((vf0) arrayList.get(i3)).aBUhIZ95pth = i3;
        }
        this.wJXRvW1l9At = i2;
        xf0 xf0Var6 = vf0Var.wJXRvW1l9At;
        xf0Var6.setSelected(false);
        xf0Var6.setActivated(false);
        int i4 = vf0Var.aBUhIZ95pth;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
        if (this.XB6ioTeWZY2 == 1 && this.rAQLLnQzyBa == 0) {
            layoutParams.width = 0;
            layoutParams.weight = 1.0f;
        } else {
            layoutParams.width = -2;
            layoutParams.weight = 0.0f;
        }
        this.ykVrBoeh7sI.addView(xf0Var6, i4, layoutParams);
        if (zIsEmpty) {
            TabLayout tabLayout2 = vf0Var.MarFYthBr4b;
            if (tabLayout2 != null) {
                tabLayout2.wJXRvW1l9At(vf0Var);
            } else {
                n4.Ndt5adT1n2F("Tab not attached to a TabLayout");
            }
        }
    }

    public final void MarFYthBr4b() {
        uf0 uf0Var = this.ykVrBoeh7sI;
        int childCount = uf0Var.getChildCount();
        while (true) {
            childCount--;
            if (childCount < 0) {
                break;
            }
            xf0 xf0Var = (xf0) uf0Var.getChildAt(childCount);
            uf0Var.removeViewAt(childCount);
            if (xf0Var != null) {
                xf0Var.setTab(null);
                xf0Var.setSelected(false);
                this.iFM7bRXghng.kheiy7RMk6s(xf0Var);
            }
            requestLayout();
        }
        Iterator it = this.Ndt5adT1n2F.iterator();
        while (it.hasNext()) {
            vf0 vf0Var = (vf0) it.next();
            it.remove();
            vf0Var.MarFYthBr4b = null;
            vf0Var.wJXRvW1l9At = null;
            vf0Var.HgCgyIrsRhc = null;
            vf0Var.nDGTvOUPAhx = null;
            vf0Var.kheiy7RMk6s = null;
            vf0Var.aBUhIZ95pth = -1;
            vf0Var.brBhnf7Rph0 = null;
            cFNknbO9KWg.kheiy7RMk6s(vf0Var);
        }
        this.iQvCvXTWXYz = null;
    }

    public final void Ndt5adT1n2F(int i) {
        float f = i + 0.0f;
        int iRound = Math.round(f);
        if (iRound >= 0) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (iRound >= uf0Var.getChildCount()) {
                return;
            }
            uf0Var.Ndt5adT1n2F.wJXRvW1l9At = Math.round(f);
            ValueAnimator valueAnimator = uf0Var.wJXRvW1l9At;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                uf0Var.wJXRvW1l9At.cancel();
            }
            uf0Var.kheiy7RMk6s(uf0Var.getChildAt(i), uf0Var.getChildAt(i + 1), 0.0f);
            ValueAnimator valueAnimator2 = this.uHy5z3aH4qy;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.uHy5z3aH4qy.cancel();
            }
            int iABUhIZ95pth = aBUhIZ95pth(i);
            int scrollX = getScrollX();
            if ((i >= getSelectedTabPosition() || iABUhIZ95pth < scrollX) && (i <= getSelectedTabPosition() || iABUhIZ95pth > scrollX)) {
                getSelectedTabPosition();
            }
            if (getLayoutDirection() == 1 && ((i >= getSelectedTabPosition() || iABUhIZ95pth > scrollX) && (i <= getSelectedTabPosition() || iABUhIZ95pth < scrollX))) {
                getSelectedTabPosition();
            }
            if (i < 0) {
                iABUhIZ95pth = 0;
            }
            scrollTo(iABUhIZ95pth, 0);
            setSelectedTabView(iRound);
        }
    }

    public final int aBUhIZ95pth(int i) {
        uf0 uf0Var;
        View childAt;
        int i2 = this.XB6ioTeWZY2;
        if ((i2 != 0 && i2 != 2) || (childAt = (uf0Var = this.ykVrBoeh7sI).getChildAt(i)) == null) {
            return 0;
        }
        int i3 = i + 1;
        View childAt2 = i3 < uf0Var.getChildCount() ? uf0Var.getChildAt(i3) : null;
        int width = childAt.getWidth();
        int width2 = childAt2 != null ? childAt2.getWidth() : 0;
        int left = ((width / 2) + childAt.getLeft()) - (getWidth() / 2);
        int i4 = (int) ((width + width2) * 0.5f * 0.0f);
        return getLayoutDirection() == 0 ? left + i4 : left - i4;
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public final void addView(View view) {
        HgCgyIrsRhc(view);
    }

    public final void brBhnf7Rph0() {
        if (this.uHy5z3aH4qy == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.uHy5z3aH4qy = valueAnimator;
            valueAnimator.setInterpolator(this.gfMrr7pMNlA);
            this.uHy5z3aH4qy.setDuration(this.OcCEV0cN9EJ);
            this.uHy5z3aH4qy.addUpdateListener(new h5(2, this));
        }
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    public int getSelectedTabPosition() {
        vf0 vf0Var = this.iQvCvXTWXYz;
        if (vf0Var != null) {
            return vf0Var.aBUhIZ95pth;
        }
        return -1;
    }

    public int getTabCount() {
        return this.Ndt5adT1n2F.size();
    }

    public int getTabGravity() {
        return this.rAQLLnQzyBa;
    }

    public ColorStateList getTabIconTint() {
        return this.lJCHxZXkFBB;
    }

    public int getTabIndicatorAnimationMode() {
        return this.D5vWTmG37B7;
    }

    public int getTabIndicatorGravity() {
        return this.yOSzBmjeOMj;
    }

    public int getTabMaxWidth() {
        return this.mYvwaIfm0QL;
    }

    public int getTabMode() {
        return this.XB6ioTeWZY2;
    }

    public ColorStateList getTabRippleColor() {
        return this.n7QsYWNZtSU;
    }

    public Drawable getTabSelectedIndicator() {
        return this.g0egR5i1XsF;
    }

    public ColorStateList getTabTextColors() {
        return this.WGVIMf7e7f9;
    }

    public final void iQvCvXTWXYz(boolean z) {
        int i = 0;
        while (true) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (i >= uf0Var.getChildCount()) {
                return;
            }
            View childAt = uf0Var.getChildAt(i);
            childAt.setMinimumWidth(getTabMinWidth());
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
            if (this.XB6ioTeWZY2 == 1 && this.rAQLLnQzyBa == 0) {
                layoutParams.width = 0;
                layoutParams.weight = 1.0f;
            } else {
                layoutParams.width = -2;
                layoutParams.weight = 0.0f;
            }
            if (z) {
                childAt.requestLayout();
            }
            i++;
        }
    }

    public final void kheiy7RMk6s() {
        int i = this.XB6ioTeWZY2;
        int iMax = (i == 0 || i == 2) ? Math.max(0, this.RD9v7iCsyVj - this.ocrRjEg1xWE) : 0;
        uf0 uf0Var = this.ykVrBoeh7sI;
        uf0Var.setPaddingRelative(iMax, 0, 0, 0);
        int i2 = this.XB6ioTeWZY2;
        if (i2 == 0) {
            int i3 = this.rAQLLnQzyBa;
            if (i3 == 0) {
                Log.w("TabLayout", "MODE_SCROLLABLE + GRAVITY_FILL is not supported, GRAVITY_START will be used instead");
            } else if (i3 == 1) {
                uf0Var.setGravity(1);
            } else if (i3 == 2) {
            }
            uf0Var.setGravity(8388611);
        } else if (i2 == 1 || i2 == 2) {
            if (this.rAQLLnQzyBa == 2) {
                Log.w("TabLayout", "GRAVITY_START is not supported with the current tab mode, GRAVITY_CENTER will be used instead");
            }
            uf0Var.setGravity(1);
        }
        iQvCvXTWXYz(true);
    }

    public final void nDGTvOUPAhx(int i) {
        if (i == -1) {
            return;
        }
        if (getWindowToken() != null && isLaidOut()) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            int childCount = uf0Var.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                if (uf0Var.getChildAt(i2).getWidth() > 0) {
                }
            }
            int scrollX = getScrollX();
            int iABUhIZ95pth = aBUhIZ95pth(i);
            if (scrollX != iABUhIZ95pth) {
                brBhnf7Rph0();
                this.uHy5z3aH4qy.setIntValues(scrollX, iABUhIZ95pth);
                this.uHy5z3aH4qy.start();
            }
            ValueAnimator valueAnimator = uf0Var.wJXRvW1l9At;
            if (valueAnimator != null && valueAnimator.isRunning() && uf0Var.Ndt5adT1n2F.wJXRvW1l9At != i) {
                uf0Var.wJXRvW1l9At.cancel();
            }
            uf0Var.aBUhIZ95pth(i, this.OcCEV0cN9EJ, true);
            return;
        }
        Ndt5adT1n2F(i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof vw) {
            zd.ZNZD85DkjoE(this, (vw) background);
        }
        getParent();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int i = 0;
        while (true) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (i >= uf0Var.getChildCount()) {
                super.onDraw(canvas);
                return;
            }
            View childAt = uf0Var.getChildAt(i);
            if (childAt instanceof xf0) {
                xf0 xf0Var = (xf0) childAt;
                int i2 = xf0.WGVIMf7e7f9;
                Drawable drawable = xf0Var.H8bE8XWjtoS;
                if (drawable != null) {
                    drawable.setBounds(xf0Var.getLeft(), xf0Var.getTop(), xf0Var.getRight(), xf0Var.getBottom());
                    xf0Var.H8bE8XWjtoS.draw(canvas);
                }
            }
            i++;
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(1, getTabCount(), false, 1));
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return (getTabMode() == 0 || getTabMode() == 2) && super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARN: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i2) {
        int iRound = Math.round(v90.aBUhIZ95pth(getContext(), getDefaultHeight()));
        int mode = View.MeasureSpec.getMode(i2);
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                i2 = View.MeasureSpec.makeMeasureSpec(getPaddingBottom() + getPaddingTop() + iRound, 1073741824);
            }
        } else if (getChildCount() == 1 && View.MeasureSpec.getSize(i2) >= iRound) {
            getChildAt(0).setMinimumHeight(iRound);
        }
        int size = View.MeasureSpec.getSize(i);
        if (View.MeasureSpec.getMode(i) != 0) {
            int iABUhIZ95pth = this.IVXw3Dlz2AG;
            if (iABUhIZ95pth <= 0) {
                iABUhIZ95pth = (int) (size - v90.aBUhIZ95pth(getContext(), 56));
            }
            this.mYvwaIfm0QL = iABUhIZ95pth;
        }
        super.onMeasure(i, i2);
        if (getChildCount() == 1) {
            View childAt = getChildAt(0);
            int i3 = this.XB6ioTeWZY2;
            if (i3 == 0) {
                if (childAt.getMeasuredWidth() >= getMeasuredWidth()) {
                    return;
                }
            } else if (i3 != 1) {
                if (i3 != 2) {
                    return;
                }
                if (childAt.getMeasuredWidth() >= getMeasuredWidth()) {
                }
            } else if (childAt.getMeasuredWidth() == getMeasuredWidth()) {
                return;
            }
            childAt.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), ViewGroup.getChildMeasureSpec(i2, getPaddingBottom() + getPaddingTop(), childAt.getLayoutParams().height));
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() != 8 || getTabMode() == 0 || getTabMode() == 2) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        Drawable background = getBackground();
        if (background instanceof vw) {
            ((vw) background).Oby7UOJk982(f);
        }
    }

    public void setInlineLabel(boolean z) {
        if (this.kMJtaEXWLpZ == z) {
            return;
        }
        this.kMJtaEXWLpZ = z;
        int i = 0;
        while (true) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (i >= uf0Var.getChildCount()) {
                kheiy7RMk6s();
                return;
            }
            View childAt = uf0Var.getChildAt(i);
            if (childAt instanceof xf0) {
                xf0 xf0Var = (xf0) childAt;
                xf0Var.setOrientation(!xf0Var.Zrl8J6Z2Dje.kMJtaEXWLpZ ? 1 : 0);
                TextView textView = xf0Var.Oby7UOJk982;
                if (textView == null && xf0Var.miDHqavGimy == null) {
                    xf0Var.Ndt5adT1n2F(xf0Var.Ndt5adT1n2F, xf0Var.iQvCvXTWXYz, true);
                } else {
                    xf0Var.Ndt5adT1n2F(textView, xf0Var.miDHqavGimy, false);
                }
            }
            i++;
        }
    }

    public void setInlineLabelResource(int i) {
        setInlineLabel(getResources().getBoolean(i));
    }

    @Deprecated
    public void setOnTabSelectedListener(rf0 rf0Var) {
        rf0 rf0Var2 = this.X0MyC8YR7bY;
        ArrayList arrayList = this.IYi9Twa3Yjg;
        if (rf0Var2 != null) {
            arrayList.remove(rf0Var2);
        }
        this.X0MyC8YR7bY = rf0Var;
        if (rf0Var == null || arrayList.contains(rf0Var)) {
            return;
        }
        arrayList.add(rf0Var);
    }

    public void setScrollAnimatorListener(Animator.AnimatorListener animatorListener) {
        brBhnf7Rph0();
        this.uHy5z3aH4qy.addListener(animatorListener);
    }

    public void setSelectedTabIndicator(Drawable drawable) {
        if (drawable == null) {
            drawable = new GradientDrawable();
        }
        Drawable drawableMutate = drawable.mutate();
        this.g0egR5i1XsF = drawableMutate;
        int i = this.z7hVgGhB3r5;
        if (i != 0) {
            drawableMutate.setTint(i);
        } else {
            drawableMutate.setTintList(null);
        }
        int intrinsicHeight = this.gVHumS1PT2O;
        if (intrinsicHeight == -1) {
            intrinsicHeight = this.g0egR5i1XsF.getIntrinsicHeight();
        }
        this.ykVrBoeh7sI.nDGTvOUPAhx(intrinsicHeight);
    }

    public void setSelectedTabIndicatorColor(int i) {
        this.z7hVgGhB3r5 = i;
        Drawable drawable = this.g0egR5i1XsF;
        if (i != 0) {
            drawable.setTint(i);
        } else {
            drawable.setTintList(null);
        }
        iQvCvXTWXYz(false);
    }

    public void setSelectedTabIndicatorGravity(int i) {
        if (this.yOSzBmjeOMj != i) {
            this.yOSzBmjeOMj = i;
            this.ykVrBoeh7sI.postInvalidateOnAnimation();
        }
    }

    @Deprecated
    public void setSelectedTabIndicatorHeight(int i) {
        this.gVHumS1PT2O = i;
        this.ykVrBoeh7sI.nDGTvOUPAhx(i);
    }

    public void setTabGravity(int i) {
        if (this.rAQLLnQzyBa != i) {
            this.rAQLLnQzyBa = i;
            kheiy7RMk6s();
        }
    }

    public void setTabIconTint(ColorStateList colorStateList) {
        if (this.lJCHxZXkFBB != colorStateList) {
            this.lJCHxZXkFBB = colorStateList;
            ArrayList arrayList = this.Ndt5adT1n2F;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                xf0 xf0Var = ((vf0) arrayList.get(i)).wJXRvW1l9At;
                if (xf0Var != null) {
                    xf0Var.brBhnf7Rph0();
                }
            }
        }
    }

    public void setTabIconTintResource(int i) {
        setTabIconTint(mn0.n7QsYWNZtSU(getContext(), i));
    }

    public void setTabIndicatorAnimationMode(int i) {
        this.D5vWTmG37B7 = i;
        if (i == 0) {
            this.V73zDzxkiRf = new sa0(8);
            return;
        }
        int i2 = 1;
        if (i == 1) {
            this.V73zDzxkiRf = new ij(0);
        } else {
            if (i == 2) {
                this.V73zDzxkiRf = new ij(i2);
                return;
            }
            throw new IllegalArgumentException(i + " is not a valid TabIndicatorAnimationMode");
        }
    }

    public void setTabIndicatorFullWidth(boolean z) {
        this.wBZqWeQU8tl = z;
        int i = uf0.iQvCvXTWXYz;
        uf0 uf0Var = this.ykVrBoeh7sI;
        uf0Var.HgCgyIrsRhc(uf0Var.Ndt5adT1n2F.getSelectedTabPosition());
        uf0Var.postInvalidateOnAnimation();
    }

    public void setTabMode(int i) {
        if (i != this.XB6ioTeWZY2) {
            this.XB6ioTeWZY2 = i;
            kheiy7RMk6s();
        }
    }

    public void setTabRippleColor(ColorStateList colorStateList) {
        if (this.n7QsYWNZtSU == colorStateList) {
            return;
        }
        this.n7QsYWNZtSU = colorStateList;
        int i = 0;
        while (true) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (i >= uf0Var.getChildCount()) {
                return;
            }
            View childAt = uf0Var.getChildAt(i);
            if (childAt instanceof xf0) {
                Context context = getContext();
                int i2 = xf0.WGVIMf7e7f9;
                ((xf0) childAt).MarFYthBr4b(context);
            }
            i++;
        }
    }

    public void setTabRippleColorResource(int i) {
        setTabRippleColor(mn0.n7QsYWNZtSU(getContext(), i));
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.WGVIMf7e7f9 != colorStateList) {
            this.WGVIMf7e7f9 = colorStateList;
            ArrayList arrayList = this.Ndt5adT1n2F;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                xf0 xf0Var = ((vf0) arrayList.get(i)).wJXRvW1l9At;
                if (xf0Var != null) {
                    xf0Var.brBhnf7Rph0();
                }
            }
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(f20 f20Var) {
        MarFYthBr4b();
    }

    public void setUnboundedRipple(boolean z) {
        if (this.hSdjhQTBcYv == z) {
            return;
        }
        this.hSdjhQTBcYv = z;
        int i = 0;
        while (true) {
            uf0 uf0Var = this.ykVrBoeh7sI;
            if (i >= uf0Var.getChildCount()) {
                return;
            }
            View childAt = uf0Var.getChildAt(i);
            if (childAt instanceof xf0) {
                Context context = getContext();
                int i2 = xf0.WGVIMf7e7f9;
                ((xf0) childAt).MarFYthBr4b(context);
            }
            i++;
        }
    }

    public void setUnboundedRippleResource(int i) {
        setUnboundedRipple(getResources().getBoolean(i));
    }

    public void setupWithViewPager(jl0 jl0Var) {
        MarFYthBr4b();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }

    public final void wJXRvW1l9At(vf0 vf0Var) {
        vf0 vf0Var2 = this.iQvCvXTWXYz;
        ArrayList arrayList = this.IYi9Twa3Yjg;
        if (vf0Var2 == vf0Var) {
            if (vf0Var2 != null) {
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    ((rf0) arrayList.get(size)).HgCgyIrsRhc(vf0Var);
                }
                nDGTvOUPAhx(vf0Var.aBUhIZ95pth);
                return;
            }
            return;
        }
        int i = vf0Var.aBUhIZ95pth;
        if ((vf0Var2 == null || vf0Var2.aBUhIZ95pth == -1) && i != -1) {
            Ndt5adT1n2F(i);
        } else {
            nDGTvOUPAhx(i);
        }
        if (i != -1) {
            setSelectedTabView(i);
        }
        this.iQvCvXTWXYz = vf0Var;
        if (vf0Var2 != null && vf0Var2.MarFYthBr4b != null) {
            for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
                ((rf0) arrayList.get(size2)).nDGTvOUPAhx(vf0Var2);
            }
        }
        for (int size3 = arrayList.size() - 1; size3 >= 0; size3--) {
            ((rf0) arrayList.get(size3)).kheiy7RMk6s(vf0Var);
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public final void addView(View view, int i) {
        HgCgyIrsRhc(view);
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        HgCgyIrsRhc(view);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        HgCgyIrsRhc(view);
    }

    @Deprecated
    public void setOnTabSelectedListener(sf0 sf0Var) {
        setOnTabSelectedListener((rf0) sf0Var);
    }

    public void setSelectedTabIndicator(int i) {
        if (i != 0) {
            setSelectedTabIndicator(l80.g0egR5i1XsF(getContext(), i));
        } else {
            setSelectedTabIndicator((Drawable) null);
        }
    }

    public TabLayout(Context context) {
        this(context, null);
    }
}
