package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import defpackage.cu;
import defpackage.fi;
import defpackage.ix;
import defpackage.qk0;
import defpackage.u90;
import defpackage.um;
import defpackage.ux;
import defpackage.x70;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class NavigationMenuItemView extends um implements ux {
    public static final int[] gVHumS1PT2O = {R.attr.state_checked};
    public boolean IVXw3Dlz2AG;
    public boolean JyMrFevGyEE;
    public ix OcCEV0cN9EJ;
    public final CheckedTextView RD9v7iCsyVj;
    public boolean XB6ioTeWZY2;
    public boolean ZNZD85DkjoE;
    public Drawable kMJtaEXWLpZ;
    public int mYvwaIfm0QL;
    public FrameLayout rAQLLnQzyBa;
    public final fi wBZqWeQU8tl;
    public ColorStateList yOSzBmjeOMj;

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.ZNZD85DkjoE = true;
        fi fiVar = new fi(this);
        this.wBZqWeQU8tl = fiVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(com.kolosta.rejin.kiltor.R.layout.design_navigation_menu_item, (ViewGroup) this, true);
        setIconSize(context.getResources().getDimensionPixelSize(com.kolosta.rejin.kiltor.R.dimen.design_navigation_icon_size));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(com.kolosta.rejin.kiltor.R.id.design_menu_item_text);
        this.RD9v7iCsyVj = checkedTextView;
        qk0.kLF8MllXouM(checkedTextView, fiVar);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.rAQLLnQzyBa == null) {
                this.rAQLLnQzyBa = (FrameLayout) ((ViewStub) findViewById(com.kolosta.rejin.kiltor.R.id.design_menu_item_action_area_stub)).inflate();
            }
            if (view.getParent() != null) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            this.rAQLLnQzyBa.removeAllViews();
            this.rAQLLnQzyBa.addView(view);
        }
    }

    @Override // defpackage.ux
    public ix getItemData() {
        return this.OcCEV0cN9EJ;
    }

    @Override // defpackage.ux
    public final void kheiy7RMk6s(ix ixVar) {
        StateListDrawable stateListDrawable;
        this.OcCEV0cN9EJ = ixVar;
        int i = ixVar.HgCgyIrsRhc;
        if (i > 0) {
            setId(i);
        }
        setVisibility(ixVar.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(com.kolosta.rejin.kiltor.R.attr.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(gVHumS1PT2O, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            setBackground(stateListDrawable);
        }
        setCheckable(ixVar.isCheckable());
        setChecked(ixVar.isChecked());
        setEnabled(ixVar.isEnabled());
        setTitle(ixVar.brBhnf7Rph0);
        setIcon(ixVar.getIcon());
        setActionView(ixVar.getActionView());
        setContentDescription(ixVar.Zrl8J6Z2Dje);
        u90.Zrl8J6Z2Dje(this, ixVar.WGVIMf7e7f9);
        ix ixVar2 = this.OcCEV0cN9EJ;
        CharSequence charSequence = ixVar2.brBhnf7Rph0;
        CheckedTextView checkedTextView = this.RD9v7iCsyVj;
        if (charSequence == null && ixVar2.getIcon() == null && this.OcCEV0cN9EJ.getActionView() != null) {
            checkedTextView.setVisibility(8);
            FrameLayout frameLayout = this.rAQLLnQzyBa;
            if (frameLayout != null) {
                cu cuVar = (cu) frameLayout.getLayoutParams();
                ((LinearLayout.LayoutParams) cuVar).width = -1;
                this.rAQLLnQzyBa.setLayoutParams(cuVar);
                return;
            }
            return;
        }
        checkedTextView.setVisibility(0);
        FrameLayout frameLayout2 = this.rAQLLnQzyBa;
        if (frameLayout2 != null) {
            cu cuVar2 = (cu) frameLayout2.getLayoutParams();
            ((LinearLayout.LayoutParams) cuVar2).width = -2;
            this.rAQLLnQzyBa.setLayoutParams(cuVar2);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 1);
        ix ixVar = this.OcCEV0cN9EJ;
        if (ixVar != null && ixVar.isCheckable() && this.OcCEV0cN9EJ.isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, gVHumS1PT2O);
        }
        return iArrOnCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.IVXw3Dlz2AG != z) {
            this.IVXw3Dlz2AG = z;
            this.wBZqWeQU8tl.Ndt5adT1n2F(this.RD9v7iCsyVj, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        CheckedTextView checkedTextView = this.RD9v7iCsyVj;
        checkedTextView.setChecked(z);
        checkedTextView.setTypeface(checkedTextView.getTypeface(), (z && this.ZNZD85DkjoE) ? 1 : 0);
    }

    public void setHorizontalPadding(int i) {
        setPadding(i, getPaddingTop(), i, getPaddingBottom());
    }

    public void setIcon(Drawable drawable) throws Resources.NotFoundException {
        if (drawable != null) {
            if (this.XB6ioTeWZY2) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = drawable.mutate();
                drawable.setTintList(this.yOSzBmjeOMj);
            }
            int i = this.mYvwaIfm0QL;
            drawable.setBounds(0, 0, i, i);
        } else if (this.JyMrFevGyEE) {
            if (this.kMJtaEXWLpZ == null) {
                Resources resources = getResources();
                Resources.Theme theme = getContext().getTheme();
                ThreadLocal threadLocal = x70.HgCgyIrsRhc;
                Drawable drawable2 = resources.getDrawable(com.kolosta.rejin.kiltor.R.drawable.navigation_empty_icon, theme);
                this.kMJtaEXWLpZ = drawable2;
                if (drawable2 != null) {
                    int i2 = this.mYvwaIfm0QL;
                    drawable2.setBounds(0, 0, i2, i2);
                }
            }
            drawable = this.kMJtaEXWLpZ;
        }
        this.RD9v7iCsyVj.setCompoundDrawablesRelative(drawable, null, null, null);
    }

    public void setIconPadding(int i) {
        this.RD9v7iCsyVj.setCompoundDrawablePadding(i);
    }

    public void setIconSize(int i) {
        this.mYvwaIfm0QL = i;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.yOSzBmjeOMj = colorStateList;
        this.XB6ioTeWZY2 = colorStateList != null;
        ix ixVar = this.OcCEV0cN9EJ;
        if (ixVar != null) {
            setIcon(ixVar.getIcon());
        }
    }

    public void setMaxLines(int i) {
        this.RD9v7iCsyVj.setMaxLines(i);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.JyMrFevGyEE = z;
    }

    public void setTextAppearance(int i) {
        this.RD9v7iCsyVj.setTextAppearance(i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.RD9v7iCsyVj.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.RD9v7iCsyVj.setText(charSequence);
    }

    public NavigationMenuItemView(Context context) {
        this(context, null);
    }
}
