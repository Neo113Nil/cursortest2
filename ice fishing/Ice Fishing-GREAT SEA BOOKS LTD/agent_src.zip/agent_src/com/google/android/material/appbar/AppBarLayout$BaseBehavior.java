package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;
import defpackage.il0;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class AppBarLayout$BaseBehavior<T> extends il0 {
    public AppBarLayout$BaseBehavior() {
    }

    public AppBarLayout$BaseBehavior(Context context, AttributeSet attributeSet) {
    }
}
