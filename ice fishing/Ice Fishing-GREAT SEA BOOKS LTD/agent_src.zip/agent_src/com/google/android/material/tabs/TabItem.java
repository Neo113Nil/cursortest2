package com.google.android.material.tabs;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import defpackage.l80;
import defpackage.s40;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class TabItem extends View {
    public final Drawable Ndt5adT1n2F;
    public final int iQvCvXTWXYz;
    public final CharSequence wJXRvW1l9At;

    public TabItem(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s40.fVTKpwokKnY);
        this.wJXRvW1l9At = typedArrayObtainStyledAttributes.getText(2);
        this.Ndt5adT1n2F = (!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : l80.g0egR5i1XsF(context, resourceId);
        this.iQvCvXTWXYz = typedArrayObtainStyledAttributes.getResourceId(1, 0);
        typedArrayObtainStyledAttributes.recycle();
    }

    public TabItem(Context context) {
        this(context, null);
    }
}
