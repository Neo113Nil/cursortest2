package com.google.android.material.focus;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableWrapper;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.util.AttributeSet;
import android.util.StateSet;
import android.util.TypedValue;
import android.view.animation.OvershootInterpolator;
import defpackage.MarFYthBr4b;
import defpackage.RM9erU4r8X4;
import defpackage.ac0;
import defpackage.cc0;
import defpackage.dm;
import defpackage.em;
import defpackage.gj;
import defpackage.hn;
import defpackage.l80;
import defpackage.s40;
import defpackage.vw;
import defpackage.y90;
import java.io.IOException;
import java.lang.ref.WeakReference;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class FocusRingDrawable extends DrawableWrapper {
    public float H8bE8XWjtoS;
    public final RectF Ndt5adT1n2F;
    public final hn Oby7UOJk982;
    public boolean WGVIMf7e7f9;
    public float Zrl8J6Z2Dje;
    public em g0egR5i1XsF;
    public final Rect iQvCvXTWXYz;
    public final Matrix kLF8MllXouM;
    public boolean lJCHxZXkFBB;
    public WeakReference miDHqavGimy;
    public boolean n7QsYWNZtSU;
    public final Path ocrRjEg1xWE;
    public ObjectAnimator uCRx9YCOc24;
    public final Paint wJXRvW1l9At;
    public final Path ykVrBoeh7sI;
    public static final ColorDrawable z7hVgGhB3r5 = new ColorDrawable(0);
    public static final int[] C48z5w8gjNK = {R.attr.state_focused, R.attr.state_window_focused};
    public static final OvershootInterpolator P56qh5C3eoK = new OvershootInterpolator(4.0f);
    public static final dm fVTKpwokKnY = new dm("interpolation");

    public FocusRingDrawable(em emVar, Resources resources) {
        super(null);
        Paint paint = new Paint(1);
        this.wJXRvW1l9At = paint;
        this.Ndt5adT1n2F = new RectF();
        this.iQvCvXTWXYz = new Rect();
        this.ykVrBoeh7sI = new Path();
        this.ocrRjEg1xWE = new Path();
        this.kLF8MllXouM = new Matrix();
        this.Oby7UOJk982 = hn.nDGTvOUPAhx();
        this.H8bE8XWjtoS = -1.0f;
        this.Zrl8J6Z2Dje = 1.0f;
        this.lJCHxZXkFBB = false;
        this.n7QsYWNZtSU = false;
        em emVar2 = new em(emVar);
        this.g0egR5i1XsF = emVar2;
        Drawable.ConstantState constantState = emVar2.HgCgyIrsRhc;
        if (constantState != null) {
            setDrawable(resources != null ? constantState.newDrawable(resources) : constantState.newDrawable());
        }
        paint.setStyle(Paint.Style.STROKE);
        if (Float.isNaN(this.g0egR5i1XsF.ykVrBoeh7sI)) {
            return;
        }
        paint.setStrokeWidth(this.g0egR5i1XsF.ykVrBoeh7sI);
    }

    public static float MarFYthBr4b(float f, Resources.Theme theme, int i, TypedArray typedArray, int i2, int i3) {
        if (!Float.isNaN(f)) {
            return f;
        }
        Resources resources = theme.getResources();
        if (i != Float.MIN_VALUE) {
            TypedValue typedValue = new TypedValue();
            if (theme.resolveAttribute(i, typedValue, true)) {
                return typedValue.getDimension(resources.getDisplayMetrics());
            }
        }
        float dimension = typedArray.getDimension(i2, Float.NaN);
        if (!Float.isNaN(dimension)) {
            return dimension;
        }
        if (i3 == 0) {
            return Float.NaN;
        }
        return resources.getDimension(i3);
    }

    public static FocusRingDrawable brBhnf7Rph0(Context context, LayerDrawable layerDrawable, vw vwVar) {
        if (!l80.hSdjhQTBcYv(context.getTheme(), com.kolosta.rejin.kiltor.R.attr.focusRingsEnabled, false)) {
            return null;
        }
        FocusRingDrawable focusRingDrawable = new FocusRingDrawable(context, z7hVgGhB3r5);
        if (vwVar != null) {
            focusRingDrawable.miDHqavGimy = new WeakReference(vwVar);
        }
        layerDrawable.addLayer(focusRingDrawable);
        focusRingDrawable.setCallback(layerDrawable);
        return focusRingDrawable;
    }

    public static int kheiy7RMk6s(TypedArray typedArray, int i) {
        if (typedArray.getType(i) != 2) {
            return Integer.MIN_VALUE;
        }
        TypedValue typedValue = new TypedValue();
        if (typedArray.getValue(i, typedValue)) {
            return typedValue.data;
        }
        return Integer.MIN_VALUE;
    }

    public final void HgCgyIrsRhc(RectF rectF) {
        Rect rect = this.g0egR5i1XsF.C48z5w8gjNK;
        if (rect != null) {
            rectF.set(rect);
            return;
        }
        WeakReference weakReference = this.miDHqavGimy;
        if (weakReference != null && weakReference.get() != null) {
            rectF.set(((vw) this.miDHqavGimy.get()).getBounds());
            return;
        }
        if (!(getDrawable() instanceof RippleDrawable)) {
            rectF.set(getBounds());
            return;
        }
        RippleDrawable rippleDrawable = (RippleDrawable) getDrawable();
        Rect rect2 = this.iQvCvXTWXYz;
        rippleDrawable.getHotspotBounds(rect2);
        int radius = rippleDrawable.getRadius();
        if (radius > 0) {
            rect2.inset(Math.max(0, (rect2.width() / 2) - radius), Math.max(0, (rect2.height() / 2) - radius));
        }
        rectF.set(rect2);
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0074  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void aBUhIZ95pth(Resources.Theme theme) {
        TypedValue typedValueGVHumS1PT2O;
        TypedArray typedArrayObtainStyledAttributes = theme.obtainStyledAttributes(s40.wJXRvW1l9At);
        int i = this.g0egR5i1XsF.aBUhIZ95pth;
        if (i != Integer.MIN_VALUE && (typedValueGVHumS1PT2O = l80.gVHumS1PT2O(theme, i)) != null) {
            em emVar = this.g0egR5i1XsF;
            emVar.kheiy7RMk6s = typedValueGVHumS1PT2O.data != 0;
            emVar.brBhnf7Rph0 = true;
        }
        em emVar2 = this.g0egR5i1XsF;
        if (!emVar2.brBhnf7Rph0) {
            emVar2.kheiy7RMk6s = l80.hSdjhQTBcYv(theme, com.kolosta.rejin.kiltor.R.attr.focusRingsEnabled, emVar2.kheiy7RMk6s);
        }
        em emVar3 = this.g0egR5i1XsF;
        if (emVar3.kheiy7RMk6s) {
            int color = emVar3.MarFYthBr4b;
            int i2 = emVar3.wJXRvW1l9At;
            if (color == Integer.MIN_VALUE) {
                if (i2 != Integer.MIN_VALUE) {
                    TypedValue typedValue = new TypedValue();
                    color = theme.resolveAttribute(i2, typedValue, true) ? typedValue.data : typedArrayObtainStyledAttributes.getColor(5, -16777216);
                }
            }
            emVar3.MarFYthBr4b = color;
            em emVar4 = this.g0egR5i1XsF;
            int color2 = emVar4.Ndt5adT1n2F;
            int i3 = emVar4.iQvCvXTWXYz;
            if (color2 == Integer.MIN_VALUE) {
                if (i3 != Integer.MIN_VALUE) {
                    TypedValue typedValue2 = new TypedValue();
                    color2 = theme.resolveAttribute(i3, typedValue2, true) ? typedValue2.data : typedArrayObtainStyledAttributes.getColor(1, -1);
                }
            }
            emVar4.Ndt5adT1n2F = color2;
            em emVar5 = this.g0egR5i1XsF;
            emVar5.ykVrBoeh7sI = MarFYthBr4b(emVar5.ykVrBoeh7sI, theme, emVar5.ocrRjEg1xWE, typedArrayObtainStyledAttributes, 6, com.kolosta.rejin.kiltor.R.dimen.mtrl_focus_ring_outer_stroke_width);
            em emVar6 = this.g0egR5i1XsF;
            emVar6.kLF8MllXouM = MarFYthBr4b(emVar6.kLF8MllXouM, theme, emVar6.Oby7UOJk982, typedArrayObtainStyledAttributes, 3, com.kolosta.rejin.kiltor.R.dimen.mtrl_focus_ring_inner_stroke_width);
            em emVar7 = this.g0egR5i1XsF;
            emVar7.miDHqavGimy = MarFYthBr4b(emVar7.miDHqavGimy, theme, emVar7.H8bE8XWjtoS, typedArrayObtainStyledAttributes, 7, 0);
            em emVar8 = this.g0egR5i1XsF;
            emVar8.uCRx9YCOc24 = MarFYthBr4b(emVar8.uCRx9YCOc24, theme, emVar8.Zrl8J6Z2Dje, typedArrayObtainStyledAttributes, 4, 0);
            if (Float.isNaN(this.g0egR5i1XsF.uCRx9YCOc24)) {
                this.g0egR5i1XsF.uCRx9YCOc24 = 0.0f;
            }
            em emVar9 = this.g0egR5i1XsF;
            emVar9.WGVIMf7e7f9 = MarFYthBr4b(emVar9.WGVIMf7e7f9, theme, emVar9.lJCHxZXkFBB, typedArrayObtainStyledAttributes, 2, com.kolosta.rejin.kiltor.R.dimen.mtrl_focus_ring_inner_stroke_inset);
            em emVar10 = this.g0egR5i1XsF;
            int i4 = emVar10.g0egR5i1XsF;
            int[] iArr = s40.C48z5w8gjNK;
            if (i4 != Integer.MIN_VALUE) {
                emVar10.n7QsYWNZtSU = cc0.wJXRvW1l9At(theme.obtainStyledAttributes(i4, iArr), new MarFYthBr4b(0.0f)).HgCgyIrsRhc();
            } else {
                int i5 = emVar10.z7hVgGhB3r5;
                if (i5 == Integer.MIN_VALUE) {
                    i5 = com.kolosta.rejin.kiltor.R.attr.focusRingsShapeAppearance;
                }
                TypedValue typedValueGVHumS1PT2O2 = l80.gVHumS1PT2O(theme, i5);
                if (typedValueGVHumS1PT2O2 != null) {
                    this.g0egR5i1XsF.n7QsYWNZtSU = cc0.wJXRvW1l9At(theme.obtainStyledAttributes(typedValueGVHumS1PT2O2.resourceId, iArr), new MarFYthBr4b(0.0f)).HgCgyIrsRhc();
                }
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        Paint.Style style = Paint.Style.STROKE;
        Paint paint = this.wJXRvW1l9At;
        paint.setStyle(style);
        if (Float.isNaN(this.g0egR5i1XsF.ykVrBoeh7sI)) {
            return;
        }
        paint.setStrokeWidth(this.g0egR5i1XsF.ykVrBoeh7sI);
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final void applyTheme(Resources.Theme theme) {
        super.applyTheme(theme);
        aBUhIZ95pth(theme);
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final boolean canApplyTheme() {
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00b7  */
    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void draw(Canvas canvas) {
        float fMax;
        int radius;
        super.draw(canvas);
        em emVar = this.g0egR5i1XsF;
        if (emVar.kheiy7RMk6s && this.lJCHxZXkFBB) {
            float f = emVar.uCRx9YCOc24;
            float f2 = emVar.ykVrBoeh7sI / 2.0f;
            float f3 = this.Zrl8J6Z2Dje;
            float f4 = (f2 * f3) + f;
            float f5 = ((emVar.kLF8MllXouM / 2.0f) * f3) + f + emVar.WGVIMf7e7f9;
            Path path = this.ocrRjEg1xWE;
            if (path.isEmpty()) {
                WeakReference weakReference = this.miDHqavGimy;
                if (weakReference == null || weakReference.get() == null) {
                    path = null;
                } else {
                    path = ((vw) this.miDHqavGimy.get()).H8bE8XWjtoS;
                    if (path.isEmpty()) {
                    }
                }
            }
            Path path2 = path;
            em emVar2 = this.g0egR5i1XsF;
            if (path2 != null) {
                nDGTvOUPAhx(canvas, path2, f5, emVar2.kLF8MllXouM, emVar2.Ndt5adT1n2F);
                em emVar3 = this.g0egR5i1XsF;
                nDGTvOUPAhx(canvas, path2, f4, emVar3.ykVrBoeh7sI, emVar3.MarFYthBr4b);
                return;
            }
            if (Float.isNaN(emVar2.miDHqavGimy)) {
                fMax = this.H8bE8XWjtoS;
                if (fMax < 0.0f) {
                    WeakReference weakReference2 = this.miDHqavGimy;
                    if (weakReference2 == null || weakReference2.get() == null) {
                        Drawable drawable = getDrawable();
                        fMax = (!(drawable instanceof RippleDrawable) || (radius = ((RippleDrawable) drawable).getRadius()) < 0) ? 0.0f : radius;
                    } else {
                        vw vwVar = (vw) this.miDHqavGimy.get();
                        float fNDGTvOUPAhx = vwVar.nDGTvOUPAhx(vwVar.brBhnf7Rph0(), vwVar.Ndt5adT1n2F.HgCgyIrsRhc.aBUhIZ95pth(), vwVar.OcCEV0cN9EJ);
                        if (fNDGTvOUPAhx >= 0.0f) {
                            fNDGTvOUPAhx *= vwVar.Ndt5adT1n2F.iQvCvXTWXYz;
                        }
                        if (fNDGTvOUPAhx >= 0.0f) {
                            fMax = Math.max(0.0f, fNDGTvOUPAhx - (this.g0egR5i1XsF.ykVrBoeh7sI / 2.0f));
                        }
                    }
                }
            } else {
                fMax = this.g0egR5i1XsF.miDHqavGimy;
            }
            float fMax2 = Math.max(0.0f, fMax - (this.g0egR5i1XsF.ykVrBoeh7sI / 2.0f));
            em emVar4 = this.g0egR5i1XsF;
            float f6 = emVar4.kLF8MllXouM;
            int i = emVar4.Ndt5adT1n2F;
            RectF rectF = this.Ndt5adT1n2F;
            HgCgyIrsRhc(rectF);
            rectF.inset(f5, f5);
            float f7 = f6 * this.Zrl8J6Z2Dje;
            Paint paint = this.wJXRvW1l9At;
            paint.setStrokeWidth(f7);
            paint.setColor(i);
            canvas.drawRoundRect(rectF, fMax2, fMax2, paint);
            em emVar5 = this.g0egR5i1XsF;
            float f8 = emVar5.ykVrBoeh7sI;
            int i2 = emVar5.MarFYthBr4b;
            HgCgyIrsRhc(rectF);
            rectF.inset(f4, f4);
            paint.setStrokeWidth(f8 * this.Zrl8J6Z2Dje);
            paint.setColor(i2);
            canvas.drawRoundRect(rectF, fMax, fMax, paint);
        }
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final Drawable.ConstantState getConstantState() {
        em emVar = this.g0egR5i1XsF;
        if (emVar.HgCgyIrsRhc == null) {
            return null;
        }
        emVar.nDGTvOUPAhx = getChangingConfigurations();
        return this.g0egR5i1XsF;
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final boolean hasFocusStateSpecified() {
        try {
            if (super.hasFocusStateSpecified()) {
                return true;
            }
            return this.g0egR5i1XsF.kheiy7RMk6s;
        } catch (NoSuchMethodError unused) {
            return this.g0egR5i1XsF.kheiy7RMk6s;
        }
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException, IOException {
        super.inflate(resources, xmlPullParser, attributeSet, theme);
        int[] iArr = s40.wJXRvW1l9At;
        TypedArray typedArrayObtainStyledAttributes = theme != null ? theme.obtainStyledAttributes(attributeSet, iArr, 0, 0) : resources.obtainAttributes(attributeSet, iArr);
        this.g0egR5i1XsF.aBUhIZ95pth = kheiy7RMk6s(typedArrayObtainStyledAttributes, 0);
        if (this.g0egR5i1XsF.aBUhIZ95pth == Integer.MIN_VALUE && typedArrayObtainStyledAttributes.hasValue(0)) {
            em emVar = this.g0egR5i1XsF;
            emVar.kheiy7RMk6s = typedArrayObtainStyledAttributes.getBoolean(0, emVar.kheiy7RMk6s);
            this.g0egR5i1XsF.brBhnf7Rph0 = true;
        }
        this.g0egR5i1XsF.wJXRvW1l9At = kheiy7RMk6s(typedArrayObtainStyledAttributes, 5);
        em emVar2 = this.g0egR5i1XsF;
        if (emVar2.wJXRvW1l9At == Integer.MIN_VALUE) {
            emVar2.MarFYthBr4b = typedArrayObtainStyledAttributes.getColor(5, Integer.MIN_VALUE);
        }
        this.g0egR5i1XsF.iQvCvXTWXYz = kheiy7RMk6s(typedArrayObtainStyledAttributes, 1);
        em emVar3 = this.g0egR5i1XsF;
        if (emVar3.iQvCvXTWXYz == Integer.MIN_VALUE) {
            emVar3.Ndt5adT1n2F = typedArrayObtainStyledAttributes.getColor(1, Integer.MIN_VALUE);
        }
        this.g0egR5i1XsF.ocrRjEg1xWE = kheiy7RMk6s(typedArrayObtainStyledAttributes, 6);
        em emVar4 = this.g0egR5i1XsF;
        if (emVar4.ocrRjEg1xWE == Integer.MIN_VALUE) {
            emVar4.ykVrBoeh7sI = typedArrayObtainStyledAttributes.getDimension(6, Float.NaN);
        }
        this.g0egR5i1XsF.Oby7UOJk982 = kheiy7RMk6s(typedArrayObtainStyledAttributes, 3);
        em emVar5 = this.g0egR5i1XsF;
        if (emVar5.Oby7UOJk982 == Integer.MIN_VALUE) {
            emVar5.kLF8MllXouM = typedArrayObtainStyledAttributes.getDimension(3, Float.NaN);
        }
        this.g0egR5i1XsF.Oby7UOJk982 = kheiy7RMk6s(typedArrayObtainStyledAttributes, 3);
        em emVar6 = this.g0egR5i1XsF;
        if (emVar6.Oby7UOJk982 == Integer.MIN_VALUE) {
            emVar6.kLF8MllXouM = typedArrayObtainStyledAttributes.getDimension(3, Float.NaN);
        }
        this.g0egR5i1XsF.H8bE8XWjtoS = kheiy7RMk6s(typedArrayObtainStyledAttributes, 7);
        em emVar7 = this.g0egR5i1XsF;
        if (emVar7.H8bE8XWjtoS == Integer.MIN_VALUE) {
            emVar7.miDHqavGimy = typedArrayObtainStyledAttributes.getDimension(7, Float.NaN);
        }
        this.g0egR5i1XsF.Zrl8J6Z2Dje = kheiy7RMk6s(typedArrayObtainStyledAttributes, 4);
        em emVar8 = this.g0egR5i1XsF;
        if (emVar8.Zrl8J6Z2Dje == Integer.MIN_VALUE) {
            emVar8.uCRx9YCOc24 = typedArrayObtainStyledAttributes.getDimension(4, Float.NaN);
        }
        this.g0egR5i1XsF.lJCHxZXkFBB = kheiy7RMk6s(typedArrayObtainStyledAttributes, 2);
        em emVar9 = this.g0egR5i1XsF;
        if (emVar9.lJCHxZXkFBB == Integer.MIN_VALUE) {
            emVar9.WGVIMf7e7f9 = typedArrayObtainStyledAttributes.getDimension(2, Float.NaN);
        }
        this.g0egR5i1XsF.z7hVgGhB3r5 = kheiy7RMk6s(typedArrayObtainStyledAttributes, 8);
        this.g0egR5i1XsF.g0egR5i1XsF = typedArrayObtainStyledAttributes.getType(8) == 1 ? typedArrayObtainStyledAttributes.getResourceId(8, Integer.MIN_VALUE) : Integer.MIN_VALUE;
        typedArrayObtainStyledAttributes.recycle();
        int depth = xmlPullParser.getDepth();
        Drawable drawableCreateFromXmlInner = null;
        while (true) {
            int next = xmlPullParser.next();
            if (next == 1 || (next == 3 && xmlPullParser.getDepth() <= depth)) {
                break;
            } else if (next == 2) {
                drawableCreateFromXmlInner = Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme);
            }
        }
        if (drawableCreateFromXmlInner != null) {
            setDrawable(drawableCreateFromXmlInner);
            this.g0egR5i1XsF.HgCgyIrsRhc = drawableCreateFromXmlInner.getConstantState();
        } else {
            ColorDrawable colorDrawable = z7hVgGhB3r5;
            setDrawable(colorDrawable);
            this.g0egR5i1XsF.HgCgyIrsRhc = colorDrawable.getConstantState();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final boolean isProjected() {
        Drawable drawable = getDrawable();
        return drawable != null && drawable.isProjected();
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final boolean isStateful() {
        return super.isStateful() || this.g0egR5i1XsF.kheiy7RMk6s;
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final void jumpToCurrentState() {
        super.jumpToCurrentState();
        ObjectAnimator objectAnimator = this.uCRx9YCOc24;
        if (objectAnimator != null) {
            objectAnimator.end();
            this.uCRx9YCOc24 = null;
        }
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final Drawable mutate() {
        if (!this.n7QsYWNZtSU && super.mutate() == this) {
            this.g0egR5i1XsF = new em(this.g0egR5i1XsF);
            Drawable drawable = getDrawable();
            if (drawable != null) {
                this.g0egR5i1XsF.HgCgyIrsRhc = drawable.getConstantState();
            }
            this.n7QsYWNZtSU = true;
        }
        return this;
    }

    public final void nDGTvOUPAhx(Canvas canvas, Path path, float f, float f2, int i) {
        RectF rectF = this.Ndt5adT1n2F;
        HgCgyIrsRhc(rectF);
        float f3 = f * 2.0f;
        float fWidth = 1.0f - (f3 / rectF.width());
        float fHeight = 1.0f - (f3 / rectF.height());
        Matrix matrix = this.kLF8MllXouM;
        matrix.reset();
        matrix.postScale(fWidth, fHeight, rectF.centerX(), rectF.centerY());
        Path path2 = this.ykVrBoeh7sI;
        path.transform(matrix, path2);
        float f4 = f2 * this.Zrl8J6Z2Dje;
        Paint paint = this.wJXRvW1l9At;
        paint.setStrokeWidth(f4);
        paint.setColor(i);
        canvas.drawPath(path2, paint);
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final void onBoundsChange(Rect rect) {
        float[] cornerRadii;
        float cornerRadius;
        cc0 cc0Var;
        super.onBoundsChange(rect);
        em emVar = this.g0egR5i1XsF;
        if (emVar.kheiy7RMk6s) {
            ac0 ac0Var = emVar.n7QsYWNZtSU;
            if (ac0Var != null) {
                wJXRvW1l9At(ac0Var);
                return;
            }
            Drawable drawable = getDrawable();
            cc0 cc0Var2 = null;
            if (drawable instanceof ShapeDrawable) {
                Outline outline = new Outline();
                ((ShapeDrawable) drawable).getOutline(outline);
                if (outline.getRadius() > 0.0f) {
                    y90 y90Var = new y90();
                    y90 y90Var2 = new y90();
                    y90 y90Var3 = new y90();
                    y90 y90Var4 = new y90();
                    gj gjVar = new gj(0);
                    gj gjVar2 = new gj(0);
                    gj gjVar3 = new gj(0);
                    gj gjVar4 = new gj(0);
                    float radius = outline.getRadius();
                    MarFYthBr4b marFYthBr4b = new MarFYthBr4b(radius);
                    MarFYthBr4b marFYthBr4b2 = new MarFYthBr4b(radius);
                    MarFYthBr4b marFYthBr4b3 = new MarFYthBr4b(radius);
                    MarFYthBr4b marFYthBr4b4 = new MarFYthBr4b(radius);
                    cc0Var = new cc0();
                    cc0Var.HgCgyIrsRhc = y90Var;
                    cc0Var.nDGTvOUPAhx = y90Var2;
                    cc0Var.kheiy7RMk6s = y90Var3;
                    cc0Var.aBUhIZ95pth = y90Var4;
                    cc0Var.brBhnf7Rph0 = marFYthBr4b;
                    cc0Var.MarFYthBr4b = marFYthBr4b2;
                    cc0Var.wJXRvW1l9At = marFYthBr4b3;
                    cc0Var.Ndt5adT1n2F = marFYthBr4b4;
                    cc0Var.iQvCvXTWXYz = gjVar;
                    cc0Var.ykVrBoeh7sI = gjVar2;
                    cc0Var.ocrRjEg1xWE = gjVar3;
                    cc0Var.kLF8MllXouM = gjVar4;
                    cc0Var2 = cc0Var;
                }
            } else if (drawable instanceof GradientDrawable) {
                GradientDrawable gradientDrawable = (GradientDrawable) drawable;
                try {
                    cornerRadii = gradientDrawable.getCornerRadii();
                } catch (NullPointerException unused) {
                    cornerRadii = null;
                }
                if (cornerRadii != null) {
                    y90 y90Var5 = new y90();
                    y90 y90Var6 = new y90();
                    y90 y90Var7 = new y90();
                    y90 y90Var8 = new y90();
                    gj gjVar5 = new gj(0);
                    gj gjVar6 = new gj(0);
                    gj gjVar7 = new gj(0);
                    gj gjVar8 = new gj(0);
                    MarFYthBr4b marFYthBr4b5 = new MarFYthBr4b(Math.min(cornerRadii[0], cornerRadii[1]));
                    MarFYthBr4b marFYthBr4b6 = new MarFYthBr4b(Math.min(cornerRadii[2], cornerRadii[3]));
                    MarFYthBr4b marFYthBr4b7 = new MarFYthBr4b(Math.min(cornerRadii[4], cornerRadii[5]));
                    MarFYthBr4b marFYthBr4b8 = new MarFYthBr4b(Math.min(cornerRadii[6], cornerRadii[7]));
                    cc0Var = new cc0();
                    cc0Var.HgCgyIrsRhc = y90Var5;
                    cc0Var.nDGTvOUPAhx = y90Var6;
                    cc0Var.kheiy7RMk6s = y90Var7;
                    cc0Var.aBUhIZ95pth = y90Var8;
                    cc0Var.brBhnf7Rph0 = marFYthBr4b5;
                    cc0Var.MarFYthBr4b = marFYthBr4b6;
                    cc0Var.wJXRvW1l9At = marFYthBr4b7;
                    cc0Var.Ndt5adT1n2F = marFYthBr4b8;
                    cc0Var.iQvCvXTWXYz = gjVar5;
                    cc0Var.ykVrBoeh7sI = gjVar6;
                    cc0Var.ocrRjEg1xWE = gjVar7;
                    cc0Var.kLF8MllXouM = gjVar8;
                    cc0Var2 = cc0Var;
                } else {
                    try {
                        cornerRadius = gradientDrawable.getCornerRadius();
                    } catch (NullPointerException unused2) {
                        cornerRadius = -1.0f;
                    }
                    if (cornerRadius > 0.0f) {
                        y90 y90Var9 = new y90();
                        y90 y90Var10 = new y90();
                        y90 y90Var11 = new y90();
                        y90 y90Var12 = new y90();
                        gj gjVar9 = new gj(0);
                        gj gjVar10 = new gj(0);
                        gj gjVar11 = new gj(0);
                        gj gjVar12 = new gj(0);
                        MarFYthBr4b marFYthBr4b9 = new MarFYthBr4b(cornerRadius);
                        MarFYthBr4b marFYthBr4b10 = new MarFYthBr4b(cornerRadius);
                        MarFYthBr4b marFYthBr4b11 = new MarFYthBr4b(cornerRadius);
                        MarFYthBr4b marFYthBr4b12 = new MarFYthBr4b(cornerRadius);
                        cc0 cc0Var3 = new cc0();
                        cc0Var3.HgCgyIrsRhc = y90Var9;
                        cc0Var3.nDGTvOUPAhx = y90Var10;
                        cc0Var3.kheiy7RMk6s = y90Var11;
                        cc0Var3.aBUhIZ95pth = y90Var12;
                        cc0Var3.brBhnf7Rph0 = marFYthBr4b9;
                        cc0Var3.MarFYthBr4b = marFYthBr4b10;
                        cc0Var3.wJXRvW1l9At = marFYthBr4b11;
                        cc0Var3.Ndt5adT1n2F = marFYthBr4b12;
                        cc0Var3.iQvCvXTWXYz = gjVar9;
                        cc0Var3.ykVrBoeh7sI = gjVar10;
                        cc0Var3.ocrRjEg1xWE = gjVar11;
                        cc0Var3.kLF8MllXouM = gjVar12;
                        cc0Var2 = cc0Var3;
                    }
                }
            }
            if (cc0Var2 != null) {
                wJXRvW1l9At(cc0Var2);
            } else {
                this.H8bE8XWjtoS = -1.0f;
                this.ocrRjEg1xWE.reset();
            }
        }
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public final boolean onStateChange(int[] iArr) {
        em emVar = this.g0egR5i1XsF;
        if (!emVar.kheiy7RMk6s) {
            this.lJCHxZXkFBB = false;
            return super.onStateChange(iArr);
        }
        boolean zStateSetMatches = StateSet.stateSetMatches(emVar.P56qh5C3eoK, iArr);
        boolean z = this.lJCHxZXkFBB != zStateSetMatches;
        this.lJCHxZXkFBB = zStateSetMatches;
        if (z && iArr.length > 0 && !this.WGVIMf7e7f9) {
            ObjectAnimator objectAnimator = this.uCRx9YCOc24;
            if (objectAnimator != null) {
                objectAnimator.cancel();
                this.uCRx9YCOc24 = null;
            }
            if (zStateSetMatches) {
                ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, fVTKpwokKnY, 0.0f, 1.0f);
                objectAnimatorOfFloat.setDuration(300L);
                objectAnimatorOfFloat.setInterpolator(P56qh5C3eoK);
                objectAnimatorOfFloat.addListener(new RM9erU4r8X4(2, this));
                this.uCRx9YCOc24 = objectAnimatorOfFloat;
                objectAnimatorOfFloat.start();
            } else {
                this.Zrl8J6Z2Dje = 1.0f;
            }
        }
        this.WGVIMf7e7f9 = iArr.length == 0;
        return super.onStateChange(iArr) || z;
    }

    public final void wJXRvW1l9At(ac0 ac0Var) {
        RectF rectF = this.Ndt5adT1n2F;
        HgCgyIrsRhc(rectF);
        cc0 cc0VarNDGTvOUPAhx = ac0Var.nDGTvOUPAhx(C48z5w8gjNK);
        boolean zIQvCvXTWXYz = cc0VarNDGTvOUPAhx.iQvCvXTWXYz(rectF);
        Path path = this.ocrRjEg1xWE;
        if (!zIQvCvXTWXYz) {
            this.Oby7UOJk982.HgCgyIrsRhc(cc0VarNDGTvOUPAhx, null, 1.0f, rectF, null, path);
            this.H8bE8XWjtoS = -1.0f;
            return;
        }
        em emVar = this.g0egR5i1XsF;
        float f = ((emVar.ykVrBoeh7sI / 2.0f) * this.Zrl8J6Z2Dje) + emVar.uCRx9YCOc24;
        rectF.inset(f, f);
        this.H8bE8XWjtoS = cc0VarNDGTvOUPAhx.brBhnf7Rph0.HgCgyIrsRhc(rectF);
        path.reset();
    }

    public FocusRingDrawable(Context context, Drawable drawable) {
        super(drawable);
        this.wJXRvW1l9At = new Paint(1);
        this.Ndt5adT1n2F = new RectF();
        this.iQvCvXTWXYz = new Rect();
        this.ykVrBoeh7sI = new Path();
        this.ocrRjEg1xWE = new Path();
        this.kLF8MllXouM = new Matrix();
        this.Oby7UOJk982 = hn.nDGTvOUPAhx();
        this.H8bE8XWjtoS = -1.0f;
        this.Zrl8J6Z2Dje = 1.0f;
        this.lJCHxZXkFBB = false;
        this.n7QsYWNZtSU = false;
        em emVar = new em(null);
        this.g0egR5i1XsF = emVar;
        if (drawable != null) {
            emVar.HgCgyIrsRhc = drawable.getConstantState();
        }
        aBUhIZ95pth(context.getTheme());
    }

    public FocusRingDrawable() {
        super(null);
        this.wJXRvW1l9At = new Paint(1);
        this.Ndt5adT1n2F = new RectF();
        this.iQvCvXTWXYz = new Rect();
        this.ykVrBoeh7sI = new Path();
        this.ocrRjEg1xWE = new Path();
        this.kLF8MllXouM = new Matrix();
        this.Oby7UOJk982 = hn.nDGTvOUPAhx();
        this.H8bE8XWjtoS = -1.0f;
        this.Zrl8J6Z2Dje = 1.0f;
        this.lJCHxZXkFBB = false;
        this.n7QsYWNZtSU = false;
        this.g0egR5i1XsF = new em(null);
    }

    @Override // android.graphics.drawable.Drawable
    public final void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        inflate(resources, xmlPullParser, attributeSet, null);
    }
}
