package com.google.android.material.theme;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.google.android.material.button.MaterialButton;
import defpackage.d3;
import defpackage.dw;
import defpackage.l80;
import defpackage.mn0;
import defpackage.o0;
import defpackage.q0;
import defpackage.qw;
import defpackage.rw;
import defpackage.s0;
import defpackage.s40;
import defpackage.vi0;
import defpackage.x1;
import defpackage.x2;
import defpackage.yw;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class MaterialComponentsViewInflater extends d3 {
    @Override // defpackage.d3
    public final o0 HgCgyIrsRhc(Context context, AttributeSet attributeSet) {
        return new dw(context, attributeSet);
    }

    @Override // defpackage.d3
    public final x1 aBUhIZ95pth(Context context, AttributeSet attributeSet) {
        return new rw(context, attributeSet);
    }

    @Override // defpackage.d3
    public final x2 brBhnf7Rph0(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        yw ywVar = new yw(vi0.wBZqWeQU8tl(context, attributeSet, R.attr.textViewStyle, 0), attributeSet, R.attr.textViewStyle);
        Context context2 = ywVar.getContext();
        if (l80.D5vWTmG37B7(context2, com.kolosta.rejin.kiltor.R.attr.textAppearanceLineHeightEnabled, true)) {
            Resources.Theme theme = context2.getTheme();
            int[] iArr = s40.WGVIMf7e7f9;
            TypedArray typedArrayObtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, iArr, R.attr.textViewStyle, 0);
            int[] iArr2 = {1, 2};
            int iP56qh5C3eoK = -1;
            for (int i = 0; i < 2 && iP56qh5C3eoK < 0; i++) {
                iP56qh5C3eoK = mn0.P56qh5C3eoK(context2, typedArrayObtainStyledAttributes, iArr2[i], -1);
            }
            typedArrayObtainStyledAttributes.recycle();
            if (iP56qh5C3eoK == -1) {
                TypedArray typedArrayObtainStyledAttributes2 = theme.obtainStyledAttributes(attributeSet, iArr, R.attr.textViewStyle, 0);
                int resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, -1);
                typedArrayObtainStyledAttributes2.recycle();
                if (resourceId != -1) {
                    TypedArray typedArrayObtainStyledAttributes3 = theme.obtainStyledAttributes(resourceId, s40.Zrl8J6Z2Dje);
                    Context context3 = ywVar.getContext();
                    int[] iArr3 = {2, 4};
                    int iP56qh5C3eoK2 = -1;
                    for (int i2 = 0; i2 < 2 && iP56qh5C3eoK2 < 0; i2++) {
                        iP56qh5C3eoK2 = mn0.P56qh5C3eoK(context3, typedArrayObtainStyledAttributes3, iArr3[i2], -1);
                    }
                    typedArrayObtainStyledAttributes3.recycle();
                    if (iP56qh5C3eoK2 >= 0) {
                        ywVar.setLineHeight(iP56qh5C3eoK2);
                    }
                }
            }
        }
        return ywVar;
    }

    @Override // defpackage.d3
    public final s0 kheiy7RMk6s(Context context, AttributeSet attributeSet) {
        return new qw(context, attributeSet);
    }

    @Override // defpackage.d3
    public final q0 nDGTvOUPAhx(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }
}
