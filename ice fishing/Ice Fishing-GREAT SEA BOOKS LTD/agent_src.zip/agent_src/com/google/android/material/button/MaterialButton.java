package com.google.android.material.button;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.TextView;
import defpackage.SO78vOEPH7q;
import defpackage.ac0;
import defpackage.cc0;
import defpackage.e80;
import defpackage.es;
import defpackage.iw;
import defpackage.jw;
import defpackage.kw;
import defpackage.l80;
import defpackage.lw;
import defpackage.mc0;
import defpackage.me0;
import defpackage.mn0;
import defpackage.n4;
import defpackage.ne0;
import defpackage.q0;
import defpackage.s40;
import defpackage.v90;
import defpackage.vi0;
import defpackage.vr;
import defpackage.vw;
import defpackage.wd0;
import defpackage.zd;
import defpackage.zh0;
import java.util.Iterator;
import java.util.LinkedHashSet;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class MaterialButton extends q0 implements Checkable, mc0 {
    public static final int[] V73zDzxkiRf = {R.attr.state_checkable};
    public static final int[] gfMrr7pMNlA = {R.attr.state_checked};
    public int C48z5w8gjNK;
    public int D57UaHJBpF2;
    public float D5vWTmG37B7;
    public Drawable H8bE8XWjtoS;
    public boolean I538XrPZXnv;
    public int IVXw3Dlz2AG;
    public int JyMrFevGyEE;
    public PorterDuff.Mode Oby7UOJk982;
    public int OcCEV0cN9EJ;
    public int P56qh5C3eoK;
    public float RD9v7iCsyVj;
    public Drawable WGVIMf7e7f9;
    public int XB6ioTeWZY2;
    public int ZNZD85DkjoE;
    public ColorStateList Zrl8J6Z2Dje;
    public int fVTKpwokKnY;
    public int g0egR5i1XsF;
    public kw gVHumS1PT2O;
    public float hSdjhQTBcYv;
    public final LinkedHashSet kLF8MllXouM;
    public int kMJtaEXWLpZ;
    public boolean lJCHxZXkFBB;
    public boolean mYvwaIfm0QL;
    public ColorStateList miDHqavGimy;
    public String n7QsYWNZtSU;
    public final lw ocrRjEg1xWE;
    public int rAQLLnQzyBa;
    public PorterDuff.Mode uCRx9YCOc24;
    public int wBZqWeQU8tl;
    public boolean yOSzBmjeOMj;
    public int z7hVgGhB3r5;

    public MaterialButton(Context context, AttributeSet attributeSet) {
        super(vi0.gVHumS1PT2O(context, attributeSet, com.kolosta.rejin.kiltor.R.attr.materialButtonStyle, com.kolosta.rejin.kiltor.R.style.Widget_MaterialComponents_Button, new int[]{com.kolosta.rejin.kiltor.R.attr.materialSizeOverlay}), attributeSet, com.kolosta.rejin.kiltor.R.attr.materialButtonStyle);
        this.kLF8MllXouM = new LinkedHashSet();
        this.I538XrPZXnv = false;
        this.mYvwaIfm0QL = false;
        this.ZNZD85DkjoE = Integer.MIN_VALUE;
        this.RD9v7iCsyVj = -2.1474836E9f;
        this.rAQLLnQzyBa = Integer.MIN_VALUE;
        this.OcCEV0cN9EJ = Integer.MIN_VALUE;
        this.kMJtaEXWLpZ = Integer.MIN_VALUE;
        this.gVHumS1PT2O = kw.wJXRvW1l9At;
        Context context2 = getContext();
        TypedArray typedArrayD57UaHJBpF2 = es.D57UaHJBpF2(context2, attributeSet, s40.ocrRjEg1xWE, com.kolosta.rejin.kiltor.R.attr.materialButtonStyle, com.kolosta.rejin.kiltor.R.style.Widget_MaterialComponents_Button, new int[0]);
        this.P56qh5C3eoK = typedArrayD57UaHJBpF2.getDimensionPixelSize(13, 0);
        int i = typedArrayD57UaHJBpF2.getInt(16, -1);
        PorterDuff.Mode mode = PorterDuff.Mode.SRC_IN;
        this.Oby7UOJk982 = v90.kLF8MllXouM(i, mode);
        this.miDHqavGimy = mn0.z7hVgGhB3r5(getContext(), typedArrayD57UaHJBpF2, 15);
        this.H8bE8XWjtoS = mn0.fVTKpwokKnY(getContext(), typedArrayD57UaHJBpF2, 11);
        this.JyMrFevGyEE = typedArrayD57UaHJBpF2.getInteger(12, 1);
        this.g0egR5i1XsF = typedArrayD57UaHJBpF2.getDimensionPixelSize(14, 0);
        this.uCRx9YCOc24 = v90.kLF8MllXouM(typedArrayD57UaHJBpF2.getInt(22, -1), mode);
        this.Zrl8J6Z2Dje = typedArrayD57UaHJBpF2.hasValue(21) ? mn0.z7hVgGhB3r5(getContext(), typedArrayD57UaHJBpF2, 21) : this.miDHqavGimy;
        this.IVXw3Dlz2AG = typedArrayD57UaHJBpF2.getInteger(20, 3);
        Drawable drawableFVTKpwokKnY = mn0.fVTKpwokKnY(getContext(), typedArrayD57UaHJBpF2, 19);
        this.WGVIMf7e7f9 = drawableFVTKpwokKnY;
        this.lJCHxZXkFBB = drawableFVTKpwokKnY == null;
        ac0 ac0VarMarFYthBr4b = me0.MarFYthBr4b(context2, typedArrayD57UaHJBpF2, 23);
        ac0VarMarFYthBr4b = ac0VarMarFYthBr4b == null ? cc0.MarFYthBr4b(context2, attributeSet, com.kolosta.rejin.kiltor.R.attr.materialButtonStyle, com.kolosta.rejin.kiltor.R.style.Widget_MaterialComponents_Button).HgCgyIrsRhc() : ac0VarMarFYthBr4b;
        boolean z = typedArrayD57UaHJBpF2.getBoolean(17, false);
        lw lwVar = new lw(this, ac0VarMarFYthBr4b);
        this.ocrRjEg1xWE = lwVar;
        lwVar.brBhnf7Rph0 = typedArrayD57UaHJBpF2.getDimensionPixelOffset(2, 0);
        lwVar.MarFYthBr4b = typedArrayD57UaHJBpF2.getDimensionPixelOffset(3, 0);
        lwVar.wJXRvW1l9At = typedArrayD57UaHJBpF2.getDimensionPixelOffset(4, 0);
        lwVar.Ndt5adT1n2F = typedArrayD57UaHJBpF2.getDimensionPixelOffset(5, 0);
        if (typedArrayD57UaHJBpF2.hasValue(9)) {
            int dimensionPixelSize = typedArrayD57UaHJBpF2.getDimensionPixelSize(9, -1);
            lwVar.iQvCvXTWXYz = dimensionPixelSize;
            lwVar.nDGTvOUPAhx = lwVar.nDGTvOUPAhx.HgCgyIrsRhc(dimensionPixelSize);
            lwVar.aBUhIZ95pth();
            lwVar.WGVIMf7e7f9 = true;
        }
        lwVar.ykVrBoeh7sI = typedArrayD57UaHJBpF2.getDimensionPixelSize(26, 0);
        lwVar.ocrRjEg1xWE = v90.kLF8MllXouM(typedArrayD57UaHJBpF2.getInt(8, -1), mode);
        lwVar.kLF8MllXouM = mn0.z7hVgGhB3r5(getContext(), typedArrayD57UaHJBpF2, 7);
        lwVar.Oby7UOJk982 = mn0.z7hVgGhB3r5(getContext(), typedArrayD57UaHJBpF2, 25);
        lwVar.miDHqavGimy = mn0.z7hVgGhB3r5(getContext(), typedArrayD57UaHJBpF2, 18);
        lwVar.lJCHxZXkFBB = typedArrayD57UaHJBpF2.getBoolean(6, false);
        lwVar.z7hVgGhB3r5 = typedArrayD57UaHJBpF2.getDimensionPixelSize(10, 0);
        lwVar.n7QsYWNZtSU = typedArrayD57UaHJBpF2.getBoolean(27, true);
        int paddingStart = getPaddingStart();
        int paddingTop = getPaddingTop();
        int paddingEnd = getPaddingEnd();
        int paddingBottom = getPaddingBottom();
        if (typedArrayD57UaHJBpF2.hasValue(0)) {
            lwVar.Zrl8J6Z2Dje = true;
            setSupportBackgroundTintList(lwVar.kLF8MllXouM);
            setSupportBackgroundTintMode(lwVar.ocrRjEg1xWE);
        } else {
            lwVar.kheiy7RMk6s();
        }
        setPaddingRelative(paddingStart + lwVar.brBhnf7Rph0, paddingTop + lwVar.wJXRvW1l9At, paddingEnd + lwVar.MarFYthBr4b, paddingBottom + lwVar.Ndt5adT1n2F);
        setCheckedInternal(typedArrayD57UaHJBpF2.getBoolean(1, false));
        if (ac0VarMarFYthBr4b instanceof me0) {
            lwVar.kheiy7RMk6s = mn0.uHy5z3aH4qy(getContext());
            if (lwVar.nDGTvOUPAhx instanceof me0) {
                lwVar.aBUhIZ95pth();
            }
        }
        setOpticalCenterEnabled(z);
        typedArrayD57UaHJBpF2.recycle();
        setCompoundDrawablePadding(this.P56qh5C3eoK);
        WGVIMf7e7f9(this.H8bE8XWjtoS != null);
        g0egR5i1XsF(this.WGVIMf7e7f9 != null);
    }

    private Layout.Alignment getActualTextAlignment() {
        int textAlignment = getTextAlignment();
        return textAlignment != 1 ? (textAlignment == 6 || textAlignment == 3) ? Layout.Alignment.ALIGN_OPPOSITE : textAlignment != 4 ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER : getGravityTextAlignment();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float getDisplayedWidthIncrease() {
        return this.D5vWTmG37B7;
    }

    private Layout.Alignment getGravityTextAlignment() {
        int gravity = getGravity() & 8388615;
        return gravity != 1 ? (gravity == 5 || gravity == 8388613) ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER;
    }

    private int getOpticalCenterShift() {
        return 0;
    }

    private int getTextHeight() {
        if (getLineCount() > 1) {
            return getLayout().getHeight();
        }
        TextPaint paint = getPaint();
        String string = getText().toString();
        if (getTransformationMethod() != null) {
            string = getTransformationMethod().getTransformation(string, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(string, 0, string.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextLayoutWidth() {
        int lineCount = getLineCount();
        float fMax = 0.0f;
        for (int i = 0; i < lineCount; i++) {
            fMax = Math.max(fMax, getLayout().getLineWidth(i));
        }
        return (int) Math.ceil(fMax);
    }

    private void setCheckedInternal(boolean z) {
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar == null || !lwVar.lJCHxZXkFBB || this.I538XrPZXnv == z) {
            return;
        }
        this.I538XrPZXnv = z;
        refreshDrawableState();
        getParent();
        if (this.mYvwaIfm0QL) {
            return;
        }
        this.mYvwaIfm0QL = true;
        Iterator it = this.kLF8MllXouM.iterator();
        if (!it.hasNext()) {
            this.mYvwaIfm0QL = false;
        } else {
            it.next().getClass();
            zh0.nDGTvOUPAhx();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setDisplayedWidthIncrease(float f) {
        if (this.D5vWTmG37B7 != f) {
            this.D5vWTmG37B7 = f;
            n7QsYWNZtSU();
            invalidate();
            getParent();
        }
    }

    public final boolean H8bE8XWjtoS() {
        int i = this.IVXw3Dlz2AG;
        return i == 16 || i == 32;
    }

    public final int MarFYthBr4b(int i, int i2) {
        int intrinsicWidth;
        int intrinsicWidth2;
        Drawable drawable = this.H8bE8XWjtoS;
        if (drawable != null) {
            intrinsicWidth = this.g0egR5i1XsF;
            if (intrinsicWidth == 0) {
                intrinsicWidth = drawable.getIntrinsicWidth();
            }
        } else {
            intrinsicWidth = 0;
        }
        Drawable drawable2 = this.WGVIMf7e7f9;
        if (drawable2 != null) {
            intrinsicWidth2 = this.g0egR5i1XsF;
            if (intrinsicWidth2 == 0) {
                intrinsicWidth2 = drawable2.getIntrinsicWidth();
            }
        } else {
            intrinsicWidth2 = 0;
        }
        int textLayoutWidth = (((((i - getTextLayoutWidth()) - getPaddingEnd()) - intrinsicWidth) - intrinsicWidth2) - this.P56qh5C3eoK) - getPaddingStart();
        if (getActualTextAlignment() == Layout.Alignment.ALIGN_CENTER) {
            textLayoutWidth /= 2;
        }
        return (getLayoutDirection() == 1) != (i2 == 4) ? -textLayoutWidth : textLayoutWidth;
    }

    public final Drawable Ndt5adT1n2F(int i) {
        if (i == 0) {
            if (this.WGVIMf7e7f9 == null || !miDHqavGimy()) {
                return null;
            }
            return this.WGVIMf7e7f9;
        }
        if (i == 1) {
            if (this.WGVIMf7e7f9 == null || !H8bE8XWjtoS()) {
                return null;
            }
            return this.WGVIMf7e7f9;
        }
        if (i == 2 && this.WGVIMf7e7f9 != null && Oby7UOJk982()) {
            return this.WGVIMf7e7f9;
        }
        return null;
    }

    public final boolean Oby7UOJk982() {
        int i = this.IVXw3Dlz2AG;
        return i == 3 || i == 4;
    }

    public final void WGVIMf7e7f9(boolean z) {
        Drawable drawable = this.H8bE8XWjtoS;
        if (drawable != null) {
            Drawable drawableMutate = drawable.mutate();
            this.H8bE8XWjtoS = drawableMutate;
            drawableMutate.setTintList(this.miDHqavGimy);
            PorterDuff.Mode mode = this.Oby7UOJk982;
            if (mode != null) {
                this.H8bE8XWjtoS.setTintMode(mode);
            }
            int intrinsicWidth = this.g0egR5i1XsF;
            if (intrinsicWidth == 0) {
                intrinsicWidth = this.H8bE8XWjtoS.getIntrinsicWidth();
            }
            int intrinsicHeight = this.g0egR5i1XsF;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.H8bE8XWjtoS.getIntrinsicHeight();
            }
            Drawable drawable2 = this.H8bE8XWjtoS;
            int i = this.z7hVgGhB3r5;
            int i2 = this.C48z5w8gjNK;
            drawable2.setBounds(i, i2, intrinsicWidth + i, intrinsicHeight + i2);
            this.H8bE8XWjtoS.setVisible(true, z);
        }
        if (this.H8bE8XWjtoS != null && this.WGVIMf7e7f9 != null && aBUhIZ95pth()) {
            n4.Ndt5adT1n2F("iconGravity cannot have the same alignment as secondaryIconGravity");
            return;
        }
        if (this.H8bE8XWjtoS == null && this.WGVIMf7e7f9 != null && aBUhIZ95pth()) {
            return;
        }
        Drawable[] compoundDrawablesRelative = getCompoundDrawablesRelative();
        boolean z2 = (ocrRjEg1xWE() && compoundDrawablesRelative[0] != this.H8bE8XWjtoS) || (ykVrBoeh7sI() && compoundDrawablesRelative[2] != this.H8bE8XWjtoS) || (kLF8MllXouM() && compoundDrawablesRelative[1] != this.H8bE8XWjtoS);
        if (z || z2) {
            if (ocrRjEg1xWE()) {
                setCompoundDrawablesRelative(this.H8bE8XWjtoS, Ndt5adT1n2F(1), Ndt5adT1n2F(2), null);
            } else if (ykVrBoeh7sI()) {
                setCompoundDrawablesRelative(Ndt5adT1n2F(0), Ndt5adT1n2F(1), this.H8bE8XWjtoS, null);
            } else if (kLF8MllXouM()) {
                setCompoundDrawablesRelative(Ndt5adT1n2F(0), this.H8bE8XWjtoS, Ndt5adT1n2F(2), null);
            }
        }
    }

    public final /* synthetic */ void Zrl8J6Z2Dje() {
        this.XB6ioTeWZY2 = getOpticalCenterShift();
        n7QsYWNZtSU();
        invalidate();
    }

    public final boolean aBUhIZ95pth() {
        if (ocrRjEg1xWE() && miDHqavGimy()) {
            return true;
        }
        if (ykVrBoeh7sI() && Oby7UOJk982()) {
            return true;
        }
        return kLF8MllXouM() && H8bE8XWjtoS();
    }

    public final boolean brBhnf7Rph0(int i) {
        Layout.Alignment actualTextAlignment = getActualTextAlignment();
        return i == 1 || i == 3 || (i == 2 && actualTextAlignment == Layout.Alignment.ALIGN_NORMAL) || (i == 4 && actualTextAlignment == Layout.Alignment.ALIGN_OPPOSITE);
    }

    public final void g0egR5i1XsF(boolean z) {
        Drawable drawable = this.WGVIMf7e7f9;
        if (drawable != null) {
            Drawable drawableMutate = drawable.mutate();
            this.WGVIMf7e7f9 = drawableMutate;
            drawableMutate.setTintList(this.Zrl8J6Z2Dje);
            PorterDuff.Mode mode = this.uCRx9YCOc24;
            if (mode != null) {
                this.WGVIMf7e7f9.setTintMode(mode);
            }
            int intrinsicWidth = this.g0egR5i1XsF;
            if (intrinsicWidth == 0) {
                intrinsicWidth = this.WGVIMf7e7f9.getIntrinsicWidth();
            }
            int intrinsicHeight = this.g0egR5i1XsF;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.WGVIMf7e7f9.getIntrinsicHeight();
            }
            Drawable drawable2 = this.WGVIMf7e7f9;
            int i = this.fVTKpwokKnY;
            int i2 = this.D57UaHJBpF2;
            drawable2.setBounds(i, i2, intrinsicWidth + i, intrinsicHeight + i2);
            this.WGVIMf7e7f9.setVisible(true, z);
        }
        if (this.WGVIMf7e7f9 != null && this.H8bE8XWjtoS != null && aBUhIZ95pth()) {
            n4.Ndt5adT1n2F("secondaryIconGravity cannot have the same alignment as iconGravity");
            return;
        }
        if (this.WGVIMf7e7f9 == null) {
            if (this.lJCHxZXkFBB) {
                return;
            }
            if (this.H8bE8XWjtoS != null && aBUhIZ95pth()) {
                return;
            }
        }
        Drawable[] compoundDrawablesRelative = getCompoundDrawablesRelative();
        boolean z2 = (miDHqavGimy() && compoundDrawablesRelative[0] != this.WGVIMf7e7f9) || (Oby7UOJk982() && compoundDrawablesRelative[2] != this.WGVIMf7e7f9) || (H8bE8XWjtoS() && compoundDrawablesRelative[1] != this.WGVIMf7e7f9);
        if (z || z2) {
            if (miDHqavGimy()) {
                setCompoundDrawablesRelative(this.WGVIMf7e7f9, iQvCvXTWXYz(1), iQvCvXTWXYz(2), null);
            } else if (Oby7UOJk982()) {
                setCompoundDrawablesRelative(iQvCvXTWXYz(0), iQvCvXTWXYz(1), this.WGVIMf7e7f9, null);
            } else if (H8bE8XWjtoS()) {
                setCompoundDrawablesRelative(iQvCvXTWXYz(0), this.WGVIMf7e7f9, iQvCvXTWXYz(2), null);
            }
        }
    }

    public String getA11yClassName() {
        if (!TextUtils.isEmpty(this.n7QsYWNZtSU)) {
            return this.n7QsYWNZtSU;
        }
        lw lwVar = this.ocrRjEg1xWE;
        return ((lwVar == null || !lwVar.lJCHxZXkFBB) ? Button.class : CompoundButton.class).getName();
    }

    public int getAllowedWidthDecrease() {
        return this.kMJtaEXWLpZ;
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.iQvCvXTWXYz;
        }
        return 0;
    }

    public wd0 getCornerSpringForce() {
        return this.ocrRjEg1xWE.kheiy7RMk6s;
    }

    public Drawable getIcon() {
        return this.H8bE8XWjtoS;
    }

    public int getIconGravity() {
        return this.JyMrFevGyEE;
    }

    public int getIconPadding() {
        return this.P56qh5C3eoK;
    }

    public int getIconSize() {
        return this.g0egR5i1XsF;
    }

    public ColorStateList getIconTint() {
        return this.miDHqavGimy;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.Oby7UOJk982;
    }

    public int getInsetBottom() {
        return this.ocrRjEg1xWE.Ndt5adT1n2F;
    }

    public int getInsetLeft() {
        return this.ocrRjEg1xWE.brBhnf7Rph0;
    }

    public int getInsetRight() {
        return this.ocrRjEg1xWE.MarFYthBr4b;
    }

    public int getInsetTop() {
        return this.ocrRjEg1xWE.wJXRvW1l9At;
    }

    public ColorStateList getRippleColor() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.miDHqavGimy;
        }
        return null;
    }

    public Drawable getSecondaryIcon() {
        return this.WGVIMf7e7f9;
    }

    public int getSecondaryIconGravity() {
        return this.IVXw3Dlz2AG;
    }

    public ColorStateList getSecondaryIconTint() {
        return this.Zrl8J6Z2Dje;
    }

    public PorterDuff.Mode getSecondaryIconTintMode() {
        return this.uCRx9YCOc24;
    }

    public ac0 getShapeAppearance() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.nDGTvOUPAhx;
        }
        n4.C48z5w8gjNK("Attempted to get ShapeAppearance from a MaterialButton which has an overwritten background.");
        return null;
    }

    public cc0 getShapeAppearanceModel() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.nDGTvOUPAhx.aBUhIZ95pth();
        }
        n4.C48z5w8gjNK("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
        return null;
    }

    public ColorStateList getStrokeColor() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.Oby7UOJk982;
        }
        return null;
    }

    public int getStrokeWidth() {
        if (uCRx9YCOc24()) {
            return this.ocrRjEg1xWE.ykVrBoeh7sI;
        }
        return 0;
    }

    @Override // defpackage.q0
    public ColorStateList getSupportBackgroundTintList() {
        return uCRx9YCOc24() ? this.ocrRjEg1xWE.kLF8MllXouM : super.getSupportBackgroundTintList();
    }

    @Override // defpackage.q0
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return uCRx9YCOc24() ? this.ocrRjEg1xWE.ocrRjEg1xWE : super.getSupportBackgroundTintMode();
    }

    public final Drawable iQvCvXTWXYz(int i) {
        if (i == 0) {
            if (this.H8bE8XWjtoS == null || !ocrRjEg1xWE()) {
                return null;
            }
            return this.H8bE8XWjtoS;
        }
        if (i == 1) {
            if (this.H8bE8XWjtoS == null || !ykVrBoeh7sI()) {
                return null;
            }
            return this.H8bE8XWjtoS;
        }
        if (i == 2 && this.H8bE8XWjtoS != null && ykVrBoeh7sI()) {
            return this.H8bE8XWjtoS;
        }
        return null;
    }

    @Override // android.widget.Checkable
    public final boolean isChecked() {
        return this.I538XrPZXnv;
    }

    public final boolean kLF8MllXouM() {
        int i = this.JyMrFevGyEE;
        return i == 16 || i == 32;
    }

    public final void lJCHxZXkFBB(int i, int i2) {
        if (this.H8bE8XWjtoS == null || getLayout() == null) {
            return;
        }
        if (ocrRjEg1xWE() || ykVrBoeh7sI()) {
            this.C48z5w8gjNK = 0;
            if (brBhnf7Rph0(this.JyMrFevGyEE)) {
                this.z7hVgGhB3r5 = 0;
                WGVIMf7e7f9(false);
                return;
            }
            int iMarFYthBr4b = MarFYthBr4b(i, this.JyMrFevGyEE);
            if (this.z7hVgGhB3r5 != iMarFYthBr4b) {
                this.z7hVgGhB3r5 = iMarFYthBr4b;
                WGVIMf7e7f9(false);
                return;
            }
            return;
        }
        if (kLF8MllXouM()) {
            this.z7hVgGhB3r5 = 0;
            if (this.JyMrFevGyEE == 16) {
                this.C48z5w8gjNK = 0;
                WGVIMf7e7f9(false);
                return;
            }
            int intrinsicHeight = this.g0egR5i1XsF;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.H8bE8XWjtoS.getIntrinsicHeight();
            }
            int iWJXRvW1l9At = wJXRvW1l9At(i2, intrinsicHeight);
            if (this.C48z5w8gjNK != iWJXRvW1l9At) {
                this.C48z5w8gjNK = iWJXRvW1l9At;
                WGVIMf7e7f9(false);
            }
        }
    }

    public final boolean miDHqavGimy() {
        int i = this.IVXw3Dlz2AG;
        return i == 1 || i == 2;
    }

    public final void n7QsYWNZtSU() {
        int i = (int) (this.D5vWTmG37B7 - this.hSdjhQTBcYv);
        boolean z = getLayoutDirection() == 1;
        int i2 = this.XB6ioTeWZY2;
        if (z) {
            i2 = -i2;
        }
        int i3 = (i / 2) + i2;
        if (getLayoutParams() != null) {
            getLayoutParams().width = (int) (this.RD9v7iCsyVj + i);
        }
        setPaddingRelative(this.rAQLLnQzyBa + i3, getPaddingTop(), (this.OcCEV0cN9EJ + i) - i3, getPaddingBottom());
    }

    public final boolean ocrRjEg1xWE() {
        int i = this.JyMrFevGyEE;
        return i == 1 || i == 2;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (uCRx9YCOc24()) {
            zd.ZNZD85DkjoE(this, this.ocrRjEg1xWE.HgCgyIrsRhc(false));
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 2);
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar != null && lwVar.lJCHxZXkFBB) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, V73zDzxkiRf);
        }
        if (this.I538XrPZXnv) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, gfMrr7pMNlA);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // defpackage.q0, android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(this.I538XrPZXnv);
    }

    @Override // defpackage.q0, android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        lw lwVar = this.ocrRjEg1xWE;
        accessibilityNodeInfo.setCheckable(lwVar != null && lwVar.lJCHxZXkFBB);
        accessibilityNodeInfo.setChecked(this.I538XrPZXnv);
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @Override // defpackage.q0, android.widget.TextView, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        super.onLayout(z, i, i2, i3, i4);
        lJCHxZXkFBB(getMeasuredWidth(), getMeasuredHeight());
        z7hVgGhB3r5(getMeasuredWidth(), getMeasuredHeight());
        int i6 = getResources().getConfiguration().orientation;
        if (this.ZNZD85DkjoE != i6) {
            this.ZNZD85DkjoE = i6;
            this.RD9v7iCsyVj = -2.1474836E9f;
        }
        if (this.RD9v7iCsyVj == -2.1474836E9f) {
            this.RD9v7iCsyVj = getMeasuredWidth();
            getParent();
        }
        if (this.kMJtaEXWLpZ == Integer.MIN_VALUE) {
            if (this.H8bE8XWjtoS == null) {
                i5 = 0;
            } else {
                int iconPadding = getIconPadding();
                int intrinsicWidth = this.g0egR5i1XsF;
                if (intrinsicWidth == 0) {
                    intrinsicWidth = this.H8bE8XWjtoS.getIntrinsicWidth();
                }
                i5 = iconPadding + intrinsicWidth;
            }
            this.kMJtaEXWLpZ = (getMeasuredWidth() - getTextLayoutWidth()) - i5;
        }
        if (this.rAQLLnQzyBa == Integer.MIN_VALUE) {
            this.rAQLLnQzyBa = getPaddingStart();
        }
        if (this.OcCEV0cN9EJ == Integer.MIN_VALUE) {
            this.OcCEV0cN9EJ = getPaddingEnd();
        }
        getParent();
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof jw)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        jw jwVar = (jw) parcelable;
        super.onRestoreInstanceState(jwVar.wJXRvW1l9At);
        setChecked(jwVar.iQvCvXTWXYz);
    }

    @Override // android.widget.TextView, android.view.View
    public final Parcelable onSaveInstanceState() {
        jw jwVar = new jw(super.onSaveInstanceState());
        jwVar.iQvCvXTWXYz = this.I538XrPZXnv;
        return jwVar;
    }

    @Override // defpackage.q0, android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        lJCHxZXkFBB(getMeasuredWidth(), getMeasuredHeight());
        z7hVgGhB3r5(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public final boolean performClick() {
        boolean z;
        if (isEnabled() && this.ocrRjEg1xWE.n7QsYWNZtSU) {
            toggle();
            z = true;
        } else {
            z = false;
        }
        boolean zPerformClick = super.performClick();
        if (z && !zPerformClick) {
            playSoundEffect(0);
        }
        return zPerformClick;
    }

    @Override // android.view.View
    public final void refreshDrawableState() {
        super.refreshDrawableState();
        if (this.H8bE8XWjtoS != null) {
            if (this.H8bE8XWjtoS.setState(getDrawableState())) {
                invalidate();
            }
        }
    }

    public void setA11yClassName(String str) {
        this.n7QsYWNZtSU = str;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i) {
        if (!uCRx9YCOc24()) {
            super.setBackgroundColor(i);
            return;
        }
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar.HgCgyIrsRhc(false) != null) {
            lwVar.HgCgyIrsRhc(false).setTint(i);
        }
    }

    @Override // defpackage.q0, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (!uCRx9YCOc24()) {
            super.setBackgroundDrawable(drawable);
            return;
        }
        if (drawable == getBackground()) {
            getBackground().setState(drawable.getState());
            return;
        }
        Log.w("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.Zrl8J6Z2Dje = true;
        MaterialButton materialButton = lwVar.HgCgyIrsRhc;
        materialButton.setSupportBackgroundTintList(lwVar.kLF8MllXouM);
        materialButton.setSupportBackgroundTintMode(lwVar.ocrRjEg1xWE);
        super.setBackgroundDrawable(drawable);
    }

    @Override // defpackage.q0, android.view.View
    public void setBackgroundResource(int i) {
        setBackgroundDrawable(i != 0 ? l80.g0egR5i1XsF(getContext(), i) : null);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z) {
        if (uCRx9YCOc24()) {
            this.ocrRjEg1xWE.lJCHxZXkFBB = z;
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        setCheckedInternal(z);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablePadding(int i) {
        if (getCompoundDrawablePadding() != i) {
            this.RD9v7iCsyVj = -2.1474836E9f;
        }
        super.setCompoundDrawablePadding(i);
    }

    public void setCornerRadius(int i) {
        if (uCRx9YCOc24()) {
            lw lwVar = this.ocrRjEg1xWE;
            if (lwVar.WGVIMf7e7f9 && lwVar.iQvCvXTWXYz == i) {
                return;
            }
            lwVar.iQvCvXTWXYz = i;
            lwVar.WGVIMf7e7f9 = true;
            lwVar.nDGTvOUPAhx = lwVar.nDGTvOUPAhx.HgCgyIrsRhc(i);
            lwVar.aBUhIZ95pth();
        }
    }

    public void setCornerRadiusResource(int i) {
        if (uCRx9YCOc24()) {
            setCornerRadius(getResources().getDimensionPixelSize(i));
        }
    }

    public void setCornerSpringForce(wd0 wd0Var) {
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.kheiy7RMk6s = wd0Var;
        if (lwVar.nDGTvOUPAhx instanceof me0) {
            lwVar.aBUhIZ95pth();
        }
    }

    public void setDisplayedWidthDecrease(int i) {
        this.hSdjhQTBcYv = Math.min(i, this.kMJtaEXWLpZ);
        n7QsYWNZtSU();
        invalidate();
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        if (uCRx9YCOc24()) {
            this.ocrRjEg1xWE.HgCgyIrsRhc(false).Oby7UOJk982(f);
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.H8bE8XWjtoS != drawable) {
            this.RD9v7iCsyVj = -2.1474836E9f;
            this.H8bE8XWjtoS = drawable;
            WGVIMf7e7f9(true);
            lJCHxZXkFBB(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i) {
        if (this.JyMrFevGyEE != i) {
            if (this.H8bE8XWjtoS != null && this.WGVIMf7e7f9 != null && aBUhIZ95pth()) {
                n4.Ndt5adT1n2F("iconGravity cannot have the same alignment as secondaryIconGravity");
            } else {
                this.JyMrFevGyEE = i;
                lJCHxZXkFBB(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    public void setIconPadding(int i) {
        if (this.P56qh5C3eoK != i) {
            this.P56qh5C3eoK = i;
            setCompoundDrawablePadding(i);
        }
    }

    public void setIconResource(int i) {
        setIcon(i != 0 ? l80.g0egR5i1XsF(getContext(), i) : null);
    }

    public void setIconSize(int i) {
        if (i < 0) {
            n4.Ndt5adT1n2F("iconSize cannot be less than 0");
        } else if (this.g0egR5i1XsF != i) {
            this.RD9v7iCsyVj = -2.1474836E9f;
            this.g0egR5i1XsF = i;
            WGVIMf7e7f9(true);
            g0egR5i1XsF(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.miDHqavGimy != colorStateList) {
            this.miDHqavGimy = colorStateList;
            WGVIMf7e7f9(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.Oby7UOJk982 != mode) {
            this.Oby7UOJk982 = mode;
            WGVIMf7e7f9(false);
        }
    }

    public void setIconTintResource(int i) {
        setIconTint(mn0.n7QsYWNZtSU(getContext(), i));
    }

    public void setInsetBottom(int i) {
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.nDGTvOUPAhx(lwVar.brBhnf7Rph0, lwVar.wJXRvW1l9At, lwVar.MarFYthBr4b, i);
    }

    public void setInsetLeft(int i) {
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.nDGTvOUPAhx(i, lwVar.wJXRvW1l9At, lwVar.MarFYthBr4b, lwVar.Ndt5adT1n2F);
    }

    public void setInsetRight(int i) {
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.nDGTvOUPAhx(lwVar.brBhnf7Rph0, lwVar.wJXRvW1l9At, i, lwVar.Ndt5adT1n2F);
    }

    public void setInsetTop(int i) {
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.nDGTvOUPAhx(lwVar.brBhnf7Rph0, i, lwVar.MarFYthBr4b, lwVar.Ndt5adT1n2F);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOpticalCenterEnabled(boolean z) {
        if (this.yOSzBmjeOMj != z) {
            this.yOSzBmjeOMj = z;
            lw lwVar = this.ocrRjEg1xWE;
            if (z) {
                vr vrVar = new vr(this);
                lwVar.aBUhIZ95pth = vrVar;
                vw vwVarHgCgyIrsRhc = lwVar.HgCgyIrsRhc(false);
                if (vwVarHgCgyIrsRhc != null) {
                    vwVarHgCgyIrsRhc.XB6ioTeWZY2 = vrVar;
                }
            } else {
                lwVar.aBUhIZ95pth = null;
                vw vwVarHgCgyIrsRhc2 = lwVar.HgCgyIrsRhc(false);
                if (vwVarHgCgyIrsRhc2 != null) {
                    vwVarHgCgyIrsRhc2.XB6ioTeWZY2 = null;
                }
            }
            post(new SO78vOEPH7q(9, this));
        }
    }

    @Override // android.view.View
    public void setPressed(boolean z) {
        super.setPressed(z);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (uCRx9YCOc24()) {
            lw lwVar = this.ocrRjEg1xWE;
            MaterialButton materialButton = lwVar.HgCgyIrsRhc;
            if (lwVar.miDHqavGimy != colorStateList) {
                lwVar.miDHqavGimy = colorStateList;
                if (materialButton.getBackground() instanceof RippleDrawable) {
                    ((RippleDrawable) materialButton.getBackground()).setColor(e80.nDGTvOUPAhx(colorStateList));
                }
            }
        }
    }

    public void setRippleColorResource(int i) {
        if (uCRx9YCOc24()) {
            setRippleColor(mn0.n7QsYWNZtSU(getContext(), i));
        }
    }

    public void setSecondaryIcon(Drawable drawable) {
        if (this.WGVIMf7e7f9 != drawable) {
            this.RD9v7iCsyVj = -2.1474836E9f;
            this.WGVIMf7e7f9 = drawable;
            this.lJCHxZXkFBB = false;
            g0egR5i1XsF(true);
            z7hVgGhB3r5(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setSecondaryIconGravity(int i) {
        if (this.IVXw3Dlz2AG != i) {
            if (this.WGVIMf7e7f9 != null && this.H8bE8XWjtoS != null && aBUhIZ95pth()) {
                n4.Ndt5adT1n2F("secondaryIconGravity cannot have the same alignment as iconGravity");
            } else {
                this.IVXw3Dlz2AG = i;
                z7hVgGhB3r5(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    public void setSecondaryIconResource(int i) {
        setSecondaryIcon(i != 0 ? l80.g0egR5i1XsF(getContext(), i) : null);
    }

    public void setSecondaryIconTint(ColorStateList colorStateList) {
        if (this.Zrl8J6Z2Dje != colorStateList) {
            this.Zrl8J6Z2Dje = colorStateList;
            g0egR5i1XsF(false);
        }
    }

    public void setSecondaryIconTintMode(PorterDuff.Mode mode) {
        if (this.uCRx9YCOc24 != mode) {
            this.uCRx9YCOc24 = mode;
            g0egR5i1XsF(false);
        }
    }

    public void setSecondaryIconTintResource(int i) {
        setSecondaryIconTint(mn0.n7QsYWNZtSU(getContext(), i));
    }

    public void setShapeAppearance(ac0 ac0Var) {
        if (!uCRx9YCOc24()) {
            n4.C48z5w8gjNK("Attempted to set ShapeAppearance on a MaterialButton which has an overwritten background.");
            return;
        }
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar.kheiy7RMk6s == null && ac0Var.brBhnf7Rph0()) {
            lwVar.kheiy7RMk6s = mn0.uHy5z3aH4qy(getContext());
            if (lwVar.nDGTvOUPAhx instanceof me0) {
                lwVar.aBUhIZ95pth();
            }
        }
        lwVar.nDGTvOUPAhx = ac0Var;
        lwVar.aBUhIZ95pth();
    }

    @Override // defpackage.mc0
    public void setShapeAppearanceModel(cc0 cc0Var) {
        if (!uCRx9YCOc24()) {
            n4.C48z5w8gjNK("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
            return;
        }
        lw lwVar = this.ocrRjEg1xWE;
        lwVar.nDGTvOUPAhx = cc0Var;
        lwVar.aBUhIZ95pth();
    }

    public void setShouldDrawSurfaceColorStroke(boolean z) {
        if (uCRx9YCOc24()) {
            lw lwVar = this.ocrRjEg1xWE;
            lwVar.uCRx9YCOc24 = z;
            lwVar.brBhnf7Rph0();
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (uCRx9YCOc24()) {
            lw lwVar = this.ocrRjEg1xWE;
            if (lwVar.Oby7UOJk982 != colorStateList) {
                lwVar.Oby7UOJk982 = colorStateList;
                lwVar.brBhnf7Rph0();
            }
        }
    }

    public void setStrokeColorResource(int i) {
        if (uCRx9YCOc24()) {
            setStrokeColor(mn0.n7QsYWNZtSU(getContext(), i));
        }
    }

    public void setStrokeWidth(int i) {
        if (uCRx9YCOc24()) {
            lw lwVar = this.ocrRjEg1xWE;
            if (lwVar.ykVrBoeh7sI != i) {
                lwVar.ykVrBoeh7sI = i;
                lwVar.brBhnf7Rph0();
            }
        }
    }

    public void setStrokeWidthResource(int i) {
        if (uCRx9YCOc24()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i));
        }
    }

    @Override // defpackage.q0
    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (!uCRx9YCOc24()) {
            super.setSupportBackgroundTintList(colorStateList);
            return;
        }
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar.kLF8MllXouM != colorStateList) {
            lwVar.kLF8MllXouM = colorStateList;
            if (lwVar.HgCgyIrsRhc(false) != null) {
                lwVar.HgCgyIrsRhc(false).setTintList(lwVar.kLF8MllXouM);
            }
        }
    }

    @Override // defpackage.q0
    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (!uCRx9YCOc24()) {
            super.setSupportBackgroundTintMode(mode);
            return;
        }
        lw lwVar = this.ocrRjEg1xWE;
        if (lwVar.ocrRjEg1xWE != mode) {
            lwVar.ocrRjEg1xWE = mode;
            if (lwVar.HgCgyIrsRhc(false) == null || lwVar.ocrRjEg1xWE == null) {
                return;
            }
            lwVar.HgCgyIrsRhc(false).setTintMode(lwVar.ocrRjEg1xWE);
        }
    }

    @Override // android.widget.TextView
    public final void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        this.RD9v7iCsyVj = -2.1474836E9f;
        super.setText(charSequence, bufferType);
    }

    @Override // android.view.View
    public void setTextAlignment(int i) {
        super.setTextAlignment(i);
        lJCHxZXkFBB(getMeasuredWidth(), getMeasuredHeight());
        z7hVgGhB3r5(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // defpackage.q0, android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        this.RD9v7iCsyVj = -2.1474836E9f;
        super.setTextAppearance(context, i);
    }

    @Override // defpackage.q0, android.widget.TextView
    public final void setTextSize(int i, float f) {
        this.RD9v7iCsyVj = -2.1474836E9f;
        super.setTextSize(i, f);
    }

    public void setToggleCheckedStateOnClick(boolean z) {
        this.ocrRjEg1xWE.n7QsYWNZtSU = z;
    }

    @Override // android.widget.TextView
    public void setWidth(int i) {
        this.RD9v7iCsyVj = -2.1474836E9f;
        super.setWidth(i);
    }

    public void setWidthChangeDirection(kw kwVar) {
        if (this.gVHumS1PT2O != kwVar) {
            this.gVHumS1PT2O = kwVar;
        }
    }

    public void setWidthChangeMax(int i) {
        if (this.wBZqWeQU8tl != i) {
            this.wBZqWeQU8tl = i;
        }
    }

    @Override // android.widget.Checkable
    public final void toggle() {
        setChecked(!this.I538XrPZXnv);
    }

    public final boolean uCRx9YCOc24() {
        lw lwVar = this.ocrRjEg1xWE;
        return (lwVar == null || lwVar.Zrl8J6Z2Dje) ? false : true;
    }

    public final int wJXRvW1l9At(int i, int i2) {
        return Math.max(0, (((((i - getTextHeight()) - getPaddingTop()) - i2) - this.P56qh5C3eoK) - getPaddingBottom()) / 2);
    }

    public final boolean ykVrBoeh7sI() {
        int i = this.JyMrFevGyEE;
        return i == 3 || i == 4;
    }

    public final void z7hVgGhB3r5(int i, int i2) {
        if (this.WGVIMf7e7f9 == null || getLayout() == null) {
            return;
        }
        if (miDHqavGimy() || Oby7UOJk982()) {
            this.D57UaHJBpF2 = 0;
            if (brBhnf7Rph0(this.IVXw3Dlz2AG)) {
                this.fVTKpwokKnY = 0;
                g0egR5i1XsF(false);
                return;
            }
            int iMarFYthBr4b = MarFYthBr4b(i, this.IVXw3Dlz2AG);
            if (this.fVTKpwokKnY != iMarFYthBr4b) {
                this.fVTKpwokKnY = iMarFYthBr4b;
                g0egR5i1XsF(false);
                return;
            }
            return;
        }
        if (H8bE8XWjtoS()) {
            this.fVTKpwokKnY = 0;
            if (this.IVXw3Dlz2AG == 16) {
                this.D57UaHJBpF2 = 0;
                g0egR5i1XsF(false);
                return;
            }
            int intrinsicHeight = this.g0egR5i1XsF;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.WGVIMf7e7f9.getIntrinsicHeight();
            }
            int iWJXRvW1l9At = wJXRvW1l9At(i2, intrinsicHeight);
            if (this.D57UaHJBpF2 != iWJXRvW1l9At) {
                this.D57UaHJBpF2 = iWJXRvW1l9At;
                g0egR5i1XsF(false);
            }
        }
    }

    public void setOnPressedChangeListenerInternal(iw iwVar) {
    }

    public void setSizeChange(ne0 ne0Var) {
    }

    public MaterialButton(Context context) {
        this(context, null);
    }
}
