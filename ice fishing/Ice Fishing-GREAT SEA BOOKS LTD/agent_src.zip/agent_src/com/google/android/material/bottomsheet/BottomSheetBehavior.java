package com.google.android.material.bottomsheet;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import com.kolosta.rejin.kiltor.R;
import defpackage.X0MyC8YR7bY;
import defpackage.bd0;
import defpackage.cc0;
import defpackage.ew;
import defpackage.h5;
import defpackage.m4;
import defpackage.mn0;
import defpackage.n4;
import defpackage.s40;
import defpackage.vw;
import defpackage.zd;
import java.util.ArrayList;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class BottomSheetBehavior<V extends View> extends zd implements ew {
    public boolean IVXw3Dlz2AG;
    public int JyMrFevGyEE;
    public final cc0 OcCEV0cN9EJ;
    public final ColorStateList RD9v7iCsyVj;
    public final ValueAnimator XB6ioTeWZY2;
    public final vw ZNZD85DkjoE;
    public int gVHumS1PT2O;
    public final int kMJtaEXWLpZ;
    public final boolean mYvwaIfm0QL;
    public final boolean rAQLLnQzyBa;
    public final boolean wBZqWeQU8tl;
    public boolean yOSzBmjeOMj;

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        int i;
        int i2;
        this.mYvwaIfm0QL = true;
        new X0MyC8YR7bY(this);
        this.gVHumS1PT2O = 4;
        new ArrayList();
        new ArrayList();
        new SparseIntArray();
        new SparseIntArray();
        new SparseIntArray();
        new Rect();
        context.getResources().getDimensionPixelSize(R.dimen.mtrl_min_touch_target_size);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s40.kheiy7RMk6s);
        int i3 = 3;
        if (typedArrayObtainStyledAttributes.hasValue(3)) {
            this.RD9v7iCsyVj = mn0.z7hVgGhB3r5(context, typedArrayObtainStyledAttributes, 3);
        }
        if (typedArrayObtainStyledAttributes.hasValue(24)) {
            this.OcCEV0cN9EJ = cc0.MarFYthBr4b(context, attributeSet, R.attr.bottomSheetStyle, R.style.Widget_Design_BottomSheet_Modal).HgCgyIrsRhc();
        }
        cc0 cc0Var = this.OcCEV0cN9EJ;
        if (cc0Var != null) {
            vw vwVar = new vw(cc0Var);
            this.ZNZD85DkjoE = vwVar;
            vwVar.ykVrBoeh7sI(context);
            ColorStateList colorStateList = this.RD9v7iCsyVj;
            if (colorStateList != null) {
                this.ZNZD85DkjoE.miDHqavGimy(colorStateList);
            } else {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(android.R.attr.colorBackground, typedValue, true);
                this.ZNZD85DkjoE.setTint(typedValue.data);
            }
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.XB6ioTeWZY2 = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(500L);
        this.XB6ioTeWZY2.addUpdateListener(new h5(0, this));
        typedArrayObtainStyledAttributes.getDimension(2, -1.0f);
        if (typedArrayObtainStyledAttributes.hasValue(0)) {
            typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1);
        }
        if (typedArrayObtainStyledAttributes.hasValue(1)) {
            typedArrayObtainStyledAttributes.getDimensionPixelSize(1, -1);
        }
        TypedValue typedValuePeekValue = typedArrayObtainStyledAttributes.peekValue(12);
        if (typedValuePeekValue == null || (i2 = typedValuePeekValue.data) != -1) {
            D5vWTmG37B7(typedArrayObtainStyledAttributes.getDimensionPixelSize(12, -1));
        } else {
            D5vWTmG37B7(i2);
        }
        boolean z = typedArrayObtainStyledAttributes.getBoolean(10, false);
        if (this.wBZqWeQU8tl != z) {
            this.wBZqWeQU8tl = z;
            if (!z && this.gVHumS1PT2O == 5) {
                hSdjhQTBcYv(4);
            }
        }
        typedArrayObtainStyledAttributes.getBoolean(16, false);
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(8, true);
        if (this.mYvwaIfm0QL != z2) {
            this.mYvwaIfm0QL = z2;
            if (!z2 || (i = this.gVHumS1PT2O) != 6) {
                i3 = this.gVHumS1PT2O;
                i = i3;
            }
            if (i == i3) {
                i3 = i;
            } else {
                this.gVHumS1PT2O = i3;
            }
            V73zDzxkiRf(i3);
        }
        typedArrayObtainStyledAttributes.getBoolean(15, false);
        typedArrayObtainStyledAttributes.getBoolean(5, true);
        typedArrayObtainStyledAttributes.getBoolean(6, true);
        typedArrayObtainStyledAttributes.getInt(13, 0);
        float f = typedArrayObtainStyledAttributes.getFloat(9, 0.5f);
        if (f <= 0.0f || f >= 1.0f) {
            n4.Ndt5adT1n2F("ratio must be a float value between 0 and 1");
            throw null;
        }
        TypedValue typedValuePeekValue2 = typedArrayObtainStyledAttributes.peekValue(7);
        if (typedValuePeekValue2 == null || typedValuePeekValue2.type != 16) {
            int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(7, 0);
            if (dimensionPixelOffset < 0) {
                n4.Ndt5adT1n2F("offset must be greater than or equal to 0");
                throw null;
            }
            this.kMJtaEXWLpZ = dimensionPixelOffset;
            V73zDzxkiRf(this.gVHumS1PT2O);
        } else {
            int i4 = typedValuePeekValue2.data;
            if (i4 < 0) {
                n4.Ndt5adT1n2F("offset must be greater than or equal to 0");
                throw null;
            }
            this.kMJtaEXWLpZ = i4;
            V73zDzxkiRf(this.gVHumS1PT2O);
        }
        typedArrayObtainStyledAttributes.getInt(14, 500);
        typedArrayObtainStyledAttributes.getBoolean(11, false);
        typedArrayObtainStyledAttributes.getBoolean(4, true);
        typedArrayObtainStyledAttributes.getBoolean(20, false);
        typedArrayObtainStyledAttributes.getBoolean(21, false);
        typedArrayObtainStyledAttributes.getBoolean(22, false);
        typedArrayObtainStyledAttributes.getBoolean(23, true);
        typedArrayObtainStyledAttributes.getBoolean(17, false);
        typedArrayObtainStyledAttributes.getBoolean(18, false);
        typedArrayObtainStyledAttributes.getBoolean(19, false);
        this.rAQLLnQzyBa = typedArrayObtainStyledAttributes.getBoolean(26, true);
        typedArrayObtainStyledAttributes.recycle();
        ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    public final void D5vWTmG37B7(int i) {
        boolean z = this.IVXw3Dlz2AG;
        if (i == -1) {
            if (z) {
                return;
            }
            this.IVXw3Dlz2AG = true;
        } else if (z || this.JyMrFevGyEE != i) {
            this.IVXw3Dlz2AG = false;
            this.JyMrFevGyEE = Math.max(0, i);
        }
    }

    public final void V73zDzxkiRf(int i) {
        vw vwVar;
        if (i == 2) {
            return;
        }
        boolean z = this.gVHumS1PT2O == 3 && this.rAQLLnQzyBa;
        if (this.yOSzBmjeOMj == z || (vwVar = this.ZNZD85DkjoE) == null) {
            return;
        }
        this.yOSzBmjeOMj = z;
        ValueAnimator valueAnimator = this.XB6ioTeWZY2;
        if (valueAnimator == null) {
            if (valueAnimator != null && valueAnimator.isRunning()) {
                valueAnimator.cancel();
            }
            vwVar.H8bE8XWjtoS(this.yOSzBmjeOMj ? 0.0f : 1.0f);
            return;
        }
        if (valueAnimator.isRunning()) {
            valueAnimator.reverse();
        } else {
            valueAnimator.setFloatValues(vwVar.Ndt5adT1n2F.iQvCvXTWXYz, z ? 0.0f : 1.0f);
            valueAnimator.start();
        }
    }

    public final void hSdjhQTBcYv(int i) {
        boolean z;
        if (i == 1 || i == 2) {
            StringBuilder sb = new StringBuilder("STATE_");
            sb.append(i == 1 ? "DRAGGING" : "SETTLING");
            sb.append(" should not be set externally.");
            throw new IllegalArgumentException(sb.toString());
        }
        if (!this.wBZqWeQU8tl && i == 5) {
            Log.w("BottomSheetBehavior", "Cannot set state: " + i);
            return;
        }
        if (i == 6 && (z = this.mYvwaIfm0QL)) {
            if (i != 3) {
                if (i != 4 && i != 5 && i != 6) {
                    n4.Ndt5adT1n2F(bd0.brBhnf7Rph0(i, "Invalid state to get top offset: "));
                    return;
                }
            } else if (!z) {
                Math.max(this.kMJtaEXWLpZ, 0);
            }
        }
        if (this.gVHumS1PT2O == i) {
            return;
        }
        this.gVHumS1PT2O = i;
    }

    @Override // defpackage.ew
    public final void kheiy7RMk6s(m4 m4Var) {
    }

    @Override // defpackage.ew
    public final void nDGTvOUPAhx(m4 m4Var) {
    }

    @Override // defpackage.ew
    public final void HgCgyIrsRhc() {
    }

    @Override // defpackage.ew
    public final void aBUhIZ95pth() {
    }

    public BottomSheetBehavior() {
        this.mYvwaIfm0QL = true;
        new X0MyC8YR7bY(this);
        this.gVHumS1PT2O = 4;
        new ArrayList();
        new ArrayList();
        new SparseIntArray();
        new SparseIntArray();
        new SparseIntArray();
        new Rect();
    }
}
