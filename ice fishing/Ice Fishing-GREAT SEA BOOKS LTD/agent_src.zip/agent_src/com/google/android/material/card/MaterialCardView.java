package com.google.android.material.card;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.FrameLayout;
import defpackage.cc0;
import defpackage.es;
import defpackage.f6;
import defpackage.l80;
import defpackage.mc0;
import defpackage.me0;
import defpackage.mn0;
import defpackage.mw;
import defpackage.ow;
import defpackage.s40;
import defpackage.tw;
import defpackage.vi0;
import defpackage.vw;
import defpackage.wd0;
import defpackage.zd;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class MaterialCardView extends f6 implements Checkable, mc0 {
    public boolean H8bE8XWjtoS;
    public final ow Oby7UOJk982;
    public final boolean miDHqavGimy;
    public boolean uCRx9YCOc24;
    public static final int[] Zrl8J6Z2Dje = {R.attr.state_checkable};
    public static final int[] WGVIMf7e7f9 = {R.attr.state_checked};
    public static final int[] lJCHxZXkFBB = {com.kolosta.rejin.kiltor.R.attr.state_dragged};
    public static final int[] n7QsYWNZtSU = {R.attr.state_hovered};

    public MaterialCardView(Context context, AttributeSet attributeSet) {
        me0 me0VarMarFYthBr4b;
        super(vi0.wBZqWeQU8tl(context, attributeSet, com.kolosta.rejin.kiltor.R.attr.materialCardViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_MaterialComponents_CardView), attributeSet);
        this.H8bE8XWjtoS = false;
        this.uCRx9YCOc24 = false;
        this.miDHqavGimy = true;
        TypedArray typedArrayD57UaHJBpF2 = es.D57UaHJBpF2(getContext(), attributeSet, s40.kLF8MllXouM, com.kolosta.rejin.kiltor.R.attr.materialCardViewStyle, com.kolosta.rejin.kiltor.R.style.Widget_MaterialComponents_CardView, new int[0]);
        ow owVar = new ow(this, attributeSet);
        this.Oby7UOJk982 = owVar;
        ColorStateList cardBackgroundColor = super.getCardBackgroundColor();
        vw vwVar = owVar.kheiy7RMk6s;
        vwVar.miDHqavGimy(cardBackgroundColor);
        owVar.nDGTvOUPAhx.set(super.getContentPaddingLeft(), super.getContentPaddingTop(), super.getContentPaddingRight(), super.getContentPaddingBottom());
        owVar.kLF8MllXouM();
        MaterialCardView materialCardView = owVar.HgCgyIrsRhc;
        ColorStateList colorStateListZ7hVgGhB3r5 = mn0.z7hVgGhB3r5(materialCardView.getContext(), typedArrayD57UaHJBpF2, 11);
        owVar.H8bE8XWjtoS = colorStateListZ7hVgGhB3r5;
        if (colorStateListZ7hVgGhB3r5 == null) {
            owVar.H8bE8XWjtoS = ColorStateList.valueOf(-1);
        }
        owVar.iQvCvXTWXYz = typedArrayD57UaHJBpF2.getDimensionPixelSize(12, 0);
        boolean z = typedArrayD57UaHJBpF2.getBoolean(0, false);
        owVar.n7QsYWNZtSU = z;
        materialCardView.setLongClickable(z);
        owVar.Oby7UOJk982 = mn0.z7hVgGhB3r5(materialCardView.getContext(), typedArrayD57UaHJBpF2, 6);
        owVar.wJXRvW1l9At(mn0.fVTKpwokKnY(materialCardView.getContext(), typedArrayD57UaHJBpF2, 2));
        owVar.wJXRvW1l9At = typedArrayD57UaHJBpF2.getDimensionPixelSize(5, 0);
        owVar.MarFYthBr4b = typedArrayD57UaHJBpF2.getDimensionPixelSize(4, 0);
        owVar.Ndt5adT1n2F = typedArrayD57UaHJBpF2.getInteger(3, 8388661);
        ColorStateList colorStateListZ7hVgGhB3r52 = mn0.z7hVgGhB3r5(materialCardView.getContext(), typedArrayD57UaHJBpF2, 7);
        owVar.kLF8MllXouM = colorStateListZ7hVgGhB3r52;
        if (colorStateListZ7hVgGhB3r52 == null) {
            owVar.kLF8MllXouM = ColorStateList.valueOf(vi0.uCRx9YCOc24(materialCardView, com.kolosta.rejin.kiltor.R.attr.colorControlHighlight));
        }
        ColorStateList colorStateListZ7hVgGhB3r53 = mn0.z7hVgGhB3r5(materialCardView.getContext(), typedArrayD57UaHJBpF2, 1);
        colorStateListZ7hVgGhB3r53 = colorStateListZ7hVgGhB3r53 == null ? ColorStateList.valueOf(0) : colorStateListZ7hVgGhB3r53;
        vw vwVar2 = owVar.aBUhIZ95pth;
        vwVar2.miDHqavGimy(colorStateListZ7hVgGhB3r53);
        RippleDrawable rippleDrawable = owVar.uCRx9YCOc24;
        if (rippleDrawable != null) {
            rippleDrawable.setColor(owVar.kLF8MllXouM);
        }
        vwVar.Oby7UOJk982(materialCardView.getCardElevation());
        float f = owVar.iQvCvXTWXYz;
        ColorStateList colorStateList = owVar.H8bE8XWjtoS;
        vwVar2.Ndt5adT1n2F.ykVrBoeh7sI = f;
        vwVar2.invalidateSelf();
        tw twVar = vwVar2.Ndt5adT1n2F;
        if (twVar.aBUhIZ95pth != colorStateList) {
            twVar.aBUhIZ95pth = colorStateList;
            vwVar2.onStateChange(vwVar2.getState());
        }
        materialCardView.setBackgroundInternal(owVar.aBUhIZ95pth(vwVar));
        Drawable drawableKheiy7RMk6s = owVar.ykVrBoeh7sI() ? owVar.kheiy7RMk6s() : vwVar2;
        owVar.ykVrBoeh7sI = drawableKheiy7RMk6s;
        materialCardView.setForeground(owVar.aBUhIZ95pth(drawableKheiy7RMk6s));
        if (owVar.brBhnf7Rph0 == -1.0f && (me0VarMarFYthBr4b = me0.MarFYthBr4b(materialCardView.getContext(), typedArrayD57UaHJBpF2, 8)) != null) {
            wd0 wd0VarUHy5z3aH4qy = mn0.uHy5z3aH4qy(materialCardView.getContext());
            vwVar.kLF8MllXouM(wd0VarUHy5z3aH4qy);
            vwVar2.kLF8MllXouM(wd0VarUHy5z3aH4qy);
            vw vwVar3 = owVar.WGVIMf7e7f9;
            if (vwVar3 != null) {
                vwVar3.kLF8MllXouM(wd0VarUHy5z3aH4qy);
            }
            owVar.Ndt5adT1n2F(me0VarMarFYthBr4b);
        }
        typedArrayD57UaHJBpF2.recycle();
    }

    private RectF getBoundsAsRectF() {
        RectF rectF = new RectF();
        rectF.set(this.Oby7UOJk982.kheiy7RMk6s.getBounds());
        return rectF;
    }

    @Override // defpackage.f6
    public ColorStateList getCardBackgroundColor() {
        return this.Oby7UOJk982.kheiy7RMk6s.Ndt5adT1n2F.kheiy7RMk6s;
    }

    public ColorStateList getCardForegroundColor() {
        return this.Oby7UOJk982.aBUhIZ95pth.Ndt5adT1n2F.kheiy7RMk6s;
    }

    public float getCardViewRadius() {
        return super.getRadius();
    }

    public Drawable getCheckedIcon() {
        return this.Oby7UOJk982.ocrRjEg1xWE;
    }

    public int getCheckedIconGravity() {
        return this.Oby7UOJk982.Ndt5adT1n2F;
    }

    public int getCheckedIconMargin() {
        return this.Oby7UOJk982.MarFYthBr4b;
    }

    public int getCheckedIconSize() {
        return this.Oby7UOJk982.wJXRvW1l9At;
    }

    public ColorStateList getCheckedIconTint() {
        return this.Oby7UOJk982.Oby7UOJk982;
    }

    @Override // defpackage.f6
    public int getContentPaddingBottom() {
        return this.Oby7UOJk982.nDGTvOUPAhx.bottom;
    }

    @Override // defpackage.f6
    public int getContentPaddingLeft() {
        return this.Oby7UOJk982.nDGTvOUPAhx.left;
    }

    @Override // defpackage.f6
    public int getContentPaddingRight() {
        return this.Oby7UOJk982.nDGTvOUPAhx.right;
    }

    @Override // defpackage.f6
    public int getContentPaddingTop() {
        return this.Oby7UOJk982.nDGTvOUPAhx.top;
    }

    public float getProgress() {
        return this.Oby7UOJk982.kheiy7RMk6s.Ndt5adT1n2F.iQvCvXTWXYz;
    }

    @Override // defpackage.f6
    public float getRadius() {
        vw vwVar = this.Oby7UOJk982.kheiy7RMk6s;
        float[] fArr = vwVar.OcCEV0cN9EJ;
        return fArr != null ? fArr[3] : vwVar.Ndt5adT1n2F.HgCgyIrsRhc.aBUhIZ95pth().brBhnf7Rph0.HgCgyIrsRhc(vwVar.brBhnf7Rph0());
    }

    public ColorStateList getRippleColor() {
        return this.Oby7UOJk982.kLF8MllXouM;
    }

    public cc0 getShapeAppearanceModel() {
        return this.Oby7UOJk982.miDHqavGimy.aBUhIZ95pth();
    }

    @Deprecated
    public int getStrokeColor() {
        ColorStateList colorStateList = this.Oby7UOJk982.H8bE8XWjtoS;
        if (colorStateList == null) {
            return -1;
        }
        return colorStateList.getDefaultColor();
    }

    public ColorStateList getStrokeColorStateList() {
        return this.Oby7UOJk982.H8bE8XWjtoS;
    }

    public int getStrokeWidth() {
        return this.Oby7UOJk982.iQvCvXTWXYz;
    }

    @Override // android.widget.Checkable
    public final boolean isChecked() {
        return this.H8bE8XWjtoS;
    }

    public final void nDGTvOUPAhx() {
        ow owVar;
        RippleDrawable rippleDrawable;
        if (Build.VERSION.SDK_INT <= 26 || (rippleDrawable = (owVar = this.Oby7UOJk982).uCRx9YCOc24) == null) {
            return;
        }
        Rect bounds = rippleDrawable.getBounds();
        int i = bounds.bottom;
        owVar.uCRx9YCOc24.setBounds(bounds.left, bounds.top, bounds.right, i - 1);
        owVar.uCRx9YCOc24.setBounds(bounds.left, bounds.top, bounds.right, i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ow owVar = this.Oby7UOJk982;
        owVar.ocrRjEg1xWE();
        zd.ZNZD85DkjoE(this, owVar.kheiy7RMk6s);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 8);
        ow owVar = this.Oby7UOJk982;
        if (owVar != null && owVar.n7QsYWNZtSU) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, Zrl8J6Z2Dje);
        }
        if (this.H8bE8XWjtoS) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, WGVIMf7e7f9);
        }
        if (this.uCRx9YCOc24) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, lJCHxZXkFBB);
        }
        if (isDuplicateParentStateEnabled()) {
            if (isPressed()) {
                View.mergeDrawableStates(iArrOnCreateDrawableState, FrameLayout.PRESSED_STATE_SET);
            }
            if (isHovered()) {
                View.mergeDrawableStates(iArrOnCreateDrawableState, n7QsYWNZtSU);
            }
            if (isEnabled()) {
                View.mergeDrawableStates(iArrOnCreateDrawableState, FrameLayout.ENABLED_STATE_SET);
            }
            if (isFocused()) {
                View.mergeDrawableStates(iArrOnCreateDrawableState, FrameLayout.FOCUSED_STATE_SET);
            }
            if (isSelected()) {
                View.mergeDrawableStates(iArrOnCreateDrawableState, FrameLayout.SELECTED_STATE_SET);
            }
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.cardview.widget.CardView");
        accessibilityEvent.setChecked(this.H8bE8XWjtoS);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.cardview.widget.CardView");
        ow owVar = this.Oby7UOJk982;
        accessibilityNodeInfo.setCheckable(owVar != null && owVar.n7QsYWNZtSU);
        accessibilityNodeInfo.setClickable(isClickable());
        accessibilityNodeInfo.setChecked(this.H8bE8XWjtoS);
    }

    @Override // defpackage.f6, android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.Oby7UOJk982.brBhnf7Rph0(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (this.miDHqavGimy) {
            ow owVar = this.Oby7UOJk982;
            if (!owVar.lJCHxZXkFBB) {
                Log.i("MaterialCardView", "Setting a custom background is not supported.");
                owVar.lJCHxZXkFBB = true;
            }
            super.setBackgroundDrawable(drawable);
        }
    }

    public void setBackgroundInternal(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    @Override // defpackage.f6
    public void setCardBackgroundColor(int i) {
        this.Oby7UOJk982.kheiy7RMk6s.miDHqavGimy(ColorStateList.valueOf(i));
    }

    @Override // defpackage.f6
    public void setCardElevation(float f) {
        super.setCardElevation(f);
        ow owVar = this.Oby7UOJk982;
        owVar.kheiy7RMk6s.Oby7UOJk982(owVar.HgCgyIrsRhc.getCardElevation());
    }

    public void setCardForegroundColor(ColorStateList colorStateList) {
        vw vwVar = this.Oby7UOJk982.aBUhIZ95pth;
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        vwVar.miDHqavGimy(colorStateList);
    }

    public void setCheckable(boolean z) {
        this.Oby7UOJk982.n7QsYWNZtSU = z;
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (this.H8bE8XWjtoS != z) {
            toggle();
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        this.Oby7UOJk982.wJXRvW1l9At(drawable);
    }

    public void setCheckedIconGravity(int i) {
        ow owVar = this.Oby7UOJk982;
        if (owVar.Ndt5adT1n2F != i) {
            owVar.Ndt5adT1n2F = i;
            MaterialCardView materialCardView = owVar.HgCgyIrsRhc;
            owVar.brBhnf7Rph0(materialCardView.getMeasuredWidth(), materialCardView.getMeasuredHeight());
        }
    }

    public void setCheckedIconMargin(int i) {
        this.Oby7UOJk982.MarFYthBr4b = i;
    }

    public void setCheckedIconMarginResource(int i) {
        if (i != -1) {
            this.Oby7UOJk982.MarFYthBr4b = getResources().getDimensionPixelSize(i);
        }
    }

    public void setCheckedIconResource(int i) {
        this.Oby7UOJk982.wJXRvW1l9At(l80.g0egR5i1XsF(getContext(), i));
    }

    public void setCheckedIconSize(int i) {
        this.Oby7UOJk982.wJXRvW1l9At = i;
    }

    public void setCheckedIconSizeResource(int i) {
        if (i != 0) {
            this.Oby7UOJk982.wJXRvW1l9At = getResources().getDimensionPixelSize(i);
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        ow owVar = this.Oby7UOJk982;
        owVar.Oby7UOJk982 = colorStateList;
        Drawable drawable = owVar.ocrRjEg1xWE;
        if (drawable != null) {
            drawable.setTintList(colorStateList);
        }
    }

    @Override // android.view.View
    public void setClickable(boolean z) {
        super.setClickable(z);
        ow owVar = this.Oby7UOJk982;
        if (owVar != null) {
            owVar.ocrRjEg1xWE();
        }
    }

    public void setDragged(boolean z) {
        if (this.uCRx9YCOc24 != z) {
            this.uCRx9YCOc24 = z;
            refreshDrawableState();
            nDGTvOUPAhx();
            invalidate();
        }
    }

    @Override // defpackage.f6
    public void setMaxCardElevation(float f) {
        super.setMaxCardElevation(f);
        this.Oby7UOJk982.Oby7UOJk982();
    }

    @Override // defpackage.f6
    public void setPreventCornerOverlap(boolean z) {
        super.setPreventCornerOverlap(z);
        ow owVar = this.Oby7UOJk982;
        owVar.Oby7UOJk982();
        owVar.kLF8MllXouM();
    }

    public void setProgress(float f) {
        ow owVar = this.Oby7UOJk982;
        owVar.kheiy7RMk6s.H8bE8XWjtoS(f);
        vw vwVar = owVar.aBUhIZ95pth;
        if (vwVar != null) {
            vwVar.H8bE8XWjtoS(f);
        }
        vw vwVar2 = owVar.WGVIMf7e7f9;
        if (vwVar2 != null) {
            vwVar2.H8bE8XWjtoS(f);
        }
    }

    @Override // defpackage.f6
    public void setRadius(float f) {
        super.setRadius(f);
        ow owVar = this.Oby7UOJk982;
        owVar.brBhnf7Rph0 = f;
        owVar.Ndt5adT1n2F(owVar.miDHqavGimy.aBUhIZ95pth().HgCgyIrsRhc(f));
        owVar.ykVrBoeh7sI.invalidateSelf();
        if (owVar.iQvCvXTWXYz() || (owVar.HgCgyIrsRhc.getPreventCornerOverlap() && !owVar.kheiy7RMk6s.ocrRjEg1xWE())) {
            owVar.kLF8MllXouM();
        }
        if (owVar.iQvCvXTWXYz()) {
            owVar.Oby7UOJk982();
        }
    }

    public void setRippleColor(ColorStateList colorStateList) {
        ow owVar = this.Oby7UOJk982;
        owVar.kLF8MllXouM = colorStateList;
        RippleDrawable rippleDrawable = owVar.uCRx9YCOc24;
        if (rippleDrawable != null) {
            rippleDrawable.setColor(colorStateList);
        }
    }

    public void setRippleColorResource(int i) throws Resources.NotFoundException {
        ColorStateList colorStateListN7QsYWNZtSU = mn0.n7QsYWNZtSU(getContext(), i);
        ow owVar = this.Oby7UOJk982;
        owVar.kLF8MllXouM = colorStateListN7QsYWNZtSU;
        RippleDrawable rippleDrawable = owVar.uCRx9YCOc24;
        if (rippleDrawable != null) {
            rippleDrawable.setColor(colorStateListN7QsYWNZtSU);
        }
    }

    @Override // defpackage.mc0
    public void setShapeAppearanceModel(cc0 cc0Var) {
        setClipToOutline(cc0Var.iQvCvXTWXYz(getBoundsAsRectF()));
        this.Oby7UOJk982.Ndt5adT1n2F(cc0Var);
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        ow owVar = this.Oby7UOJk982;
        if (owVar.H8bE8XWjtoS != colorStateList) {
            owVar.H8bE8XWjtoS = colorStateList;
            vw vwVar = owVar.aBUhIZ95pth;
            vwVar.Ndt5adT1n2F.ykVrBoeh7sI = owVar.iQvCvXTWXYz;
            vwVar.invalidateSelf();
            tw twVar = vwVar.Ndt5adT1n2F;
            if (twVar.aBUhIZ95pth != colorStateList) {
                twVar.aBUhIZ95pth = colorStateList;
                vwVar.onStateChange(vwVar.getState());
            }
        }
        invalidate();
    }

    public void setStrokeWidth(int i) {
        ow owVar = this.Oby7UOJk982;
        if (i != owVar.iQvCvXTWXYz) {
            owVar.iQvCvXTWXYz = i;
            vw vwVar = owVar.aBUhIZ95pth;
            ColorStateList colorStateList = owVar.H8bE8XWjtoS;
            vwVar.Ndt5adT1n2F.ykVrBoeh7sI = i;
            vwVar.invalidateSelf();
            tw twVar = vwVar.Ndt5adT1n2F;
            if (twVar.aBUhIZ95pth != colorStateList) {
                twVar.aBUhIZ95pth = colorStateList;
                vwVar.onStateChange(vwVar.getState());
            }
        }
        invalidate();
    }

    @Override // defpackage.f6
    public void setUseCompatPadding(boolean z) {
        super.setUseCompatPadding(z);
        ow owVar = this.Oby7UOJk982;
        owVar.Oby7UOJk982();
        owVar.kLF8MllXouM();
    }

    @Override // android.widget.Checkable
    public final void toggle() {
        ow owVar = this.Oby7UOJk982;
        if (owVar != null && owVar.n7QsYWNZtSU && isEnabled()) {
            this.H8bE8XWjtoS = !this.H8bE8XWjtoS;
            refreshDrawableState();
            nDGTvOUPAhx();
            owVar.MarFYthBr4b(this.H8bE8XWjtoS, true);
        }
    }

    @Override // defpackage.f6
    public void setCardBackgroundColor(ColorStateList colorStateList) {
        this.Oby7UOJk982.kheiy7RMk6s.miDHqavGimy(colorStateList);
    }

    public void setStrokeColor(int i) {
        setStrokeColor(ColorStateList.valueOf(i));
    }

    public void setOnCheckedChangeListener(mw mwVar) {
    }

    public MaterialCardView(Context context) {
        this(context, null);
    }
}
