package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import defpackage.s40;
import defpackage.zd;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class FloatingActionButton$BaseBehavior<T> extends zd {
    public FloatingActionButton$BaseBehavior(Context context, AttributeSet attributeSet) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s40.MarFYthBr4b);
        typedArrayObtainStyledAttributes.getBoolean(0, true);
        typedArrayObtainStyledAttributes.recycle();
    }

    public FloatingActionButton$BaseBehavior() {
    }
}
