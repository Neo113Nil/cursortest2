package com.google.android.material.behavior;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import defpackage.zd;
import java.util.LinkedHashSet;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
@Deprecated
/* loaded from: classes.dex */
public class HideBottomViewOnScrollBehavior<V extends View> extends zd {
    public HideBottomViewOnScrollBehavior() {
        new LinkedHashSet();
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
        new LinkedHashSet();
    }
}
