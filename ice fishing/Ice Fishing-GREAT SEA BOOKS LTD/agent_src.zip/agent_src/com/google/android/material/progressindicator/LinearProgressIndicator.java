package com.google.android.material.progressindicator;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Pair;
import defpackage.bu;
import defpackage.h1;
import defpackage.iu;
import defpackage.n4;
import defpackage.of;
import defpackage.pi;
import defpackage.rr;
import defpackage.yt;
import defpackage.z4;
import defpackage.zt;
import java.util.Objects;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class LinearProgressIndicator extends z4 {
    public LinearProgressIndicator(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        iu iuVar = this.wJXRvW1l9At;
        yt ytVar = new yt(iuVar);
        ytVar.MarFYthBr4b = 300.0f;
        ytVar.H8bE8XWjtoS = new Pair(new pi(), new pi());
        Context context2 = getContext();
        h1 ztVar = iuVar.Zrl8J6Z2Dje == 0 ? new zt(iuVar) : new bu(context2, iuVar);
        rr rrVar = new rr(context2, iuVar);
        rrVar.n7QsYWNZtSU = ytVar;
        rrVar.g0egR5i1XsF = ztVar;
        ztVar.HgCgyIrsRhc = rrVar;
        setIndeterminateDrawable(rrVar);
        setProgressDrawable(new of(getContext(), iuVar, ytVar));
        this.H8bE8XWjtoS = true;
    }

    @Override // defpackage.z4
    public final void HgCgyIrsRhc(int i) {
        iu iuVar = this.wJXRvW1l9At;
        if (iuVar != null && iuVar.Zrl8J6Z2Dje == 0 && isIndeterminate()) {
            return;
        }
        super.HgCgyIrsRhc(i);
    }

    public int getIndeterminateAnimationType() {
        return this.wJXRvW1l9At.Zrl8J6Z2Dje;
    }

    public int getIndicatorDirection() {
        return this.wJXRvW1l9At.WGVIMf7e7f9;
    }

    public int getTrackInnerCornerRadius() {
        return this.wJXRvW1l9At.z7hVgGhB3r5;
    }

    public Integer getTrackStopIndicatorPadding() {
        return this.wJXRvW1l9At.g0egR5i1XsF;
    }

    public int getTrackStopIndicatorSize() {
        return this.wJXRvW1l9At.n7QsYWNZtSU;
    }

    @Override // defpackage.z4, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        iu iuVar = this.wJXRvW1l9At;
        boolean z2 = true;
        if (iuVar.WGVIMf7e7f9 != 1 && ((getLayoutDirection() != 1 || iuVar.WGVIMf7e7f9 != 2) && (getLayoutDirection() != 0 || iuVar.WGVIMf7e7f9 != 3))) {
            z2 = false;
        }
        iuVar.lJCHxZXkFBB = z2;
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        int paddingRight = i - (getPaddingRight() + getPaddingLeft());
        int paddingBottom = i2 - (getPaddingBottom() + getPaddingTop());
        rr indeterminateDrawable = getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setBounds(0, 0, paddingRight, paddingBottom);
        }
        of progressDrawable = getProgressDrawable();
        if (progressDrawable != null) {
            progressDrawable.setBounds(0, 0, paddingRight, paddingBottom);
        }
    }

    public void setIndeterminateAnimationType(int i) {
        iu iuVar = this.wJXRvW1l9At;
        if (iuVar.Zrl8J6Z2Dje == i) {
            return;
        }
        if (nDGTvOUPAhx() && isIndeterminate()) {
            n4.C48z5w8gjNK("Cannot change indeterminate animation type while the progress indicator is show in indeterminate mode.");
            return;
        }
        iuVar.Zrl8J6Z2Dje = i;
        iuVar.aBUhIZ95pth();
        if (i == 0) {
            rr indeterminateDrawable = getIndeterminateDrawable();
            zt ztVar = new zt(iuVar);
            indeterminateDrawable.g0egR5i1XsF = ztVar;
            ztVar.HgCgyIrsRhc = indeterminateDrawable;
        } else {
            rr indeterminateDrawable2 = getIndeterminateDrawable();
            bu buVar = new bu(getContext(), iuVar);
            indeterminateDrawable2.g0egR5i1XsF = buVar;
            buVar.HgCgyIrsRhc = indeterminateDrawable2;
        }
        if (getProgressDrawable() != null && getIndeterminateDrawable() != null) {
            getIndeterminateDrawable().g0egR5i1XsF.kLF8MllXouM(this.lJCHxZXkFBB);
        }
        invalidate();
    }

    @Override // defpackage.z4
    public void setIndicatorColor(int... iArr) {
        super.setIndicatorColor(iArr);
        this.wJXRvW1l9At.aBUhIZ95pth();
    }

    public void setIndicatorDirection(int i) {
        iu iuVar = this.wJXRvW1l9At;
        iuVar.WGVIMf7e7f9 = i;
        boolean z = true;
        if (i != 1 && ((getLayoutDirection() != 1 || iuVar.WGVIMf7e7f9 != 2) && (getLayoutDirection() != 0 || i != 3))) {
            z = false;
        }
        iuVar.lJCHxZXkFBB = z;
        invalidate();
    }

    @Override // defpackage.z4
    public void setTrackCornerRadius(int i) {
        super.setTrackCornerRadius(i);
        this.wJXRvW1l9At.aBUhIZ95pth();
        invalidate();
    }

    public void setTrackInnerCornerRadius(int i) {
        iu iuVar = this.wJXRvW1l9At;
        if (iuVar.z7hVgGhB3r5 != i) {
            iuVar.z7hVgGhB3r5 = Math.round(Math.min(i, iuVar.HgCgyIrsRhc / 2.0f));
            iuVar.P56qh5C3eoK = false;
            iuVar.fVTKpwokKnY = true;
            iuVar.aBUhIZ95pth();
            invalidate();
        }
    }

    public void setTrackInnerCornerRadiusFraction(float f) {
        iu iuVar = this.wJXRvW1l9At;
        if (iuVar.C48z5w8gjNK != f) {
            iuVar.C48z5w8gjNK = Math.min(f, 0.5f);
            iuVar.P56qh5C3eoK = true;
            iuVar.fVTKpwokKnY = true;
            iuVar.aBUhIZ95pth();
            invalidate();
        }
    }

    public void setTrackStopIndicatorPadding(Integer num) {
        iu iuVar = this.wJXRvW1l9At;
        if (Objects.equals(iuVar.g0egR5i1XsF, num)) {
            return;
        }
        iuVar.g0egR5i1XsF = num;
        invalidate();
    }

    public void setTrackStopIndicatorSize(int i) {
        iu iuVar = this.wJXRvW1l9At;
        if (iuVar.n7QsYWNZtSU != i) {
            iuVar.n7QsYWNZtSU = i;
            iuVar.aBUhIZ95pth();
            invalidate();
        }
    }

    public LinearProgressIndicator(Context context) {
        this(context, null);
    }
}
