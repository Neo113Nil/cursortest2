package com.google.android.material.carousel;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import com.kolosta.rejin.kiltor.R;
import defpackage.bd0;
import defpackage.f60;
import defpackage.g60;
import defpackage.h6;
import defpackage.i6;
import defpackage.j6;
import defpackage.l60;
import defpackage.n4;
import defpackage.p60;
import defpackage.s40;
import defpackage.zi;
import java.util.ArrayList;
import java.util.Collections;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class CarouselLayoutManager extends f60 {
    public final zi H8bE8XWjtoS;
    public final View.OnLayoutChangeListener Zrl8J6Z2Dje;
    public j6 uCRx9YCOc24;

    public CarouselLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        Paint paint = new Paint();
        Collections.unmodifiableList(new ArrayList());
        paint.setStrokeWidth(5.0f);
        paint.setColor(-65281);
        this.Zrl8J6Z2Dje = new View.OnLayoutChangeListener() { // from class: g6
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
                if (i5 - i3 == i9 - i7 && i6 - i4 == i10 - i8) {
                    return;
                }
                view.post(new SO78vOEPH7q(2, this.HgCgyIrsRhc));
            }
        };
        this.H8bE8XWjtoS = new zi();
        pDfwYwzMf5H();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s40.aBUhIZ95pth);
            typedArrayObtainStyledAttributes.getInt(0, 0);
            pDfwYwzMf5H();
            a(typedArrayObtainStyledAttributes.getInt(0, 0));
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // defpackage.f60
    public final void EIfOZATD9S5(p60 p60Var) {
        if (g0egR5i1XsF() == 0) {
            return;
        }
        f60.rAQLLnQzyBa(n7QsYWNZtSU(0));
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0047  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0058  */
    @Override // defpackage.f60
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View IYi9Twa3Yjg(View view, int i, l60 l60Var, p60 p60Var) {
        char c;
        if (g0egR5i1XsF() != 0) {
            int i2 = this.uCRx9YCOc24.HgCgyIrsRhc;
            if (i == 1) {
                c = 65535;
                if (c != 0) {
                    if (c == 65535) {
                        if (f60.rAQLLnQzyBa(view) != 0) {
                            int iRAQLLnQzyBa = f60.rAQLLnQzyBa(n7QsYWNZtSU(0)) - 1;
                            if (iRAQLLnQzyBa < 0 || iRAQLLnQzyBa >= I538XrPZXnv()) {
                                return n7QsYWNZtSU(ZB6EwfQgURM() ? g0egR5i1XsF() - 1 : 0);
                            }
                            this.uCRx9YCOc24.HgCgyIrsRhc();
                            throw null;
                        }
                    } else if (f60.rAQLLnQzyBa(view) != I538XrPZXnv() - 1) {
                        int iRAQLLnQzyBa2 = f60.rAQLLnQzyBa(n7QsYWNZtSU(g0egR5i1XsF() - 1)) + 1;
                        if (iRAQLLnQzyBa2 < 0 || iRAQLLnQzyBa2 >= I538XrPZXnv()) {
                            return n7QsYWNZtSU(ZB6EwfQgURM() ? 0 : g0egR5i1XsF() - 1);
                        }
                        this.uCRx9YCOc24.HgCgyIrsRhc();
                        throw null;
                    }
                }
            } else if (i == 2) {
                c = 1;
                if (c != 0) {
                }
            } else {
                if (i == 17) {
                    if (i2 == 0) {
                        if (ZB6EwfQgURM()) {
                        }
                    }
                    c = 0;
                } else if (i != 33) {
                    if (i != 66) {
                        if (i != 130) {
                            Log.d("CarouselLayoutManager", "Unknown focus request:" + i);
                        } else if (i2 == 1) {
                        }
                        c = 0;
                    } else {
                        if (i2 == 0) {
                            if (ZB6EwfQgURM()) {
                            }
                        }
                        c = 0;
                    }
                } else if (i2 != 1) {
                    c = 0;
                }
                if (c != 0) {
                }
            }
        }
        return null;
    }

    @Override // defpackage.f60
    public final int Oby7UOJk982(p60 p60Var) {
        return 0;
    }

    @Override // defpackage.f60
    public final void P56qh5C3eoK(View view, Rect rect) {
        super.P56qh5C3eoK(view, rect);
        rect.centerY();
        if (lhOeDqVB8Ye()) {
            rect.centerX();
        }
        throw null;
    }

    @Override // defpackage.f60
    public final void RM9erU4r8X4(l60 l60Var, p60 p60Var) {
        if (p60Var.nDGTvOUPAhx() > 0) {
            if ((lhOeDqVB8Ye() ? this.Oby7UOJk982 : this.miDHqavGimy) > 0.0f) {
                ZB6EwfQgURM();
                l60Var.aBUhIZ95pth(0);
                n4.C48z5w8gjNK("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
                return;
            }
        }
        Aj3vze09p9a(l60Var);
    }

    @Override // defpackage.f60
    public final void X0MyC8YR7bY(RecyclerView recyclerView) {
        recyclerView.removeOnLayoutChangeListener(this.Zrl8J6Z2Dje);
    }

    @Override // defpackage.f60
    public final int Ypoyc6CSuwk(int i, l60 l60Var, p60 p60Var) {
        if (!lhOeDqVB8Ye() || g0egR5i1XsF() == 0 || i == 0) {
            return 0;
        }
        l60Var.aBUhIZ95pth(0);
        n4.C48z5w8gjNK("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
        return 0;
    }

    public final boolean ZB6EwfQgURM() {
        return lhOeDqVB8Ye() && mYvwaIfm0QL() == 1;
    }

    @Override // defpackage.f60
    public final g60 Zrl8J6Z2Dje() {
        return new g60(-2, -2);
    }

    public final void a(int i) {
        j6 i6Var;
        if (i != 0 && i != 1) {
            n4.Ndt5adT1n2F(bd0.brBhnf7Rph0(i, "invalid orientation:"));
            return;
        }
        nDGTvOUPAhx(null);
        j6 j6Var = this.uCRx9YCOc24;
        if (j6Var == null || i != j6Var.HgCgyIrsRhc) {
            if (i == 0) {
                i6Var = new i6(this);
            } else {
                if (i != 1) {
                    n4.Ndt5adT1n2F("invalid orientation");
                    return;
                }
                i6Var = new h6(1);
            }
            this.uCRx9YCOc24 = i6Var;
            pDfwYwzMf5H();
        }
    }

    @Override // defpackage.f60
    public final boolean aBUhIZ95pth() {
        return !lhOeDqVB8Ye();
    }

    @Override // defpackage.f60
    public final boolean cVDN2FegiBA(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
        return false;
    }

    @Override // defpackage.f60
    public final void eXVzbg621Zg() {
        I538XrPZXnv();
    }

    @Override // defpackage.f60
    public final void gfMrr7pMNlA(RecyclerView recyclerView) throws Resources.NotFoundException {
        Context context = recyclerView.getContext();
        zi ziVar = this.H8bE8XWjtoS;
        float dimension = ziVar.HgCgyIrsRhc;
        if (dimension <= 0.0f) {
            dimension = context.getResources().getDimension(R.dimen.m3_carousel_small_item_size_min);
        }
        ziVar.HgCgyIrsRhc = dimension;
        float dimension2 = ziVar.nDGTvOUPAhx;
        if (dimension2 <= 0.0f) {
            dimension2 = context.getResources().getDimension(R.dimen.m3_carousel_small_item_size_max);
        }
        ziVar.nDGTvOUPAhx = dimension2;
        pDfwYwzMf5H();
        recyclerView.addOnLayoutChangeListener(this.Zrl8J6Z2Dje);
    }

    @Override // defpackage.f60
    public final int iQvCvXTWXYz(p60 p60Var) {
        g0egR5i1XsF();
        return 0;
    }

    @Override // defpackage.f60
    public final int kLF8MllXouM(p60 p60Var) {
        g0egR5i1XsF();
        return 0;
    }

    @Override // defpackage.f60
    public final boolean kMJtaEXWLpZ() {
        return true;
    }

    @Override // defpackage.f60
    public final boolean kheiy7RMk6s() {
        return lhOeDqVB8Ye();
    }

    public final boolean lhOeDqVB8Ye() {
        return this.uCRx9YCOc24.HgCgyIrsRhc == 0;
    }

    @Override // defpackage.f60
    public final int miDHqavGimy(p60 p60Var) {
        return 0;
    }

    @Override // defpackage.f60
    public final void oMjM3NKsTUI(int i, int i2) {
        I538XrPZXnv();
    }

    @Override // defpackage.f60
    public final void oQsxzW6q98D(int i, int i2) {
        I538XrPZXnv();
    }

    @Override // defpackage.f60
    public final int ocrRjEg1xWE(p60 p60Var) {
        return 0;
    }

    @Override // defpackage.f60
    public final int tzA8uRWBsm9(int i, l60 l60Var, p60 p60Var) {
        if (!aBUhIZ95pth() || g0egR5i1XsF() == 0 || i == 0) {
            return 0;
        }
        l60Var.aBUhIZ95pth(0);
        n4.C48z5w8gjNK("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
        return 0;
    }

    @Override // defpackage.f60
    public final void uHy5z3aH4qy(AccessibilityEvent accessibilityEvent) {
        super.uHy5z3aH4qy(accessibilityEvent);
        if (g0egR5i1XsF() > 0) {
            accessibilityEvent.setFromIndex(f60.rAQLLnQzyBa(n7QsYWNZtSU(0)));
            accessibilityEvent.setToIndex(f60.rAQLLnQzyBa(n7QsYWNZtSU(g0egR5i1XsF() - 1)));
        }
    }

    @Override // defpackage.f60
    public final int ykVrBoeh7sI(p60 p60Var) {
        return 0;
    }

    public CarouselLayoutManager() {
        zi ziVar = new zi();
        Paint paint = new Paint();
        Collections.unmodifiableList(new ArrayList());
        paint.setStrokeWidth(5.0f);
        paint.setColor(-65281);
        this.Zrl8J6Z2Dje = new View.OnLayoutChangeListener() { // from class: g6
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
                if (i5 - i3 == i9 - i7 && i6 - i4 == i10 - i8) {
                    return;
                }
                view.post(new SO78vOEPH7q(2, this.HgCgyIrsRhc));
            }
        };
        this.H8bE8XWjtoS = ziVar;
        pDfwYwzMf5H();
        a(0);
    }
}
