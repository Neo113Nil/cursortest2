package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import defpackage.zd;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
@Deprecated
/* loaded from: classes.dex */
public abstract class ExpandableBehavior extends zd {
    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
    }
}
