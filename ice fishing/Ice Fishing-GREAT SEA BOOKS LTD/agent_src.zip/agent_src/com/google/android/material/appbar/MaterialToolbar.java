package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import com.kolosta.rejin.kiltor.R;
import defpackage.cc0;
import defpackage.cd;
import defpackage.es;
import defpackage.s40;
import defpackage.vi0;
import defpackage.vw;
import defpackage.zd;
import java.util.ArrayList;
import java.util.Collections;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class MaterialToolbar extends Toolbar {
    public static final ImageView.ScaleType[] EIfOZATD9S5 = {ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE};
    public ImageView.ScaleType A1nEDgk5yL3;
    public boolean BnMjCWDbFSU;
    public Boolean RM9erU4r8X4;
    public Integer eXVzbg621Zg;
    public boolean oMjM3NKsTUI;

    public MaterialToolbar(Context context, AttributeSet attributeSet) {
        super(vi0.wBZqWeQU8tl(context, attributeSet, R.attr.toolbarStyle, R.style.Widget_MaterialComponents_Toolbar), attributeSet, 0);
        Context context2 = getContext();
        TypedArray typedArrayD57UaHJBpF2 = es.D57UaHJBpF2(context2, attributeSet, s40.lJCHxZXkFBB, R.attr.toolbarStyle, R.style.Widget_MaterialComponents_Toolbar, new int[0]);
        if (typedArrayD57UaHJBpF2.hasValue(2)) {
            setNavigationIconTint(typedArrayD57UaHJBpF2.getColor(2, -1));
        }
        this.BnMjCWDbFSU = typedArrayD57UaHJBpF2.getBoolean(6, false);
        this.oMjM3NKsTUI = typedArrayD57UaHJBpF2.getBoolean(5, false);
        int i = typedArrayD57UaHJBpF2.getInt(1, -1);
        if (i >= 0) {
            ImageView.ScaleType[] scaleTypeArr = EIfOZATD9S5;
            if (i < scaleTypeArr.length) {
                this.A1nEDgk5yL3 = scaleTypeArr[i];
            }
        }
        if (typedArrayD57UaHJBpF2.hasValue(0)) {
            this.RM9erU4r8X4 = Boolean.valueOf(typedArrayD57UaHJBpF2.getBoolean(0, false));
        }
        typedArrayD57UaHJBpF2.recycle();
        cc0 cc0VarHgCgyIrsRhc = cc0.MarFYthBr4b(context2, attributeSet, R.attr.toolbarStyle, R.style.Widget_MaterialComponents_Toolbar).HgCgyIrsRhc();
        Drawable background = getBackground();
        ColorStateList colorStateListValueOf = background == null ? ColorStateList.valueOf(0) : vi0.Zrl8J6Z2Dje(background);
        if (colorStateListValueOf != null) {
            vw vwVar = new vw(cc0VarHgCgyIrsRhc);
            vwVar.miDHqavGimy(colorStateListValueOf);
            vwVar.ykVrBoeh7sI(context2);
            vwVar.Oby7UOJk982(getElevation());
            setBackground(vwVar);
        }
    }

    public final void g0egR5i1XsF(TextView textView, Pair pair) {
        int measuredWidth = getMeasuredWidth();
        int measuredWidth2 = textView.getMeasuredWidth();
        int i = (measuredWidth / 2) - (measuredWidth2 / 2);
        int i2 = measuredWidth2 + i;
        int iMax = Math.max(Math.max(((Integer) pair.first).intValue() - i, 0), Math.max(i2 - ((Integer) pair.second).intValue(), 0));
        if (iMax > 0) {
            i += iMax;
            i2 -= iMax;
            textView.measure(View.MeasureSpec.makeMeasureSpec(i2 - i, 1073741824), textView.getMeasuredHeightAndState());
        }
        textView.layout(i, textView.getTop(), i2, textView.getBottom());
    }

    public ImageView.ScaleType getLogoScaleType() {
        return this.A1nEDgk5yL3;
    }

    public Integer getNavigationIconTint() {
        return this.eXVzbg621Zg;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof vw) {
            zd.ZNZD85DkjoE(this, (vw) background);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        ImageView imageView;
        Drawable drawable;
        super.onLayout(z, i, i2, i3, i4);
        cd cdVar = vi0.ykVrBoeh7sI;
        int i5 = 0;
        ImageView imageView2 = null;
        if (this.BnMjCWDbFSU || this.oMjM3NKsTUI) {
            ArrayList arrayListC48z5w8gjNK = vi0.C48z5w8gjNK(this, getTitle());
            TextView textView = arrayListC48z5w8gjNK.isEmpty() ? null : (TextView) Collections.min(arrayListC48z5w8gjNK, cdVar);
            ArrayList arrayListC48z5w8gjNK2 = vi0.C48z5w8gjNK(this, getSubtitle());
            TextView textView2 = arrayListC48z5w8gjNK2.isEmpty() ? null : (TextView) Collections.max(arrayListC48z5w8gjNK2, cdVar);
            if (textView != null || textView2 != null) {
                int measuredWidth = getMeasuredWidth();
                int i6 = measuredWidth / 2;
                int paddingLeft = getPaddingLeft();
                int paddingRight = measuredWidth - getPaddingRight();
                for (int i7 = 0; i7 < getChildCount(); i7++) {
                    View childAt = getChildAt(i7);
                    if (childAt.getVisibility() != 8 && childAt != textView && childAt != textView2) {
                        if (childAt.getRight() < i6 && childAt.getRight() > paddingLeft) {
                            paddingLeft = childAt.getRight();
                        }
                        if (childAt.getLeft() > i6 && childAt.getLeft() < paddingRight) {
                            paddingRight = childAt.getLeft();
                        }
                    }
                }
                Pair pair = new Pair(Integer.valueOf(paddingLeft), Integer.valueOf(paddingRight));
                if (this.BnMjCWDbFSU && textView != null) {
                    g0egR5i1XsF(textView, pair);
                }
                if (this.oMjM3NKsTUI && textView2 != null) {
                    g0egR5i1XsF(textView2, pair);
                }
            }
        }
        Drawable logo = getLogo();
        if (logo != null) {
            while (true) {
                if (i5 >= getChildCount()) {
                    break;
                }
                View childAt2 = getChildAt(i5);
                if ((childAt2 instanceof ImageView) && (drawable = (imageView = (ImageView) childAt2).getDrawable()) != null && drawable.getConstantState() != null && drawable.getConstantState().equals(logo.getConstantState())) {
                    imageView2 = imageView;
                    break;
                }
                i5++;
            }
        }
        if (imageView2 != null) {
            Boolean bool = this.RM9erU4r8X4;
            if (bool != null) {
                imageView2.setAdjustViewBounds(bool.booleanValue());
            }
            ImageView.ScaleType scaleType = this.A1nEDgk5yL3;
            if (scaleType != null) {
                imageView2.setScaleType(scaleType);
            }
        }
    }

    @Override // android.view.View
    public void setElevation(float f) {
        super.setElevation(f);
        Drawable background = getBackground();
        if (background instanceof vw) {
            ((vw) background).Oby7UOJk982(f);
        }
    }

    public void setLogoAdjustViewBounds(boolean z) {
        Boolean bool = this.RM9erU4r8X4;
        if (bool == null || bool.booleanValue() != z) {
            this.RM9erU4r8X4 = Boolean.valueOf(z);
            requestLayout();
        }
    }

    public void setLogoScaleType(ImageView.ScaleType scaleType) {
        if (this.A1nEDgk5yL3 != scaleType) {
            this.A1nEDgk5yL3 = scaleType;
            requestLayout();
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null && this.eXVzbg621Zg != null) {
            drawable = drawable.mutate();
            drawable.setTint(this.eXVzbg621Zg.intValue());
        }
        super.setNavigationIcon(drawable);
    }

    public void setNavigationIconTint(int i) {
        this.eXVzbg621Zg = Integer.valueOf(i);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }

    public void setSubtitleCentered(boolean z) {
        if (this.oMjM3NKsTUI != z) {
            this.oMjM3NKsTUI = z;
            requestLayout();
        }
    }

    public void setTitleCentered(boolean z) {
        if (this.BnMjCWDbFSU != z) {
            this.BnMjCWDbFSU = z;
            requestLayout();
        }
    }

    public MaterialToolbar(Context context) {
        this(context, null);
    }
}
