package com.google.android.material.internal.Dos.dcdexzocikkxkkdzknxzzhi;

/* loaded from: classes.dex */
public final class pwpawqrlvmbvuamvmmlwswvmpupbu {
    public static final int GADBSDHEUI = 58602918;
    public static final int UPJKMNOEOW = -288704173;
}
