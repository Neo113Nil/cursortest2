package com.google.android.material.sidesheet;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import com.kolosta.rejin.kiltor.R;
import defpackage.cc0;
import defpackage.ew;
import defpackage.m4;
import defpackage.mn0;
import defpackage.s40;
import defpackage.vw;
import defpackage.zc0;
import defpackage.zd;
import java.util.LinkedHashSet;

/* compiled from: r8-map-id-9dc1412978b0cf2269450236326e8d52f144bde2d278afbc08e3857cf0f84802 */
/* loaded from: classes.dex */
public class SideSheetBehavior<V extends View> extends zd implements ew {
    public final cc0 IVXw3Dlz2AG;
    public final ColorStateList JyMrFevGyEE;
    public int ZNZD85DkjoE;
    public final vw mYvwaIfm0QL;

    public SideSheetBehavior(Context context, AttributeSet attributeSet) {
        new zc0(this);
        this.ZNZD85DkjoE = 5;
        new LinkedHashSet();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s40.P56qh5C3eoK);
        if (typedArrayObtainStyledAttributes.hasValue(3)) {
            this.JyMrFevGyEE = mn0.z7hVgGhB3r5(context, typedArrayObtainStyledAttributes, 3);
        }
        if (typedArrayObtainStyledAttributes.hasValue(6)) {
            this.IVXw3Dlz2AG = cc0.MarFYthBr4b(context, attributeSet, 0, R.style.Widget_Material3_SideSheet).HgCgyIrsRhc();
        }
        if (typedArrayObtainStyledAttributes.hasValue(5)) {
            typedArrayObtainStyledAttributes.getResourceId(5, -1);
        }
        cc0 cc0Var = this.IVXw3Dlz2AG;
        if (cc0Var != null) {
            vw vwVar = new vw(cc0Var);
            this.mYvwaIfm0QL = vwVar;
            vwVar.ykVrBoeh7sI(context);
            ColorStateList colorStateList = this.JyMrFevGyEE;
            if (colorStateList != null) {
                this.mYvwaIfm0QL.miDHqavGimy(colorStateList);
            } else {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(android.R.attr.colorBackground, typedValue, true);
                this.mYvwaIfm0QL.setTint(typedValue.data);
            }
        }
        typedArrayObtainStyledAttributes.getDimension(2, -1.0f);
        typedArrayObtainStyledAttributes.getBoolean(4, true);
        typedArrayObtainStyledAttributes.recycle();
        ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    @Override // defpackage.ew
    public final void kheiy7RMk6s(m4 m4Var) {
    }

    @Override // defpackage.ew
    public final void nDGTvOUPAhx(m4 m4Var) {
    }

    @Override // defpackage.ew
    public final void HgCgyIrsRhc() {
    }

    @Override // defpackage.ew
    public final void aBUhIZ95pth() {
    }

    public SideSheetBehavior() {
        new zc0(this);
        this.ZNZD85DkjoE = 5;
        new LinkedHashSet();
    }
}
