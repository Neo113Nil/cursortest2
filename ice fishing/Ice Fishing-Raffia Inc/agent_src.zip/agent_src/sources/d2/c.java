package d2;

import P.C0035x;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class c implements Iterator, Y1.a {

    /* renamed from: c, reason: collision with root package name */
    public final Iterator f2923c;
    public Object e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ f f2925f;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f2922b = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f2924d = -1;

    public c(d dVar) {
        this.f2925f = dVar;
        this.f2923c = new C0035x((d) dVar.f2927b);
    }

    public void a() {
        Object next;
        do {
            Iterator it = this.f2923c;
            if (!it.hasNext()) {
                this.f2924d = 0;
                return;
            }
            next = it.next();
        } while (((Boolean) ((j) ((d) this.f2925f).f2928c).h(next)).booleanValue());
        this.e = next;
        this.f2924d = 1;
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [W1.l, X1.j] */
    public void b() {
        Iterator it = this.f2923c;
        if (it.hasNext()) {
            Object next = it.next();
            if (((Boolean) ((X1.j) ((d) this.f2925f).f2928c).h(next)).booleanValue()) {
                this.f2924d = 1;
                this.e = next;
                return;
            }
        }
        this.f2924d = 0;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f2922b) {
            case 0:
                if (this.f2924d == -1) {
                    a();
                }
                if (this.f2924d == 1) {
                }
                break;
            default:
                if (this.f2924d == -1) {
                    b();
                }
                if (this.f2924d == 1) {
                }
                break;
        }
        return true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.f2922b) {
            case 0:
                if (this.f2924d == -1) {
                    a();
                }
                if (this.f2924d == 0) {
                    throw new NoSuchElementException();
                }
                Object obj = this.e;
                this.e = null;
                this.f2924d = -1;
                return obj;
            default:
                if (this.f2924d == -1) {
                    b();
                }
                if (this.f2924d == 0) {
                    throw new NoSuchElementException();
                }
                Object obj2 = this.e;
                this.e = null;
                this.f2924d = -1;
                return obj2;
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.f2922b) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public c(d dVar, byte b3) {
        this.f2925f = dVar;
        this.f2923c = ((f) dVar.f2927b).iterator();
    }
}
