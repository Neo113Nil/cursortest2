package d2;

import J1.k;
import W1.l;
import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.R;
import j0.C0200e;
import java.util.ArrayList;
import k1.AbstractC0239g;
import q0.AbstractC0398A;
import q0.C0404a;
import y0.InterfaceC0531a;
import y0.InterfaceC0533c;

/* loaded from: classes.dex */
public final /* synthetic */ class j implements l {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f2935b;

    public /* synthetic */ j(int i) {
        this.f2935b = i;
    }

    @Override // W1.l
    public final Object h(Object obj) throws Exception {
        InterfaceC0533c interfaceC0533cA;
        switch (this.f2935b) {
            case 0:
                return Boolean.valueOf(obj == null);
            case 1:
                InterfaceC0531a interfaceC0531a = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a, "_connection");
                interfaceC0533cA = interfaceC0531a.A("SELECT * FROM rider WHERE id = 1");
                try {
                    return interfaceC0533cA.t() ? new m1.d((int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "id")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "spotScore")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "bestRun")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "checksRun")), interfaceC0533cA.q(AbstractC0239g.o(interfaceC0533cA, "riderTag"))) : null;
                } finally {
                }
            case 2:
                InterfaceC0531a interfaceC0531a2 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a2, "_connection");
                interfaceC0533cA = interfaceC0531a2.A("DELETE FROM bagged");
                try {
                    interfaceC0533cA.t();
                    interfaceC0533cA.close();
                    return k.f632a;
                } finally {
                }
            case 3:
                InterfaceC0531a interfaceC0531a3 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a3, "_connection");
                interfaceC0533cA = interfaceC0531a3.A("SELECT * FROM opened_card ORDER BY lastOpenedAt DESC");
                try {
                    int iO = AbstractC0239g.o(interfaceC0533cA, "trickId");
                    int iO2 = AbstractC0239g.o(interfaceC0533cA, "lastOpenedAt");
                    ArrayList arrayList = new ArrayList();
                    while (interfaceC0533cA.t()) {
                        arrayList.add(new m1.c(interfaceC0533cA.q(iO), interfaceC0533cA.s(iO2)));
                    }
                    return arrayList;
                } finally {
                }
            case 4:
                InterfaceC0531a interfaceC0531a4 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a4, "_connection");
                interfaceC0533cA = interfaceC0531a4.A("DELETE FROM opened_card");
                try {
                    interfaceC0533cA.t();
                    interfaceC0533cA.close();
                    return k.f632a;
                } finally {
                }
            case 5:
                InterfaceC0531a interfaceC0531a5 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a5, "_connection");
                interfaceC0533cA = interfaceC0531a5.A("DELETE FROM landing_report");
                try {
                    interfaceC0533cA.t();
                    interfaceC0533cA.close();
                    return k.f632a;
                } finally {
                }
            case 6:
                InterfaceC0531a interfaceC0531a6 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a6, "_connection");
                interfaceC0533cA = interfaceC0531a6.A("DELETE FROM trail_event");
                try {
                    interfaceC0533cA.t();
                    interfaceC0533cA.close();
                    return k.f632a;
                } finally {
                }
            case 7:
                InterfaceC0531a interfaceC0531a7 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a7, "_connection");
                interfaceC0533cA = interfaceC0531a7.A("SELECT * FROM trail_event ORDER BY at DESC, id DESC");
                try {
                    int iO3 = AbstractC0239g.o(interfaceC0533cA, "id");
                    int iO4 = AbstractC0239g.o(interfaceC0533cA, "kind");
                    int iO5 = AbstractC0239g.o(interfaceC0533cA, "label");
                    int iO6 = AbstractC0239g.o(interfaceC0533cA, "right");
                    int iO7 = AbstractC0239g.o(interfaceC0533cA, "total");
                    int iO8 = AbstractC0239g.o(interfaceC0533cA, "at");
                    ArrayList arrayList2 = new ArrayList();
                    while (interfaceC0533cA.t()) {
                        arrayList2.add(new m1.e(interfaceC0533cA.s(iO3), interfaceC0533cA.q(iO4), interfaceC0533cA.q(iO5), (int) interfaceC0533cA.s(iO6), (int) interfaceC0533cA.s(iO7), interfaceC0533cA.s(iO8)));
                    }
                    return arrayList2;
                } finally {
                }
            case 8:
                InterfaceC0531a interfaceC0531a8 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a8, "_connection");
                interfaceC0533cA = interfaceC0531a8.A("SELECT * FROM rider WHERE id = 1");
                try {
                    return interfaceC0533cA.t() ? new m1.d((int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "id")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "spotScore")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "bestRun")), (int) interfaceC0533cA.s(AbstractC0239g.o(interfaceC0533cA, "checksRun")), interfaceC0533cA.q(AbstractC0239g.o(interfaceC0533cA, "riderTag"))) : null;
                } finally {
                }
            case 9:
                InterfaceC0531a interfaceC0531a9 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a9, "_connection");
                interfaceC0533cA = interfaceC0531a9.A("SELECT trickId FROM bagged");
                try {
                    ArrayList arrayList3 = new ArrayList();
                    while (interfaceC0533cA.t()) {
                        arrayList3.add(interfaceC0533cA.q(0));
                    }
                    return arrayList3;
                } finally {
                }
            case 10:
                InterfaceC0531a interfaceC0531a10 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a10, "_connection");
                interfaceC0533cA = interfaceC0531a10.A("SELECT COUNT(*) FROM landing_report");
                try {
                    int iS = interfaceC0533cA.t() ? (int) interfaceC0533cA.s(0) : 0;
                    interfaceC0533cA.close();
                    return Integer.valueOf(iS);
                } finally {
                }
            case 11:
                InterfaceC0531a interfaceC0531a11 = (InterfaceC0531a) obj;
                X1.i.e(interfaceC0531a11, "_connection");
                interfaceC0533cA = interfaceC0531a11.A("DELETE FROM rider");
                try {
                    interfaceC0533cA.t();
                    interfaceC0533cA.close();
                    return k.f632a;
                } finally {
                }
            case 12:
                X1.i.e((C0404a) obj, "config");
                throw new J1.d();
            case 13:
                InterfaceC0533c interfaceC0533c = (InterfaceC0533c) obj;
                X1.i.e(interfaceC0533c, "it");
                return Boolean.valueOf(interfaceC0533c.t());
            case 14:
                InterfaceC0533c interfaceC0533c2 = (InterfaceC0533c) obj;
                X1.i.e(interfaceC0533c2, "statement");
                L1.k kVar = new L1.k();
                while (interfaceC0533c2.t()) {
                    kVar.add(Integer.valueOf((int) interfaceC0533c2.s(0)));
                }
                return AbstractC0046a.d(kVar);
            default:
                C0200e c0200e = (C0200e) obj;
                X1.i.e(c0200e, "$this$anim");
                c0200e.f3690a = R.anim.nav_enter;
                c0200e.f3691b = R.anim.nav_exit;
                c0200e.f3692c = R.anim.nav_pop_enter;
                c0200e.f3693d = R.anim.nav_pop_exit;
                return k.f632a;
        }
    }

    public /* synthetic */ j(AbstractC0398A abstractC0398A) {
        this.f2935b = 12;
    }
}
