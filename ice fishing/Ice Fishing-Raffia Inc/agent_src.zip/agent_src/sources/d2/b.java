package d2;

import K1.t;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class b implements f {

    /* renamed from: a, reason: collision with root package name */
    public static final b f2921a = new b();

    @Override // d2.f
    public final Iterator iterator() {
        return t.f681b;
    }
}
