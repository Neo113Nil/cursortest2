package d2;

import J1.k;
import a.AbstractC0046a;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class g implements Iterator, N1.d, Y1.a {

    /* renamed from: b, reason: collision with root package name */
    public int f2932b;

    /* renamed from: c, reason: collision with root package name */
    public Object f2933c;

    /* renamed from: d, reason: collision with root package name */
    public Iterator f2934d;
    public N1.d e;

    public final RuntimeException a() {
        int i = this.f2932b;
        if (i == 4) {
            return new NoSuchElementException();
        }
        if (i == 5) {
            return new IllegalStateException("Iterator has failed.");
        }
        return new IllegalStateException("Unexpected state of the iterator: " + this.f2932b);
    }

    @Override // N1.d
    public final void c(Object obj) throws Throwable {
        AbstractC0046a.N(obj);
        this.f2932b = 4;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        while (true) {
            int i = this.f2932b;
            if (i != 0) {
                if (i != 1) {
                    if (i == 2 || i == 3) {
                        return true;
                    }
                    if (i == 4) {
                        return false;
                    }
                    throw a();
                }
                Iterator it = this.f2934d;
                X1.i.b(it);
                if (it.hasNext()) {
                    this.f2932b = 2;
                    return true;
                }
                this.f2934d = null;
            }
            this.f2932b = 5;
            N1.d dVar = this.e;
            X1.i.b(dVar);
            this.e = null;
            dVar.c(k.f632a);
        }
    }

    @Override // N1.d
    public final N1.i k() {
        return N1.j.f809b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i = this.f2932b;
        if (i == 0 || i == 1) {
            if (hasNext()) {
                return next();
            }
            throw new NoSuchElementException();
        }
        if (i == 2) {
            this.f2932b = 1;
            Iterator it = this.f2934d;
            X1.i.b(it);
            return it.next();
        }
        if (i != 3) {
            throw a();
        }
        this.f2932b = 0;
        Object obj = this.f2933c;
        this.f2933c = null;
        return obj;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
