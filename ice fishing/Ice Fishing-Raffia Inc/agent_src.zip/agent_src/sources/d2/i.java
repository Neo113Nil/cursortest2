package d2;

/* loaded from: classes.dex */
public abstract class i extends b1.e {
}
