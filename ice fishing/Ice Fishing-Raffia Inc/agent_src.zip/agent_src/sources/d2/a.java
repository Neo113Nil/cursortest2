package d2;

import K1.s;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class a implements f {

    /* renamed from: a, reason: collision with root package name */
    public final AtomicReference f2920a;

    public a(s sVar) {
        this.f2920a = new AtomicReference(sVar);
    }

    @Override // d2.f
    public final Iterator iterator() {
        f fVar = (f) this.f2920a.getAndSet(null);
        if (fVar != null) {
            return fVar.iterator();
        }
        throw new IllegalStateException("This sequence can be consumed only once.");
    }
}
