package d2;

import K1.s;
import K1.u;
import W1.l;
import a.AbstractC0046a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public abstract class h extends i {
    public static f s0(Iterator it) {
        X1.i.e(it, "<this>");
        return new a(new s(1, it));
    }

    public static f t0(Object obj, l lVar) {
        return obj == null ? b.f2921a : new d(new A0.e(3, obj), lVar);
    }

    public static List u0(f fVar) {
        Iterator it = fVar.iterator();
        if (!it.hasNext()) {
            return u.f682b;
        }
        Object next = it.next();
        if (!it.hasNext()) {
            return AbstractC0046a.H(next);
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(next);
        while (it.hasNext()) {
            arrayList.add(it.next());
        }
        return arrayList;
    }
}
