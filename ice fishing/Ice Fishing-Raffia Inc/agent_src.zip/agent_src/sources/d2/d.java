package d2;

import P.C0035x;
import W1.l;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class d implements f {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f2926a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f2927b;

    /* renamed from: c, reason: collision with root package name */
    public final J1.a f2928c;

    public /* synthetic */ d(f fVar, l lVar, int i) {
        this.f2926a = i;
        this.f2927b = fVar;
        this.f2928c = lVar;
    }

    @Override // d2.f
    public final Iterator iterator() {
        switch (this.f2926a) {
            case 0:
                return new c(this);
            case 1:
                return new e(this);
            case 2:
                return new c(this, (byte) 0);
            default:
                return new C0035x(this);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public d(f fVar, l lVar) {
        this.f2926a = 2;
        this.f2927b = fVar;
        this.f2928c = (X1.j) lVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public d(A0.e eVar, l lVar) {
        this.f2926a = 1;
        this.f2927b = eVar;
        this.f2928c = (X1.j) lVar;
    }
}
