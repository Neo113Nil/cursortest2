package d2;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class e implements Iterator, Y1.a {

    /* renamed from: b, reason: collision with root package name */
    public Object f2929b;

    /* renamed from: c, reason: collision with root package name */
    public int f2930c = -2;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ d f2931d;

    public e(d dVar) {
        this.f2931d = dVar;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [W1.l, X1.j] */
    public final void a() {
        Object objH;
        int i = this.f2930c;
        d dVar = this.f2931d;
        if (i == -2) {
            objH = ((A0.e) dVar.f2927b).f221c;
        } else {
            ?? r02 = (X1.j) dVar.f2928c;
            Object obj = this.f2929b;
            X1.i.b(obj);
            objH = r02.h(obj);
        }
        this.f2929b = objH;
        this.f2930c = objH == null ? 0 : 1;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f2930c < 0) {
            a();
        }
        return this.f2930c == 1;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f2930c < 0) {
            a();
        }
        if (this.f2930c == 0) {
            throw new NoSuchElementException();
        }
        Object obj = this.f2929b;
        X1.i.c(obj, "null cannot be cast to non-null type T of kotlin.sequences.GeneratorSequence");
        this.f2930c = -1;
        return obj;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
