package Q1;

import java.util.List;

/* loaded from: classes.dex */
public interface a extends List, Y1.a {
}
