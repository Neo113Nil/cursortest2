package Q1;

import K1.e;
import X1.i;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class b extends e implements a, Serializable {

    /* renamed from: b, reason: collision with root package name */
    public final Enum[] f1011b;

    public b(Enum[] enumArr) {
        this.f1011b = enumArr;
    }

    @Override // K1.e
    public final int a() {
        return this.f1011b.length;
    }

    @Override // K1.e, java.util.List, java.util.Collection
    public final boolean contains(Object obj) {
        if (!(obj instanceof Enum)) {
            return false;
        }
        Enum r5 = (Enum) obj;
        i.e(r5, "element");
        int iOrdinal = r5.ordinal();
        Enum[] enumArr = this.f1011b;
        i.e(enumArr, "<this>");
        return ((iOrdinal < 0 || iOrdinal >= enumArr.length) ? null : enumArr[iOrdinal]) == r5;
    }

    @Override // java.util.List
    public final Object get(int i) {
        Enum[] enumArr = this.f1011b;
        int length = enumArr.length;
        if (i < 0 || i >= length) {
            throw new IndexOutOfBoundsException(H.e.e(i, length, "index: ", ", size: "));
        }
        return enumArr[i];
    }

    @Override // K1.e, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Enum)) {
            return -1;
        }
        Enum r5 = (Enum) obj;
        i.e(r5, "element");
        int iOrdinal = r5.ordinal();
        Enum[] enumArr = this.f1011b;
        i.e(enumArr, "<this>");
        if (((iOrdinal < 0 || iOrdinal >= enumArr.length) ? null : enumArr[iOrdinal]) == r5) {
            return iOrdinal;
        }
        return -1;
    }

    @Override // K1.e, java.util.List
    public final int lastIndexOf(Object obj) {
        if (!(obj instanceof Enum)) {
            return -1;
        }
        Enum r2 = (Enum) obj;
        i.e(r2, "element");
        return indexOf(r2);
    }
}
