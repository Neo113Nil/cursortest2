package U;

import C.h;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public abstract class b implements Parcelable {

    /* renamed from: b, reason: collision with root package name */
    public final Parcelable f1144b;

    /* renamed from: c, reason: collision with root package name */
    public static final a f1143c = new a();
    public static final Parcelable.Creator<b> CREATOR = new h(3);

    public b() {
        this.f1144b = null;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f1144b, i);
    }

    public b(Parcelable parcelable) {
        if (parcelable != null) {
            this.f1144b = parcelable == f1143c ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public b(Parcel parcel, ClassLoader classLoader) {
        Parcelable parcelable = parcel.readParcelable(classLoader);
        this.f1144b = parcelable == null ? f1143c : parcelable;
    }
}
