package H;

import G.k;
import M.n;
import a.AbstractC0046a;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import p0.s0;
import s.C0439j;

/* loaded from: classes.dex */
public abstract class g {

    /* renamed from: a, reason: collision with root package name */
    public static final AbstractC0046a f558a;

    /* renamed from: b, reason: collision with root package name */
    public static final s0 f559b;

    static {
        AbstractC0046a.b("TypefaceCompat static init");
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            f558a = new j();
        } else if (i >= 28) {
            f558a = new i();
        } else {
            f558a = new h();
        }
        f559b = new s0(16);
        Trace.endSection();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0047  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Typeface a(Context context, G.e eVar, Resources resources, int i, String str, int i3, int i4, G.b bVar, boolean z2) throws InterruptedException {
        Typeface typefaceO;
        Typeface typefaceCreate;
        List listUnmodifiableList;
        int i5 = 4;
        int i6 = 1;
        boolean z3 = false;
        Object[] objArr = 0;
        Object[] objArr2 = 0;
        int i7 = -3;
        if (eVar instanceof G.h) {
            G.h hVar = (G.h) eVar;
            String str2 = hVar.e;
            if (str2 == null || str2.isEmpty()) {
                typefaceCreate = null;
                if (typefaceCreate == null) {
                    if (bVar != null) {
                        new Handler(Looper.getMainLooper()).post(new k(bVar, 0, typefaceCreate));
                    }
                    return typefaceCreate;
                }
                Object[] objArr3 = !z2 ? bVar != null : hVar.f515d != 0;
                int i8 = z2 ? hVar.f514c : -1;
                Handler handler = new Handler(Looper.getMainLooper());
                A0.f fVar = new A0.f(3, z3);
                fVar.f224c = bVar;
                M.e eVar2 = hVar.f513b;
                if (eVar2 != null) {
                    Object[] objArr4 = {hVar.f512a, eVar2};
                    ArrayList arrayList = new ArrayList(2);
                    for (int i9 = 0; i9 < 2; i9++) {
                        Object obj = objArr4[i9];
                        Objects.requireNonNull(obj);
                        arrayList.add(obj);
                    }
                    listUnmodifiableList = Collections.unmodifiableList(arrayList);
                } else {
                    Object[] objArr5 = {hVar.f512a};
                    ArrayList arrayList2 = new ArrayList(1);
                    Object obj2 = objArr5[0];
                    Objects.requireNonNull(obj2);
                    arrayList2.add(obj2);
                    listUnmodifiableList = Collections.unmodifiableList(arrayList2);
                }
                List list = listUnmodifiableList;
                n nVar = new n(handler);
                A.i iVar = new A.i(fVar, i5, nVar);
                if (objArr3 != true) {
                    String strA = M.i.a(list, i4);
                    Typeface typeface = (Typeface) M.i.f754a.f(strA);
                    if (typeface != null) {
                        nVar.execute(new E.b(fVar, i5, typeface));
                        typefaceO = typeface;
                    } else {
                        M.g gVar = new M.g(objArr == true ? 1 : 0, iVar);
                        synchronized (M.i.f756c) {
                            try {
                                C0439j c0439j = M.i.f757d;
                                ArrayList arrayList3 = (ArrayList) c0439j.get(strA);
                                if (arrayList3 != null) {
                                    arrayList3.add(gVar);
                                } else {
                                    ArrayList arrayList4 = new ArrayList();
                                    arrayList4.add(gVar);
                                    c0439j.put(strA, arrayList4);
                                    M.f fVar2 = new M.f(strA, context, list, i4, 1);
                                    ThreadPoolExecutor threadPoolExecutor = M.i.f755b;
                                    M.g gVar2 = new M.g(i6, strA);
                                    Handler handler2 = Looper.myLooper() == null ? new Handler(Looper.getMainLooper()) : new Handler();
                                    K0.d dVar = new K0.d();
                                    dVar.f645c = fVar2;
                                    dVar.f646d = gVar2;
                                    dVar.e = handler2;
                                    threadPoolExecutor.execute(dVar);
                                }
                            } finally {
                            }
                        }
                        typefaceO = null;
                    }
                } else {
                    if (list.size() > 1) {
                        throw new IllegalArgumentException("Fallbacks with blocking fetches are not supported for performance reasons");
                    }
                    M.e eVar3 = (M.e) list.get(0);
                    s0 s0Var = M.i.f754a;
                    ArrayList arrayList5 = new ArrayList(1);
                    Object obj3 = new Object[]{eVar3}[0];
                    Objects.requireNonNull(obj3);
                    arrayList5.add(obj3);
                    String strA2 = M.i.a(Collections.unmodifiableList(arrayList5), i4);
                    Typeface typeface2 = (Typeface) M.i.f754a.f(strA2);
                    if (typeface2 != null) {
                        nVar.execute(new E.b(fVar, i5, typeface2));
                        typefaceO = typeface2;
                    } else if (i8 == -1) {
                        ArrayList arrayList6 = new ArrayList(1);
                        Object obj4 = new Object[]{eVar3}[0];
                        Objects.requireNonNull(obj4);
                        arrayList6.add(obj4);
                        M.h hVarB = M.i.b(strA2, context, Collections.unmodifiableList(arrayList6), i4);
                        iVar.I(hVarB);
                        typefaceO = hVarB.f752a;
                    } else {
                        try {
                            try {
                                M.h hVar2 = (M.h) M.i.f755b.submit(new M.f(strA2, context, eVar3, i4, 0)).get(i8, TimeUnit.MILLISECONDS);
                                iVar.I(hVar2);
                                typefaceO = hVar2.f752a;
                            } catch (InterruptedException e) {
                                throw e;
                            } catch (ExecutionException e3) {
                                throw new RuntimeException(e3);
                            } catch (TimeoutException unused) {
                                throw new InterruptedException("timeout");
                            }
                        } catch (InterruptedException unused2) {
                            ((n) iVar.f95d).execute(new M.a(i7, (int) (objArr2 == true ? 1 : 0), iVar.f94c));
                        }
                    }
                }
            } else {
                typefaceCreate = Typeface.create(str2, 0);
                Typeface typefaceCreate2 = Typeface.create(Typeface.DEFAULT, 0);
                if (typefaceCreate == null || typefaceCreate.equals(typefaceCreate2)) {
                }
                if (typefaceCreate == null) {
                }
            }
        } else {
            typefaceO = f558a.o(context, (G.f) eVar, resources, i4);
            if (bVar != null) {
                if (typefaceO != null) {
                    new Handler(Looper.getMainLooper()).post(new k(bVar, 0, typefaceO));
                } else {
                    bVar.a(-3);
                }
            }
        }
        if (typefaceO != null) {
            f559b.j(b(resources, i, str, i3, i4), typefaceO);
        }
        return typefaceO;
    }

    public static String b(Resources resources, int i, String str, int i3, int i4) {
        return resources.getResourcePackageName(i) + '-' + str + '-' + i3 + '-' + i + '-' + i4;
    }
}
