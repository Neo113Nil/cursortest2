package H;

import android.graphics.Color;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final ThreadLocal f550a = new ThreadLocal();

    public static int a(double d3, double d4, double d5) {
        double d6 = (((-0.4986d) * d5) + (((-1.5372d) * d4) + (3.2406d * d3))) / 100.0d;
        double d7 = ((0.0415d * d5) + ((1.8758d * d4) + ((-0.9689d) * d3))) / 100.0d;
        double d8 = ((1.057d * d5) + (((-0.204d) * d4) + (0.0557d * d3))) / 100.0d;
        double dPow = d6 > 0.0031308d ? (Math.pow(d6, 0.4166666666666667d) * 1.055d) - 0.055d : d6 * 12.92d;
        double dPow2 = d7 > 0.0031308d ? (Math.pow(d7, 0.4166666666666667d) * 1.055d) - 0.055d : d7 * 12.92d;
        double dPow3 = d8 > 0.0031308d ? (Math.pow(d8, 0.4166666666666667d) * 1.055d) - 0.055d : d8 * 12.92d;
        int iRound = (int) Math.round(dPow * 255.0d);
        int iMin = iRound < 0 ? 0 : Math.min(iRound, 255);
        int iRound2 = (int) Math.round(dPow2 * 255.0d);
        int iMin2 = iRound2 < 0 ? 0 : Math.min(iRound2, 255);
        int iRound3 = (int) Math.round(dPow3 * 255.0d);
        return Color.rgb(iMin, iMin2, iRound3 >= 0 ? Math.min(iRound3, 255) : 0);
    }

    public static int b(int i, int i3, float f3) {
        float f4 = 1.0f - f3;
        return Color.argb((int) ((Color.alpha(i3) * f3) + (Color.alpha(i) * f4)), (int) ((Color.red(i3) * f3) + (Color.red(i) * f4)), (int) ((Color.green(i3) * f3) + (Color.green(i) * f4)), (int) ((Color.blue(i3) * f3) + (Color.blue(i) * f4)));
    }

    public static int c(int i, int i3) {
        int iAlpha = Color.alpha(i3);
        int iAlpha2 = Color.alpha(i);
        int i4 = 255 - (((255 - iAlpha2) * (255 - iAlpha)) / 255);
        return Color.argb(i4, d(Color.red(i), iAlpha2, Color.red(i3), iAlpha, i4), d(Color.green(i), iAlpha2, Color.green(i3), iAlpha, i4), d(Color.blue(i), iAlpha2, Color.blue(i3), iAlpha, i4));
    }

    public static int d(int i, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            return 0;
        }
        return (((255 - i3) * (i4 * i5)) + ((i * 255) * i3)) / (i6 * 255);
    }

    public static int e(int i, int i3) {
        if (i3 < 0 || i3 > 255) {
            throw new IllegalArgumentException("alpha must be between 0 and 255.");
        }
        return (i & 16777215) | (i3 << 24);
    }
}
