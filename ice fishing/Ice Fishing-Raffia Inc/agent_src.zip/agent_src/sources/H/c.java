package H;

import android.graphics.Insets;

/* loaded from: classes.dex */
public final class c {
    public static final c e = new c(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f551a;

    /* renamed from: b, reason: collision with root package name */
    public final int f552b;

    /* renamed from: c, reason: collision with root package name */
    public final int f553c;

    /* renamed from: d, reason: collision with root package name */
    public final int f554d;

    public c(int i, int i3, int i4, int i5) {
        this.f551a = i;
        this.f552b = i3;
        this.f553c = i4;
        this.f554d = i5;
    }

    public static c a(c cVar, c cVar2) {
        return b(Math.max(cVar.f551a, cVar2.f551a), Math.max(cVar.f552b, cVar2.f552b), Math.max(cVar.f553c, cVar2.f553c), Math.max(cVar.f554d, cVar2.f554d));
    }

    public static c b(int i, int i3, int i4, int i5) {
        return (i == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? e : new c(i, i3, i4, i5);
    }

    public static c c(Insets insets) {
        return b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public final Insets d() {
        return b.b(this.f551a, this.f552b, this.f553c, this.f554d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        c cVar = (c) obj;
        return this.f554d == cVar.f554d && this.f551a == cVar.f551a && this.f553c == cVar.f553c && this.f552b == cVar.f552b;
    }

    public final int hashCode() {
        return (((((this.f551a * 31) + this.f552b) * 31) + this.f553c) * 31) + this.f554d;
    }

    public final String toString() {
        return "Insets{left=" + this.f551a + ", top=" + this.f552b + ", right=" + this.f553c + ", bottom=" + this.f554d + '}';
    }
}
