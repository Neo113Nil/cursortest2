package H;

import a.AbstractC0046a;
import android.graphics.Path;
import android.util.Log;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public char f556a;

    /* renamed from: b, reason: collision with root package name */
    public final float[] f557b;

    public f(char c3, float[] fArr) {
        this.f556a = c3;
        this.f557b = fArr;
    }

    public static void a(Path path, float f3, float f4, float f5, float f6, float f7, float f8, float f9, boolean z2, boolean z3) {
        double d3;
        double d4;
        double radians = Math.toRadians(f9);
        double dCos = Math.cos(radians);
        double dSin = Math.sin(radians);
        double d5 = f3;
        double d6 = f4;
        double d7 = (d6 * dSin) + (d5 * dCos);
        double d8 = d5;
        double d9 = f7;
        double d10 = d7 / d9;
        double d11 = f8;
        double d12 = ((d6 * dCos) + ((-f3) * dSin)) / d11;
        double d13 = d6;
        double d14 = f6;
        double d15 = ((d14 * dSin) + (f5 * dCos)) / d9;
        double d16 = ((d14 * dCos) + ((-f5) * dSin)) / d11;
        double d17 = d10 - d15;
        double d18 = d12 - d16;
        double d19 = (d10 + d15) / 2.0d;
        double d20 = (d12 + d16) / 2.0d;
        double d21 = (d18 * d18) + (d17 * d17);
        if (d21 == 0.0d) {
            Log.w("PathParser", " Points are coincident");
            return;
        }
        double d22 = (1.0d / d21) - 0.25d;
        if (d22 < 0.0d) {
            Log.w("PathParser", "Points are too far apart " + d21);
            float fSqrt = (float) (Math.sqrt(d21) / 1.99999d);
            a(path, f3, f4, f5, f6, f7 * fSqrt, f8 * fSqrt, f9, z2, z3);
            return;
        }
        double dSqrt = Math.sqrt(d22);
        double d23 = d17 * dSqrt;
        double d24 = dSqrt * d18;
        if (z2 == z3) {
            d3 = d19 - d24;
            d4 = d20 + d23;
        } else {
            d3 = d19 + d24;
            d4 = d20 - d23;
        }
        double dAtan2 = Math.atan2(d12 - d4, d10 - d3);
        double dAtan22 = Math.atan2(d16 - d4, d15 - d3) - dAtan2;
        if (z3 != (dAtan22 >= 0.0d)) {
            dAtan22 = dAtan22 > 0.0d ? dAtan22 - 6.283185307179586d : dAtan22 + 6.283185307179586d;
        }
        double d25 = d3 * d9;
        double d26 = d4 * d11;
        double d27 = (d25 * dCos) - (d26 * dSin);
        double d28 = (d26 * dCos) + (d25 * dSin);
        int iCeil = (int) Math.ceil(Math.abs((dAtan22 * 4.0d) / 3.141592653589793d));
        double dCos2 = Math.cos(radians);
        double dSin2 = Math.sin(radians);
        double dCos3 = Math.cos(dAtan2);
        double dSin3 = Math.sin(dAtan2);
        double d29 = -d9;
        double d30 = d29 * dCos2;
        double d31 = d11 * dSin2;
        double d32 = (d30 * dSin3) - (d31 * dCos3);
        double d33 = d29 * dSin2;
        double d34 = d11 * dCos2;
        double d35 = (dCos3 * d34) + (dSin3 * d33);
        double d36 = d34;
        double d37 = dAtan22 / iCeil;
        int i = 0;
        while (i < iCeil) {
            double d38 = dAtan2 + d37;
            double dSin4 = Math.sin(d38);
            double dCos4 = Math.cos(d38);
            double d39 = d37;
            double d40 = (((d9 * dCos2) * dCos4) + d27) - (d31 * dSin4);
            double d41 = d36;
            double d42 = d27;
            double d43 = (d41 * dSin4) + (d9 * dSin2 * dCos4) + d28;
            double d44 = (d30 * dSin4) - (d31 * dCos4);
            double d45 = (dCos4 * d41) + (dSin4 * d33);
            double d46 = d38 - dAtan2;
            double dTan = Math.tan(d46 / 2.0d);
            double dSqrt2 = ((Math.sqrt(((dTan * 3.0d) * dTan) + 4.0d) - 1.0d) * Math.sin(d46)) / 3.0d;
            path.rLineTo(0.0f, 0.0f);
            path.cubicTo((float) ((d32 * dSqrt2) + d8), (float) ((d35 * dSqrt2) + d13), (float) (d40 - (dSqrt2 * d44)), (float) (d43 - (dSqrt2 * d45)), (float) d40, (float) d43);
            i++;
            dAtan2 = d38;
            d33 = d33;
            dCos2 = dCos2;
            iCeil = iCeil;
            d35 = d45;
            d9 = d9;
            d32 = d44;
            d8 = d40;
            d13 = d43;
            d27 = d42;
            d37 = d39;
            d36 = d41;
        }
    }

    public static void b(f[] fVarArr, Path path) {
        int i;
        int i3;
        char c3;
        int i4;
        int i5;
        f fVar;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        f[] fVarArr2 = fVarArr;
        int i6 = 6;
        float[] fArr = new float[6];
        int length = fVarArr2.length;
        int i7 = 0;
        char c4 = 'm';
        while (i7 < length) {
            f fVar2 = fVarArr2[i7];
            char c5 = fVar2.f556a;
            float f15 = fArr[0];
            float f16 = fArr[1];
            float f17 = fArr[2];
            float f18 = fArr[3];
            float f19 = fArr[4];
            float f20 = fArr[5];
            switch (c5) {
                case 'A':
                case 'a':
                    i = 7;
                    break;
                case 'C':
                case 'c':
                    i = i6;
                    break;
                case 'H':
                case 'V':
                case 'h':
                case 'v':
                    i = 1;
                    break;
                case 'Q':
                case 'S':
                case 'q':
                case 's':
                    i = 4;
                    break;
                case 'Z':
                case 'z':
                    path.close();
                    path.moveTo(f19, f20);
                    f15 = f19;
                    f17 = f15;
                    f16 = f20;
                    f18 = f16;
                default:
                    i = 2;
                    break;
            }
            float f21 = f19;
            float f22 = f20;
            float f23 = f15;
            float f24 = f16;
            int i8 = 0;
            while (true) {
                float[] fArr2 = fVar2.f557b;
                if (i8 < fArr2.length) {
                    if (c5 != 'A') {
                        if (c5 != 'C') {
                            if (c5 == 'H') {
                                i3 = i8;
                                c3 = c5;
                                i4 = i7;
                                i5 = length;
                                fVar = fVar2;
                                path.lineTo(fArr2[i3], f24);
                                f23 = fArr2[i3];
                            } else if (c5 == 'Q') {
                                i3 = i8;
                                c3 = c5;
                                i4 = i7;
                                i5 = length;
                                fVar = fVar2;
                                float f25 = fArr2[i3];
                                int i9 = i3 + 1;
                                float f26 = fArr2[i9];
                                int i10 = i3 + 2;
                                int i11 = i3 + 3;
                                path.quadTo(f25, f26, fArr2[i10], fArr2[i11]);
                                f3 = fArr2[i3];
                                f4 = fArr2[i9];
                                f23 = fArr2[i10];
                                f24 = fArr2[i11];
                            } else if (c5 == 'V') {
                                i3 = i8;
                                c3 = c5;
                                i4 = i7;
                                i5 = length;
                                fVar = fVar2;
                                path.lineTo(f23, fArr2[i3]);
                                f24 = fArr2[i3];
                            } else if (c5 != 'a') {
                                if (c5 != 'c') {
                                    if (c5 != 'h') {
                                        if (c5 == 'q') {
                                            i3 = i8;
                                            float f27 = f24;
                                            float f28 = f23;
                                            int i12 = i3 + 1;
                                            int i13 = i3 + 2;
                                            int i14 = i3 + 3;
                                            path.rQuadTo(fArr2[i3], fArr2[i12], fArr2[i13], fArr2[i14]);
                                            float f29 = f28 + fArr2[i3];
                                            float f30 = fArr2[i12] + f27;
                                            float f31 = f28 + fArr2[i13];
                                            f24 = f27 + fArr2[i14];
                                            f18 = f30;
                                            f17 = f29;
                                            c3 = c5;
                                            i4 = i7;
                                            i5 = length;
                                            f23 = f31;
                                        } else if (c5 == 'v') {
                                            i3 = i8;
                                            path.rLineTo(0.0f, fArr2[i3]);
                                            f24 += fArr2[i3];
                                        } else if (c5 == 'L') {
                                            i3 = i8;
                                            int i15 = i3 + 1;
                                            path.lineTo(fArr2[i3], fArr2[i15]);
                                            f23 = fArr2[i3];
                                            f24 = fArr2[i15];
                                        } else if (c5 == 'M') {
                                            i3 = i8;
                                            f23 = fArr2[i3];
                                            f24 = fArr2[i3 + 1];
                                            if (i3 > 0) {
                                                path.lineTo(f23, f24);
                                            } else {
                                                path.moveTo(f23, f24);
                                                f22 = f24;
                                                f21 = f23;
                                            }
                                        } else if (c5 == 'S') {
                                            i3 = i8;
                                            float f32 = f24;
                                            float f33 = f23;
                                            if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                                f9 = (f32 * 2.0f) - f18;
                                                f10 = (f33 * 2.0f) - f17;
                                            } else {
                                                f10 = f33;
                                                f9 = f32;
                                            }
                                            int i16 = i3 + 1;
                                            int i17 = i3 + 2;
                                            int i18 = i3 + 3;
                                            path.cubicTo(f10, f9, fArr2[i3], fArr2[i16], fArr2[i17], fArr2[i18]);
                                            float f34 = fArr2[i3];
                                            float f35 = fArr2[i16];
                                            f23 = fArr2[i17];
                                            f24 = fArr2[i18];
                                            f18 = f35;
                                            f17 = f34;
                                        } else if (c5 == 'T') {
                                            i3 = i8;
                                            float f36 = f24;
                                            float f37 = f23;
                                            if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                                f5 = (f37 * 2.0f) - f17;
                                                f6 = (f36 * 2.0f) - f18;
                                            } else {
                                                f5 = f37;
                                                f6 = f36;
                                            }
                                            int i19 = i3 + 1;
                                            path.quadTo(f5, f6, fArr2[i3], fArr2[i19]);
                                            f7 = fArr2[i3];
                                            f8 = fArr2[i19];
                                        } else if (c5 == 'l') {
                                            i3 = i8;
                                            int i20 = i3 + 1;
                                            path.rLineTo(fArr2[i3], fArr2[i20]);
                                            f23 += fArr2[i3];
                                            f24 += fArr2[i20];
                                        } else if (c5 == 'm') {
                                            i3 = i8;
                                            float f38 = fArr2[i3];
                                            f23 += f38;
                                            float f39 = fArr2[i3 + 1];
                                            f24 += f39;
                                            if (i3 > 0) {
                                                path.rLineTo(f38, f39);
                                            } else {
                                                path.rMoveTo(f38, f39);
                                                f22 = f24;
                                                f21 = f23;
                                            }
                                        } else if (c5 == 's') {
                                            if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                                float f40 = f23 - f17;
                                                f11 = f24 - f18;
                                                f12 = f40;
                                            } else {
                                                f11 = 0.0f;
                                                f12 = 0.0f;
                                            }
                                            int i21 = i8 + 1;
                                            int i22 = i8 + 2;
                                            int i23 = i8 + 3;
                                            i3 = i8;
                                            float f41 = f24;
                                            float f42 = f23;
                                            path.rCubicTo(f12, f11, fArr2[i8], fArr2[i21], fArr2[i22], fArr2[i23]);
                                            f5 = f42 + fArr2[i3];
                                            f6 = f41 + fArr2[i21];
                                            f7 = f42 + fArr2[i22];
                                            f8 = fArr2[i23] + f41;
                                        } else if (c5 != 't') {
                                            i3 = i8;
                                        } else {
                                            if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                                f13 = f23 - f17;
                                                f14 = f24 - f18;
                                            } else {
                                                f14 = 0.0f;
                                                f13 = 0.0f;
                                            }
                                            int i24 = i8 + 1;
                                            path.rQuadTo(f13, f14, fArr2[i8], fArr2[i24]);
                                            float f43 = f13 + f23;
                                            float f44 = f14 + f24;
                                            f23 += fArr2[i8];
                                            f24 += fArr2[i24];
                                            f18 = f44;
                                            i3 = i8;
                                            c3 = c5;
                                            i4 = i7;
                                            i5 = length;
                                            f17 = f43;
                                        }
                                        fVar = fVar2;
                                    } else {
                                        i3 = i8;
                                        path.rLineTo(fArr2[i3], 0.0f);
                                        f23 += fArr2[i3];
                                    }
                                    c3 = c5;
                                    i4 = i7;
                                    i5 = length;
                                    fVar = fVar2;
                                } else {
                                    i3 = i8;
                                    float f45 = f24;
                                    float f46 = f23;
                                    int i25 = i3 + 2;
                                    int i26 = i3 + 3;
                                    int i27 = i3 + 4;
                                    int i28 = i3 + 5;
                                    path.rCubicTo(fArr2[i3], fArr2[i3 + 1], fArr2[i25], fArr2[i26], fArr2[i27], fArr2[i28]);
                                    f5 = f46 + fArr2[i25];
                                    f6 = f45 + fArr2[i26];
                                    f7 = f46 + fArr2[i27];
                                    f8 = fArr2[i28] + f45;
                                }
                                f18 = f6;
                                f17 = f5;
                                c3 = c5;
                                i4 = i7;
                                i5 = length;
                                f23 = f7;
                                f24 = f8;
                                fVar = fVar2;
                            } else {
                                i3 = i8;
                                float f47 = f24;
                                float f48 = f23;
                                int i29 = i3 + 5;
                                int i30 = i3 + 6;
                                c3 = c5;
                                i5 = length;
                                fVar = fVar2;
                                i4 = i7;
                                a(path, f48, f47, fArr2[i29] + f48, fArr2[i30] + f47, fArr2[i3], fArr2[i3 + 1], fArr2[i3 + 2], fArr2[i3 + 3] != 0.0f, fArr2[i3 + 4] != 0.0f);
                                f23 = f48 + fArr2[i29];
                                f24 = f47 + fArr2[i30];
                            }
                            i8 = i3 + i;
                            fVar2 = fVar;
                            length = i5;
                            c4 = c3;
                            c5 = c4;
                            i7 = i4;
                        } else {
                            i3 = i8;
                            c3 = c5;
                            i4 = i7;
                            i5 = length;
                            fVar = fVar2;
                            int i31 = i3 + 2;
                            int i32 = i3 + 3;
                            int i33 = i3 + 4;
                            int i34 = i3 + 5;
                            path.cubicTo(fArr2[i3], fArr2[i3 + 1], fArr2[i31], fArr2[i32], fArr2[i33], fArr2[i34]);
                            f23 = fArr2[i33];
                            f24 = fArr2[i34];
                            f3 = fArr2[i31];
                            f4 = fArr2[i32];
                        }
                        f17 = f3;
                        f18 = f4;
                        i8 = i3 + i;
                        fVar2 = fVar;
                        length = i5;
                        c4 = c3;
                        c5 = c4;
                        i7 = i4;
                    } else {
                        i3 = i8;
                        c3 = c5;
                        i4 = i7;
                        i5 = length;
                        fVar = fVar2;
                        int i35 = i3 + 5;
                        int i36 = i3 + 6;
                        a(path, f23, f24, fArr2[i35], fArr2[i36], fArr2[i3], fArr2[i3 + 1], fArr2[i3 + 2], fArr2[i3 + 3] != 0.0f, fArr2[i3 + 4] != 0.0f);
                        f23 = fArr2[i35];
                        f24 = fArr2[i36];
                    }
                    f18 = f24;
                    f17 = f23;
                    i8 = i3 + i;
                    fVar2 = fVar;
                    length = i5;
                    c4 = c3;
                    c5 = c4;
                    i7 = i4;
                }
            }
            fArr[0] = f23;
            fArr[1] = f24;
            fArr[2] = f17;
            fArr[3] = f18;
            fArr[4] = f21;
            fArr[5] = f22;
            c4 = fVar2.f556a;
            i7++;
            fVarArr2 = fVarArr;
            length = length;
            i6 = 6;
        }
    }

    public f(f fVar) {
        this.f556a = fVar.f556a;
        float[] fArr = fVar.f557b;
        this.f557b = AbstractC0046a.k(fArr, fArr.length);
    }
}
