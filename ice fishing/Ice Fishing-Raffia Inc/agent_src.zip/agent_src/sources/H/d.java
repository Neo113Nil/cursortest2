package H;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f555a = 0;

    static {
        new ThreadLocal();
    }
}
