package H;

import android.graphics.Insets;
import android.os.Trace;

/* loaded from: classes.dex */
public abstract class b {
    public static boolean a() {
        return Trace.isEnabled();
    }

    public static Insets b(int i, int i3, int i4, int i5) {
        return Insets.of(i, i3, i4, i5);
    }
}
