package H;

import M.k;
import a.AbstractC0046a;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class h extends AbstractC0046a {

    /* renamed from: o, reason: collision with root package name */
    public static Class f560o = null;

    /* renamed from: p, reason: collision with root package name */
    public static Constructor f561p = null;

    /* renamed from: q, reason: collision with root package name */
    public static Method f562q = null;

    /* renamed from: r, reason: collision with root package name */
    public static Method f563r = null;

    /* renamed from: s, reason: collision with root package name */
    public static boolean f564s = false;

    /* renamed from: h, reason: collision with root package name */
    public final Class f565h;
    public final Constructor i;

    /* renamed from: j, reason: collision with root package name */
    public final Method f566j;

    /* renamed from: k, reason: collision with root package name */
    public final Method f567k;

    /* renamed from: l, reason: collision with root package name */
    public final Method f568l;

    /* renamed from: m, reason: collision with root package name */
    public final Method f569m;

    /* renamed from: n, reason: collision with root package name */
    public final Method f570n;

    public h() throws NoSuchMethodException, ClassNotFoundException, SecurityException {
        Method methodX;
        Constructor<?> constructor;
        Method methodW;
        Method method;
        Method method2;
        Method method3;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            methodW = W(cls2);
            Class cls3 = Integer.TYPE;
            method = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            methodX = X(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e.getClass().getName()), e);
            methodX = null;
            constructor = null;
            methodW = null;
            method = null;
            method2 = null;
            method3 = null;
        }
        this.f565h = cls;
        this.i = constructor;
        this.f566j = methodW;
        this.f567k = method;
        this.f568l = method2;
        this.f569m = method3;
        this.f570n = methodX;
    }

    public static boolean Q(Object obj, String str, int i, boolean z2) throws NoSuchMethodException, ClassNotFoundException, SecurityException {
        T();
        try {
            return ((Boolean) f562q.invoke(obj, str, Integer.valueOf(i), Boolean.valueOf(z2))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public static void T() throws NoSuchMethodException, ClassNotFoundException, SecurityException {
        Method method;
        Class<?> cls;
        Method method2;
        if (f564s) {
            return;
        }
        f564s = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e("TypefaceCompatApi21Impl", e.getClass().getName(), e);
            method = null;
            cls = null;
            method2 = null;
        }
        f561p = constructor;
        f560o = cls;
        f562q = method2;
        f563r = method;
    }

    public static Method W(Class cls) {
        Class cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls2, Boolean.TYPE, cls2, cls2, cls2, FontVariationAxis[].class);
    }

    public final void O(Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        try {
            this.f569m.invoke(obj, null);
        } catch (IllegalAccessException | InvocationTargetException unused) {
        }
    }

    public final boolean P(Context context, Object obj, String str, int i, int i3, int i4, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f566j.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i), Integer.valueOf(i3), Integer.valueOf(i4), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Typeface R(Object obj) throws ArrayIndexOutOfBoundsException, IllegalArgumentException, NegativeArraySizeException {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) this.f565h, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) this.f570n.invoke(null, objNewInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean S(Object obj) {
        try {
            return ((Boolean) this.f568l.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public final boolean U() {
        Method method = this.f566j;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return method != null;
    }

    public final Object V() {
        try {
            return this.i.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            return null;
        }
    }

    public Method X(Class cls) throws NoSuchMethodException, SecurityException {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    @Override // a.AbstractC0046a
    public final Typeface o(Context context, G.f fVar, Resources resources, int i) throws IllegalAccessException, NoSuchMethodException, InstantiationException, ClassNotFoundException, SecurityException, ArrayIndexOutOfBoundsException, IllegalArgumentException, InvocationTargetException, NegativeArraySizeException {
        if (U()) {
            Object objV = V();
            if (objV == null) {
                return null;
            }
            for (G.g gVar : fVar.f506a) {
                if (!P(context, objV, gVar.f507a, gVar.e, gVar.f508b, gVar.f509c ? 1 : 0, FontVariationAxis.fromFontVariationSettings(gVar.f510d))) {
                    O(objV);
                    return null;
                }
            }
            if (S(objV)) {
                return R(objV);
            }
            return null;
        }
        T();
        try {
            Object objNewInstance = f561p.newInstance(null);
            for (G.g gVar2 : fVar.f506a) {
                File fileB = AbstractC0046a.B(context);
                if (fileB == null) {
                    return null;
                }
                try {
                } catch (RuntimeException unused) {
                } catch (Throwable th) {
                    fileB.delete();
                    throw th;
                }
                if (!AbstractC0046a.l(fileB, resources, gVar2.f511f) || !Q(objNewInstance, fileB.getPath(), gVar2.f508b, gVar2.f509c)) {
                    fileB.delete();
                    return null;
                }
                fileB.delete();
            }
            T();
            try {
                Object objNewInstance2 = Array.newInstance((Class<?>) f560o, 1);
                Array.set(objNewInstance2, 0, objNewInstance);
                return (Typeface) f563r.invoke(null, objNewInstance2);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    @Override // a.AbstractC0046a
    public final Typeface p(Context context, k[] kVarArr, int i) throws IllegalAccessException, IOException, IllegalArgumentException, InvocationTargetException {
        Typeface typefaceR;
        boolean zBooleanValue;
        if (kVarArr.length < 1) {
            return null;
        }
        if (!U()) {
            k kVarV = v(kVarArr, i);
            try {
                ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(kVarV.f760a, "r", null);
                if (parcelFileDescriptorOpenFileDescriptor == null) {
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        parcelFileDescriptorOpenFileDescriptor.close();
                    }
                    return null;
                }
                try {
                    Typeface typefaceBuild = new Typeface.Builder(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor()).setWeight(kVarV.f762c).setItalic(kVarV.f763d).build();
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return typefaceBuild;
                } finally {
                }
            } catch (IOException unused) {
                return null;
            }
        }
        HashMap map = new HashMap();
        for (k kVar : kVarArr) {
            if (kVar.e == 0) {
                Uri uri = kVar.f760a;
                if (!map.containsKey(uri)) {
                    map.put(uri, AbstractC0046a.I(context, uri));
                }
            }
        }
        Map mapUnmodifiableMap = Collections.unmodifiableMap(map);
        Object objV = V();
        if (objV == null) {
            return null;
        }
        int length = kVarArr.length;
        int i3 = 0;
        boolean z2 = false;
        while (i3 < length) {
            k kVar2 = kVarArr[i3];
            ByteBuffer byteBuffer = (ByteBuffer) mapUnmodifiableMap.get(kVar2.f760a);
            if (byteBuffer != null) {
                try {
                    zBooleanValue = ((Boolean) this.f567k.invoke(objV, byteBuffer, Integer.valueOf(kVar2.f761b), null, Integer.valueOf(kVar2.f762c), Integer.valueOf(kVar2.f763d ? 1 : 0))).booleanValue();
                } catch (IllegalAccessException | InvocationTargetException unused2) {
                    zBooleanValue = false;
                }
                if (!zBooleanValue) {
                    O(objV);
                    return null;
                }
                z2 = true;
            }
            i3++;
            z2 = z2;
        }
        if (!z2) {
            O(objV);
            return null;
        }
        if (S(objV) && (typefaceR = R(objV)) != null) {
            return Typeface.create(typefaceR, i);
        }
        return null;
    }

    @Override // a.AbstractC0046a
    public final Typeface r(Context context, Resources resources, int i, String str, int i3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (!U()) {
            return super.r(context, resources, i, str, i3);
        }
        Object objV = V();
        if (objV == null) {
            return null;
        }
        if (!P(context, objV, str, 0, -1, -1, null)) {
            O(objV);
            return null;
        }
        if (S(objV)) {
            return R(objV);
        }
        return null;
    }
}
