package P1;

import X1.i;
import X1.o;
import X1.p;

/* loaded from: classes.dex */
public abstract class g extends c implements X1.g {
    public final int e;

    public g(int i, N1.d dVar) {
        super(dVar);
        this.e = i;
    }

    @Override // X1.g
    public final int g() {
        return this.e;
    }

    @Override // P1.a
    public final String toString() {
        if (this.f974b != null) {
            return super.toString();
        }
        o.f1365a.getClass();
        String strA = p.a(this);
        i.d(strA, "renderLambdaToString(...)");
        return strA;
    }
}
