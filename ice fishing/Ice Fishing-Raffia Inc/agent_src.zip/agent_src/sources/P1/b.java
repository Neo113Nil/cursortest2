package P1;

import N1.i;

/* loaded from: classes.dex */
public final class b implements N1.d {

    /* renamed from: b, reason: collision with root package name */
    public static final b f975b = new b();

    @Override // N1.d
    public final void c(Object obj) {
        throw new IllegalStateException("This continuation is already complete");
    }

    @Override // N1.d
    public final i k() {
        throw new IllegalStateException("This continuation is already complete");
    }

    public final String toString() {
        return "This continuation is already complete";
    }
}
