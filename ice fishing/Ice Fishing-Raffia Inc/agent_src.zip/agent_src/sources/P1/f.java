package P1;

import P.C0023k;

/* loaded from: classes.dex */
public abstract class f {

    /* renamed from: a, reason: collision with root package name */
    public static final C0023k f978a = new C0023k((Object) null, (Object) null, (Object) null, 1);

    /* renamed from: b, reason: collision with root package name */
    public static C0023k f979b;
}
