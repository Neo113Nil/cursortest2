package P1;

import N1.i;
import g2.C0143g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import l2.AbstractC0269a;
import l2.h;

/* loaded from: classes.dex */
public abstract class c extends a {

    /* renamed from: c, reason: collision with root package name */
    public final i f976c;

    /* renamed from: d, reason: collision with root package name */
    public transient N1.d f977d;

    public c(N1.d dVar, i iVar) {
        super(dVar);
        this.f976c = iVar;
    }

    @Override // N1.d
    public i k() {
        i iVar = this.f976c;
        X1.i.b(iVar);
        return iVar;
    }

    @Override // P1.a
    public void p() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        N1.d dVar = this.f977d;
        if (dVar != null && dVar != this) {
            N1.g gVarC = k().C(N1.e.f808b);
            X1.i.b(gVarC);
            h hVar = (h) dVar;
            do {
                atomicReferenceFieldUpdater = h.i;
            } while (atomicReferenceFieldUpdater.get(hVar) == AbstractC0269a.f4083d);
            Object obj = atomicReferenceFieldUpdater.get(hVar);
            C0143g c0143g = obj instanceof C0143g ? (C0143g) obj : null;
            if (c0143g != null) {
                c0143g.r();
            }
        }
        this.f977d = b.f975b;
    }

    public c(N1.d dVar) {
        this(dVar, dVar != null ? dVar.k() : null);
    }
}
