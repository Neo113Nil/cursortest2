package P1;

import P.C0023k;
import X1.i;
import a.AbstractC0046a;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public abstract class a implements N1.d, d, Serializable {

    /* renamed from: b, reason: collision with root package name */
    public final N1.d f974b;

    public a(N1.d dVar) {
        this.f974b = dVar;
    }

    @Override // N1.d
    public final void c(Object obj) {
        N1.d dVar = this;
        while (true) {
            a aVar = (a) dVar;
            N1.d dVar2 = aVar.f974b;
            i.b(dVar2);
            try {
                obj = aVar.o(obj);
                if (obj == O1.a.f839b) {
                    return;
                }
            } catch (Throwable th) {
                obj = AbstractC0046a.n(th);
            }
            aVar.p();
            if (!(dVar2 instanceof a)) {
                dVar2.c(obj);
                return;
            }
            dVar = dVar2;
        }
    }

    @Override // P1.d
    public d f() {
        N1.d dVar = this.f974b;
        if (dVar instanceof d) {
            return (d) dVar;
        }
        return null;
    }

    public N1.d m(N1.d dVar, Object obj) {
        throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
    }

    public StackTraceElement n() throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        int iIntValue;
        String strC;
        Method method;
        Object objInvoke;
        Method method2;
        Object objInvoke2;
        e eVar = (e) getClass().getAnnotation(e.class);
        String str = null;
        if (eVar == null) {
            return null;
        }
        int iV = eVar.v();
        if (iV > 1) {
            throw new IllegalStateException(("Debug metadata version mismatch. Expected: 1, got " + iV + ". Please update the Kotlin standard library.").toString());
        }
        try {
            Field declaredField = getClass().getDeclaredField("label");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(this);
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            iIntValue = (num != null ? num.intValue() : 0) - 1;
        } catch (Exception unused) {
            iIntValue = -1;
        }
        int i = iIntValue >= 0 ? eVar.l()[iIntValue] : -1;
        C0023k c0023k = f.f979b;
        C0023k c0023k2 = f.f978a;
        if (c0023k == null) {
            try {
                C0023k c0023k3 = new C0023k(Class.class.getDeclaredMethod("getModule", null), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", null), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", null), 1);
                f.f979b = c0023k3;
                c0023k = c0023k3;
            } catch (Exception unused2) {
                f.f979b = c0023k2;
                c0023k = c0023k2;
            }
        }
        if (c0023k != c0023k2 && (method = (Method) c0023k.f912b) != null && (objInvoke = method.invoke(getClass(), null)) != null && (method2 = (Method) c0023k.f913c) != null && (objInvoke2 = method2.invoke(objInvoke, null)) != null) {
            Method method3 = (Method) c0023k.f914d;
            Object objInvoke3 = method3 != null ? method3.invoke(objInvoke2, null) : null;
            if (objInvoke3 instanceof String) {
                str = (String) objInvoke3;
            }
        }
        if (str == null) {
            strC = eVar.c();
        } else {
            strC = str + '/' + eVar.c();
        }
        return new StackTraceElement(strC, eVar.m(), eVar.f(), i);
    }

    public abstract Object o(Object obj);

    public void p() {
    }

    public String toString() throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        StringBuilder sb = new StringBuilder("Continuation at ");
        Object objN = n();
        if (objN == null) {
            objN = getClass().getName();
        }
        sb.append(objN);
        return sb.toString();
    }
}
