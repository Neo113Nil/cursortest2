package c;

import b.k;
import java.util.concurrent.CopyOnWriteArraySet;

/* renamed from: c.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0084a {

    /* renamed from: a, reason: collision with root package name */
    public final CopyOnWriteArraySet f2071a = new CopyOnWriteArraySet();

    /* renamed from: b, reason: collision with root package name */
    public volatile k f2072b;
}
