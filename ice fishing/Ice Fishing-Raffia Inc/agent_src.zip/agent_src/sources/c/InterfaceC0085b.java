package c;

/* renamed from: c.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0085b {
    void a();
}
