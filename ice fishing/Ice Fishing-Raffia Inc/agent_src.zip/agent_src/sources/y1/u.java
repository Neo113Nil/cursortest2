package y1;

import java.util.List;

/* loaded from: classes.dex */
public final class u implements v {

    /* renamed from: a, reason: collision with root package name */
    public final r1.f f6050a;

    /* renamed from: b, reason: collision with root package name */
    public final List f6051b;

    public u(r1.f fVar, List list) {
        X1.i.e(fVar, "summary");
        this.f6050a = fVar;
        this.f6051b = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof u)) {
            return false;
        }
        u uVar = (u) obj;
        return X1.i.a(this.f6050a, uVar.f6050a) && X1.i.a(this.f6051b, uVar.f6051b);
    }

    public final int hashCode() {
        return this.f6051b.hashCode() + (this.f6050a.hashCode() * 31);
    }

    public final String toString() {
        return "Ready(summary=" + this.f6050a + ", patches=" + this.f6051b + ")";
    }
}
