package y1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestFragment;
import g2.AbstractC0160y;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class l extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f6041f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ RiderCrestFragment f6042g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l(RiderCrestFragment riderCrestFragment, N1.d dVar) {
        super(2, dVar);
        this.f6042g = riderCrestFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) throws Throwable {
        l lVar = (l) m((N1.d) obj2, (InterfaceC0158w) obj);
        J1.k kVar = J1.k.f632a;
        lVar.o(kVar);
        return kVar;
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        l lVar = new l(this.f6042g, dVar);
        lVar.f6041f = obj;
        return lVar;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        AbstractC0046a.N(obj);
        InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f6041f;
        RiderCrestFragment riderCrestFragment = this.f6042g;
        AbstractC0160y.l(interfaceC0158w, null, 0, new j(riderCrestFragment, null), 3);
        AbstractC0160y.l(interfaceC0158w, null, 0, new k(riderCrestFragment, null), 3);
        return J1.k.f632a;
    }
}
