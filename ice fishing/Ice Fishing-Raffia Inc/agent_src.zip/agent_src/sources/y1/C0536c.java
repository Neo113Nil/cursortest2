package y1;

import P.C0023k;
import android.widget.LinearLayout;
import p0.l0;

/* renamed from: y1.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0536c extends l0 {

    /* renamed from: u, reason: collision with root package name */
    public final C0023k f6027u;

    public C0536c(C0023k c0023k) {
        super((LinearLayout) c0023k.f912b);
        this.f6027u = c0023k;
    }
}
