package y1;

/* loaded from: classes.dex */
public final class p implements s {

    /* renamed from: a, reason: collision with root package name */
    public static final p f6046a = new p();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof p);
    }

    public final int hashCode() {
        return -1320963414;
    }

    public final String toString() {
        return "ConfirmWipe";
    }
}
