package y1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestFragment;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestViewModel;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class k extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f6039f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ RiderCrestFragment f6040g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(RiderCrestFragment riderCrestFragment, N1.d dVar) {
        super(2, dVar);
        this.f6040g = riderCrestFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((k) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new k(this.f6040g, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f6039f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            RiderCrestFragment riderCrestFragment = this.f6040g;
            RiderCrestViewModel riderCrestViewModelQ = riderCrestFragment.Q();
            i iVar = new i(riderCrestFragment, 1);
            this.f6039f = 1;
            if (riderCrestViewModelQ.e.c(iVar, this) == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
