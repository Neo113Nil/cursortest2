package y1;

/* loaded from: classes.dex */
public final class x extends P1.c {
    public /* synthetic */ Object e;

    /* renamed from: f, reason: collision with root package name */
    public int f6055f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ o1.g f6056g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x(o1.g gVar, N1.d dVar) {
        super(dVar);
        this.f6056g = gVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.e = obj;
        this.f6055f |= Integer.MIN_VALUE;
        return this.f6056g.b(null, this);
    }
}
