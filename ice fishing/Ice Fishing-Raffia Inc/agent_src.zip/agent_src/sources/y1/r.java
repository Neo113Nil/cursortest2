package y1;

/* loaded from: classes.dex */
public final class r implements s {

    /* renamed from: a, reason: collision with root package name */
    public final String f6048a;

    public r(String str) {
        this.f6048a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof r) && X1.i.a(this.f6048a, ((r) obj).f6048a);
    }

    public final int hashCode() {
        return this.f6048a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("Open(trickId="), this.f6048a, ")");
    }
}
