package y1;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f6028a;

    public e(String str) {
        this.f6028a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof e) && X1.i.a(this.f6028a, ((e) obj).f6028a);
    }

    public final int hashCode() {
        return this.f6028a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("GoCard(trickId="), this.f6028a, ")");
    }
}
