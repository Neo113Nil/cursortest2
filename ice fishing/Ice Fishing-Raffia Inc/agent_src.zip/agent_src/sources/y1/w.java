package y1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestViewModel;
import g2.AbstractC0160y;
import g2.C0143g;
import g2.InterfaceC0158w;
import h.ExecutorC0185n;
import java.util.concurrent.RejectedExecutionException;
import l1.C0267f;
import l1.C0268g;
import m.RunnableC0277d;
import q0.AbstractC0398A;
import q0.C0400C;
import q0.C0401D;
import v0.C0474c;

/* loaded from: classes.dex */
public final class w extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f6052f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ s f6053g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ RiderCrestViewModel f6054h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(s sVar, RiderCrestViewModel riderCrestViewModel, N1.d dVar) {
        super(2, dVar);
        this.f6053g = sVar;
        this.f6054h = riderCrestViewModel;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((w) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new w(this.f6053g, this.f6054h, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        Object objS;
        ExecutorC0185n executorC0185n;
        O1.a aVar = O1.a.f839b;
        int i = this.f6052f;
        J1.k kVar = J1.k.f632a;
        if (i == 0) {
            AbstractC0046a.N(obj);
            s sVar = this.f6053g;
            boolean z2 = sVar instanceof q;
            RiderCrestViewModel riderCrestViewModel = this.f6054h;
            if (z2) {
                t1.b bVar = riderCrestViewModel.f2873b;
                String str = ((q) sVar).f6047a;
                this.f6052f = 1;
                bVar.getClass();
                Object objB = bVar.f5530a.b(e2.h.E0(str).toString(), this);
                if (objB != aVar) {
                    objB = kVar;
                }
                if (objB == aVar) {
                    return aVar;
                }
            } else if (sVar.equals(p.f6046a)) {
                t1.b bVar2 = riderCrestViewModel.f2874c;
                this.f6052f = 2;
                C0268g c0268g = bVar2.f5530a.f4731a;
                C0267f c0267f = new C0267f(c0268g, null);
                AbstractC0398A abstractC0398A = c0268g.f4071a;
                if (abstractC0398A.g()) {
                    C0400C c0400c = new C0400C(new C0474c(null, c0267f, abstractC0398A), null);
                    N1.i iVar = this.f976c;
                    X1.i.b(iVar);
                    C0401D c0401d = (C0401D) iVar.C(C0401D.f5109d);
                    N1.f fVar = c0401d != null ? c0401d.f5110b : null;
                    if (fVar != null) {
                        objS = AbstractC0160y.s(fVar, c0400c, this);
                    } else {
                        X1.i.b(iVar);
                        C0143g c0143g = new C0143g(1, L1.d.M(this));
                        c0143g.v();
                        try {
                            executorC0185n = abstractC0398A.f5097d;
                        } catch (RejectedExecutionException e) {
                            c0143g.q(new IllegalStateException("Unable to acquire a thread to perform the database transaction.", e));
                        }
                        if (executorC0185n == null) {
                            X1.i.g("internalTransactionExecutor");
                            throw null;
                        }
                        executorC0185n.execute(new RunnableC0277d(iVar, c0143g, abstractC0398A, c0400c));
                        objS = c0143g.u();
                    }
                } else {
                    l2.e eVar = abstractC0398A.f5094a;
                    if (eVar == null) {
                        X1.i.g("coroutineScope");
                        throw null;
                    }
                    objS = AbstractC0160y.s(eVar.f4089b, new v0.f(null, c0267f, abstractC0398A), this);
                }
                if (objS != aVar) {
                    objS = kVar;
                }
                if (objS != aVar) {
                    objS = kVar;
                }
                if (objS != aVar) {
                    objS = kVar;
                }
                if (objS == aVar) {
                    return aVar;
                }
            } else {
                if (!(sVar instanceof r)) {
                    throw new C0.c();
                }
                i2.d dVar = riderCrestViewModel.f2875d;
                e eVar2 = new e(((r) sVar).f6048a);
                this.f6052f = 3;
                if (dVar.d(this, eVar2) == aVar) {
                    return aVar;
                }
            }
        } else {
            if (i != 1 && i != 2 && i != 3) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return kVar;
    }
}
