package y1;

/* loaded from: classes.dex */
public interface o {
}
