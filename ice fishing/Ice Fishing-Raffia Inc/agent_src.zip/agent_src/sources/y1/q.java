package y1;

/* loaded from: classes.dex */
public final class q implements s {

    /* renamed from: a, reason: collision with root package name */
    public final String f6047a;

    public q(String str) {
        this.f6047a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof q) && X1.i.a(this.f6047a, ((q) obj).f6047a);
    }

    public final int hashCode() {
        return this.f6047a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("KeepTag(tag="), this.f6047a, ")");
    }
}
