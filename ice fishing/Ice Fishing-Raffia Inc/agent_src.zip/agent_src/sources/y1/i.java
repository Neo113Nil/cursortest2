package y1;

import E0.C0000a;
import K1.C0011b;
import android.content.Context;
import android.text.Editable;
import com.kortosi.kluani.qorzanis.R;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestFragment;
import j2.InterfaceC0225g;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final /* synthetic */ class i implements InterfaceC0225g, X1.f {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f6035b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ RiderCrestFragment f6036c;

    public /* synthetic */ i(RiderCrestFragment riderCrestFragment, int i) {
        this.f6035b = i;
        this.f6036c = riderCrestFragment;
    }

    @Override // X1.f
    public final J1.a a() {
        switch (this.f6035b) {
            case 0:
                return new X1.a(this.f6036c, RiderCrestFragment.class, "render", "render(Lcom/kortosi/kluani/qorzanis/ui/profile/RiderCrestState;)V");
            default:
                return new X1.a(this.f6036c, RiderCrestFragment.class, "handle", "handle(Lcom/kortosi/kluani/qorzanis/ui/profile/RiderCrestEffect;)V");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ff  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x015c A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r3v8, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r5v10, types: [java.lang.Iterable, java.lang.Object, java.util.List] */
    @Override // j2.InterfaceC0225g
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object b(Object obj, N1.d dVar) {
        ArrayList arrayList;
        Iterator it;
        C0011b c0011b;
        int i;
        switch (this.f6035b) {
            case 0:
                v vVar = (v) obj;
                final RiderCrestFragment riderCrestFragment = this.f6036c;
                riderCrestFragment.getClass();
                int i3 = 0;
                if (X1.i.a(vVar, t.f6049a)) {
                    riderCrestFragment.P().i.setVisibility(0);
                    riderCrestFragment.P().f5296f.setVisibility(8);
                } else {
                    if (!(vVar instanceof u)) {
                        throw new C0.c();
                    }
                    riderCrestFragment.P().i.setVisibility(8);
                    riderCrestFragment.P().f5296f.setVisibility(0);
                    u uVar = (u) vVar;
                    final r1.f fVar = uVar.f6050a;
                    String strN = fVar.f5369a;
                    if (e2.h.z0(strN)) {
                        strN = riderCrestFragment.n(R.string.rider_tag_default);
                        X1.i.d(strN, "getString(...)");
                    }
                    if (riderCrestFragment.f2870i0) {
                        if (!riderCrestFragment.P().f5299j.hasFocus()) {
                            Editable text = riderCrestFragment.P().f5299j.getText();
                            if (!X1.i.a(text != null ? text.toString() : null, strN)) {
                            }
                        }
                        riderCrestFragment.P().f5304o.setText(String.valueOf(fVar.f5370b));
                        riderCrestFragment.P().f5294c.setText(riderCrestFragment.o(R.string.crest_of_twelve, Integer.valueOf(fVar.f5371c), 12));
                        q1.c cVarP = riderCrestFragment.P();
                        Q1.b bVar = r1.l.f5410h;
                        arrayList = new ArrayList(K1.n.S(bVar, 10));
                        it = bVar.iterator();
                        while (true) {
                            c0011b = (C0011b) it;
                            if (c0011b.hasNext()) {
                            }
                            Context contextL = riderCrestFragment.L();
                            String strName = lVar.name();
                            X1.i.e(strName, "id");
                            arrayList.add(new v1.a(strN, iIntValue, iIntValue, contextL.getColor(v1.f.f5738a[Math.abs(strName.hashCode()) % 6])));
                            i3 = 0;
                        }
                    } else {
                        riderCrestFragment.f2870i0 = true;
                        riderCrestFragment.P().f5299j.setText(strN);
                        riderCrestFragment.P().f5304o.setText(String.valueOf(fVar.f5370b));
                        riderCrestFragment.P().f5294c.setText(riderCrestFragment.o(R.string.crest_of_twelve, Integer.valueOf(fVar.f5371c), 12));
                        q1.c cVarP2 = riderCrestFragment.P();
                        Q1.b bVar2 = r1.l.f5410h;
                        arrayList = new ArrayList(K1.n.S(bVar2, 10));
                        it = bVar2.iterator();
                        while (true) {
                            c0011b = (C0011b) it;
                            if (c0011b.hasNext()) {
                                cVarP2.f5297g.setBars(arrayList);
                                riderCrestFragment.P().f5293b.setText(String.valueOf(fVar.e));
                                riderCrestFragment.P().f5303n.setText(String.valueOf(fVar.f5373f));
                                riderCrestFragment.P().e.setText(String.valueOf(fVar.f5372d));
                                riderCrestFragment.P().f5295d.setText(String.valueOf(fVar.f5374g));
                                ?? r5 = fVar.f5377k;
                                ArrayList arrayList2 = new ArrayList(K1.n.S(r5, 10));
                                Iterator it2 = r5.iterator();
                                while (it2.hasNext()) {
                                    arrayList2.add(Long.valueOf(((r1.h) it2.next()).f5383a));
                                }
                                final boolean z2 = !arrayList2.equals(riderCrestFragment.f2872k0);
                                riderCrestFragment.f2872k0 = arrayList2;
                                riderCrestFragment.P().f5305p.setVisibility(r5.isEmpty() ? 0 : 8);
                                riderCrestFragment.f2868g0.f4816d.b(r5, new Runnable() { // from class: y1.g
                                    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, java.util.Collection] */
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        if (!z2 || fVar.f5377k.isEmpty()) {
                                            return;
                                        }
                                        riderCrestFragment.P().f5306q.scheduleLayoutAnimation();
                                    }
                                });
                                q1.c cVarP3 = riderCrestFragment.P();
                                ?? r3 = fVar.f5378l;
                                cVarP3.f5300k.setVisibility(r3.isEmpty() ? 0 : 8);
                                x1.x xVar = riderCrestFragment.f2869h0;
                                if (xVar == null) {
                                    X1.i.g("opened");
                                    throw null;
                                }
                                xVar.f4816d.b(r3, null);
                                List list = uVar.f6051b;
                                if (list.isEmpty()) {
                                    i = 0;
                                } else {
                                    Iterator it3 = list.iterator();
                                    i = 0;
                                    while (it3.hasNext()) {
                                        if (((r1.e) it3.next()).f5368b && (i = i + 1) < 0) {
                                            throw new ArithmeticException("Count overflow has happened.");
                                        }
                                    }
                                }
                                int i4 = riderCrestFragment.f2871j0;
                                if (i4 >= 0 && i != i4) {
                                    q1.c cVarP4 = riderCrestFragment.P();
                                    C0000a c0000a = new C0000a();
                                    c0000a.D(riderCrestFragment.m().getInteger(R.integer.motion_normal));
                                    E0.u.a(cVarP4.f5301l, c0000a);
                                }
                                riderCrestFragment.f2871j0 = i;
                                riderCrestFragment.f2867f0.f4816d.b(list, null);
                            } else {
                                r1.l lVar = (r1.l) c0011b.next();
                                String strN2 = riderCrestFragment.n(v1.f.b(lVar));
                                X1.i.d(strN2, "getString(...)");
                                Integer num = (Integer) fVar.f5375h.get(lVar);
                                int iIntValue = num != null ? num.intValue() : i3;
                                Integer num2 = (Integer) fVar.i.get(lVar);
                                int iIntValue2 = num2 != null ? num2.intValue() : 0;
                                Context contextL2 = riderCrestFragment.L();
                                String strName2 = lVar.name();
                                X1.i.e(strName2, "id");
                                arrayList.add(new v1.a(strN2, iIntValue, iIntValue2, contextL2.getColor(v1.f.f5738a[Math.abs(strName2.hashCode()) % 6])));
                                i3 = 0;
                            }
                        }
                    }
                }
                return J1.k.f632a;
            default:
                e eVar = (e) obj;
                RiderCrestFragment riderCrestFragment2 = this.f6036c;
                riderCrestFragment2.getClass();
                if (eVar == null) {
                    throw new C0.c();
                }
                v1.f.a(riderCrestFragment2, R.id.riderCrestFragment, new n(eVar.f6028a));
                return J1.k.f632a;
        }
    }

    public final boolean equals(Object obj) {
        switch (this.f6035b) {
            case 0:
                if ((obj instanceof InterfaceC0225g) && (obj instanceof X1.f)) {
                    break;
                }
                break;
            default:
                if ((obj instanceof InterfaceC0225g) && (obj instanceof X1.f)) {
                    break;
                }
                break;
        }
        return a().equals(((X1.f) obj).a());
    }

    public final int hashCode() {
        switch (this.f6035b) {
        }
        return a().hashCode();
    }
}
