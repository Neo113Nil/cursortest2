package y1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestFragment;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestViewModel;
import g2.InterfaceC0158w;
import j2.L;

/* loaded from: classes.dex */
public final class j extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f6037f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ RiderCrestFragment f6038g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(RiderCrestFragment riderCrestFragment, N1.d dVar) {
        super(2, dVar);
        this.f6038g = riderCrestFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) throws Throwable {
        ((j) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
        return O1.a.f839b;
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new j(this.f6038g, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f6037f;
        if (i != 0) {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
            throw new C0.c();
        }
        AbstractC0046a.N(obj);
        RiderCrestFragment riderCrestFragment = this.f6038g;
        RiderCrestViewModel riderCrestViewModelQ = riderCrestFragment.Q();
        i iVar = new i(riderCrestFragment, 0);
        this.f6037f = 1;
        ((L) riderCrestViewModelQ.f2876f.f3856b).c(iVar, this);
        return aVar;
    }
}
