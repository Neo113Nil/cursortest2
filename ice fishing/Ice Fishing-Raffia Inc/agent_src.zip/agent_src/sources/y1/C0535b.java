package y1;

import android.widget.LinearLayout;
import p0.l0;

/* renamed from: y1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0535b extends l0 {

    /* renamed from: u, reason: collision with root package name */
    public final C.k f6025u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ x1.x f6026v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0535b(x1.x xVar, C.k kVar) {
        super((LinearLayout) kVar.f271a);
        this.f6026v = xVar;
        this.f6025u = kVar;
    }
}
