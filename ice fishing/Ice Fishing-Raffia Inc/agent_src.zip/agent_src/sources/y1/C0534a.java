package y1;

import p0.AbstractC0371b;

/* renamed from: y1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0534a extends AbstractC0371b {
    public static final C0534a e = new C0534a(0);

    /* renamed from: f, reason: collision with root package name */
    public static final C0534a f6022f = new C0534a(1);

    /* renamed from: g, reason: collision with root package name */
    public static final C0534a f6023g = new C0534a(2);

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f6024d;

    public /* synthetic */ C0534a(int i) {
        this.f6024d = i;
    }

    @Override // p0.AbstractC0371b
    public final boolean a(Object obj, Object obj2) {
        switch (this.f6024d) {
            case 0:
                return ((r1.j) obj).equals((r1.j) obj2);
            case 1:
                return ((r1.e) obj).equals((r1.e) obj2);
            default:
                return ((r1.h) obj).equals((r1.h) obj2);
        }
    }

    @Override // p0.AbstractC0371b
    public final boolean b(Object obj, Object obj2) {
        switch (this.f6024d) {
            case 0:
                return ((r1.j) obj).f5391a.equals(((r1.j) obj2).f5391a);
            case 1:
                return ((r1.e) obj).f5367a == ((r1.e) obj2).f5367a;
            default:
                return ((r1.h) obj).f5383a == ((r1.h) obj2).f5383a;
        }
    }
}
