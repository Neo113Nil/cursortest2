package y1;

import android.os.Bundle;
import com.kortosi.kluani.qorzanis.R;
import j0.InterfaceC0194B;

/* loaded from: classes.dex */
public final class n implements InterfaceC0194B {

    /* renamed from: a, reason: collision with root package name */
    public final String f6045a;

    public n(String str) {
        this.f6045a = str;
    }

    @Override // j0.InterfaceC0194B
    public final Bundle a() {
        Bundle bundle = new Bundle();
        bundle.putString("trickId", this.f6045a);
        return bundle;
    }

    @Override // j0.InterfaceC0194B
    public final int b() {
        return R.id.action_riderCrest_to_landingCard;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof n) && X1.i.a(this.f6045a, ((n) obj).f6045a);
    }

    public final int hashCode() {
        return this.f6045a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("ActionRiderCrestToLandingCard(trickId="), this.f6045a, ")");
    }
}
