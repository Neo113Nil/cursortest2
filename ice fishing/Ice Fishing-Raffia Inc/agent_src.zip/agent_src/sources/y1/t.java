package y1;

/* loaded from: classes.dex */
public final class t implements v {

    /* renamed from: a, reason: collision with root package name */
    public static final t f6049a = new t();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof t);
    }

    public final int hashCode() {
        return -1791931478;
    }

    public final String toString() {
        return "Loading";
    }
}
