package y1;

import android.widget.LinearLayout;
import p0.l0;

/* loaded from: classes.dex */
public final class y extends l0 {

    /* renamed from: u, reason: collision with root package name */
    public final C.k f6057u;

    public y(C.k kVar) {
        super((LinearLayout) kVar.f271a);
        this.f6057u = kVar;
    }
}
