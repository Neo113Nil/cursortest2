package y1;

import P.C0023k;
import a.AbstractC0046a;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.lifecycle.Z;
import com.kortosi.kluani.qorzanis.R;
import com.kortosi.kluani.qorzanis.ui.common.TrailNodeView;
import com.kortosi.kluani.qorzanis.ui.common.TrickSigilView;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import p0.AbstractC0371b;
import p0.G;
import p0.l0;
import r1.C0429a;
import z1.C0542b;

/* loaded from: classes.dex */
public final class d extends G {
    public final /* synthetic */ int e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(AbstractC0371b abstractC0371b, int i) {
        super(abstractC0371b);
        this.e = i;
    }

    @Override // p0.L
    public final void d(l0 l0Var, int i) {
        int i3;
        int i4;
        String string;
        switch (this.e) {
            case 0:
                Object objG = g(i);
                X1.i.d(objG, "getItem(...)");
                r1.e eVar = (r1.e) objG;
                C0023k c0023k = ((C0536c) l0Var).f6027u;
                Context context = ((LinearLayout) c0023k.f912b).getContext();
                r1.d dVar = eVar.f5367a;
                int iOrdinal = dVar.ordinal();
                if (iOrdinal == 0) {
                    i3 = R.string.patch_first_report;
                } else if (iOrdinal == 1) {
                    i3 = R.string.patch_five_bag;
                } else if (iOrdinal == 2) {
                    i3 = R.string.patch_full_rung;
                } else if (iOrdinal == 3) {
                    i3 = R.string.patch_clean_sheet;
                } else if (iOrdinal == 4) {
                    i3 = R.string.patch_fifty_points;
                } else {
                    if (iOrdinal != 5) {
                        throw new C0.c();
                    }
                    i3 = R.string.patch_ten_cards;
                }
                ((TextView) c0023k.f913c).setText(context.getString(i3));
                int iOrdinal2 = dVar.ordinal();
                if (iOrdinal2 == 0) {
                    i4 = R.string.patch_first_report_rule;
                } else if (iOrdinal2 == 1) {
                    i4 = R.string.patch_five_bag_rule;
                } else if (iOrdinal2 == 2) {
                    i4 = R.string.patch_full_rung_rule;
                } else if (iOrdinal2 == 3) {
                    i4 = R.string.patch_clean_sheet_rule;
                } else if (iOrdinal2 == 4) {
                    i4 = R.string.patch_fifty_points_rule;
                } else {
                    if (iOrdinal2 != 5) {
                        throw new C0.c();
                    }
                    i4 = R.string.patch_ten_cards_rule;
                }
                ((TextView) c0023k.f914d).setText(context.getString(i4));
                boolean z2 = eVar.f5368b;
                float f3 = z2 ? 1.0f : 0.4f;
                LinearLayout linearLayout = (LinearLayout) c0023k.f912b;
                linearLayout.setAlpha(f3);
                linearLayout.setContentDescription(context.getString(z2 ? R.string.cd_patch_earned : R.string.cd_patch_locked));
                return;
            case 1:
                y yVar = (y) l0Var;
                Object objG2 = g(i);
                X1.i.d(objG2, "getItem(...)");
                r1.h hVar = (r1.h) objG2;
                boolean z3 = i == 0;
                boolean z4 = i == a() - 1;
                C.k kVar = yVar.f6057u;
                Context context2 = ((LinearLayout) kVar.f271a).getContext();
                TrailNodeView trailNodeView = (TrailNodeView) kVar.f274d;
                trailNodeView.setFirst(z3);
                trailNodeView.setLast(z4);
                r1.i iVar = r1.i.f5389c;
                r1.i iVar2 = hVar.f5384b;
                trailNodeView.setFilled(iVar2 == iVar);
                int iOrdinal3 = iVar2.ordinal();
                if (iOrdinal3 == 0) {
                    string = context2.getString(R.string.trail_report_kept, hVar.f5385c);
                } else {
                    if (iOrdinal3 != 1) {
                        throw new C0.c();
                    }
                    string = context2.getString(R.string.trail_check_done, Integer.valueOf(hVar.f5386d), Integer.valueOf(hVar.e));
                }
                ((TextView) kVar.f273c).setText(string);
                DateTimeFormatter dateTimeFormatter = v1.b.f5725a;
                String str = Instant.ofEpochMilli(hVar.f5387f).atZone(ZoneId.systemDefault()).toLocalDate().format(v1.b.f5725a);
                X1.i.d(str, "format(...)");
                ((TextView) kVar.f272b).setText(str);
                return;
            default:
                Object objG3 = g(i);
                X1.i.d(objG3, "getItem(...)");
                C0429a c0429a = (C0429a) objG3;
                Z z5 = ((C0542b) l0Var).f6060u;
                Context context3 = ((LinearLayout) z5.f1801b).getContext();
                Integer numValueOf = Integer.valueOf(i + 1);
                r1.b bVar = c0429a.f5352a;
                ((TextView) z5.f1803d).setText(context3.getString(R.string.check_result_row, numValueOf, bVar.f5354a.f5392b));
                ((TrickSigilView) z5.f1804f).a(bVar.f5354a);
                int i5 = bVar.f5356c;
                int i6 = c0429a.f5353b;
                boolean z6 = i6 == i5;
                TextView textView = (TextView) z5.e;
                ImageView imageView = (ImageView) z5.f1802c;
                if (z6) {
                    imageView.setImageResource(R.drawable.ic_read_right);
                    imageView.setContentDescription(context3.getString(R.string.cd_read_right));
                    textView.setVisibility(8);
                    return;
                }
                imageView.setImageResource(R.drawable.ic_read_wrong);
                imageView.setContentDescription(context3.getString(R.string.cd_read_wrong));
                textView.setVisibility(0);
                String str2 = (String) K1.l.Y(bVar.f5355b, i6);
                if (str2 == null) {
                    str2 = "";
                }
                textView.setText(context3.getString(R.string.check_you_said, str2));
                return;
        }
    }

    @Override // p0.L
    public final l0 e(ViewGroup viewGroup, int i) {
        switch (this.e) {
            case 0:
                X1.i.e(viewGroup, "parent");
                View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_profile_patch, viewGroup, false);
                int i3 = R.id.patchName;
                TextView textView = (TextView) AbstractC0046a.w(viewInflate, R.id.patchName);
                if (textView != null) {
                    i3 = R.id.patchRule;
                    TextView textView2 = (TextView) AbstractC0046a.w(viewInflate, R.id.patchRule);
                    if (textView2 != null) {
                        return new C0536c(new C0023k((LinearLayout) viewInflate, textView, textView2, 8));
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i3)));
            case 1:
                X1.i.e(viewGroup, "parent");
                View viewInflate2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_profile_trail, viewGroup, false);
                int i4 = R.id.trailDate;
                TextView textView3 = (TextView) AbstractC0046a.w(viewInflate2, R.id.trailDate);
                if (textView3 != null) {
                    i4 = R.id.trailLabel;
                    TextView textView4 = (TextView) AbstractC0046a.w(viewInflate2, R.id.trailLabel);
                    if (textView4 != null) {
                        i4 = R.id.trailNode;
                        TrailNodeView trailNodeView = (TrailNodeView) AbstractC0046a.w(viewInflate2, R.id.trailNode);
                        if (trailNodeView != null) {
                            return new y(new C.k((LinearLayout) viewInflate2, textView3, textView4, trailNodeView));
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(viewInflate2.getResources().getResourceName(i4)));
            default:
                X1.i.e(viewGroup, "parent");
                View viewInflate3 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_quiz_result, viewGroup, false);
                int i5 = R.id.resultIcon;
                ImageView imageView = (ImageView) AbstractC0046a.w(viewInflate3, R.id.resultIcon);
                if (imageView != null) {
                    i5 = R.id.resultName;
                    TextView textView5 = (TextView) AbstractC0046a.w(viewInflate3, R.id.resultName);
                    if (textView5 != null) {
                        i5 = R.id.resultSaid;
                        TextView textView6 = (TextView) AbstractC0046a.w(viewInflate3, R.id.resultSaid);
                        if (textView6 != null) {
                            i5 = R.id.resultSigil;
                            TrickSigilView trickSigilView = (TrickSigilView) AbstractC0046a.w(viewInflate3, R.id.resultSigil);
                            if (trickSigilView != null) {
                                return new C0542b(new Z((LinearLayout) viewInflate3, imageView, textView5, textView6, trickSigilView));
                            }
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(viewInflate3.getResources().getResourceName(i5)));
        }
    }
}
