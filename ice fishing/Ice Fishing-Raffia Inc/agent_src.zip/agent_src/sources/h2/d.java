package h2;

import J1.k;
import W1.l;
import X1.i;
import X1.j;
import android.os.Bundle;
import d2.h;
import e1.C0123e;
import j0.AbstractC0193A;
import j0.C0198c;
import j0.C0205j;
import j0.C0208m;
import j0.D;
import j0.F;
import j0.I;
import j0.J;
import j0.U;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class d extends j implements l {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f3516c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f3517d;
    public final /* synthetic */ Object e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(Object obj, int i, Object obj2) {
        super(1);
        this.f3516c = i;
        this.f3517d = obj;
        this.e = obj2;
    }

    @Override // W1.l
    public final Object h(Object obj) {
        U u2;
        AbstractC0193A abstractC0193AC;
        k kVar = k.f632a;
        Object obj2 = this.f3517d;
        Object obj3 = this.e;
        switch (this.f3516c) {
            case 0:
                ((e) obj2).f3518d.removeCallbacks((E.b) obj3);
                return kVar;
            case 1:
                J j3 = (J) obj;
                i.e(j3, "$this$navOptions");
                j3.a(C0198c.i);
                AbstractC0193A abstractC0193A = (AbstractC0193A) obj2;
                if (abstractC0193A instanceof D) {
                    int i = AbstractC0193A.f3578k;
                    Iterator it = h.t0(abstractC0193A, C0198c.f3682m).iterator();
                    while (true) {
                        F f3 = (F) obj3;
                        if (it.hasNext()) {
                            AbstractC0193A abstractC0193A2 = (AbstractC0193A) it.next();
                            AbstractC0193A abstractC0193AG = f3.g();
                            if (i.a(abstractC0193A2, abstractC0193AG != null ? abstractC0193AG.f3580c : null)) {
                            }
                        } else {
                            int i3 = D.f3589o;
                            j3.f3641d = b1.e.v(f3.i()).i;
                            j3.e = true;
                        }
                    }
                }
                return kVar;
            default:
                C0205j c0205j = (C0205j) obj;
                i.e(c0205j, "backStackEntry");
                AbstractC0193A abstractC0193A3 = c0205j.f3704c;
                if (abstractC0193A3 == null) {
                    abstractC0193A3 = null;
                }
                if (abstractC0193A3 == null || (abstractC0193AC = (u2 = (U) obj2).c(abstractC0193A3, c0205j.d(), (I) obj3)) == null) {
                    return null;
                }
                if (abstractC0193AC.equals(abstractC0193A3)) {
                    return c0205j;
                }
                C0208m c0208mB = u2.b();
                Bundle bundleA = abstractC0193AC.a(c0205j.d());
                F f4 = c0208mB.f3724h;
                return C0123e.e(f4.f3597a, abstractC0193AC, bundleA, f4.j(), f4.f3609o);
        }
    }
}
