package h2;

import N1.i;
import android.os.Handler;
import android.os.Looper;
import g2.AbstractC0155t;
import g2.B;
import g2.C0143g;
import g2.C0156u;
import g2.F;
import g2.H;
import g2.Y;
import g2.k0;
import g2.r0;
import java.util.concurrent.CancellationException;
import l2.AbstractC0269a;
import l2.o;

/* loaded from: classes.dex */
public final class e extends AbstractC0155t implements B {
    private volatile e _immediate;

    /* renamed from: d, reason: collision with root package name */
    public final Handler f3518d;
    public final String e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f3519f;

    /* renamed from: g, reason: collision with root package name */
    public final e f3520g;

    public e(Handler handler, String str, boolean z2) {
        this.f3518d = handler;
        this.e = str;
        this.f3519f = z2;
        this._immediate = z2 ? this : null;
        e eVar = this._immediate;
        if (eVar == null) {
            eVar = new e(handler, str, true);
            this._immediate = eVar;
        }
        this.f3520g = eVar;
    }

    @Override // g2.B
    public final void D(long j3, C0143g c0143g) {
        E.b bVar = new E.b(c0143g, 7, this);
        if (j3 > 4611686018427387903L) {
            j3 = 4611686018427387903L;
        }
        if (this.f3518d.postDelayed(bVar, j3)) {
            c0143g.x(new d(this, 0, bVar));
        } else {
            L(c0143g.f3143f, bVar);
        }
    }

    @Override // g2.AbstractC0155t
    public final void H(i iVar, Runnable runnable) {
        if (this.f3518d.post(runnable)) {
            return;
        }
        L(iVar, runnable);
    }

    @Override // g2.AbstractC0155t
    public final boolean J() {
        return (this.f3519f && X1.i.a(Looper.myLooper(), this.f3518d.getLooper())) ? false : true;
    }

    @Override // g2.AbstractC0155t
    public AbstractC0155t K(int i) {
        AbstractC0269a.b(1);
        return this;
    }

    public final void L(i iVar, Runnable runnable) {
        CancellationException cancellationException = new CancellationException("The task was rejected, the handler underlying the dispatcher '" + this + "' was closed");
        Y y2 = (Y) iVar.C(C0156u.f3173c);
        if (y2 != null) {
            y2.a(cancellationException);
        }
        F.f3105b.H(iVar, runnable);
    }

    public final boolean equals(Object obj) {
        return (obj instanceof e) && ((e) obj).f3518d == this.f3518d;
    }

    public final int hashCode() {
        return System.identityHashCode(this.f3518d);
    }

    @Override // g2.AbstractC0155t
    public final String toString() {
        e eVar;
        String str;
        n2.d dVar = F.f3104a;
        e eVar2 = o.f4111a;
        if (this == eVar2) {
            str = "Dispatchers.Main";
        } else {
            try {
                eVar = eVar2.f3520g;
            } catch (UnsupportedOperationException unused) {
                eVar = null;
            }
            str = this == eVar ? "Dispatchers.Main.immediate" : null;
        }
        if (str != null) {
            return str;
        }
        String string = this.e;
        if (string == null) {
            string = this.f3518d.toString();
        }
        return this.f3519f ? H.e.h(string, ".immediate") : string;
    }

    @Override // g2.B
    public final H x(long j3, final r0 r0Var, i iVar) {
        if (j3 > 4611686018427387903L) {
            j3 = 4611686018427387903L;
        }
        if (this.f3518d.postDelayed(r0Var, j3)) {
            return new H() { // from class: h2.c
                @Override // g2.H
                public final void f() {
                    this.f3514b.f3518d.removeCallbacks(r0Var);
                }
            };
        }
        L(iVar, r0Var);
        return k0.f3152b;
    }

    public e(Handler handler) {
        this(handler, null, false);
    }
}
