package x1;

/* renamed from: x1.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0515q {
}
