package x1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import com.kortosi.kluani.qorzanis.ui.home.DropInViewModel;
import g2.InterfaceC0158w;
import j2.L;

/* renamed from: x1.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0506h extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5950f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ DropInFragment f5951g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0506h(DropInFragment dropInFragment, N1.d dVar) {
        super(2, dVar);
        this.f5951g = dropInFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) throws Throwable {
        ((C0506h) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
        return O1.a.f839b;
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new C0506h(this.f5951g, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5950f;
        if (i != 0) {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
            throw new C0.c();
        }
        AbstractC0046a.N(obj);
        DropInFragment dropInFragment = this.f5951g;
        DropInViewModel dropInViewModelQ = dropInFragment.Q();
        C0505g c0505g = new C0505g(dropInFragment, 0);
        this.f5950f = 1;
        ((L) dropInViewModelQ.f2859d.f3856b).c(c0505g, this);
        return aVar;
    }
}
