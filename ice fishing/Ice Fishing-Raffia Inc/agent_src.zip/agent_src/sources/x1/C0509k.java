package x1;

import a.AbstractC0046a;
import androidx.lifecycle.T;
import c0.Z;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import g2.InterfaceC0158w;

/* renamed from: x1.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0509k extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5956f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ DropInFragment f5957g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0509k(DropInFragment dropInFragment, N1.d dVar) {
        super(2, dVar);
        this.f5957g = dropInFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((C0509k) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new C0509k(this.f5957g, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5956f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            DropInFragment dropInFragment = this.f5957g;
            Z zP = dropInFragment.p();
            C0508j c0508j = new C0508j(dropInFragment, null);
            this.f5956f = 1;
            if (T.h(zP, c0508j, this) == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
