package x1;

/* renamed from: x1.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0512n implements InterfaceC0515q {

    /* renamed from: a, reason: collision with root package name */
    public final String f5959a;

    public C0512n(String str) {
        this.f5959a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0512n) && X1.i.a(this.f5959a, ((C0512n) obj).f5959a);
    }

    public final int hashCode() {
        return this.f5959a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("OpenCard(trickId="), this.f5959a, ")");
    }
}
