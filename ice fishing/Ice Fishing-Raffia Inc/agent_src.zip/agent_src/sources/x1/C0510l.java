package x1;

import android.os.Bundle;
import com.kortosi.kluani.qorzanis.R;
import j0.InterfaceC0194B;

/* renamed from: x1.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0510l implements InterfaceC0194B {

    /* renamed from: a, reason: collision with root package name */
    public final String f5958a;

    public C0510l(String str) {
        this.f5958a = str;
    }

    @Override // j0.InterfaceC0194B
    public final Bundle a() {
        Bundle bundle = new Bundle();
        bundle.putString("trickId", this.f5958a);
        return bundle;
    }

    @Override // j0.InterfaceC0194B
    public final int b() {
        return R.id.action_dropIn_to_landingCard;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0510l) && X1.i.a(this.f5958a, ((C0510l) obj).f5958a);
    }

    public final int hashCode() {
        return this.f5958a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("ActionDropInToLandingCard(trickId="), this.f5958a, ")");
    }
}
