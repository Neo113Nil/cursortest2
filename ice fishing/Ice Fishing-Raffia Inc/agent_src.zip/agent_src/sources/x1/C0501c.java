package x1;

/* renamed from: x1.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0501c implements InterfaceC0502d {

    /* renamed from: a, reason: collision with root package name */
    public static final C0501c f5942a = new C0501c();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C0501c);
    }

    public final int hashCode() {
        return -1885450080;
    }

    public final String toString() {
        return "GoRoster";
    }
}
