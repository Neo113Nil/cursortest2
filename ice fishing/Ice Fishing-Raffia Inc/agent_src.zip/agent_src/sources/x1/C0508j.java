package x1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import g2.AbstractC0160y;
import g2.InterfaceC0158w;

/* renamed from: x1.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0508j extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f5954f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ DropInFragment f5955g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0508j(DropInFragment dropInFragment, N1.d dVar) {
        super(2, dVar);
        this.f5955g = dropInFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) throws Throwable {
        C0508j c0508j = (C0508j) m((N1.d) obj2, (InterfaceC0158w) obj);
        J1.k kVar = J1.k.f632a;
        c0508j.o(kVar);
        return kVar;
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        C0508j c0508j = new C0508j(this.f5955g, dVar);
        c0508j.f5954f = obj;
        return c0508j;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        AbstractC0046a.N(obj);
        InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f5954f;
        DropInFragment dropInFragment = this.f5955g;
        AbstractC0160y.l(interfaceC0158w, null, 0, new C0506h(dropInFragment, null), 3);
        AbstractC0160y.l(interfaceC0158w, null, 0, new C0507i(dropInFragment, null), 3);
        return J1.k.f632a;
    }
}
