package x1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.home.DropInViewModel;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class u extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5968f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0515q f5969g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ DropInViewModel f5970h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(InterfaceC0515q interfaceC0515q, DropInViewModel dropInViewModel, N1.d dVar) {
        super(2, dVar);
        this.f5969g = interfaceC0515q;
        this.f5970h = dropInViewModel;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((u) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new u(this.f5969g, this.f5970h, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5968f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            C0514p c0514p = C0514p.f5961a;
            InterfaceC0515q interfaceC0515q = this.f5969g;
            boolean zEquals = interfaceC0515q.equals(c0514p);
            DropInViewModel dropInViewModel = this.f5970h;
            if (zEquals) {
                i2.d dVar = dropInViewModel.f2857b;
                C0501c c0501c = C0501c.f5942a;
                this.f5968f = 1;
                if (dVar.d(this, c0501c) == aVar) {
                    return aVar;
                }
            } else if (interfaceC0515q.equals(C0513o.f5960a)) {
                i2.d dVar2 = dropInViewModel.f2857b;
                C0500b c0500b = C0500b.f5941a;
                this.f5968f = 2;
                if (dVar2.d(this, c0500b) == aVar) {
                    return aVar;
                }
            } else {
                if (!(interfaceC0515q instanceof C0512n)) {
                    throw new C0.c();
                }
                i2.d dVar3 = dropInViewModel.f2857b;
                C0499a c0499a = new C0499a(((C0512n) interfaceC0515q).f5959a);
                this.f5968f = 3;
                if (dVar3.d(this, c0499a) == aVar) {
                    return aVar;
                }
            }
        } else {
            if (i != 1 && i != 2 && i != 3) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
