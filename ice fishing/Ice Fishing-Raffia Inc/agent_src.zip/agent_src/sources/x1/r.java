package x1;

/* loaded from: classes.dex */
public final class r implements t {

    /* renamed from: a, reason: collision with root package name */
    public static final r f5962a = new r();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof r);
    }

    public final int hashCode() {
        return 1617059823;
    }

    public final String toString() {
        return "Loading";
    }
}
