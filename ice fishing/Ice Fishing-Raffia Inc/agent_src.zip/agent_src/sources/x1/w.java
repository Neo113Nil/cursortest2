package x1;

import com.google.android.material.card.MaterialCardView;
import p0.l0;

/* loaded from: classes.dex */
public final class w extends l0 {

    /* renamed from: u, reason: collision with root package name */
    public final C.k f5972u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ x f5973v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(x xVar, C.k kVar) {
        super((MaterialCardView) kVar.f271a);
        this.f5973v = xVar;
        this.f5972u = kVar;
    }
}
