package x1;

/* renamed from: x1.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0513o implements InterfaceC0515q {

    /* renamed from: a, reason: collision with root package name */
    public static final C0513o f5960a = new C0513o();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C0513o);
    }

    public final int hashCode() {
        return 1523450556;
    }

    public final String toString() {
        return "OpenCheck";
    }
}
