package x1;

import p0.AbstractC0371b;

/* loaded from: classes.dex */
public final class v extends AbstractC0371b {

    /* renamed from: d, reason: collision with root package name */
    public static final v f5971d = new v();

    @Override // p0.AbstractC0371b
    public final boolean a(Object obj, Object obj2) {
        return ((r1.j) obj).equals((r1.j) obj2);
    }

    @Override // p0.AbstractC0371b
    public final boolean b(Object obj, Object obj2) {
        return ((r1.j) obj).f5391a.equals(((r1.j) obj2).f5391a);
    }
}
