package x1;

import K1.C0010a;
import android.view.View;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;

/* renamed from: x1.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class ViewOnClickListenerC0504f implements View.OnClickListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f5945b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ r1.j f5946c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f5947d;

    public /* synthetic */ ViewOnClickListenerC0504f(Object obj, r1.j jVar, int i) {
        this.f5945b = i;
        this.f5947d = obj;
        this.f5946c = jVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f5945b) {
            case 0:
                ((DropInFragment) this.f5947d).Q().e(new C0512n(this.f5946c.f5391a));
                break;
            case 1:
                ((C0010a) ((x) this.f5947d).f5974f).h(this.f5946c);
                break;
            default:
                ((C0010a) ((x) this.f5947d).f5974f).h(this.f5946c);
                break;
        }
    }
}
