package x1;

/* renamed from: x1.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0502d {
}
