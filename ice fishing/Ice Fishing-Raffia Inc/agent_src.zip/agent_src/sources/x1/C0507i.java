package x1;

import a.AbstractC0046a;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import com.kortosi.kluani.qorzanis.ui.home.DropInViewModel;
import g2.InterfaceC0158w;

/* renamed from: x1.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0507i extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5952f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ DropInFragment f5953g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0507i(DropInFragment dropInFragment, N1.d dVar) {
        super(2, dVar);
        this.f5953g = dropInFragment;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((C0507i) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new C0507i(this.f5953g, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5952f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            DropInFragment dropInFragment = this.f5953g;
            DropInViewModel dropInViewModelQ = dropInFragment.Q();
            C0505g c0505g = new C0505g(dropInFragment, 1);
            this.f5952f = 1;
            if (dropInViewModelQ.f2858c.c(c0505g, this) == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
