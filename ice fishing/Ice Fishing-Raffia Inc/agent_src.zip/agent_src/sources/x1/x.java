package x1;

import K1.C0010a;
import a.AbstractC0046a;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.card.MaterialCardView;
import com.kortosi.kluani.qorzanis.R;
import com.kortosi.kluani.qorzanis.ui.common.TrickSigilView;
import p0.G;
import p0.l0;
import y1.C0534a;
import y1.C0535b;

/* loaded from: classes.dex */
public final class x extends G {
    public final /* synthetic */ int e = 0;

    /* renamed from: f, reason: collision with root package name */
    public final W1.l f5974f;

    public x(C0010a c0010a) {
        super(v.f5971d);
        this.f5974f = c0010a;
    }

    @Override // p0.L
    public final void d(l0 l0Var, int i) {
        switch (this.e) {
            case 0:
                w wVar = (w) l0Var;
                Object objG = g(i);
                X1.i.d(objG, "getItem(...)");
                r1.j jVar = (r1.j) objG;
                C.k kVar = wVar.f5972u;
                ((TrickSigilView) kVar.f274d).a(jVar);
                MaterialCardView materialCardView = (MaterialCardView) kVar.f271a;
                Context context = materialCardView.getContext();
                X1.i.d(context, "getContext(...)");
                materialCardView.setCardBackgroundColor(context.getColor(v1.f.f5738a[Math.abs(jVar.f5391a.hashCode()) % 6]));
                ((TextView) kVar.f272b).setText(jVar.f5392b);
                ((TextView) kVar.f273c).setText(materialCardView.getContext().getString(R.string.rung_short, Integer.valueOf(jVar.f5394d)));
                materialCardView.setOnClickListener(new ViewOnClickListenerC0504f(wVar.f5973v, jVar, 1));
                break;
            default:
                C0535b c0535b = (C0535b) l0Var;
                Object objG2 = g(i);
                X1.i.d(objG2, "getItem(...)");
                r1.j jVar2 = (r1.j) objG2;
                C.k kVar2 = c0535b.f6025u;
                ((TrickSigilView) kVar2.f274d).a(jVar2);
                ((TextView) kVar2.f273c).setText(jVar2.f5392b);
                LinearLayout linearLayout = (LinearLayout) kVar2.f271a;
                ((TextView) kVar2.f272b).setText(linearLayout.getContext().getString(v1.f.b(jVar2.f5393c)));
                linearLayout.setOnClickListener(new ViewOnClickListenerC0504f(c0535b.f6026v, jVar2, 2));
                break;
        }
    }

    @Override // p0.L
    public final l0 e(ViewGroup viewGroup, int i) {
        switch (this.e) {
            case 0:
                X1.i.e(viewGroup, "parent");
                View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_home_rail, viewGroup, false);
                int i3 = R.id.railName;
                TextView textView = (TextView) AbstractC0046a.w(viewInflate, R.id.railName);
                if (textView != null) {
                    i3 = R.id.railRung;
                    TextView textView2 = (TextView) AbstractC0046a.w(viewInflate, R.id.railRung);
                    if (textView2 != null) {
                        i3 = R.id.railSigil;
                        TrickSigilView trickSigilView = (TrickSigilView) AbstractC0046a.w(viewInflate, R.id.railSigil);
                        if (trickSigilView != null) {
                            return new w(this, new C.k((MaterialCardView) viewInflate, textView, textView2, trickSigilView));
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i3)));
            default:
                X1.i.e(viewGroup, "parent");
                View viewInflate2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_profile_opened, viewGroup, false);
                int i4 = R.id.openedFamily;
                TextView textView3 = (TextView) AbstractC0046a.w(viewInflate2, R.id.openedFamily);
                if (textView3 != null) {
                    i4 = R.id.openedName;
                    TextView textView4 = (TextView) AbstractC0046a.w(viewInflate2, R.id.openedName);
                    if (textView4 != null) {
                        i4 = R.id.openedSigil;
                        TrickSigilView trickSigilView2 = (TrickSigilView) AbstractC0046a.w(viewInflate2, R.id.openedSigil);
                        if (trickSigilView2 != null) {
                            return new C0535b(this, new C.k((LinearLayout) viewInflate2, textView3, textView4, trickSigilView2));
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(viewInflate2.getResources().getResourceName(i4)));
        }
    }

    public x(C0010a c0010a, byte b3) {
        super(C0534a.e);
        this.f5974f = c0010a;
    }
}
