package x1;

/* renamed from: x1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0500b implements InterfaceC0502d {

    /* renamed from: a, reason: collision with root package name */
    public static final C0500b f5941a = new C0500b();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C0500b);
    }

    public final int hashCode() {
        return -74896301;
    }

    public final String toString() {
        return "GoCheck";
    }
}
