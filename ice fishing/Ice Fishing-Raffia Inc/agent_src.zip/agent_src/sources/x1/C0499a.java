package x1;

/* renamed from: x1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0499a implements InterfaceC0502d {

    /* renamed from: a, reason: collision with root package name */
    public final String f5940a;

    public C0499a(String str) {
        this.f5940a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0499a) && X1.i.a(this.f5940a, ((C0499a) obj).f5940a);
    }

    public final int hashCode() {
        return this.f5940a.hashCode();
    }

    public final String toString() {
        return H.e.j(new StringBuilder("GoCard(trickId="), this.f5940a, ")");
    }
}
