package x1;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class s implements t {

    /* renamed from: a, reason: collision with root package name */
    public final int f5963a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5964b;

    /* renamed from: c, reason: collision with root package name */
    public final int f5965c;

    /* renamed from: d, reason: collision with root package name */
    public final r1.j f5966d;
    public final List e;

    /* renamed from: f, reason: collision with root package name */
    public final ArrayList f5967f;

    public s(int i, int i3, int i4, r1.j jVar, List list, ArrayList arrayList) {
        X1.i.e(jVar, "session");
        this.f5963a = i;
        this.f5964b = i3;
        this.f5965c = i4;
        this.f5966d = jVar;
        this.e = list;
        this.f5967f = arrayList;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return this.f5963a == sVar.f5963a && this.f5964b == sVar.f5964b && this.f5965c == sVar.f5965c && X1.i.a(this.f5966d, sVar.f5966d) && this.e.equals(sVar.e) && this.f5967f.equals(sVar.f5967f);
    }

    public final int hashCode() {
        return this.f5967f.hashCode() + ((this.e.hashCode() + ((this.f5966d.hashCode() + H.e.b(this.f5965c, H.e.b(this.f5964b, Integer.hashCode(this.f5963a) * 31, 31), 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Ready(rosterCount=" + this.f5963a + ", baggedCount=" + this.f5964b + ", spotScore=" + this.f5965c + ", session=" + this.f5966d + ", topRungs=" + this.e + ", pips=" + this.f5967f + ")";
    }
}
