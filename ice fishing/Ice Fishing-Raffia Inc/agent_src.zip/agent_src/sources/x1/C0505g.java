package x1;

import com.kortosi.kluani.qorzanis.R;
import com.kortosi.kluani.qorzanis.ui.common.TrickSigilView;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import j0.C0196a;
import j2.InterfaceC0225g;
import q1.C0425b;

/* renamed from: x1.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0505g implements InterfaceC0225g, X1.f {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f5948b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ DropInFragment f5949c;

    public /* synthetic */ C0505g(DropInFragment dropInFragment, int i) {
        this.f5948b = i;
        this.f5949c = dropInFragment;
    }

    @Override // X1.f
    public final J1.a a() {
        switch (this.f5948b) {
            case 0:
                return new X1.a(this.f5949c, DropInFragment.class, "render", "render(Lcom/kortosi/kluani/qorzanis/ui/home/DropInState;)V");
            default:
                return new X1.a(this.f5949c, DropInFragment.class, "handle", "handle(Lcom/kortosi/kluani/qorzanis/ui/home/DropInEffect;)V");
        }
    }

    @Override // j2.InterfaceC0225g
    public final Object b(Object obj, N1.d dVar) {
        switch (this.f5948b) {
            case 0:
                t tVar = (t) obj;
                DropInFragment dropInFragment = this.f5949c;
                dropInFragment.getClass();
                if (X1.i.a(tVar, r.f5962a)) {
                    dropInFragment.P().f5281c.setVisibility(0);
                    dropInFragment.P().f5280b.setVisibility(8);
                } else {
                    if (!(tVar instanceof s)) {
                        throw new C0.c();
                    }
                    dropInFragment.P().f5281c.setVisibility(8);
                    dropInFragment.P().f5280b.setVisibility(0);
                    s sVar = (s) tVar;
                    dropInFragment.P().f5283f.setPips(sVar.f5967f);
                    dropInFragment.P().f5289m.setText(String.valueOf(sVar.f5963a));
                    dropInFragment.P().f5288l.setText(String.valueOf(sVar.f5964b));
                    dropInFragment.P().f5290n.setText(String.valueOf(sVar.f5965c));
                    TrickSigilView trickSigilView = dropInFragment.P().f5286j;
                    r1.j jVar = sVar.f5966d;
                    trickSigilView.a(jVar);
                    dropInFragment.P().i.setText(jVar.f5392b);
                    dropInFragment.P().f5285h.setText(dropInFragment.o(R.string.family_rung_line, dropInFragment.n(v1.f.b(jVar.f5393c)), Integer.valueOf(jVar.f5394d)));
                    C0425b c0425bP = dropInFragment.P();
                    int i = jVar.e;
                    c0425bP.f5287k.setText(i > 0 ? dropInFragment.o(R.string.spins_degrees, Integer.valueOf(i)) : dropInFragment.n(R.string.no_spin));
                    dropInFragment.P().f5284g.setOnClickListener(new ViewOnClickListenerC0504f(dropInFragment, jVar, 0));
                    x xVar = dropInFragment.f2855f0;
                    if (xVar == null) {
                        X1.i.g("rail");
                        throw null;
                    }
                    xVar.f4816d.b(sVar.e, new E.a(16, dropInFragment));
                }
                return J1.k.f632a;
            default:
                InterfaceC0502d interfaceC0502d = (InterfaceC0502d) obj;
                DropInFragment dropInFragment2 = this.f5949c;
                dropInFragment2.getClass();
                if (X1.i.a(interfaceC0502d, C0501c.f5942a)) {
                    v1.f.a(dropInFragment2, R.id.dropInFragment, new C0196a(R.id.action_dropIn_to_trickRoster));
                } else if (X1.i.a(interfaceC0502d, C0500b.f5941a)) {
                    v1.f.a(dropInFragment2, R.id.dropInFragment, new C0196a(R.id.action_dropIn_to_spotCheck));
                } else {
                    if (!(interfaceC0502d instanceof C0499a)) {
                        throw new C0.c();
                    }
                    v1.f.a(dropInFragment2, R.id.dropInFragment, new C0510l(((C0499a) interfaceC0502d).f5940a));
                }
                return J1.k.f632a;
        }
    }

    public final boolean equals(Object obj) {
        switch (this.f5948b) {
            case 0:
                if ((obj instanceof InterfaceC0225g) && (obj instanceof X1.f)) {
                    break;
                }
                break;
            default:
                if ((obj instanceof InterfaceC0225g) && (obj instanceof X1.f)) {
                    break;
                }
                break;
        }
        return a().equals(((X1.f) obj).a());
    }

    public final int hashCode() {
        switch (this.f5948b) {
        }
        return a().hashCode();
    }
}
