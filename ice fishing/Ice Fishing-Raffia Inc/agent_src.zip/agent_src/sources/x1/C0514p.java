package x1;

/* renamed from: x1.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0514p implements InterfaceC0515q {

    /* renamed from: a, reason: collision with root package name */
    public static final C0514p f5961a = new C0514p();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C0514p);
    }

    public final int hashCode() {
        return 418662231;
    }

    public final String toString() {
        return "OpenRoster";
    }
}
