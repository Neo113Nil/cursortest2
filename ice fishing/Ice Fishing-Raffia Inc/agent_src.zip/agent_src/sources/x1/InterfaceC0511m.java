package x1;

/* renamed from: x1.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0511m {
}
