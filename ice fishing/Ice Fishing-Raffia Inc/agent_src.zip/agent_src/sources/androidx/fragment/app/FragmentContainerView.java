package androidx.fragment.app;

import H.e;
import P.E;
import P.O;
import P.u0;
import X1.i;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import b0.AbstractC0083a;
import c0.AbstractComponentCallbacksC0110w;
import c0.C0089a;
import c0.C0112y;
import c0.H;
import c0.P;
import c0.X;
import c0.Y;
import com.kortosi.kluani.qorzanis.R;
import h.AbstractActivityC0180i;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f1736b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f1737c;

    /* renamed from: d, reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f1738d;
    public boolean e;

    public FragmentContainerView(Context context) {
        super(context);
        this.f1736b = new ArrayList();
        this.f1737c = new ArrayList();
        this.e = true;
    }

    public final void a(View view) {
        if (this.f1737c.contains(view)) {
            this.f1736b.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        i.e(view, "child");
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof AbstractComponentCallbacksC0110w ? (AbstractComponentCallbacksC0110w) tag : null) != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        u0 u0VarG;
        i.e(windowInsets, "insets");
        u0 u0VarG2 = u0.g(null, windowInsets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f1738d;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            i.d(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            u0VarG = u0.g(null, windowInsetsOnApplyWindowInsets);
        } else {
            WeakHashMap weakHashMap = O.f854a;
            WindowInsets windowInsetsF = u0VarG2.f();
            if (windowInsetsF != null) {
                WindowInsets windowInsetsB = E.b(this, windowInsetsF);
                if (!windowInsetsB.equals(windowInsetsF)) {
                    u0VarG2 = u0.g(this, windowInsetsB);
                }
            }
            u0VarG = u0VarG2;
        }
        if (!u0VarG.f943a.m()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                O.b(getChildAt(i), u0VarG);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        i.e(canvas, "canvas");
        if (this.e) {
            Iterator it = this.f1736b.iterator();
            while (it.hasNext()) {
                super.drawChild(canvas, (View) it.next(), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j3) {
        i.e(canvas, "canvas");
        i.e(view, "child");
        if (this.e) {
            ArrayList arrayList = this.f1736b;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j3);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        i.e(view, "view");
        this.f1737c.remove(view);
        if (this.f1736b.remove(view)) {
            this.e = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends AbstractComponentCallbacksC0110w> F getFragment() {
        AbstractActivityC0180i abstractActivityC0180i;
        AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w;
        P pI;
        View view = this;
        while (true) {
            abstractActivityC0180i = null;
            if (view == null) {
                abstractComponentCallbacksC0110w = null;
                break;
            }
            Object tag = view.getTag(R.id.fragment_container_view_tag);
            abstractComponentCallbacksC0110w = tag instanceof AbstractComponentCallbacksC0110w ? (AbstractComponentCallbacksC0110w) tag : null;
            if (abstractComponentCallbacksC0110w != null) {
                break;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        if (abstractComponentCallbacksC0110w == null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    break;
                }
                if (context instanceof AbstractActivityC0180i) {
                    abstractActivityC0180i = (AbstractActivityC0180i) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (abstractActivityC0180i == null) {
                throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
            }
            pI = ((C0112y) abstractActivityC0180i.f3357t.f224c).f2336f;
        } else {
            if (!abstractComponentCallbacksC0110w.s()) {
                throw new IllegalStateException("The Fragment " + abstractComponentCallbacksC0110w + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
            pI = abstractComponentCallbacksC0110w.i();
        }
        return (F) pI.D(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        i.e(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                i.d(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        i.e(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i) {
        View childAt = getChildAt(i);
        i.d(childAt, "view");
        a(childAt);
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        i.e(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i, int i3) {
        int i4 = i + i3;
        for (int i5 = i; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            i.d(childAt, "view");
            a(childAt);
        }
        super.removeViews(i, i3);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i, int i3) {
        int i4 = i + i3;
        for (int i5 = i; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            i.d(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i, i3);
    }

    public final void setDrawDisappearingViewsLast(boolean z2) {
        this.e = z2;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        this.f1738d = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        i.e(view, "view");
        if (view.getParent() == this) {
            this.f1737c.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        String str;
        super(context, attributeSet, 0);
        i.e(context, "context");
        this.f1736b = new ArrayList();
        this.f1737c = new ArrayList();
        this.e = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0083a.f2045b, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, P p2) {
        View view;
        super(context, attributeSet);
        i.e(context, "context");
        i.e(attributeSet, "attrs");
        i.e(p2, "fm");
        this.f1736b = new ArrayList();
        this.f1737c = new ArrayList();
        this.e = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0083a.f2045b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110wD = p2.D(id);
        if (classAttribute != null && abstractComponentCallbacksC0110wD == null) {
            if (id == -1) {
                throw new IllegalStateException(e.i("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ""));
            }
            H hI = p2.I();
            context.getClassLoader();
            AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110wA = hI.a(classAttribute);
            i.d(abstractComponentCallbacksC0110wA, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            abstractComponentCallbacksC0110wA.f2331z = id;
            abstractComponentCallbacksC0110wA.f2288A = id;
            abstractComponentCallbacksC0110wA.f2289B = string;
            abstractComponentCallbacksC0110wA.f2327v = p2;
            abstractComponentCallbacksC0110wA.f2328w = p2.f2134w;
            abstractComponentCallbacksC0110wA.E(context, attributeSet, null);
            C0089a c0089a = new C0089a(p2);
            c0089a.f2195p = true;
            abstractComponentCallbacksC0110wA.f2294H = this;
            abstractComponentCallbacksC0110wA.f2323r = true;
            c0089a.g(getId(), abstractComponentCallbacksC0110wA, string, 1);
            if (!c0089a.f2187g) {
                c0089a.f2188h = false;
                P p3 = c0089a.f2197r;
                if (p3.f2134w != null && !p3.f2108J) {
                    p3.z(true);
                    C0089a c0089a2 = p3.f2120h;
                    if (c0089a2 != null) {
                        c0089a2.f2198s = false;
                        c0089a2.d();
                        if (Log.isLoggable("FragmentManager", 3)) {
                            Log.d("FragmentManager", "Reversing mTransitioningOp " + p3.f2120h + " as part of execSingleAction for action " + c0089a);
                        }
                        p3.f2120h.f(false, false);
                        p3.f2120h.a(p3.f2109L, p3.f2110M);
                        Iterator it = p3.f2120h.f2182a.iterator();
                        while (it.hasNext()) {
                            AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w = ((Y) it.next()).f2171b;
                            if (abstractComponentCallbacksC0110w != null) {
                                abstractComponentCallbacksC0110w.f2319n = false;
                            }
                        }
                        p3.f2120h = null;
                    }
                    c0089a.a(p3.f2109L, p3.f2110M);
                    p3.f2115b = true;
                    try {
                        p3.W(p3.f2109L, p3.f2110M);
                        p3.d();
                        p3.h0();
                        p3.v();
                        ((HashMap) p3.f2116c.f271a).values().removeAll(Collections.singleton(null));
                    } catch (Throwable th) {
                        p3.d();
                        throw th;
                    }
                }
            } else {
                throw new IllegalStateException("This transaction is already being added to the back stack");
            }
        }
        Iterator it2 = p2.f2116c.h().iterator();
        while (it2.hasNext()) {
            X x2 = (X) it2.next();
            AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w2 = x2.f2168c;
            if (abstractComponentCallbacksC0110w2.f2288A == getId() && (view = abstractComponentCallbacksC0110w2.f2295I) != null && view.getParent() == null) {
                abstractComponentCallbacksC0110w2.f2294H = this;
                x2.b();
                x2.k();
            }
        }
    }
}
