package androidx.navigation.fragment;

import J1.i;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.FragmentContainerView;
import b1.e;
import c0.AbstractComponentCallbacksC0110w;
import c0.C0089a;
import com.kortosi.kluani.qorzanis.R;
import h.AbstractActivityC0180i;
import j0.C0204i;
import j0.F;
import j0.W;
import l0.p;

/* loaded from: classes.dex */
public class NavHostFragment extends AbstractComponentCallbacksC0110w {

    /* renamed from: Y, reason: collision with root package name */
    public final i f1846Y = new i(new C0204i(3, this));

    /* renamed from: Z, reason: collision with root package name */
    public View f1847Z;

    /* renamed from: a0, reason: collision with root package name */
    public int f1848a0;

    /* renamed from: b0, reason: collision with root package name */
    public boolean f1849b0;

    @Override // c0.AbstractComponentCallbacksC0110w
    public final View A(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        X1.i.e(layoutInflater, "inflater");
        Context context = layoutInflater.getContext();
        X1.i.d(context, "inflater.context");
        FragmentContainerView fragmentContainerView = new FragmentContainerView(context);
        int i = this.f2331z;
        if (i == 0 || i == -1) {
            i = R.id.nav_host_fragment_container;
        }
        fragmentContainerView.setId(i);
        return fragmentContainerView;
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void B() {
        this.f2293G = true;
        View view = this.f1847Z;
        if (view != null && e.u(view) == P()) {
            view.setTag(R.id.nav_controller_view_tag, null);
        }
        this.f1847Z = null;
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void E(Context context, AttributeSet attributeSet, Bundle bundle) {
        X1.i.e(context, "context");
        X1.i.e(attributeSet, "attrs");
        super.E(context, attributeSet, bundle);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, W.f3669b);
        X1.i.d(typedArrayObtainStyledAttributes, "context.obtainStyledAttr…tion.R.styleable.NavHost)");
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f1848a0 = resourceId;
        }
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, p.f4058c);
        X1.i.d(typedArrayObtainStyledAttributes2, "context.obtainStyledAttr…tyleable.NavHostFragment)");
        if (typedArrayObtainStyledAttributes2.getBoolean(0, false)) {
            this.f1849b0 = true;
        }
        typedArrayObtainStyledAttributes2.recycle();
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void F(Bundle bundle) {
        if (this.f1849b0) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void I(View view) {
        X1.i.e(view, "view");
        if (!(view instanceof ViewGroup)) {
            throw new IllegalStateException(("created host view " + view + " is not a ViewGroup").toString());
        }
        view.setTag(R.id.nav_controller_view_tag, P());
        if (view.getParent() != null) {
            Object parent = view.getParent();
            X1.i.c(parent, "null cannot be cast to non-null type android.view.View");
            View view2 = (View) parent;
            this.f1847Z = view2;
            if (view2.getId() == this.f2331z) {
                View view3 = this.f1847Z;
                X1.i.b(view3);
                view3.setTag(R.id.nav_controller_view_tag, P());
            }
        }
    }

    public final F P() {
        return (F) this.f1846Y.getValue();
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void y(AbstractActivityC0180i abstractActivityC0180i) {
        X1.i.e(abstractActivityC0180i, "context");
        super.y(abstractActivityC0180i);
        if (this.f1849b0) {
            C0089a c0089a = new C0089a(l());
            c0089a.i(this);
            c0089a.e();
        }
    }

    @Override // c0.AbstractComponentCallbacksC0110w
    public final void z(Bundle bundle) {
        P();
        if (bundle != null && bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
            this.f1849b0 = true;
            C0089a c0089a = new C0089a(l());
            c0089a.i(this);
            c0089a.e();
        }
        super.z(bundle);
    }
}
