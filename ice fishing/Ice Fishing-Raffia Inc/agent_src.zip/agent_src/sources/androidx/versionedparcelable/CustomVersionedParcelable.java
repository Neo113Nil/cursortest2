package androidx.versionedparcelable;

import G0.d;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements d {
}
