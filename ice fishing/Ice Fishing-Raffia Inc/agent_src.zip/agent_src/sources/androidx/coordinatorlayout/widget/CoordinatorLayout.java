package androidx.coordinatorlayout.widget;

import A0.f;
import B.a;
import C.b;
import C.d;
import C.e;
import C.g;
import C.i;
import C.j;
import C.k;
import C.l;
import O.c;
import P.C0028p;
import P.E;
import P.G;
import P.InterfaceC0026n;
import P.InterfaceC0027o;
import P.O;
import P.u0;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.kortosi.kluani.qorzanis.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.WeakHashMap;
import s.C0439j;

/* loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements InterfaceC0026n, InterfaceC0027o {

    /* renamed from: u, reason: collision with root package name */
    public static final String f1641u;

    /* renamed from: v, reason: collision with root package name */
    public static final Class[] f1642v;

    /* renamed from: w, reason: collision with root package name */
    public static final ThreadLocal f1643w;

    /* renamed from: x, reason: collision with root package name */
    public static final j f1644x;

    /* renamed from: y, reason: collision with root package name */
    public static final c f1645y;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f1646b;

    /* renamed from: c, reason: collision with root package name */
    public final k f1647c;

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList f1648d;
    public final ArrayList e;

    /* renamed from: f, reason: collision with root package name */
    public final int[] f1649f;

    /* renamed from: g, reason: collision with root package name */
    public final int[] f1650g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1651h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final int[] f1652j;

    /* renamed from: k, reason: collision with root package name */
    public View f1653k;

    /* renamed from: l, reason: collision with root package name */
    public View f1654l;

    /* renamed from: m, reason: collision with root package name */
    public g f1655m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f1656n;

    /* renamed from: o, reason: collision with root package name */
    public u0 f1657o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f1658p;

    /* renamed from: q, reason: collision with root package name */
    public Drawable f1659q;

    /* renamed from: r, reason: collision with root package name */
    public ViewGroup.OnHierarchyChangeListener f1660r;

    /* renamed from: s, reason: collision with root package name */
    public f f1661s;

    /* renamed from: t, reason: collision with root package name */
    public final C0028p f1662t;

    static {
        Package r02 = CoordinatorLayout.class.getPackage();
        f1641u = r02 != null ? r02.getName() : null;
        f1644x = new j(0);
        f1642v = new Class[]{Context.class, AttributeSet.class};
        f1643w = new ThreadLocal();
        f1645y = new c();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CoordinatorLayout(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        this.f1646b = new ArrayList();
        this.f1647c = new k(0);
        this.f1648d = new ArrayList();
        this.e = new ArrayList();
        this.f1649f = new int[2];
        this.f1650g = new int[2];
        this.f1662t = new C0028p();
        int[] iArr = a.f246a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, R.attr.coordinatorLayoutStyle, 0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f1652j = intArray;
            float f3 = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i = 0; i < length; i++) {
                this.f1652j[i] = (int) (r3[i] * f3);
            }
        }
        this.f1659q = typedArrayObtainStyledAttributes.getDrawable(1);
        typedArrayObtainStyledAttributes.recycle();
        x();
        super.setOnHierarchyChangeListener(new e(this));
        WeakHashMap weakHashMap = O.f854a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    public static Rect g() {
        Rect rect = (Rect) f1645y.a();
        return rect == null ? new Rect() : rect;
    }

    public static void l(int i, Rect rect, Rect rect2, C.f fVar, int i3, int i4) {
        int i5 = fVar.f255c;
        if (i5 == 0) {
            i5 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i5, i);
        int i6 = fVar.f256d;
        if ((i6 & 7) == 0) {
            i6 |= 8388611;
        }
        if ((i6 & 112) == 0) {
            i6 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i6, i);
        int i7 = absoluteGravity & 7;
        int i8 = absoluteGravity & 112;
        int i9 = absoluteGravity2 & 7;
        int i10 = absoluteGravity2 & 112;
        int iWidth = i9 != 1 ? i9 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int iHeight = i10 != 16 ? i10 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i7 == 1) {
            iWidth -= i3 / 2;
        } else if (i7 != 5) {
            iWidth -= i3;
        }
        if (i8 == 16) {
            iHeight -= i4 / 2;
        } else if (i8 != 80) {
            iHeight -= i4;
        }
        rect2.set(iWidth, iHeight, i3 + iWidth, i4 + iHeight);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static C.f n(View view) {
        C.f fVar = (C.f) view.getLayoutParams();
        if (!fVar.f254b) {
            if (view instanceof b) {
                C.c behavior = ((b) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                C.c cVar = fVar.f253a;
                if (cVar != behavior) {
                    if (cVar != null) {
                        cVar.j();
                    }
                    fVar.f253a = behavior;
                    fVar.f254b = true;
                    if (behavior != null) {
                        behavior.g(fVar);
                    }
                }
                fVar.f254b = true;
            } else {
                d dVar = null;
                for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                    dVar = (d) superclass.getAnnotation(d.class);
                    if (dVar != null) {
                        break;
                    }
                }
                if (dVar != null) {
                    try {
                        C.c cVar2 = (C.c) dVar.value().getDeclaredConstructor(null).newInstance(null);
                        C.c cVar3 = fVar.f253a;
                        if (cVar3 != cVar2) {
                            if (cVar3 != null) {
                                cVar3.j();
                            }
                            fVar.f253a = cVar2;
                            fVar.f254b = true;
                            if (cVar2 != null) {
                                cVar2.g(fVar);
                            }
                        }
                    } catch (Exception e) {
                        Log.e("CoordinatorLayout", "Default behavior class " + dVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e);
                    }
                }
                fVar.f254b = true;
            }
        }
        return fVar;
    }

    public static void v(View view, int i) {
        C.f fVar = (C.f) view.getLayoutParams();
        int i3 = fVar.i;
        if (i3 != i) {
            WeakHashMap weakHashMap = O.f854a;
            view.offsetLeftAndRight(i - i3);
            fVar.i = i;
        }
    }

    public static void w(View view, int i) {
        C.f fVar = (C.f) view.getLayoutParams();
        int i3 = fVar.f260j;
        if (i3 != i) {
            WeakHashMap weakHashMap = O.f854a;
            view.offsetTopAndBottom(i - i3);
            fVar.f260j = i;
        }
    }

    @Override // P.InterfaceC0026n
    public final void a(View view, View view2, int i, int i3) {
        C0028p c0028p = this.f1662t;
        if (i3 == 1) {
            c0028p.f934b = i;
        } else {
            c0028p.f933a = i;
        }
        this.f1654l = view2;
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            ((C.f) getChildAt(i4).getLayoutParams()).getClass();
        }
    }

    @Override // P.InterfaceC0027o
    public final void b(View view, int i, int i3, int i4, int i5, int i6, int[] iArr) {
        C.c cVar;
        int childCount = getChildCount();
        boolean z2 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                C.f fVar = (C.f) childAt.getLayoutParams();
                if (fVar.a(i6) && (cVar = fVar.f253a) != null) {
                    int[] iArr2 = this.f1649f;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.p(this, childAt, i3, i4, i5, iArr2);
                    iMax = i4 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i5 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z2 = true;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + iMax2;
        if (z2) {
            p(1);
        }
    }

    @Override // P.InterfaceC0026n
    public final void c(View view, int i, int i3, int i4, int i5, int i6) {
        b(view, i, i3, i4, i5, 0, this.f1650g);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C.f) && super.checkLayoutParams(layoutParams);
    }

    @Override // P.InterfaceC0026n
    public final void d(View view, int i) {
        C0028p c0028p = this.f1662t;
        if (i == 1) {
            c0028p.f934b = 0;
        } else {
            c0028p.f933a = 0;
        }
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            C.f fVar = (C.f) childAt.getLayoutParams();
            if (fVar.a(i)) {
                C.c cVar = fVar.f253a;
                if (cVar != null) {
                    cVar.u(this, childAt, view, i);
                }
                if (i == 0) {
                    fVar.f263m = false;
                } else if (i == 1) {
                    fVar.f264n = false;
                }
                fVar.f265o = false;
            }
        }
        this.f1654l = null;
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j3) {
        C.c cVar = ((C.f) view.getLayoutParams()).f253a;
        if (cVar != null) {
            cVar.getClass();
        }
        return super.drawChild(canvas, view, j3);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1659q;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // P.InterfaceC0026n
    public final void e(View view, int i, int i3, int[] iArr, int i4) {
        C.c cVar;
        int childCount = getChildCount();
        boolean z2 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                C.f fVar = (C.f) childAt.getLayoutParams();
                if (fVar.a(i4) && (cVar = fVar.f253a) != null) {
                    int[] iArr2 = this.f1649f;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.o(this, childAt, view, i, i3, iArr2, i4);
                    iMax = i > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i3 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z2 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z2) {
            p(1);
        }
    }

    @Override // P.InterfaceC0026n
    public final boolean f(View view, View view2, int i, int i3) {
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                C.f fVar = (C.f) childAt.getLayoutParams();
                C.c cVar = fVar.f253a;
                if (cVar != null) {
                    boolean zT = cVar.t(this, childAt, view, i, i3);
                    z2 |= zT;
                    if (i3 == 0) {
                        fVar.f263m = zT;
                    } else if (i3 == 1) {
                        fVar.f264n = zT;
                    }
                } else if (i3 == 0) {
                    fVar.f263m = false;
                } else if (i3 == 1) {
                    fVar.f264n = false;
                }
            }
        }
        return z2;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C.f();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C.f(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        t();
        return Collections.unmodifiableList(this.f1646b);
    }

    public final u0 getLastWindowInsets() {
        return this.f1657o;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0028p c0028p = this.f1662t;
        return c0028p.f934b | c0028p.f933a;
    }

    public Drawable getStatusBarBackground() {
        return this.f1659q;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(C.f fVar, Rect rect, int i, int i3) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - ((ViewGroup.MarginLayoutParams) fVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i3) - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin));
        rect.set(iMax, iMax2, i + iMax, i3 + iMax2);
    }

    public final void i(View view, Rect rect, boolean z2) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z2) {
            k(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList j(View view) {
        C0439j c0439j = (C0439j) this.f1647c.f272b;
        int i = c0439j.f5433d;
        ArrayList arrayList = null;
        for (int i3 = 0; i3 < i; i3++) {
            ArrayList arrayList2 = (ArrayList) c0439j.i(i3);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(c0439j.f(i3));
            }
        }
        ArrayList arrayList3 = this.e;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void k(View view, Rect rect) {
        ThreadLocal threadLocal = l.f275a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = l.f275a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        l.a(this, view, matrix);
        ThreadLocal threadLocal3 = l.f276b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int m(int i) {
        int[] iArr = this.f1652j;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i);
            return 0;
        }
        if (i >= 0 && i < iArr.length) {
            return iArr[i];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i + " out of range for " + this);
        return 0;
    }

    public final boolean o(View view, int i, int i3) {
        c cVar = f1645y;
        Rect rectG = g();
        k(view, rectG);
        try {
            return rectG.contains(i, i3);
        } finally {
            rectG.setEmpty();
            cVar.c(rectG);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        u(false);
        if (this.f1656n) {
            if (this.f1655m == null) {
                this.f1655m = new g(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f1655m);
        }
        if (this.f1657o == null) {
            WeakHashMap weakHashMap = O.f854a;
            if (getFitsSystemWindows()) {
                E.c(this);
            }
        }
        this.i = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        u(false);
        if (this.f1656n && this.f1655m != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f1655m);
        }
        View view = this.f1654l;
        if (view != null) {
            d(view, 0);
        }
        this.i = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f1658p || this.f1659q == null) {
            return;
        }
        u0 u0Var = this.f1657o;
        int iD = u0Var != null ? u0Var.d() : 0;
        if (iD > 0) {
            this.f1659q.setBounds(0, 0, getWidth(), iD);
            this.f1659q.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            u(true);
        }
        boolean zS = s(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            u(true);
        }
        return zS;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        C.c cVar;
        WeakHashMap weakHashMap = O.f854a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList = this.f1646b;
        int size = arrayList.size();
        for (int i6 = 0; i6 < size; i6++) {
            View view = (View) arrayList.get(i6);
            if (view.getVisibility() != 8 && ((cVar = ((C.f) view.getLayoutParams()).f253a) == null || !cVar.l(this, view, layoutDirection))) {
                q(view, layoutDirection);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:72:0x0159  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x0189  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i3) {
        boolean z2;
        int i4;
        int i5;
        int i6;
        int i7;
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        C.c cVar;
        int i8;
        ArrayList arrayList;
        int i9;
        boolean z3;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        boolean z4;
        int iMax;
        t();
        int childCount = getChildCount();
        int i16 = 0;
        loop0: while (true) {
            if (i16 >= childCount) {
                z2 = false;
                break;
            }
            View childAt = getChildAt(i16);
            C0439j c0439j = (C0439j) this.f1647c.f272b;
            int i17 = c0439j.f5433d;
            for (int i18 = 0; i18 < i17; i18++) {
                ArrayList arrayList2 = (ArrayList) c0439j.i(i18);
                if (arrayList2 != null && arrayList2.contains(childAt)) {
                    z2 = true;
                    break loop0;
                }
            }
            i16++;
        }
        if (z2 != this.f1656n) {
            if (z2) {
                if (this.i) {
                    if (this.f1655m == null) {
                        this.f1655m = new g(this);
                    }
                    getViewTreeObserver().addOnPreDrawListener(this.f1655m);
                }
                this.f1656n = true;
            } else {
                if (this.i && this.f1655m != null) {
                    getViewTreeObserver().removeOnPreDrawListener(this.f1655m);
                }
                this.f1656n = false;
            }
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        WeakHashMap weakHashMap = O.f854a;
        int layoutDirection = getLayoutDirection();
        boolean z5 = layoutDirection == 1;
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        int i19 = paddingLeft + paddingRight;
        int i20 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = getSuggestedMinimumWidth();
        int suggestedMinimumHeight = getSuggestedMinimumHeight();
        boolean z6 = this.f1657o != null && getFitsSystemWindows();
        ArrayList arrayList3 = this.f1646b;
        int size3 = arrayList3.size();
        int i21 = suggestedMinimumWidth;
        int i22 = suggestedMinimumHeight;
        int iCombineMeasuredStates = 0;
        int i23 = 0;
        while (i23 < size3) {
            View view = (View) arrayList3.get(i23);
            if (view.getVisibility() == 8) {
                i13 = i23;
                i8 = size3;
                arrayList = arrayList3;
                i11 = paddingLeft;
                i14 = paddingRight;
                i9 = layoutDirection;
                z4 = true;
                z3 = false;
            } else {
                C.f fVar = (C.f) view.getLayoutParams();
                int i24 = fVar.e;
                if (i24 < 0 || mode == 0) {
                    i4 = iCombineMeasuredStates;
                    i5 = i23;
                } else {
                    int iM = m(i24);
                    i4 = iCombineMeasuredStates;
                    int i25 = fVar.f255c;
                    if (i25 == 0) {
                        i25 = 8388661;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i25, layoutDirection) & 7;
                    i5 = i23;
                    if ((absoluteGravity == 3 && !z5) || (absoluteGravity == 5 && z5)) {
                        iMax = Math.max(0, (size - paddingRight) - iM);
                    } else if ((absoluteGravity == 5 && !z5) || (absoluteGravity == 3 && z5)) {
                        iMax = Math.max(0, iM - paddingLeft);
                    }
                    i6 = iMax;
                    if (z6 || view.getFitsSystemWindows()) {
                        i7 = i22;
                        iMakeMeasureSpec = i;
                        iMakeMeasureSpec2 = i3;
                    } else {
                        int iC = this.f1657o.c() + this.f1657o.b();
                        i7 = i22;
                        int iA = this.f1657o.a() + this.f1657o.d();
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size - iC, mode);
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(size2 - iA, mode2);
                    }
                    cVar = fVar.f253a;
                    if (cVar == null) {
                        int i26 = i4;
                        i13 = i5;
                        z3 = false;
                        i11 = paddingLeft;
                        i12 = i26;
                        int i27 = i7;
                        i14 = paddingRight;
                        i15 = i27;
                        i9 = layoutDirection;
                        i10 = i21;
                        i8 = size3;
                        arrayList = arrayList3;
                        if (!cVar.m(this, view, iMakeMeasureSpec, i6, iMakeMeasureSpec2)) {
                        }
                        int iMax2 = Math.max(i10, view.getMeasuredWidth() + i19 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                        int iMax3 = Math.max(i15, view.getMeasuredHeight() + i20 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                        i21 = iMax2;
                        iCombineMeasuredStates = View.combineMeasuredStates(i12, view.getMeasuredState());
                        i22 = iMax3;
                        z4 = true;
                    } else {
                        i8 = size3;
                        arrayList = arrayList3;
                        i9 = layoutDirection;
                        z3 = false;
                        i10 = i21;
                        int i28 = i5;
                        i11 = paddingLeft;
                        i12 = i4;
                        i13 = i28;
                        int i29 = i7;
                        i14 = paddingRight;
                        i15 = i29;
                    }
                    measureChildWithMargins(view, iMakeMeasureSpec, i6, iMakeMeasureSpec2, 0);
                    int iMax22 = Math.max(i10, view.getMeasuredWidth() + i19 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                    int iMax32 = Math.max(i15, view.getMeasuredHeight() + i20 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                    i21 = iMax22;
                    iCombineMeasuredStates = View.combineMeasuredStates(i12, view.getMeasuredState());
                    i22 = iMax32;
                    z4 = true;
                }
                i6 = 0;
                if (z6) {
                    i7 = i22;
                    iMakeMeasureSpec = i;
                    iMakeMeasureSpec2 = i3;
                    cVar = fVar.f253a;
                    if (cVar == null) {
                    }
                    measureChildWithMargins(view, iMakeMeasureSpec, i6, iMakeMeasureSpec2, 0);
                    int iMax222 = Math.max(i10, view.getMeasuredWidth() + i19 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                    int iMax322 = Math.max(i15, view.getMeasuredHeight() + i20 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                    i21 = iMax222;
                    iCombineMeasuredStates = View.combineMeasuredStates(i12, view.getMeasuredState());
                    i22 = iMax322;
                    z4 = true;
                }
            }
            i23 = i13 + 1;
            paddingLeft = i11;
            paddingRight = i14;
            layoutDirection = i9;
            size3 = i8;
            arrayList3 = arrayList;
        }
        int i30 = iCombineMeasuredStates;
        setMeasuredDimension(View.resolveSizeAndState(i21, i, (-16777216) & i30), View.resolveSizeAndState(i22, i3, i30 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f3, float f4, boolean z2) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C.f fVar = (C.f) childAt.getLayoutParams();
                if (fVar.a(0)) {
                    C.c cVar = fVar.f253a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f3, float f4) {
        C.c cVar;
        int childCount = getChildCount();
        boolean zN = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C.f fVar = (C.f) childAt.getLayoutParams();
                if (fVar.a(0) && (cVar = fVar.f253a) != null) {
                    zN |= cVar.n(view);
                }
            }
        }
        return zN;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i3, int[] iArr) {
        e(view, i, i3, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i3, int i4, int i5) {
        c(view, i, i3, i4, i5, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        a(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i iVar = (i) parcelable;
        super.onRestoreInstanceState(iVar.f1144b);
        SparseArray sparseArray = iVar.f269d;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C.c cVar = n(childAt).f253a;
            if (id != -1 && cVar != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                cVar.r(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableS;
        i iVar = new i(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C.c cVar = ((C.f) childAt.getLayoutParams()).f253a;
            if (id != -1 && cVar != null && (parcelableS = cVar.s(childAt)) != null) {
                sparseArray.append(id, parcelableS);
            }
        }
        iVar.f269d = sparseArray;
        return iVar;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return f(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        d(view, 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x002f  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015 A[PHI: r3
      0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:10:0x0022, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zS;
        boolean zV;
        MotionEvent motionEventObtain;
        int actionMasked = motionEvent.getActionMasked();
        if (this.f1653k == null) {
            zS = s(motionEvent, 1);
            if (!zS) {
                zV = false;
            }
            motionEventObtain = null;
            if (this.f1653k != null) {
                zV |= super.onTouchEvent(motionEvent);
            } else if (zS) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEventObtain);
            }
            if (motionEventObtain != null) {
                motionEventObtain.recycle();
            }
            if (actionMasked != 1 || actionMasked == 3) {
                u(false);
            }
            return zV;
        }
        zS = false;
        C.c cVar = ((C.f) this.f1653k.getLayoutParams()).f253a;
        if (cVar != null) {
            zV = cVar.v(this, this.f1653k, motionEvent);
        }
        motionEventObtain = null;
        if (this.f1653k != null) {
        }
        if (motionEventObtain != null) {
        }
        if (actionMasked != 1) {
            u(false);
        }
        return zV;
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x029b  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x02a7  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x02d8  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x0044 A[EDGE_INSN: B:146:0x0044->B:10:0x0044 BREAK  A[LOOP:2: B:122:0x02d4->B:139:0x030d], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00e5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void p(int i) {
        int i3;
        Rect rect;
        int i4;
        Rect rect2;
        boolean z2;
        int i5;
        Rect rect3;
        int i6;
        ArrayList arrayList;
        int i7;
        boolean zH;
        boolean z3;
        boolean z4;
        int width;
        int i8;
        int i9;
        int i10;
        int height;
        int i11;
        int i12;
        int i13;
        C.f fVar;
        int i14;
        c cVar;
        int i15;
        Rect rect4;
        Rect rect5;
        Rect rect6;
        ArrayList arrayList2;
        int i16;
        C.c cVar2;
        int i17 = i;
        WeakHashMap weakHashMap = O.f854a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList3 = this.f1646b;
        int size = arrayList3.size();
        Rect rectG = g();
        Rect rectG2 = g();
        Rect rectG3 = g();
        int i18 = 0;
        while (true) {
            c cVar3 = f1645y;
            if (i18 >= size) {
                Rect rect7 = rectG3;
                Rect rect8 = rectG2;
                Rect rect9 = rectG;
                rect9.setEmpty();
                cVar3.c(rect9);
                rect8.setEmpty();
                cVar3.c(rect8);
                rect7.setEmpty();
                cVar3.c(rect7);
                return;
            }
            View view = (View) arrayList3.get(i18);
            C.f fVar2 = (C.f) view.getLayoutParams();
            if (i17 == 0 && view.getVisibility() == 8) {
                i5 = i17;
                i4 = layoutDirection;
                i3 = i18;
                rect3 = rectG3;
                rect = rectG2;
                rect2 = rectG;
                arrayList = arrayList3;
            } else {
                int i19 = 0;
                while (i19 < i18) {
                    if (fVar2.f262l == ((View) arrayList3.get(i19))) {
                        C.f fVar3 = (C.f) view.getLayoutParams();
                        if (fVar3.f261k != null) {
                            Rect rectG4 = g();
                            Rect rectG5 = g();
                            arrayList2 = arrayList3;
                            Rect rectG6 = g();
                            k(fVar3.f261k, rectG4);
                            i(view, rectG5, false);
                            i16 = size;
                            int measuredWidth = view.getMeasuredWidth();
                            int measuredHeight = view.getMeasuredHeight();
                            fVar = fVar2;
                            cVar = cVar3;
                            i15 = i18;
                            i14 = layoutDirection;
                            rect4 = rectG3;
                            rect5 = rectG2;
                            rect6 = rectG;
                            l(layoutDirection, rectG4, rectG6, fVar3, measuredWidth, measuredHeight);
                            boolean z5 = (rectG6.left == rectG5.left && rectG6.top == rectG5.top) ? false : true;
                            h(fVar3, rectG6, measuredWidth, measuredHeight);
                            int i20 = rectG6.left - rectG5.left;
                            int i21 = rectG6.top - rectG5.top;
                            if (i20 != 0) {
                                WeakHashMap weakHashMap2 = O.f854a;
                                view.offsetLeftAndRight(i20);
                            }
                            if (i21 != 0) {
                                WeakHashMap weakHashMap3 = O.f854a;
                                view.offsetTopAndBottom(i21);
                            }
                            if (z5 && (cVar2 = fVar3.f253a) != null) {
                                cVar2.h(this, view, fVar3.f261k);
                            }
                            rectG4.setEmpty();
                            cVar.c(rectG4);
                            rectG5.setEmpty();
                            cVar.c(rectG5);
                            rectG6.setEmpty();
                            cVar.c(rectG6);
                        } else {
                            fVar = fVar2;
                            i14 = layoutDirection;
                            cVar = cVar3;
                            i15 = i18;
                            rect4 = rectG3;
                            rect5 = rectG2;
                            rect6 = rectG;
                            arrayList2 = arrayList3;
                            i16 = size;
                        }
                    }
                    i19++;
                    cVar3 = cVar;
                    size = i16;
                    arrayList3 = arrayList2;
                    layoutDirection = i14;
                    fVar2 = fVar;
                    i18 = i15;
                    rectG3 = rect4;
                    rectG2 = rect5;
                    rectG = rect6;
                }
                C.f fVar4 = fVar2;
                int i22 = layoutDirection;
                c cVar4 = cVar3;
                i3 = i18;
                Rect rect10 = rectG3;
                rect = rectG2;
                Rect rect11 = rectG;
                ArrayList arrayList4 = arrayList3;
                int i23 = size;
                i(view, rect, true);
                if (fVar4.f258g == 0 || rect.isEmpty()) {
                    i4 = i22;
                    rect2 = rect11;
                } else {
                    i4 = i22;
                    int absoluteGravity = Gravity.getAbsoluteGravity(fVar4.f258g, i4);
                    int i24 = absoluteGravity & 112;
                    if (i24 == 48) {
                        rect2 = rect11;
                        rect2.top = Math.max(rect2.top, rect.bottom);
                    } else if (i24 != 80) {
                        rect2 = rect11;
                    } else {
                        rect2 = rect11;
                        rect2.bottom = Math.max(rect2.bottom, getHeight() - rect.top);
                    }
                    int i25 = absoluteGravity & 7;
                    if (i25 == 3) {
                        rect2.left = Math.max(rect2.left, rect.right);
                    } else if (i25 == 5) {
                        rect2.right = Math.max(rect2.right, getWidth() - rect.left);
                    }
                }
                if (fVar4.f259h == 0 || view.getVisibility() != 0) {
                    z2 = false;
                    i5 = i;
                    if (i5 != 2) {
                        rect3 = rect10;
                        rect3.set(((C.f) view.getLayoutParams()).f266p);
                        if (rect3.equals(rect)) {
                            size = i23;
                            arrayList = arrayList4;
                        } else {
                            ((C.f) view.getLayoutParams()).f266p.set(rect);
                        }
                    } else {
                        rect3 = rect10;
                    }
                    i6 = i3 + 1;
                    size = i23;
                    while (true) {
                        arrayList = arrayList4;
                        if (i6 >= size) {
                            break;
                        }
                        View view2 = (View) arrayList.get(i6);
                        C.f fVar5 = (C.f) view2.getLayoutParams();
                        C.c cVar5 = fVar5.f253a;
                        if (cVar5 == null || !cVar5.f(view2, view)) {
                            i7 = 1;
                        } else if (i5 == 0 && fVar5.f265o) {
                            fVar5.f265o = z2;
                            i7 = 1;
                        } else {
                            if (i5 != 2) {
                                zH = cVar5.h(this, view2, view);
                            } else {
                                cVar5.i(this, view);
                                zH = true;
                            }
                            i7 = 1;
                            if (i5 == 1) {
                                fVar5.f265o = zH;
                            }
                        }
                        i6 += i7;
                        arrayList4 = arrayList;
                    }
                } else {
                    WeakHashMap weakHashMap4 = O.f854a;
                    if (view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                        C.f fVar6 = (C.f) view.getLayoutParams();
                        C.c cVar6 = fVar6.f253a;
                        Rect rectG7 = g();
                        Rect rectG8 = g();
                        rectG8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                        if (cVar6 == null || !cVar6.e(view)) {
                            rectG7.set(rectG8);
                        } else if (!rectG8.contains(rectG7)) {
                            throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rectG7.toShortString() + " | Bounds:" + rectG8.toShortString());
                        }
                        rectG8.setEmpty();
                        cVar4.c(rectG8);
                        if (rectG7.isEmpty()) {
                            rectG7.setEmpty();
                            cVar4.c(rectG7);
                            z2 = false;
                            i5 = i;
                            if (i5 != 2) {
                            }
                            i6 = i3 + 1;
                            size = i23;
                            while (true) {
                                arrayList = arrayList4;
                                if (i6 >= size) {
                                }
                                i6 += i7;
                                arrayList4 = arrayList;
                            }
                        } else {
                            int absoluteGravity2 = Gravity.getAbsoluteGravity(fVar6.f259h, i4);
                            if ((absoluteGravity2 & 48) != 48 || (i12 = (rectG7.top - ((ViewGroup.MarginLayoutParams) fVar6).topMargin) - fVar6.f260j) >= (i13 = rect2.top)) {
                                z3 = false;
                            } else {
                                w(view, i13 - i12);
                                z3 = true;
                            }
                            if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - rectG7.bottom) - ((ViewGroup.MarginLayoutParams) fVar6).bottomMargin) + fVar6.f260j) < (i11 = rect2.bottom)) {
                                w(view, height - i11);
                                z3 = true;
                            }
                            if (z3) {
                                z2 = false;
                            } else {
                                z2 = false;
                                w(view, 0);
                            }
                            if ((absoluteGravity2 & 3) != 3 || (i9 = (rectG7.left - ((ViewGroup.MarginLayoutParams) fVar6).leftMargin) - fVar6.i) >= (i10 = rect2.left)) {
                                z4 = z2 ? 1 : 0;
                            } else {
                                v(view, i10 - i9);
                                z4 = true;
                            }
                            if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - rectG7.right) - ((ViewGroup.MarginLayoutParams) fVar6).rightMargin) + fVar6.i) < (i8 = rect2.right)) {
                                v(view, width - i8);
                                z4 = true;
                            }
                            if (!z4) {
                                v(view, z2 ? 1 : 0);
                            }
                            rectG7.setEmpty();
                            cVar4.c(rectG7);
                            i5 = i;
                            if (i5 != 2) {
                            }
                            i6 = i3 + 1;
                            size = i23;
                            while (true) {
                                arrayList = arrayList4;
                                if (i6 >= size) {
                                }
                                i6 += i7;
                                arrayList4 = arrayList;
                            }
                        }
                    }
                }
            }
            i18 = i3 + 1;
            arrayList3 = arrayList;
            rectG2 = rect;
            i17 = i5;
            rectG = rect2;
            rectG3 = rect3;
            layoutDirection = i4;
        }
    }

    public final void q(View view, int i) {
        Rect rectG;
        Rect rectG2;
        C.f fVar = (C.f) view.getLayoutParams();
        View view2 = fVar.f261k;
        if (view2 == null && fVar.f257f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        c cVar = f1645y;
        if (view2 != null) {
            rectG = g();
            rectG2 = g();
            try {
                k(view2, rectG);
                C.f fVar2 = (C.f) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                l(i, rectG, rectG2, fVar2, measuredWidth, measuredHeight);
                h(fVar2, rectG2, measuredWidth, measuredHeight);
                view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
                return;
            } finally {
                rectG.setEmpty();
                cVar.c(rectG);
                rectG2.setEmpty();
                cVar.c(rectG2);
            }
        }
        int i3 = fVar.e;
        if (i3 < 0) {
            C.f fVar3 = (C.f) view.getLayoutParams();
            rectG = g();
            rectG.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar3).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar3).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) fVar3).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) fVar3).bottomMargin);
            if (this.f1657o != null) {
                WeakHashMap weakHashMap = O.f854a;
                if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                    rectG.left = this.f1657o.b() + rectG.left;
                    rectG.top = this.f1657o.d() + rectG.top;
                    rectG.right -= this.f1657o.c();
                    rectG.bottom -= this.f1657o.a();
                }
            }
            rectG2 = g();
            int i4 = fVar3.f255c;
            if ((i4 & 7) == 0) {
                i4 |= 8388611;
            }
            if ((i4 & 112) == 0) {
                i4 |= 48;
            }
            Gravity.apply(i4, view.getMeasuredWidth(), view.getMeasuredHeight(), rectG, rectG2, i);
            view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
            return;
        }
        C.f fVar4 = (C.f) view.getLayoutParams();
        int i5 = fVar4.f255c;
        if (i5 == 0) {
            i5 = 8388661;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i5, i);
        int i6 = absoluteGravity & 7;
        int i7 = absoluteGravity & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth2 = view.getMeasuredWidth();
        int measuredHeight2 = view.getMeasuredHeight();
        if (i == 1) {
            i3 = width - i3;
        }
        int iM = m(i3) - measuredWidth2;
        if (i6 == 1) {
            iM += measuredWidth2 / 2;
        } else if (i6 == 5) {
            iM += measuredWidth2;
        }
        int i8 = i7 != 16 ? i7 != 80 ? 0 : measuredHeight2 : measuredHeight2 / 2;
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar4).leftMargin, Math.min(iM, ((width - getPaddingRight()) - measuredWidth2) - ((ViewGroup.MarginLayoutParams) fVar4).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar4).topMargin, Math.min(i8, ((height - getPaddingBottom()) - measuredHeight2) - ((ViewGroup.MarginLayoutParams) fVar4).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth2 + iMax, measuredHeight2 + iMax2);
    }

    public final void r(View view, int i, int i3, int i4) {
        measureChildWithMargins(view, i, i3, i4, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        C.c cVar = ((C.f) view.getLayoutParams()).f253a;
        if (cVar == null || !cVar.q(this, view, rect, z2)) {
            return super.requestChildRectangleOnScreen(view, rect, z2);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        super.requestDisallowInterceptTouchEvent(z2);
        if (!z2 || this.f1651h) {
            return;
        }
        u(false);
        this.f1651h = true;
    }

    public final boolean s(MotionEvent motionEvent, int i) {
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f1648d;
        arrayList.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            arrayList.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i3) : i3));
        }
        j jVar = f1644x;
        if (jVar != null) {
            Collections.sort(arrayList, jVar);
        }
        int size = arrayList.size();
        MotionEvent motionEventObtain = null;
        boolean zK = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = (View) arrayList.get(i4);
            C.c cVar = ((C.f) view.getLayoutParams()).f253a;
            if (zK && actionMasked != 0) {
                if (cVar != null) {
                    if (motionEventObtain == null) {
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    }
                    if (i == 0) {
                        cVar.k(this, view, motionEventObtain);
                    } else if (i == 1) {
                        cVar.v(this, view, motionEventObtain);
                    }
                }
            } else if (!zK && cVar != null) {
                if (i == 0) {
                    zK = cVar.k(this, view, motionEvent);
                } else if (i == 1) {
                    zK = cVar.v(this, view, motionEvent);
                }
                if (zK) {
                    this.f1653k = view;
                }
            }
        }
        arrayList.clear();
        return zK;
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z2) {
        super.setFitsSystemWindows(z2);
        x();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f1660r = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f1659q;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f1659q = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f1659q.setState(getDrawableState());
                }
                Drawable drawable3 = this.f1659q;
                WeakHashMap weakHashMap = O.f854a;
                drawable3.setLayoutDirection(getLayoutDirection());
                this.f1659q.setVisible(getVisibility() == 0, false);
                this.f1659q.setCallback(this);
            }
            WeakHashMap weakHashMap2 = O.f854a;
            postInvalidateOnAnimation();
        }
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        setStatusBarBackground(i != 0 ? getContext().getDrawable(i) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z2 = i == 0;
        Drawable drawable = this.f1659q;
        if (drawable == null || drawable.isVisible() == z2) {
            return;
        }
        this.f1659q.setVisible(z2, false);
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0106  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void t() {
        O.b bVar;
        View viewFindViewById;
        C.c cVar;
        ArrayList arrayList = this.f1646b;
        arrayList.clear();
        k kVar = this.f1647c;
        C0439j c0439j = (C0439j) kVar.f272b;
        int i = c0439j.f5433d;
        int i3 = 0;
        while (true) {
            bVar = (O.b) kVar.f271a;
            if (i3 >= i) {
                break;
            }
            ArrayList arrayList2 = (ArrayList) c0439j.i(i3);
            if (arrayList2 != null) {
                arrayList2.clear();
                bVar.c(arrayList2);
            }
            i3++;
        }
        c0439j.clear();
        int childCount = getChildCount();
        int i4 = 0;
        loop1: while (true) {
            C0439j c0439j2 = (C0439j) kVar.f272b;
            if (i4 >= childCount) {
                ArrayList arrayList3 = (ArrayList) kVar.f273c;
                arrayList3.clear();
                HashSet hashSet = (HashSet) kVar.f274d;
                hashSet.clear();
                int i5 = c0439j2.f5433d;
                for (int i6 = 0; i6 < i5; i6++) {
                    kVar.c(c0439j2.f(i6), arrayList3, hashSet);
                }
                arrayList.addAll(arrayList3);
                Collections.reverse(arrayList);
                return;
            }
            View childAt = getChildAt(i4);
            C.f fVarN = n(childAt);
            int i7 = fVarN.f257f;
            if (i7 == -1) {
                fVarN.f262l = null;
                fVarN.f261k = null;
            } else {
                View view = fVarN.f261k;
                if (view == null || view.getId() != i7) {
                    viewFindViewById = findViewById(i7);
                    fVarN.f261k = viewFindViewById;
                    if (viewFindViewById != null) {
                        if (!isInEditMode()) {
                            throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + getResources().getResourceName(i7) + " to anchor view " + childAt);
                        }
                        fVarN.f262l = null;
                        fVarN.f261k = null;
                    } else if (viewFindViewById != this) {
                        for (ViewParent parent = viewFindViewById.getParent(); parent != this && parent != null; parent = parent.getParent()) {
                            if (parent != childAt) {
                                if (parent instanceof View) {
                                    viewFindViewById = parent;
                                }
                            } else {
                                if (!isInEditMode()) {
                                    throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                                }
                                fVarN.f262l = null;
                                fVarN.f261k = null;
                            }
                        }
                        fVarN.f262l = viewFindViewById;
                    } else {
                        if (!isInEditMode()) {
                            throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                        }
                        fVarN.f262l = null;
                        fVarN.f261k = null;
                    }
                } else {
                    View view2 = fVarN.f261k;
                    for (ViewParent parent2 = view2.getParent(); parent2 != this; parent2 = parent2.getParent()) {
                        if (parent2 == null || parent2 == childAt) {
                            fVarN.f262l = null;
                            fVarN.f261k = null;
                            viewFindViewById = findViewById(i7);
                            fVarN.f261k = viewFindViewById;
                            if (viewFindViewById != null) {
                            }
                        } else {
                            if (parent2 instanceof View) {
                                view2 = parent2;
                            }
                        }
                    }
                    fVarN.f262l = view2;
                }
            }
            if (!c0439j2.containsKey(childAt)) {
                c0439j2.put(childAt, null);
            }
            for (int i8 = 0; i8 < childCount; i8++) {
                if (i8 != i4) {
                    View childAt2 = getChildAt(i8);
                    if (childAt2 != fVarN.f262l) {
                        WeakHashMap weakHashMap = O.f854a;
                        int layoutDirection = getLayoutDirection();
                        int absoluteGravity = Gravity.getAbsoluteGravity(((C.f) childAt2.getLayoutParams()).f258g, layoutDirection);
                        if ((absoluteGravity != 0 && (Gravity.getAbsoluteGravity(fVarN.f259h, layoutDirection) & absoluteGravity) == absoluteGravity) || ((cVar = fVarN.f253a) != null && cVar.f(childAt, childAt2))) {
                            if (!c0439j2.containsKey(childAt2) && !c0439j2.containsKey(childAt2)) {
                                c0439j2.put(childAt2, null);
                            }
                            if (!c0439j2.containsKey(childAt2) || !c0439j2.containsKey(childAt)) {
                                break loop1;
                            }
                            ArrayList arrayList4 = (ArrayList) c0439j2.get(childAt2);
                            if (arrayList4 == null) {
                                arrayList4 = (ArrayList) bVar.a();
                                if (arrayList4 == null) {
                                    arrayList4 = new ArrayList();
                                }
                                c0439j2.put(childAt2, arrayList4);
                            }
                            arrayList4.add(childAt);
                        }
                    }
                }
            }
            i4++;
        }
        throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
    }

    public final void u(boolean z2) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            C.c cVar = ((C.f) childAt.getLayoutParams()).f253a;
            if (cVar != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z2) {
                    cVar.k(this, childAt, motionEventObtain);
                } else {
                    cVar.v(this, childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            ((C.f) getChildAt(i3).getLayoutParams()).getClass();
        }
        this.f1653k = null;
        this.f1651h = false;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1659q;
    }

    public final void x() {
        WeakHashMap weakHashMap = O.f854a;
        if (!getFitsSystemWindows()) {
            G.l(this, null);
            return;
        }
        if (this.f1661s == null) {
            this.f1661s = new f(1, this);
        }
        G.l(this, this.f1661s);
        setSystemUiVisibility(1280);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C.f ? new C.f((C.f) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C.f((ViewGroup.MarginLayoutParams) layoutParams) : new C.f(layoutParams);
    }
}
