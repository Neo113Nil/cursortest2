package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;
import n.C0300b;
import n.U0;

/* loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public boolean f1503b;

    /* renamed from: c, reason: collision with root package name */
    public View f1504c;

    /* renamed from: d, reason: collision with root package name */
    public View f1505d;
    public Drawable e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f1506f;

    /* renamed from: g, reason: collision with root package name */
    public Drawable f1507g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f1508h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final int f1509j;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C0300b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3064a);
        boolean z2 = false;
        this.e = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f1506f = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f1509j = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f1508h = true;
            this.f1507g = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f1508h ? !(this.e != null || this.f1506f != null) : this.f1507g == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.e;
        if (drawable != null && drawable.isStateful()) {
            this.e.setState(getDrawableState());
        }
        Drawable drawable2 = this.f1506f;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f1506f.setState(getDrawableState());
        }
        Drawable drawable3 = this.f1507g;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f1507g.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f1506f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f1507g;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f1504c = findViewById(R.id.action_bar);
        this.f1505d = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1503b || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        super.onLayout(z2, i, i3, i4, i5);
        boolean z3 = true;
        if (this.f1508h) {
            Drawable drawable = this.f1507g;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z3 = false;
            }
        } else {
            if (this.e == null) {
                z3 = false;
            } else if (this.f1504c.getVisibility() == 0) {
                this.e.setBounds(this.f1504c.getLeft(), this.f1504c.getTop(), this.f1504c.getRight(), this.f1504c.getBottom());
            } else {
                View view = this.f1505d;
                if (view == null || view.getVisibility() != 0) {
                    this.e.setBounds(0, 0, 0, 0);
                } else {
                    this.e.setBounds(this.f1505d.getLeft(), this.f1505d.getTop(), this.f1505d.getRight(), this.f1505d.getBottom());
                }
            }
            this.i = false;
        }
        if (z3) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i3) {
        int i4;
        if (this.f1504c == null && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && (i4 = this.f1509j) >= 0) {
            i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i4, View.MeasureSpec.getSize(i3)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i3);
        if (this.f1504c == null) {
            return;
        }
        View.MeasureSpec.getMode(i3);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.e);
        }
        this.e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1504c;
            if (view != null) {
                this.e.setBounds(view.getLeft(), this.f1504c.getTop(), this.f1504c.getRight(), this.f1504c.getBottom());
            }
        }
        boolean z2 = false;
        if (!this.f1508h ? !(this.e != null || this.f1506f != null) : this.f1507g == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f1507g;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f1507g);
        }
        this.f1507g = drawable;
        boolean z2 = this.f1508h;
        boolean z3 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z2 && (drawable2 = this.f1507g) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z2 ? !(this.e != null || this.f1506f != null) : this.f1507g == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f1506f;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1506f);
        }
        this.f1506f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.i && this.f1506f != null) {
                throw null;
            }
        }
        boolean z2 = false;
        if (!this.f1508h ? !(this.e != null || this.f1506f != null) : this.f1507g == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(U0 u02) {
    }

    public void setTransitioning(boolean z2) {
        this.f1503b = z2;
        setDescendantFocusability(z2 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z2 = i == 0;
        Drawable drawable = this.e;
        if (drawable != null) {
            drawable.setVisible(z2, false);
        }
        Drawable drawable2 = this.f1506f;
        if (drawable2 != null) {
            drawable2.setVisible(z2, false);
        }
        Drawable drawable3 = this.f1507g;
        if (drawable3 != null) {
            drawable3.setVisible(z2, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.e;
        boolean z2 = this.f1508h;
        return (drawable == drawable2 && !z2) || (drawable == this.f1506f && this.i) || ((drawable == this.f1507g && z2) || super.verifyDrawable(drawable));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }
}
