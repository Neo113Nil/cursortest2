package androidx.appcompat.widget;

import N.g;
import N0.f;
import P.C0023k;
import P.O;
import X0.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import b1.e;
import c0.G;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;
import h.C0170I;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import l.h;
import m.C0287n;
import m.MenuC0285l;
import n.C0291B;
import n.C0292C;
import n.C0307e0;
import n.C0320l;
import n.InterfaceC0327o0;
import n.T0;
import n.b1;
import n.c1;
import n.d1;
import n.e1;
import n.f1;
import n.g1;
import n.h1;
import n.j1;
import n.k1;
import n.o1;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* renamed from: A, reason: collision with root package name */
    public ColorStateList f1581A;

    /* renamed from: B, reason: collision with root package name */
    public ColorStateList f1582B;

    /* renamed from: C, reason: collision with root package name */
    public boolean f1583C;

    /* renamed from: D, reason: collision with root package name */
    public boolean f1584D;

    /* renamed from: E, reason: collision with root package name */
    public final ArrayList f1585E;
    public final ArrayList F;

    /* renamed from: G, reason: collision with root package name */
    public final int[] f1586G;

    /* renamed from: H, reason: collision with root package name */
    public final C0023k f1587H;

    /* renamed from: I, reason: collision with root package name */
    public ArrayList f1588I;

    /* renamed from: J, reason: collision with root package name */
    public g1 f1589J;
    public final c1 K;

    /* renamed from: L, reason: collision with root package name */
    public j1 f1590L;

    /* renamed from: M, reason: collision with root package name */
    public C0320l f1591M;

    /* renamed from: N, reason: collision with root package name */
    public e1 f1592N;

    /* renamed from: O, reason: collision with root package name */
    public g f1593O;

    /* renamed from: P, reason: collision with root package name */
    public C0170I f1594P;

    /* renamed from: Q, reason: collision with root package name */
    public boolean f1595Q;

    /* renamed from: R, reason: collision with root package name */
    public OnBackInvokedCallback f1596R;

    /* renamed from: S, reason: collision with root package name */
    public OnBackInvokedDispatcher f1597S;

    /* renamed from: T, reason: collision with root package name */
    public boolean f1598T;

    /* renamed from: U, reason: collision with root package name */
    public final f f1599U;

    /* renamed from: b, reason: collision with root package name */
    public ActionMenuView f1600b;

    /* renamed from: c, reason: collision with root package name */
    public C0307e0 f1601c;

    /* renamed from: d, reason: collision with root package name */
    public C0307e0 f1602d;
    public C0291B e;

    /* renamed from: f, reason: collision with root package name */
    public C0292C f1603f;

    /* renamed from: g, reason: collision with root package name */
    public final Drawable f1604g;

    /* renamed from: h, reason: collision with root package name */
    public final CharSequence f1605h;
    public C0291B i;

    /* renamed from: j, reason: collision with root package name */
    public View f1606j;

    /* renamed from: k, reason: collision with root package name */
    public Context f1607k;

    /* renamed from: l, reason: collision with root package name */
    public int f1608l;

    /* renamed from: m, reason: collision with root package name */
    public int f1609m;

    /* renamed from: n, reason: collision with root package name */
    public int f1610n;

    /* renamed from: o, reason: collision with root package name */
    public final int f1611o;

    /* renamed from: p, reason: collision with root package name */
    public final int f1612p;

    /* renamed from: q, reason: collision with root package name */
    public int f1613q;

    /* renamed from: r, reason: collision with root package name */
    public int f1614r;

    /* renamed from: s, reason: collision with root package name */
    public int f1615s;

    /* renamed from: t, reason: collision with root package name */
    public int f1616t;

    /* renamed from: u, reason: collision with root package name */
    public T0 f1617u;

    /* renamed from: v, reason: collision with root package name */
    public int f1618v;

    /* renamed from: w, reason: collision with root package name */
    public int f1619w;

    /* renamed from: x, reason: collision with root package name */
    public final int f1620x;

    /* renamed from: y, reason: collision with root package name */
    public CharSequence f1621y;

    /* renamed from: z, reason: collision with root package name */
    public CharSequence f1622z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i = 0; i < menu.size(); i++) {
            arrayList.add(menu.getItem(i));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new h(getContext());
    }

    public static f1 h() {
        f1 f1Var = new f1(-2, -2);
        f1Var.f4503b = 0;
        f1Var.f4502a = 8388627;
        return f1Var;
    }

    public static f1 i(ViewGroup.LayoutParams layoutParams) {
        boolean z2 = layoutParams instanceof f1;
        if (z2) {
            f1 f1Var = (f1) layoutParams;
            f1 f1Var2 = new f1(f1Var);
            f1Var2.f4503b = 0;
            f1Var2.f4503b = f1Var.f4503b;
            return f1Var2;
        }
        if (z2) {
            f1 f1Var3 = new f1((f1) layoutParams);
            f1Var3.f4503b = 0;
            return f1Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            f1 f1Var4 = new f1(layoutParams);
            f1Var4.f4503b = 0;
            return f1Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        f1 f1Var5 = new f1(marginLayoutParams);
        f1Var5.f4503b = 0;
        ((ViewGroup.MarginLayoutParams) f1Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) f1Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) f1Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) f1Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return f1Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i) {
        boolean z2 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        arrayList.clear();
        if (!z2) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                f1 f1Var = (f1) childAt.getLayoutParams();
                if (f1Var.f4503b == 0 && u(childAt)) {
                    int i4 = f1Var.f4502a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i4, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i5 = childCount - 1; i5 >= 0; i5--) {
            View childAt2 = getChildAt(i5);
            f1 f1Var2 = (f1) childAt2.getLayoutParams();
            if (f1Var2.f4503b == 0 && u(childAt2)) {
                int i6 = f1Var2.f4502a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i6, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        f1 f1VarH = layoutParams == null ? h() : !checkLayoutParams(layoutParams) ? i(layoutParams) : (f1) layoutParams;
        f1VarH.f4503b = 1;
        if (!z2 || this.f1606j == null) {
            addView(view, f1VarH);
        } else {
            view.setLayoutParams(f1VarH);
            this.F.add(view);
        }
    }

    public final void c() {
        if (this.i == null) {
            C0291B c0291b = new C0291B(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.i = c0291b;
            c0291b.setImageDrawable(this.f1604g);
            this.i.setContentDescription(this.f1605h);
            f1 f1VarH = h();
            f1VarH.f4502a = (this.f1611o & 112) | 8388611;
            f1VarH.f4503b = 2;
            this.i.setLayoutParams(f1VarH);
            this.i.setOnClickListener(new j(4, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof f1);
    }

    public final void d() {
        if (this.f1617u == null) {
            T0 t02 = new T0();
            t02.f4403a = 0;
            t02.f4404b = 0;
            t02.f4405c = Integer.MIN_VALUE;
            t02.f4406d = Integer.MIN_VALUE;
            t02.e = 0;
            t02.f4407f = 0;
            t02.f4408g = false;
            t02.f4409h = false;
            this.f1617u = t02;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f1600b;
        if (actionMenuView.f1558q == null) {
            MenuC0285l menuC0285l = (MenuC0285l) actionMenuView.getMenu();
            if (this.f1592N == null) {
                this.f1592N = new e1(this);
            }
            this.f1600b.setExpandedActionViewsExclusive(true);
            menuC0285l.b(this.f1592N, this.f1607k);
            w();
        }
    }

    public final void f() {
        if (this.f1600b == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f1600b = actionMenuView;
            actionMenuView.setPopupTheme(this.f1608l);
            this.f1600b.setOnMenuItemClickListener(this.K);
            ActionMenuView actionMenuView2 = this.f1600b;
            g gVar = this.f1593O;
            c1 c1Var = new c1(this);
            actionMenuView2.f1563v = gVar;
            actionMenuView2.f1564w = c1Var;
            f1 f1VarH = h();
            f1VarH.f4502a = (this.f1611o & 112) | 8388613;
            this.f1600b.setLayoutParams(f1VarH);
            b(this.f1600b, false);
        }
    }

    public final void g() {
        if (this.e == null) {
            this.e = new C0291B(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            f1 f1VarH = h();
            f1VarH.f4502a = (this.f1611o & 112) | 8388611;
            this.e.setLayoutParams(f1VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0291B c0291b = this.i;
        if (c0291b != null) {
            return c0291b.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0291B c0291b = this.i;
        if (c0291b != null) {
            return c0291b.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        T0 t02 = this.f1617u;
        if (t02 != null) {
            return t02.f4408g ? t02.f4403a : t02.f4404b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.f1619w;
        return i != Integer.MIN_VALUE ? i : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        T0 t02 = this.f1617u;
        if (t02 != null) {
            return t02.f4403a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        T0 t02 = this.f1617u;
        if (t02 != null) {
            return t02.f4404b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        T0 t02 = this.f1617u;
        if (t02 != null) {
            return t02.f4408g ? t02.f4404b : t02.f4403a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.f1618v;
        return i != Integer.MIN_VALUE ? i : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        MenuC0285l menuC0285l;
        ActionMenuView actionMenuView = this.f1600b;
        return (actionMenuView == null || (menuC0285l = actionMenuView.f1558q) == null || !menuC0285l.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f1619w, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1618v, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        C0292C c0292c = this.f1603f;
        if (c0292c != null) {
            return c0292c.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C0292C c0292c = this.f1603f;
        if (c0292c != null) {
            return c0292c.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f1600b.getMenu();
    }

    public View getNavButtonView() {
        return this.e;
    }

    public CharSequence getNavigationContentDescription() {
        C0291B c0291b = this.e;
        if (c0291b != null) {
            return c0291b.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0291B c0291b = this.e;
        if (c0291b != null) {
            return c0291b.getDrawable();
        }
        return null;
    }

    public C0320l getOuterActionMenuPresenter() {
        return this.f1591M;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f1600b.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f1607k;
    }

    public int getPopupTheme() {
        return this.f1608l;
    }

    public CharSequence getSubtitle() {
        return this.f1622z;
    }

    public final TextView getSubtitleTextView() {
        return this.f1602d;
    }

    public CharSequence getTitle() {
        return this.f1621y;
    }

    public int getTitleMarginBottom() {
        return this.f1616t;
    }

    public int getTitleMarginEnd() {
        return this.f1614r;
    }

    public int getTitleMarginStart() {
        return this.f1613q;
    }

    public int getTitleMarginTop() {
        return this.f1615s;
    }

    public final TextView getTitleTextView() {
        return this.f1601c;
    }

    public InterfaceC0327o0 getWrapper() {
        if (this.f1590L == null) {
            this.f1590L = new j1(this, true);
        }
        return this.f1590L;
    }

    public final int j(View view, int i) {
        f1 f1Var = (f1) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i4 = f1Var.f4502a & 112;
        if (i4 != 16 && i4 != 48 && i4 != 80) {
            i4 = this.f1620x & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) f1Var).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = ((ViewGroup.MarginLayoutParams) f1Var).topMargin;
        if (iMax < i5) {
            iMax = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i7 = ((ViewGroup.MarginLayoutParams) f1Var).bottomMargin;
            if (i6 < i7) {
                iMax = Math.max(0, iMax - (i7 - i6));
            }
        }
        return paddingTop + iMax;
    }

    public void m(int i) {
        getMenuInflater().inflate(i, getMenu());
    }

    public final void n() {
        Iterator it = this.f1588I.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(((MenuItem) it.next()).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it2 = ((CopyOnWriteArrayList) this.f1587H.f913c).iterator();
        while (it2.hasNext()) {
            ((G) it2.next()).f2086a.k();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f1588I = currentMenuItems2;
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.F.contains(view);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        w();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f1599U);
        w();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1584D = false;
        }
        if (!this.f1584D) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f1584D = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1584D = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:106:0x0298 A[LOOP:0: B:105:0x0296->B:106:0x0298, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:109:0x02b5 A[LOOP:1: B:108:0x02b3->B:109:0x02b5, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:112:0x02d3 A[LOOP:2: B:111:0x02d1->B:112:0x02d3, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0314  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x0321 A[LOOP:3: B:120:0x031f->B:121:0x0321, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x011e  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x0221  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int iQ;
        int iR;
        boolean zU;
        boolean zU2;
        int i6;
        int measuredHeight;
        int i7;
        int i8;
        boolean z3;
        int i9;
        int i10;
        int i11;
        int paddingTop;
        int i12;
        int i13;
        int i14;
        int i15;
        int size;
        int iQ2;
        int i16;
        int size2;
        int i17;
        int size3;
        int i18;
        int i19;
        int i20;
        int size4;
        boolean z4 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i21 = width - paddingRight;
        int[] iArr = this.f1586G;
        iArr[1] = 0;
        iArr[0] = 0;
        WeakHashMap weakHashMap = O.f854a;
        int minimumHeight = getMinimumHeight();
        int iMin = minimumHeight >= 0 ? Math.min(minimumHeight, i5 - i3) : 0;
        if (!u(this.e)) {
            iQ = paddingLeft;
        } else {
            if (z4) {
                iR = r(this.e, i21, iMin, iArr);
                iQ = paddingLeft;
                if (u(this.i)) {
                    if (z4) {
                        iR = r(this.i, iR, iMin, iArr);
                    } else {
                        iQ = q(this.i, iQ, iMin, iArr);
                    }
                }
                if (u(this.f1600b)) {
                    if (z4) {
                        iQ = q(this.f1600b, iQ, iMin, iArr);
                    } else {
                        iR = r(this.f1600b, iR, iMin, iArr);
                    }
                }
                int currentContentInsetLeft = getCurrentContentInsetLeft();
                int currentContentInsetRight = getCurrentContentInsetRight();
                iArr[0] = Math.max(0, currentContentInsetLeft - iQ);
                iArr[1] = Math.max(0, currentContentInsetRight - (i21 - iR));
                int iMax = Math.max(iQ, currentContentInsetLeft);
                int iMin2 = Math.min(iR, i21 - currentContentInsetRight);
                if (u(this.f1606j)) {
                    if (z4) {
                        iMin2 = r(this.f1606j, iMin2, iMin, iArr);
                    } else {
                        iMax = q(this.f1606j, iMax, iMin, iArr);
                    }
                }
                if (u(this.f1603f)) {
                    if (z4) {
                        iMin2 = r(this.f1603f, iMin2, iMin, iArr);
                    } else {
                        iMax = q(this.f1603f, iMax, iMin, iArr);
                    }
                }
                zU = u(this.f1601c);
                zU2 = u(this.f1602d);
                if (zU) {
                    i6 = paddingRight;
                    measuredHeight = 0;
                } else {
                    f1 f1Var = (f1) this.f1601c.getLayoutParams();
                    i6 = paddingRight;
                    measuredHeight = ((ViewGroup.MarginLayoutParams) f1Var).bottomMargin + this.f1601c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) f1Var).topMargin;
                }
                if (zU2) {
                    i7 = width;
                } else {
                    f1 f1Var2 = (f1) this.f1602d.getLayoutParams();
                    i7 = width;
                    measuredHeight += this.f1602d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) f1Var2).topMargin + ((ViewGroup.MarginLayoutParams) f1Var2).bottomMargin;
                }
                if (!zU || zU2) {
                    C0307e0 c0307e0 = !zU ? this.f1601c : this.f1602d;
                    C0307e0 c0307e02 = !zU2 ? this.f1602d : this.f1601c;
                    f1 f1Var3 = (f1) c0307e0.getLayoutParams();
                    f1 f1Var4 = (f1) c0307e02.getLayoutParams();
                    if ((zU || this.f1601c.getMeasuredWidth() <= 0) && (!zU2 || this.f1602d.getMeasuredWidth() <= 0)) {
                        i8 = paddingLeft;
                        z3 = false;
                    } else {
                        i8 = paddingLeft;
                        z3 = true;
                    }
                    i9 = this.f1620x & 112;
                    i10 = iMin;
                    if (i9 == 48) {
                        i11 = iMax;
                        paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) f1Var3).topMargin + this.f1615s;
                    } else if (i9 != 80) {
                        int iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                        i11 = iMax;
                        int i22 = ((ViewGroup.MarginLayoutParams) f1Var3).topMargin + this.f1615s;
                        if (iMax2 < i22) {
                            iMax2 = i22;
                        } else {
                            int i23 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                            int i24 = ((ViewGroup.MarginLayoutParams) f1Var3).bottomMargin;
                            int i25 = this.f1616t;
                            if (i23 < i24 + i25) {
                                iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) f1Var4).bottomMargin + i25) - i23));
                            }
                        }
                        paddingTop = paddingTop2 + iMax2;
                    } else {
                        i11 = iMax;
                        paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) f1Var4).bottomMargin) - this.f1616t) - measuredHeight;
                    }
                    if (z4) {
                        int i26 = (z3 ? this.f1613q : 0) - iArr[1];
                        iMin2 -= Math.max(0, i26);
                        iArr[1] = Math.max(0, -i26);
                        if (zU) {
                            f1 f1Var5 = (f1) this.f1601c.getLayoutParams();
                            int measuredWidth = iMin2 - this.f1601c.getMeasuredWidth();
                            int measuredHeight2 = this.f1601c.getMeasuredHeight() + paddingTop;
                            this.f1601c.layout(measuredWidth, paddingTop, iMin2, measuredHeight2);
                            i14 = measuredWidth - this.f1614r;
                            paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) f1Var5).bottomMargin;
                        } else {
                            i14 = iMin2;
                        }
                        if (zU2) {
                            int i27 = paddingTop + ((ViewGroup.MarginLayoutParams) ((f1) this.f1602d.getLayoutParams())).topMargin;
                            this.f1602d.layout(iMin2 - this.f1602d.getMeasuredWidth(), i27, iMin2, this.f1602d.getMeasuredHeight() + i27);
                            i15 = iMin2 - this.f1614r;
                        } else {
                            i15 = iMin2;
                        }
                        if (z3) {
                            iMin2 = Math.min(i14, i15);
                        }
                        iMax = i11;
                    } else {
                        int i28 = (z3 ? this.f1613q : 0) - iArr[0];
                        iMax = Math.max(0, i28) + i11;
                        iArr[0] = Math.max(0, -i28);
                        if (zU) {
                            f1 f1Var6 = (f1) this.f1601c.getLayoutParams();
                            int measuredWidth2 = this.f1601c.getMeasuredWidth() + iMax;
                            int measuredHeight3 = this.f1601c.getMeasuredHeight() + paddingTop;
                            this.f1601c.layout(iMax, paddingTop, measuredWidth2, measuredHeight3);
                            i12 = measuredWidth2 + this.f1614r;
                            paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) f1Var6).bottomMargin;
                        } else {
                            i12 = iMax;
                        }
                        if (zU2) {
                            int i29 = paddingTop + ((ViewGroup.MarginLayoutParams) ((f1) this.f1602d.getLayoutParams())).topMargin;
                            int measuredWidth3 = this.f1602d.getMeasuredWidth() + iMax;
                            this.f1602d.layout(iMax, i29, measuredWidth3, this.f1602d.getMeasuredHeight() + i29);
                            i13 = measuredWidth3 + this.f1614r;
                        } else {
                            i13 = iMax;
                        }
                        if (z3) {
                            iMax = Math.max(i12, i13);
                        }
                    }
                } else {
                    i8 = paddingLeft;
                    i10 = iMin;
                }
                ArrayList arrayList = this.f1585E;
                a(arrayList, 3);
                size = arrayList.size();
                iQ2 = iMax;
                for (i16 = 0; i16 < size; i16++) {
                    iQ2 = q((View) arrayList.get(i16), iQ2, i10, iArr);
                }
                int i30 = i10;
                a(arrayList, 5);
                size2 = arrayList.size();
                for (i17 = 0; i17 < size2; i17++) {
                    iMin2 = r((View) arrayList.get(i17), iMin2, i30, iArr);
                }
                a(arrayList, 1);
                int i31 = iArr[0];
                int i32 = iArr[1];
                size3 = arrayList.size();
                int i33 = i32;
                int i34 = i31;
                i18 = 0;
                int measuredWidth4 = 0;
                while (i18 < size3) {
                    View view = (View) arrayList.get(i18);
                    f1 f1Var7 = (f1) view.getLayoutParams();
                    int i35 = ((ViewGroup.MarginLayoutParams) f1Var7).leftMargin - i34;
                    int i36 = ((ViewGroup.MarginLayoutParams) f1Var7).rightMargin - i33;
                    int iMax3 = Math.max(0, i35);
                    int iMax4 = Math.max(0, i36);
                    int iMax5 = Math.max(0, -i35);
                    int iMax6 = Math.max(0, -i36);
                    measuredWidth4 += view.getMeasuredWidth() + iMax3 + iMax4;
                    i18++;
                    i33 = iMax6;
                    i34 = iMax5;
                }
                i20 = ((((i7 - i8) - i6) / 2) + i8) - (measuredWidth4 / 2);
                int i37 = measuredWidth4 + i20;
                if (i20 >= iQ2) {
                    iQ2 = i37 > iMin2 ? i20 - (i37 - iMin2) : i20;
                }
                size4 = arrayList.size();
                for (i19 = 0; i19 < size4; i19++) {
                    iQ2 = q((View) arrayList.get(i19), iQ2, i30, iArr);
                }
                arrayList.clear();
            }
            iQ = q(this.e, paddingLeft, iMin, iArr);
        }
        iR = i21;
        if (u(this.i)) {
        }
        if (u(this.f1600b)) {
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iQ);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i21 - iR));
        int iMax7 = Math.max(iQ, currentContentInsetLeft2);
        int iMin22 = Math.min(iR, i21 - currentContentInsetRight2);
        if (u(this.f1606j)) {
        }
        if (u(this.f1603f)) {
        }
        zU = u(this.f1601c);
        zU2 = u(this.f1602d);
        if (zU) {
        }
        if (zU2) {
        }
        if (zU) {
            if (!zU) {
            }
            if (!zU2) {
            }
            f1 f1Var32 = (f1) c0307e0.getLayoutParams();
            f1 f1Var42 = (f1) c0307e02.getLayoutParams();
            if (zU) {
                i8 = paddingLeft;
                z3 = false;
                i9 = this.f1620x & 112;
                i10 = iMin;
                if (i9 == 48) {
                }
                if (z4) {
                }
            } else {
                i8 = paddingLeft;
                z3 = false;
                i9 = this.f1620x & 112;
                i10 = iMin;
                if (i9 == 48) {
                }
                if (z4) {
                }
            }
        }
        ArrayList arrayList2 = this.f1585E;
        a(arrayList2, 3);
        size = arrayList2.size();
        iQ2 = iMax7;
        while (i16 < size) {
        }
        int i302 = i10;
        a(arrayList2, 5);
        size2 = arrayList2.size();
        while (i17 < size2) {
        }
        a(arrayList2, 1);
        int i312 = iArr[0];
        int i322 = iArr[1];
        size3 = arrayList2.size();
        int i332 = i322;
        int i342 = i312;
        i18 = 0;
        int measuredWidth42 = 0;
        while (i18 < size3) {
        }
        i20 = ((((i7 - i8) - i6) / 2) + i8) - (measuredWidth42 / 2);
        int i372 = measuredWidth42 + i20;
        if (i20 >= iQ2) {
        }
        size4 = arrayList2.size();
        while (i19 < size4) {
        }
        arrayList2.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i3) {
        char c3;
        char c4;
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iL;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean z2 = o1.f4571a;
        int i4 = 0;
        if (getLayoutDirection() == 1) {
            c4 = 1;
            c3 = 0;
        } else {
            c3 = 1;
            c4 = 0;
        }
        if (u(this.e)) {
            t(this.e, i, 0, i3, this.f1612p);
            iK = k(this.e) + this.e.getMeasuredWidth();
            iMax = Math.max(0, l(this.e) + this.e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.e.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (u(this.i)) {
            t(this.i, i, 0, i3, this.f1612p);
            iK = k(this.i) + this.i.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.i) + this.i.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.i.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        int[] iArr = this.f1586G;
        iArr[c4] = iMax4;
        if (u(this.f1600b)) {
            t(this.f1600b, i, iMax3, i3, this.f1612p);
            iK2 = k(this.f1600b) + this.f1600b.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f1600b) + this.f1600b.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1600b.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[c3] = Math.max(0, currentContentInsetEnd - iK2);
        if (u(this.f1606j)) {
            iMax5 += s(this.f1606j, i, iMax5, i3, 0, iArr);
            iMax = Math.max(iMax, l(this.f1606j) + this.f1606j.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1606j.getMeasuredState());
        }
        if (u(this.f1603f)) {
            iMax5 += s(this.f1603f, i, iMax5, i3, 0, iArr);
            iMax = Math.max(iMax, l(this.f1603f) + this.f1603f.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1603f.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (((f1) childAt.getLayoutParams()).f4503b == 0 && u(childAt)) {
                iMax5 += s(childAt, i, iMax5, i3, 0, iArr);
                iMax = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
            }
        }
        int i6 = this.f1615s + this.f1616t;
        int i7 = this.f1613q + this.f1614r;
        if (u(this.f1601c)) {
            s(this.f1601c, i, iMax5 + i7, i3, i6, iArr);
            int iK3 = k(this.f1601c) + this.f1601c.getMeasuredWidth();
            iL = l(this.f1601c) + this.f1601c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f1601c.getMeasuredState());
            iMax2 = iK3;
        } else {
            iL = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (u(this.f1602d)) {
            iMax2 = Math.max(iMax2, s(this.f1602d, i, iMax5 + i7, i3, iL + i6, iArr));
            iL = l(this.f1602d) + this.f1602d.getMeasuredHeight() + iL;
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f1602d.getMeasuredState());
        }
        int iMax6 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax6;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + iMax5 + iMax2, getSuggestedMinimumWidth()), i, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16);
        if (!this.f1595Q) {
            i4 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i8 = 0; i8 < childCount2; i8++) {
            View childAt2 = getChildAt(i8);
            if (u(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i4 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i4);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof h1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h1 h1Var = (h1) parcelable;
        super.onRestoreInstanceState(h1Var.f1144b);
        ActionMenuView actionMenuView = this.f1600b;
        MenuC0285l menuC0285l = actionMenuView != null ? actionMenuView.f1558q : null;
        int i = h1Var.f4507d;
        if (i != 0 && this.f1592N != null && menuC0285l != null && (menuItemFindItem = menuC0285l.findItem(i)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (h1Var.e) {
            f fVar = this.f1599U;
            removeCallbacks(fVar);
            post(fVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        d();
        T0 t02 = this.f1617u;
        boolean z2 = i == 1;
        if (z2 == t02.f4408g) {
            return;
        }
        t02.f4408g = z2;
        if (!t02.f4409h) {
            t02.f4403a = t02.e;
            t02.f4404b = t02.f4407f;
            return;
        }
        if (z2) {
            int i3 = t02.f4406d;
            if (i3 == Integer.MIN_VALUE) {
                i3 = t02.e;
            }
            t02.f4403a = i3;
            int i4 = t02.f4405c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = t02.f4407f;
            }
            t02.f4404b = i4;
            return;
        }
        int i5 = t02.f4405c;
        if (i5 == Integer.MIN_VALUE) {
            i5 = t02.e;
        }
        t02.f4403a = i5;
        int i6 = t02.f4406d;
        if (i6 == Integer.MIN_VALUE) {
            i6 = t02.f4407f;
        }
        t02.f4404b = i6;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C0287n c0287n;
        h1 h1Var = new h1(super.onSaveInstanceState());
        e1 e1Var = this.f1592N;
        if (e1Var != null && (c0287n = e1Var.f4500c) != null) {
            h1Var.f4507d = c0287n.f4232a;
        }
        h1Var.e = p();
        return h1Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1583C = false;
        }
        if (!this.f1583C) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f1583C = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1583C = false;
        }
        return true;
    }

    public final boolean p() {
        C0320l c0320l;
        ActionMenuView actionMenuView = this.f1600b;
        return (actionMenuView == null || (c0320l = actionMenuView.f1562u) == null || !c0320l.h()) ? false : true;
    }

    public final int q(View view, int i, int i3, int[] iArr) {
        f1 f1Var = (f1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) f1Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i4) + i;
        iArr[0] = Math.max(0, -i4);
        int iJ = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) f1Var).rightMargin + iMax;
    }

    public final int r(View view, int i, int i3, int[] iArr) {
        f1 f1Var = (f1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) f1Var).rightMargin - iArr[1];
        int iMax = i - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int iJ = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) f1Var).leftMargin);
    }

    public final int s(View view, int i, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + iMax + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public void setBackInvokedCallbackEnabled(boolean z2) {
        if (this.f1598T != z2) {
            this.f1598T = z2;
            w();
        }
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(e.A(getContext(), i));
    }

    public void setCollapsible(boolean z2) {
        this.f1595Q = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f1619w) {
            this.f1619w = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f1618v) {
            this.f1618v = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(e.A(getContext(), i));
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(e.A(getContext(), i));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.e.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(g1 g1Var) {
        this.f1589J = g1Var;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f1600b.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.f1608l != i) {
            this.f1608l = i;
            if (i == 0) {
                this.f1607k = getContext();
            } else {
                this.f1607k = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitleMarginBottom(int i) {
        this.f1616t = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.f1614r = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.f1613q = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.f1615s = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public final void t(View view, int i, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean u(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final boolean v() {
        C0320l c0320l;
        ActionMenuView actionMenuView = this.f1600b;
        return (actionMenuView == null || (c0320l = actionMenuView.f1562u) == null || !c0320l.n()) ? false : true;
    }

    public final void w() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = d1.a(this);
            e1 e1Var = this.f1592N;
            boolean z2 = (e1Var == null || e1Var.f4500c == null || onBackInvokedDispatcherA == null || !isAttachedToWindow() || !this.f1598T) ? false : true;
            if (z2 && this.f1597S == null) {
                if (this.f1596R == null) {
                    this.f1596R = d1.b(new b1(this, 0));
                }
                d1.c(onBackInvokedDispatcherA, this.f1596R);
                this.f1597S = onBackInvokedDispatcherA;
                return;
            }
            if (z2 || (onBackInvokedDispatcher = this.f1597S) == null) {
                return;
            }
            d1.d(onBackInvokedDispatcher, this.f1596R);
            this.f1597S = null;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f1620x = 8388627;
        this.f1585E = new ArrayList();
        this.F = new ArrayList();
        this.f1586G = new int[2];
        this.f1587H = new C0023k(new b1(this, 1));
        this.f1588I = new ArrayList();
        this.K = new c1(this);
        this.f1599U = new f(12, this);
        Context context2 = getContext();
        int[] iArr = AbstractC0131a.f3086y;
        C0023k c0023kH = C0023k.h(context2, attributeSet, iArr, R.attr.toolbarStyle);
        O.l(this, context, iArr, attributeSet, (TypedArray) c0023kH.f913c, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        this.f1609m = typedArray.getResourceId(28, 0);
        this.f1610n = typedArray.getResourceId(19, 0);
        this.f1620x = typedArray.getInteger(0, 8388627);
        this.f1611o = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f1616t = dimensionPixelOffset;
        this.f1615s = dimensionPixelOffset;
        this.f1614r = dimensionPixelOffset;
        this.f1613q = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f1613q = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f1614r = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f1615s = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f1616t = dimensionPixelOffset5;
        }
        this.f1612p = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        T0 t02 = this.f1617u;
        t02.f4409h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            t02.e = dimensionPixelSize;
            t02.f4403a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            t02.f4407f = dimensionPixelSize2;
            t02.f4404b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            t02.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f1618v = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f1619w = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f1604g = c0023kH.c(4);
        this.f1605h = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f1607k = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableC = c0023kH.c(16);
        if (drawableC != null) {
            setNavigationIcon(drawableC);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableC2 = c0023kH.c(11);
        if (drawableC2 != null) {
            setLogo(drawableC2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(c0023kH.b(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(c0023kH.b(20));
        }
        if (typedArray.hasValue(14)) {
            m(typedArray.getResourceId(14, 0));
        }
        c0023kH.j();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        f1 f1Var = new f1(context, attributeSet);
        f1Var.f4502a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3065b);
        f1Var.f4502a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        f1Var.f4503b = 0;
        return f1Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0291B c0291b = this.i;
        if (c0291b != null) {
            c0291b.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.i.setImageDrawable(drawable);
        } else {
            C0291B c0291b = this.i;
            if (c0291b != null) {
                c0291b.setImageDrawable(this.f1604g);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f1603f == null) {
                this.f1603f = new C0292C(getContext(), null, 0);
            }
            if (!o(this.f1603f)) {
                b(this.f1603f, true);
            }
        } else {
            C0292C c0292c = this.f1603f;
            if (c0292c != null && o(c0292c)) {
                removeView(this.f1603f);
                this.F.remove(this.f1603f);
            }
        }
        C0292C c0292c2 = this.f1603f;
        if (c0292c2 != null) {
            c0292c2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f1603f == null) {
            this.f1603f = new C0292C(getContext(), null, 0);
        }
        C0292C c0292c = this.f1603f;
        if (c0292c != null) {
            c0292c.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        C0291B c0291b = this.e;
        if (c0291b != null) {
            c0291b.setContentDescription(charSequence);
            k1.a(this.e, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.e)) {
                b(this.e, true);
            }
        } else {
            C0291B c0291b = this.e;
            if (c0291b != null && o(c0291b)) {
                removeView(this.e);
                this.F.remove(this.e);
            }
        }
        C0291B c0291b2 = this.e;
        if (c0291b2 != null) {
            c0291b2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0307e0 c0307e0 = this.f1602d;
            if (c0307e0 != null && o(c0307e0)) {
                removeView(this.f1602d);
                this.F.remove(this.f1602d);
            }
        } else {
            if (this.f1602d == null) {
                Context context = getContext();
                C0307e0 c0307e02 = new C0307e0(context, null);
                this.f1602d = c0307e02;
                c0307e02.setSingleLine();
                this.f1602d.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f1610n;
                if (i != 0) {
                    this.f1602d.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f1582B;
                if (colorStateList != null) {
                    this.f1602d.setTextColor(colorStateList);
                }
            }
            if (!o(this.f1602d)) {
                b(this.f1602d, true);
            }
        }
        C0307e0 c0307e03 = this.f1602d;
        if (c0307e03 != null) {
            c0307e03.setText(charSequence);
        }
        this.f1622z = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f1582B = colorStateList;
        C0307e0 c0307e0 = this.f1602d;
        if (c0307e0 != null) {
            c0307e0.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0307e0 c0307e0 = this.f1601c;
            if (c0307e0 != null && o(c0307e0)) {
                removeView(this.f1601c);
                this.F.remove(this.f1601c);
            }
        } else {
            if (this.f1601c == null) {
                Context context = getContext();
                C0307e0 c0307e02 = new C0307e0(context, null);
                this.f1601c = c0307e02;
                c0307e02.setSingleLine();
                this.f1601c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f1609m;
                if (i != 0) {
                    this.f1601c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f1581A;
                if (colorStateList != null) {
                    this.f1601c.setTextColor(colorStateList);
                }
            }
            if (!o(this.f1601c)) {
                b(this.f1601c, true);
            }
        }
        C0307e0 c0307e03 = this.f1601c;
        if (c0307e03 != null) {
            c0307e03.setText(charSequence);
        }
        this.f1621y = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f1581A = colorStateList;
        C0307e0 c0307e0 = this.f1601c;
        if (c0307e0 != null) {
            c0307e0.setTextColor(colorStateList);
        }
    }
}
