package androidx.appcompat.widget;

import P.U;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import h.LayoutInflaterFactory2C0164C;
import h.r;
import m.MenuC0285l;
import n.C0310g;
import n.C0320l;
import n.InterfaceC0323m0;
import n.InterfaceC0325n0;
import n.j1;

/* loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public TypedValue f1572b;

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f1573c;

    /* renamed from: d, reason: collision with root package name */
    public TypedValue f1574d;
    public TypedValue e;

    /* renamed from: f, reason: collision with root package name */
    public TypedValue f1575f;

    /* renamed from: g, reason: collision with root package name */
    public TypedValue f1576g;

    /* renamed from: h, reason: collision with root package name */
    public final Rect f1577h;
    public InterfaceC0323m0 i;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f1577h = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f1575f == null) {
            this.f1575f = new TypedValue();
        }
        return this.f1575f;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f1576g == null) {
            this.f1576g = new TypedValue();
        }
        return this.f1576g;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f1574d == null) {
            this.f1574d = new TypedValue();
        }
        return this.f1574d;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        return this.e;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f1572b == null) {
            this.f1572b = new TypedValue();
        }
        return this.f1572b;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f1573c == null) {
            this.f1573c = new TypedValue();
        }
        return this.f1573c;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        InterfaceC0323m0 interfaceC0323m0 = this.i;
        if (interfaceC0323m0 != null) {
            interfaceC0323m0.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        C0320l c0320l;
        super.onDetachedFromWindow();
        InterfaceC0323m0 interfaceC0323m0 = this.i;
        if (interfaceC0323m0 != null) {
            LayoutInflaterFactory2C0164C layoutInflaterFactory2C0164C = ((r) interfaceC0323m0).f3379c;
            InterfaceC0325n0 interfaceC0325n0 = layoutInflaterFactory2C0164C.f3246s;
            if (interfaceC0325n0 != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0325n0;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((j1) actionBarOverlayLayout.f1536f).f4512a.f1600b;
                if (actionMenuView != null && (c0320l = actionMenuView.f1562u) != null) {
                    c0320l.e();
                    C0310g c0310g = c0320l.f4555v;
                    if (c0310g != null && c0310g.b()) {
                        c0310g.i.dismiss();
                    }
                }
            }
            if (layoutInflaterFactory2C0164C.f3251x != null) {
                layoutInflaterFactory2C0164C.f3240m.getDecorView().removeCallbacks(layoutInflaterFactory2C0164C.f3252y);
                if (layoutInflaterFactory2C0164C.f3251x.isShowing()) {
                    try {
                        layoutInflaterFactory2C0164C.f3251x.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                layoutInflaterFactory2C0164C.f3251x = null;
            }
            U u2 = layoutInflaterFactory2C0164C.f3253z;
            if (u2 != null) {
                u2.b();
            }
            MenuC0285l menuC0285l = layoutInflaterFactory2C0164C.A(0).f3195h;
            if (menuC0285l != null) {
                menuC0285l.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i3) {
        int iMakeMeasureSpec;
        boolean z2;
        int iMakeMeasureSpec2;
        int i4;
        int i5;
        float fraction;
        int i6;
        int i7;
        float fraction2;
        int i8;
        int i9;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z3 = true;
        boolean z4 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i3);
        Rect rect = this.f1577h;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i;
            z2 = false;
        } else {
            TypedValue typedValue = z4 ? this.e : this.f1574d;
            if (typedValue != null && (i8 = typedValue.type) != 0) {
                if (i8 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else if (i8 == 6) {
                    int i10 = displayMetrics.widthPixels;
                    fraction3 = typedValue.getFraction(i10, i10);
                } else {
                    i9 = 0;
                    if (i9 <= 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i9 - (rect.left + rect.right), View.MeasureSpec.getSize(i)), 1073741824);
                        z2 = true;
                    }
                }
                i9 = (int) fraction3;
                if (i9 <= 0) {
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i3;
        } else {
            TypedValue typedValue2 = z4 ? this.f1575f : this.f1576g;
            if (typedValue2 != null && (i6 = typedValue2.type) != 0) {
                if (i6 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else if (i6 == 6) {
                    int i11 = displayMetrics.heightPixels;
                    fraction2 = typedValue2.getFraction(i11, i11);
                } else {
                    i7 = 0;
                    if (i7 <= 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i7 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i3)), 1073741824);
                    }
                }
                i7 = (int) fraction2;
                if (i7 <= 0) {
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z2 || mode != Integer.MIN_VALUE) {
            z3 = false;
        } else {
            TypedValue typedValue3 = z4 ? this.f1573c : this.f1572b;
            if (typedValue3 != null && (i4 = typedValue3.type) != 0) {
                if (i4 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else if (i4 == 6) {
                    int i12 = displayMetrics.widthPixels;
                    fraction = typedValue3.getFraction(i12, i12);
                } else {
                    i5 = 0;
                    if (i5 > 0) {
                        i5 -= rect.left + rect.right;
                    }
                    if (measuredWidth >= i5) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
                    }
                }
                i5 = (int) fraction;
                if (i5 > 0) {
                }
                if (measuredWidth >= i5) {
                }
            }
        }
        if (z3) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(InterfaceC0323m0 interfaceC0323m0) {
        this.i = interfaceC0323m0;
    }
}
