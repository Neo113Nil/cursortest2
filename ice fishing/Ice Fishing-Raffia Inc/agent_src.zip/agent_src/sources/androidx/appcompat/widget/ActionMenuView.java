package androidx.appcompat.widget;

import N.g;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import e1.C0123e;
import m.C0287n;
import m.InterfaceC0283j;
import m.InterfaceC0284k;
import m.MenuC0285l;
import m.w;
import m.z;
import n.B0;
import n.C0;
import n.C0310g;
import n.C0316j;
import n.C0320l;
import n.C0324n;
import n.C0326o;
import n.InterfaceC0322m;
import n.InterfaceC0328p;
import n.o1;

/* loaded from: classes.dex */
public class ActionMenuView extends C0 implements InterfaceC0284k, z {

    /* renamed from: A, reason: collision with root package name */
    public final int f1556A;

    /* renamed from: B, reason: collision with root package name */
    public InterfaceC0328p f1557B;

    /* renamed from: q, reason: collision with root package name */
    public MenuC0285l f1558q;

    /* renamed from: r, reason: collision with root package name */
    public Context f1559r;

    /* renamed from: s, reason: collision with root package name */
    public int f1560s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f1561t;

    /* renamed from: u, reason: collision with root package name */
    public C0320l f1562u;

    /* renamed from: v, reason: collision with root package name */
    public g f1563v;

    /* renamed from: w, reason: collision with root package name */
    public InterfaceC0283j f1564w;

    /* renamed from: x, reason: collision with root package name */
    public boolean f1565x;

    /* renamed from: y, reason: collision with root package name */
    public int f1566y;

    /* renamed from: z, reason: collision with root package name */
    public final int f1567z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f3 = context.getResources().getDisplayMetrics().density;
        this.f1567z = (int) (56.0f * f3);
        this.f1556A = (int) (f3 * 4.0f);
        this.f1559r = context;
        this.f1560s = 0;
    }

    public static C0324n j() {
        C0324n c0324n = new C0324n(-2, -2);
        c0324n.f4564a = false;
        ((LinearLayout.LayoutParams) c0324n).gravity = 16;
        return c0324n;
    }

    public static C0324n k(ViewGroup.LayoutParams layoutParams) {
        C0324n c0324n;
        if (layoutParams == null) {
            return j();
        }
        if (layoutParams instanceof C0324n) {
            C0324n c0324n2 = (C0324n) layoutParams;
            c0324n = new C0324n(c0324n2);
            c0324n.f4564a = c0324n2.f4564a;
        } else {
            c0324n = new C0324n(layoutParams);
        }
        if (((LinearLayout.LayoutParams) c0324n).gravity <= 0) {
            ((LinearLayout.LayoutParams) c0324n).gravity = 16;
        }
        return c0324n;
    }

    @Override // m.z
    public final void b(MenuC0285l menuC0285l) {
        this.f1558q = menuC0285l;
    }

    @Override // m.InterfaceC0284k
    public final boolean c(C0287n c0287n) {
        return this.f1558q.q(c0287n, null, 0);
    }

    @Override // n.C0, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0324n;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // n.C0
    /* renamed from: f */
    public final /* bridge */ /* synthetic */ B0 generateDefaultLayoutParams() {
        return j();
    }

    @Override // n.C0
    /* renamed from: g */
    public final B0 generateLayoutParams(AttributeSet attributeSet) {
        return new C0324n(getContext(), attributeSet);
    }

    @Override // n.C0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return j();
    }

    @Override // n.C0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public Menu getMenu() {
        if (this.f1558q == null) {
            Context context = getContext();
            MenuC0285l menuC0285l = new MenuC0285l(context);
            this.f1558q = menuC0285l;
            menuC0285l.e = new C0326o(0, this);
            C0320l c0320l = new C0320l(context);
            this.f1562u = c0320l;
            c0320l.f4547n = true;
            c0320l.f4548o = true;
            w c0123e = this.f1563v;
            if (c0123e == null) {
                c0123e = new C0123e();
            }
            c0320l.f4540f = c0123e;
            this.f1558q.b(c0320l, this.f1559r);
            C0320l c0320l2 = this.f1562u;
            c0320l2.i = this;
            this.f1558q = c0320l2.f4539d;
        }
        return this.f1558q;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0320l c0320l = this.f1562u;
        C0316j c0316j = c0320l.f4544k;
        if (c0316j != null) {
            return c0316j.getDrawable();
        }
        if (c0320l.f4546m) {
            return c0320l.f4545l;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f1560s;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // n.C0
    /* renamed from: h */
    public final /* bridge */ /* synthetic */ B0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public final boolean l(int i) {
        boolean zC = false;
        if (i == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i - 1);
        KeyEvent.Callback childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof InterfaceC0322m)) {
            zC = ((InterfaceC0322m) childAt).c();
        }
        return (i <= 0 || !(childAt2 instanceof InterfaceC0322m)) ? zC : zC | ((InterfaceC0322m) childAt2).b();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0320l c0320l = this.f1562u;
        if (c0320l != null) {
            c0320l.d();
            if (this.f1562u.h()) {
                this.f1562u.e();
                this.f1562u.n();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0320l c0320l = this.f1562u;
        if (c0320l != null) {
            c0320l.e();
            C0310g c0310g = c0320l.f4555v;
            if (c0310g == null || !c0310g.b()) {
                return;
            }
            c0310g.i.dismiss();
        }
    }

    @Override // n.C0, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int width;
        int paddingLeft;
        if (!this.f1565x) {
            super.onLayout(z2, i, i3, i4, i5);
            return;
        }
        int childCount = getChildCount();
        int i6 = (i5 - i3) / 2;
        int dividerWidth = getDividerWidth();
        int i7 = i4 - i;
        int paddingRight = (i7 - getPaddingRight()) - getPaddingLeft();
        boolean z3 = o1.f4571a;
        boolean z4 = getLayoutDirection() == 1;
        int i8 = 0;
        int i9 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                C0324n c0324n = (C0324n) childAt.getLayoutParams();
                if (c0324n.f4564a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (l(i10)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z4) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) c0324n).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) c0324n).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i11 = i6 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i11, width, measuredHeight + i11);
                    paddingRight -= measuredWidth;
                    i8 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) c0324n).leftMargin) + ((LinearLayout.LayoutParams) c0324n).rightMargin;
                    l(i10);
                    i9++;
                }
            }
        }
        if (childCount == 1 && i8 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i12 = (i7 / 2) - (measuredWidth2 / 2);
            int i13 = i6 - (measuredHeight2 / 2);
            childAt2.layout(i12, i13, measuredWidth2 + i12, measuredHeight2 + i13);
            return;
        }
        int i14 = i9 - (i8 ^ 1);
        int iMax = Math.max(0, i14 > 0 ? paddingRight / i14 : 0);
        if (z4) {
            int width2 = getWidth() - getPaddingRight();
            for (int i15 = 0; i15 < childCount; i15++) {
                View childAt3 = getChildAt(i15);
                C0324n c0324n2 = (C0324n) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !c0324n2.f4564a) {
                    int i16 = width2 - ((LinearLayout.LayoutParams) c0324n2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i17 = i6 - (measuredHeight3 / 2);
                    childAt3.layout(i16 - measuredWidth3, i17, i16, measuredHeight3 + i17);
                    width2 = i16 - ((measuredWidth3 + ((LinearLayout.LayoutParams) c0324n2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt4 = getChildAt(i18);
            C0324n c0324n3 = (C0324n) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !c0324n3.f4564a) {
                int i19 = paddingLeft2 + ((LinearLayout.LayoutParams) c0324n3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i20 = i6 - (measuredHeight4 / 2);
                childAt4.layout(i19, i20, i19 + measuredWidth4, measuredHeight4 + i20);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) c0324n3).rightMargin + iMax + i19;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r4v28 */
    /* JADX WARN: Type inference failed for: r4v29, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v31 */
    /* JADX WARN: Type inference failed for: r4v36 */
    @Override // n.C0, android.view.View
    public final void onMeasure(int i, int i3) {
        int i4;
        boolean z2;
        int i5;
        boolean z3;
        int i6;
        int i7;
        int i8;
        ?? r4;
        int i9;
        int i10;
        int i11;
        MenuC0285l menuC0285l;
        boolean z4 = this.f1565x;
        boolean z5 = View.MeasureSpec.getMode(i) == 1073741824;
        this.f1565x = z5;
        if (z4 != z5) {
            this.f1566y = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (this.f1565x && (menuC0285l = this.f1558q) != null && size != this.f1566y) {
            this.f1566y = size;
            menuC0285l.p(true);
        }
        int childCount = getChildCount();
        if (!this.f1565x || childCount <= 0) {
            for (int i12 = 0; i12 < childCount; i12++) {
                C0324n c0324n = (C0324n) getChildAt(i12).getLayoutParams();
                ((LinearLayout.LayoutParams) c0324n).rightMargin = 0;
                ((LinearLayout.LayoutParams) c0324n).leftMargin = 0;
            }
            super.onMeasure(i, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i);
        int size3 = View.MeasureSpec.getSize(i3);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, paddingBottom, -2);
        int i13 = size2 - paddingRight;
        int i14 = this.f1567z;
        int i15 = i13 / i14;
        int i16 = i13 % i14;
        if (i15 == 0) {
            setMeasuredDimension(i13, 0);
            return;
        }
        int i17 = (i16 / i15) + i14;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i18 = 0;
        int iMax2 = 0;
        int i19 = 0;
        boolean z6 = false;
        int i20 = 0;
        long j3 = 0;
        while (true) {
            i4 = this.f1556A;
            if (i19 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i19);
            int i21 = size3;
            int i22 = i13;
            if (childAt.getVisibility() == 8) {
                i9 = mode;
                i10 = paddingBottom;
            } else {
                boolean z7 = childAt instanceof ActionMenuItemView;
                int i23 = i18 + 1;
                if (z7) {
                    childAt.setPadding(i4, 0, i4, 0);
                }
                C0324n c0324n2 = (C0324n) childAt.getLayoutParams();
                c0324n2.f4568f = false;
                c0324n2.f4566c = 0;
                c0324n2.f4565b = 0;
                c0324n2.f4567d = false;
                ((LinearLayout.LayoutParams) c0324n2).leftMargin = 0;
                ((LinearLayout.LayoutParams) c0324n2).rightMargin = 0;
                c0324n2.e = z7 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i24 = c0324n2.f4564a ? 1 : i15;
                C0324n c0324n3 = (C0324n) childAt.getLayoutParams();
                i9 = mode;
                i10 = paddingBottom;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - paddingBottom, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z7 ? (ActionMenuItemView) childAt : null;
                boolean z8 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                if (i24 <= 0 || (z8 && i24 < 2)) {
                    i11 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i24 * i17, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i11 = measuredWidth / i17;
                    if (measuredWidth % i17 != 0) {
                        i11++;
                    }
                    if (z8 && i11 < 2) {
                        i11 = 2;
                    }
                }
                c0324n3.f4567d = !c0324n3.f4564a && z8;
                c0324n3.f4565b = i11;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i11 * i17, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i11);
                if (c0324n2.f4567d) {
                    i20++;
                }
                if (c0324n2.f4564a) {
                    z6 = true;
                }
                i15 -= i11;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i11 == 1) {
                    j3 |= 1 << i19;
                }
                i18 = i23;
            }
            i19++;
            size3 = i21;
            i13 = i22;
            paddingBottom = i10;
            mode = i9;
        }
        int i25 = mode;
        int i26 = i13;
        int i27 = size3;
        boolean z9 = z6 && i18 == 2;
        boolean z10 = false;
        while (i20 > 0 && i15 > 0) {
            int i28 = Integer.MAX_VALUE;
            int i29 = 0;
            int i30 = 0;
            long j4 = 0;
            while (i30 < childCount2) {
                C0324n c0324n4 = (C0324n) getChildAt(i30).getLayoutParams();
                boolean z11 = z10;
                if (c0324n4.f4567d) {
                    int i31 = c0324n4.f4565b;
                    if (i31 < i28) {
                        j4 = 1 << i30;
                        i28 = i31;
                        i29 = 1;
                    } else if (i31 == i28) {
                        j4 |= 1 << i30;
                        i29++;
                    }
                }
                i30++;
                z10 = z11;
            }
            z2 = z10;
            j3 |= j4;
            if (i29 > i15) {
                break;
            }
            int i32 = i28 + 1;
            int i33 = 0;
            while (i33 < childCount2) {
                View childAt2 = getChildAt(i33);
                C0324n c0324n5 = (C0324n) childAt2.getLayoutParams();
                int i34 = iMax;
                int i35 = childMeasureSpec;
                int i36 = childCount2;
                long j5 = 1 << i33;
                if ((j4 & j5) != 0) {
                    if (z9 && c0324n5.e) {
                        r4 = 1;
                        r4 = 1;
                        if (i15 == 1) {
                            childAt2.setPadding(i4 + i17, 0, i4, 0);
                        }
                    } else {
                        r4 = 1;
                    }
                    c0324n5.f4565b += r4;
                    c0324n5.f4568f = r4;
                    i15--;
                } else if (c0324n5.f4565b == i32) {
                    j3 |= j5;
                }
                i33++;
                childMeasureSpec = i35;
                iMax = i34;
                childCount2 = i36;
            }
            z10 = true;
        }
        z2 = z10;
        int i37 = iMax;
        int i38 = childMeasureSpec;
        int i39 = childCount2;
        boolean z12 = !z6 && i18 == 1;
        if (i15 <= 0 || j3 == 0 || (i15 >= i18 - 1 && !z12 && iMax2 <= 1)) {
            i5 = i39;
            z3 = z2;
        } else {
            float fBitCount = Long.bitCount(j3);
            if (!z12) {
                if ((j3 & 1) != 0 && !((C0324n) getChildAt(0).getLayoutParams()).e) {
                    fBitCount -= 0.5f;
                }
                int i40 = i39 - 1;
                if ((j3 & (1 << i40)) != 0 && !((C0324n) getChildAt(i40).getLayoutParams()).e) {
                    fBitCount -= 0.5f;
                }
            }
            int i41 = fBitCount > 0.0f ? (int) ((i15 * i17) / fBitCount) : 0;
            boolean z13 = z2;
            i5 = i39;
            for (int i42 = 0; i42 < i5; i42++) {
                if ((j3 & (1 << i42)) != 0) {
                    View childAt3 = getChildAt(i42);
                    C0324n c0324n6 = (C0324n) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        c0324n6.f4566c = i41;
                        c0324n6.f4568f = true;
                        if (i42 == 0 && !c0324n6.e) {
                            ((LinearLayout.LayoutParams) c0324n6).leftMargin = (-i41) / 2;
                        }
                        z13 = true;
                    } else {
                        if (c0324n6.f4564a) {
                            c0324n6.f4566c = i41;
                            c0324n6.f4568f = true;
                            ((LinearLayout.LayoutParams) c0324n6).rightMargin = (-i41) / 2;
                            z13 = true;
                        } else {
                            if (i42 != 0) {
                                ((LinearLayout.LayoutParams) c0324n6).leftMargin = i41 / 2;
                            }
                            if (i42 != i5 - 1) {
                                ((LinearLayout.LayoutParams) c0324n6).rightMargin = i41 / 2;
                            }
                        }
                    }
                }
            }
            z3 = z13;
        }
        if (z3) {
            int i43 = 0;
            while (i43 < i5) {
                View childAt4 = getChildAt(i43);
                C0324n c0324n7 = (C0324n) childAt4.getLayoutParams();
                if (c0324n7.f4568f) {
                    i8 = i38;
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((c0324n7.f4565b * i17) + c0324n7.f4566c, 1073741824), i8);
                } else {
                    i8 = i38;
                }
                i43++;
                i38 = i8;
            }
        }
        if (i25 != 1073741824) {
            i7 = i26;
            i6 = i37;
        } else {
            i6 = i27;
            i7 = i26;
        }
        setMeasuredDimension(i7, i6);
    }

    public void setExpandedActionViewsExclusive(boolean z2) {
        this.f1562u.f4552s = z2;
    }

    public void setOnMenuItemClickListener(InterfaceC0328p interfaceC0328p) {
        this.f1557B = interfaceC0328p;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0320l c0320l = this.f1562u;
        C0316j c0316j = c0320l.f4544k;
        if (c0316j != null) {
            c0316j.setImageDrawable(drawable);
        } else {
            c0320l.f4546m = true;
            c0320l.f4545l = drawable;
        }
    }

    public void setOverflowReserved(boolean z2) {
        this.f1561t = z2;
    }

    public void setPopupTheme(int i) {
        if (this.f1560s != i) {
            this.f1560s = i;
            if (i == 0) {
                this.f1559r = getContext();
            } else {
                this.f1559r = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0320l c0320l) {
        this.f1562u = c0320l;
        c0320l.i = this;
        this.f1558q = c0320l.f4539d;
    }

    @Override // n.C0, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0324n(getContext(), attributeSet);
    }
}
