package androidx.appcompat.widget;

import E0.k;
import H.c;
import P.C0028p;
import P.E;
import P.G;
import P.InterfaceC0026n;
import P.InterfaceC0027o;
import P.O;
import P.f0;
import P.g0;
import P.h0;
import P.i0;
import P.j0;
import P.q0;
import P.u0;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import b1.e;
import com.kortosi.kluani.qorzanis.R;
import java.util.WeakHashMap;
import l.j;
import m.MenuC0285l;
import m.w;
import n.C0306e;
import n.C0308f;
import n.C0320l;
import n.InterfaceC0304d;
import n.InterfaceC0325n0;
import n.InterfaceC0327o0;
import n.RunnableC0302c;
import n.e1;
import n.j1;

@SuppressLint({"UnknownNullness"})
/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC0325n0, InterfaceC0026n, InterfaceC0027o {

    /* renamed from: D, reason: collision with root package name */
    public static final int[] f1528D = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* renamed from: E, reason: collision with root package name */
    public static final u0 f1529E;
    public static final Rect F;

    /* renamed from: A, reason: collision with root package name */
    public final RunnableC0302c f1530A;

    /* renamed from: B, reason: collision with root package name */
    public final C0028p f1531B;

    /* renamed from: C, reason: collision with root package name */
    public final C0308f f1532C;

    /* renamed from: b, reason: collision with root package name */
    public int f1533b;

    /* renamed from: c, reason: collision with root package name */
    public int f1534c;

    /* renamed from: d, reason: collision with root package name */
    public ContentFrameLayout f1535d;
    public ActionBarContainer e;

    /* renamed from: f, reason: collision with root package name */
    public InterfaceC0327o0 f1536f;

    /* renamed from: g, reason: collision with root package name */
    public Drawable f1537g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1538h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1539j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1540k;

    /* renamed from: l, reason: collision with root package name */
    public int f1541l;

    /* renamed from: m, reason: collision with root package name */
    public int f1542m;

    /* renamed from: n, reason: collision with root package name */
    public final Rect f1543n;

    /* renamed from: o, reason: collision with root package name */
    public final Rect f1544o;

    /* renamed from: p, reason: collision with root package name */
    public final Rect f1545p;

    /* renamed from: q, reason: collision with root package name */
    public final Rect f1546q;

    /* renamed from: r, reason: collision with root package name */
    public u0 f1547r;

    /* renamed from: s, reason: collision with root package name */
    public u0 f1548s;

    /* renamed from: t, reason: collision with root package name */
    public u0 f1549t;

    /* renamed from: u, reason: collision with root package name */
    public u0 f1550u;

    /* renamed from: v, reason: collision with root package name */
    public InterfaceC0304d f1551v;

    /* renamed from: w, reason: collision with root package name */
    public OverScroller f1552w;

    /* renamed from: x, reason: collision with root package name */
    public ViewPropertyAnimator f1553x;

    /* renamed from: y, reason: collision with root package name */
    public final k f1554y;

    /* renamed from: z, reason: collision with root package name */
    public final RunnableC0302c f1555z;

    static {
        int i = Build.VERSION.SDK_INT;
        j0 i0Var = i >= 34 ? new i0() : i >= 30 ? new h0() : i >= 29 ? new g0() : new f0();
        i0Var.g(c.b(0, 1, 0, 1));
        f1529E = i0Var.b();
        F = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1534c = 0;
        this.f1543n = new Rect();
        this.f1544o = new Rect();
        this.f1545p = new Rect();
        this.f1546q = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        u0 u0Var = u0.f942b;
        this.f1547r = u0Var;
        this.f1548s = u0Var;
        this.f1549t = u0Var;
        this.f1550u = u0Var;
        this.f1554y = new k(8, this);
        this.f1555z = new RunnableC0302c(this, 0);
        this.f1530A = new RunnableC0302c(this, 1);
        i(context);
        this.f1531B = new C0028p();
        C0308f c0308f = new C0308f(context);
        c0308f.setWillNotDraw(true);
        this.f1532C = c0308f;
        addView(c0308f);
    }

    public static boolean g(View view, Rect rect, boolean z2) {
        boolean z3;
        C0306e c0306e = (C0306e) view.getLayoutParams();
        int i = ((ViewGroup.MarginLayoutParams) c0306e).leftMargin;
        int i3 = rect.left;
        if (i != i3) {
            ((ViewGroup.MarginLayoutParams) c0306e).leftMargin = i3;
            z3 = true;
        } else {
            z3 = false;
        }
        int i4 = ((ViewGroup.MarginLayoutParams) c0306e).topMargin;
        int i5 = rect.top;
        if (i4 != i5) {
            ((ViewGroup.MarginLayoutParams) c0306e).topMargin = i5;
            z3 = true;
        }
        int i6 = ((ViewGroup.MarginLayoutParams) c0306e).rightMargin;
        int i7 = rect.right;
        if (i6 != i7) {
            ((ViewGroup.MarginLayoutParams) c0306e).rightMargin = i7;
            z3 = true;
        }
        if (z2) {
            int i8 = ((ViewGroup.MarginLayoutParams) c0306e).bottomMargin;
            int i9 = rect.bottom;
            if (i8 != i9) {
                ((ViewGroup.MarginLayoutParams) c0306e).bottomMargin = i9;
                return true;
            }
        }
        return z3;
    }

    @Override // P.InterfaceC0026n
    public final void a(View view, View view2, int i, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // P.InterfaceC0027o
    public final void b(View view, int i, int i3, int i4, int i5, int i6, int[] iArr) {
        c(view, i, i3, i4, i5, i6);
    }

    @Override // P.InterfaceC0026n
    public final void c(View view, int i, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i, i3, i4, i5);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0306e;
    }

    @Override // P.InterfaceC0026n
    public final void d(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f1537g != null) {
            if (this.e.getVisibility() == 0) {
                translationY = (int) (this.e.getTranslationY() + this.e.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f1537g.setBounds(0, translationY, getWidth(), this.f1537g.getIntrinsicHeight() + translationY);
            this.f1537g.draw(canvas);
        }
    }

    @Override // P.InterfaceC0026n
    public final void e(View view, int i, int i3, int[] iArr, int i4) {
    }

    @Override // P.InterfaceC0026n
    public final boolean f(View view, View view2, int i, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0306e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0306e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.e;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0028p c0028p = this.f1531B;
        return c0028p.f934b | c0028p.f933a;
    }

    public CharSequence getTitle() {
        k();
        return ((j1) this.f1536f).f4512a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f1555z);
        removeCallbacks(this.f1530A);
        ViewPropertyAnimator viewPropertyAnimator = this.f1553x;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f1528D);
        this.f1533b = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f1537g = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f1552w = new OverScroller(context);
    }

    public final void j(int i) {
        k();
        if (i == 2) {
            ((j1) this.f1536f).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i == 5) {
            ((j1) this.f1536f).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else {
            if (i != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        InterfaceC0327o0 wrapper;
        if (this.f1535d == null) {
            this.f1535d = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.e = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof InterfaceC0327o0) {
                wrapper = (InterfaceC0327o0) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f1536f = wrapper;
        }
    }

    public final void l(MenuC0285l menuC0285l, w wVar) {
        k();
        j1 j1Var = (j1) this.f1536f;
        C0320l c0320l = j1Var.f4522m;
        Toolbar toolbar = j1Var.f4512a;
        if (c0320l == null) {
            C0320l c0320l2 = new C0320l(toolbar.getContext());
            j1Var.f4522m = c0320l2;
            c0320l2.f4543j = R.id.action_menu_presenter;
        }
        C0320l c0320l3 = j1Var.f4522m;
        c0320l3.f4540f = wVar;
        if (menuC0285l == null && toolbar.f1600b == null) {
            return;
        }
        toolbar.f();
        MenuC0285l menuC0285l2 = toolbar.f1600b.f1558q;
        if (menuC0285l2 == menuC0285l) {
            return;
        }
        if (menuC0285l2 != null) {
            menuC0285l2.r(toolbar.f1591M);
            menuC0285l2.r(toolbar.f1592N);
        }
        if (toolbar.f1592N == null) {
            toolbar.f1592N = new e1(toolbar);
        }
        c0320l3.f4552s = true;
        if (menuC0285l != null) {
            menuC0285l.b(c0320l3, toolbar.f1607k);
            menuC0285l.b(toolbar.f1592N, toolbar.f1607k);
        } else {
            c0320l3.f(toolbar.f1607k, null);
            toolbar.f1592N.f(toolbar.f1607k, null);
            c0320l3.d();
            toolbar.f1592N.d();
        }
        toolbar.f1600b.setPopupTheme(toolbar.f1608l);
        toolbar.f1600b.setPresenter(c0320l3);
        toolbar.f1591M = c0320l3;
        toolbar.w();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        u0 u0VarG = u0.g(this, windowInsets);
        boolean zG = g(this.e, new Rect(u0VarG.b(), u0VarG.d(), u0VarG.c(), u0VarG.a()), false);
        WeakHashMap weakHashMap = O.f854a;
        Rect rect = this.f1543n;
        G.b(this, u0VarG, rect);
        int i = rect.left;
        int i3 = rect.top;
        int i4 = rect.right;
        int i5 = rect.bottom;
        q0 q0Var = u0VarG.f943a;
        u0 u0VarL = q0Var.l(i, i3, i4, i5);
        this.f1547r = u0VarL;
        boolean z2 = true;
        if (!this.f1548s.equals(u0VarL)) {
            this.f1548s = this.f1547r;
            zG = true;
        }
        Rect rect2 = this.f1544o;
        if (rect2.equals(rect)) {
            z2 = zG;
        } else {
            rect2.set(rect);
        }
        if (z2) {
            requestLayout();
        }
        return q0Var.a().f943a.c().f943a.b().f();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = O.f854a;
        E.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                C0306e c0306e = (C0306e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) c0306e).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) c0306e).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00aa  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i3) {
        int measuredHeight;
        k();
        measureChildWithMargins(this.e, i, 0, i3, 0);
        C0306e c0306e = (C0306e) this.e.getLayoutParams();
        int iMax = Math.max(0, this.e.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0306e).leftMargin + ((ViewGroup.MarginLayoutParams) c0306e).rightMargin);
        int iMax2 = Math.max(0, this.e.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0306e).topMargin + ((ViewGroup.MarginLayoutParams) c0306e).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.e.getMeasuredState());
        WeakHashMap weakHashMap = O.f854a;
        boolean z2 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z2) {
            measuredHeight = this.f1533b;
            if (this.i && this.e.getTabContainer() != null) {
                measuredHeight += this.f1533b;
            }
        } else {
            measuredHeight = this.e.getVisibility() != 8 ? this.e.getMeasuredHeight() : 0;
        }
        Rect rect = this.f1543n;
        Rect rect2 = this.f1545p;
        rect2.set(rect);
        this.f1549t = this.f1547r;
        if (this.f1538h || z2) {
            c cVarB = c.b(this.f1549t.b(), this.f1549t.d() + measuredHeight, this.f1549t.c(), this.f1549t.a());
            u0 u0Var = this.f1549t;
            int i4 = Build.VERSION.SDK_INT;
            j0 i0Var = i4 >= 34 ? new i0(u0Var) : i4 >= 30 ? new h0(u0Var) : i4 >= 29 ? new g0(u0Var) : new f0(u0Var);
            i0Var.g(cVarB);
            this.f1549t = i0Var.b();
        } else {
            C0308f c0308f = this.f1532C;
            u0 u0Var2 = f1529E;
            Rect rect3 = this.f1546q;
            G.b(c0308f, u0Var2, rect3);
            if (!rect3.equals(F)) {
                rect2.top += measuredHeight;
                rect2.bottom = rect2.bottom;
                this.f1549t = this.f1549t.f943a.l(0, measuredHeight, 0, 0);
            }
        }
        g(this.f1535d, rect2, true);
        if (!this.f1550u.equals(this.f1549t)) {
            u0 u0Var3 = this.f1549t;
            this.f1550u = u0Var3;
            O.b(this.f1535d, u0Var3);
        }
        measureChildWithMargins(this.f1535d, i, 0, i3, 0);
        C0306e c0306e2 = (C0306e) this.f1535d.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f1535d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0306e2).leftMargin + ((ViewGroup.MarginLayoutParams) c0306e2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f1535d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0306e2).topMargin + ((ViewGroup.MarginLayoutParams) c0306e2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f1535d.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f3, float f4, boolean z2) {
        if (!this.f1539j || !z2) {
            return false;
        }
        this.f1552w.fling(0, 0, 0, (int) f4, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f1552w.getFinalY() > this.e.getHeight()) {
            h();
            this.f1530A.run();
        } else {
            h();
            this.f1555z.run();
        }
        this.f1540k = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f3, float f4) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i3, int i4, int i5) {
        int i6 = this.f1541l + i3;
        this.f1541l = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        h.O o3;
        j jVar;
        this.f1531B.f933a = i;
        this.f1541l = getActionBarHideOffset();
        h();
        InterfaceC0304d interfaceC0304d = this.f1551v;
        if (interfaceC0304d == null || (jVar = (o3 = (h.O) interfaceC0304d).f3302u) == null) {
            return;
        }
        jVar.a();
        o3.f3302u = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.e.getVisibility() != 0) {
            return false;
        }
        return this.f1539j;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f1539j || this.f1540k) {
            return;
        }
        if (this.f1541l <= this.e.getHeight()) {
            h();
            postDelayed(this.f1555z, 600L);
        } else {
            h();
            postDelayed(this.f1530A, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        k();
        int i3 = this.f1542m ^ i;
        this.f1542m = i;
        boolean z2 = (i & 4) == 0;
        boolean z3 = (i & 256) != 0;
        InterfaceC0304d interfaceC0304d = this.f1551v;
        if (interfaceC0304d != null) {
            h.O o3 = (h.O) interfaceC0304d;
            o3.f3298q = !z3;
            if (z2 || !z3) {
                if (o3.f3299r) {
                    o3.f3299r = false;
                    o3.v0(true);
                }
            } else if (!o3.f3299r) {
                o3.f3299r = true;
                o3.v0(true);
            }
        }
        if ((i3 & 256) == 0 || this.f1551v == null) {
            return;
        }
        WeakHashMap weakHashMap = O.f854a;
        E.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f1534c = i;
        InterfaceC0304d interfaceC0304d = this.f1551v;
        if (interfaceC0304d != null) {
            ((h.O) interfaceC0304d).f3297p = i;
        }
    }

    public void setActionBarHideOffset(int i) {
        h();
        this.e.setTranslationY(-Math.max(0, Math.min(i, this.e.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC0304d interfaceC0304d) {
        this.f1551v = interfaceC0304d;
        if (getWindowToken() != null) {
            ((h.O) this.f1551v).f3297p = this.f1534c;
            int i = this.f1542m;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                WeakHashMap weakHashMap = O.f854a;
                E.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.i = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f1539j) {
            this.f1539j = z2;
            if (z2) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i) {
        k();
        j1 j1Var = (j1) this.f1536f;
        j1Var.f4515d = i != 0 ? e.A(j1Var.f4512a.getContext(), i) : null;
        j1Var.d();
    }

    public void setLogo(int i) {
        k();
        j1 j1Var = (j1) this.f1536f;
        j1Var.e = i != 0 ? e.A(j1Var.f4512a.getContext(), i) : null;
        j1Var.d();
    }

    public void setOverlayMode(boolean z2) {
        this.f1538h = z2;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i) {
    }

    @Override // n.InterfaceC0325n0
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((j1) this.f1536f).f4520k = callback;
    }

    @Override // n.InterfaceC0325n0
    public void setWindowTitle(CharSequence charSequence) {
        k();
        j1 j1Var = (j1) this.f1536f;
        if (j1Var.f4517g) {
            return;
        }
        j1Var.f4518h = charSequence;
        if ((j1Var.f4513b & 8) != 0) {
            Toolbar toolbar = j1Var.f4512a;
            toolbar.setTitle(charSequence);
            if (j1Var.f4517g) {
                O.n(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0306e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        j1 j1Var = (j1) this.f1536f;
        j1Var.f4515d = drawable;
        j1Var.d();
    }
}
