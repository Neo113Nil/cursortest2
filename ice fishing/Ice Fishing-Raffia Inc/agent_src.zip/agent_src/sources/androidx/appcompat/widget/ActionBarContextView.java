package androidx.appcompat.widget;

import P.O;
import P.U;
import X0.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import b1.e;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;
import l.AbstractC0257a;
import m.MenuC0285l;
import m.z;
import n.C0298a;
import n.C0310g;
import n.C0320l;
import n.o1;

/* loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* renamed from: b, reason: collision with root package name */
    public final C0298a f1510b;

    /* renamed from: c, reason: collision with root package name */
    public final Context f1511c;

    /* renamed from: d, reason: collision with root package name */
    public ActionMenuView f1512d;
    public C0320l e;

    /* renamed from: f, reason: collision with root package name */
    public int f1513f;

    /* renamed from: g, reason: collision with root package name */
    public U f1514g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1515h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1516j;

    /* renamed from: k, reason: collision with root package name */
    public CharSequence f1517k;

    /* renamed from: l, reason: collision with root package name */
    public View f1518l;

    /* renamed from: m, reason: collision with root package name */
    public View f1519m;

    /* renamed from: n, reason: collision with root package name */
    public View f1520n;

    /* renamed from: o, reason: collision with root package name */
    public LinearLayout f1521o;

    /* renamed from: p, reason: collision with root package name */
    public TextView f1522p;

    /* renamed from: q, reason: collision with root package name */
    public TextView f1523q;

    /* renamed from: r, reason: collision with root package name */
    public final int f1524r;

    /* renamed from: s, reason: collision with root package name */
    public final int f1525s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f1526t;

    /* renamed from: u, reason: collision with root package name */
    public final int f1527u;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        this.f1510b = new C0298a(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f1511c = context;
        } else {
            this.f1511c = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3067d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : e.A(context, resourceId));
        this.f1524r = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f1525s = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f1513f = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f1527u = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i3);
        return Math.max(0, i - view.getMeasuredWidth());
    }

    public static int g(View view, int i, int i3, int i4, boolean z2) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = ((i4 - measuredHeight) / 2) + i3;
        if (z2) {
            view.layout(i - measuredWidth, i5, i, measuredHeight + i5);
        } else {
            view.layout(i, i5, i + measuredWidth, measuredHeight + i5);
        }
        return z2 ? -measuredWidth : measuredWidth;
    }

    public final void c(AbstractC0257a abstractC0257a) {
        View view = this.f1518l;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f1527u, (ViewGroup) this, false);
            this.f1518l = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f1518l);
        }
        View viewFindViewById = this.f1518l.findViewById(R.id.action_mode_close_button);
        this.f1519m = viewFindViewById;
        viewFindViewById.setOnClickListener(new j(3, abstractC0257a));
        MenuC0285l menuC0285lD = abstractC0257a.d();
        C0320l c0320l = this.e;
        if (c0320l != null) {
            c0320l.e();
            C0310g c0310g = c0320l.f4555v;
            if (c0310g != null && c0310g.b()) {
                c0310g.i.dismiss();
            }
        }
        C0320l c0320l2 = new C0320l(getContext());
        this.e = c0320l2;
        c0320l2.f4547n = true;
        c0320l2.f4548o = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        menuC0285lD.b(this.e, this.f1511c);
        C0320l c0320l3 = this.e;
        z zVar = c0320l3.i;
        if (zVar == null) {
            z zVar2 = (z) c0320l3.e.inflate(c0320l3.f4541g, (ViewGroup) this, false);
            c0320l3.i = zVar2;
            zVar2.b(c0320l3.f4539d);
            c0320l3.d();
        }
        z zVar3 = c0320l3.i;
        if (zVar != zVar3) {
            ((ActionMenuView) zVar3).setPresenter(c0320l3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) zVar3;
        this.f1512d = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f1512d, layoutParams);
    }

    public final void d() {
        if (this.f1521o == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f1521o = linearLayout;
            this.f1522p = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f1523q = (TextView) this.f1521o.findViewById(R.id.action_bar_subtitle);
            int i = this.f1524r;
            if (i != 0) {
                this.f1522p.setTextAppearance(getContext(), i);
            }
            int i3 = this.f1525s;
            if (i3 != 0) {
                this.f1523q.setTextAppearance(getContext(), i3);
            }
        }
        this.f1522p.setText(this.f1516j);
        this.f1523q.setText(this.f1517k);
        boolean zIsEmpty = TextUtils.isEmpty(this.f1516j);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f1517k);
        this.f1523q.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f1521o.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f1521o.getParent() == null) {
            addView(this.f1521o);
        }
    }

    public final void e() {
        removeAllViews();
        this.f1520n = null;
        this.f1512d = null;
        this.e = null;
        View view = this.f1519m;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f1514g != null ? this.f1510b.f4473b : getVisibility();
    }

    public int getContentHeight() {
        return this.f1513f;
    }

    public CharSequence getSubtitle() {
        return this.f1517k;
    }

    public CharSequence getTitle() {
        return this.f1516j;
    }

    @Override // android.view.View
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i) {
        if (i != getVisibility()) {
            U u2 = this.f1514g;
            if (u2 != null) {
                u2.b();
            }
            super.setVisibility(i);
        }
    }

    public final U i(int i, long j3) {
        U u2 = this.f1514g;
        if (u2 != null) {
            u2.b();
        }
        C0298a c0298a = this.f1510b;
        if (i != 0) {
            U uA = O.a(this);
            uA.a(0.0f);
            uA.c(j3);
            c0298a.f4474c.f1514g = uA;
            c0298a.f4473b = i;
            uA.d(c0298a);
            return uA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        U uA2 = O.a(this);
        uA2.a(1.0f);
        uA2.c(j3);
        c0298a.f4474c.f1514g = uA2;
        c0298a.f4473b = i;
        uA2.d(c0298a);
        return uA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, AbstractC0131a.f3064a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        C0320l c0320l = this.e;
        if (c0320l != null) {
            Configuration configuration2 = c0320l.f4538c.getResources().getConfiguration();
            int i = configuration2.screenWidthDp;
            int i3 = configuration2.screenHeightDp;
            c0320l.f4551r = (configuration2.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && i3 > 720) || (i > 720 && i3 > 960)) ? 5 : (i >= 500 || (i > 640 && i3 > 480) || (i > 480 && i3 > 640)) ? 4 : i >= 360 ? 3 : 2;
            MenuC0285l menuC0285l = c0320l.f4539d;
            if (menuC0285l != null) {
                menuC0285l.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0320l c0320l = this.e;
        if (c0320l != null) {
            c0320l.e();
            C0310g c0310g = this.e.f4555v;
            if (c0310g == null || !c0310g.b()) {
                return;
            }
            c0310g.i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.i = false;
        }
        if (!this.i) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.i = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.i = false;
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        boolean z3 = o1.f4571a;
        boolean z4 = getLayoutDirection() == 1;
        int paddingRight = z4 ? (i4 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
        View view = this.f1518l;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1518l.getLayoutParams();
            int i6 = z4 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = z4 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i8 = z4 ? paddingRight - i6 : paddingRight + i6;
            int iG = g(this.f1518l, i8, paddingTop, paddingTop2, z4) + i8;
            paddingRight = z4 ? iG - i7 : iG + i7;
        }
        LinearLayout linearLayout = this.f1521o;
        if (linearLayout != null && this.f1520n == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(this.f1521o, paddingRight, paddingTop, paddingTop2, z4);
        }
        View view2 = this.f1520n;
        if (view2 != null) {
            g(view2, paddingRight, paddingTop, paddingTop2, z4);
        }
        int paddingLeft = z4 ? getPaddingLeft() : (i4 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f1512d;
        if (actionMenuView != null) {
            g(actionMenuView, paddingLeft, paddingTop, paddingTop2, !z4);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i3) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i3) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.f1513f;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i3);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f1518l;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1518l.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f1512d;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f1512d, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f1521o;
        if (linearLayout != null && this.f1520n == null) {
            if (this.f1526t) {
                this.f1521o.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f1521o.getMeasuredWidth();
                boolean z2 = measuredWidth <= paddingLeft;
                if (z2) {
                    paddingLeft -= measuredWidth;
                }
                this.f1521o.setVisibility(z2 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f1520n;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i4 = layoutParams.width;
            int i5 = i4 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i4 >= 0) {
                paddingLeft = Math.min(i4, paddingLeft);
            }
            int i6 = layoutParams.height;
            int i7 = i6 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i6 >= 0) {
                iMin = Math.min(i6, iMin);
            }
            this.f1520n.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i5), View.MeasureSpec.makeMeasureSpec(iMin, i7));
        }
        if (this.f1513f > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i8) {
                i8 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i8);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1515h = false;
        }
        if (!this.f1515h) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f1515h = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1515h = false;
        }
        return true;
    }

    public void setContentHeight(int i) {
        this.f1513f = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f1520n;
        if (view2 != null) {
            removeView(view2);
        }
        this.f1520n = view;
        if (view != null && (linearLayout = this.f1521o) != null) {
            removeView(linearLayout);
            this.f1521o = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1517k = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f1516j = charSequence;
        d();
        O.n(this, charSequence);
    }

    public void setTitleOptional(boolean z2) {
        if (z2 != this.f1526t) {
            requestLayout();
        }
        this.f1526t = z2;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
