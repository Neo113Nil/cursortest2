package androidx.appcompat.view.menu;

import P.C0023k;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;
import m.C0287n;
import m.MenuC0285l;
import m.y;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements y, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: b, reason: collision with root package name */
    public C0287n f1488b;

    /* renamed from: c, reason: collision with root package name */
    public ImageView f1489c;

    /* renamed from: d, reason: collision with root package name */
    public RadioButton f1490d;
    public TextView e;

    /* renamed from: f, reason: collision with root package name */
    public CheckBox f1491f;

    /* renamed from: g, reason: collision with root package name */
    public TextView f1492g;

    /* renamed from: h, reason: collision with root package name */
    public ImageView f1493h;
    public ImageView i;

    /* renamed from: j, reason: collision with root package name */
    public LinearLayout f1494j;

    /* renamed from: k, reason: collision with root package name */
    public final Drawable f1495k;

    /* renamed from: l, reason: collision with root package name */
    public final int f1496l;

    /* renamed from: m, reason: collision with root package name */
    public final Context f1497m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f1498n;

    /* renamed from: o, reason: collision with root package name */
    public final Drawable f1499o;

    /* renamed from: p, reason: collision with root package name */
    public final boolean f1500p;

    /* renamed from: q, reason: collision with root package name */
    public LayoutInflater f1501q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f1502r;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0023k c0023kH = C0023k.h(getContext(), attributeSet, AbstractC0131a.f3080s, R.attr.listMenuViewStyle);
        this.f1495k = c0023kH.c(5);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        this.f1496l = typedArray.getResourceId(1, -1);
        this.f1498n = typedArray.getBoolean(7, false);
        this.f1497m = context;
        this.f1499o = c0023kH.c(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f1500p = typedArrayObtainStyledAttributes.hasValue(0);
        c0023kH.j();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f1501q == null) {
            this.f1501q = LayoutInflater.from(getContext());
        }
        return this.f1501q;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f1493h;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005e  */
    @Override // m.y
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(C0287n c0287n) {
        boolean z2;
        int i;
        String string;
        boolean z3;
        this.f1488b = c0287n;
        setVisibility(c0287n.isVisible() ? 0 : 8);
        setTitle(c0287n.e);
        setCheckable(c0287n.isCheckable());
        if (c0287n.f4243n.o()) {
            if ((c0287n.f4243n.n() ? c0287n.f4239j : c0287n.f4238h) != 0) {
                z2 = true;
            }
        } else {
            z2 = false;
        }
        c0287n.f4243n.n();
        if (z2) {
            C0287n c0287n2 = this.f1488b;
            if (c0287n2.f4243n.o()) {
                if ((c0287n2.f4243n.n() ? c0287n2.f4239j : c0287n2.f4238h) != 0) {
                    z3 = true;
                }
                if (z3) {
                }
            } else {
                z3 = false;
                i = z3 ? 0 : 8;
            }
        }
        if (i == 0) {
            TextView textView = this.f1492g;
            C0287n c0287n3 = this.f1488b;
            char c3 = c0287n3.f4243n.n() ? c0287n3.f4239j : c0287n3.f4238h;
            if (c3 == 0) {
                string = "";
            } else {
                MenuC0285l menuC0285l = c0287n3.f4243n;
                Resources resources = menuC0285l.f4204a.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(menuC0285l.f4204a).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i3 = menuC0285l.n() ? c0287n3.f4240k : c0287n3.i;
                C0287n.c(i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label), sb);
                C0287n.c(i3, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label), sb);
                C0287n.c(i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label), sb);
                C0287n.c(i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label), sb);
                C0287n.c(i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label), sb);
                C0287n.c(i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label), sb);
                if (c3 == '\b') {
                    sb.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c3 == '\n') {
                    sb.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c3 != ' ') {
                    sb.append(c3);
                } else {
                    sb.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb.toString();
            }
            textView.setText(string);
        }
        if (this.f1492g.getVisibility() != i) {
            this.f1492g.setVisibility(i);
        }
        setIcon(c0287n.getIcon());
        setEnabled(c0287n.isEnabled());
        setSubMenuArrowVisible(c0287n.hasSubMenu());
        setContentDescription(c0287n.f4246q);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.i;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.i.getLayoutParams();
        rect.top = this.i.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // m.y
    public C0287n getItemData() {
        return this.f1488b;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f1495k);
        TextView textView = (TextView) findViewById(R.id.title);
        this.e = textView;
        int i = this.f1496l;
        if (i != -1) {
            textView.setTextAppearance(this.f1497m, i);
        }
        this.f1492g = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f1493h = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f1499o);
        }
        this.i = (ImageView) findViewById(R.id.group_divider);
        this.f1494j = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i3) {
        if (this.f1489c != null && this.f1498n) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1489c.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        View view;
        if (!z2 && this.f1490d == null && this.f1491f == null) {
            return;
        }
        if ((this.f1488b.f4253x & 4) != 0) {
            if (this.f1490d == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1490d = radioButton;
                LinearLayout linearLayout = this.f1494j;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1490d;
            view = this.f1491f;
        } else {
            if (this.f1491f == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1491f = checkBox;
                LinearLayout linearLayout2 = this.f1494j;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1491f;
            view = this.f1490d;
        }
        if (z2) {
            compoundButton.setChecked(this.f1488b.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f1491f;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f1490d;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if ((this.f1488b.f4253x & 4) != 0) {
            if (this.f1490d == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f1490d = radioButton;
                LinearLayout linearLayout = this.f1494j;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1490d;
        } else {
            if (this.f1491f == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f1491f = checkBox;
                LinearLayout linearLayout2 = this.f1494j;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1491f;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f1502r = z2;
        this.f1498n = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.i;
        if (imageView != null) {
            imageView.setVisibility((this.f1500p || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1488b.f4243n.getClass();
        boolean z2 = this.f1502r;
        if (z2 || this.f1498n) {
            ImageView imageView = this.f1489c;
            if (imageView == null && drawable == null && !this.f1498n) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f1489c = imageView2;
                LinearLayout linearLayout = this.f1494j;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f1498n) {
                this.f1489c.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f1489c;
            if (!z2) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f1489c.getVisibility() != 0) {
                this.f1489c.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.e.getVisibility() != 8) {
                this.e.setVisibility(8);
            }
        } else {
            this.e.setText(charSequence);
            if (this.e.getVisibility() != 0) {
                this.e.setVisibility(0);
            }
        }
    }
}
