package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import g.AbstractC0131a;
import m.AbstractC0276c;
import m.C0275b;
import m.C0287n;
import m.InterfaceC0284k;
import m.MenuC0285l;
import m.y;
import n.C0307e0;
import n.InterfaceC0322m;
import n.k1;

/* loaded from: classes.dex */
public class ActionMenuItemView extends C0307e0 implements y, View.OnClickListener, InterfaceC0322m {
    public C0287n i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1476j;

    /* renamed from: k, reason: collision with root package name */
    public Drawable f1477k;

    /* renamed from: l, reason: collision with root package name */
    public InterfaceC0284k f1478l;

    /* renamed from: m, reason: collision with root package name */
    public C0275b f1479m;

    /* renamed from: n, reason: collision with root package name */
    public AbstractC0276c f1480n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1481o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f1482p;

    /* renamed from: q, reason: collision with root package name */
    public final int f1483q;

    /* renamed from: r, reason: collision with root package name */
    public int f1484r;

    /* renamed from: s, reason: collision with root package name */
    public final int f1485s;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f1481o = h();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3066c, 0, 0);
        this.f1483q = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f1485s = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f1484r = -1;
        setSaveEnabled(false);
    }

    @Override // m.y
    public final void a(C0287n c0287n) {
        this.i = c0287n;
        setIcon(c0287n.getIcon());
        setTitle(c0287n.getTitleCondensed());
        setId(c0287n.f4232a);
        setVisibility(c0287n.isVisible() ? 0 : 8);
        setEnabled(c0287n.isEnabled());
        if (c0287n.hasSubMenu() && this.f1479m == null) {
            this.f1479m = new C0275b(this);
        }
    }

    @Override // n.InterfaceC0322m
    public final boolean b() {
        return !TextUtils.isEmpty(getText()) && this.i.getIcon() == null;
    }

    @Override // n.InterfaceC0322m
    public final boolean c() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // m.y
    public C0287n getItemData() {
        return this.i;
    }

    public final boolean h() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    public final void i() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f1476j);
        if (this.f1477k != null && ((this.i.f4254y & 4) != 4 || (!this.f1481o && !this.f1482p))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        setText(z4 ? this.f1476j : null);
        CharSequence charSequence = this.i.f4246q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z4 ? null : this.i.e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.i.f4247r;
        if (TextUtils.isEmpty(charSequence2)) {
            k1.a(this, z4 ? null : this.i.e);
        } else {
            k1.a(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        InterfaceC0284k interfaceC0284k = this.f1478l;
        if (interfaceC0284k != null) {
            interfaceC0284k.c(this.i);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1481o = h();
        i();
    }

    @Override // n.C0307e0, android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i3) {
        int i4;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i4 = this.f1484r) >= 0) {
            super.setPadding(i4, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i3);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int i5 = this.f1483q;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i5) : i5;
        if (mode != 1073741824 && i5 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i3);
        }
        if (!zIsEmpty || this.f1477k == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1477k.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C0275b c0275b;
        if (this.i.hasSubMenu() && (c0275b = this.f1479m) != null && c0275b.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f1482p != z2) {
            this.f1482p = z2;
            C0287n c0287n = this.i;
            if (c0287n != null) {
                MenuC0285l menuC0285l = c0287n.f4243n;
                menuC0285l.f4212k = true;
                menuC0285l.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1477k = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f1485s;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (intrinsicHeight * (i / intrinsicWidth));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (intrinsicWidth * (i / intrinsicHeight));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, null, null, null);
        i();
    }

    public void setItemInvoker(InterfaceC0284k interfaceC0284k) {
        this.f1478l = interfaceC0284k;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i, int i3, int i4, int i5) {
        this.f1484r = i;
        super.setPadding(i, i3, i4, i5);
    }

    public void setPopupCallback(AbstractC0276c abstractC0276c) {
        this.f1480n = abstractC0276c;
    }

    public void setTitle(CharSequence charSequence) {
        this.f1476j = charSequence;
        i();
    }
}
