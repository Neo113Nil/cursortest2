package androidx.appcompat.view.menu;

import P.C0023k;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import m.C0287n;
import m.InterfaceC0284k;
import m.MenuC0285l;
import m.z;

/* loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements InterfaceC0284k, z, AdapterView.OnItemClickListener {

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f1486c = {R.attr.background, R.attr.divider};

    /* renamed from: b, reason: collision with root package name */
    public MenuC0285l f1487b;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C0023k c0023kH = C0023k.h(context, attributeSet, f1486c, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(c0023kH.c(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(c0023kH.c(1));
        }
        c0023kH.j();
    }

    @Override // m.z
    public final void b(MenuC0285l menuC0285l) {
        this.f1487b = menuC0285l;
    }

    @Override // m.InterfaceC0284k
    public final boolean c(C0287n c0287n) {
        return this.f1487b.q(c0287n, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j3) {
        c((C0287n) getAdapter().getItem(i));
    }
}
