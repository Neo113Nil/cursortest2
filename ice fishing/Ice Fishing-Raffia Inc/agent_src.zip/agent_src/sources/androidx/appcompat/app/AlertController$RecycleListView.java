package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import g.AbstractC0131a;

/* loaded from: classes.dex */
public class AlertController$RecycleListView extends ListView {

    /* renamed from: b, reason: collision with root package name */
    public final int f1474b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1475c;

    public AlertController$RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3082u);
        this.f1475c = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, -1);
        this.f1474b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, -1);
    }
}
