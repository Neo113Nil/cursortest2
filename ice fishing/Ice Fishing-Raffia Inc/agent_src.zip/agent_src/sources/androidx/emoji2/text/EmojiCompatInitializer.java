package androidx.emoji2.text;

import C0.b;
import G1.a;
import Y.j;
import Y.k;
import Y.t;
import android.content.Context;
import androidx.lifecycle.C0078w;
import androidx.lifecycle.InterfaceC0076u;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* loaded from: classes.dex */
public class EmojiCompatInitializer implements b {
    @Override // C0.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // C0.b
    public final Object b(Context context) {
        Object objB;
        t tVar = new t(new a(context, 1));
        tVar.f1374a = 1;
        if (j.f1378k == null) {
            synchronized (j.f1377j) {
                try {
                    if (j.f1378k == null) {
                        j.f1378k = new j(tVar);
                    }
                } finally {
                }
            }
        }
        C0.a aVarC = C0.a.c(context);
        aVarC.getClass();
        synchronized (C0.a.e) {
            try {
                objB = aVarC.f278a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } finally {
            }
        }
        C0078w c0078wE = ((InterfaceC0076u) objB).e();
        c0078wE.a(new k(this, c0078wE));
        return Boolean.TRUE;
    }
}
