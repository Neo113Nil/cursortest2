package androidx.lifecycle;

import a.AbstractC0046a;
import g2.AbstractC0160y;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class I extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public o2.a f1760f;

    /* renamed from: g, reason: collision with root package name */
    public P1.g f1761g;

    /* renamed from: h, reason: collision with root package name */
    public int f1762h;
    public final /* synthetic */ o2.d i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ P1.g f1763j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public I(o2.d dVar, W1.p pVar, N1.d dVar2) {
        super(2, dVar2);
        this.i = dVar;
        this.f1763j = (P1.g) pVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((I) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [P1.g, W1.p] */
    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new I(this.i, this.f1763j, dVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v2, types: [W1.p] */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r3v3, types: [o2.a] */
    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        o2.d dVar;
        ?? r12;
        o2.a aVar;
        Throwable th;
        O1.a aVar2 = O1.a.f839b;
        int i = this.f1762h;
        try {
            if (i == 0) {
                AbstractC0046a.N(obj);
                dVar = this.i;
                this.f1760f = dVar;
                P1.g gVar = this.f1763j;
                this.f1761g = gVar;
                this.f1762h = 1;
                r12 = gVar;
                if (dVar.a(this) == aVar2) {
                    return aVar2;
                }
            } else {
                if (i != 1) {
                    if (i != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    aVar = this.f1760f;
                    try {
                        AbstractC0046a.N(obj);
                        aVar.b(null);
                        return J1.k.f632a;
                    } catch (Throwable th2) {
                        th = th2;
                        aVar.b(null);
                        throw th;
                    }
                }
                W1.p pVar = (W1.p) this.f1761g;
                ?? r3 = this.f1760f;
                AbstractC0046a.N(obj);
                dVar = r3;
                r12 = pVar;
            }
            H h3 = new H(r12, null);
            this.f1760f = dVar;
            this.f1761g = null;
            this.f1762h = 2;
            if (AbstractC0160y.a(h3, this) == aVar2) {
                return aVar2;
            }
            aVar = dVar;
            aVar.b(null);
            return J1.k.f632a;
        } catch (Throwable th3) {
            aVar = dVar;
            th = th3;
            aVar.b(null);
            throw th;
        }
    }
}
