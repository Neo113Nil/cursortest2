package androidx.lifecycle;

import a.AbstractC0046a;
import android.os.Bundle;
import java.util.Arrays;
import java.util.Map;

/* loaded from: classes.dex */
public final class U implements w0.c {

    /* renamed from: a, reason: collision with root package name */
    public final A.i f1789a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f1790b;

    /* renamed from: c, reason: collision with root package name */
    public Bundle f1791c;

    /* renamed from: d, reason: collision with root package name */
    public final J1.i f1792d;

    public U(A.i iVar, e0 e0Var) {
        X1.i.e(iVar, "savedStateRegistry");
        this.f1789a = iVar;
        this.f1792d = new J1.i(new A0.e(1, e0Var));
    }

    @Override // w0.c
    public final Bundle a() {
        Bundle bundleE = AbstractC0046a.e((J1.e[]) Arrays.copyOf(new J1.e[0], 0));
        Bundle bundle = this.f1791c;
        if (bundle != null) {
            bundleE.putAll(bundle);
        }
        for (Map.Entry entry : ((V) this.f1792d.getValue()).f1793b.entrySet()) {
            String str = (String) entry.getKey();
            Bundle bundleA = ((c0.D) ((P) entry.getValue()).f1781b.f1804f).a();
            if (!bundleA.isEmpty()) {
                X1.i.e(str, "key");
                bundleE.putBundle(str, bundleA);
            }
        }
        this.f1790b = false;
        return bundleE;
    }

    public final void b() {
        if (this.f1790b) {
            return;
        }
        Bundle bundleG = this.f1789a.g("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundleE = AbstractC0046a.e((J1.e[]) Arrays.copyOf(new J1.e[0], 0));
        Bundle bundle = this.f1791c;
        if (bundle != null) {
            bundleE.putAll(bundle);
        }
        if (bundleG != null) {
            bundleE.putAll(bundleG);
        }
        this.f1791c = bundleE;
        this.f1790b = true;
    }
}
