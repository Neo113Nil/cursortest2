package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* loaded from: classes.dex */
public final class F extends AbstractC0063g {
    final /* synthetic */ G this$0;

    public static final class a extends AbstractC0063g {
        final /* synthetic */ G this$0;

        public a(G g3) {
            this.this$0 = g3;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            X1.i.e(activity, "activity");
            this.this$0.a();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            X1.i.e(activity, "activity");
            G g3 = this.this$0;
            int i = g3.f1751b + 1;
            g3.f1751b = i;
            if (i == 1 && g3.e) {
                g3.f1755g.d(EnumC0069m.ON_START);
                g3.e = false;
            }
        }
    }

    public F(G g3) {
        this.this$0 = g3;
    }

    @Override // androidx.lifecycle.AbstractC0063g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        X1.i.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i = O.f1778c;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            X1.i.c(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((O) fragmentFindFragmentByTag).f1779b = this.this$0.i;
        }
    }

    @Override // androidx.lifecycle.AbstractC0063g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        X1.i.e(activity, "activity");
        G g3 = this.this$0;
        int i = g3.f1752c - 1;
        g3.f1752c = i;
        if (i == 0) {
            Handler handler = g3.f1754f;
            X1.i.b(handler);
            handler.postDelayed(g3.f1756h, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        X1.i.e(activity, "activity");
        E.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC0063g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        X1.i.e(activity, "activity");
        G g3 = this.this$0;
        int i = g3.f1751b - 1;
        g3.f1751b = i;
        if (i == 0 && g3.f1753d) {
            g3.f1755g.d(EnumC0069m.ON_STOP);
            g3.e = true;
        }
    }
}
