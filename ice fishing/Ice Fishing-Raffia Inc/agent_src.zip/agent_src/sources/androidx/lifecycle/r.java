package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public abstract class r {

    /* renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f1831a = new AtomicBoolean(false);
}
