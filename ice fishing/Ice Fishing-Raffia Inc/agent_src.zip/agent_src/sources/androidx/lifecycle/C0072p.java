package androidx.lifecycle;

import g2.C0156u;
import g2.InterfaceC0158w;

/* renamed from: androidx.lifecycle.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0072p implements InterfaceC0074s, InterfaceC0158w {

    /* renamed from: b, reason: collision with root package name */
    public final C0078w f1829b;

    /* renamed from: c, reason: collision with root package name */
    public final N1.i f1830c;

    public C0072p(C0078w c0078w, N1.i iVar) {
        g2.Y y2;
        X1.i.e(iVar, "coroutineContext");
        this.f1829b = c0078w;
        this.f1830c = iVar;
        if (c0078w.f1837d != EnumC0070n.f1822b || (y2 = (g2.Y) iVar.C(C0156u.f3173c)) == null) {
            return;
        }
        y2.a(null);
    }

    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) {
        C0078w c0078w = this.f1829b;
        if (c0078w.f1837d.compareTo(EnumC0070n.f1822b) <= 0) {
            c0078w.f(this);
            g2.Y y2 = (g2.Y) this.f1830c.C(C0156u.f3173c);
            if (y2 != null) {
                y2.a(null);
            }
        }
    }

    @Override // g2.InterfaceC0158w
    public final N1.i x() {
        return this.f1830c;
    }
}
