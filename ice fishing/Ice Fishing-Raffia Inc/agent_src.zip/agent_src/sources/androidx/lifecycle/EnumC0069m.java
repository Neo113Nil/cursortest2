package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* renamed from: androidx.lifecycle.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0069m {
    private static final /* synthetic */ Q1.a $ENTRIES;
    private static final /* synthetic */ EnumC0069m[] $VALUES;
    public static final C0067k Companion;
    public static final EnumC0069m ON_ANY;
    public static final EnumC0069m ON_CREATE;
    public static final EnumC0069m ON_DESTROY;
    public static final EnumC0069m ON_PAUSE;
    public static final EnumC0069m ON_RESUME;
    public static final EnumC0069m ON_START;
    public static final EnumC0069m ON_STOP;

    static {
        EnumC0069m enumC0069m = new EnumC0069m("ON_CREATE", 0);
        ON_CREATE = enumC0069m;
        EnumC0069m enumC0069m2 = new EnumC0069m("ON_START", 1);
        ON_START = enumC0069m2;
        EnumC0069m enumC0069m3 = new EnumC0069m("ON_RESUME", 2);
        ON_RESUME = enumC0069m3;
        EnumC0069m enumC0069m4 = new EnumC0069m("ON_PAUSE", 3);
        ON_PAUSE = enumC0069m4;
        EnumC0069m enumC0069m5 = new EnumC0069m("ON_STOP", 4);
        ON_STOP = enumC0069m5;
        EnumC0069m enumC0069m6 = new EnumC0069m("ON_DESTROY", 5);
        ON_DESTROY = enumC0069m6;
        EnumC0069m enumC0069m7 = new EnumC0069m("ON_ANY", 6);
        ON_ANY = enumC0069m7;
        EnumC0069m[] enumC0069mArr = {enumC0069m, enumC0069m2, enumC0069m3, enumC0069m4, enumC0069m5, enumC0069m6, enumC0069m7};
        $VALUES = enumC0069mArr;
        $ENTRIES = new Q1.b(enumC0069mArr);
        Companion = new C0067k();
    }

    public static EnumC0069m valueOf(String str) {
        return (EnumC0069m) Enum.valueOf(EnumC0069m.class, str);
    }

    public static EnumC0069m[] values() {
        return (EnumC0069m[]) $VALUES.clone();
    }

    public final EnumC0070n a() {
        switch (AbstractC0068l.f1821a[ordinal()]) {
            case 1:
            case 2:
                return EnumC0070n.f1824d;
            case 3:
            case 4:
                return EnumC0070n.e;
            case 5:
                return EnumC0070n.f1825f;
            case 6:
                return EnumC0070n.f1822b;
            case 7:
                throw new IllegalArgumentException(this + " has no target state");
            default:
                throw new C0.c();
        }
    }
}
