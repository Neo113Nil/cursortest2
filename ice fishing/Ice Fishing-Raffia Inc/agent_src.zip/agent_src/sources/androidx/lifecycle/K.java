package androidx.lifecycle;

import a.AbstractC0046a;
import g2.C0143g;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class K extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public X1.n f1770f;

    /* renamed from: g, reason: collision with root package name */
    public X1.n f1771g;

    /* renamed from: h, reason: collision with root package name */
    public int f1772h;
    public final /* synthetic */ C0078w i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0158w f1773j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ P1.g f1774k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public K(C0078w c0078w, InterfaceC0158w interfaceC0158w, W1.p pVar, N1.d dVar) {
        super(2, dVar);
        this.i = c0078w;
        this.f1773j = interfaceC0158w;
        this.f1774k = (P1.g) pVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((K) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [P1.g, W1.p] */
    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new K(this.i, this.f1773j, this.f1774k, dVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0089  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00a0  */
    /* JADX WARN: Type inference failed for: r15v0, types: [P1.g, W1.p] */
    @Override // P1.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object o(Object obj) throws Throwable {
        X1.n nVar;
        X1.n nVar2;
        g2.Y y2;
        InterfaceC0074s interfaceC0074s;
        g2.Y y3;
        InterfaceC0074s interfaceC0074s2;
        O1.a aVar = O1.a.f839b;
        int i = this.f1772h;
        J1.k kVar = J1.k.f632a;
        C0078w c0078w = this.i;
        if (i != 0) {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            nVar2 = this.f1771g;
            nVar = this.f1770f;
            try {
                AbstractC0046a.N(obj);
                y3 = (g2.Y) nVar.f1364b;
                if (y3 != null) {
                    y3.a(null);
                }
                interfaceC0074s2 = (InterfaceC0074s) nVar2.f1364b;
                if (interfaceC0074s2 != null) {
                    c0078w.f(interfaceC0074s2);
                }
                return kVar;
            } catch (Throwable th) {
                th = th;
                y2 = (g2.Y) nVar.f1364b;
                if (y2 != null) {
                    y2.a(null);
                }
                interfaceC0074s = (InterfaceC0074s) nVar2.f1364b;
                if (interfaceC0074s != null) {
                    c0078w.f(interfaceC0074s);
                }
                throw th;
            }
        }
        AbstractC0046a.N(obj);
        if (c0078w.f1837d == EnumC0070n.f1822b) {
            return kVar;
        }
        X1.n nVar3 = new X1.n();
        X1.n nVar4 = new X1.n();
        try {
            EnumC0070n enumC0070n = EnumC0070n.e;
            InterfaceC0158w interfaceC0158w = this.f1773j;
            ?? r15 = this.f1774k;
            this.f1770f = nVar3;
            this.f1771g = nVar4;
            this.f1772h = 1;
            C0143g c0143g = new C0143g(1, L1.d.M(this));
            c0143g.v();
            EnumC0069m.Companion.getClass();
            J j3 = new J(EnumC0069m.ON_START, nVar3, interfaceC0158w, C0067k.a(enumC0070n), c0143g, new o2.d(false), r15);
            nVar4.f1364b = j3;
            c0078w.a(j3);
            if (c0143g.u() == aVar) {
                return aVar;
            }
            nVar = nVar3;
            nVar2 = nVar4;
            y3 = (g2.Y) nVar.f1364b;
            if (y3 != null) {
            }
            interfaceC0074s2 = (InterfaceC0074s) nVar2.f1364b;
            if (interfaceC0074s2 != null) {
            }
            return kVar;
        } catch (Throwable th2) {
            th = th2;
            nVar = nVar3;
            nVar2 = nVar4;
            y2 = (g2.Y) nVar.f1364b;
            if (y2 != null) {
            }
            interfaceC0074s = (InterfaceC0074s) nVar2.f1364b;
            if (interfaceC0074s != null) {
            }
            throw th;
        }
    }
}
