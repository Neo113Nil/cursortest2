package androidx.lifecycle;

import android.app.Application;
import android.os.Bundle;
import e1.C0123e;
import g0.C0134c;
import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class W implements b0 {

    /* renamed from: a, reason: collision with root package name */
    public final Application f1794a;

    /* renamed from: b, reason: collision with root package name */
    public final a0 f1795b;

    /* renamed from: c, reason: collision with root package name */
    public final Bundle f1796c;

    /* renamed from: d, reason: collision with root package name */
    public final C0078w f1797d;
    public final A.i e;

    public W(Application application, w0.d dVar, Bundle bundle) {
        a0 a0Var;
        X1.i.e(dVar, "owner");
        this.e = dVar.b();
        this.f1797d = dVar.e();
        this.f1796c = bundle;
        this.f1794a = application;
        if (application != null) {
            if (a0.f1805c == null) {
                a0.f1805c = new a0(application);
            }
            a0Var = a0.f1805c;
            X1.i.b(a0Var);
        } else {
            a0Var = new a0(null);
        }
        this.f1795b = a0Var;
    }

    @Override // androidx.lifecycle.b0
    public final Y a(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return d(canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Override // androidx.lifecycle.b0
    public final Y b(X1.e eVar, C0134c c0134c) {
        return c(L1.d.F(eVar), c0134c);
    }

    @Override // androidx.lifecycle.b0
    public final Y c(Class cls, C0134c c0134c) {
        C0123e c0123e = T.e;
        LinkedHashMap linkedHashMap = c0134c.f3089a;
        String str = (String) linkedHashMap.get(c0123e);
        if (str == null) {
            throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
        }
        if (linkedHashMap.get(T.f1785a) == null || linkedHashMap.get(T.f1786b) == null) {
            if (this.f1797d != null) {
                return d(str, cls);
            }
            throw new IllegalStateException("SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel.");
        }
        Application application = (Application) linkedHashMap.get(a0.f1806d);
        boolean zIsAssignableFrom = AbstractC0057a.class.isAssignableFrom(cls);
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? X.a(cls, X.f1799b) : X.a(cls, X.f1798a);
        return constructorA == null ? this.f1795b.c(cls, c0134c) : (!zIsAssignableFrom || application == null) ? X.b(cls, constructorA, T.c(c0134c)) : X.b(cls, constructorA, application, T.c(c0134c));
    }

    public final Y d(String str, Class cls) throws NoSuchMethodException, SecurityException {
        C0078w c0078w = this.f1797d;
        if (c0078w == null) {
            throw new UnsupportedOperationException("SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
        }
        boolean zIsAssignableFrom = AbstractC0057a.class.isAssignableFrom(cls);
        Application application = this.f1794a;
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? X.a(cls, X.f1799b) : X.a(cls, X.f1798a);
        if (constructorA == null) {
            if (application != null) {
                return this.f1795b.a(cls);
            }
            if (c0.f1812a == null) {
                c0.f1812a = new c0();
            }
            X1.i.b(c0.f1812a);
            return b1.e.s(cls);
        }
        A.i iVar = this.e;
        X1.i.b(iVar);
        Q qB = T.b(iVar, c0078w, str, this.f1796c);
        P p2 = qB.f1783c;
        Y yB = (!zIsAssignableFrom || application == null) ? X.b(cls, constructorA, p2) : X.b(cls, constructorA, application, p2);
        yB.a("androidx.lifecycle.savedstate.vm.tag", qB);
        return yB;
    }
}
