package androidx.lifecycle;

import java.util.Iterator;

/* loaded from: classes.dex */
public abstract class Y {

    /* renamed from: a, reason: collision with root package name */
    public final h0.b f1800a = new h0.b();

    public final void a(String str, AutoCloseable autoCloseable) {
        AutoCloseable autoCloseable2;
        h0.b bVar = this.f1800a;
        if (bVar != null) {
            if (bVar.f3395d) {
                h0.b.a(autoCloseable);
                return;
            }
            synchronized (bVar.f3392a) {
                autoCloseable2 = (AutoCloseable) bVar.f3393b.put(str, autoCloseable);
            }
            h0.b.a(autoCloseable2);
        }
    }

    /* JADX WARN: Failed to analyze thrown exceptions
    java.util.ConcurrentModificationException
    	at java.base/java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1095)
    	at java.base/java.util.ArrayList$Itr.next(ArrayList.java:1049)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:118)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:69)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.checkInsn(MethodThrowsVisitor.java:179)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:132)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:69)
     */
    public final void b() {
        h0.b bVar = this.f1800a;
        if (bVar != null && !bVar.f3395d) {
            bVar.f3395d = true;
            synchronized (bVar.f3392a) {
                try {
                    Iterator it = bVar.f3393b.values().iterator();
                    while (it.hasNext()) {
                        h0.b.a((AutoCloseable) it.next());
                    }
                    Iterator it2 = bVar.f3394c.iterator();
                    while (it2.hasNext()) {
                        h0.b.a((AutoCloseable) it2.next());
                    }
                    bVar.f3394c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        d();
    }

    public final AutoCloseable c(String str) {
        AutoCloseable autoCloseable;
        h0.b bVar = this.f1800a;
        if (bVar == null) {
            return null;
        }
        synchronized (bVar.f3392a) {
            autoCloseable = (AutoCloseable) bVar.f3393b.get(str);
        }
        return autoCloseable;
    }

    public void d() {
    }
}
