package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* renamed from: androidx.lifecycle.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0070n {

    /* renamed from: b, reason: collision with root package name */
    public static final EnumC0070n f1822b;

    /* renamed from: c, reason: collision with root package name */
    public static final EnumC0070n f1823c;

    /* renamed from: d, reason: collision with root package name */
    public static final EnumC0070n f1824d;
    public static final EnumC0070n e;

    /* renamed from: f, reason: collision with root package name */
    public static final EnumC0070n f1825f;

    /* renamed from: g, reason: collision with root package name */
    public static final /* synthetic */ EnumC0070n[] f1826g;

    static {
        EnumC0070n enumC0070n = new EnumC0070n("DESTROYED", 0);
        f1822b = enumC0070n;
        EnumC0070n enumC0070n2 = new EnumC0070n("INITIALIZED", 1);
        f1823c = enumC0070n2;
        EnumC0070n enumC0070n3 = new EnumC0070n("CREATED", 2);
        f1824d = enumC0070n3;
        EnumC0070n enumC0070n4 = new EnumC0070n("STARTED", 3);
        e = enumC0070n4;
        EnumC0070n enumC0070n5 = new EnumC0070n("RESUMED", 4);
        f1825f = enumC0070n5;
        f1826g = new EnumC0070n[]{enumC0070n, enumC0070n2, enumC0070n3, enumC0070n4, enumC0070n5};
    }

    public static EnumC0070n valueOf(String str) {
        return (EnumC0070n) Enum.valueOf(EnumC0070n.class, str);
    }

    public static EnumC0070n[] values() {
        return (EnumC0070n[]) f1826g.clone();
    }
}
