package androidx.lifecycle;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.kortosi.kluani.qorzanis.ui.common.TrickSigilView;
import g0.AbstractC0133b;
import java.util.LinkedHashMap;
import java.util.Map;

/* loaded from: classes.dex */
public final class Z implements J1.b {

    /* renamed from: b, reason: collision with root package name */
    public final Object f1801b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f1802c;

    /* renamed from: d, reason: collision with root package name */
    public final Object f1803d;
    public final Object e;

    /* renamed from: f, reason: collision with root package name */
    public Object f1804f;

    public Z(Map map) {
        X1.i.e(map, "initialState");
        this.f1801b = new LinkedHashMap(map);
        this.f1802c = new LinkedHashMap();
        this.f1803d = new LinkedHashMap();
        this.e = new LinkedHashMap();
        this.f1804f = new c0.D(1, this);
    }

    public void a(Object obj, String str) {
        X1.i.e(str, "key");
        ((LinkedHashMap) this.f1801b).put(str, obj);
        j2.u uVar = (j2.u) ((LinkedHashMap) this.f1803d).get(str);
        if (uVar != null) {
            ((j2.L) uVar).k(obj);
        }
        j2.u uVar2 = (j2.u) ((LinkedHashMap) this.e).get(str);
        if (uVar2 != null) {
            ((j2.L) uVar2).k(obj);
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [W1.a, X1.j] */
    /* JADX WARN: Type inference failed for: r2v1, types: [W1.a, X1.j] */
    @Override // J1.b
    public Object getValue() {
        Y y2 = (Y) this.f1804f;
        if (y2 != null) {
            return y2;
        }
        d0 d0Var = (d0) ((X1.j) this.f1802c).a();
        b0 b0Var = (b0) ((W1.a) this.e).a();
        AbstractC0133b abstractC0133b = (AbstractC0133b) ((X1.j) this.f1803d).a();
        X1.i.e(d0Var, "store");
        X1.i.e(b0Var, "factory");
        X1.i.e(abstractC0133b, "extras");
        C.k kVar = new C.k(d0Var, b0Var, abstractC0133b);
        X1.e eVar = (X1.e) this.f1801b;
        String strB = eVar.b();
        if (strB == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        Y yK = kVar.k(eVar, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB));
        this.f1804f = yK;
        return yK;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Z(X1.e eVar, W1.a aVar, W1.a aVar2, W1.a aVar3) {
        this.f1801b = eVar;
        this.f1802c = (X1.j) aVar;
        this.e = aVar2;
        this.f1803d = (X1.j) aVar3;
    }

    public Z(LinearLayout linearLayout, ImageView imageView, TextView textView, TextView textView2, TrickSigilView trickSigilView) {
        this.f1801b = linearLayout;
        this.f1802c = imageView;
        this.f1803d = textView;
        this.e = textView2;
        this.f1804f = trickSigilView;
    }
}
