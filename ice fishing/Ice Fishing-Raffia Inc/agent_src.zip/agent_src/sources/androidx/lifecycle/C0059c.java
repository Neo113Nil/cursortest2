package androidx.lifecycle;

import java.lang.reflect.Method;

/* renamed from: androidx.lifecycle.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0059c {

    /* renamed from: a, reason: collision with root package name */
    public final int f1810a;

    /* renamed from: b, reason: collision with root package name */
    public final Method f1811b;

    public C0059c(int i, Method method) throws SecurityException {
        this.f1810a = i;
        this.f1811b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0059c)) {
            return false;
        }
        C0059c c0059c = (C0059c) obj;
        return this.f1810a == c0059c.f1810a && this.f1811b.getName().equals(c0059c.f1811b.getName());
    }

    public final int hashCode() {
        return this.f1811b.getName().hashCode() + (this.f1810a * 31);
    }
}
