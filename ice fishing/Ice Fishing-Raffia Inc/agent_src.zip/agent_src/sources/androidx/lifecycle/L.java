package androidx.lifecycle;

import a.AbstractC0046a;
import g2.AbstractC0160y;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class L extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f1775f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f1776g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0078w f1777h;
    public final /* synthetic */ P1.g i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public L(C0078w c0078w, W1.p pVar, N1.d dVar) {
        super(2, dVar);
        this.f1777h = c0078w;
        this.i = (P1.g) pVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((L) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [P1.g, W1.p] */
    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        L l3 = new L(this.f1777h, this.i, dVar);
        l3.f1776g = obj;
        return l3;
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [P1.g, W1.p] */
    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f1775f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f1776g;
            n2.d dVar = g2.F.f3104a;
            h2.e eVar = l2.o.f4111a.f3520g;
            K k3 = new K(this.f1777h, interfaceC0158w, this.i, null);
            this.f1775f = 1;
            if (AbstractC0160y.s(eVar, k3, this) == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
