package androidx.lifecycle;

import K1.C0011b;
import a.AbstractC0046a;
import android.app.Application;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.dex */
public abstract class X {

    /* renamed from: a, reason: collision with root package name */
    public static final List f1798a = K1.m.P(Application.class, P.class);

    /* renamed from: b, reason: collision with root package name */
    public static final List f1799b = AbstractC0046a.H(P.class);

    public static final Constructor a(Class cls, List list) {
        X1.i.e(list, "signature");
        C0011b c0011bD = X1.q.d(cls.getConstructors());
        while (c0011bD.hasNext()) {
            Constructor constructor = (Constructor) c0011bD.next();
            Class<?>[] parameterTypes = constructor.getParameterTypes();
            X1.i.d(parameterTypes, "getParameterTypes(...)");
            List listU = K1.j.U(parameterTypes);
            if (list.equals(listU)) {
                return constructor;
            }
            if (list.size() == listU.size() && listU.containsAll(list)) {
                throw new UnsupportedOperationException("Class " + cls.getSimpleName() + " must have parameters in the proper order: " + list);
            }
        }
        return null;
    }

    public static final Y b(Class cls, Constructor constructor, Object... objArr) {
        try {
            return (Y) constructor.newInstance(Arrays.copyOf(objArr, objArr.length));
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Failed to access " + cls, e);
        } catch (InstantiationException e3) {
            throw new RuntimeException("A " + cls + " cannot be instantiated.", e3);
        } catch (InvocationTargetException e4) {
            throw new RuntimeException("An exception happened in constructor of " + cls, e4.getCause());
        }
    }
}
