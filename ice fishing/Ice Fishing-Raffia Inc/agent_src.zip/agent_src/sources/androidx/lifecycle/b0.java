package androidx.lifecycle;

import g0.C0134c;

/* loaded from: classes.dex */
public interface b0 {
    default Y a(Class cls) {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    default Y b(X1.e eVar, C0134c c0134c) {
        return c(L1.d.F(eVar), c0134c);
    }

    default Y c(Class cls, C0134c c0134c) {
        return a(cls);
    }
}
