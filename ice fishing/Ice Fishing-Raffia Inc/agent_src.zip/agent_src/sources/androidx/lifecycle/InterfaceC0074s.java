package androidx.lifecycle;

/* renamed from: androidx.lifecycle.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0074s extends InterfaceC0075t {
    void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m);
}
