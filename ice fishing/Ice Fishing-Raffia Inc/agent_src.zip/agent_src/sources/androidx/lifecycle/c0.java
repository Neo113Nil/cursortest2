package androidx.lifecycle;

import g0.C0134c;

/* loaded from: classes.dex */
public class c0 implements b0 {

    /* renamed from: a, reason: collision with root package name */
    public static c0 f1812a;

    @Override // androidx.lifecycle.b0
    public Y a(Class cls) {
        return b1.e.s(cls);
    }

    @Override // androidx.lifecycle.b0
    public final Y b(X1.e eVar, C0134c c0134c) {
        return c(L1.d.F(eVar), c0134c);
    }

    @Override // androidx.lifecycle.b0
    public Y c(Class cls, C0134c c0134c) {
        return a(cls);
    }
}
