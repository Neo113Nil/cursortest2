package androidx.lifecycle;

import g2.AbstractC0160y;
import g2.C0143g;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class J implements InterfaceC0074s {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ EnumC0069m f1764b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ X1.n f1765c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0158w f1766d;
    public final /* synthetic */ EnumC0069m e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0143g f1767f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ o2.d f1768g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ P1.g f1769h;

    /* JADX WARN: Multi-variable type inference failed */
    public J(EnumC0069m enumC0069m, X1.n nVar, InterfaceC0158w interfaceC0158w, EnumC0069m enumC0069m2, C0143g c0143g, o2.d dVar, W1.p pVar) {
        this.f1764b = enumC0069m;
        this.f1765c = nVar;
        this.f1766d = interfaceC0158w;
        this.e = enumC0069m2;
        this.f1767f = c0143g;
        this.f1768g = dVar;
        this.f1769h = (P1.g) pVar;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [P1.g, W1.p] */
    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) {
        X1.n nVar = this.f1765c;
        if (enumC0069m == this.f1764b) {
            nVar.f1364b = AbstractC0160y.l(this.f1766d, null, 0, new I(this.f1768g, this.f1769h, null), 3);
            return;
        }
        if (enumC0069m == this.e) {
            g2.Y y2 = (g2.Y) nVar.f1364b;
            if (y2 != null) {
                y2.a(null);
            }
            nVar.f1364b = null;
        }
        if (enumC0069m == EnumC0069m.ON_DESTROY) {
            this.f1767f.c(J1.k.f632a);
        }
    }
}
