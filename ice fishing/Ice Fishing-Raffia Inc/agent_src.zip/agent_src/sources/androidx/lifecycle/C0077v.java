package androidx.lifecycle;

/* renamed from: androidx.lifecycle.v, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0077v {

    /* renamed from: a, reason: collision with root package name */
    public EnumC0070n f1832a;

    /* renamed from: b, reason: collision with root package name */
    public InterfaceC0074s f1833b;

    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) {
        EnumC0070n enumC0070nA = enumC0069m.a();
        EnumC0070n enumC0070n = this.f1832a;
        X1.i.e(enumC0070n, "state1");
        if (enumC0070nA.compareTo(enumC0070n) < 0) {
            enumC0070n = enumC0070nA;
        }
        this.f1832a = enumC0070n;
        this.f1833b.a(interfaceC0076u, enumC0069m);
        this.f1832a = enumC0070nA;
    }
}
