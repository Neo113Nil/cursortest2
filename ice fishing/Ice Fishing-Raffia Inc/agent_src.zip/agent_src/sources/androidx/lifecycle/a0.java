package androidx.lifecycle;

import android.app.Application;
import e1.C0123e;
import g0.C0134c;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public final class a0 extends c0 {

    /* renamed from: c, reason: collision with root package name */
    public static a0 f1805c;

    /* renamed from: d, reason: collision with root package name */
    public static final C0123e f1806d = new C0123e();

    /* renamed from: b, reason: collision with root package name */
    public final Application f1807b;

    public a0(Application application) {
        this.f1807b = application;
    }

    @Override // androidx.lifecycle.c0, androidx.lifecycle.b0
    public final Y a(Class cls) {
        Application application = this.f1807b;
        if (application != null) {
            return d(cls, application);
        }
        throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
    }

    @Override // androidx.lifecycle.c0, androidx.lifecycle.b0
    public final Y c(Class cls, C0134c c0134c) {
        if (this.f1807b != null) {
            return a(cls);
        }
        Application application = (Application) c0134c.f3089a.get(f1806d);
        if (application != null) {
            return d(cls, application);
        }
        if (AbstractC0057a.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
        }
        return b1.e.s(cls);
    }

    public final Y d(Class cls, Application application) {
        if (!AbstractC0057a.class.isAssignableFrom(cls)) {
            return b1.e.s(cls);
        }
        try {
            Y y2 = (Y) cls.getConstructor(Application.class).newInstance(application);
            X1.i.b(y2);
            return y2;
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Cannot create an instance of " + cls, e);
        } catch (InstantiationException e3) {
            throw new RuntimeException("Cannot create an instance of " + cls, e3);
        } catch (NoSuchMethodException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        } catch (InvocationTargetException e5) {
            throw new RuntimeException("Cannot create an instance of " + cls, e5);
        }
    }
}
