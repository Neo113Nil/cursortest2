package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

/* renamed from: androidx.lifecycle.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0073q extends AbstractC0063g {
    @Override // androidx.lifecycle.AbstractC0063g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        X1.i.e(activity, "activity");
        int i = O.f1778c;
        M.b(activity);
    }
}
