package androidx.lifecycle;

import android.os.Handler;

/* loaded from: classes.dex */
public final class G implements InterfaceC0076u {

    /* renamed from: j, reason: collision with root package name */
    public static final G f1750j = new G();

    /* renamed from: b, reason: collision with root package name */
    public int f1751b;

    /* renamed from: c, reason: collision with root package name */
    public int f1752c;

    /* renamed from: f, reason: collision with root package name */
    public Handler f1754f;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1753d = true;
    public boolean e = true;

    /* renamed from: g, reason: collision with root package name */
    public final C0078w f1755g = new C0078w(this);

    /* renamed from: h, reason: collision with root package name */
    public final E.a f1756h = new E.a(5, this);
    public final A0.f i = new A0.f(20, this);

    public final void a() {
        int i = this.f1752c + 1;
        this.f1752c = i;
        if (i == 1) {
            if (this.f1753d) {
                this.f1755g.d(EnumC0069m.ON_RESUME);
                this.f1753d = false;
            } else {
                Handler handler = this.f1754f;
                X1.i.b(handler);
                handler.removeCallbacks(this.f1756h);
            }
        }
    }

    @Override // androidx.lifecycle.InterfaceC0076u
    public final C0078w e() {
        return this.f1755g;
    }
}
