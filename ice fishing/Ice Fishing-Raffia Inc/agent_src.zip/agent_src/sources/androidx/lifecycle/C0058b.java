package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0058b {

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f1808a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f1809b;

    public C0058b(HashMap map) {
        this.f1809b = map;
        for (Map.Entry entry : map.entrySet()) {
            EnumC0069m enumC0069m = (EnumC0069m) entry.getValue();
            List arrayList = (List) this.f1808a.get(enumC0069m);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f1808a.put(enumC0069m, arrayList);
            }
            arrayList.add((C0059c) entry.getKey());
        }
    }

    public static void a(List list, InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m, InterfaceC0075t interfaceC0075t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                C0059c c0059c = (C0059c) list.get(size);
                c0059c.getClass();
                try {
                    int i = c0059c.f1810a;
                    Method method = c0059c.f1811b;
                    if (i == 0) {
                        method.invoke(interfaceC0075t, null);
                    } else if (i == 1) {
                        method.invoke(interfaceC0075t, interfaceC0076u);
                    } else if (i == 2) {
                        method.invoke(interfaceC0075t, interfaceC0076u, enumC0069m);
                    }
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e3) {
                    throw new RuntimeException("Failed to call observer method", e3.getCause());
                }
            }
        }
    }
}
