package androidx.lifecycle;

import c0.AbstractComponentCallbacksC0110w;

/* loaded from: classes.dex */
public abstract class A {

    /* renamed from: b, reason: collision with root package name */
    public final C f1739b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1740c;

    /* renamed from: d, reason: collision with root package name */
    public int f1741d = -1;
    public final /* synthetic */ B e;

    public A(B b3, C c3) {
        this.e = b3;
        this.f1739b = c3;
    }

    public final void b(boolean z2) {
        if (z2 == this.f1740c) {
            return;
        }
        this.f1740c = z2;
        int i = z2 ? 1 : -1;
        B b3 = this.e;
        int i3 = b3.f1745c;
        b3.f1745c = i + i3;
        if (!b3.f1746d) {
            b3.f1746d = true;
            while (true) {
                try {
                    int i4 = b3.f1745c;
                    if (i3 == i4) {
                        break;
                    } else {
                        i3 = i4;
                    }
                } finally {
                    b3.f1746d = false;
                }
            }
        }
        if (this.f1740c) {
            b3.c(this);
        }
    }

    public void c() {
    }

    public boolean d(AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w) {
        return false;
    }

    public abstract boolean e();
}
