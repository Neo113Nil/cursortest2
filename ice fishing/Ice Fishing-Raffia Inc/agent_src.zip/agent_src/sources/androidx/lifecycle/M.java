package androidx.lifecycle;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;
import androidx.lifecycle.O;

/* loaded from: classes.dex */
public abstract class M {
    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, EnumC0069m enumC0069m) {
        C0078w c0078wE;
        X1.i.e(activity, "activity");
        X1.i.e(enumC0069m, "event");
        if (!(activity instanceof InterfaceC0076u) || (c0078wE = ((InterfaceC0076u) activity).e()) == null) {
            return;
        }
        c0078wE.d(enumC0069m);
    }

    public static void b(Activity activity) {
        X1.i.e(activity, "activity");
        if (Build.VERSION.SDK_INT >= 29) {
            O.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new O.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new O(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
