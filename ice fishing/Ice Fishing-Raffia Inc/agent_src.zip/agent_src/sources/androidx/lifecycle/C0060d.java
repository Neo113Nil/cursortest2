package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* renamed from: androidx.lifecycle.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0060d {

    /* renamed from: c, reason: collision with root package name */
    public static final C0060d f1813c = new C0060d();

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f1814a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f1815b = new HashMap();

    public static void b(HashMap map, C0059c c0059c, EnumC0069m enumC0069m, Class cls) {
        EnumC0069m enumC0069m2 = (EnumC0069m) map.get(c0059c);
        if (enumC0069m2 == null || enumC0069m == enumC0069m2) {
            if (enumC0069m2 == null) {
                map.put(c0059c, enumC0069m);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c0059c.f1811b.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + enumC0069m2 + ", new value " + enumC0069m);
    }

    public final C0058b a(Class cls, Method[] methodArr) throws SecurityException {
        int i;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        HashMap map2 = this.f1814a;
        if (superclass != null) {
            C0058b c0058bA = (C0058b) map2.get(superclass);
            if (c0058bA == null) {
                c0058bA = a(superclass, null);
            }
            map.putAll(c0058bA.f1809b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            C0058b c0058bA2 = (C0058b) map2.get(cls2);
            if (c0058bA2 == null) {
                c0058bA2 = a(cls2, null);
            }
            for (Map.Entry entry : c0058bA2.f1809b.entrySet()) {
                b(map, (C0059c) entry.getKey(), (EnumC0069m) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
            }
        }
        boolean z2 = false;
        for (Method method : methodArr) {
            D d3 = (D) method.getAnnotation(D.class);
            if (d3 != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else {
                    if (!InterfaceC0076u.class.isAssignableFrom(parameterTypes[0])) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i = 1;
                }
                EnumC0069m enumC0069mValue = d3.value();
                if (parameterTypes.length > 1) {
                    if (!EnumC0069m.class.isAssignableFrom(parameterTypes[1])) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (enumC0069mValue != EnumC0069m.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                b(map, new C0059c(i, method), enumC0069mValue, cls);
                z2 = true;
            }
        }
        C0058b c0058b = new C0058b(map);
        map2.put(cls, c0058b);
        this.f1815b.put(cls, Boolean.valueOf(z2));
        return c0058b;
    }
}
