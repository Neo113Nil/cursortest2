package androidx.lifecycle;

import android.os.Looper;
import java.util.Map;
import o.C0356a;
import p.C0364d;
import p.C0366f;

/* loaded from: classes.dex */
public class B {

    /* renamed from: j, reason: collision with root package name */
    public static final Object f1742j = new Object();

    /* renamed from: a, reason: collision with root package name */
    public final Object f1743a;

    /* renamed from: b, reason: collision with root package name */
    public final C0366f f1744b = new C0366f();

    /* renamed from: c, reason: collision with root package name */
    public int f1745c = 0;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1746d;
    public volatile Object e;

    /* renamed from: f, reason: collision with root package name */
    public volatile Object f1747f;

    /* renamed from: g, reason: collision with root package name */
    public int f1748g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1749h;
    public boolean i;

    public B() {
        Object obj = f1742j;
        this.f1747f = obj;
        this.e = obj;
        this.f1748g = -1;
    }

    public static void a(String str) {
        C0356a.G().f4713b.getClass();
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(H.e.i("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(A a3) {
        if (a3.f1740c) {
            if (!a3.e()) {
                a3.b(false);
                return;
            }
            int i = a3.f1741d;
            int i3 = this.f1748g;
            if (i >= i3) {
                return;
            }
            a3.f1741d = i3;
            a3.f1739b.b(this.e);
        }
    }

    public final void c(A a3) {
        if (this.f1749h) {
            this.i = true;
            return;
        }
        this.f1749h = true;
        do {
            this.i = false;
            if (a3 != null) {
                b(a3);
                a3 = null;
            } else {
                C0366f c0366f = this.f1744b;
                c0366f.getClass();
                C0364d c0364d = new C0364d(c0366f);
                c0366f.f4779d.put(c0364d, Boolean.FALSE);
                while (c0364d.hasNext()) {
                    b((A) ((Map.Entry) c0364d.next()).getValue());
                    if (this.i) {
                        break;
                    }
                }
            }
        } while (this.i);
        this.f1749h = false;
    }

    public final void d(Object obj) {
        a("setValue");
        this.f1748g++;
        this.e = obj;
        c(null);
    }
}
