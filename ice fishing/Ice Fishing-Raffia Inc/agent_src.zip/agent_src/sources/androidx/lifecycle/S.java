package androidx.lifecycle;

import g0.C0134c;

/* loaded from: classes.dex */
public final class S implements b0 {
    @Override // androidx.lifecycle.b0
    public final Y b(X1.e eVar, C0134c c0134c) {
        return new V();
    }
}
