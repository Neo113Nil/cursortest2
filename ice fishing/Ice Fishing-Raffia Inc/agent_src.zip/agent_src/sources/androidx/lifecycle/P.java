package androidx.lifecycle;

import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class P {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f1780a;

    /* renamed from: b, reason: collision with root package name */
    public final Z f1781b;

    public P(L1.h hVar) {
        this.f1780a = new LinkedHashMap();
        this.f1781b = new Z(hVar);
    }

    public final Object a(String str) {
        Object objJ;
        Z z2 = this.f1781b;
        LinkedHashMap linkedHashMap = (LinkedHashMap) z2.f1801b;
        try {
            j2.u uVar = (j2.u) ((LinkedHashMap) z2.e).get(str);
            return (uVar == null || (objJ = ((j2.L) uVar).j()) == null) ? linkedHashMap.get(str) : objJ;
        } catch (ClassCastException unused) {
            linkedHashMap.remove(str);
            ((LinkedHashMap) z2.f1803d).remove(str);
            return null;
        }
    }

    public P() {
        this.f1780a = new LinkedHashMap();
        this.f1781b = new Z(K1.v.f683b);
    }
}
