package androidx.lifecycle;

/* renamed from: androidx.lifecycle.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0067k {
    public static EnumC0069m a(EnumC0070n enumC0070n) {
        X1.i.e(enumC0070n, "state");
        int iOrdinal = enumC0070n.ordinal();
        if (iOrdinal == 2) {
            return EnumC0069m.ON_DESTROY;
        }
        if (iOrdinal == 3) {
            return EnumC0069m.ON_STOP;
        }
        if (iOrdinal != 4) {
            return null;
        }
        return EnumC0069m.ON_PAUSE;
    }

    public static EnumC0069m b(EnumC0070n enumC0070n) {
        X1.i.e(enumC0070n, "state");
        int iOrdinal = enumC0070n.ordinal();
        if (iOrdinal == 1) {
            return EnumC0069m.ON_CREATE;
        }
        if (iOrdinal == 2) {
            return EnumC0069m.ON_START;
        }
        if (iOrdinal != 3) {
            return null;
        }
        return EnumC0069m.ON_RESUME;
    }
}
