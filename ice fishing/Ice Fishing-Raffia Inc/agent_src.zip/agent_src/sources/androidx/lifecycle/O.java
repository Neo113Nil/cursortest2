package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* loaded from: classes.dex */
public class O extends Fragment {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f1778c = 0;

    /* renamed from: b, reason: collision with root package name */
    public A0.f f1779b;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final N Companion = new N();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            X1.i.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            X1.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            X1.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            X1.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            X1.i.e(activity, "activity");
            int i = O.f1778c;
            M.a(activity, EnumC0069m.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            X1.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            X1.i.e(activity, "activity");
            X1.i.e(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            X1.i.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            X1.i.e(activity, "activity");
        }
    }

    public final void a(EnumC0069m enumC0069m) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            X1.i.d(activity, "getActivity(...)");
            M.a(activity, enumC0069m);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(EnumC0069m.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(EnumC0069m.ON_DESTROY);
        this.f1779b = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(EnumC0069m.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        A0.f fVar = this.f1779b;
        if (fVar != null) {
            ((G) fVar.f224c).a();
        }
        a(EnumC0069m.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        A0.f fVar = this.f1779b;
        if (fVar != null) {
            G g3 = (G) fVar.f224c;
            int i = g3.f1751b + 1;
            g3.f1751b = i;
            if (i == 1 && g3.e) {
                g3.f1755g.d(EnumC0069m.ON_START);
                g3.e = false;
            }
        }
        a(EnumC0069m.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(EnumC0069m.ON_STOP);
    }
}
