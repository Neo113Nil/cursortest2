package androidx.lifecycle;

import g0.C0134c;

/* renamed from: androidx.lifecycle.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0065i {
    C0134c a();

    b0 g();
}
