package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements C0.b {
    @Override // C0.b
    public final List a() {
        return K1.u.f682b;
    }

    @Override // C0.b
    public final Object b(Context context) {
        X1.i.e(context, "context");
        C0.a aVarC = C0.a.c(context);
        X1.i.d(aVarC, "getInstance(...)");
        if (!aVarC.f279b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!r.f1831a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            X1.i.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new C0073q());
        }
        G g3 = G.f1750j;
        g3.getClass();
        g3.f1754f = new Handler();
        g3.f1755g.d(EnumC0069m.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        X1.i.c(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new F(g3));
        return g3;
    }
}
