package androidx.lifecycle;

import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import o.C0356a;
import p.C0361a;
import p.C0362b;
import p.C0363c;
import p.C0364d;
import w0.C0476a;

/* renamed from: androidx.lifecycle.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0078w {

    /* renamed from: a, reason: collision with root package name */
    public A0.f f1834a = new A0.f(19);

    /* renamed from: b, reason: collision with root package name */
    public final boolean f1835b = true;

    /* renamed from: c, reason: collision with root package name */
    public C0361a f1836c = new C0361a();

    /* renamed from: d, reason: collision with root package name */
    public EnumC0070n f1837d;
    public final WeakReference e;

    /* renamed from: f, reason: collision with root package name */
    public int f1838f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1839g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1840h;
    public final ArrayList i;

    /* renamed from: j, reason: collision with root package name */
    public final j2.L f1841j;

    public C0078w(InterfaceC0076u interfaceC0076u) {
        EnumC0070n enumC0070n = EnumC0070n.f1823c;
        this.f1837d = enumC0070n;
        this.i = new ArrayList();
        this.e = new WeakReference(interfaceC0076u);
        this.f1841j = new j2.L(enumC0070n);
    }

    public final void a(InterfaceC0075t interfaceC0075t) {
        InterfaceC0074s c0062f;
        InterfaceC0076u interfaceC0076u;
        ArrayList arrayList = this.i;
        int i = 2;
        Object obj = null;
        X1.i.e(interfaceC0075t, "observer");
        c("addObserver");
        EnumC0070n enumC0070n = this.f1837d;
        EnumC0070n enumC0070n2 = EnumC0070n.f1822b;
        if (enumC0070n != enumC0070n2) {
            enumC0070n2 = EnumC0070n.f1823c;
        }
        C0077v c0077v = new C0077v();
        HashMap map = AbstractC0079x.f1842a;
        boolean z2 = interfaceC0075t instanceof InterfaceC0074s;
        boolean z3 = interfaceC0075t instanceof Y.k;
        if (z2 && z3) {
            c0062f = new C0062f((Y.k) interfaceC0075t, (InterfaceC0074s) interfaceC0075t);
        } else if (z3) {
            c0062f = new C0062f((Y.k) interfaceC0075t, (InterfaceC0074s) null);
        } else if (z2) {
            c0062f = (InterfaceC0074s) interfaceC0075t;
        } else {
            Class<?> cls = interfaceC0075t.getClass();
            if (AbstractC0079x.b(cls) == 2) {
                Object obj2 = AbstractC0079x.f1843b.get(cls);
                X1.i.b(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    AbstractC0079x.a((Constructor) list.get(0), interfaceC0075t);
                    throw null;
                }
                int size = list.size();
                InterfaceC0064h[] interfaceC0064hArr = new InterfaceC0064h[size];
                if (size > 0) {
                    AbstractC0079x.a((Constructor) list.get(0), interfaceC0075t);
                    throw null;
                }
                c0062f = new C0476a(i, interfaceC0064hArr);
            } else {
                c0062f = new C0062f(interfaceC0075t);
            }
        }
        c0077v.f1833b = c0062f;
        c0077v.f1832a = enumC0070n2;
        C0361a c0361a = this.f1836c;
        C0363c c0363cA = c0361a.a(interfaceC0075t);
        if (c0363cA != null) {
            obj = c0363cA.f4772c;
        } else {
            HashMap map2 = c0361a.f4767f;
            C0363c c0363c = new C0363c(interfaceC0075t, c0077v);
            c0361a.e++;
            C0363c c0363c2 = c0361a.f4778c;
            if (c0363c2 == null) {
                c0361a.f4777b = c0363c;
                c0361a.f4778c = c0363c;
            } else {
                c0363c2.f4773d = c0363c;
                c0363c.e = c0363c2;
                c0361a.f4778c = c0363c;
            }
            map2.put(interfaceC0075t, c0363c);
        }
        if (((C0077v) obj) == null && (interfaceC0076u = (InterfaceC0076u) this.e.get()) != null) {
            boolean z4 = this.f1838f != 0 || this.f1839g;
            EnumC0070n enumC0070nB = b(interfaceC0075t);
            this.f1838f++;
            while (c0077v.f1832a.compareTo(enumC0070nB) < 0 && this.f1836c.f4767f.containsKey(interfaceC0075t)) {
                arrayList.add(c0077v.f1832a);
                C0067k c0067k = EnumC0069m.Companion;
                EnumC0070n enumC0070n3 = c0077v.f1832a;
                c0067k.getClass();
                EnumC0069m enumC0069mB = C0067k.b(enumC0070n3);
                if (enumC0069mB == null) {
                    throw new IllegalStateException("no event up from " + c0077v.f1832a);
                }
                c0077v.a(interfaceC0076u, enumC0069mB);
                arrayList.remove(arrayList.size() - 1);
                enumC0070nB = b(interfaceC0075t);
            }
            if (!z4) {
                h();
            }
            this.f1838f--;
        }
    }

    public final EnumC0070n b(InterfaceC0075t interfaceC0075t) {
        HashMap map = this.f1836c.f4767f;
        C0363c c0363c = map.containsKey(interfaceC0075t) ? ((C0363c) map.get(interfaceC0075t)).e : null;
        EnumC0070n enumC0070n = c0363c != null ? ((C0077v) c0363c.f4772c).f1832a : null;
        ArrayList arrayList = this.i;
        EnumC0070n enumC0070n2 = arrayList.isEmpty() ? null : (EnumC0070n) arrayList.get(arrayList.size() - 1);
        EnumC0070n enumC0070n3 = this.f1837d;
        X1.i.e(enumC0070n3, "state1");
        if (enumC0070n == null || enumC0070n.compareTo(enumC0070n3) >= 0) {
            enumC0070n = enumC0070n3;
        }
        return (enumC0070n2 == null || enumC0070n2.compareTo(enumC0070n) >= 0) ? enumC0070n : enumC0070n2;
    }

    public final void c(String str) {
        if (this.f1835b) {
            C0356a.G().f4713b.getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(H.e.i("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void d(EnumC0069m enumC0069m) {
        X1.i.e(enumC0069m, "event");
        c("handleLifecycleEvent");
        e(enumC0069m.a());
    }

    public final void e(EnumC0070n enumC0070n) {
        if (this.f1837d == enumC0070n) {
            return;
        }
        InterfaceC0076u interfaceC0076u = (InterfaceC0076u) this.e.get();
        EnumC0070n enumC0070n2 = this.f1837d;
        X1.i.e(enumC0070n2, "current");
        X1.i.e(enumC0070n, "next");
        EnumC0070n enumC0070n3 = EnumC0070n.f1823c;
        EnumC0070n enumC0070n4 = EnumC0070n.f1822b;
        if (enumC0070n2 == enumC0070n3 && enumC0070n == enumC0070n4) {
            throw new IllegalStateException(("State must be at least '" + EnumC0070n.f1824d + "' to be moved to '" + enumC0070n + "' in component " + interfaceC0076u).toString());
        }
        if (enumC0070n2 == enumC0070n4 && enumC0070n2 != enumC0070n) {
            throw new IllegalStateException(("State is '" + enumC0070n4 + "' and cannot be moved to `" + enumC0070n + "` in component " + interfaceC0076u).toString());
        }
        this.f1837d = enumC0070n;
        if (this.f1839g || this.f1838f != 0) {
            this.f1840h = true;
            return;
        }
        this.f1839g = true;
        h();
        this.f1839g = false;
        if (this.f1837d == enumC0070n4) {
            this.f1836c = new C0361a();
        }
    }

    public final void f(InterfaceC0075t interfaceC0075t) {
        X1.i.e(interfaceC0075t, "observer");
        c("removeObserver");
        this.f1836c.b(interfaceC0075t);
    }

    public final void g(EnumC0070n enumC0070n) {
        X1.i.e(enumC0070n, "state");
        c("setCurrentState");
        e(enumC0070n);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0030, code lost:
    
        r7.f1840h = false;
        r7.f1841j.k(r7.f1837d);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0039, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void h() {
        InterfaceC0076u interfaceC0076u = (InterfaceC0076u) this.e.get();
        if (interfaceC0076u == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            C0361a c0361a = this.f1836c;
            if (c0361a.e != 0) {
                C0363c c0363c = c0361a.f4777b;
                X1.i.b(c0363c);
                EnumC0070n enumC0070n = ((C0077v) c0363c.f4772c).f1832a;
                C0363c c0363c2 = this.f1836c.f4778c;
                X1.i.b(c0363c2);
                EnumC0070n enumC0070n2 = ((C0077v) c0363c2.f4772c).f1832a;
                if (enumC0070n == enumC0070n2 && this.f1837d == enumC0070n2) {
                    break;
                }
                this.f1840h = false;
                EnumC0070n enumC0070n3 = this.f1837d;
                C0363c c0363c3 = this.f1836c.f4777b;
                X1.i.b(c0363c3);
                if (enumC0070n3.compareTo(((C0077v) c0363c3.f4772c).f1832a) < 0) {
                    C0361a c0361a2 = this.f1836c;
                    C0362b c0362b = new C0362b(c0361a2.f4778c, c0361a2.f4777b, 1);
                    c0361a2.f4779d.put(c0362b, Boolean.FALSE);
                    while (c0362b.hasNext() && !this.f1840h) {
                        Map.Entry entry = (Map.Entry) c0362b.next();
                        X1.i.b(entry);
                        InterfaceC0075t interfaceC0075t = (InterfaceC0075t) entry.getKey();
                        C0077v c0077v = (C0077v) entry.getValue();
                        while (c0077v.f1832a.compareTo(this.f1837d) > 0 && !this.f1840h && this.f1836c.f4767f.containsKey(interfaceC0075t)) {
                            C0067k c0067k = EnumC0069m.Companion;
                            EnumC0070n enumC0070n4 = c0077v.f1832a;
                            c0067k.getClass();
                            EnumC0069m enumC0069mA = C0067k.a(enumC0070n4);
                            if (enumC0069mA == null) {
                                throw new IllegalStateException("no event down from " + c0077v.f1832a);
                            }
                            this.i.add(enumC0069mA.a());
                            c0077v.a(interfaceC0076u, enumC0069mA);
                            this.i.remove(r4.size() - 1);
                        }
                    }
                }
                C0363c c0363c4 = this.f1836c.f4778c;
                if (!this.f1840h && c0363c4 != null && this.f1837d.compareTo(((C0077v) c0363c4.f4772c).f1832a) > 0) {
                    C0361a c0361a3 = this.f1836c;
                    c0361a3.getClass();
                    C0364d c0364d = new C0364d(c0361a3);
                    c0361a3.f4779d.put(c0364d, Boolean.FALSE);
                    while (c0364d.hasNext() && !this.f1840h) {
                        Map.Entry entry2 = (Map.Entry) c0364d.next();
                        InterfaceC0075t interfaceC0075t2 = (InterfaceC0075t) entry2.getKey();
                        C0077v c0077v2 = (C0077v) entry2.getValue();
                        while (c0077v2.f1832a.compareTo(this.f1837d) < 0 && !this.f1840h && this.f1836c.f4767f.containsKey(interfaceC0075t2)) {
                            this.i.add(c0077v2.f1832a);
                            C0067k c0067k2 = EnumC0069m.Companion;
                            EnumC0070n enumC0070n5 = c0077v2.f1832a;
                            c0067k2.getClass();
                            EnumC0069m enumC0069mB = C0067k.b(enumC0070n5);
                            if (enumC0069mB == null) {
                                throw new IllegalStateException("no event up from " + c0077v2.f1832a);
                            }
                            c0077v2.a(interfaceC0076u, enumC0069mB);
                            this.i.remove(r4.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
    }
}
