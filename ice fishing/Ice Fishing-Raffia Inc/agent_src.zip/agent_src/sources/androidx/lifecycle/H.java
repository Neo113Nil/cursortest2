package androidx.lifecycle;

import a.AbstractC0046a;
import g2.InterfaceC0158w;

/* loaded from: classes.dex */
public final class H extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f1757f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f1758g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ W1.p f1759h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public H(W1.p pVar, N1.d dVar) {
        super(2, dVar);
        this.f1759h = pVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((H) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        H h3 = new H(this.f1759h, dVar);
        h3.f1758g = obj;
        return h3;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f1757f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f1758g;
            this.f1757f = 1;
            if (this.f1759h.e(interfaceC0158w, this) == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return J1.k.f632a;
    }
}
