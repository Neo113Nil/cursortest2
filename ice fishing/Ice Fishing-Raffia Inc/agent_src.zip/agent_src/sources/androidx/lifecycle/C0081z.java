package androidx.lifecycle;

import c0.AbstractComponentCallbacksC0110w;

/* renamed from: androidx.lifecycle.z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0081z extends A implements InterfaceC0074s {

    /* renamed from: f, reason: collision with root package name */
    public final AbstractComponentCallbacksC0110w f1844f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ B f1845g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0081z(B b3, AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w, l0.o oVar) {
        super(b3, oVar);
        this.f1845g = b3;
        this.f1844f = abstractComponentCallbacksC0110w;
    }

    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) {
        AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w = this.f1844f;
        EnumC0070n enumC0070n = abstractComponentCallbacksC0110w.f2302Q.f1837d;
        if (enumC0070n != EnumC0070n.f1822b) {
            EnumC0070n enumC0070n2 = null;
            while (enumC0070n2 != enumC0070n) {
                b(e());
                enumC0070n2 = enumC0070n;
                enumC0070n = abstractComponentCallbacksC0110w.f2302Q.f1837d;
            }
            return;
        }
        B b3 = this.f1845g;
        b3.getClass();
        B.a("removeObserver");
        A a3 = (A) b3.f1744b.b(this.f1739b);
        if (a3 == null) {
            return;
        }
        a3.c();
        a3.b(false);
    }

    @Override // androidx.lifecycle.A
    public final void c() {
        this.f1844f.f2302Q.f(this);
    }

    @Override // androidx.lifecycle.A
    public final boolean d(AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w) {
        return this.f1844f == abstractComponentCallbacksC0110w;
    }

    @Override // androidx.lifecycle.A
    public final boolean e() {
        return this.f1844f.f2302Q.f1837d.compareTo(EnumC0070n.e) >= 0;
    }
}
