package androidx.lifecycle;

import a.AbstractC0046a;
import g2.C0156u;
import g2.InterfaceC0158w;

/* renamed from: androidx.lifecycle.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0071o extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f1827f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ C0072p f1828g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0071o(C0072p c0072p, N1.d dVar) {
        super(2, dVar);
        this.f1828g = c0072p;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) throws Throwable {
        C0071o c0071o = (C0071o) m((N1.d) obj2, (InterfaceC0158w) obj);
        J1.k kVar = J1.k.f632a;
        c0071o.o(kVar);
        return kVar;
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        C0071o c0071o = new C0071o(this.f1828g, dVar);
        c0071o.f1827f = obj;
        return c0071o;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        AbstractC0046a.N(obj);
        InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f1827f;
        C0072p c0072p = this.f1828g;
        C0078w c0078w = c0072p.f1829b;
        if (c0078w.f1837d.compareTo(EnumC0070n.f1823c) >= 0) {
            c0078w.a(c0072p);
        } else {
            g2.Y y2 = (g2.Y) interfaceC0158w.x().C(C0156u.f3173c);
            if (y2 != null) {
                y2.a(null);
            }
        }
        return J1.k.f632a;
    }
}
