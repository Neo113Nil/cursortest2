package androidx.lifecycle;

import a.AbstractC0046a;
import android.os.Bundle;
import android.view.View;
import com.kortosi.kluani.qorzanis.R;
import e1.C0123e;
import g0.AbstractC0133b;
import g0.C0132a;
import g0.C0134c;
import g2.AbstractC0160y;
import g2.o0;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicReference;
import w0.C0476a;

/* loaded from: classes.dex */
public abstract class T {

    /* renamed from: a, reason: collision with root package name */
    public static final C0123e f1785a = new C0123e();

    /* renamed from: b, reason: collision with root package name */
    public static final C0123e f1786b = new C0123e();

    /* renamed from: c, reason: collision with root package name */
    public static final C0123e f1787c = new C0123e();

    /* renamed from: d, reason: collision with root package name */
    public static final C0123e f1788d = new C0123e();
    public static final C0123e e = new C0123e();

    public static final void a(Y y2, A.i iVar, C0078w c0078w) throws NoSuchMethodException, SecurityException {
        X1.i.e(iVar, "registry");
        X1.i.e(c0078w, "lifecycle");
        Q q2 = (Q) y2.c("androidx.lifecycle.savedstate.vm.tag");
        if (q2 == null || q2.f1784d) {
            return;
        }
        q2.b(iVar, c0078w);
        j(iVar, c0078w);
    }

    public static final Q b(A.i iVar, C0078w c0078w, String str, Bundle bundle) throws NoSuchMethodException, SecurityException {
        P p2;
        X1.i.e(iVar, "registry");
        X1.i.e(c0078w, "lifecycle");
        Bundle bundleG = iVar.g(str);
        if (bundleG != null) {
            bundle = bundleG;
        }
        if (bundle == null) {
            p2 = new P();
        } else {
            ClassLoader classLoader = P.class.getClassLoader();
            X1.i.b(classLoader);
            bundle.setClassLoader(classLoader);
            L1.h hVar = new L1.h(bundle.size());
            for (String str2 : bundle.keySet()) {
                X1.i.b(str2);
                hVar.put(str2, bundle.get(str2));
            }
            p2 = new P(hVar.b());
        }
        Q q2 = new Q(str, p2);
        q2.b(iVar, c0078w);
        j(iVar, c0078w);
        return q2;
    }

    public static final P c(C0134c c0134c) {
        C0123e c0123e = f1785a;
        LinkedHashMap linkedHashMap = c0134c.f3089a;
        w0.d dVar = (w0.d) linkedHashMap.get(c0123e);
        if (dVar == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `SAVED_STATE_REGISTRY_OWNER_KEY`");
        }
        e0 e0Var = (e0) linkedHashMap.get(f1786b);
        if (e0Var == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_STORE_OWNER_KEY`");
        }
        Bundle bundle = (Bundle) linkedHashMap.get(f1787c);
        String str = (String) linkedHashMap.get(e);
        if (str == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_KEY`");
        }
        w0.c cVarY = dVar.b().y();
        Bundle bundle2 = null;
        U u2 = cVarY instanceof U ? (U) cVarY : null;
        if (u2 == null) {
            throw new IllegalStateException("enableSavedStateHandles() wasn't called prior to createSavedStateHandle() call");
        }
        LinkedHashMap linkedHashMap2 = f(e0Var).f1793b;
        P p2 = (P) linkedHashMap2.get(str);
        if (p2 == null) {
            u2.b();
            Bundle bundle3 = u2.f1791c;
            if (bundle3 != null && bundle3.containsKey(str)) {
                Bundle bundle4 = bundle3.getBundle(str);
                if (bundle4 == null) {
                    bundle4 = AbstractC0046a.e((J1.e[]) Arrays.copyOf(new J1.e[0], 0));
                }
                bundle3.remove(str);
                if (bundle3.isEmpty()) {
                    u2.f1791c = null;
                }
                bundle2 = bundle4;
            }
            if (bundle2 != null) {
                bundle = bundle2;
            }
            if (bundle == null) {
                p2 = new P();
            } else {
                ClassLoader classLoader = P.class.getClassLoader();
                X1.i.b(classLoader);
                bundle.setClassLoader(classLoader);
                L1.h hVar = new L1.h(bundle.size());
                for (String str2 : bundle.keySet()) {
                    X1.i.b(str2);
                    hVar.put(str2, bundle.get(str2));
                }
                p2 = new P(hVar.b());
            }
            linkedHashMap2.put(str, p2);
        }
        return p2;
    }

    public static final void d(w0.d dVar) {
        EnumC0070n enumC0070n = dVar.e().f1837d;
        if (enumC0070n != EnumC0070n.f1823c && enumC0070n != EnumC0070n.f1824d) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        if (dVar.b().y() == null) {
            U u2 = new U(dVar.b(), (e0) dVar);
            dVar.b().O("androidx.lifecycle.internal.SavedStateHandlesProvider", u2);
            dVar.e().a(new C0476a(3, u2));
        }
    }

    public static final C0072p e(c0.Z z2) {
        C0072p c0072p;
        C0078w c0078wE = z2.e();
        X1.i.e(c0078wE, "<this>");
        loop0: while (true) {
            A0.f fVar = c0078wE.f1834a;
            c0072p = (C0072p) ((AtomicReference) fVar.f224c).get();
            if (c0072p == null) {
                o0 o0Var = new o0(null);
                n2.d dVar = g2.F.f3104a;
                c0072p = new C0072p(c0078wE, L1.d.g0(o0Var, l2.o.f4111a.f3520g));
                AtomicReference atomicReference = (AtomicReference) fVar.f224c;
                while (!atomicReference.compareAndSet(null, c0072p)) {
                    if (atomicReference.get() != null) {
                        break;
                    }
                }
                n2.d dVar2 = g2.F.f3104a;
                AbstractC0160y.l(c0072p, l2.o.f4111a.f3520g, 0, new C0071o(c0072p, null), 2);
                break loop0;
            }
            break;
        }
        return c0072p;
    }

    public static final V f(e0 e0Var) {
        S s2 = new S();
        AbstractC0133b abstractC0133bA = e0Var instanceof InterfaceC0065i ? ((InterfaceC0065i) e0Var).a() : C0132a.f3088b;
        X1.i.e(abstractC0133bA, "extras");
        d0 d0VarC = e0Var.c();
        X1.i.e(d0VarC, "store");
        return (V) new C.k(d0VarC, s2, abstractC0133bA).k(X1.o.a(V.class), "androidx.lifecycle.internal.SavedStateHandlesVM");
    }

    public static final h0.a g(Y y2) {
        h0.a aVar;
        X1.i.e(y2, "<this>");
        synchronized (f1788d) {
            aVar = (h0.a) y2.c("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY");
            if (aVar == null) {
                N1.i iVar = N1.j.f809b;
                try {
                    n2.d dVar = g2.F.f3104a;
                    iVar = l2.o.f4111a.f3520g;
                } catch (J1.d | IllegalStateException unused) {
                }
                h0.a aVar2 = new h0.a(iVar.E(new o0(null)));
                y2.a("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY", aVar2);
                aVar = aVar2;
            }
        }
        return aVar;
    }

    public static final Object h(c0.Z z2, W1.p pVar, P1.g gVar) {
        Object objA;
        z2.f();
        C0078w c0078w = z2.f2180f;
        EnumC0070n enumC0070n = c0078w.f1837d;
        EnumC0070n enumC0070n2 = EnumC0070n.f1822b;
        J1.k kVar = J1.k.f632a;
        O1.a aVar = O1.a.f839b;
        if (enumC0070n == enumC0070n2 || (objA = AbstractC0160y.a(new L(c0078w, pVar, null), gVar)) != aVar) {
            objA = kVar;
        }
        return objA == aVar ? objA : kVar;
    }

    public static final void i(View view, InterfaceC0076u interfaceC0076u) {
        X1.i.e(view, "<this>");
        view.setTag(R.id.view_tree_lifecycle_owner, interfaceC0076u);
    }

    public static void j(A.i iVar, C0078w c0078w) throws NoSuchMethodException, SecurityException {
        EnumC0070n enumC0070n = c0078w.f1837d;
        if (enumC0070n == EnumC0070n.f1823c || enumC0070n.compareTo(EnumC0070n.e) >= 0) {
            iVar.R();
        } else {
            c0078w.a(new C0062f(iVar, c0078w));
        }
    }
}
