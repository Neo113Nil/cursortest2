package androidx.lifecycle;

import android.app.Activity;
import androidx.lifecycle.F;

/* loaded from: classes.dex */
public abstract class E {
    public static final void a(Activity activity, F.a aVar) {
        X1.i.e(activity, "activity");
        activity.registerActivityLifecycleCallbacks(aVar);
    }
}
