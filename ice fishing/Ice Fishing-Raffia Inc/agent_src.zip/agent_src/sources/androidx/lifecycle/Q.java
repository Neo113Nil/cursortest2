package androidx.lifecycle;

/* loaded from: classes.dex */
public final class Q implements InterfaceC0074s, AutoCloseable {

    /* renamed from: b, reason: collision with root package name */
    public final String f1782b;

    /* renamed from: c, reason: collision with root package name */
    public final P f1783c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1784d;

    public Q(String str, P p2) {
        this.f1782b = str;
        this.f1783c = p2;
    }

    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) {
        if (enumC0069m == EnumC0069m.ON_DESTROY) {
            this.f1784d = false;
            interfaceC0076u.e().f(this);
        }
    }

    public final void b(A.i iVar, C0078w c0078w) {
        X1.i.e(iVar, "registry");
        X1.i.e(c0078w, "lifecycle");
        if (this.f1784d) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.f1784d = true;
        c0078w.a(this);
        iVar.O(this.f1782b, (c0.D) this.f1783c.f1781b.f1804f);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
    }
}
