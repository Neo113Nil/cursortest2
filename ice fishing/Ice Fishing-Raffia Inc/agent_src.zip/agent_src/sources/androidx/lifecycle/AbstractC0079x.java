package androidx.lifecycle;

import K1.C0011b;
import a.AbstractC0046a;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/* renamed from: androidx.lifecycle.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0079x {

    /* renamed from: a, reason: collision with root package name */
    public static final HashMap f1842a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public static final HashMap f1843b = new HashMap();

    public static void a(Constructor constructor, InterfaceC0075t interfaceC0075t) {
        try {
            X1.i.b(constructor.newInstance(interfaceC0075t));
            throw new ClassCastException();
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e3) {
            throw new RuntimeException(e3);
        } catch (InvocationTargetException e4) {
            throw new RuntimeException(e4);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x0110  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0142 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int b(Class cls) throws NoSuchMethodException, SecurityException {
        Constructor<?> declaredConstructor;
        boolean zBooleanValue;
        C0011b c0011bD;
        HashMap map = f1842a;
        Integer num = (Integer) map.get(cls);
        if (num != null) {
            return num.intValue();
        }
        int i = 1;
        if (cls.getCanonicalName() != null) {
            ArrayList arrayList = null;
            try {
                Package r3 = cls.getPackage();
                String canonicalName = cls.getCanonicalName();
                String name = r3 != null ? r3.getName() : "";
                X1.i.b(name);
                if (name.length() != 0) {
                    X1.i.b(canonicalName);
                    canonicalName = canonicalName.substring(name.length() + 1);
                    X1.i.d(canonicalName, "substring(...)");
                }
                X1.i.b(canonicalName);
                String strConcat = e2.h.A0(canonicalName, ".", "_").concat("_LifecycleAdapter");
                if (name.length() != 0) {
                    strConcat = name + '.' + strConcat;
                }
                declaredConstructor = Class.forName(strConcat).getDeclaredConstructor(cls);
                if (!declaredConstructor.isAccessible()) {
                    declaredConstructor.setAccessible(true);
                }
            } catch (ClassNotFoundException unused) {
                declaredConstructor = null;
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
            HashMap map2 = f1843b;
            if (declaredConstructor != null) {
                map2.put(cls, AbstractC0046a.H(declaredConstructor));
            } else {
                C0060d c0060d = C0060d.f1813c;
                HashMap map3 = c0060d.f1815b;
                Boolean bool = (Boolean) map3.get(cls);
                if (bool != null) {
                    zBooleanValue = bool.booleanValue();
                } else {
                    try {
                        Method[] declaredMethods = cls.getDeclaredMethods();
                        int length = declaredMethods.length;
                        int i3 = 0;
                        while (true) {
                            if (i3 >= length) {
                                map3.put(cls, Boolean.FALSE);
                                zBooleanValue = false;
                                break;
                            }
                            if (((D) declaredMethods[i3].getAnnotation(D.class)) != null) {
                                c0060d.a(cls, declaredMethods);
                                zBooleanValue = true;
                                break;
                            }
                            i3++;
                        }
                    } catch (NoClassDefFoundError e3) {
                        throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e3);
                    }
                }
                if (!zBooleanValue) {
                    Class superclass = cls.getSuperclass();
                    if (superclass != null && InterfaceC0075t.class.isAssignableFrom(superclass)) {
                        X1.i.b(superclass);
                        if (b(superclass) != 1) {
                            Object obj = map2.get(superclass);
                            X1.i.b(obj);
                            arrayList = new ArrayList((Collection) obj);
                            c0011bD = X1.q.d(cls.getInterfaces());
                            while (true) {
                                if (!c0011bD.hasNext()) {
                                    Class cls2 = (Class) c0011bD.next();
                                    if (cls2 != null && InterfaceC0075t.class.isAssignableFrom(cls2)) {
                                        X1.i.b(cls2);
                                        if (b(cls2) == 1) {
                                            break;
                                        }
                                        if (arrayList == null) {
                                            arrayList = new ArrayList();
                                        }
                                        Object obj2 = map2.get(cls2);
                                        X1.i.b(obj2);
                                        arrayList.addAll((Collection) obj2);
                                    }
                                } else if (arrayList != null) {
                                    map2.put(cls, arrayList);
                                }
                            }
                        }
                    } else {
                        c0011bD = X1.q.d(cls.getInterfaces());
                        while (true) {
                            if (!c0011bD.hasNext()) {
                            }
                        }
                    }
                }
            }
            i = 2;
        }
        map.put(cls, Integer.valueOf(i));
        return i;
    }
}
