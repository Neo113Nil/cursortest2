package androidx.lifecycle;

import java.util.Iterator;
import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class d0 {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f1816a = new LinkedHashMap();

    public final void a() {
        LinkedHashMap linkedHashMap = this.f1816a;
        Iterator it = linkedHashMap.values().iterator();
        while (it.hasNext()) {
            ((Y) it.next()).b();
        }
        linkedHashMap.clear();
    }
}
