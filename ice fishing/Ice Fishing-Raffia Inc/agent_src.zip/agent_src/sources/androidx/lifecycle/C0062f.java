package androidx.lifecycle;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;

/* renamed from: androidx.lifecycle.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0062f implements InterfaceC0074s {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1818b = 1;

    /* renamed from: c, reason: collision with root package name */
    public final Object f1819c;

    /* renamed from: d, reason: collision with root package name */
    public final Object f1820d;

    public C0062f(Y.k kVar, InterfaceC0074s interfaceC0074s) {
        X1.i.e(kVar, "defaultLifecycleObserver");
        this.f1819c = kVar;
        this.f1820d = interfaceC0074s;
    }

    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        switch (this.f1818b) {
            case 0:
                int i = AbstractC0061e.f1817a[enumC0069m.ordinal()];
                Y.k kVar = (Y.k) this.f1819c;
                switch (i) {
                    case 1:
                        kVar.getClass();
                        break;
                    case 2:
                        kVar.getClass();
                        break;
                    case 3:
                        kVar.f1387c.getClass();
                        (Build.VERSION.SDK_INT >= 28 ? Y.b.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new Y.n(), 500L);
                        kVar.f1386b.f(kVar);
                        break;
                    case 4:
                        kVar.getClass();
                        break;
                    case 5:
                        kVar.getClass();
                        break;
                    case 6:
                        kVar.getClass();
                        break;
                    case 7:
                        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
                    default:
                        throw new C0.c();
                }
                InterfaceC0074s interfaceC0074s = (InterfaceC0074s) this.f1820d;
                if (interfaceC0074s != null) {
                    interfaceC0074s.a(interfaceC0076u, enumC0069m);
                    return;
                }
                return;
            case 1:
                if (enumC0069m == EnumC0069m.ON_START) {
                    ((C0078w) this.f1819c).f(this);
                    ((A.i) this.f1820d).R();
                    return;
                }
                return;
            default:
                HashMap map = ((C0058b) this.f1820d).f1808a;
                List list = (List) map.get(enumC0069m);
                InterfaceC0075t interfaceC0075t = (InterfaceC0075t) this.f1819c;
                C0058b.a(list, interfaceC0076u, enumC0069m, interfaceC0075t);
                C0058b.a((List) map.get(EnumC0069m.ON_ANY), interfaceC0076u, enumC0069m, interfaceC0075t);
                return;
        }
    }

    public C0062f(InterfaceC0075t interfaceC0075t) {
        this.f1819c = interfaceC0075t;
        C0060d c0060d = C0060d.f1813c;
        Class<?> cls = interfaceC0075t.getClass();
        C0058b c0058b = (C0058b) c0060d.f1814a.get(cls);
        this.f1820d = c0058b == null ? c0060d.a(cls, null) : c0058b;
    }

    public C0062f(A.i iVar, C0078w c0078w) {
        this.f1819c = c0078w;
        this.f1820d = iVar;
    }
}
