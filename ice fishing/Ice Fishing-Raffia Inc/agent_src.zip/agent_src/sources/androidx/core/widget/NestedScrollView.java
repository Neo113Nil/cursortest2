package androidx.core.widget;

import A0.f;
import L1.d;
import P.C0019g;
import P.C0025m;
import P.C0028p;
import P.C0033v;
import P.G;
import P.InterfaceC0024l;
import P.InterfaceC0027o;
import P.O;
import S.c;
import S.e;
import S.g;
import S.h;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements InterfaceC0027o, InterfaceC0024l {

    /* renamed from: D, reason: collision with root package name */
    public static final float f1677D = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* renamed from: E, reason: collision with root package name */
    public static final e f1678E = new e(0);
    public static final int[] F = {R.attr.fillViewport};

    /* renamed from: A, reason: collision with root package name */
    public final C0025m f1679A;

    /* renamed from: B, reason: collision with root package name */
    public float f1680B;

    /* renamed from: C, reason: collision with root package name */
    public final C0019g f1681C;

    /* renamed from: b, reason: collision with root package name */
    public final float f1682b;

    /* renamed from: c, reason: collision with root package name */
    public long f1683c;

    /* renamed from: d, reason: collision with root package name */
    public final Rect f1684d;
    public final OverScroller e;

    /* renamed from: f, reason: collision with root package name */
    public final EdgeEffect f1685f;

    /* renamed from: g, reason: collision with root package name */
    public final EdgeEffect f1686g;

    /* renamed from: h, reason: collision with root package name */
    public C0033v f1687h;
    public int i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1688j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1689k;

    /* renamed from: l, reason: collision with root package name */
    public View f1690l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1691m;

    /* renamed from: n, reason: collision with root package name */
    public VelocityTracker f1692n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1693o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f1694p;

    /* renamed from: q, reason: collision with root package name */
    public final int f1695q;

    /* renamed from: r, reason: collision with root package name */
    public final int f1696r;

    /* renamed from: s, reason: collision with root package name */
    public final int f1697s;

    /* renamed from: t, reason: collision with root package name */
    public int f1698t;

    /* renamed from: u, reason: collision with root package name */
    public final int[] f1699u;

    /* renamed from: v, reason: collision with root package name */
    public final int[] f1700v;

    /* renamed from: w, reason: collision with root package name */
    public int f1701w;

    /* renamed from: x, reason: collision with root package name */
    public int f1702x;

    /* renamed from: y, reason: collision with root package name */
    public h f1703y;

    /* renamed from: z, reason: collision with root package name */
    public final C0028p f1704z;

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.nestedScrollViewStyle);
        this.f1684d = new Rect();
        this.f1688j = true;
        this.f1689k = false;
        this.f1690l = null;
        this.f1691m = false;
        this.f1694p = true;
        this.f1698t = -1;
        this.f1699u = new int[2];
        this.f1700v = new int[2];
        this.f1681C = new C0019g(getContext(), new f(13, this));
        int i = Build.VERSION.SDK_INT;
        this.f1685f = i >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f1686g = i >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f1682b = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.e = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1695q = viewConfiguration.getScaledTouchSlop();
        this.f1696r = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1697s = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, F, com.kortosi.kluani.qorzanis.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f1704z = new C0028p();
        this.f1679A = new C0025m(this);
        setNestedScrollingEnabled(true);
        O.m(this, f1678E);
    }

    private C0033v getScrollFeedbackProvider() {
        if (this.f1687h == null) {
            this.f1687h = new C0033v(this);
        }
        return this.f1687h;
    }

    public static boolean l(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && l((View) parent, nestedScrollView);
    }

    @Override // P.InterfaceC0026n
    public final void a(View view, View view2, int i, int i3) {
        C0028p c0028p = this.f1704z;
        if (i3 == 1) {
            c0028p.f934b = i;
        } else {
            c0028p.f933a = i;
        }
        this.f1679A.g(2, i3);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // P.InterfaceC0027o
    public final void b(View view, int i, int i3, int i4, int i5, int i6, int[] iArr) {
        n(i5, i6, iArr);
    }

    @Override // P.InterfaceC0026n
    public final void c(View view, int i, int i3, int i4, int i5, int i6) {
        n(i5, i6, null);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00f9  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void computeScroll() {
        int iRound;
        int i;
        if (this.e.isFinished()) {
            return;
        }
        this.e.computeScrollOffset();
        int currY = this.e.getCurrY();
        int i3 = currY - this.f1702x;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f1686g;
        EdgeEffect edgeEffect2 = this.f1685f;
        if (i3 <= 0 || d.B(edgeEffect2) == 0.0f) {
            if (i3 < 0 && d.B(edgeEffect) != 0.0f) {
                float f3 = height;
                iRound = Math.round(d.b0(edgeEffect, (i3 * 4.0f) / f3, 0.5f) * (f3 / 4.0f));
                if (iRound != i3) {
                    edgeEffect.finish();
                }
            }
            this.f1702x = currY;
            int[] iArr = this.f1700v;
            iArr[1] = 0;
            this.f1679A.c(0, i3, 1, iArr, null);
            i = i3 - iArr[1];
            int scrollRange = getScrollRange();
            if (Build.VERSION.SDK_INT >= 35) {
                S.f.a(this, Math.abs(this.e.getCurrVelocity()));
            }
            if (i != 0) {
                int scrollY = getScrollY();
                p(i, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i4 = i - scrollY2;
                iArr[1] = 0;
                this.f1679A.d(0, scrollY2, 0, i4, this.f1699u, 1, iArr);
                i = i4 - iArr[1];
            }
            if (i != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i < 0) {
                        if (edgeEffect2.isFinished()) {
                            edgeEffect2.onAbsorb((int) this.e.getCurrVelocity());
                        }
                    } else if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.e.getCurrVelocity());
                    }
                }
                this.e.abortAnimation();
                w(1);
            }
            if (this.e.isFinished()) {
                postInvalidateOnAnimation();
                return;
            } else {
                w(1);
                return;
            }
        }
        iRound = Math.round(d.b0(edgeEffect2, ((-i3) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i3) {
            edgeEffect2.finish();
        }
        i3 -= iRound;
        this.f1702x = currY;
        int[] iArr2 = this.f1700v;
        iArr2[1] = 0;
        this.f1679A.c(0, i3, 1, iArr2, null);
        i = i3 - iArr2[1];
        int scrollRange2 = getScrollRange();
        if (Build.VERSION.SDK_INT >= 35) {
        }
        if (i != 0) {
        }
        if (i != 0) {
        }
        if (this.e.isFinished()) {
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > iMax ? bottom + (scrollY - iMax) : bottom;
    }

    @Override // P.InterfaceC0026n
    public final void d(View view, int i) {
        C0028p c0028p = this.f1704z;
        if (i == 1) {
            c0028p.f934b = 0;
        } else {
            c0028p.f933a = 0;
        }
        w(i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || i(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f3, float f4, boolean z2) {
        return this.f1679A.a(f3, f4, z2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f3, float f4) {
        return this.f1679A.b(f3, f4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i3, int[] iArr, int[] iArr2) {
        return this.f1679A.c(i, i3, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i3, int i4, int i5, int[] iArr) {
        return this.f1679A.d(i, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f1685f;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f1686g;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // P.InterfaceC0026n
    public final void e(View view, int i, int i3, int[] iArr, int i4) {
        this.f1679A.c(i, i3, i4, iArr, null);
    }

    @Override // P.InterfaceC0026n
    public final boolean f(View view, View view2, int i, int i3) {
        return (i & 2) != 0;
    }

    public final boolean g(int i) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !m(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, -1, null, 0, 1, true);
        } else {
            Rect rect = this.f1684d;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            s(h(rect), -1, null, 0, 1, true);
            viewFindNextFocus.requestFocus(i);
        }
        if (viewFindFocus == null || !viewFindFocus.isFocused() || m(viewFindFocus, 0, getHeight())) {
            return true;
        }
        int descendantFocusability = getDescendantFocusability();
        setDescendantFocusability(131072);
        requestFocus();
        setDescendantFocusability(descendantFocusability);
        return true;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0028p c0028p = this.f1704z;
        return c0028p.f934b | c0028p.f933a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f1680B == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f1680B = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f1680B;
    }

    public final int h(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i3 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i4 = rect.bottom;
        if (i4 > i3 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i3, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        }
        if (rect.top >= scrollY || i4 >= i3) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i3 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f1679A.f(0);
    }

    public final boolean i(KeyEvent keyEvent) {
        this.f1684d.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() != 0) {
                    return false;
                }
                int keyCode = keyEvent.getKeyCode();
                if (keyCode == 19) {
                    return keyEvent.isAltPressed() ? k(33) : g(33);
                }
                if (keyCode == 20) {
                    return keyEvent.isAltPressed() ? k(130) : g(130);
                }
                if (keyCode == 62) {
                    q(keyEvent.isShiftPressed() ? 33 : 130);
                    return false;
                }
                if (keyCode == 92) {
                    return k(33);
                }
                if (keyCode == 93) {
                    return k(130);
                }
                if (keyCode == 122) {
                    q(33);
                    return false;
                }
                if (keyCode != 123) {
                    return false;
                }
                q(130);
                return false;
            }
        }
        if (!isFocused() || keyEvent.getKeyCode() == 4) {
            return false;
        }
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
        return (viewFindNextFocus == null || viewFindNextFocus == this || !viewFindNextFocus.requestFocus(130)) ? false : true;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f1679A.f928d;
    }

    public final void j(int i) {
        if (getChildCount() > 0) {
            this.e.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f1679A.g(2, 1);
            this.f1702x = getScrollY();
            postInvalidateOnAnimation();
            if (Build.VERSION.SDK_INT >= 35) {
                S.f.a(this, Math.abs(this.e.getCurrVelocity()));
            }
        }
    }

    public final boolean k(int i) {
        int childCount;
        boolean z2 = i == 130;
        int height = getHeight();
        Rect rect = this.f1684d;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return r(i, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i, int i3) {
        Rect rect = this.f1684d;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i >= getScrollY() && rect.top - i <= getScrollY() + i3;
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i, int i3) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f1679A.d(0, scrollY2, 0, i - scrollY2, null, i3, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1698t) {
            int i = actionIndex == 0 ? 1 : 0;
            this.i = (int) motionEvent.getY(i);
            this.f1698t = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f1692n;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1689k = false;
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i;
        int width;
        float axisValue;
        if (motionEvent.getAction() == 8 && !this.f1691m) {
            if (d.R(motionEvent, 2)) {
                i = 9;
                axisValue = motionEvent.getAxisValue(9);
                width = (int) motionEvent.getX();
            } else if (d.R(motionEvent, 4194304)) {
                float axisValue2 = motionEvent.getAxisValue(26);
                width = getWidth() / 2;
                i = 26;
                axisValue = axisValue2;
            } else {
                i = 0;
                width = 0;
                axisValue = 0.0f;
            }
            if (axisValue != 0.0f) {
                s(-((int) (getVerticalScrollFactorCompat() * axisValue)), i, motionEvent, width, 1, d.R(motionEvent, 8194));
                if (i == 0) {
                    return true;
                }
                this.f1681C.a(motionEvent, i);
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0119  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z2 = true;
        if (action == 2 && this.f1691m) {
            return true;
        }
        int i = action & 255;
        if (i == 0) {
            int y2 = (int) motionEvent.getY();
            int x2 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y2 < childAt.getTop() - scrollY || y2 >= childAt.getBottom() - scrollY || x2 < childAt.getLeft() || x2 >= childAt.getRight()) {
                    if (!v(motionEvent) && this.e.isFinished()) {
                        z2 = false;
                    }
                    this.f1691m = z2;
                    VelocityTracker velocityTracker = this.f1692n;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f1692n = null;
                    }
                } else {
                    this.i = y2;
                    this.f1698t = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker2 = this.f1692n;
                    if (velocityTracker2 == null) {
                        this.f1692n = VelocityTracker.obtain();
                    } else {
                        velocityTracker2.clear();
                    }
                    this.f1692n.addMovement(motionEvent);
                    this.e.computeScrollOffset();
                    if (!v(motionEvent) && this.e.isFinished()) {
                        z2 = false;
                    }
                    this.f1691m = z2;
                    this.f1679A.g(2, 0);
                }
            }
        } else if (i == 1) {
            this.f1691m = false;
            this.f1698t = -1;
            VelocityTracker velocityTracker3 = this.f1692n;
            if (velocityTracker3 != null) {
                velocityTracker3.recycle();
                this.f1692n = null;
            }
            if (this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i == 2) {
            int i3 = this.f1698t;
            if (i3 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i3);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i3 + " in onInterceptTouchEvent");
                } else {
                    int y3 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y3 - this.i) > this.f1695q && (2 & getNestedScrollAxes()) == 0) {
                        this.f1691m = true;
                        this.i = y3;
                        if (this.f1692n == null) {
                            this.f1692n = VelocityTracker.obtain();
                        }
                        this.f1692n.addMovement(motionEvent);
                        this.f1701w = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i != 3) {
            if (i == 6) {
                o(motionEvent);
            }
        }
        return this.f1691m;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int measuredHeight;
        super.onLayout(z2, i, i3, i4, i5);
        int i6 = 0;
        this.f1688j = false;
        View view = this.f1690l;
        if (view != null && l(view, this)) {
            View view2 = this.f1690l;
            Rect rect = this.f1684d;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        this.f1690l = null;
        if (!this.f1689k) {
            if (this.f1703y != null) {
                scrollTo(getScrollX(), this.f1703y.f1065b);
                this.f1703y = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i6 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i6 != scrollY) {
                scrollTo(getScrollX(), i6);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1689k = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i3) {
        super.onMeasure(i, i3);
        if (this.f1693o && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f3, float f4, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(0.0f, f4, true);
        j((int) f4);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f3, float f4) {
        return this.f1679A.b(f3, f4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i3, int[] iArr) {
        this.f1679A.c(i, i3, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i3, int i4, int i5) {
        n(i5, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        a(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i, int i3, boolean z2, boolean z3) {
        super.scrollTo(i, i3);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (viewFindNextFocus != null && m(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h hVar = (h) parcelable;
        super.onRestoreInstanceState(hVar.getSuperState());
        this.f1703y = hVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        h hVar = new h(super.onSaveInstanceState());
        hVar.f1065b = getScrollY();
        return hVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i, int i3, int i4, int i5) {
        super.onScrollChanged(i, i3, i4, i5);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i3, int i4, int i5) {
        super.onSizeChanged(i, i3, i4, i5);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !m(viewFindFocus, 0, i5)) {
            return;
        }
        Rect rect = this.f1684d;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iH = h(rect);
        if (iH != 0) {
            if (this.f1694p) {
                u(0, iH, false);
            } else {
                scrollBy(0, iH);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return f(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        d(view, 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x0124  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x013a  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0141  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0145  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x014c  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fB0;
        int iRound;
        int i;
        ViewParent parent2;
        if (this.f1692n == null) {
            this.f1692n = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1701w = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f3 = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f1701w);
        C0025m c0025m = this.f1679A;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f1686g;
            EdgeEffect edgeEffect2 = this.f1685f;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f1692n;
                velocityTracker.computeCurrentVelocity(1000, this.f1697s);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f1698t);
                if (Math.abs(yVelocity) >= this.f1696r) {
                    if (d.B(edgeEffect2) != 0.0f) {
                        if (t(edgeEffect2, yVelocity)) {
                            edgeEffect2.onAbsorb(yVelocity);
                        } else {
                            j(-yVelocity);
                        }
                    } else if (d.B(edgeEffect) != 0.0f) {
                        int i3 = -yVelocity;
                        if (t(edgeEffect, i3)) {
                            edgeEffect.onAbsorb(i3);
                        } else {
                            j(i3);
                        }
                    } else {
                        int i4 = -yVelocity;
                        float f4 = i4;
                        if (!c0025m.b(0.0f, f4)) {
                            dispatchNestedFling(0.0f, f4, true);
                            j(i4);
                        }
                    }
                } else if (this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f1698t = -1;
                this.f1691m = false;
                VelocityTracker velocityTracker2 = this.f1692n;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f1692n = null;
                }
                w(0);
                this.f1685f.onRelease();
                this.f1686g.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f1698t);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f1698t + " in onTouchEvent");
                } else {
                    int y2 = (int) motionEvent.getY(iFindPointerIndex);
                    int i5 = this.i - y2;
                    float x2 = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i5 / getHeight();
                    if (d.B(edgeEffect2) != 0.0f) {
                        fB0 = -d.b0(edgeEffect2, -height, x2);
                        if (d.B(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        if (d.B(edgeEffect) != 0.0f) {
                            fB0 = d.b0(edgeEffect, height, 1.0f - x2);
                            if (d.B(edgeEffect) == 0.0f) {
                                edgeEffect.onRelease();
                            }
                        }
                        iRound = Math.round(f3 * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i = i5 - iRound;
                        if (!this.f1691m && Math.abs(i) > this.f1695q) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.f1691m = true;
                            i = i <= 0 ? i - this.f1695q : i + this.f1695q;
                        }
                        if (this.f1691m) {
                            int iS = s(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.i = y2 - iS;
                            this.f1701w += iS;
                        }
                    }
                    f3 = fB0;
                    iRound = Math.round(f3 * getHeight());
                    if (iRound != 0) {
                    }
                    i = i5 - iRound;
                    if (!this.f1691m) {
                        parent2 = getParent();
                        if (parent2 != null) {
                        }
                        this.f1691m = true;
                        if (i <= 0) {
                        }
                    }
                    if (this.f1691m) {
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f1691m && getChildCount() > 0 && this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f1698t = -1;
                this.f1691m = false;
                VelocityTracker velocityTracker3 = this.f1692n;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f1692n = null;
                }
                w(0);
                this.f1685f.onRelease();
                this.f1686g.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.i = (int) motionEvent.getY(actionIndex);
                this.f1698t = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                o(motionEvent);
                this.i = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f1698t));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f1691m && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.e.isFinished()) {
                this.e.abortAnimation();
                w(1);
            }
            int y3 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.i = y3;
            this.f1698t = pointerId;
            c0025m.g(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f1692n;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final boolean p(int i, int i3, int i4, int i5) {
        boolean z2;
        boolean z3;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i6 = i4 + i;
        if (i3 <= 0 && i3 >= 0) {
            z2 = false;
        } else {
            i3 = 0;
            z2 = true;
        }
        if (i6 > i5) {
            z3 = true;
        } else if (i6 < 0) {
            i5 = 0;
            z3 = true;
        } else {
            i5 = i6;
            z3 = false;
        }
        if (z3 && !this.f1679A.f(1)) {
            this.e.springBack(i3, i5, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i3, i5);
        return z2 || z3;
    }

    public final void q(int i) {
        boolean z2 = i == 130;
        int height = getHeight();
        Rect rect = this.f1684d;
        if (z2) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i3 = rect.top;
        int i4 = height + i3;
        rect.bottom = i4;
        r(i, i3, i4);
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0068  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean r(int i, int i3, int i4) {
        boolean z2;
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = height + scrollY;
        boolean z3 = i == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z4 = false;
        for (int i6 = 0; i6 < size; i6++) {
            View view2 = focusables.get(i6);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i3 < bottom && top < i4) {
                boolean z5 = i3 < top && bottom < i4;
                if (view == null) {
                    view = view2;
                    z4 = z5;
                } else {
                    boolean z6 = (z3 && top < view.getTop()) || (!z3 && bottom > view.getBottom());
                    if (z4) {
                        if (z5 && z6) {
                            view = view2;
                        }
                    } else if (z5) {
                        view = view2;
                        z4 = true;
                    } else if (z6) {
                    }
                }
            }
        }
        View view3 = view == null ? this : view;
        if (i3 < scrollY || i4 > i5) {
            s(z3 ? i3 - scrollY : i4 - i5, -1, null, 0, 1, true);
            z2 = true;
        } else {
            z2 = false;
        }
        if (view3 != findFocus()) {
            view3.requestFocus(i);
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f1688j) {
            this.f1690l = view2;
        } else {
            Rect rect = this.f1684d;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iH = h(rect);
        boolean z3 = iH != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, iH);
            } else {
                u(0, iH, false);
            }
        }
        return z3;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        VelocityTracker velocityTracker;
        if (z2 && (velocityTracker = this.f1692n) != null) {
            velocityTracker.recycle();
            this.f1692n = null;
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f1688j = true;
        super.requestLayout();
    }

    /* JADX WARN: Removed duplicated region for block: B:53:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0131  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int s(int i, int i3, MotionEvent motionEvent, int i4, int i5, boolean z2) {
        int i6;
        int i7;
        boolean z3;
        boolean z4;
        VelocityTracker velocityTracker;
        C0025m c0025m = this.f1679A;
        if (i5 == 1) {
            c0025m.g(2, i5);
        }
        boolean zC = this.f1679A.c(0, i, i5, this.f1700v, this.f1699u);
        int[] iArr = this.f1700v;
        int[] iArr2 = this.f1699u;
        if (zC) {
            i6 = i - iArr[1];
            i7 = iArr2[1];
        } else {
            i6 = i;
            i7 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z5 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z2;
        boolean z6 = p(i6, 0, scrollY, scrollRange) && !c0025m.f(i5);
        int scrollY2 = getScrollY() - scrollY;
        if (motionEvent != null && scrollY2 != 0) {
            getScrollFeedbackProvider().f944a.c(motionEvent.getDeviceId(), motionEvent.getSource(), i3, scrollY2);
        }
        iArr[1] = 0;
        this.f1679A.d(0, scrollY2, 0, i6 - scrollY2, this.f1699u, i5, iArr);
        int i8 = i7 + iArr2[1];
        int i9 = i6 - iArr[1];
        int i10 = scrollY + i9;
        EdgeEffect edgeEffect = this.f1686g;
        EdgeEffect edgeEffect2 = this.f1685f;
        if (i10 >= 0) {
            if (i10 > scrollRange && z5) {
                d.b0(edgeEffect, i9 / getHeight(), 1.0f - (i4 / getWidth()));
                if (motionEvent != null) {
                    z3 = false;
                    getScrollFeedbackProvider().f944a.a(motionEvent.getDeviceId(), motionEvent.getSource(), i3, false);
                } else {
                    z3 = false;
                }
                if (!edgeEffect2.isFinished()) {
                    edgeEffect2.onRelease();
                }
            }
            if (edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
                postInvalidateOnAnimation();
                z4 = z3;
            } else {
                z4 = z6;
            }
            if (z4 && i5 == 0 && (velocityTracker = this.f1692n) != null) {
                velocityTracker.clear();
            }
            if (i5 == 1) {
                w(i5);
                edgeEffect2.onRelease();
                edgeEffect.onRelease();
            }
            return i8;
        }
        if (z5) {
            d.b0(edgeEffect2, (-i9) / getHeight(), i4 / getWidth());
            if (motionEvent != null) {
                getScrollFeedbackProvider().f944a.a(motionEvent.getDeviceId(), motionEvent.getSource(), i3, true);
            }
            if (!edgeEffect.isFinished()) {
                edgeEffect.onRelease();
            }
        }
        z3 = false;
        if (edgeEffect2.isFinished()) {
            postInvalidateOnAnimation();
            z4 = z3;
        }
        if (z4) {
            velocityTracker.clear();
        }
        if (i5 == 1) {
        }
        return i8;
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i < 0) {
                i = 0;
            } else if (width + i > width2) {
                i = width2 - width;
            }
            if (height >= height2 || i3 < 0) {
                i3 = 0;
            } else if (height + i3 > height2) {
                i3 = height2 - height;
            }
            if (i == getScrollX() && i3 == getScrollY()) {
                return;
            }
            super.scrollTo(i, i3);
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.f1693o) {
            this.f1693o = z2;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        C0025m c0025m = this.f1679A;
        if (c0025m.f928d) {
            WeakHashMap weakHashMap = O.f854a;
            G.m(c0025m.f927c);
        }
        c0025m.f928d = z2;
    }

    public void setOnScrollChangeListener(g gVar) {
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.f1694p = z2;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.f1679A.g(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        float fB = d.B(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i) * 0.35f;
        float f3 = this.f1682b * 0.015f;
        double dLog = Math.log(fAbs / f3);
        double d3 = f1677D;
        return ((float) (Math.exp((d3 / (d3 - 1.0d)) * dLog) * ((double) f3))) < fB;
    }

    public final void u(int i, int i3, boolean z2) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f1683c > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.e.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, height - height2))) - scrollY, 250);
            if (z2) {
                this.f1679A.g(2, 1);
            } else {
                w(1);
            }
            this.f1702x = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.e.isFinished()) {
                this.e.abortAnimation();
                w(1);
            }
            scrollBy(i, i3);
        }
        this.f1683c = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z2;
        EdgeEffect edgeEffect = this.f1685f;
        if (d.B(edgeEffect) != 0.0f) {
            d.b0(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z2 = true;
        } else {
            z2 = false;
        }
        EdgeEffect edgeEffect2 = this.f1686g;
        if (d.B(edgeEffect2) == 0.0f) {
            return z2;
        }
        d.b0(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i) {
        this.f1679A.h(i);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
