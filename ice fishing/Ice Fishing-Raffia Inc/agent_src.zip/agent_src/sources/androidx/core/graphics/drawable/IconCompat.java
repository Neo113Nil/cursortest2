package androidx.core.graphics.drawable;

import I.a;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f1668k = PorterDuff.Mode.SRC_IN;

    /* renamed from: b, reason: collision with root package name */
    public Object f1670b;

    /* renamed from: j, reason: collision with root package name */
    public String f1676j;

    /* renamed from: a, reason: collision with root package name */
    public int f1669a = -1;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f1671c = null;

    /* renamed from: d, reason: collision with root package name */
    public Parcelable f1672d = null;
    public int e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f1673f = 0;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f1674g = null;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f1675h = f1668k;
    public String i = null;

    public final String toString() {
        String str;
        int iIntValue;
        if (this.f1669a == -1) {
            return String.valueOf(this.f1670b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f1669a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f1669a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f1670b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f1670b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f1676j);
                sb.append(" id=");
                int i = this.f1669a;
                if (i == -1) {
                    int i3 = Build.VERSION.SDK_INT;
                    Object obj = this.f1670b;
                    if (i3 >= 28) {
                        iIntValue = a.b(obj);
                    } else {
                        iIntValue = 0;
                        try {
                            iIntValue = ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
                        } catch (IllegalAccessException e) {
                            Log.e("IconCompat", "Unable to get icon resource", e);
                        } catch (NoSuchMethodException e3) {
                            Log.e("IconCompat", "Unable to get icon resource", e3);
                        } catch (InvocationTargetException e4) {
                            Log.e("IconCompat", "Unable to get icon resource", e4);
                        }
                    }
                } else {
                    if (i != 2) {
                        throw new IllegalStateException("called getResId() on " + this);
                    }
                    iIntValue = this.e;
                }
                sb.append(String.format("0x%08x", Integer.valueOf(iIntValue)));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.e);
                if (this.f1673f != 0) {
                    sb.append(" off=");
                    sb.append(this.f1673f);
                    break;
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f1670b);
                break;
        }
        if (this.f1674g != null) {
            sb.append(" tint=");
            sb.append(this.f1674g);
        }
        if (this.f1675h != f1668k) {
            sb.append(" mode=");
            sb.append(this.f1675h);
        }
        sb.append(")");
        return sb.toString();
    }
}
