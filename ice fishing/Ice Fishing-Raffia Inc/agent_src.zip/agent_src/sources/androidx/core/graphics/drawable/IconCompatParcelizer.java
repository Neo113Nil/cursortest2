package androidx.core.graphics.drawable;

import G0.b;
import G0.c;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(b bVar) {
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.f1669a;
        if (bVar.e(1)) {
            i = ((c) bVar).e.readInt();
        }
        iconCompat.f1669a = i;
        byte[] bArr = iconCompat.f1671c;
        if (bVar.e(2)) {
            Parcel parcel = ((c) bVar).e;
            int i3 = parcel.readInt();
            if (i3 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i3];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f1671c = bArr;
        iconCompat.f1672d = bVar.f(iconCompat.f1672d, 3);
        int i4 = iconCompat.e;
        if (bVar.e(4)) {
            i4 = ((c) bVar).e.readInt();
        }
        iconCompat.e = i4;
        int i5 = iconCompat.f1673f;
        if (bVar.e(5)) {
            i5 = ((c) bVar).e.readInt();
        }
        iconCompat.f1673f = i5;
        iconCompat.f1674g = (ColorStateList) bVar.f(iconCompat.f1674g, 6);
        String string = iconCompat.i;
        if (bVar.e(7)) {
            string = ((c) bVar).e.readString();
        }
        iconCompat.i = string;
        String string2 = iconCompat.f1676j;
        if (bVar.e(8)) {
            string2 = ((c) bVar).e.readString();
        }
        iconCompat.f1676j = string2;
        iconCompat.f1675h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.f1669a) {
            case -1:
                Parcelable parcelable = iconCompat.f1672d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f1670b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f1672d;
                if (parcelable2 != null) {
                    iconCompat.f1670b = parcelable2;
                } else {
                    byte[] bArr3 = iconCompat.f1671c;
                    iconCompat.f1670b = bArr3;
                    iconCompat.f1669a = 3;
                    iconCompat.e = 0;
                    iconCompat.f1673f = bArr3.length;
                }
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f1671c, Charset.forName("UTF-16"));
                iconCompat.f1670b = str;
                if (iconCompat.f1669a == 2 && iconCompat.f1676j == null) {
                    iconCompat.f1676j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f1670b = iconCompat.f1671c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, b bVar) {
        bVar.getClass();
        iconCompat.i = iconCompat.f1675h.name();
        switch (iconCompat.f1669a) {
            case -1:
                iconCompat.f1672d = (Parcelable) iconCompat.f1670b;
                break;
            case 1:
            case 5:
                iconCompat.f1672d = (Parcelable) iconCompat.f1670b;
                break;
            case 2:
                iconCompat.f1671c = ((String) iconCompat.f1670b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f1671c = (byte[]) iconCompat.f1670b;
                break;
            case 4:
            case 6:
                iconCompat.f1671c = iconCompat.f1670b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f1669a;
        if (-1 != i) {
            bVar.h(1);
            ((c) bVar).e.writeInt(i);
        }
        byte[] bArr = iconCompat.f1671c;
        if (bArr != null) {
            bVar.h(2);
            int length = bArr.length;
            Parcel parcel = ((c) bVar).e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1672d;
        if (parcelable != null) {
            bVar.h(3);
            ((c) bVar).e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.e;
        if (i3 != 0) {
            bVar.h(4);
            ((c) bVar).e.writeInt(i3);
        }
        int i4 = iconCompat.f1673f;
        if (i4 != 0) {
            bVar.h(5);
            ((c) bVar).e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f1674g;
        if (colorStateList != null) {
            bVar.h(6);
            ((c) bVar).e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.i;
        if (str != null) {
            bVar.h(7);
            ((c) bVar).e.writeString(str);
        }
        String str2 = iconCompat.f1676j;
        if (str2 != null) {
            bVar.h(8);
            ((c) bVar).e.writeString(str2);
        }
    }
}
