package androidx.core.app;

import G0.b;
import G0.c;
import G0.d;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        d dVarG = remoteActionCompat.f1663a;
        if (bVar.e(1)) {
            dVarG = bVar.g();
        }
        remoteActionCompat.f1663a = (IconCompat) dVarG;
        CharSequence charSequence = remoteActionCompat.f1664b;
        if (bVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).e);
        }
        remoteActionCompat.f1664b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f1665c;
        if (bVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).e);
        }
        remoteActionCompat.f1665c = charSequence2;
        remoteActionCompat.f1666d = (PendingIntent) bVar.f(remoteActionCompat.f1666d, 4);
        boolean z2 = remoteActionCompat.e;
        if (bVar.e(5)) {
            z2 = ((c) bVar).e.readInt() != 0;
        }
        remoteActionCompat.e = z2;
        boolean z3 = remoteActionCompat.f1667f;
        if (bVar.e(6)) {
            z3 = ((c) bVar).e.readInt() != 0;
        }
        remoteActionCompat.f1667f = z3;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, b bVar) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        bVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f1663a;
        bVar.h(1);
        bVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f1664b;
        bVar.h(2);
        Parcel parcel = ((c) bVar).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f1665c;
        bVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f1666d;
        bVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z2 = remoteActionCompat.e;
        bVar.h(5);
        parcel.writeInt(z2 ? 1 : 0);
        boolean z3 = remoteActionCompat.f1667f;
        bVar.h(6);
        parcel.writeInt(z3 ? 1 : 0);
    }
}
