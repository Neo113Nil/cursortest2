package androidx.core.app;

import G0.d;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements d {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f1663a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f1664b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f1665c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f1666d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1667f;
}
