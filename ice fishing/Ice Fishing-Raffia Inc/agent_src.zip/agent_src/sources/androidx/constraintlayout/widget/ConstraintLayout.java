package androidx.constraintlayout.widget;

import A.c;
import A.d;
import A.e;
import A.f;
import A.g;
import A.h;
import A.i;
import A.p;
import A.q;
import A.r;
import A.t;
import A.u;
import P.C0023k;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;
import v.C0468c;
import x.C0492a;
import x.C0495d;
import x.C0496e;
import x.j;
import y.AbstractC0530o;
import y.C0518c;
import y.C0520e;
import y.C0524i;
import y.C0526k;
import y.C0528m;

/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* renamed from: q, reason: collision with root package name */
    public static u f1627q;

    /* renamed from: b, reason: collision with root package name */
    public final SparseArray f1628b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f1629c;

    /* renamed from: d, reason: collision with root package name */
    public final C0496e f1630d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f1631f;

    /* renamed from: g, reason: collision with root package name */
    public int f1632g;

    /* renamed from: h, reason: collision with root package name */
    public int f1633h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public int f1634j;

    /* renamed from: k, reason: collision with root package name */
    public p f1635k;

    /* renamed from: l, reason: collision with root package name */
    public i f1636l;

    /* renamed from: m, reason: collision with root package name */
    public int f1637m;

    /* renamed from: n, reason: collision with root package name */
    public HashMap f1638n;

    /* renamed from: o, reason: collision with root package name */
    public final SparseArray f1639o;

    /* renamed from: p, reason: collision with root package name */
    public final f f1640p;

    public ConstraintLayout(Context context, AttributeSet attributeSet) throws XmlPullParserException, IOException, NumberFormatException {
        super(context, attributeSet);
        this.f1628b = new SparseArray();
        this.f1629c = new ArrayList(4);
        this.f1630d = new C0496e();
        this.e = 0;
        this.f1631f = 0;
        this.f1632g = Integer.MAX_VALUE;
        this.f1633h = Integer.MAX_VALUE;
        this.i = true;
        this.f1634j = 257;
        this.f1635k = null;
        this.f1636l = null;
        this.f1637m = -1;
        this.f1638n = new HashMap();
        this.f1639o = new SparseArray();
        this.f1640p = new f(this, this);
        i(attributeSet, 0);
    }

    public static e g() {
        e eVar = new e(-2, -2);
        eVar.f39a = -1;
        eVar.f41b = -1;
        eVar.f43c = -1.0f;
        eVar.f45d = true;
        eVar.e = -1;
        eVar.f48f = -1;
        eVar.f50g = -1;
        eVar.f52h = -1;
        eVar.i = -1;
        eVar.f55j = -1;
        eVar.f57k = -1;
        eVar.f59l = -1;
        eVar.f61m = -1;
        eVar.f63n = -1;
        eVar.f65o = -1;
        eVar.f67p = -1;
        eVar.f69q = 0;
        eVar.f70r = 0.0f;
        eVar.f71s = -1;
        eVar.f72t = -1;
        eVar.f73u = -1;
        eVar.f74v = -1;
        eVar.f75w = Integer.MIN_VALUE;
        eVar.f76x = Integer.MIN_VALUE;
        eVar.f77y = Integer.MIN_VALUE;
        eVar.f78z = Integer.MIN_VALUE;
        eVar.f15A = Integer.MIN_VALUE;
        eVar.f16B = Integer.MIN_VALUE;
        eVar.f17C = Integer.MIN_VALUE;
        eVar.f18D = 0;
        eVar.f19E = 0.5f;
        eVar.F = 0.5f;
        eVar.f20G = null;
        eVar.f21H = -1.0f;
        eVar.f22I = -1.0f;
        eVar.f23J = 0;
        eVar.K = 0;
        eVar.f24L = 0;
        eVar.f25M = 0;
        eVar.f26N = 0;
        eVar.f27O = 0;
        eVar.f28P = 0;
        eVar.f29Q = 0;
        eVar.f30R = 1.0f;
        eVar.f31S = 1.0f;
        eVar.f32T = -1;
        eVar.f33U = -1;
        eVar.f34V = -1;
        eVar.f35W = false;
        eVar.f36X = false;
        eVar.f37Y = null;
        eVar.f38Z = 0;
        eVar.f40a0 = true;
        eVar.f42b0 = true;
        eVar.f44c0 = false;
        eVar.f46d0 = false;
        eVar.f47e0 = false;
        eVar.f49f0 = -1;
        eVar.f51g0 = -1;
        eVar.f53h0 = -1;
        eVar.f54i0 = -1;
        eVar.f56j0 = Integer.MIN_VALUE;
        eVar.f58k0 = Integer.MIN_VALUE;
        eVar.f60l0 = 0.5f;
        eVar.f68p0 = new C0495d();
        return eVar;
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int iMax2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static u getSharedValues() {
        if (f1627q == null) {
            u uVar = new u();
            new SparseIntArray();
            new HashMap();
            f1627q = uVar;
        }
        return f1627q;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) throws NumberFormatException {
        Object tag;
        int size;
        ArrayList arrayList = this.f1629c;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i = 0; i < size; i++) {
                ((c) arrayList.get(i)).getClass();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i4 = Integer.parseInt(strArrSplit[0]);
                        int i5 = Integer.parseInt(strArrSplit[1]);
                        int i6 = Integer.parseInt(strArrSplit[2]);
                        int i7 = (int) ((i4 / 1080.0f) * width);
                        int i8 = (int) ((i5 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f3 = i7;
                        float f4 = i8;
                        float f5 = i7 + ((int) ((i6 / 1080.0f) * width));
                        canvas.drawLine(f3, f4, f5, f4, paint);
                        float f6 = i8 + ((int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height));
                        canvas.drawLine(f5, f4, f5, f6, paint);
                        canvas.drawLine(f5, f6, f3, f6, paint);
                        canvas.drawLine(f3, f6, f3, f4, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f3, f4, f5, f6, paint);
                        canvas.drawLine(f3, f6, f5, f4, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.i = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        e eVar = new e(context, attributeSet);
        eVar.f39a = -1;
        eVar.f41b = -1;
        eVar.f43c = -1.0f;
        eVar.f45d = true;
        eVar.e = -1;
        eVar.f48f = -1;
        eVar.f50g = -1;
        eVar.f52h = -1;
        eVar.i = -1;
        eVar.f55j = -1;
        eVar.f57k = -1;
        eVar.f59l = -1;
        eVar.f61m = -1;
        eVar.f63n = -1;
        eVar.f65o = -1;
        eVar.f67p = -1;
        eVar.f69q = 0;
        eVar.f70r = 0.0f;
        eVar.f71s = -1;
        eVar.f72t = -1;
        eVar.f73u = -1;
        eVar.f74v = -1;
        eVar.f75w = Integer.MIN_VALUE;
        eVar.f76x = Integer.MIN_VALUE;
        eVar.f77y = Integer.MIN_VALUE;
        eVar.f78z = Integer.MIN_VALUE;
        eVar.f15A = Integer.MIN_VALUE;
        eVar.f16B = Integer.MIN_VALUE;
        eVar.f17C = Integer.MIN_VALUE;
        eVar.f18D = 0;
        eVar.f19E = 0.5f;
        eVar.F = 0.5f;
        eVar.f20G = null;
        eVar.f21H = -1.0f;
        eVar.f22I = -1.0f;
        eVar.f23J = 0;
        eVar.K = 0;
        eVar.f24L = 0;
        eVar.f25M = 0;
        eVar.f26N = 0;
        eVar.f27O = 0;
        eVar.f28P = 0;
        eVar.f29Q = 0;
        eVar.f30R = 1.0f;
        eVar.f31S = 1.0f;
        eVar.f32T = -1;
        eVar.f33U = -1;
        eVar.f34V = -1;
        eVar.f35W = false;
        eVar.f36X = false;
        eVar.f37Y = null;
        eVar.f38Z = 0;
        eVar.f40a0 = true;
        eVar.f42b0 = true;
        eVar.f44c0 = false;
        eVar.f46d0 = false;
        eVar.f47e0 = false;
        eVar.f49f0 = -1;
        eVar.f51g0 = -1;
        eVar.f53h0 = -1;
        eVar.f54i0 = -1;
        eVar.f56j0 = Integer.MIN_VALUE;
        eVar.f58k0 = Integer.MIN_VALUE;
        eVar.f60l0 = 0.5f;
        eVar.f68p0 = new C0495d();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, t.f206b);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i);
            int i3 = d.f14a.get(index);
            switch (i3) {
                case 1:
                    eVar.f34V = typedArrayObtainStyledAttributes.getInt(index, eVar.f34V);
                    break;
                case 2:
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f67p);
                    eVar.f67p = resourceId;
                    if (resourceId == -1) {
                        eVar.f67p = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 3:
                    eVar.f69q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f69q);
                    break;
                case 4:
                    float f3 = typedArrayObtainStyledAttributes.getFloat(index, eVar.f70r) % 360.0f;
                    eVar.f70r = f3;
                    if (f3 < 0.0f) {
                        eVar.f70r = (360.0f - f3) % 360.0f;
                        break;
                    } else {
                        break;
                    }
                case 5:
                    eVar.f39a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f39a);
                    break;
                case 6:
                    eVar.f41b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f41b);
                    break;
                case 7:
                    eVar.f43c = typedArrayObtainStyledAttributes.getFloat(index, eVar.f43c);
                    break;
                case 8:
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.e);
                    eVar.e = resourceId2;
                    if (resourceId2 == -1) {
                        eVar.e = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 9:
                    int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f48f);
                    eVar.f48f = resourceId3;
                    if (resourceId3 == -1) {
                        eVar.f48f = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 10:
                    int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f50g);
                    eVar.f50g = resourceId4;
                    if (resourceId4 == -1) {
                        eVar.f50g = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 11:
                    int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f52h);
                    eVar.f52h = resourceId5;
                    if (resourceId5 == -1) {
                        eVar.f52h = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 12:
                    int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.i);
                    eVar.i = resourceId6;
                    if (resourceId6 == -1) {
                        eVar.i = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 13:
                    int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f55j);
                    eVar.f55j = resourceId7;
                    if (resourceId7 == -1) {
                        eVar.f55j = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 14:
                    int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f57k);
                    eVar.f57k = resourceId8;
                    if (resourceId8 == -1) {
                        eVar.f57k = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 15:
                    int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f59l);
                    eVar.f59l = resourceId9;
                    if (resourceId9 == -1) {
                        eVar.f59l = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 16:
                    int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f61m);
                    eVar.f61m = resourceId10;
                    if (resourceId10 == -1) {
                        eVar.f61m = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 17:
                    int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f71s);
                    eVar.f71s = resourceId11;
                    if (resourceId11 == -1) {
                        eVar.f71s = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 18:
                    int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f72t);
                    eVar.f72t = resourceId12;
                    if (resourceId12 == -1) {
                        eVar.f72t = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 19:
                    int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f73u);
                    eVar.f73u = resourceId13;
                    if (resourceId13 == -1) {
                        eVar.f73u = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 20:
                    int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f74v);
                    eVar.f74v = resourceId14;
                    if (resourceId14 == -1) {
                        eVar.f74v = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 21:
                    eVar.f75w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f75w);
                    break;
                case 22:
                    eVar.f76x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f76x);
                    break;
                case 23:
                    eVar.f77y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f77y);
                    break;
                case 24:
                    eVar.f78z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f78z);
                    break;
                case 25:
                    eVar.f15A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f15A);
                    break;
                case 26:
                    eVar.f16B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f16B);
                    break;
                case 27:
                    eVar.f35W = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f35W);
                    break;
                case 28:
                    eVar.f36X = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f36X);
                    break;
                case 29:
                    eVar.f19E = typedArrayObtainStyledAttributes.getFloat(index, eVar.f19E);
                    break;
                case 30:
                    eVar.F = typedArrayObtainStyledAttributes.getFloat(index, eVar.F);
                    break;
                case 31:
                    int i4 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    eVar.f24L = i4;
                    if (i4 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 32:
                    int i5 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    eVar.f25M = i5;
                    if (i5 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 33:
                    try {
                        eVar.f26N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f26N);
                        break;
                    } catch (Exception unused) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.f26N) == -2) {
                            eVar.f26N = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 34:
                    try {
                        eVar.f28P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f28P);
                        break;
                    } catch (Exception unused2) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.f28P) == -2) {
                            eVar.f28P = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 35:
                    eVar.f30R = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, eVar.f30R));
                    eVar.f24L = 2;
                    break;
                case 36:
                    try {
                        eVar.f27O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f27O);
                        break;
                    } catch (Exception unused3) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.f27O) == -2) {
                            eVar.f27O = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 37:
                    try {
                        eVar.f29Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f29Q);
                        break;
                    } catch (Exception unused4) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.f29Q) == -2) {
                            eVar.f29Q = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 38:
                    eVar.f31S = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, eVar.f31S));
                    eVar.f25M = 2;
                    break;
                default:
                    switch (i3) {
                        case 44:
                            p.h(eVar, typedArrayObtainStyledAttributes.getString(index));
                            break;
                        case 45:
                            eVar.f21H = typedArrayObtainStyledAttributes.getFloat(index, eVar.f21H);
                            break;
                        case 46:
                            eVar.f22I = typedArrayObtainStyledAttributes.getFloat(index, eVar.f22I);
                            break;
                        case 47:
                            eVar.f23J = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 48:
                            eVar.K = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 49:
                            eVar.f32T = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f32T);
                            break;
                        case 50:
                            eVar.f33U = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f33U);
                            break;
                        case 51:
                            eVar.f37Y = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 52:
                            int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f63n);
                            eVar.f63n = resourceId15;
                            if (resourceId15 == -1) {
                                eVar.f63n = typedArrayObtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 53:
                            int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f65o);
                            eVar.f65o = resourceId16;
                            if (resourceId16 == -1) {
                                eVar.f65o = typedArrayObtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 54:
                            eVar.f18D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f18D);
                            break;
                        case 55:
                            eVar.f17C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f17C);
                            break;
                        default:
                            switch (i3) {
                                case 64:
                                    p.g(eVar, typedArrayObtainStyledAttributes, index, 0);
                                    break;
                                case 65:
                                    p.g(eVar, typedArrayObtainStyledAttributes, index, 1);
                                    break;
                                case 66:
                                    eVar.f38Z = typedArrayObtainStyledAttributes.getInt(index, eVar.f38Z);
                                    break;
                                case 67:
                                    eVar.f45d = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f45d);
                                    break;
                            }
                    }
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        eVar.a();
        return eVar;
    }

    public int getMaxHeight() {
        return this.f1633h;
    }

    public int getMaxWidth() {
        return this.f1632g;
    }

    public int getMinHeight() {
        return this.f1631f;
    }

    public int getMinWidth() {
        return this.e;
    }

    public int getOptimizationLevel() {
        return this.f1630d.f5856D0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        C0496e c0496e = this.f1630d;
        if (c0496e.f5829j == null) {
            int id2 = getId();
            if (id2 != -1) {
                c0496e.f5829j = getContext().getResources().getResourceEntryName(id2);
            } else {
                c0496e.f5829j = "parent";
            }
        }
        if (c0496e.f5827h0 == null) {
            c0496e.f5827h0 = c0496e.f5829j;
            Log.v("ConstraintLayout", " setDebugName " + c0496e.f5827h0);
        }
        Iterator it = c0496e.f5864q0.iterator();
        while (it.hasNext()) {
            C0495d c0495d = (C0495d) it.next();
            View view = c0495d.f5823f0;
            if (view != null) {
                if (c0495d.f5829j == null && (id = view.getId()) != -1) {
                    c0495d.f5829j = getContext().getResources().getResourceEntryName(id);
                }
                if (c0495d.f5827h0 == null) {
                    c0495d.f5827h0 = c0495d.f5829j;
                    Log.v("ConstraintLayout", " setDebugName " + c0495d.f5827h0);
                }
            }
        }
        c0496e.n(sb);
        return sb.toString();
    }

    public final C0495d h(View view) {
        if (view == this) {
            return this.f1630d;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof e) {
            return ((e) view.getLayoutParams()).f68p0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof e) {
            return ((e) view.getLayoutParams()).f68p0;
        }
        return null;
    }

    public final void i(AttributeSet attributeSet, int i) throws XmlPullParserException, IOException, NumberFormatException {
        C0496e c0496e = this.f1630d;
        c0496e.f5823f0 = this;
        f fVar = this.f1640p;
        c0496e.f5868u0 = fVar;
        c0496e.f5866s0.f5989f = fVar;
        this.f1628b.put(getId(), this);
        this.f1635k = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, t.f206b, i, 0);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == 16) {
                    this.e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.e);
                } else if (index == 17) {
                    this.f1631f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f1631f);
                } else if (index == 14) {
                    this.f1632g = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f1632g);
                } else if (index == 15) {
                    this.f1633h = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f1633h);
                } else if (index == 113) {
                    this.f1634j = typedArrayObtainStyledAttributes.getInt(index, this.f1634j);
                } else if (index == 56) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            j(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1636l = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        p pVar = new p();
                        this.f1635k = pVar;
                        pVar.e(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1635k = null;
                    }
                    this.f1637m = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        c0496e.f5856D0 = this.f1634j;
        C0468c.f5635q = c0496e.W(512);
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0076  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void j(int i) throws XmlPullParserException, Resources.NotFoundException, IOException, NumberFormatException {
        int eventType;
        g gVar;
        Context context = getContext();
        i iVar = new i(0, false);
        iVar.f94c = new SparseArray();
        iVar.f95d = new SparseArray();
        XmlResourceParser xml = context.getResources().getXml(i);
        try {
            eventType = xml.getEventType();
            gVar = null;
        } catch (IOException e) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i, e);
        } catch (XmlPullParserException e3) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i, e3);
        }
        while (true) {
            char c3 = 1;
            if (eventType == 1) {
                this.f1636l = iVar;
                return;
            }
            if (eventType == 2) {
                String name = xml.getName();
                switch (name.hashCode()) {
                    case -1349929691:
                        if (!name.equals("ConstraintSet")) {
                            c3 = 65535;
                            break;
                        } else {
                            c3 = 4;
                            break;
                        }
                    case 80204913:
                        if (name.equals("State")) {
                            c3 = 2;
                            break;
                        }
                        break;
                    case 1382829617:
                        if (name.equals("StateSet")) {
                            break;
                        }
                        break;
                    case 1657696882:
                        if (name.equals("layoutDescription")) {
                            c3 = 0;
                            break;
                        }
                        break;
                    case 1901439077:
                        if (name.equals("Variant")) {
                            c3 = 3;
                            break;
                        }
                        break;
                    default:
                        c3 = 65535;
                        break;
                }
                if (c3 == 2) {
                    g gVar2 = new g(context, xml);
                    ((SparseArray) iVar.f94c).put(gVar2.f86b, gVar2);
                    gVar = gVar2;
                } else if (c3 == 3) {
                    h hVar = new h(context, xml);
                    if (gVar != null) {
                        ((ArrayList) gVar.f88d).add(hVar);
                    }
                } else if (c3 == 4) {
                    iVar.J(context, xml);
                }
            }
            eventType = xml.next();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:159:0x02ea  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0309  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x032b  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x0348  */
    /* JADX WARN: Removed duplicated region for block: B:287:0x04d1  */
    /* JADX WARN: Removed duplicated region for block: B:420:0x04d5 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void k(C0496e c0496e, int i, int i3, int i4) {
        int iMin;
        int iMax;
        int iMin2;
        int iMax2;
        int i5;
        int i6;
        boolean z2;
        f fVar;
        int i7;
        int i8;
        int i9;
        boolean zT;
        ArrayList arrayList;
        int i10;
        f fVar2;
        int i11;
        f fVar3;
        boolean z3;
        C0526k c0526k;
        C0528m c0528m;
        int i12;
        int i13;
        int i14;
        int i15;
        int[] iArr;
        int i16;
        int i17;
        boolean z4;
        Iterator it;
        Iterator it2;
        boolean z5;
        C0496e c0496e2 = c0496e;
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i4);
        int iMax3 = Math.max(0, getPaddingTop());
        int iMax4 = Math.max(0, getPaddingBottom());
        int i18 = iMax3 + iMax4;
        int paddingWidth = getPaddingWidth();
        f fVar4 = this.f1640p;
        fVar4.f80b = iMax3;
        fVar4.f81c = iMax4;
        fVar4.f82d = paddingWidth;
        fVar4.e = i18;
        fVar4.f83f = i3;
        fVar4.f84g = i4;
        int iMax5 = Math.max(0, getPaddingStart());
        int iMax6 = Math.max(0, getPaddingEnd());
        int i19 = 1;
        if (iMax5 <= 0 && iMax6 <= 0) {
            iMax5 = Math.max(0, getPaddingLeft());
        } else if ((getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection()) {
            iMax5 = iMax6;
        }
        int i20 = size - paddingWidth;
        int i21 = size2 - i18;
        int i22 = fVar4.e;
        int i23 = fVar4.f82d;
        int childCount = getChildCount();
        if (mode != Integer.MIN_VALUE) {
            if (mode != 0) {
                if (mode != 1073741824) {
                    iMin = 0;
                } else {
                    iMin = Math.min(this.f1632g - i23, i20);
                    i19 = 1;
                }
            } else if (childCount == 0) {
                iMax = Math.max(0, this.e);
                iMin = iMax;
                i19 = 2;
            } else {
                iMin = 0;
                i19 = 2;
            }
        } else if (childCount == 0) {
            iMax = Math.max(0, this.e);
            iMin = iMax;
            i19 = 2;
        } else {
            iMin = i20;
            i19 = 2;
        }
        if (mode2 != Integer.MIN_VALUE) {
            if (mode2 != 0) {
                iMin2 = mode2 != 1073741824 ? 0 : Math.min(this.f1633h - i22, i21);
                i5 = 1;
            } else if (childCount == 0) {
                iMax2 = Math.max(0, this.f1631f);
                iMin2 = iMax2;
                i5 = 2;
            } else {
                iMin2 = 0;
                i5 = 2;
            }
        } else if (childCount == 0) {
            iMax2 = Math.max(0, this.f1631f);
            iMin2 = iMax2;
            i5 = 2;
        } else {
            iMin2 = i21;
            i5 = 2;
        }
        int iQ = c0496e.q();
        C0520e c0520e = c0496e2.f5866s0;
        int i24 = iMin;
        if (i24 != iQ || iMin2 != c0496e.k()) {
            c0520e.f5987c = true;
        }
        c0496e2.f5811Y = 0;
        c0496e2.f5812Z = 0;
        int i25 = this.f1632g - i23;
        int[] iArr2 = c0496e2.f5791C;
        iArr2[0] = i25;
        iArr2[1] = this.f1633h - i22;
        c0496e2.f5816b0 = 0;
        c0496e2.f5818c0 = 0;
        c0496e2.M(i19);
        c0496e2.O(i24);
        c0496e2.N(i5);
        c0496e2.L(iMin2);
        int i26 = this.e - i23;
        if (i26 < 0) {
            c0496e2.f5816b0 = 0;
        } else {
            c0496e2.f5816b0 = i26;
        }
        int i27 = this.f1631f - i22;
        if (i27 < 0) {
            c0496e2.f5818c0 = 0;
        } else {
            c0496e2.f5818c0 = i27;
        }
        c0496e2.f5871x0 = iMax5;
        c0496e2.f5872y0 = iMax3;
        C0023k c0023k = c0496e2.f5865r0;
        c0023k.getClass();
        f fVar5 = c0496e2.f5868u0;
        int size3 = c0496e2.f5864q0.size();
        int iQ2 = c0496e.q();
        int iK = c0496e.k();
        boolean zC = j.c(i, 128);
        boolean z6 = zC || j.c(i, 64);
        if (z6) {
            for (int i28 = 0; i28 < size3; i28++) {
                C0495d c0495d = (C0495d) c0496e2.f5864q0.get(i28);
                int[] iArr3 = c0495d.f5842p0;
                boolean z7 = (iArr3[0] == 3) && (iArr3[1] == 3) && c0495d.f5809W > 0.0f;
                if ((c0495d.x() && z7) || ((c0495d.y() && z7) || (c0495d instanceof x.g) || c0495d.x() || c0495d.y())) {
                    i6 = 1073741824;
                    z6 = false;
                    break;
                }
            }
            i6 = 1073741824;
        } else {
            i6 = 1073741824;
        }
        boolean z8 = ((mode == i6 && mode2 == i6) || zC) & z6;
        if (z8) {
            int iMin3 = Math.min(iArr2[0], i20);
            int iMin4 = Math.min(iArr2[1], i21);
            if (mode == 1073741824 && c0496e.q() != iMin3) {
                c0496e2.O(iMin3);
                c0496e2.f5866s0.f5986b = true;
            }
            if (mode2 == 1073741824 && c0496e.k() != iMin4) {
                c0496e2.L(iMin4);
                c0496e2.f5866s0.f5986b = true;
            }
            if (mode == 1073741824 && mode2 == 1073741824) {
                boolean z9 = c0520e.f5986b;
                C0496e c0496e3 = c0520e.f5985a;
                if (z9 || c0520e.f5987c) {
                    Iterator it3 = c0496e3.f5864q0.iterator();
                    while (it3.hasNext()) {
                        C0495d c0495d2 = (C0495d) it3.next();
                        c0495d2.h();
                        c0495d2.f5813a = false;
                        c0495d2.f5819d.n();
                        c0495d2.e.m();
                    }
                    i14 = 0;
                    c0496e3.h();
                    c0496e3.f5813a = false;
                    c0496e3.f5819d.n();
                    c0496e3.e.m();
                    c0520e.f5987c = false;
                } else {
                    i14 = 0;
                }
                c0520e.b(c0520e.f5988d);
                c0496e3.f5811Y = i14;
                c0496e3.f5812Z = i14;
                int iJ = c0496e3.j(i14);
                int iJ2 = c0496e3.j(1);
                if (c0520e.f5986b) {
                    c0520e.c();
                }
                int iR = c0496e3.r();
                int iS = c0496e3.s();
                z2 = z8;
                c0496e3.f5819d.f6020h.d(iR);
                c0496e3.e.f6020h.d(iS);
                c0520e.g();
                ArrayList arrayList2 = c0520e.e;
                fVar = fVar5;
                if (iJ == 2 || iJ2 == 2) {
                    if (zC) {
                        Iterator it4 = arrayList2.iterator();
                        while (true) {
                            if (it4.hasNext()) {
                                if (!((AbstractC0530o) it4.next()).k()) {
                                    zC = false;
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                    if (zC && iJ == 2) {
                        c0496e3.M(1);
                        i7 = iQ2;
                        c0496e3.O(c0520e.d(c0496e3, 0));
                        c0496e3.f5819d.e.d(c0496e3.q());
                    } else {
                        i7 = iQ2;
                    }
                    if (zC && iJ2 == 2) {
                        i15 = 1;
                        c0496e3.N(1);
                        c0496e3.L(c0520e.d(c0496e3, 1));
                        c0496e3.e.e.d(c0496e3.k());
                    }
                    iArr = c0496e3.f5842p0;
                    i8 = iK;
                    i16 = iArr[0];
                    if (i16 != i15 || i16 == 4) {
                        int iQ3 = c0496e3.q() + iR;
                        c0496e3.f5819d.i.d(iQ3);
                        c0496e3.f5819d.e.d(iQ3 - iR);
                        c0520e.g();
                        i17 = iArr[1];
                        if (i17 != 1 || i17 == 4) {
                            int iK2 = c0496e3.k() + iS;
                            c0496e3.e.i.d(iK2);
                            c0496e3.e.e.d(iK2 - iS);
                        }
                        c0520e.g();
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    it = arrayList2.iterator();
                    while (it.hasNext()) {
                        AbstractC0530o abstractC0530o = (AbstractC0530o) it.next();
                        if (abstractC0530o.f6015b != c0496e3 || abstractC0530o.f6019g) {
                            abstractC0530o.e();
                        }
                    }
                    it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                        AbstractC0530o abstractC0530o2 = (AbstractC0530o) it2.next();
                        if (z4 || abstractC0530o2.f6015b != c0496e3) {
                            if (!abstractC0530o2.f6020h.f5999j || ((!abstractC0530o2.i.f5999j && !(abstractC0530o2 instanceof C0524i)) || (!abstractC0530o2.e.f5999j && !(abstractC0530o2 instanceof C0518c) && !(abstractC0530o2 instanceof C0524i)))) {
                                z5 = false;
                                break;
                            }
                        }
                    }
                    z5 = true;
                    c0496e3.M(iJ);
                    c0496e3.N(iJ2);
                    zT = z5;
                    i13 = 1073741824;
                    i9 = 2;
                } else {
                    i7 = iQ2;
                }
                i15 = 1;
                iArr = c0496e3.f5842p0;
                i8 = iK;
                i16 = iArr[0];
                if (i16 != i15) {
                    int iQ32 = c0496e3.q() + iR;
                    c0496e3.f5819d.i.d(iQ32);
                    c0496e3.f5819d.e.d(iQ32 - iR);
                    c0520e.g();
                    i17 = iArr[1];
                    if (i17 != 1) {
                        int iK22 = c0496e3.k() + iS;
                        c0496e3.e.i.d(iK22);
                        c0496e3.e.e.d(iK22 - iS);
                        c0520e.g();
                        z4 = true;
                        it = arrayList2.iterator();
                        while (it.hasNext()) {
                        }
                        it2 = arrayList2.iterator();
                        while (it2.hasNext()) {
                        }
                        z5 = true;
                        c0496e3.M(iJ);
                        c0496e3.N(iJ2);
                        zT = z5;
                        i13 = 1073741824;
                        i9 = 2;
                    }
                }
            } else {
                z2 = z8;
                fVar = fVar5;
                i7 = iQ2;
                i8 = iK;
                boolean z10 = c0520e.f5986b;
                C0496e c0496e4 = c0520e.f5985a;
                if (z10) {
                    Iterator it5 = c0496e4.f5864q0.iterator();
                    while (it5.hasNext()) {
                        C0495d c0495d3 = (C0495d) it5.next();
                        c0495d3.h();
                        c0495d3.f5813a = false;
                        C0526k c0526k2 = c0495d3.f5819d;
                        c0526k2.e.f5999j = false;
                        c0526k2.f6019g = false;
                        c0526k2.n();
                        C0528m c0528m2 = c0495d3.e;
                        c0528m2.e.f5999j = false;
                        c0528m2.f6019g = false;
                        c0528m2.m();
                    }
                    i12 = 0;
                    c0496e4.h();
                    c0496e4.f5813a = false;
                    C0526k c0526k3 = c0496e4.f5819d;
                    c0526k3.e.f5999j = false;
                    c0526k3.f6019g = false;
                    c0526k3.n();
                    C0528m c0528m3 = c0496e4.e;
                    c0528m3.e.f5999j = false;
                    c0528m3.f6019g = false;
                    c0528m3.m();
                    c0520e.c();
                } else {
                    i12 = 0;
                }
                c0520e.b(c0520e.f5988d);
                c0496e4.f5811Y = i12;
                c0496e4.f5812Z = i12;
                c0496e4.f5819d.f6020h.d(i12);
                c0496e4.e.f6020h.d(i12);
                i13 = 1073741824;
                if (mode == 1073741824) {
                    zT = c0496e2.T(i12, zC);
                    i9 = 1;
                } else {
                    i9 = 0;
                    zT = true;
                }
                if (mode2 == 1073741824) {
                    zT &= c0496e2.T(1, zC);
                    i9++;
                }
            }
            if (zT) {
                c0496e2.P(mode == i13, mode2 == i13);
            }
        } else {
            z2 = z8;
            fVar = fVar5;
            i7 = iQ2;
            i8 = iK;
            i9 = 0;
            zT = false;
        }
        if (zT && i9 == 2) {
            return;
        }
        int i29 = c0496e2.f5856D0;
        if (size3 > 0) {
            int size4 = c0496e2.f5864q0.size();
            boolean zW = c0496e2.W(64);
            f fVar6 = c0496e2.f5868u0;
            for (int i30 = 0; i30 < size4; i30++) {
                C0495d c0495d4 = (C0495d) c0496e2.f5864q0.get(i30);
                if (!(c0495d4 instanceof x.h) && !(c0495d4 instanceof C0492a) && !c0495d4.F && (!zW || (c0526k = c0495d4.f5819d) == null || (c0528m = c0495d4.e) == null || !c0526k.e.f5999j || !c0528m.e.f5999j)) {
                    int iJ3 = c0495d4.j(0);
                    int iJ4 = c0495d4.j(1);
                    boolean z11 = iJ3 == 3 && c0495d4.f5844r != 1 && iJ4 == 3 && c0495d4.f5845s != 1;
                    if (!z11 && c0496e2.W(1) && !(c0495d4 instanceof x.g)) {
                        if (iJ3 == 3 && c0495d4.f5844r == 0 && iJ4 != 3 && !c0495d4.x()) {
                            z11 = true;
                        }
                        if (iJ4 == 3 && c0495d4.f5845s == 0 && iJ3 != 3 && !c0495d4.x()) {
                            z11 = true;
                        }
                        if (iJ3 == 3 || iJ4 == 3) {
                            if (c0495d4.f5809W > 0.0f) {
                                z11 = true;
                            }
                        }
                        if (z11) {
                            c0023k.g(0, fVar6, c0495d4);
                        }
                    }
                    if (z11) {
                    }
                }
            }
            ConstraintLayout constraintLayout = fVar6.f79a;
            int childCount2 = constraintLayout.getChildCount();
            for (int i31 = 0; i31 < childCount2; i31++) {
                constraintLayout.getChildAt(i31);
            }
            ArrayList arrayList3 = constraintLayout.f1629c;
            int size5 = arrayList3.size();
            if (size5 > 0) {
                for (int i32 = 0; i32 < size5; i32++) {
                    ((c) arrayList3.get(i32)).getClass();
                }
            }
        }
        c0023k.l(c0496e2);
        ArrayList arrayList4 = (ArrayList) c0023k.f912b;
        int size6 = arrayList4.size();
        int i33 = i7;
        int i34 = i8;
        if (size3 > 0) {
            c0023k.k(c0496e2, 0, i33, i34);
        }
        if (size6 > 0) {
            int[] iArr4 = c0496e2.f5842p0;
            boolean z12 = iArr4[0] == 2;
            boolean z13 = iArr4[1] == 2;
            int iQ4 = c0496e.q();
            C0496e c0496e5 = (C0496e) c0023k.f914d;
            int iMax7 = Math.max(iQ4, c0496e5.f5816b0);
            int iMax8 = Math.max(c0496e.k(), c0496e5.f5818c0);
            int i35 = 0;
            boolean z14 = false;
            while (i35 < size6) {
                C0495d c0495d5 = (C0495d) arrayList4.get(i35);
                if (c0495d5 instanceof x.g) {
                    int iQ5 = c0495d5.q();
                    int iK3 = c0495d5.k();
                    i11 = i29;
                    fVar3 = fVar;
                    boolean zG = z14 | c0023k.g(1, fVar3, c0495d5);
                    int iQ6 = c0495d5.q();
                    int iK4 = c0495d5.k();
                    if (iQ6 != iQ5) {
                        c0495d5.O(iQ6);
                        if (z12 && c0495d5.r() + c0495d5.f5807U > iMax7) {
                            iMax7 = Math.max(iMax7, c0495d5.i(4).e() + c0495d5.r() + c0495d5.f5807U);
                        }
                        z3 = true;
                    } else {
                        z3 = zG;
                    }
                    if (iK4 != iK3) {
                        c0495d5.L(iK4);
                        if (z13 && c0495d5.s() + c0495d5.f5808V > iMax8) {
                            iMax8 = Math.max(iMax8, c0495d5.i(5).e() + c0495d5.s() + c0495d5.f5808V);
                        }
                        z3 = true;
                    }
                    z14 = ((x.g) c0495d5).f5922y0 | z3;
                } else {
                    i11 = i29;
                    fVar3 = fVar;
                }
                i35++;
                fVar = fVar3;
                i29 = i11;
            }
            int i36 = i29;
            f fVar7 = fVar;
            int i37 = 0;
            while (i37 < 2) {
                int i38 = 0;
                while (i38 < size6) {
                    C0495d c0495d6 = (C0495d) arrayList4.get(i38);
                    if (((c0495d6 instanceof x.i) && !(c0495d6 instanceof x.g)) || (c0495d6 instanceof x.h) || c0495d6.f5825g0 == 8 || ((z2 && c0495d6.f5819d.e.f5999j && c0495d6.e.e.f5999j) || (c0495d6 instanceof x.g))) {
                        fVar2 = fVar7;
                        arrayList = arrayList4;
                        i10 = size6;
                    } else {
                        int iQ7 = c0495d6.q();
                        int iK5 = c0495d6.k();
                        arrayList = arrayList4;
                        int i39 = c0495d6.f5814a0;
                        i10 = size6;
                        boolean zG2 = c0023k.g(i37 == 1 ? 2 : 1, fVar7, c0495d6) | z14;
                        int iQ8 = c0495d6.q();
                        fVar2 = fVar7;
                        int iK6 = c0495d6.k();
                        if (iQ8 != iQ7) {
                            c0495d6.O(iQ8);
                            if (z12 && c0495d6.r() + c0495d6.f5807U > iMax7) {
                                iMax7 = Math.max(iMax7, c0495d6.i(4).e() + c0495d6.r() + c0495d6.f5807U);
                            }
                            zG2 = true;
                        }
                        if (iK6 != iK5) {
                            c0495d6.L(iK6);
                            if (z13 && c0495d6.s() + c0495d6.f5808V > iMax8) {
                                iMax8 = Math.max(iMax8, c0495d6.i(5).e() + c0495d6.s() + c0495d6.f5808V);
                            }
                            zG2 = true;
                        }
                        z14 = (!c0495d6.f5793E || i39 == c0495d6.f5814a0) ? zG2 : true;
                    }
                    i38++;
                    arrayList4 = arrayList;
                    size6 = i10;
                    fVar7 = fVar2;
                }
                f fVar8 = fVar7;
                ArrayList arrayList5 = arrayList4;
                int i40 = size6;
                if (!z14) {
                    break;
                }
                i37++;
                c0023k.k(c0496e, i37, i33, i34);
                fVar7 = fVar8;
                arrayList4 = arrayList5;
                size6 = i40;
                z14 = false;
            }
            c0496e2 = c0496e;
            i29 = i36;
        }
        c0496e2.f5856D0 = i29;
        C0468c.f5635q = c0496e2.W(512);
    }

    public final void l(C0495d c0495d, e eVar, SparseArray sparseArray, int i, int i3) {
        View view = (View) this.f1628b.get(i);
        C0495d c0495d2 = (C0495d) sparseArray.get(i);
        if (c0495d2 == null || view == null || !(view.getLayoutParams() instanceof e)) {
            return;
        }
        eVar.f44c0 = true;
        if (i3 == 6) {
            e eVar2 = (e) view.getLayoutParams();
            eVar2.f44c0 = true;
            eVar2.f68p0.f5793E = true;
        }
        c0495d.i(6).b(c0495d2.i(i3), eVar.f18D, eVar.f17C, true);
        c0495d.f5793E = true;
        c0495d.i(3).j();
        c0495d.i(5).j();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            e eVar = (e) childAt.getLayoutParams();
            C0495d c0495d = eVar.f68p0;
            if (childAt.getVisibility() != 8 || eVar.f46d0 || eVar.f47e0 || zIsInEditMode) {
                int iR = c0495d.r();
                int iS = c0495d.s();
                childAt.layout(iR, iS, c0495d.q() + iR, c0495d.k() + iS);
            }
        }
        ArrayList arrayList = this.f1629c;
        int size = arrayList.size();
        if (size > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                ((c) arrayList.get(i7)).getClass();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:104:0x01b6  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x02ec  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x0308  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x0329  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x0346  */
    /* JADX WARN: Removed duplicated region for block: B:175:0x036d  */
    /* JADX WARN: Removed duplicated region for block: B:178:0x038b  */
    /* JADX WARN: Removed duplicated region for block: B:185:0x03b1  */
    /* JADX WARN: Removed duplicated region for block: B:187:0x03be  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x03e1  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x03e9  */
    /* JADX WARN: Removed duplicated region for block: B:272:0x0510  */
    /* JADX WARN: Removed duplicated region for block: B:275:0x0516  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onMeasure(int i, int i3) throws Resources.NotFoundException, NumberFormatException {
        boolean z2;
        int i4;
        int i5;
        C0495d c0495d;
        int i6;
        C0495d c0495d2;
        int i7;
        C0495d c0495d3;
        int i8;
        e eVar;
        float f3;
        int i9;
        int i10;
        int i11;
        float fAbs;
        int i12;
        ArrayList arrayList;
        ArrayList arrayList2;
        C0495d c0495d4;
        ConstraintLayout constraintLayout = this;
        boolean z3 = constraintLayout.i;
        constraintLayout.i = z3;
        int i13 = 0;
        if (!z3) {
            int childCount = getChildCount();
            int i14 = 0;
            while (true) {
                if (i14 >= childCount) {
                    break;
                }
                if (constraintLayout.getChildAt(i14).isLayoutRequested()) {
                    constraintLayout.i = true;
                    break;
                }
                i14++;
            }
        }
        boolean z4 = (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
        C0496e c0496e = constraintLayout.f1630d;
        c0496e.f5869v0 = z4;
        if (constraintLayout.i) {
            constraintLayout.i = false;
            int childCount2 = getChildCount();
            int i15 = 0;
            while (true) {
                if (i15 >= childCount2) {
                    z2 = false;
                    break;
                } else {
                    if (constraintLayout.getChildAt(i15).isLayoutRequested()) {
                        z2 = true;
                        break;
                    }
                    i15++;
                }
            }
            if (z2) {
                boolean zIsInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i16 = 0; i16 < childCount3; i16++) {
                    C0495d c0495dH = constraintLayout.h(constraintLayout.getChildAt(i16));
                    if (c0495dH != null) {
                        c0495dH.C();
                    }
                }
                Object obj = null;
                if (zIsInEditMode) {
                    for (int i17 = 0; i17 < childCount3; i17++) {
                        View childAt = constraintLayout.getChildAt(i17);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            Integer numValueOf = Integer.valueOf(childAt.getId());
                            if (resourceName != null) {
                                if (constraintLayout.f1638n == null) {
                                    constraintLayout.f1638n = new HashMap();
                                }
                                int iIndexOf = resourceName.indexOf("/");
                                constraintLayout.f1638n.put(iIndexOf != -1 ? resourceName.substring(iIndexOf + 1) : resourceName, numValueOf);
                            }
                            int iIndexOf2 = resourceName.indexOf(47);
                            if (iIndexOf2 != -1) {
                                resourceName = resourceName.substring(iIndexOf2 + 1);
                            }
                            int id = childAt.getId();
                            if (id != 0) {
                                View viewFindViewById = (View) constraintLayout.f1628b.get(id);
                                if (viewFindViewById == null && (viewFindViewById = constraintLayout.findViewById(id)) != null && viewFindViewById != constraintLayout && viewFindViewById.getParent() == constraintLayout) {
                                    constraintLayout.onViewAdded(viewFindViewById);
                                }
                                if (viewFindViewById == constraintLayout) {
                                    c0495d4 = c0496e;
                                    c0495d4.f5827h0 = resourceName;
                                } else {
                                    c0495d4 = viewFindViewById == null ? null : ((e) viewFindViewById.getLayoutParams()).f68p0;
                                    c0495d4.f5827h0 = resourceName;
                                }
                            } else {
                                c0495d4 = c0496e;
                                c0495d4.f5827h0 = resourceName;
                            }
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (constraintLayout.f1637m != -1) {
                    for (int i18 = 0; i18 < childCount3; i18++) {
                        constraintLayout.getChildAt(i18).getId();
                    }
                }
                p pVar = constraintLayout.f1635k;
                if (pVar != null) {
                    pVar.a(constraintLayout);
                }
                c0496e.f5864q0.clear();
                ArrayList arrayList3 = constraintLayout.f1629c;
                int size = arrayList3.size();
                if (size > 0) {
                    int i19 = 0;
                    while (i19 < size) {
                        c cVar = (c) arrayList3.get(i19);
                        if (cVar.isInEditMode()) {
                            cVar.setIds(cVar.f11f);
                        }
                        x.i iVar = cVar.e;
                        if (iVar == null) {
                            arrayList = arrayList3;
                        } else {
                            iVar.f5931r0 = i13;
                            Arrays.fill(iVar.f5930q0, obj);
                            int i20 = i13;
                            while (i20 < cVar.f9c) {
                                int i21 = cVar.f8b[i20];
                                View view = (View) constraintLayout.f1628b.get(i21);
                                if (view == null) {
                                    Integer numValueOf2 = Integer.valueOf(i21);
                                    HashMap map = cVar.f13h;
                                    String str = (String) map.get(numValueOf2);
                                    int iF = cVar.f(constraintLayout, str);
                                    if (iF != 0) {
                                        cVar.f8b[i20] = iF;
                                        map.put(Integer.valueOf(iF), str);
                                        view = (View) constraintLayout.f1628b.get(iF);
                                    }
                                }
                                if (view != null) {
                                    x.i iVar2 = cVar.e;
                                    C0495d c0495dH2 = constraintLayout.h(view);
                                    iVar2.getClass();
                                    if (c0495dH2 == iVar2 || c0495dH2 == null) {
                                        arrayList2 = arrayList3;
                                    } else {
                                        int i22 = iVar2.f5931r0 + 1;
                                        C0495d[] c0495dArr = iVar2.f5930q0;
                                        arrayList2 = arrayList3;
                                        if (i22 > c0495dArr.length) {
                                            iVar2.f5930q0 = (C0495d[]) Arrays.copyOf(c0495dArr, c0495dArr.length * 2);
                                        }
                                        C0495d[] c0495dArr2 = iVar2.f5930q0;
                                        int i23 = iVar2.f5931r0;
                                        c0495dArr2[i23] = c0495dH2;
                                        iVar2.f5931r0 = i23 + 1;
                                    }
                                }
                                i20++;
                                arrayList3 = arrayList2;
                            }
                            arrayList = arrayList3;
                            cVar.e.S();
                        }
                        i19++;
                        arrayList3 = arrayList;
                        obj = null;
                        i13 = 0;
                    }
                }
                for (int i24 = 0; i24 < childCount3; i24++) {
                    constraintLayout.getChildAt(i24);
                }
                SparseArray sparseArray = constraintLayout.f1639o;
                sparseArray.clear();
                sparseArray.put(0, c0496e);
                sparseArray.put(getId(), c0496e);
                for (int i25 = 0; i25 < childCount3; i25++) {
                    View childAt2 = constraintLayout.getChildAt(i25);
                    sparseArray.put(childAt2.getId(), constraintLayout.h(childAt2));
                }
                int i26 = 0;
                while (i26 < childCount3) {
                    View childAt3 = constraintLayout.getChildAt(i26);
                    C0495d c0495dH3 = constraintLayout.h(childAt3);
                    if (c0495dH3 == null) {
                        i4 = childCount3;
                    } else {
                        e eVar2 = (e) childAt3.getLayoutParams();
                        c0496e.f5864q0.add(c0495dH3);
                        C0495d c0495d5 = c0495dH3.f5806T;
                        if (c0495d5 != null) {
                            ((C0496e) c0495d5).f5864q0.remove(c0495dH3);
                            c0495dH3.C();
                        }
                        c0495dH3.f5806T = c0496e;
                        eVar2.a();
                        c0495dH3.f5825g0 = childAt3.getVisibility();
                        c0495dH3.f5823f0 = childAt3;
                        if (childAt3 instanceof c) {
                            ((c) childAt3).h(c0495dH3, c0496e.f5869v0);
                        }
                        if (eVar2.f46d0) {
                            x.h hVar = (x.h) c0495dH3;
                            int i27 = eVar2.f62m0;
                            int i28 = eVar2.f64n0;
                            float f4 = eVar2.f66o0;
                            if (f4 != -1.0f) {
                                if (f4 > -1.0f) {
                                    hVar.f5924q0 = f4;
                                    hVar.f5925r0 = -1;
                                    hVar.f5926s0 = -1;
                                }
                            } else if (i27 != -1) {
                                if (i27 > -1) {
                                    hVar.f5924q0 = -1.0f;
                                    hVar.f5925r0 = i27;
                                    hVar.f5926s0 = -1;
                                }
                            } else if (i28 != -1 && i28 > -1) {
                                hVar.f5924q0 = -1.0f;
                                hVar.f5925r0 = -1;
                                hVar.f5926s0 = i28;
                            }
                            i4 = childCount3;
                        } else {
                            int i29 = eVar2.f49f0;
                            int i30 = eVar2.f51g0;
                            int i31 = eVar2.f53h0;
                            int i32 = eVar2.f54i0;
                            int i33 = eVar2.f56j0;
                            i4 = childCount3;
                            int i34 = eVar2.f58k0;
                            float f5 = eVar2.f60l0;
                            int i35 = eVar2.f67p;
                            if (i35 != -1) {
                                C0495d c0495d6 = (C0495d) sparseArray.get(i35);
                                if (c0495d6 != null) {
                                    float f6 = eVar2.f70r;
                                    c0495dH3.v(7, 7, eVar2.f69q, 0, c0495d6);
                                    c0495dH3.f5792D = f6;
                                }
                                eVar = eVar2;
                            } else {
                                if (i29 != -1) {
                                    C0495d c0495d7 = (C0495d) sparseArray.get(i29);
                                    if (c0495d7 != null) {
                                        c0495dH3.v(2, 2, ((ViewGroup.MarginLayoutParams) eVar2).leftMargin, i33, c0495d7);
                                    }
                                } else {
                                    i5 = -1;
                                    if (i30 != -1) {
                                        C0495d c0495d8 = (C0495d) sparseArray.get(i30);
                                        if (c0495d8 != null) {
                                            c0495dH3.v(2, 4, ((ViewGroup.MarginLayoutParams) eVar2).leftMargin, i33, c0495d8);
                                        }
                                    }
                                    if (i31 == i5) {
                                        C0495d c0495d9 = (C0495d) sparseArray.get(i31);
                                        if (c0495d9 != null) {
                                            c0495dH3.v(4, 2, ((ViewGroup.MarginLayoutParams) eVar2).rightMargin, i34, c0495d9);
                                        }
                                    } else if (i32 != i5 && (c0495d = (C0495d) sparseArray.get(i32)) != null) {
                                        c0495dH3.v(4, 4, ((ViewGroup.MarginLayoutParams) eVar2).rightMargin, i34, c0495d);
                                    }
                                    i6 = eVar2.i;
                                    if (i6 == -1) {
                                        C0495d c0495d10 = (C0495d) sparseArray.get(i6);
                                        if (c0495d10 != null) {
                                            c0495dH3.v(3, 3, ((ViewGroup.MarginLayoutParams) eVar2).topMargin, eVar2.f76x, c0495d10);
                                        }
                                    } else {
                                        int i36 = eVar2.f55j;
                                        if (i36 != -1 && (c0495d2 = (C0495d) sparseArray.get(i36)) != null) {
                                            c0495dH3.v(3, 5, ((ViewGroup.MarginLayoutParams) eVar2).topMargin, eVar2.f76x, c0495d2);
                                        }
                                    }
                                    i7 = eVar2.f57k;
                                    if (i7 == -1) {
                                        C0495d c0495d11 = (C0495d) sparseArray.get(i7);
                                        if (c0495d11 != null) {
                                            c0495dH3.v(5, 3, ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin, eVar2.f78z, c0495d11);
                                        }
                                    } else {
                                        int i37 = eVar2.f59l;
                                        if (i37 != -1 && (c0495d3 = (C0495d) sparseArray.get(i37)) != null) {
                                            c0495dH3.v(5, 5, ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin, eVar2.f78z, c0495d3);
                                        }
                                    }
                                    i8 = eVar2.f61m;
                                    if (i8 == -1) {
                                        eVar = eVar2;
                                        l(c0495dH3, eVar2, sparseArray, i8, 6);
                                    } else {
                                        eVar = eVar2;
                                        int i38 = eVar.f63n;
                                        if (i38 != -1) {
                                            l(c0495dH3, eVar, sparseArray, i38, 3);
                                        } else {
                                            int i39 = eVar.f65o;
                                            if (i39 != -1) {
                                                l(c0495dH3, eVar, sparseArray, i39, 5);
                                            }
                                        }
                                    }
                                    if (f5 >= 0.0f) {
                                        c0495dH3.f5820d0 = f5;
                                    }
                                    f3 = eVar.F;
                                    if (f3 >= 0.0f) {
                                        c0495dH3.f5821e0 = f3;
                                    }
                                }
                                i5 = -1;
                                if (i31 == i5) {
                                }
                                i6 = eVar2.i;
                                if (i6 == -1) {
                                }
                                i7 = eVar2.f57k;
                                if (i7 == -1) {
                                }
                                i8 = eVar2.f61m;
                                if (i8 == -1) {
                                }
                                if (f5 >= 0.0f) {
                                }
                                f3 = eVar.F;
                                if (f3 >= 0.0f) {
                                }
                            }
                            if (zIsInEditMode && ((i12 = eVar.f32T) != -1 || eVar.f33U != -1)) {
                                int i40 = eVar.f33U;
                                c0495dH3.f5811Y = i12;
                                c0495dH3.f5812Z = i40;
                            }
                            if (eVar.f40a0) {
                                c0495dH3.M(1);
                                c0495dH3.O(((ViewGroup.MarginLayoutParams) eVar).width);
                                if (((ViewGroup.MarginLayoutParams) eVar).width == -2) {
                                    c0495dH3.M(2);
                                }
                            } else if (((ViewGroup.MarginLayoutParams) eVar).width == -1) {
                                if (eVar.f35W) {
                                    c0495dH3.M(3);
                                } else {
                                    c0495dH3.M(4);
                                }
                                c0495dH3.i(2).f5787g = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
                                c0495dH3.i(4).f5787g = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
                            } else {
                                c0495dH3.M(3);
                                c0495dH3.O(0);
                            }
                            if (eVar.f42b0) {
                                i9 = -1;
                                c0495dH3.N(1);
                                c0495dH3.L(((ViewGroup.MarginLayoutParams) eVar).height);
                                if (((ViewGroup.MarginLayoutParams) eVar).height == -2) {
                                    c0495dH3.N(2);
                                }
                            } else {
                                i9 = -1;
                                if (((ViewGroup.MarginLayoutParams) eVar).height == -1) {
                                    if (eVar.f36X) {
                                        c0495dH3.N(3);
                                    } else {
                                        c0495dH3.N(4);
                                    }
                                    c0495dH3.i(3).f5787g = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
                                    c0495dH3.i(5).f5787g = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
                                } else {
                                    c0495dH3.N(3);
                                    c0495dH3.L(0);
                                }
                            }
                            String str2 = eVar.f20G;
                            if (str2 == null || str2.length() == 0) {
                                c0495dH3.f5809W = 0.0f;
                            } else {
                                int length = str2.length();
                                int iIndexOf3 = str2.indexOf(44);
                                if (iIndexOf3 <= 0 || iIndexOf3 >= length - 1) {
                                    i10 = i9;
                                    i11 = 0;
                                } else {
                                    String strSubstring = str2.substring(0, iIndexOf3);
                                    i10 = strSubstring.equalsIgnoreCase("W") ? 0 : strSubstring.equalsIgnoreCase("H") ? 1 : i9;
                                    i11 = iIndexOf3 + 1;
                                }
                                int iIndexOf4 = str2.indexOf(58);
                                if (iIndexOf4 < 0 || iIndexOf4 >= length - 1) {
                                    String strSubstring2 = str2.substring(i11);
                                    fAbs = strSubstring2.length() > 0 ? Float.parseFloat(strSubstring2) : 0.0f;
                                    if (fAbs > 0.0f) {
                                        c0495dH3.f5809W = fAbs;
                                        c0495dH3.f5810X = i10;
                                    }
                                } else {
                                    String strSubstring3 = str2.substring(i11, iIndexOf4);
                                    String strSubstring4 = str2.substring(iIndexOf4 + 1);
                                    if (strSubstring3.length() > 0 && strSubstring4.length() > 0) {
                                        try {
                                            float f7 = Float.parseFloat(strSubstring3);
                                            float f8 = Float.parseFloat(strSubstring4);
                                            if (f7 > 0.0f && f8 > 0.0f) {
                                                fAbs = i10 == 1 ? Math.abs(f8 / f7) : Math.abs(f7 / f8);
                                            }
                                        } catch (NumberFormatException unused2) {
                                        }
                                        if (fAbs > 0.0f) {
                                        }
                                    }
                                }
                            }
                            float f9 = eVar.f21H;
                            float[] fArr = c0495dH3.f5832k0;
                            fArr[0] = f9;
                            fArr[1] = eVar.f22I;
                            c0495dH3.f5828i0 = eVar.f23J;
                            c0495dH3.f5830j0 = eVar.K;
                            int i41 = eVar.f38Z;
                            if (i41 >= 0 && i41 <= 3) {
                                c0495dH3.f5843q = i41;
                            }
                            int i42 = eVar.f24L;
                            int i43 = eVar.f26N;
                            int i44 = eVar.f28P;
                            float f10 = eVar.f30R;
                            c0495dH3.f5844r = i42;
                            c0495dH3.f5847u = i43;
                            if (i44 == Integer.MAX_VALUE) {
                                i44 = 0;
                            }
                            c0495dH3.f5848v = i44;
                            c0495dH3.f5849w = f10;
                            if (f10 > 0.0f && f10 < 1.0f && i42 == 0) {
                                c0495dH3.f5844r = 2;
                            }
                            int i45 = eVar.f25M;
                            int i46 = eVar.f27O;
                            int i47 = eVar.f29Q;
                            float f11 = eVar.f31S;
                            c0495dH3.f5845s = i45;
                            c0495dH3.f5850x = i46;
                            if (i47 == Integer.MAX_VALUE) {
                                i47 = 0;
                            }
                            c0495dH3.f5851y = i47;
                            c0495dH3.f5852z = f11;
                            if (f11 > 0.0f && f11 < 1.0f && i45 == 0) {
                                c0495dH3.f5845s = 2;
                            }
                        }
                    }
                    i26++;
                    constraintLayout = this;
                    childCount3 = i4;
                }
            }
            if (z2) {
                c0496e.f5865r0.l(c0496e);
            }
        }
        c0496e.f5870w0.getClass();
        k(c0496e, this.f1634j, i, i3);
        int iQ = c0496e.q();
        int iK = c0496e.k();
        boolean z5 = c0496e.f5857E0;
        boolean z6 = c0496e.f5858F0;
        f fVar = this.f1640p;
        int i48 = fVar.e;
        int iResolveSizeAndState = View.resolveSizeAndState(iQ + fVar.f82d, i, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(iK + i48, i3, 0) & 16777215;
        int iMin = Math.min(this.f1632g, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.f1633h, iResolveSizeAndState2);
        if (z5) {
            iMin |= 16777216;
        }
        if (z6) {
            iMin2 |= 16777216;
        }
        setMeasuredDimension(iMin, iMin2);
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        C0495d c0495dH = h(view);
        if ((view instanceof r) && !(c0495dH instanceof x.h)) {
            e eVar = (e) view.getLayoutParams();
            x.h hVar = new x.h();
            eVar.f68p0 = hVar;
            eVar.f46d0 = true;
            hVar.S(eVar.f34V);
        }
        if (view instanceof c) {
            c cVar = (c) view;
            cVar.i();
            ((e) view.getLayoutParams()).f47e0 = true;
            ArrayList arrayList = this.f1629c;
            if (!arrayList.contains(cVar)) {
                arrayList.add(cVar);
            }
        }
        this.f1628b.put(view.getId(), view);
        this.i = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f1628b.remove(view.getId());
        C0495d c0495dH = h(view);
        this.f1630d.f5864q0.remove(c0495dH);
        c0495dH.C();
        this.f1629c.remove(view);
        this.i = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.i = true;
        super.requestLayout();
    }

    public void setConstraintSet(p pVar) {
        this.f1635k = pVar;
    }

    @Override // android.view.View
    public void setId(int i) {
        int id = getId();
        SparseArray sparseArray = this.f1628b;
        sparseArray.remove(id);
        super.setId(i);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i == this.f1633h) {
            return;
        }
        this.f1633h = i;
        requestLayout();
    }

    public void setMaxWidth(int i) {
        if (i == this.f1632g) {
            return;
        }
        this.f1632g = i;
        requestLayout();
    }

    public void setMinHeight(int i) {
        if (i == this.f1631f) {
            return;
        }
        this.f1631f = i;
        requestLayout();
    }

    public void setMinWidth(int i) {
        if (i == this.e) {
            return;
        }
        this.e = i;
        requestLayout();
    }

    public void setOnConstraintsChanged(q qVar) {
        i iVar = this.f1636l;
        if (iVar != null) {
            iVar.getClass();
        }
    }

    public void setOptimizationLevel(int i) {
        this.f1634j = i;
        C0496e c0496e = this.f1630d;
        c0496e.f5856D0 = i;
        C0468c.f5635q = c0496e.W(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) throws XmlPullParserException, IOException, NumberFormatException {
        super(context, attributeSet, i);
        this.f1628b = new SparseArray();
        this.f1629c = new ArrayList(4);
        this.f1630d = new C0496e();
        this.e = 0;
        this.f1631f = 0;
        this.f1632g = Integer.MAX_VALUE;
        this.f1633h = Integer.MAX_VALUE;
        this.i = true;
        this.f1634j = 257;
        this.f1635k = null;
        this.f1636l = null;
        this.f1637m = -1;
        this.f1638n = new HashMap();
        this.f1639o = new SparseArray();
        this.f1640p = new f(this, this);
        i(attributeSet, i);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        e eVar = new e(layoutParams);
        eVar.f39a = -1;
        eVar.f41b = -1;
        eVar.f43c = -1.0f;
        eVar.f45d = true;
        eVar.e = -1;
        eVar.f48f = -1;
        eVar.f50g = -1;
        eVar.f52h = -1;
        eVar.i = -1;
        eVar.f55j = -1;
        eVar.f57k = -1;
        eVar.f59l = -1;
        eVar.f61m = -1;
        eVar.f63n = -1;
        eVar.f65o = -1;
        eVar.f67p = -1;
        eVar.f69q = 0;
        eVar.f70r = 0.0f;
        eVar.f71s = -1;
        eVar.f72t = -1;
        eVar.f73u = -1;
        eVar.f74v = -1;
        eVar.f75w = Integer.MIN_VALUE;
        eVar.f76x = Integer.MIN_VALUE;
        eVar.f77y = Integer.MIN_VALUE;
        eVar.f78z = Integer.MIN_VALUE;
        eVar.f15A = Integer.MIN_VALUE;
        eVar.f16B = Integer.MIN_VALUE;
        eVar.f17C = Integer.MIN_VALUE;
        eVar.f18D = 0;
        eVar.f19E = 0.5f;
        eVar.F = 0.5f;
        eVar.f20G = null;
        eVar.f21H = -1.0f;
        eVar.f22I = -1.0f;
        eVar.f23J = 0;
        eVar.K = 0;
        eVar.f24L = 0;
        eVar.f25M = 0;
        eVar.f26N = 0;
        eVar.f27O = 0;
        eVar.f28P = 0;
        eVar.f29Q = 0;
        eVar.f30R = 1.0f;
        eVar.f31S = 1.0f;
        eVar.f32T = -1;
        eVar.f33U = -1;
        eVar.f34V = -1;
        eVar.f35W = false;
        eVar.f36X = false;
        eVar.f37Y = null;
        eVar.f38Z = 0;
        eVar.f40a0 = true;
        eVar.f42b0 = true;
        eVar.f44c0 = false;
        eVar.f46d0 = false;
        eVar.f47e0 = false;
        eVar.f49f0 = -1;
        eVar.f51g0 = -1;
        eVar.f53h0 = -1;
        eVar.f54i0 = -1;
        eVar.f56j0 = Integer.MIN_VALUE;
        eVar.f58k0 = Integer.MIN_VALUE;
        eVar.f60l0 = 0.5f;
        eVar.f68p0 = new C0495d();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            ((ViewGroup.MarginLayoutParams) eVar).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) eVar).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) eVar).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = marginLayoutParams.bottomMargin;
            eVar.setMarginStart(marginLayoutParams.getMarginStart());
            eVar.setMarginEnd(marginLayoutParams.getMarginEnd());
        }
        if (layoutParams instanceof e) {
            e eVar2 = (e) layoutParams;
            eVar.f39a = eVar2.f39a;
            eVar.f41b = eVar2.f41b;
            eVar.f43c = eVar2.f43c;
            eVar.f45d = eVar2.f45d;
            eVar.e = eVar2.e;
            eVar.f48f = eVar2.f48f;
            eVar.f50g = eVar2.f50g;
            eVar.f52h = eVar2.f52h;
            eVar.i = eVar2.i;
            eVar.f55j = eVar2.f55j;
            eVar.f57k = eVar2.f57k;
            eVar.f59l = eVar2.f59l;
            eVar.f61m = eVar2.f61m;
            eVar.f63n = eVar2.f63n;
            eVar.f65o = eVar2.f65o;
            eVar.f67p = eVar2.f67p;
            eVar.f69q = eVar2.f69q;
            eVar.f70r = eVar2.f70r;
            eVar.f71s = eVar2.f71s;
            eVar.f72t = eVar2.f72t;
            eVar.f73u = eVar2.f73u;
            eVar.f74v = eVar2.f74v;
            eVar.f75w = eVar2.f75w;
            eVar.f76x = eVar2.f76x;
            eVar.f77y = eVar2.f77y;
            eVar.f78z = eVar2.f78z;
            eVar.f15A = eVar2.f15A;
            eVar.f16B = eVar2.f16B;
            eVar.f17C = eVar2.f17C;
            eVar.f18D = eVar2.f18D;
            eVar.f19E = eVar2.f19E;
            eVar.F = eVar2.F;
            eVar.f20G = eVar2.f20G;
            eVar.f21H = eVar2.f21H;
            eVar.f22I = eVar2.f22I;
            eVar.f23J = eVar2.f23J;
            eVar.K = eVar2.K;
            eVar.f35W = eVar2.f35W;
            eVar.f36X = eVar2.f36X;
            eVar.f24L = eVar2.f24L;
            eVar.f25M = eVar2.f25M;
            eVar.f26N = eVar2.f26N;
            eVar.f28P = eVar2.f28P;
            eVar.f27O = eVar2.f27O;
            eVar.f29Q = eVar2.f29Q;
            eVar.f30R = eVar2.f30R;
            eVar.f31S = eVar2.f31S;
            eVar.f32T = eVar2.f32T;
            eVar.f33U = eVar2.f33U;
            eVar.f34V = eVar2.f34V;
            eVar.f40a0 = eVar2.f40a0;
            eVar.f42b0 = eVar2.f42b0;
            eVar.f44c0 = eVar2.f44c0;
            eVar.f46d0 = eVar2.f46d0;
            eVar.f49f0 = eVar2.f49f0;
            eVar.f51g0 = eVar2.f51g0;
            eVar.f53h0 = eVar2.f53h0;
            eVar.f54i0 = eVar2.f54i0;
            eVar.f56j0 = eVar2.f56j0;
            eVar.f58k0 = eVar2.f58k0;
            eVar.f60l0 = eVar2.f60l0;
            eVar.f37Y = eVar2.f37Y;
            eVar.f38Z = eVar2.f38Z;
            eVar.f68p0 = eVar2.f68p0;
        }
        return eVar;
    }
}
