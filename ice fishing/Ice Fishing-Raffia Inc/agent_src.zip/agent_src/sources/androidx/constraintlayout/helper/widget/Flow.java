package androidx.constraintlayout.helper.widget;

import A.f;
import A.t;
import A.v;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import x.C0494c;
import x.C0495d;
import x.C0496e;
import x.C0497f;
import x.g;
import x.h;
import y.C0517b;

/* loaded from: classes.dex */
public class Flow extends v {

    /* renamed from: k, reason: collision with root package name */
    public final g f1626k;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8b = new int[32];
        this.f13h = new HashMap();
        this.f10d = context;
        super.g(attributeSet);
        g gVar = new g();
        gVar.f5916s0 = 0;
        gVar.f5917t0 = 0;
        gVar.f5918u0 = 0;
        gVar.f5919v0 = 0;
        gVar.f5920w0 = 0;
        gVar.f5921x0 = 0;
        gVar.f5922y0 = false;
        gVar.f5923z0 = 0;
        gVar.f5890A0 = 0;
        gVar.f5891B0 = new C0517b();
        gVar.f5892C0 = null;
        gVar.f5893D0 = -1;
        gVar.f5894E0 = -1;
        gVar.f5895F0 = -1;
        gVar.f5896G0 = -1;
        gVar.H0 = -1;
        gVar.f5897I0 = -1;
        gVar.f5898J0 = 0.5f;
        gVar.f5899K0 = 0.5f;
        gVar.f5900L0 = 0.5f;
        gVar.f5901M0 = 0.5f;
        gVar.f5902N0 = 0.5f;
        gVar.f5903O0 = 0.5f;
        gVar.f5904P0 = 0;
        gVar.f5905Q0 = 0;
        gVar.f5906R0 = 2;
        gVar.f5907S0 = 2;
        gVar.T0 = 0;
        gVar.f5908U0 = -1;
        gVar.f5909V0 = 0;
        gVar.f5910W0 = new ArrayList();
        gVar.f5911X0 = null;
        gVar.f5912Y0 = null;
        gVar.f5913Z0 = null;
        gVar.f5915b1 = 0;
        this.f1626k = gVar;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, t.f206b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f1626k.f5909V0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    g gVar2 = this.f1626k;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar2.f5916s0 = dimensionPixelSize;
                    gVar2.f5917t0 = dimensionPixelSize;
                    gVar2.f5918u0 = dimensionPixelSize;
                    gVar2.f5919v0 = dimensionPixelSize;
                } else if (index == 18) {
                    g gVar3 = this.f1626k;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar3.f5918u0 = dimensionPixelSize2;
                    gVar3.f5920w0 = dimensionPixelSize2;
                    gVar3.f5921x0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f1626k.f5919v0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f1626k.f5920w0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f1626k.f5916s0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f1626k.f5921x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f1626k.f5917t0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f1626k.T0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f1626k.f5893D0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f1626k.f5894E0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f1626k.f5895F0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f1626k.H0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f1626k.f5896G0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f1626k.f5897I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f1626k.f5898J0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f1626k.f5900L0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f1626k.f5902N0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f1626k.f5901M0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f1626k.f5903O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f1626k.f5899K0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f1626k.f5906R0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f1626k.f5907S0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f1626k.f5904P0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f1626k.f5905Q0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f1626k.f5908U0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.e = this.f1626k;
        i();
    }

    @Override // A.c
    public final void h(C0495d c0495d, boolean z2) {
        g gVar = this.f1626k;
        int i = gVar.f5918u0;
        if (i > 0 || gVar.f5919v0 > 0) {
            if (z2) {
                gVar.f5920w0 = gVar.f5919v0;
                gVar.f5921x0 = i;
            } else {
                gVar.f5920w0 = i;
                gVar.f5921x0 = gVar.f5919v0;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:384:0x0702  */
    /* JADX WARN: Removed duplicated region for block: B:397:0x07a8  */
    /* JADX WARN: Removed duplicated region for block: B:398:0x07ad  */
    /* JADX WARN: Removed duplicated region for block: B:405:0x07c1  */
    /* JADX WARN: Removed duplicated region for block: B:406:0x07c4  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:413:0x07e0  */
    /* JADX WARN: Removed duplicated region for block: B:414:0x07e2  */
    /* JADX WARN: Removed duplicated region for block: B:424:0x00ce A[EDGE_INSN: B:424:0x00ce->B:59:0x00ce BREAK  A[LOOP:1: B:53:0x00ba->B:58:0x00ca], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0103  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x011e  */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    @Override // A.v
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void j(g gVar, int i, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int[] iArr;
        C0497f c0497f;
        char c3;
        ?? r2;
        int i17;
        int i18;
        int iMin;
        int[] iArr2;
        int i19;
        int i20;
        C0495d[] c0495dArr;
        int i21;
        int i22;
        ArrayList arrayList;
        int[] iArr3;
        C0495d c0495d;
        int i23;
        int i24;
        int iCeil;
        int iCeil2;
        Object obj;
        C0495d c0495d2;
        int i25;
        int i26;
        int i27;
        ArrayList arrayList2;
        int i28;
        int i29;
        int i30;
        C0495d c0495d3;
        int i31;
        int i32;
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (gVar == null) {
            setMeasuredDimension(0, 0);
            return;
        }
        if (gVar.f5931r0 <= 0) {
            int i33 = gVar.f5920w0;
            int i34 = gVar.f5921x0;
            int i35 = gVar.f5916s0;
            int i36 = gVar.f5917t0;
            int[] iArr4 = new int[2];
            int i37 = (size - i33) - i34;
            i4 = gVar.f5909V0;
            if (i4 == 1) {
                i37 = (size2 - i35) - i36;
            }
            if (i4 != 0) {
                if (gVar.f5893D0 == -1) {
                    gVar.f5893D0 = 0;
                }
                if (gVar.f5894E0 == -1) {
                    gVar.f5894E0 = 0;
                }
            } else {
                if (gVar.f5893D0 == -1) {
                    gVar.f5893D0 = 0;
                }
                if (gVar.f5894E0 == -1) {
                    gVar.f5894E0 = 0;
                }
            }
            C0495d[] c0495dArr2 = gVar.f5930q0;
            i5 = 0;
            i6 = 0;
            while (true) {
                i7 = gVar.f5931r0;
                if (i5 < i7) {
                    break;
                }
                if (gVar.f5930q0[i5].f5825g0 == 8) {
                    i6++;
                }
                i5++;
            }
            if (i6 > 0) {
                c0495dArr2 = new C0495d[i7 - i6];
                int i38 = 0;
                i7 = 0;
                while (i38 < gVar.f5931r0) {
                    C0495d c0495d4 = gVar.f5930q0[i38];
                    int i39 = i37;
                    int[] iArr5 = iArr4;
                    if (c0495d4.f5825g0 != 8) {
                        c0495dArr2[i7] = c0495d4;
                        i7++;
                    }
                    i38++;
                    i37 = i39;
                    iArr4 = iArr5;
                }
            }
            int i40 = i37;
            int[] iArr6 = iArr4;
            int i41 = i7;
            C0495d[] c0495dArr3 = c0495dArr2;
            gVar.f5914a1 = c0495dArr3;
            gVar.f5915b1 = i41;
            i8 = gVar.T0;
            ArrayList arrayList3 = gVar.f5910W0;
            if (i8 == 0) {
                C0494c c0494c = gVar.f5797J;
                C0494c c0494c2 = gVar.f5796I;
                C0494c c0494c3 = gVar.K;
                C0494c c0494c4 = gVar.f5798L;
                int[] iArr7 = gVar.f5842p0;
                if (i8 == 1) {
                    i9 = i36;
                    i10 = i35;
                    i11 = i34;
                    i12 = i33;
                    i13 = mode;
                    i14 = size;
                    i15 = mode2;
                    i16 = size2;
                    iArr = iArr6;
                    ArrayList arrayList4 = arrayList3;
                    int i42 = gVar.f5909V0;
                    if (i41 != 0) {
                        arrayList4.clear();
                        C0497f c0497f2 = new C0497f(gVar, i42, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i40);
                        arrayList4.add(c0497f2);
                        if (i42 == 0) {
                            C0497f c0497f3 = c0497f2;
                            i20 = 0;
                            int i43 = 0;
                            int i44 = 0;
                            while (i44 < i41) {
                                C0495d c0495d5 = c0495dArr3[i44];
                                int iU = gVar.U(c0495d5, i40);
                                if (c0495d5.f5842p0[0] == 3) {
                                    i20++;
                                }
                                int i45 = i20;
                                boolean z2 = (i43 == i40 || (gVar.f5904P0 + i43) + iU > i40) && c0497f3.f5875b != null;
                                if (!z2 && i44 > 0 && (i24 = gVar.f5908U0) > 0 && i44 % i24 == 0) {
                                    z2 = true;
                                }
                                if (z2) {
                                    iArr3 = iArr7;
                                    c0495d = c0495d5;
                                    i23 = i42;
                                    C0497f c0497f4 = new C0497f(gVar, i42, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i40);
                                    c0497f4.f5885n = i44;
                                    arrayList4.add(c0497f4);
                                    c0497f3 = c0497f4;
                                } else {
                                    iArr3 = iArr7;
                                    c0495d = c0495d5;
                                    i23 = i42;
                                    if (i44 > 0) {
                                        i43 = gVar.f5904P0 + iU + i43;
                                    }
                                    c0497f3.a(c0495d);
                                    i44++;
                                    i20 = i45;
                                    iArr7 = iArr3;
                                    i42 = i23;
                                }
                                i43 = iU;
                                c0497f3.a(c0495d);
                                i44++;
                                i20 = i45;
                                iArr7 = iArr3;
                                i42 = i23;
                            }
                            iArr2 = iArr7;
                            i19 = i42;
                        } else {
                            iArr2 = iArr7;
                            i19 = i42;
                            C0497f c0497f5 = c0497f2;
                            int i46 = 0;
                            i20 = 0;
                            int i47 = 0;
                            while (i46 < i41) {
                                C0495d c0495d6 = c0495dArr3[i46];
                                int iT = gVar.T(c0495d6, i40);
                                if (c0495d6.f5842p0[1] == 3) {
                                    i20++;
                                }
                                int i48 = i20;
                                boolean z3 = (i47 == i40 || (gVar.f5905Q0 + i47) + iT > i40) && c0497f5.f5875b != null;
                                if (!z3 && i46 > 0 && (i21 = gVar.f5908U0) > 0 && i46 % i21 == 0) {
                                    z3 = true;
                                }
                                if (z3) {
                                    c0495dArr = c0495dArr3;
                                    C0497f c0497f6 = new C0497f(gVar, i19, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i40);
                                    c0497f6.f5885n = i46;
                                    arrayList4.add(c0497f6);
                                    i47 = iT;
                                    c0497f5 = c0497f6;
                                } else {
                                    c0495dArr = c0495dArr3;
                                    i47 = i46 > 0 ? gVar.f5905Q0 + iT + i47 : iT;
                                }
                                c0497f5.a(c0495d6);
                                i46++;
                                i20 = i48;
                                c0495dArr3 = c0495dArr;
                            }
                        }
                        int size3 = arrayList4.size();
                        int i49 = gVar.f5920w0;
                        int i50 = gVar.f5916s0;
                        int i51 = gVar.f5921x0;
                        int i52 = gVar.f5917t0;
                        boolean z4 = iArr2[0] == 2 || iArr2[1] == 2;
                        if (i20 > 0 && z4) {
                            for (int i53 = 0; i53 < size3; i53++) {
                                C0497f c0497f7 = (C0497f) arrayList4.get(i53);
                                if (i19 == 0) {
                                    c0497f7.e(i40 - c0497f7.d());
                                } else {
                                    c0497f7.e(i40 - c0497f7.c());
                                }
                            }
                        }
                        int i54 = i50;
                        C0494c c0494c5 = c0494c2;
                        C0494c c0494c6 = c0494c3;
                        C0494c c0494c7 = c0494c4;
                        int i55 = 0;
                        int i56 = 0;
                        int i57 = 0;
                        int i58 = i49;
                        C0494c c0494c8 = c0494c;
                        while (i55 < size3) {
                            C0497f c0497f8 = (C0497f) arrayList4.get(i55);
                            if (i19 == 0) {
                                if (i55 < size3 - 1) {
                                    c0494c7 = ((C0497f) arrayList4.get(i55 + 1)).f5875b.f5797J;
                                    arrayList = arrayList4;
                                    i52 = 0;
                                } else {
                                    i52 = gVar.f5917t0;
                                    arrayList = arrayList4;
                                    c0494c7 = c0494c4;
                                }
                                C0494c c0494c9 = c0497f8.f5875b.f5798L;
                                c0497f8.f(i19, c0494c5, c0494c8, c0494c6, c0494c7, i58, i54, i51, i52, i40);
                                int iMax = Math.max(i56, c0497f8.d());
                                int iC = c0497f8.c() + i57;
                                if (i55 > 0) {
                                    iC += gVar.f5905Q0;
                                }
                                i22 = size3;
                                i56 = iMax;
                                i57 = iC;
                                c0494c8 = c0494c9;
                                arrayList4 = arrayList;
                                i54 = 0;
                            } else {
                                ArrayList arrayList5 = arrayList4;
                                if (i55 < size3 - 1) {
                                    arrayList4 = arrayList5;
                                    i22 = size3;
                                    c0494c6 = ((C0497f) arrayList4.get(i55 + 1)).f5875b.f5796I;
                                    i51 = 0;
                                } else {
                                    arrayList4 = arrayList5;
                                    i51 = gVar.f5921x0;
                                    i22 = size3;
                                    c0494c6 = c0494c3;
                                }
                                C0494c c0494c10 = c0497f8.f5875b.K;
                                c0497f8.f(i19, c0494c5, c0494c8, c0494c6, c0494c7, i58, i54, i51, i52, i40);
                                int iD = c0497f8.d() + i56;
                                int iMax2 = Math.max(i57, c0497f8.c());
                                if (i55 > 0) {
                                    iD += gVar.f5904P0;
                                }
                                i56 = iD;
                                i57 = iMax2;
                                i58 = 0;
                                c0494c5 = c0494c10;
                            }
                            i55++;
                            size3 = i22;
                        }
                        iArr[0] = i56;
                        iArr[1] = i57;
                    }
                } else if (i8 == 2) {
                    i9 = i36;
                    i10 = i35;
                    i11 = i34;
                    i12 = i33;
                    i13 = mode;
                    i14 = size;
                    i15 = mode2;
                    i16 = size2;
                    iArr = iArr6;
                    int i59 = gVar.f5909V0;
                    if (i59 == 0) {
                        int i60 = gVar.f5908U0;
                        if (i60 <= 0) {
                            int i61 = 0;
                            iCeil2 = 0;
                            for (int i62 = 0; i62 < i41; i62++) {
                                if (i62 > 0) {
                                    i61 += gVar.f5904P0;
                                }
                                C0495d c0495d7 = c0495dArr3[i62];
                                if (c0495d7 != null) {
                                    int iU2 = gVar.U(c0495d7, i40) + i61;
                                    if (iU2 > i40) {
                                        break;
                                    }
                                    iCeil2++;
                                    i61 = iU2;
                                }
                            }
                        } else {
                            iCeil2 = i60;
                        }
                        iCeil = 0;
                    } else {
                        iCeil = gVar.f5908U0;
                        if (iCeil <= 0) {
                            int i63 = 0;
                            int i64 = 0;
                            for (int i65 = 0; i65 < i41; i65++) {
                                if (i65 > 0) {
                                    i63 += gVar.f5905Q0;
                                }
                                C0495d c0495d8 = c0495dArr3[i65];
                                if (c0495d8 != null) {
                                    int iT2 = gVar.T(c0495d8, i40) + i63;
                                    if (iT2 > i40) {
                                        break;
                                    }
                                    i64++;
                                    i63 = iT2;
                                }
                            }
                            iCeil = i64;
                        }
                        iCeil2 = 0;
                    }
                    if (gVar.f5913Z0 == null) {
                        gVar.f5913Z0 = new int[2];
                    }
                    boolean z5 = (iCeil == 0 && i59 == 1) || (iCeil2 == 0 && i59 == 0);
                    while (!z5) {
                        if (i59 == 0) {
                            iCeil = (int) Math.ceil(i41 / iCeil2);
                        } else {
                            iCeil2 = (int) Math.ceil(i41 / iCeil);
                        }
                        C0495d[] c0495dArr4 = gVar.f5912Y0;
                        if (c0495dArr4 == null || c0495dArr4.length < iCeil2) {
                            obj = null;
                            gVar.f5912Y0 = new C0495d[iCeil2];
                        } else {
                            obj = null;
                            Arrays.fill(c0495dArr4, (Object) null);
                        }
                        C0495d[] c0495dArr5 = gVar.f5911X0;
                        if (c0495dArr5 == null || c0495dArr5.length < iCeil) {
                            gVar.f5911X0 = new C0495d[iCeil];
                        } else {
                            Arrays.fill(c0495dArr5, obj);
                        }
                        for (int i66 = 0; i66 < iCeil2; i66++) {
                            for (int i67 = 0; i67 < iCeil; i67++) {
                                int i68 = (i67 * iCeil2) + i66;
                                if (i59 == 1) {
                                    i68 = (i66 * iCeil) + i67;
                                }
                                if (i68 < c0495dArr3.length && (c0495d2 = c0495dArr3[i68]) != null) {
                                    int iU3 = gVar.U(c0495d2, i40);
                                    C0495d c0495d9 = gVar.f5912Y0[i66];
                                    if (c0495d9 == null || c0495d9.q() < iU3) {
                                        gVar.f5912Y0[i66] = c0495d2;
                                    }
                                    int iT3 = gVar.T(c0495d2, i40);
                                    C0495d c0495d10 = gVar.f5911X0[i67];
                                    if (c0495d10 == null || c0495d10.k() < iT3) {
                                        gVar.f5911X0[i67] = c0495d2;
                                    }
                                }
                            }
                        }
                        int iU4 = 0;
                        for (int i69 = 0; i69 < iCeil2; i69++) {
                            C0495d c0495d11 = gVar.f5912Y0[i69];
                            if (c0495d11 != null) {
                                if (i69 > 0) {
                                    iU4 += gVar.f5904P0;
                                }
                                iU4 = gVar.U(c0495d11, i40) + iU4;
                            }
                        }
                        int iT4 = 0;
                        for (int i70 = 0; i70 < iCeil; i70++) {
                            C0495d c0495d12 = gVar.f5911X0[i70];
                            if (c0495d12 != null) {
                                if (i70 > 0) {
                                    iT4 += gVar.f5905Q0;
                                }
                                iT4 = gVar.T(c0495d12, i40) + iT4;
                            }
                        }
                        iArr[0] = iU4;
                        iArr[1] = iT4;
                        if (i59 == 0) {
                            if (iU4 <= i40 || iCeil2 <= 1) {
                                z5 = true;
                            } else {
                                iCeil2--;
                            }
                        } else if (iT4 <= i40 || iCeil <= 1) {
                            z5 = true;
                        } else {
                            iCeil--;
                        }
                    }
                    int[] iArr8 = gVar.f5913Z0;
                    iArr8[0] = iCeil2;
                    iArr8[1] = iCeil;
                } else if (i8 != 3) {
                    i9 = i36;
                    i10 = i35;
                    i11 = i34;
                    i12 = i33;
                    i13 = mode;
                    i14 = size;
                    i15 = mode2;
                    i16 = size2;
                    iArr = iArr6;
                } else {
                    int i71 = gVar.f5909V0;
                    if (i41 != 0) {
                        arrayList3.clear();
                        i16 = size2;
                        int i72 = i40;
                        iArr = iArr6;
                        i9 = i36;
                        i10 = i35;
                        i11 = i34;
                        i12 = i33;
                        i15 = mode2;
                        ArrayList arrayList6 = arrayList3;
                        C0497f c0497f9 = new C0497f(gVar, i71, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i72);
                        arrayList6.add(c0497f9);
                        if (i71 == 0) {
                            int i73 = 0;
                            i25 = 0;
                            int i74 = 0;
                            int i75 = 0;
                            while (i75 < i41) {
                                i73++;
                                C0495d c0495d13 = c0495dArr3[i75];
                                int i76 = i72;
                                int iU5 = gVar.U(c0495d13, i76);
                                if (c0495d13.f5842p0[0] == 3) {
                                    i25++;
                                }
                                int i77 = i25;
                                boolean z6 = (i74 == i76 || (gVar.f5904P0 + i74) + iU5 > i76) && c0497f9.f5875b != null;
                                if (!z6 && i75 > 0 && (i32 = gVar.f5908U0) > 0 && i73 > i32) {
                                    z6 = true;
                                }
                                if (z6) {
                                    i72 = i76;
                                    i30 = size;
                                    c0495d3 = c0495d13;
                                    i29 = mode;
                                    i31 = i75;
                                    c0497f9 = new C0497f(gVar, i71, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i72);
                                    c0497f9.f5885n = i31;
                                    arrayList6.add(c0497f9);
                                    i74 = iU5;
                                    i73 = 1;
                                } else {
                                    i72 = i76;
                                    i29 = mode;
                                    i30 = size;
                                    c0495d3 = c0495d13;
                                    i31 = i75;
                                    i74 = i31 > 0 ? gVar.f5904P0 + iU5 + i74 : iU5;
                                }
                                c0497f9.a(c0495d3);
                                i75 = i31 + 1;
                                i25 = i77;
                                size = i30;
                                mode = i29;
                            }
                            i13 = mode;
                            i14 = size;
                        } else {
                            i13 = mode;
                            i14 = size;
                            int i78 = 0;
                            i25 = 0;
                            int i79 = 0;
                            int i80 = 0;
                            while (i80 < i41) {
                                i78++;
                                C0495d c0495d14 = c0495dArr3[i80];
                                int i81 = i72;
                                int iT5 = gVar.T(c0495d14, i81);
                                if (c0495d14.f5842p0[1] == 3) {
                                    i25++;
                                }
                                int i82 = i25;
                                boolean z7 = (i79 == i81 || (gVar.f5905Q0 + i79) + iT5 > i81) && c0497f9.f5875b != null;
                                if (!z7 && i80 > 0 && (i26 = gVar.f5908U0) > 0 && i78 > i26) {
                                    z7 = true;
                                }
                                if (z7) {
                                    i72 = i81;
                                    c0497f9 = new C0497f(gVar, i71, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i81);
                                    c0497f9.f5885n = i80;
                                    arrayList6.add(c0497f9);
                                    i79 = iT5;
                                    i78 = 1;
                                } else {
                                    i72 = i81;
                                    i79 = i80 > 0 ? gVar.f5905Q0 + iT5 + i79 : iT5;
                                }
                                c0497f9.a(c0495d14);
                                i80++;
                                i25 = i82;
                            }
                        }
                        int size4 = arrayList6.size();
                        int i83 = gVar.f5920w0;
                        int i84 = gVar.f5916s0;
                        int i85 = gVar.f5921x0;
                        int i86 = gVar.f5917t0;
                        boolean z8 = iArr7[0] == 2 || iArr7[1] == 2;
                        if (i25 > 0 && z8) {
                            int i87 = 0;
                            while (i87 < size4) {
                                C0497f c0497f10 = (C0497f) arrayList6.get(i87);
                                if (i71 == 0) {
                                    i28 = i72;
                                    c0497f10.e(i28 - c0497f10.d());
                                } else {
                                    i28 = i72;
                                    c0497f10.e(i28 - c0497f10.c());
                                }
                                i87++;
                                i72 = i28;
                            }
                        }
                        int i88 = i72;
                        C0494c c0494c11 = c0494c;
                        C0494c c0494c12 = c0494c2;
                        C0494c c0494c13 = c0494c3;
                        C0494c c0494c14 = c0494c4;
                        int i89 = 0;
                        int i90 = 0;
                        int i91 = 0;
                        while (i89 < size4) {
                            C0497f c0497f11 = (C0497f) arrayList6.get(i89);
                            if (i71 == 0) {
                                if (i89 < size4 - 1) {
                                    c0494c14 = ((C0497f) arrayList6.get(i89 + 1)).f5875b.f5797J;
                                    arrayList2 = arrayList6;
                                    i86 = 0;
                                } else {
                                    i86 = gVar.f5917t0;
                                    arrayList2 = arrayList6;
                                    c0494c14 = c0494c4;
                                }
                                C0494c c0494c15 = c0497f11.f5875b.f5798L;
                                c0497f11.f(i71, c0494c12, c0494c11, c0494c13, c0494c14, i83, i84, i85, i86, i88);
                                int iMax3 = Math.max(i90, c0497f11.d());
                                int iC2 = c0497f11.c() + i91;
                                if (i89 > 0) {
                                    iC2 += gVar.f5905Q0;
                                }
                                i27 = size4;
                                i90 = iMax3;
                                i91 = iC2;
                                c0494c11 = c0494c15;
                                arrayList6 = arrayList2;
                                i84 = 0;
                            } else {
                                ArrayList arrayList7 = arrayList6;
                                if (i89 < size4 - 1) {
                                    arrayList6 = arrayList7;
                                    i27 = size4;
                                    c0494c13 = ((C0497f) arrayList6.get(i89 + 1)).f5875b.f5796I;
                                    i85 = 0;
                                } else {
                                    arrayList6 = arrayList7;
                                    i85 = gVar.f5921x0;
                                    i27 = size4;
                                    c0494c13 = c0494c3;
                                }
                                C0494c c0494c16 = c0497f11.f5875b.K;
                                c0497f11.f(i71, c0494c12, c0494c11, c0494c13, c0494c14, i83, i84, i85, i86, i88);
                                int iD2 = c0497f11.d() + i90;
                                int iMax4 = Math.max(i91, c0497f11.c());
                                if (i89 > 0) {
                                    iD2 += gVar.f5904P0;
                                }
                                i90 = iD2;
                                c0494c12 = c0494c16;
                                i91 = iMax4;
                                i83 = 0;
                            }
                            i89++;
                            size4 = i27;
                        }
                        iArr[0] = i90;
                        iArr[1] = i91;
                    }
                }
            } else {
                i9 = i36;
                i10 = i35;
                i11 = i34;
                i12 = i33;
                i13 = mode;
                i14 = size;
                i15 = mode2;
                i16 = size2;
                iArr = iArr6;
                int i92 = gVar.f5909V0;
                if (i41 != 0) {
                    if (arrayList3.size() == 0) {
                        c0497f = new C0497f(gVar, i92, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, i40);
                        arrayList3.add(c0497f);
                    } else {
                        c0497f = (C0497f) arrayList3.get(0);
                        c0497f.f5876c = 0;
                        c0497f.f5875b = null;
                        c0497f.f5883l = 0;
                        c0497f.f5884m = 0;
                        c0497f.f5885n = 0;
                        c0497f.f5886o = 0;
                        c0497f.f5887p = 0;
                        c0497f.f(i92, gVar.f5796I, gVar.f5797J, gVar.K, gVar.f5798L, gVar.f5920w0, gVar.f5916s0, gVar.f5921x0, gVar.f5917t0, i40);
                    }
                    for (int i93 = 0; i93 < i41; i93++) {
                        c0497f.a(c0495dArr3[i93]);
                    }
                    c3 = 0;
                    iArr[0] = c0497f.d();
                    r2 = 1;
                    iArr[1] = c0497f.c();
                }
                int i94 = iArr[c3] + i12 + i11;
                int i95 = iArr[r2] + i10 + i9;
                i17 = i13;
                if (i17 == 1073741824) {
                    i18 = i15;
                    iMin = i14;
                } else {
                    if (i17 == Integer.MIN_VALUE) {
                        iMin = Math.min(i94, i14);
                    } else if (i17 == 0) {
                        iMin = i94;
                    } else {
                        i18 = i15;
                        iMin = 0;
                    }
                    i18 = i15;
                }
                int iMin2 = i18 == 1073741824 ? i16 : i18 == Integer.MIN_VALUE ? Math.min(i95, i16) : i18 == 0 ? i95 : 0;
                gVar.f5923z0 = iMin;
                gVar.f5890A0 = iMin2;
                gVar.O(iMin);
                gVar.L(iMin2);
                gVar.f5922y0 = gVar.f5931r0 > 0 ? r2 : false;
            }
            c3 = 0;
            r2 = 1;
            int i942 = iArr[c3] + i12 + i11;
            int i952 = iArr[r2] + i10 + i9;
            i17 = i13;
            if (i17 == 1073741824) {
            }
            if (i18 == 1073741824) {
            }
            gVar.f5923z0 = iMin;
            gVar.f5890A0 = iMin2;
            gVar.O(iMin);
            gVar.L(iMin2);
            gVar.f5922y0 = gVar.f5931r0 > 0 ? r2 : false;
        } else {
            C0495d c0495d15 = gVar.f5806T;
            f fVar = c0495d15 != null ? ((C0496e) c0495d15).f5868u0 : null;
            if (fVar == null) {
                gVar.f5923z0 = 0;
                gVar.f5890A0 = 0;
                gVar.f5922y0 = false;
            } else {
                for (int i96 = 0; i96 < gVar.f5931r0; i96++) {
                    C0495d c0495d16 = gVar.f5930q0[i96];
                    if (c0495d16 != null && !(c0495d16 instanceof h)) {
                        int iJ = c0495d16.j(0);
                        int iJ2 = c0495d16.j(1);
                        if (iJ != 3 || c0495d16.f5844r == 1 || iJ2 != 3 || c0495d16.f5845s == 1) {
                            if (iJ == 3) {
                                iJ = 2;
                            }
                            if (iJ2 == 3) {
                                iJ2 = 2;
                            }
                            C0517b c0517b = gVar.f5891B0;
                            c0517b.f5975a = iJ;
                            c0517b.f5976b = iJ2;
                            c0517b.f5977c = c0495d16.q();
                            c0517b.f5978d = c0495d16.k();
                            fVar.b(c0495d16, c0517b);
                            c0495d16.O(c0517b.e);
                            c0495d16.L(c0517b.f5979f);
                            c0495d16.I(c0517b.f5980g);
                        }
                    }
                }
                int i332 = gVar.f5920w0;
                int i342 = gVar.f5921x0;
                int i352 = gVar.f5916s0;
                int i362 = gVar.f5917t0;
                int[] iArr42 = new int[2];
                int i372 = (size - i332) - i342;
                i4 = gVar.f5909V0;
                if (i4 == 1) {
                }
                if (i4 != 0) {
                }
                C0495d[] c0495dArr22 = gVar.f5930q0;
                i5 = 0;
                i6 = 0;
                while (true) {
                    i7 = gVar.f5931r0;
                    if (i5 < i7) {
                    }
                    i5++;
                }
                if (i6 > 0) {
                }
                int i402 = i372;
                int[] iArr62 = iArr42;
                int i412 = i7;
                C0495d[] c0495dArr32 = c0495dArr22;
                gVar.f5914a1 = c0495dArr32;
                gVar.f5915b1 = i412;
                i8 = gVar.T0;
                ArrayList arrayList32 = gVar.f5910W0;
                if (i8 == 0) {
                }
                c3 = 0;
                r2 = 1;
                int i9422 = iArr[c3] + i12 + i11;
                int i9522 = iArr[r2] + i10 + i9;
                i17 = i13;
                if (i17 == 1073741824) {
                }
                if (i18 == 1073741824) {
                }
                gVar.f5923z0 = iMin;
                gVar.f5890A0 = iMin2;
                gVar.O(iMin);
                gVar.L(iMin2);
                gVar.f5922y0 = gVar.f5931r0 > 0 ? r2 : false;
            }
        }
        setMeasuredDimension(gVar.f5923z0, gVar.f5890A0);
    }

    @Override // A.c, android.view.View
    public final void onMeasure(int i, int i3) {
        j(this.f1626k, i, i3);
    }

    public void setFirstHorizontalBias(float f3) {
        this.f1626k.f5900L0 = f3;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i) {
        this.f1626k.f5895F0 = i;
        requestLayout();
    }

    public void setFirstVerticalBias(float f3) {
        this.f1626k.f5901M0 = f3;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i) {
        this.f1626k.f5896G0 = i;
        requestLayout();
    }

    public void setHorizontalAlign(int i) {
        this.f1626k.f5906R0 = i;
        requestLayout();
    }

    public void setHorizontalBias(float f3) {
        this.f1626k.f5898J0 = f3;
        requestLayout();
    }

    public void setHorizontalGap(int i) {
        this.f1626k.f5904P0 = i;
        requestLayout();
    }

    public void setHorizontalStyle(int i) {
        this.f1626k.f5893D0 = i;
        requestLayout();
    }

    public void setLastHorizontalBias(float f3) {
        this.f1626k.f5902N0 = f3;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i) {
        this.f1626k.H0 = i;
        requestLayout();
    }

    public void setLastVerticalBias(float f3) {
        this.f1626k.f5903O0 = f3;
        requestLayout();
    }

    public void setLastVerticalStyle(int i) {
        this.f1626k.f5897I0 = i;
        requestLayout();
    }

    public void setMaxElementsWrap(int i) {
        this.f1626k.f5908U0 = i;
        requestLayout();
    }

    public void setOrientation(int i) {
        this.f1626k.f5909V0 = i;
        requestLayout();
    }

    public void setPadding(int i) {
        g gVar = this.f1626k;
        gVar.f5916s0 = i;
        gVar.f5917t0 = i;
        gVar.f5918u0 = i;
        gVar.f5919v0 = i;
        requestLayout();
    }

    public void setPaddingBottom(int i) {
        this.f1626k.f5917t0 = i;
        requestLayout();
    }

    public void setPaddingLeft(int i) {
        this.f1626k.f5920w0 = i;
        requestLayout();
    }

    public void setPaddingRight(int i) {
        this.f1626k.f5921x0 = i;
        requestLayout();
    }

    public void setPaddingTop(int i) {
        this.f1626k.f5916s0 = i;
        requestLayout();
    }

    public void setVerticalAlign(int i) {
        this.f1626k.f5907S0 = i;
        requestLayout();
    }

    public void setVerticalBias(float f3) {
        this.f1626k.f5899K0 = f3;
        requestLayout();
    }

    public void setVerticalGap(int i) {
        this.f1626k.f5905Q0 = i;
        requestLayout();
    }

    public void setVerticalStyle(int i) {
        this.f1626k.f5894E0 = i;
        requestLayout();
    }

    public void setWrapMode(int i) {
        this.f1626k.T0 = i;
        requestLayout();
    }
}
