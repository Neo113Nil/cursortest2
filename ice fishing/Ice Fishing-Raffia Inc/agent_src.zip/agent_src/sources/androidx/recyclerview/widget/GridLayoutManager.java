package androidx.recyclerview.widget;

import A.i;
import A0.f;
import K0.h;
import P.O;
import Q.e;
import Q.g;
import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;
import p0.C0367A;
import p0.C0368B;
import p0.C0369C;
import p0.C0393y;
import p0.D;
import p0.L;
import p0.V;
import p0.W;
import p0.b0;
import p0.h0;
import p0.l0;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: P, reason: collision with root package name */
    public static final Set f1850P = Collections.unmodifiableSet(new HashSet(Arrays.asList(17, 66, 33, 130)));

    /* renamed from: E, reason: collision with root package name */
    public boolean f1851E;
    public int F;

    /* renamed from: G, reason: collision with root package name */
    public int[] f1852G;

    /* renamed from: H, reason: collision with root package name */
    public View[] f1853H;

    /* renamed from: I, reason: collision with root package name */
    public final SparseIntArray f1854I;

    /* renamed from: J, reason: collision with root package name */
    public final SparseIntArray f1855J;
    public final i K;

    /* renamed from: L, reason: collision with root package name */
    public final Rect f1856L;

    /* renamed from: M, reason: collision with root package name */
    public int f1857M;

    /* renamed from: N, reason: collision with root package name */
    public int f1858N;

    /* renamed from: O, reason: collision with root package name */
    public int f1859O;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i3) {
        super(context, attributeSet, i, i3);
        this.f1851E = false;
        this.F = -1;
        this.f1854I = new SparseIntArray();
        this.f1855J = new SparseIntArray();
        this.K = new i(17);
        this.f1856L = new Rect();
        this.f1857M = -1;
        this.f1858N = -1;
        this.f1859O = -1;
        s1(V.H(context, attributeSet, i, i3).f4836b);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final boolean C0() {
        return this.f1874z == null && !this.f1851E;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void E0(h0 h0Var, C0369C c0369c, h hVar) {
        int i;
        int i3 = this.F;
        for (int i4 = 0; i4 < this.F && (i = c0369c.f4791d) >= 0 && i < h0Var.b() && i3 > 0; i4++) {
            hVar.b(c0369c.f4791d, Math.max(0, c0369c.f4793g));
            this.K.getClass();
            i3--;
            c0369c.f4791d += c0369c.e;
        }
    }

    @Override // p0.V
    public final int I(b0 b0Var, h0 h0Var) {
        if (this.f1864p == 0) {
            return Math.min(this.F, B());
        }
        if (h0Var.b() < 1) {
            return 0;
        }
        return o1(h0Var.b() - 1, b0Var, h0Var) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View Q0(b0 b0Var, h0 h0Var, boolean z2, boolean z3) {
        int i;
        int iV;
        int iV2 = v();
        int i3 = 1;
        if (z3) {
            iV = v() - 1;
            i = -1;
            i3 = -1;
        } else {
            i = iV2;
            iV = 0;
        }
        int iB = h0Var.b();
        J0();
        int iM = this.f1866r.m();
        int i4 = this.f1866r.i();
        View view = null;
        View view2 = null;
        while (iV != i) {
            View viewU = u(iV);
            int iG = V.G(viewU);
            if (iG >= 0 && iG < iB && p1(iG, b0Var, h0Var) == 0) {
                if (((W) viewU.getLayoutParams()).f4852a.i()) {
                    if (view2 == null) {
                        view2 = viewU;
                    }
                } else {
                    if (this.f1866r.g(viewU) < i4 && this.f1866r.d(viewU) >= iM) {
                        return viewU;
                    }
                    if (view == null) {
                        view = viewU;
                    }
                }
            }
            iV += i3;
        }
        return view != null ? view : view2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:64:0x00df, code lost:
    
        if (r13 == (r2 > r15)) goto L55;
     */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x011a  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View T(View view, int i, b0 b0Var, h0 h0Var) {
        View viewD;
        int iV;
        int i3;
        int iV2;
        View view2;
        View view3;
        int i4;
        b0 b0Var2 = b0Var;
        h0 h0Var2 = h0Var;
        RecyclerView recyclerView = this.f4840b;
        View view4 = null;
        if (recyclerView == null || (viewD = recyclerView.D(view)) == null || this.f4839a.f4904c.contains(viewD)) {
            viewD = null;
        }
        if (viewD == null) {
            return null;
        }
        C0393y c0393y = (C0393y) viewD.getLayoutParams();
        int i5 = c0393y.e;
        int i6 = c0393y.f5073f + i5;
        if (super.T(view, i, b0Var, h0Var) == null) {
            return null;
        }
        if ((I0(i) == 1) != this.f1869u) {
            iV2 = v() - 1;
            iV = -1;
            i3 = -1;
        } else {
            iV = v();
            i3 = 1;
            iV2 = 0;
        }
        boolean z2 = this.f1864p == 1 && V0();
        int iO1 = o1(iV2, b0Var2, h0Var2);
        int i7 = -1;
        int i8 = -1;
        int i9 = i3;
        int iMin = 0;
        int iMin2 = 0;
        int i10 = iV2;
        View view5 = null;
        while (i10 != iV) {
            int i11 = iV;
            int iO12 = o1(i10, b0Var2, h0Var2);
            View viewU = u(i10);
            if (viewU == viewD) {
                break;
            }
            if (!viewU.hasFocusable() || iO12 == iO1) {
                C0393y c0393y2 = (C0393y) viewU.getLayoutParams();
                int i12 = c0393y2.e;
                view2 = viewD;
                int i13 = c0393y2.f5073f + i12;
                if (viewU.hasFocusable() && i12 == i5 && i13 == i6) {
                    return viewU;
                }
                if (!(viewU.hasFocusable() && view4 == null) && (viewU.hasFocusable() || view5 != null)) {
                    view3 = view5;
                    int iMin3 = Math.min(i13, i6) - Math.max(i12, i5);
                    if (!viewU.hasFocusable()) {
                        if (view4 == null) {
                            i4 = iMin;
                            if (!this.f4841c.C(viewU) || !this.f4842d.C(viewU)) {
                                if (iMin3 <= iMin2) {
                                    if (iMin3 == iMin2) {
                                        if (z2 == (i12 > i7)) {
                                        }
                                        i10 += i9;
                                        b0Var2 = b0Var;
                                        h0Var2 = h0Var;
                                        iV = i11;
                                        viewD = view2;
                                    }
                                }
                                if (viewU.hasFocusable()) {
                                    int i14 = c0393y2.e;
                                    iMin2 = Math.min(i13, i6) - Math.max(i12, i5);
                                    i7 = i14;
                                    iMin = i4;
                                    view5 = viewU;
                                } else {
                                    int i15 = c0393y2.e;
                                    iMin = Math.min(i13, i6) - Math.max(i12, i5);
                                    i8 = i15;
                                    view5 = view3;
                                    view4 = viewU;
                                }
                                i10 += i9;
                                b0Var2 = b0Var;
                                h0Var2 = h0Var;
                                iV = i11;
                                viewD = view2;
                            }
                        }
                        iMin = i4;
                        view5 = view3;
                        i10 += i9;
                        b0Var2 = b0Var;
                        h0Var2 = h0Var;
                        iV = i11;
                        viewD = view2;
                    } else if (iMin3 <= iMin) {
                        if (iMin3 == iMin) {
                        }
                    }
                } else {
                    view3 = view5;
                }
                i4 = iMin;
                if (viewU.hasFocusable()) {
                }
                i10 += i9;
                b0Var2 = b0Var;
                h0Var2 = h0Var;
                iV = i11;
                viewD = view2;
            } else {
                if (view4 != null) {
                    break;
                }
                view2 = viewD;
                view3 = view5;
            }
            i4 = iMin;
            iMin = i4;
            view5 = view3;
            i10 += i9;
            b0Var2 = b0Var;
            h0Var2 = h0Var;
            iV = i11;
            viewD = view2;
        }
        return view4 != null ? view4 : view5;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final void V(b0 b0Var, h0 h0Var, g gVar) {
        super.V(b0Var, h0Var, gVar);
        gVar.i(GridView.class.getName());
        L l3 = this.f4840b.f1929n;
        if (l3 == null || l3.a() <= 1) {
            return;
        }
        gVar.b(e.f993p);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v22 */
    /* JADX WARN: Type inference failed for: r8v23, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r8v31 */
    /* JADX WARN: Type inference failed for: r8v32 */
    /* JADX WARN: Type inference failed for: r8v37 */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void W0(b0 b0Var, h0 h0Var, C0369C c0369c, C0368B c0368b) {
        int i;
        int i3;
        int i4;
        int iF;
        int iD;
        int iF2;
        int iF3;
        int iW;
        int iW2;
        ?? r8;
        int i5;
        View viewB;
        int iL = this.f1866r.l();
        boolean z2 = iL != 1073741824;
        int i6 = v() > 0 ? this.f1852G[this.F] : 0;
        if (z2) {
            t1();
        }
        boolean z3 = c0369c.e == 1;
        int iP1 = this.F;
        if (!z3) {
            iP1 = p1(c0369c.f4791d, b0Var, h0Var) + q1(c0369c.f4791d, b0Var, h0Var);
        }
        int i7 = 0;
        while (i7 < this.F && (i5 = c0369c.f4791d) >= 0 && i5 < h0Var.b() && iP1 > 0) {
            int i8 = c0369c.f4791d;
            int iQ1 = q1(i8, b0Var, h0Var);
            if (iQ1 > this.F) {
                throw new IllegalArgumentException("Item at position " + i8 + " requires " + iQ1 + " spans but GridLayoutManager has only " + this.F + " spans.");
            }
            iP1 -= iQ1;
            if (iP1 < 0 || (viewB = c0369c.b(b0Var)) == null) {
                break;
            }
            this.f1853H[i7] = viewB;
            i7++;
        }
        if (i7 == 0) {
            c0368b.f4785b = true;
            return;
        }
        if (z3) {
            i4 = 1;
            i3 = i7;
            i = 0;
        } else {
            i = i7 - 1;
            i3 = -1;
            i4 = -1;
        }
        int i9 = 0;
        while (i != i3) {
            View view = this.f1853H[i];
            C0393y c0393y = (C0393y) view.getLayoutParams();
            int iQ12 = q1(V.G(view), b0Var, h0Var);
            c0393y.f5073f = iQ12;
            c0393y.e = i9;
            i9 += iQ12;
            i += i4;
        }
        float f3 = 0.0f;
        int i10 = 0;
        for (int i11 = 0; i11 < i7; i11++) {
            View view2 = this.f1853H[i11];
            if (c0369c.f4796k != null) {
                r8 = 0;
                r8 = 0;
                if (z3) {
                    b(view2, -1, true);
                } else {
                    b(view2, 0, true);
                }
            } else if (z3) {
                r8 = 0;
                b(view2, -1, false);
            } else {
                r8 = 0;
                b(view2, 0, false);
            }
            RecyclerView recyclerView = this.f4840b;
            Rect rect = this.f1856L;
            if (recyclerView == null) {
                rect.set(r8, r8, r8, r8);
            } else {
                rect.set(recyclerView.N(view2));
            }
            r1(view2, iL, r8);
            int iE = this.f1866r.e(view2);
            if (iE > i10) {
                i10 = iE;
            }
            float f4 = (this.f1866r.f(view2) * 1.0f) / ((C0393y) view2.getLayoutParams()).f5073f;
            if (f4 > f3) {
                f3 = f4;
            }
        }
        if (z2) {
            h1(Math.max(Math.round(f3 * this.F), i6));
            i10 = 0;
            for (int i12 = 0; i12 < i7; i12++) {
                View view3 = this.f1853H[i12];
                r1(view3, 1073741824, true);
                int iE2 = this.f1866r.e(view3);
                if (iE2 > i10) {
                    i10 = iE2;
                }
            }
        }
        for (int i13 = 0; i13 < i7; i13++) {
            View view4 = this.f1853H[i13];
            if (this.f1866r.e(view4) != i10) {
                C0393y c0393y2 = (C0393y) view4.getLayoutParams();
                Rect rect2 = c0393y2.f4853b;
                int i14 = rect2.top + rect2.bottom + ((ViewGroup.MarginLayoutParams) c0393y2).topMargin + ((ViewGroup.MarginLayoutParams) c0393y2).bottomMargin;
                int i15 = rect2.left + rect2.right + ((ViewGroup.MarginLayoutParams) c0393y2).leftMargin + ((ViewGroup.MarginLayoutParams) c0393y2).rightMargin;
                int iN1 = n1(c0393y2.e, c0393y2.f5073f);
                if (this.f1864p == 1) {
                    iW2 = V.w(false, iN1, 1073741824, i15, ((ViewGroup.MarginLayoutParams) c0393y2).width);
                    iW = View.MeasureSpec.makeMeasureSpec(i10 - i14, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i10 - i15, 1073741824);
                    iW = V.w(false, iN1, 1073741824, i14, ((ViewGroup.MarginLayoutParams) c0393y2).height);
                    iW2 = iMakeMeasureSpec;
                }
                if (z0(view4, iW2, iW, (W) view4.getLayoutParams())) {
                    view4.measure(iW2, iW);
                }
            }
        }
        c0368b.f4784a = i10;
        if (this.f1864p != 1) {
            if (c0369c.f4792f == -1) {
                int i16 = c0369c.f4789b;
                iD = i16 - i10;
                iF = i16;
            } else {
                int i17 = c0369c.f4789b;
                iF = i17 + i10;
                iD = i17;
            }
            iF2 = 0;
            iF3 = 0;
        } else if (c0369c.f4792f == -1) {
            iF3 = c0369c.f4789b;
            iF2 = iF3 - i10;
            iD = 0;
            iF = 0;
        } else {
            int i18 = c0369c.f4789b;
            iF2 = i18;
            iF = 0;
            iF3 = i18 + i10;
            iD = 0;
        }
        for (int i19 = 0; i19 < i7; i19++) {
            View view5 = this.f1853H[i19];
            C0393y c0393y3 = (C0393y) view5.getLayoutParams();
            if (this.f1864p != 1) {
                iF2 = F() + this.f1852G[c0393y3.e];
                iF3 = this.f1866r.f(view5) + iF2;
            } else if (V0()) {
                int iD2 = D() + this.f1852G[this.F - c0393y3.e];
                iF = iD2;
                iD = iD2 - this.f1866r.f(view5);
            } else {
                iD = D() + this.f1852G[c0393y3.e];
                iF = this.f1866r.f(view5) + iD;
            }
            V.N(view5, iD, iF2, iF, iF3);
            if (c0393y3.f4852a.i() || c0393y3.f4852a.l()) {
                c0368b.f4786c = true;
            }
            c0368b.f4787d = view5.hasFocusable() | c0368b.f4787d;
        }
        Arrays.fill(this.f1853H, (Object) null);
    }

    @Override // p0.V
    public final void X(b0 b0Var, h0 h0Var, View view, g gVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0393y)) {
            W(view, gVar);
            return;
        }
        C0393y c0393y = (C0393y) layoutParams;
        int iO1 = o1(c0393y.f4852a.b(), b0Var, h0Var);
        if (this.f1864p == 0) {
            gVar.j(f.u(c0393y.e, c0393y.f5073f, iO1, 1, false, false));
        } else {
            gVar.j(f.u(iO1, 1, c0393y.e, c0393y.f5073f, false, false));
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void X0(b0 b0Var, h0 h0Var, C0367A c0367a, int i) {
        t1();
        if (h0Var.b() > 0 && !h0Var.f4914g) {
            boolean z2 = i == 1;
            int iP1 = p1(c0367a.f4781b, b0Var, h0Var);
            if (z2) {
                while (iP1 > 0) {
                    int i3 = c0367a.f4781b;
                    if (i3 <= 0) {
                        break;
                    }
                    int i4 = i3 - 1;
                    c0367a.f4781b = i4;
                    iP1 = p1(i4, b0Var, h0Var);
                }
            } else {
                int iB = h0Var.b() - 1;
                int i5 = c0367a.f4781b;
                while (i5 < iB) {
                    int i6 = i5 + 1;
                    int iP12 = p1(i6, b0Var, h0Var);
                    if (iP12 <= iP1) {
                        break;
                    }
                    i5 = i6;
                    iP1 = iP12;
                }
                c0367a.f4781b = i5;
            }
        }
        i1();
    }

    @Override // p0.V
    public final void Y(int i, int i3) {
        i iVar = this.K;
        iVar.A();
        ((SparseIntArray) iVar.f95d).clear();
    }

    @Override // p0.V
    public final void Z() {
        i iVar = this.K;
        iVar.A();
        ((SparseIntArray) iVar.f95d).clear();
    }

    @Override // p0.V
    public final void a0(int i, int i3) {
        i iVar = this.K;
        iVar.A();
        ((SparseIntArray) iVar.f95d).clear();
    }

    @Override // p0.V
    public final void b0(int i, int i3) {
        i iVar = this.K;
        iVar.A();
        ((SparseIntArray) iVar.f95d).clear();
    }

    @Override // p0.V
    public final void c0(int i, int i3) {
        i iVar = this.K;
        iVar.A();
        ((SparseIntArray) iVar.f95d).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final void d0(b0 b0Var, h0 h0Var) {
        boolean z2 = h0Var.f4914g;
        SparseIntArray sparseIntArray = this.f1855J;
        SparseIntArray sparseIntArray2 = this.f1854I;
        if (z2) {
            int iV = v();
            for (int i = 0; i < iV; i++) {
                C0393y c0393y = (C0393y) u(i).getLayoutParams();
                int iB = c0393y.f4852a.b();
                sparseIntArray2.put(iB, c0393y.f5073f);
                sparseIntArray.put(iB, c0393y.e);
            }
        }
        super.d0(b0Var, h0Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void d1(boolean z2) {
        if (z2) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.d1(false);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final void e0(h0 h0Var) {
        View viewQ;
        super.e0(h0Var);
        this.f1851E = false;
        int i = this.f1857M;
        if (i == -1 || (viewQ = q(i)) == null) {
            return;
        }
        viewQ.sendAccessibilityEvent(67108864);
        this.f1857M = -1;
    }

    @Override // p0.V
    public final boolean f(W w2) {
        return w2 instanceof C0393y;
    }

    public final void h1(int i) {
        int i3;
        int[] iArr = this.f1852G;
        int i4 = this.F;
        if (iArr == null || iArr.length != i4 + 1 || iArr[iArr.length - 1] != i) {
            iArr = new int[i4 + 1];
        }
        int i5 = 0;
        iArr[0] = 0;
        int i6 = i / i4;
        int i7 = i % i4;
        int i8 = 0;
        for (int i9 = 1; i9 <= i4; i9++) {
            i5 += i7;
            if (i5 <= 0 || i4 - i5 >= i7) {
                i3 = i6;
            } else {
                i3 = i6 + 1;
                i5 -= i4;
            }
            i8 += i3;
            iArr[i9] = i8;
        }
        this.f1852G = iArr;
    }

    /* JADX WARN: Removed duplicated region for block: B:122:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:125:0x01a8  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x01aa A[EDGE_INSN: B:215:0x01aa->B:126:0x01aa BREAK  A[LOOP:2: B:130:0x01ba->B:139:0x01e3, LOOP_LABEL: LOOP:2: B:130:0x01ba->B:139:0x01e3], EDGE_INSN: B:221:0x01aa->B:126:0x01aa BREAK  A[LOOP:5: B:152:0x0222->B:163:0x0252, LOOP_LABEL: LOOP:5: B:152:0x0222->B:163:0x0252]] */
    /* JADX WARN: Removed duplicated region for block: B:146:0x0214  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x027f  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean i0(int i, Bundle bundle) {
        View viewU;
        l0 l0VarL;
        int iIntValue;
        int i3;
        if (i != e.f993p.a() || i == -1) {
            if (i != 16908343 || bundle == null) {
                return super.i0(i, bundle);
            }
            int i4 = bundle.getInt("android.view.accessibility.action.ARGUMENT_ROW_INT", -1);
            int i5 = bundle.getInt("android.view.accessibility.action.ARGUMENT_COLUMN_INT", -1);
            if (i4 != -1 && i5 != -1) {
                int iA = this.f4840b.f1929n.a();
                int i6 = 0;
                while (true) {
                    if (i6 >= iA) {
                        i6 = -1;
                        break;
                    }
                    RecyclerView recyclerView = this.f4840b;
                    int iP1 = p1(i6, recyclerView.f1911d, recyclerView.f1919h0);
                    RecyclerView recyclerView2 = this.f4840b;
                    int iO1 = o1(i6, recyclerView2.f1911d, recyclerView2.f1919h0);
                    if (this.f1864p != 1) {
                        if (iP1 == i4 && iO1 == i5) {
                            break;
                        }
                        i6++;
                    } else {
                        if (iP1 == i5 && iO1 == i4) {
                            break;
                        }
                        i6++;
                    }
                }
                if (i6 > -1) {
                    this.f1872x = i6;
                    this.f1873y = 0;
                    D d3 = this.f1874z;
                    if (d3 != null) {
                        d3.f4798b = -1;
                    }
                    o0();
                    return true;
                }
            }
            return false;
        }
        int i7 = 0;
        while (true) {
            if (i7 >= v()) {
                viewU = null;
                break;
            }
            View viewU2 = u(i7);
            Objects.requireNonNull(viewU2);
            if (viewU2.isAccessibilityFocused()) {
                viewU = u(i7);
                break;
            }
            i7++;
        }
        if (viewU == null || bundle == null) {
            return false;
        }
        int i8 = bundle.getInt("android.view.accessibility.action.ARGUMENT_DIRECTION_INT", -1);
        if (!f1850P.contains(Integer.valueOf(i8)) || (l0VarL = this.f4840b.L(viewU)) == null) {
            return false;
        }
        RecyclerView recyclerView3 = l0VarL.f4961r;
        int iJ = recyclerView3 == null ? -1 : recyclerView3.J(l0VarL);
        int iK1 = k1(iJ);
        int iJ1 = j1(iJ);
        if (iK1 >= 0 && iJ1 >= 0) {
            if (!l1(iJ).contains(Integer.valueOf(this.f1858N)) || !m1(j1(iJ), iJ).contains(Integer.valueOf(this.f1859O))) {
                this.f1858N = iK1;
                this.f1859O = iJ1;
            }
            int i9 = this.f1858N;
            if (i9 == -1) {
                i9 = iK1;
            }
            int i10 = this.f1859O;
            if (i10 != -1) {
                iJ1 = i10;
            }
            if (i8 == 17) {
                iIntValue = iJ - 1;
                while (iIntValue >= 0) {
                    int iK12 = k1(iIntValue);
                    int iJ12 = j1(iIntValue);
                    if (iK12 < 0 || iJ12 < 0) {
                        break;
                    }
                    if (this.f1864p != 1) {
                        if (l1(iIntValue).contains(Integer.valueOf(i9)) && iJ12 < iJ1) {
                            this.f1859O = iJ12;
                            break;
                        }
                        iIntValue--;
                    } else {
                        if ((iK12 == i9 && iJ12 < iJ1) || iK12 < i9) {
                            this.f1858N = iK12;
                            this.f1859O = iJ12;
                            break;
                        }
                        iIntValue--;
                    }
                }
                iIntValue = -1;
                if (iIntValue == -1) {
                }
                if (iIntValue != -1) {
                }
            } else if (i8 == 33) {
                iIntValue = iJ - 1;
                while (iIntValue >= 0) {
                    int iK13 = k1(iIntValue);
                    int iJ13 = j1(iIntValue);
                    if (iK13 < 0 || iJ13 < 0) {
                        break;
                    }
                    if (this.f1864p != 1) {
                        if (iK13 < i9 && iJ13 == iJ1) {
                            this.f1858N = ((Integer) Collections.max(l1(iIntValue))).intValue();
                            break;
                        }
                        iIntValue--;
                    } else {
                        if (iK13 < i9 && m1(j1(iIntValue), iIntValue).contains(Integer.valueOf(iJ1))) {
                            this.f1858N = iK13;
                            break;
                        }
                        iIntValue--;
                    }
                }
                iIntValue = -1;
                if (iIntValue == -1) {
                }
                if (iIntValue != -1) {
                }
            } else if (i8 == 66) {
                iIntValue = iJ + 1;
                while (iIntValue < B()) {
                    int iK14 = k1(iIntValue);
                    int iJ14 = j1(iIntValue);
                    if (iK14 < 0 || iJ14 < 0) {
                        break;
                    }
                    if (this.f1864p != 1) {
                        if (iJ14 > iJ1 && l1(iIntValue).contains(Integer.valueOf(i9))) {
                            this.f1859O = iJ14;
                            break;
                        }
                        iIntValue++;
                    } else {
                        if ((iK14 == i9 && iJ14 > iJ1) || iK14 > i9) {
                            this.f1858N = iK14;
                            this.f1859O = iJ14;
                            break;
                        }
                        iIntValue++;
                    }
                }
                iIntValue = -1;
                if (iIntValue == -1) {
                    if (i8 != 17) {
                    }
                }
                if (iIntValue != -1) {
                }
            } else {
                if (i8 != 130) {
                    return false;
                }
                iIntValue = iJ + 1;
                while (iIntValue < B()) {
                    int iK15 = k1(iIntValue);
                    int iJ15 = j1(iIntValue);
                    if (iK15 < 0 || iJ15 < 0) {
                        break;
                    }
                    if (this.f1864p != 1) {
                        if (iK15 > i9 && iJ15 == iJ1) {
                            this.f1858N = k1(iIntValue);
                            break;
                        }
                        iIntValue++;
                    } else {
                        if (iK15 > i9 && (iJ15 == iJ1 || m1(j1(iIntValue), iIntValue).contains(Integer.valueOf(iJ1)))) {
                            this.f1858N = iK15;
                            break;
                        }
                        iIntValue++;
                    }
                }
                iIntValue = -1;
                if (iIntValue == -1 && (i3 = this.f1864p) == 0) {
                    if (i8 != 17) {
                        if (iK1 >= 0 && i3 != 1) {
                            TreeMap treeMap = new TreeMap(Collections.reverseOrder());
                            int i11 = 0;
                            loop2: while (true) {
                                if (i11 >= B()) {
                                    for (Integer num : treeMap.keySet()) {
                                        int iIntValue2 = num.intValue();
                                        if (iIntValue2 < iK1) {
                                            iIntValue = ((Integer) treeMap.get(num)).intValue();
                                            this.f1858N = iIntValue2;
                                            this.f1859O = j1(iIntValue);
                                            break;
                                        }
                                    }
                                } else {
                                    Iterator it = l1(i11).iterator();
                                    while (it.hasNext()) {
                                        Integer num2 = (Integer) it.next();
                                        if (num2.intValue() < 0) {
                                            break loop2;
                                        }
                                        treeMap.put(num2, Integer.valueOf(i11));
                                    }
                                    i11++;
                                }
                            }
                            iIntValue = -1;
                        } else {
                            iIntValue = -1;
                        }
                    } else if (i8 == 66) {
                        if (iK1 >= 0 && i3 != 1) {
                            TreeMap treeMap2 = new TreeMap();
                            int i12 = 0;
                            loop5: while (true) {
                                if (i12 >= B()) {
                                    for (Integer num3 : treeMap2.keySet()) {
                                        int iIntValue3 = num3.intValue();
                                        if (iIntValue3 > iK1) {
                                            iIntValue = ((Integer) treeMap2.get(num3)).intValue();
                                            this.f1858N = iIntValue3;
                                            this.f1859O = 0;
                                            break;
                                        }
                                    }
                                } else {
                                    Iterator it2 = l1(i12).iterator();
                                    while (it2.hasNext()) {
                                        Integer num4 = (Integer) it2.next();
                                        if (num4.intValue() < 0) {
                                            break loop5;
                                        }
                                        if (!treeMap2.containsKey(num4)) {
                                            treeMap2.put(num4, Integer.valueOf(i12));
                                        }
                                    }
                                    i12++;
                                }
                            }
                            iIntValue = -1;
                        }
                    }
                }
                if (iIntValue != -1) {
                    q0(iIntValue);
                    this.f1857M = iIntValue;
                    return true;
                }
            }
        }
        return false;
    }

    public final void i1() {
        View[] viewArr = this.f1853H;
        if (viewArr == null || viewArr.length != this.F) {
            this.f1853H = new View[this.F];
        }
    }

    public final int j1(int i) {
        if (this.f1864p == 0) {
            RecyclerView recyclerView = this.f4840b;
            return o1(i, recyclerView.f1911d, recyclerView.f1919h0);
        }
        RecyclerView recyclerView2 = this.f4840b;
        return p1(i, recyclerView2.f1911d, recyclerView2.f1919h0);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int k(h0 h0Var) {
        return G0(h0Var);
    }

    public final int k1(int i) {
        if (this.f1864p == 1) {
            RecyclerView recyclerView = this.f4840b;
            return o1(i, recyclerView.f1911d, recyclerView.f1919h0);
        }
        RecyclerView recyclerView2 = this.f4840b;
        return p1(i, recyclerView2.f1911d, recyclerView2.f1919h0);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int l(h0 h0Var) {
        return H0(h0Var);
    }

    public final HashSet l1(int i) {
        return m1(k1(i), i);
    }

    public final HashSet m1(int i, int i3) {
        HashSet hashSet = new HashSet();
        RecyclerView recyclerView = this.f4840b;
        int iQ1 = q1(i3, recyclerView.f1911d, recyclerView.f1919h0);
        for (int i4 = i; i4 < i + iQ1; i4++) {
            hashSet.add(Integer.valueOf(i4));
        }
        return hashSet;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int n(h0 h0Var) {
        return G0(h0Var);
    }

    public final int n1(int i, int i3) {
        if (this.f1864p != 1 || !V0()) {
            int[] iArr = this.f1852G;
            return iArr[i3 + i] - iArr[i];
        }
        int[] iArr2 = this.f1852G;
        int i4 = this.F;
        return iArr2[i4 - i] - iArr2[(i4 - i) - i3];
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int o(h0 h0Var) {
        return H0(h0Var);
    }

    public final int o1(int i, b0 b0Var, h0 h0Var) {
        boolean z2 = h0Var.f4914g;
        i iVar = this.K;
        if (!z2) {
            int i3 = this.F;
            iVar.getClass();
            return i.z(i, i3);
        }
        int iB = b0Var.b(i);
        if (iB != -1) {
            int i4 = this.F;
            iVar.getClass();
            return i.z(iB, i4);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int p0(int i, b0 b0Var, h0 h0Var) {
        t1();
        i1();
        return super.p0(i, b0Var, h0Var);
    }

    public final int p1(int i, b0 b0Var, h0 h0Var) {
        boolean z2 = h0Var.f4914g;
        i iVar = this.K;
        if (!z2) {
            int i3 = this.F;
            iVar.getClass();
            return i % i3;
        }
        int i4 = this.f1855J.get(i, -1);
        if (i4 != -1) {
            return i4;
        }
        int iB = b0Var.b(i);
        if (iB != -1) {
            int i5 = this.F;
            iVar.getClass();
            return iB % i5;
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 0;
    }

    public final int q1(int i, b0 b0Var, h0 h0Var) {
        boolean z2 = h0Var.f4914g;
        i iVar = this.K;
        if (!z2) {
            iVar.getClass();
            return 1;
        }
        int i3 = this.f1854I.get(i, -1);
        if (i3 != -1) {
            return i3;
        }
        if (b0Var.b(i) != -1) {
            iVar.getClass();
            return 1;
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final W r() {
        return this.f1864p == 0 ? new C0393y(-2, -1) : new C0393y(-1, -2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, p0.V
    public final int r0(int i, b0 b0Var, h0 h0Var) {
        t1();
        i1();
        return super.r0(i, b0Var, h0Var);
    }

    public final void r1(View view, int i, boolean z2) {
        int iW;
        int iW2;
        C0393y c0393y = (C0393y) view.getLayoutParams();
        Rect rect = c0393y.f4853b;
        int i3 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) c0393y).topMargin + ((ViewGroup.MarginLayoutParams) c0393y).bottomMargin;
        int i4 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) c0393y).leftMargin + ((ViewGroup.MarginLayoutParams) c0393y).rightMargin;
        int iN1 = n1(c0393y.e, c0393y.f5073f);
        if (this.f1864p == 1) {
            iW2 = V.w(false, iN1, i, i4, ((ViewGroup.MarginLayoutParams) c0393y).width);
            iW = V.w(true, this.f1866r.n(), this.f4849m, i3, ((ViewGroup.MarginLayoutParams) c0393y).height);
        } else {
            int iW3 = V.w(false, iN1, i, i3, ((ViewGroup.MarginLayoutParams) c0393y).height);
            int iW4 = V.w(true, this.f1866r.n(), this.f4848l, i4, ((ViewGroup.MarginLayoutParams) c0393y).width);
            iW = iW3;
            iW2 = iW4;
        }
        W w2 = (W) view.getLayoutParams();
        if (z2 ? z0(view, iW2, iW, w2) : x0(view, iW2, iW, w2)) {
            view.measure(iW2, iW);
        }
    }

    @Override // p0.V
    public final W s(Context context, AttributeSet attributeSet) {
        C0393y c0393y = new C0393y(context, attributeSet);
        c0393y.e = -1;
        c0393y.f5073f = 0;
        return c0393y;
    }

    public final void s1(int i) {
        if (i == this.F) {
            return;
        }
        this.f1851E = true;
        if (i < 1) {
            throw new IllegalArgumentException(H.e.g("Span count should be at least 1. Provided ", i));
        }
        this.F = i;
        this.K.A();
        o0();
    }

    @Override // p0.V
    public final W t(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            C0393y c0393y = new C0393y((ViewGroup.MarginLayoutParams) layoutParams);
            c0393y.e = -1;
            c0393y.f5073f = 0;
            return c0393y;
        }
        C0393y c0393y2 = new C0393y(layoutParams);
        c0393y2.e = -1;
        c0393y2.f5073f = 0;
        return c0393y2;
    }

    public final void t1() {
        int iC;
        int iF;
        if (this.f1864p == 1) {
            iC = this.f4850n - E();
            iF = D();
        } else {
            iC = this.f4851o - C();
            iF = F();
        }
        h1(iC - iF);
    }

    @Override // p0.V
    public final void u0(Rect rect, int i, int i3) {
        int iG;
        int iG2;
        if (this.f1852G == null) {
            super.u0(rect, i, i3);
        }
        int iE = E() + D();
        int iC = C() + F();
        if (this.f1864p == 1) {
            int iHeight = rect.height() + iC;
            RecyclerView recyclerView = this.f4840b;
            WeakHashMap weakHashMap = O.f854a;
            iG2 = V.g(i3, iHeight, recyclerView.getMinimumHeight());
            int[] iArr = this.f1852G;
            iG = V.g(i, iArr[iArr.length - 1] + iE, this.f4840b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iE;
            RecyclerView recyclerView2 = this.f4840b;
            WeakHashMap weakHashMap2 = O.f854a;
            iG = V.g(i, iWidth, recyclerView2.getMinimumWidth());
            int[] iArr2 = this.f1852G;
            iG2 = V.g(i3, iArr2[iArr2.length - 1] + iC, this.f4840b.getMinimumHeight());
        }
        this.f4840b.setMeasuredDimension(iG, iG2);
    }

    @Override // p0.V
    public final int x(b0 b0Var, h0 h0Var) {
        if (this.f1864p == 1) {
            return Math.min(this.F, B());
        }
        if (h0Var.b() < 1) {
            return 0;
        }
        return o1(h0Var.b() - 1, b0Var, h0Var) + 1;
    }

    public GridLayoutManager(int i) {
        super(1);
        this.f1851E = false;
        this.F = -1;
        this.f1854I = new SparseIntArray();
        this.f1855J = new SparseIntArray();
        this.K = new i(17);
        this.f1856L = new Rect();
        this.f1857M = -1;
        this.f1858N = -1;
        this.f1859O = -1;
        s1(i);
    }

    public GridLayoutManager() {
        super(1);
        this.f1851E = false;
        this.F = -1;
        this.f1854I = new SparseIntArray();
        this.f1855J = new SparseIntArray();
        this.K = new i(17);
        this.f1856L = new Rect();
        this.f1857M = -1;
        this.f1858N = -1;
        this.f1859O = -1;
        s1(3);
    }
}
