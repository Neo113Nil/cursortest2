package androidx.recyclerview.widget;

import A.i;
import K0.h;
import N0.f;
import P.O;
import Y.g;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;
import p0.AbstractC0371b;
import p0.C0394z;
import p0.E;
import p0.U;
import p0.V;
import p0.W;
import p0.b0;
import p0.g0;
import p0.h0;
import p0.o0;
import p0.p0;
import p0.q0;
import p0.r0;
import p0.s0;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends V implements g0 {

    /* renamed from: B, reason: collision with root package name */
    public final i f1956B;

    /* renamed from: C, reason: collision with root package name */
    public final int f1957C;

    /* renamed from: D, reason: collision with root package name */
    public boolean f1958D;

    /* renamed from: E, reason: collision with root package name */
    public boolean f1959E;
    public r0 F;

    /* renamed from: G, reason: collision with root package name */
    public final Rect f1960G;

    /* renamed from: H, reason: collision with root package name */
    public final o0 f1961H;

    /* renamed from: I, reason: collision with root package name */
    public final boolean f1962I;

    /* renamed from: J, reason: collision with root package name */
    public int[] f1963J;
    public final f K;

    /* renamed from: p, reason: collision with root package name */
    public final int f1964p;

    /* renamed from: q, reason: collision with root package name */
    public final s0[] f1965q;

    /* renamed from: r, reason: collision with root package name */
    public final g f1966r;

    /* renamed from: s, reason: collision with root package name */
    public final g f1967s;

    /* renamed from: t, reason: collision with root package name */
    public final int f1968t;

    /* renamed from: u, reason: collision with root package name */
    public int f1969u;

    /* renamed from: v, reason: collision with root package name */
    public final C0394z f1970v;

    /* renamed from: w, reason: collision with root package name */
    public boolean f1971w;

    /* renamed from: y, reason: collision with root package name */
    public final BitSet f1973y;

    /* renamed from: x, reason: collision with root package name */
    public boolean f1972x = false;

    /* renamed from: z, reason: collision with root package name */
    public int f1974z = -1;

    /* renamed from: A, reason: collision with root package name */
    public int f1955A = Integer.MIN_VALUE;

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i3) {
        this.f1964p = -1;
        this.f1971w = false;
        i iVar = new i(18, false);
        this.f1956B = iVar;
        this.f1957C = 2;
        this.f1960G = new Rect();
        this.f1961H = new o0(this);
        this.f1962I = true;
        this.K = new f(14, this);
        U uH = V.H(context, attributeSet, i, i3);
        int i4 = uH.f4835a;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        c(null);
        if (i4 != this.f1968t) {
            this.f1968t = i4;
            g gVar = this.f1966r;
            this.f1966r = this.f1967s;
            this.f1967s = gVar;
            o0();
        }
        int i5 = uH.f4836b;
        c(null);
        if (i5 != this.f1964p) {
            iVar.f();
            o0();
            this.f1964p = i5;
            this.f1973y = new BitSet(this.f1964p);
            this.f1965q = new s0[this.f1964p];
            for (int i6 = 0; i6 < this.f1964p; i6++) {
                this.f1965q[i6] = new s0(this, i6);
            }
            o0();
        }
        boolean z2 = uH.f4837c;
        c(null);
        r0 r0Var = this.F;
        if (r0Var != null && r0Var.i != z2) {
            r0Var.i = z2;
        }
        this.f1971w = z2;
        o0();
        C0394z c0394z = new C0394z();
        c0394z.f5074a = true;
        c0394z.f5078f = 0;
        c0394z.f5079g = 0;
        this.f1970v = c0394z;
        this.f1966r = g.b(this, this.f1968t);
        this.f1967s = g.b(this, 1 - this.f1968t);
    }

    public static int g1(int i, int i3, int i4) {
        if (i3 == 0 && i4 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i3) - i4), mode) : i;
    }

    @Override // p0.V
    public final void A0(RecyclerView recyclerView, int i) {
        E e = new E(recyclerView.getContext());
        e.f4801a = i;
        B0(e);
    }

    @Override // p0.V
    public final boolean C0() {
        return this.F == null;
    }

    public final int D0(int i) {
        if (v() == 0) {
            return this.f1972x ? 1 : -1;
        }
        return (i < N0()) != this.f1972x ? -1 : 1;
    }

    public final boolean E0() {
        int iN0;
        if (v() != 0 && this.f1957C != 0 && this.f4844g) {
            if (this.f1972x) {
                iN0 = O0();
                N0();
            } else {
                iN0 = N0();
                O0();
            }
            i iVar = this.f1956B;
            if (iN0 == 0 && S0() != null) {
                iVar.f();
                this.f4843f = true;
                o0();
                return true;
            }
        }
        return false;
    }

    public final int F0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        g gVar = this.f1966r;
        boolean z2 = !this.f1962I;
        return AbstractC0371b.c(h0Var, gVar, K0(z2), J0(z2), this, this.f1962I);
    }

    public final int G0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        g gVar = this.f1966r;
        boolean z2 = !this.f1962I;
        return AbstractC0371b.d(h0Var, gVar, K0(z2), J0(z2), this, this.f1962I, this.f1972x);
    }

    public final int H0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        g gVar = this.f1966r;
        boolean z2 = !this.f1962I;
        return AbstractC0371b.e(h0Var, gVar, K0(z2), J0(z2), this, this.f1962I);
    }

    @Override // p0.V
    public final int I(b0 b0Var, h0 h0Var) {
        if (this.f1968t == 0) {
            return Math.min(this.f1964p, h0Var.b());
        }
        return -1;
    }

    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4, types: [boolean, int] */
    public final int I0(b0 b0Var, C0394z c0394z, h0 h0Var) {
        s0 s0Var;
        ?? r6;
        int i;
        int i3;
        int iE;
        int iM;
        int iE2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8 = 0;
        int i9 = 1;
        this.f1973y.set(0, this.f1964p, true);
        C0394z c0394z2 = this.f1970v;
        int i10 = c0394z2.i ? c0394z.e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE : c0394z.e == 1 ? c0394z.f5079g + c0394z.f5075b : c0394z.f5078f - c0394z.f5075b;
        int i11 = c0394z.e;
        for (int i12 = 0; i12 < this.f1964p; i12++) {
            if (!((ArrayList) this.f1965q[i12].f5023f).isEmpty()) {
                f1(this.f1965q[i12], i11, i10);
            }
        }
        int i13 = this.f1972x ? this.f1966r.i() : this.f1966r.m();
        boolean z2 = false;
        while (true) {
            int i14 = c0394z.f5076c;
            if (((i14 < 0 || i14 >= h0Var.b()) ? i8 : i9) == 0 || (!c0394z2.i && this.f1973y.isEmpty())) {
                break;
            }
            View view = b0Var.k(c0394z.f5076c, Long.MAX_VALUE).f4946a;
            c0394z.f5076c += c0394z.f5077d;
            p0 p0Var = (p0) view.getLayoutParams();
            int iB = p0Var.f4852a.b();
            i iVar = this.f1956B;
            int[] iArr = (int[]) iVar.f94c;
            int i15 = (iArr == null || iB >= iArr.length) ? -1 : iArr[iB];
            if (i15 == -1) {
                if (W0(c0394z.e)) {
                    i7 = this.f1964p - i9;
                    i6 = -1;
                    i5 = -1;
                } else {
                    i5 = i9;
                    i6 = this.f1964p;
                    i7 = i8;
                }
                s0 s0Var2 = null;
                if (c0394z.e == i9) {
                    int iM2 = this.f1966r.m();
                    int i16 = Integer.MAX_VALUE;
                    while (i7 != i6) {
                        s0 s0Var3 = this.f1965q[i7];
                        int iG = s0Var3.g(iM2);
                        if (iG < i16) {
                            i16 = iG;
                            s0Var2 = s0Var3;
                        }
                        i7 += i5;
                    }
                } else {
                    int i17 = this.f1966r.i();
                    int i18 = Integer.MIN_VALUE;
                    while (i7 != i6) {
                        s0 s0Var4 = this.f1965q[i7];
                        int i19 = s0Var4.i(i17);
                        if (i19 > i18) {
                            s0Var2 = s0Var4;
                            i18 = i19;
                        }
                        i7 += i5;
                    }
                }
                s0Var = s0Var2;
                iVar.w(iB);
                ((int[]) iVar.f94c)[iB] = s0Var.e;
            } else {
                s0Var = this.f1965q[i15];
            }
            p0Var.e = s0Var;
            if (c0394z.e == 1) {
                r6 = 0;
                b(view, -1, false);
            } else {
                r6 = 0;
                b(view, 0, false);
            }
            if (this.f1968t == 1) {
                i = 1;
                U0(view, V.w(r6, this.f1969u, this.f4848l, r6, ((ViewGroup.MarginLayoutParams) p0Var).width), V.w(true, this.f4851o, this.f4849m, C() + F(), ((ViewGroup.MarginLayoutParams) p0Var).height));
            } else {
                i = 1;
                U0(view, V.w(true, this.f4850n, this.f4848l, E() + D(), ((ViewGroup.MarginLayoutParams) p0Var).width), V.w(false, this.f1969u, this.f4849m, 0, ((ViewGroup.MarginLayoutParams) p0Var).height));
            }
            if (c0394z.e == i) {
                iE = s0Var.g(i13);
                i3 = this.f1966r.e(view) + iE;
            } else {
                i3 = s0Var.i(i13);
                iE = i3 - this.f1966r.e(view);
            }
            if (c0394z.e == 1) {
                s0 s0Var5 = p0Var.e;
                s0Var5.getClass();
                p0 p0Var2 = (p0) view.getLayoutParams();
                p0Var2.e = s0Var5;
                ArrayList arrayList = (ArrayList) s0Var5.f5023f;
                arrayList.add(view);
                s0Var5.f5021c = Integer.MIN_VALUE;
                if (arrayList.size() == 1) {
                    s0Var5.f5020b = Integer.MIN_VALUE;
                }
                if (p0Var2.f4852a.i() || p0Var2.f4852a.l()) {
                    s0Var5.f5022d = ((StaggeredGridLayoutManager) s0Var5.f5024g).f1966r.e(view) + s0Var5.f5022d;
                }
            } else {
                s0 s0Var6 = p0Var.e;
                s0Var6.getClass();
                p0 p0Var3 = (p0) view.getLayoutParams();
                p0Var3.e = s0Var6;
                ArrayList arrayList2 = (ArrayList) s0Var6.f5023f;
                arrayList2.add(0, view);
                s0Var6.f5020b = Integer.MIN_VALUE;
                if (arrayList2.size() == 1) {
                    s0Var6.f5021c = Integer.MIN_VALUE;
                }
                if (p0Var3.f4852a.i() || p0Var3.f4852a.l()) {
                    s0Var6.f5022d = ((StaggeredGridLayoutManager) s0Var6.f5024g).f1966r.e(view) + s0Var6.f5022d;
                }
            }
            if (T0() && this.f1968t == 1) {
                iE2 = this.f1967s.i() - (((this.f1964p - 1) - s0Var.e) * this.f1969u);
                iM = iE2 - this.f1967s.e(view);
            } else {
                iM = this.f1967s.m() + (s0Var.e * this.f1969u);
                iE2 = this.f1967s.e(view) + iM;
            }
            if (this.f1968t == 1) {
                V.N(view, iM, iE, iE2, i3);
            } else {
                V.N(view, iE, iM, i3, iE2);
            }
            f1(s0Var, c0394z2.e, i10);
            Y0(b0Var, c0394z2);
            if (c0394z2.f5080h && view.hasFocusable()) {
                i4 = 0;
                this.f1973y.set(s0Var.e, false);
            } else {
                i4 = 0;
            }
            i8 = i4;
            i9 = 1;
            z2 = true;
        }
        int i20 = i8;
        if (!z2) {
            Y0(b0Var, c0394z2);
        }
        int iM3 = c0394z2.e == -1 ? this.f1966r.m() - Q0(this.f1966r.m()) : P0(this.f1966r.i()) - this.f1966r.i();
        return iM3 > 0 ? Math.min(c0394z.f5075b, iM3) : i20;
    }

    public final View J0(boolean z2) {
        int iM = this.f1966r.m();
        int i = this.f1966r.i();
        View view = null;
        for (int iV = v() - 1; iV >= 0; iV--) {
            View viewU = u(iV);
            int iG = this.f1966r.g(viewU);
            int iD = this.f1966r.d(viewU);
            if (iD > iM && iG < i) {
                if (iD <= i || !z2) {
                    return viewU;
                }
                if (view == null) {
                    view = viewU;
                }
            }
        }
        return view;
    }

    @Override // p0.V
    public final boolean K() {
        return this.f1957C != 0;
    }

    public final View K0(boolean z2) {
        int iM = this.f1966r.m();
        int i = this.f1966r.i();
        int iV = v();
        View view = null;
        for (int i3 = 0; i3 < iV; i3++) {
            View viewU = u(i3);
            int iG = this.f1966r.g(viewU);
            if (this.f1966r.d(viewU) > iM && iG < i) {
                if (iG >= iM || !z2) {
                    return viewU;
                }
                if (view == null) {
                    view = viewU;
                }
            }
        }
        return view;
    }

    @Override // p0.V
    public final boolean L() {
        return this.f1971w;
    }

    public final void L0(b0 b0Var, h0 h0Var, boolean z2) {
        int i;
        int iP0 = P0(Integer.MIN_VALUE);
        if (iP0 != Integer.MIN_VALUE && (i = this.f1966r.i() - iP0) > 0) {
            int i3 = i - (-c1(-i, b0Var, h0Var));
            if (!z2 || i3 <= 0) {
                return;
            }
            this.f1966r.r(i3);
        }
    }

    public final void M0(b0 b0Var, h0 h0Var, boolean z2) {
        int iM;
        int iQ0 = Q0(Integer.MAX_VALUE);
        if (iQ0 != Integer.MAX_VALUE && (iM = iQ0 - this.f1966r.m()) > 0) {
            int iC1 = iM - c1(iM, b0Var, h0Var);
            if (!z2 || iC1 <= 0) {
                return;
            }
            this.f1966r.r(-iC1);
        }
    }

    public final int N0() {
        if (v() == 0) {
            return 0;
        }
        return V.G(u(0));
    }

    @Override // p0.V
    public final void O(int i) {
        super.O(i);
        for (int i3 = 0; i3 < this.f1964p; i3++) {
            s0 s0Var = this.f1965q[i3];
            int i4 = s0Var.f5020b;
            if (i4 != Integer.MIN_VALUE) {
                s0Var.f5020b = i4 + i;
            }
            int i5 = s0Var.f5021c;
            if (i5 != Integer.MIN_VALUE) {
                s0Var.f5021c = i5 + i;
            }
        }
    }

    public final int O0() {
        int iV = v();
        if (iV == 0) {
            return 0;
        }
        return V.G(u(iV - 1));
    }

    @Override // p0.V
    public final void P(int i) {
        super.P(i);
        for (int i3 = 0; i3 < this.f1964p; i3++) {
            s0 s0Var = this.f1965q[i3];
            int i4 = s0Var.f5020b;
            if (i4 != Integer.MIN_VALUE) {
                s0Var.f5020b = i4 + i;
            }
            int i5 = s0Var.f5021c;
            if (i5 != Integer.MIN_VALUE) {
                s0Var.f5021c = i5 + i;
            }
        }
    }

    public final int P0(int i) {
        int iG = this.f1965q[0].g(i);
        for (int i3 = 1; i3 < this.f1964p; i3++) {
            int iG2 = this.f1965q[i3].g(i);
            if (iG2 > iG) {
                iG = iG2;
            }
        }
        return iG;
    }

    @Override // p0.V
    public final void Q() {
        this.f1956B.f();
        for (int i = 0; i < this.f1964p; i++) {
            this.f1965q[i].b();
        }
    }

    public final int Q0(int i) {
        int i3 = this.f1965q[0].i(i);
        for (int i4 = 1; i4 < this.f1964p; i4++) {
            int i5 = this.f1965q[i4].i(i);
            if (i5 < i3) {
                i3 = i5;
            }
        }
        return i3;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00c7  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00cc A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00cd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void R0(int i, int i3, int i4) {
        int i5;
        int i6;
        i iVar;
        int[] iArr;
        ArrayList arrayList;
        int i7;
        int iO0 = this.f1972x ? O0() : N0();
        if (i4 != 8) {
            i5 = i + i3;
        } else {
            if (i >= i3) {
                i5 = i + 1;
                i6 = i3;
                iVar = this.f1956B;
                iArr = (int[]) iVar.f94c;
                if (iArr != null && i6 < iArr.length) {
                    arrayList = (ArrayList) iVar.f95d;
                    if (arrayList != null) {
                        i7 = -1;
                        if (i7 != -1) {
                            int[] iArr2 = (int[]) iVar.f94c;
                            Arrays.fill(iArr2, i6, iArr2.length, -1);
                            int length = ((int[]) iVar.f94c).length;
                        } else {
                            Arrays.fill((int[]) iVar.f94c, i6, Math.min(i7 + 1, ((int[]) iVar.f94c).length), -1);
                        }
                    } else {
                        q0 q0Var = null;
                        if (arrayList != null) {
                            int size = arrayList.size() - 1;
                            while (true) {
                                if (size < 0) {
                                    break;
                                }
                                q0 q0Var2 = (q0) ((ArrayList) iVar.f95d).get(size);
                                if (q0Var2.f5000b == i6) {
                                    q0Var = q0Var2;
                                    break;
                                }
                                size--;
                            }
                        }
                        if (q0Var != null) {
                            ((ArrayList) iVar.f95d).remove(q0Var);
                        }
                        int size2 = ((ArrayList) iVar.f95d).size();
                        int i8 = 0;
                        while (true) {
                            if (i8 >= size2) {
                                i8 = -1;
                                break;
                            } else if (((q0) ((ArrayList) iVar.f95d).get(i8)).f5000b >= i6) {
                                break;
                            } else {
                                i8++;
                            }
                        }
                        if (i8 != -1) {
                            q0 q0Var3 = (q0) ((ArrayList) iVar.f95d).get(i8);
                            ((ArrayList) iVar.f95d).remove(i8);
                            i7 = q0Var3.f5000b;
                        }
                        if (i7 != -1) {
                        }
                    }
                }
                if (i4 != 1) {
                    iVar.E(i, i3);
                } else if (i4 == 2) {
                    iVar.F(i, i3);
                } else if (i4 == 8) {
                    iVar.F(i, 1);
                    iVar.E(i3, 1);
                }
                if (i5 > iO0) {
                    return;
                }
                if (i6 <= (this.f1972x ? N0() : O0())) {
                    o0();
                    return;
                }
                return;
            }
            i5 = i3 + 1;
        }
        i6 = i;
        iVar = this.f1956B;
        iArr = (int[]) iVar.f94c;
        if (iArr != null) {
            arrayList = (ArrayList) iVar.f95d;
            if (arrayList != null) {
            }
        }
        if (i4 != 1) {
        }
        if (i5 > iO0) {
        }
    }

    @Override // p0.V
    public final void S(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f4840b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.K);
        }
        for (int i = 0; i < this.f1964p; i++) {
            this.f1965q[i].b();
        }
        recyclerView.requestLayout();
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ff  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0102  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0107 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x002c A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View S0() {
        int iV = v();
        int i = iV - 1;
        BitSet bitSet = new BitSet(this.f1964p);
        bitSet.set(0, this.f1964p, true);
        char c3 = (this.f1968t == 1 && T0()) ? (char) 1 : (char) 65535;
        if (this.f1972x) {
            iV = -1;
        } else {
            i = 0;
        }
        int i3 = i < iV ? 1 : -1;
        while (i != iV) {
            View viewU = u(i);
            p0 p0Var = (p0) viewU.getLayoutParams();
            if (bitSet.get(p0Var.e.e)) {
                s0 s0Var = p0Var.e;
                if (this.f1972x) {
                    int i4 = s0Var.f5021c;
                    if (i4 == Integer.MIN_VALUE) {
                        s0Var.a();
                        i4 = s0Var.f5021c;
                    }
                    if (i4 < this.f1966r.i()) {
                        ArrayList arrayList = (ArrayList) s0Var.f5023f;
                        ((p0) ((View) arrayList.get(arrayList.size() - 1)).getLayoutParams()).getClass();
                        return viewU;
                    }
                    bitSet.clear(p0Var.e.e);
                } else {
                    int i5 = s0Var.f5020b;
                    if (i5 == Integer.MIN_VALUE) {
                        View view = (View) ((ArrayList) s0Var.f5023f).get(0);
                        p0 p0Var2 = (p0) view.getLayoutParams();
                        s0Var.f5020b = ((StaggeredGridLayoutManager) s0Var.f5024g).f1966r.g(view);
                        p0Var2.getClass();
                        i5 = s0Var.f5020b;
                    }
                    if (i5 > this.f1966r.m()) {
                        ((p0) ((View) ((ArrayList) s0Var.f5023f).get(0)).getLayoutParams()).getClass();
                        return viewU;
                    }
                    bitSet.clear(p0Var.e.e);
                }
            }
            i += i3;
            if (i != iV) {
                View viewU2 = u(i);
                if (this.f1972x) {
                    int iD = this.f1966r.d(viewU);
                    int iD2 = this.f1966r.d(viewU2);
                    if (iD < iD2) {
                        return viewU;
                    }
                    if (iD == iD2) {
                        if ((p0Var.e.e - ((p0) viewU2.getLayoutParams()).e.e >= 0) == (c3 >= 0)) {
                            return viewU;
                        }
                    } else {
                        continue;
                    }
                } else {
                    int iG = this.f1966r.g(viewU);
                    int iG2 = this.f1966r.g(viewU2);
                    if (iG > iG2) {
                        return viewU;
                    }
                    if (iG == iG2) {
                        if ((p0Var.e.e - ((p0) viewU2.getLayoutParams()).e.e >= 0) == (c3 >= 0)) {
                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0061  */
    @Override // p0.V
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View T(View view, int i, b0 b0Var, h0 h0Var) {
        View viewD;
        int i3;
        if (v() == 0) {
            return null;
        }
        RecyclerView recyclerView = this.f4840b;
        if (recyclerView == null || (viewD = recyclerView.D(view)) == null || this.f4839a.f4904c.contains(viewD)) {
            viewD = null;
        }
        if (viewD == null) {
            return null;
        }
        b1();
        if (i != 1) {
            if (i != 2) {
                if (i != 17) {
                    if (i != 33) {
                        if (i == 66 ? this.f1968t == 0 : !(i != 130 || this.f1968t != 1)) {
                            i3 = 1;
                        }
                    } else if (this.f1968t == 1) {
                        i3 = -1;
                    }
                    i3 = Integer.MIN_VALUE;
                } else if (this.f1968t != 0) {
                    i3 = Integer.MIN_VALUE;
                }
            } else if (this.f1968t != 1 && T0()) {
            }
        } else if (this.f1968t != 1 && T0()) {
        }
        if (i3 == Integer.MIN_VALUE) {
            return null;
        }
        p0 p0Var = (p0) viewD.getLayoutParams();
        p0Var.getClass();
        s0 s0Var = p0Var.e;
        int iO0 = i3 == 1 ? O0() : N0();
        e1(iO0, h0Var);
        d1(i3);
        C0394z c0394z = this.f1970v;
        c0394z.f5076c = c0394z.f5077d + iO0;
        c0394z.f5075b = (int) (this.f1966r.n() * 0.33333334f);
        c0394z.f5080h = true;
        c0394z.f5074a = false;
        I0(b0Var, c0394z, h0Var);
        this.f1958D = this.f1972x;
        View viewH = s0Var.h(iO0, i3);
        if (viewH != null && viewH != viewD) {
            return viewH;
        }
        if (W0(i3)) {
            for (int i4 = this.f1964p - 1; i4 >= 0; i4--) {
                View viewH2 = this.f1965q[i4].h(iO0, i3);
                if (viewH2 != null && viewH2 != viewD) {
                    return viewH2;
                }
            }
        } else {
            for (int i5 = 0; i5 < this.f1964p; i5++) {
                View viewH3 = this.f1965q[i5].h(iO0, i3);
                if (viewH3 != null && viewH3 != viewD) {
                    return viewH3;
                }
            }
        }
        boolean z2 = (this.f1971w ^ true) == (i3 == -1);
        View viewQ = q(z2 ? s0Var.c() : s0Var.d());
        if (viewQ != null && viewQ != viewD) {
            return viewQ;
        }
        if (W0(i3)) {
            for (int i6 = this.f1964p - 1; i6 >= 0; i6--) {
                if (i6 != s0Var.e) {
                    View viewQ2 = q(z2 ? this.f1965q[i6].c() : this.f1965q[i6].d());
                    if (viewQ2 != null && viewQ2 != viewD) {
                        return viewQ2;
                    }
                }
            }
        } else {
            for (int i7 = 0; i7 < this.f1964p; i7++) {
                View viewQ3 = q(z2 ? this.f1965q[i7].c() : this.f1965q[i7].d());
                if (viewQ3 != null && viewQ3 != viewD) {
                    return viewQ3;
                }
            }
        }
        return null;
    }

    public final boolean T0() {
        return this.f4840b.getLayoutDirection() == 1;
    }

    @Override // p0.V
    public final void U(AccessibilityEvent accessibilityEvent) {
        super.U(accessibilityEvent);
        if (v() > 0) {
            View viewK0 = K0(false);
            View viewJ0 = J0(false);
            if (viewK0 == null || viewJ0 == null) {
                return;
            }
            int iG = V.G(viewK0);
            int iG2 = V.G(viewJ0);
            if (iG < iG2) {
                accessibilityEvent.setFromIndex(iG);
                accessibilityEvent.setToIndex(iG2);
            } else {
                accessibilityEvent.setFromIndex(iG2);
                accessibilityEvent.setToIndex(iG);
            }
        }
    }

    public final void U0(View view, int i, int i3) {
        RecyclerView recyclerView = this.f4840b;
        Rect rect = this.f1960G;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.N(view));
        }
        p0 p0Var = (p0) view.getLayoutParams();
        int iG1 = g1(i, ((ViewGroup.MarginLayoutParams) p0Var).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) p0Var).rightMargin + rect.right);
        int iG12 = g1(i3, ((ViewGroup.MarginLayoutParams) p0Var).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin + rect.bottom);
        if (x0(view, iG1, iG12, p0Var)) {
            view.measure(iG1, iG12);
        }
    }

    @Override // p0.V
    public final void V(b0 b0Var, h0 h0Var, Q.g gVar) {
        super.V(b0Var, h0Var, gVar);
        gVar.i("androidx.recyclerview.widget.StaggeredGridLayoutManager");
    }

    /* JADX WARN: Removed duplicated region for block: B:114:0x01cf  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x01ec  */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0407  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void V0(b0 b0Var, h0 h0Var, boolean z2) {
        r0 r0Var;
        int iG;
        int i;
        r0 r0Var2 = this.F;
        o0 o0Var = this.f1961H;
        if (!(r0Var2 == null && this.f1974z == -1) && h0Var.b() == 0) {
            j0(b0Var);
            o0Var.a();
            return;
        }
        boolean z3 = true;
        boolean z4 = (o0Var.e && this.f1974z == -1 && this.F == null) ? false : true;
        i iVar = this.f1956B;
        StaggeredGridLayoutManager staggeredGridLayoutManager = o0Var.f4990g;
        if (z4) {
            o0Var.a();
            r0 r0Var3 = this.F;
            if (r0Var3 != null) {
                int i3 = r0Var3.f5009d;
                if (i3 > 0) {
                    if (i3 == this.f1964p) {
                        for (int i4 = 0; i4 < this.f1964p; i4++) {
                            this.f1965q[i4].b();
                            r0 r0Var4 = this.F;
                            int i5 = r0Var4.e[i4];
                            if (i5 != Integer.MIN_VALUE) {
                                i5 += r0Var4.f5013j ? this.f1966r.i() : this.f1966r.m();
                            }
                            s0 s0Var = this.f1965q[i4];
                            s0Var.f5020b = i5;
                            s0Var.f5021c = i5;
                        }
                    } else {
                        r0Var3.e = null;
                        r0Var3.f5009d = 0;
                        r0Var3.f5010f = 0;
                        r0Var3.f5011g = null;
                        r0Var3.f5012h = null;
                        r0Var3.f5007b = r0Var3.f5008c;
                    }
                }
                r0 r0Var5 = this.F;
                this.f1959E = r0Var5.f5014k;
                boolean z5 = r0Var5.i;
                c(null);
                r0 r0Var6 = this.F;
                if (r0Var6 != null && r0Var6.i != z5) {
                    r0Var6.i = z5;
                }
                this.f1971w = z5;
                o0();
                b1();
                r0 r0Var7 = this.F;
                int i6 = r0Var7.f5007b;
                if (i6 != -1) {
                    this.f1974z = i6;
                    o0Var.f4987c = r0Var7.f5013j;
                } else {
                    o0Var.f4987c = this.f1972x;
                }
                if (r0Var7.f5010f > 1) {
                    iVar.f94c = r0Var7.f5011g;
                    iVar.f95d = r0Var7.f5012h;
                }
            } else {
                b1();
                o0Var.f4987c = this.f1972x;
            }
            if (h0Var.f4914g || (i = this.f1974z) == -1) {
                if (this.f1958D) {
                    int iB = h0Var.b();
                    int iV = v();
                    for (int i7 = 0; i7 < iV; i7++) {
                        int iG2 = V.G(u(i7));
                        if (iG2 >= 0 && iG2 < iB) {
                            iG = iG2;
                            break;
                        }
                    }
                    iG = 0;
                    o0Var.f4985a = iG;
                    o0Var.f4986b = Integer.MIN_VALUE;
                    o0Var.e = true;
                } else {
                    int iB2 = h0Var.b();
                    for (int iV2 = v() - 1; iV2 >= 0; iV2--) {
                        iG = V.G(u(iV2));
                        if (iG >= 0 && iG < iB2) {
                            break;
                        }
                    }
                    iG = 0;
                    o0Var.f4985a = iG;
                    o0Var.f4986b = Integer.MIN_VALUE;
                    o0Var.e = true;
                }
            } else if (i < 0 || i >= h0Var.b()) {
                this.f1974z = -1;
                this.f1955A = Integer.MIN_VALUE;
                if (this.f1958D) {
                }
            } else {
                r0 r0Var8 = this.F;
                if (r0Var8 == null || r0Var8.f5007b == -1 || r0Var8.f5009d < 1) {
                    View viewQ = q(this.f1974z);
                    if (viewQ != null) {
                        o0Var.f4985a = this.f1972x ? O0() : N0();
                        if (this.f1955A != Integer.MIN_VALUE) {
                            if (o0Var.f4987c) {
                                o0Var.f4986b = (this.f1966r.i() - this.f1955A) - this.f1966r.d(viewQ);
                            } else {
                                o0Var.f4986b = (this.f1966r.m() + this.f1955A) - this.f1966r.g(viewQ);
                            }
                        } else if (this.f1966r.e(viewQ) > this.f1966r.n()) {
                            o0Var.f4986b = o0Var.f4987c ? this.f1966r.i() : this.f1966r.m();
                        } else {
                            int iG3 = this.f1966r.g(viewQ) - this.f1966r.m();
                            if (iG3 < 0) {
                                o0Var.f4986b = -iG3;
                            } else {
                                int i8 = this.f1966r.i() - this.f1966r.d(viewQ);
                                if (i8 < 0) {
                                    o0Var.f4986b = i8;
                                } else {
                                    o0Var.f4986b = Integer.MIN_VALUE;
                                }
                            }
                        }
                    } else {
                        int i9 = this.f1974z;
                        o0Var.f4985a = i9;
                        int i10 = this.f1955A;
                        if (i10 == Integer.MIN_VALUE) {
                            boolean z6 = D0(i9) == 1;
                            o0Var.f4987c = z6;
                            o0Var.f4986b = z6 ? staggeredGridLayoutManager.f1966r.i() : staggeredGridLayoutManager.f1966r.m();
                        } else if (o0Var.f4987c) {
                            o0Var.f4986b = staggeredGridLayoutManager.f1966r.i() - i10;
                        } else {
                            o0Var.f4986b = staggeredGridLayoutManager.f1966r.m() + i10;
                        }
                        o0Var.f4988d = true;
                    }
                } else {
                    o0Var.f4986b = Integer.MIN_VALUE;
                    o0Var.f4985a = this.f1974z;
                }
                o0Var.e = true;
            }
        }
        if (this.F == null && this.f1974z == -1 && (o0Var.f4987c != this.f1958D || T0() != this.f1959E)) {
            iVar.f();
            o0Var.f4988d = true;
        }
        if (v() > 0 && ((r0Var = this.F) == null || r0Var.f5009d < 1)) {
            if (o0Var.f4988d) {
                for (int i11 = 0; i11 < this.f1964p; i11++) {
                    this.f1965q[i11].b();
                    int i12 = o0Var.f4986b;
                    if (i12 != Integer.MIN_VALUE) {
                        s0 s0Var2 = this.f1965q[i11];
                        s0Var2.f5020b = i12;
                        s0Var2.f5021c = i12;
                    }
                }
            } else if (z4 || o0Var.f4989f == null) {
                for (int i13 = 0; i13 < this.f1964p; i13++) {
                    s0 s0Var3 = this.f1965q[i13];
                    boolean z7 = this.f1972x;
                    int i14 = o0Var.f4986b;
                    int iG4 = z7 ? s0Var3.g(Integer.MIN_VALUE) : s0Var3.i(Integer.MIN_VALUE);
                    s0Var3.b();
                    if (iG4 != Integer.MIN_VALUE) {
                        StaggeredGridLayoutManager staggeredGridLayoutManager2 = (StaggeredGridLayoutManager) s0Var3.f5024g;
                        if ((!z7 || iG4 >= staggeredGridLayoutManager2.f1966r.i()) && (z7 || iG4 <= staggeredGridLayoutManager2.f1966r.m())) {
                            if (i14 != Integer.MIN_VALUE) {
                                iG4 += i14;
                            }
                            s0Var3.f5021c = iG4;
                            s0Var3.f5020b = iG4;
                        }
                    }
                }
                s0[] s0VarArr = this.f1965q;
                int length = s0VarArr.length;
                int[] iArr = o0Var.f4989f;
                if (iArr == null || iArr.length < length) {
                    o0Var.f4989f = new int[staggeredGridLayoutManager.f1965q.length];
                }
                for (int i15 = 0; i15 < length; i15++) {
                    o0Var.f4989f[i15] = s0VarArr[i15].i(Integer.MIN_VALUE);
                }
            } else {
                for (int i16 = 0; i16 < this.f1964p; i16++) {
                    s0 s0Var4 = this.f1965q[i16];
                    s0Var4.b();
                    int i17 = o0Var.f4989f[i16];
                    s0Var4.f5020b = i17;
                    s0Var4.f5021c = i17;
                }
            }
        }
        p(b0Var);
        C0394z c0394z = this.f1970v;
        c0394z.f5074a = false;
        int iN = this.f1967s.n();
        this.f1969u = iN / this.f1964p;
        View.MeasureSpec.makeMeasureSpec(iN, this.f1967s.k());
        e1(o0Var.f4985a, h0Var);
        if (o0Var.f4987c) {
            d1(-1);
            I0(b0Var, c0394z, h0Var);
            d1(1);
            c0394z.f5076c = o0Var.f4985a + c0394z.f5077d;
            I0(b0Var, c0394z, h0Var);
        } else {
            d1(1);
            I0(b0Var, c0394z, h0Var);
            d1(-1);
            c0394z.f5076c = o0Var.f4985a + c0394z.f5077d;
            I0(b0Var, c0394z, h0Var);
        }
        if (this.f1967s.k() != 1073741824) {
            int iV3 = v();
            float fMax = 0.0f;
            for (int i18 = 0; i18 < iV3; i18++) {
                View viewU = u(i18);
                float fE = this.f1967s.e(viewU);
                if (fE >= fMax) {
                    ((p0) viewU.getLayoutParams()).getClass();
                    fMax = Math.max(fMax, fE);
                }
            }
            int i19 = this.f1969u;
            int iRound = Math.round(fMax * this.f1964p);
            if (this.f1967s.k() == Integer.MIN_VALUE) {
                iRound = Math.min(iRound, this.f1967s.n());
            }
            this.f1969u = iRound / this.f1964p;
            View.MeasureSpec.makeMeasureSpec(iRound, this.f1967s.k());
            if (this.f1969u != i19) {
                for (int i20 = 0; i20 < iV3; i20++) {
                    View viewU2 = u(i20);
                    p0 p0Var = (p0) viewU2.getLayoutParams();
                    p0Var.getClass();
                    if (T0() && this.f1968t == 1) {
                        int i21 = -((this.f1964p - 1) - p0Var.e.e);
                        viewU2.offsetLeftAndRight((this.f1969u * i21) - (i21 * i19));
                    } else {
                        int i22 = p0Var.e.e;
                        int i23 = this.f1969u * i22;
                        int i24 = i22 * i19;
                        if (this.f1968t == 1) {
                            viewU2.offsetLeftAndRight(i23 - i24);
                        } else {
                            viewU2.offsetTopAndBottom(i23 - i24);
                        }
                    }
                }
            }
        }
        if (v() > 0) {
            if (this.f1972x) {
                L0(b0Var, h0Var, true);
                M0(b0Var, h0Var, false);
            } else {
                M0(b0Var, h0Var, true);
                L0(b0Var, h0Var, false);
            }
        }
        if (!z2 || h0Var.f4914g || this.f1957C == 0 || v() <= 0 || S0() == null) {
            z3 = false;
        } else {
            RecyclerView recyclerView = this.f4840b;
            if (recyclerView != null) {
                recyclerView.removeCallbacks(this.K);
            }
            if (!E0()) {
            }
        }
        if (h0Var.f4914g) {
            o0Var.a();
        }
        this.f1958D = o0Var.f4987c;
        this.f1959E = T0();
        if (z3) {
            o0Var.a();
            V0(b0Var, h0Var, false);
        }
    }

    public final boolean W0(int i) {
        if (this.f1968t == 0) {
            return (i == -1) != this.f1972x;
        }
        return ((i == -1) == this.f1972x) == T0();
    }

    @Override // p0.V
    public final void X(b0 b0Var, h0 h0Var, View view, Q.g gVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof p0)) {
            W(view, gVar);
            return;
        }
        p0 p0Var = (p0) layoutParams;
        if (this.f1968t == 0) {
            s0 s0Var = p0Var.e;
            gVar.j(A0.f.u(s0Var != null ? s0Var.e : -1, 1, -1, -1, false, false));
        } else {
            s0 s0Var2 = p0Var.e;
            gVar.j(A0.f.u(-1, -1, s0Var2 != null ? s0Var2.e : -1, 1, false, false));
        }
    }

    public final void X0(int i, h0 h0Var) {
        int iN0;
        int i3;
        if (i > 0) {
            iN0 = O0();
            i3 = 1;
        } else {
            iN0 = N0();
            i3 = -1;
        }
        C0394z c0394z = this.f1970v;
        c0394z.f5074a = true;
        e1(iN0, h0Var);
        d1(i3);
        c0394z.f5076c = iN0 + c0394z.f5077d;
        c0394z.f5075b = Math.abs(i);
    }

    @Override // p0.V
    public final void Y(int i, int i3) {
        R0(i, i3, 1);
    }

    public final void Y0(b0 b0Var, C0394z c0394z) {
        if (!c0394z.f5074a || c0394z.i) {
            return;
        }
        if (c0394z.f5075b == 0) {
            if (c0394z.e == -1) {
                Z0(b0Var, c0394z.f5079g);
                return;
            } else {
                a1(b0Var, c0394z.f5078f);
                return;
            }
        }
        int i = 1;
        if (c0394z.e == -1) {
            int i3 = c0394z.f5078f;
            int i4 = this.f1965q[0].i(i3);
            while (i < this.f1964p) {
                int i5 = this.f1965q[i].i(i3);
                if (i5 > i4) {
                    i4 = i5;
                }
                i++;
            }
            int i6 = i3 - i4;
            Z0(b0Var, i6 < 0 ? c0394z.f5079g : c0394z.f5079g - Math.min(i6, c0394z.f5075b));
            return;
        }
        int i7 = c0394z.f5079g;
        int iG = this.f1965q[0].g(i7);
        while (i < this.f1964p) {
            int iG2 = this.f1965q[i].g(i7);
            if (iG2 < iG) {
                iG = iG2;
            }
            i++;
        }
        int i8 = iG - c0394z.f5079g;
        a1(b0Var, i8 < 0 ? c0394z.f5078f : Math.min(i8, c0394z.f5075b) + c0394z.f5078f);
    }

    @Override // p0.V
    public final void Z() {
        this.f1956B.f();
        o0();
    }

    public final void Z0(b0 b0Var, int i) {
        for (int iV = v() - 1; iV >= 0; iV--) {
            View viewU = u(iV);
            if (this.f1966r.g(viewU) < i || this.f1966r.q(viewU) < i) {
                return;
            }
            p0 p0Var = (p0) viewU.getLayoutParams();
            p0Var.getClass();
            if (((ArrayList) p0Var.e.f5023f).size() == 1) {
                return;
            }
            s0 s0Var = p0Var.e;
            ArrayList arrayList = (ArrayList) s0Var.f5023f;
            int size = arrayList.size();
            View view = (View) arrayList.remove(size - 1);
            p0 p0Var2 = (p0) view.getLayoutParams();
            p0Var2.e = null;
            if (p0Var2.f4852a.i() || p0Var2.f4852a.l()) {
                s0Var.f5022d -= ((StaggeredGridLayoutManager) s0Var.f5024g).f1966r.e(view);
            }
            if (size == 1) {
                s0Var.f5020b = Integer.MIN_VALUE;
            }
            s0Var.f5021c = Integer.MIN_VALUE;
            l0(viewU, b0Var);
        }
    }

    @Override // p0.g0
    public final PointF a(int i) {
        int iD0 = D0(i);
        PointF pointF = new PointF();
        if (iD0 == 0) {
            return null;
        }
        if (this.f1968t == 0) {
            pointF.x = iD0;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = iD0;
        }
        return pointF;
    }

    @Override // p0.V
    public final void a0(int i, int i3) {
        R0(i, i3, 8);
    }

    public final void a1(b0 b0Var, int i) {
        while (v() > 0) {
            View viewU = u(0);
            if (this.f1966r.d(viewU) > i || this.f1966r.p(viewU) > i) {
                return;
            }
            p0 p0Var = (p0) viewU.getLayoutParams();
            p0Var.getClass();
            if (((ArrayList) p0Var.e.f5023f).size() == 1) {
                return;
            }
            s0 s0Var = p0Var.e;
            ArrayList arrayList = (ArrayList) s0Var.f5023f;
            View view = (View) arrayList.remove(0);
            p0 p0Var2 = (p0) view.getLayoutParams();
            p0Var2.e = null;
            if (arrayList.size() == 0) {
                s0Var.f5021c = Integer.MIN_VALUE;
            }
            if (p0Var2.f4852a.i() || p0Var2.f4852a.l()) {
                s0Var.f5022d -= ((StaggeredGridLayoutManager) s0Var.f5024g).f1966r.e(view);
            }
            s0Var.f5020b = Integer.MIN_VALUE;
            l0(viewU, b0Var);
        }
    }

    @Override // p0.V
    public final void b0(int i, int i3) {
        R0(i, i3, 2);
    }

    public final void b1() {
        if (this.f1968t == 1 || !T0()) {
            this.f1972x = this.f1971w;
        } else {
            this.f1972x = !this.f1971w;
        }
    }

    @Override // p0.V
    public final void c(String str) {
        if (this.F == null) {
            super.c(str);
        }
    }

    @Override // p0.V
    public final void c0(int i, int i3) {
        R0(i, i3, 4);
    }

    public final int c1(int i, b0 b0Var, h0 h0Var) {
        if (v() == 0 || i == 0) {
            return 0;
        }
        X0(i, h0Var);
        C0394z c0394z = this.f1970v;
        int iI0 = I0(b0Var, c0394z, h0Var);
        if (c0394z.f5075b >= iI0) {
            i = i < 0 ? -iI0 : iI0;
        }
        this.f1966r.r(-i);
        this.f1958D = this.f1972x;
        c0394z.f5075b = 0;
        Y0(b0Var, c0394z);
        return i;
    }

    @Override // p0.V
    public final boolean d() {
        return this.f1968t == 0;
    }

    @Override // p0.V
    public final void d0(b0 b0Var, h0 h0Var) {
        V0(b0Var, h0Var, true);
    }

    public final void d1(int i) {
        C0394z c0394z = this.f1970v;
        c0394z.e = i;
        c0394z.f5077d = this.f1972x != (i == -1) ? -1 : 1;
    }

    @Override // p0.V
    public final boolean e() {
        return this.f1968t == 1;
    }

    @Override // p0.V
    public final void e0(h0 h0Var) {
        this.f1974z = -1;
        this.f1955A = Integer.MIN_VALUE;
        this.F = null;
        this.f1961H.a();
    }

    public final void e1(int i, h0 h0Var) {
        int iN;
        int iN2;
        int i3;
        C0394z c0394z = this.f1970v;
        boolean z2 = false;
        c0394z.f5075b = 0;
        c0394z.f5076c = i;
        E e = this.e;
        if (!(e != null && e.e) || (i3 = h0Var.f4909a) == -1) {
            iN = 0;
            iN2 = 0;
        } else {
            if (this.f1972x == (i3 < i)) {
                iN = this.f1966r.n();
                iN2 = 0;
            } else {
                iN2 = this.f1966r.n();
                iN = 0;
            }
        }
        RecyclerView recyclerView = this.f4840b;
        if (recyclerView == null || !recyclerView.i) {
            c0394z.f5079g = this.f1966r.h() + iN;
            c0394z.f5078f = -iN2;
        } else {
            c0394z.f5078f = this.f1966r.m() - iN2;
            c0394z.f5079g = this.f1966r.i() + iN;
        }
        c0394z.f5080h = false;
        c0394z.f5074a = true;
        if (this.f1966r.k() == 0 && this.f1966r.h() == 0) {
            z2 = true;
        }
        c0394z.i = z2;
    }

    @Override // p0.V
    public final boolean f(W w2) {
        return w2 instanceof p0;
    }

    @Override // p0.V
    public final void f0(Parcelable parcelable) {
        if (parcelable instanceof r0) {
            r0 r0Var = (r0) parcelable;
            this.F = r0Var;
            if (this.f1974z != -1) {
                r0Var.e = null;
                r0Var.f5009d = 0;
                r0Var.f5007b = -1;
                r0Var.f5008c = -1;
                r0Var.e = null;
                r0Var.f5009d = 0;
                r0Var.f5010f = 0;
                r0Var.f5011g = null;
                r0Var.f5012h = null;
            }
            o0();
        }
    }

    public final void f1(s0 s0Var, int i, int i3) {
        int i4 = s0Var.f5022d;
        int i5 = s0Var.e;
        if (i != -1) {
            int i6 = s0Var.f5021c;
            if (i6 == Integer.MIN_VALUE) {
                s0Var.a();
                i6 = s0Var.f5021c;
            }
            if (i6 - i4 >= i3) {
                this.f1973y.set(i5, false);
                return;
            }
            return;
        }
        int i7 = s0Var.f5020b;
        if (i7 == Integer.MIN_VALUE) {
            View view = (View) ((ArrayList) s0Var.f5023f).get(0);
            p0 p0Var = (p0) view.getLayoutParams();
            s0Var.f5020b = ((StaggeredGridLayoutManager) s0Var.f5024g).f1966r.g(view);
            p0Var.getClass();
            i7 = s0Var.f5020b;
        }
        if (i7 + i4 <= i3) {
            this.f1973y.set(i5, false);
        }
    }

    @Override // p0.V
    public final Parcelable g0() {
        int i;
        int iM;
        int[] iArr;
        r0 r0Var = this.F;
        if (r0Var != null) {
            r0 r0Var2 = new r0();
            r0Var2.f5009d = r0Var.f5009d;
            r0Var2.f5007b = r0Var.f5007b;
            r0Var2.f5008c = r0Var.f5008c;
            r0Var2.e = r0Var.e;
            r0Var2.f5010f = r0Var.f5010f;
            r0Var2.f5011g = r0Var.f5011g;
            r0Var2.i = r0Var.i;
            r0Var2.f5013j = r0Var.f5013j;
            r0Var2.f5014k = r0Var.f5014k;
            r0Var2.f5012h = r0Var.f5012h;
            return r0Var2;
        }
        r0 r0Var3 = new r0();
        r0Var3.i = this.f1971w;
        r0Var3.f5013j = this.f1958D;
        r0Var3.f5014k = this.f1959E;
        i iVar = this.f1956B;
        if (iVar == null || (iArr = (int[]) iVar.f94c) == null) {
            r0Var3.f5010f = 0;
        } else {
            r0Var3.f5011g = iArr;
            r0Var3.f5010f = iArr.length;
            r0Var3.f5012h = (ArrayList) iVar.f95d;
        }
        if (v() > 0) {
            r0Var3.f5007b = this.f1958D ? O0() : N0();
            View viewJ0 = this.f1972x ? J0(true) : K0(true);
            r0Var3.f5008c = viewJ0 != null ? V.G(viewJ0) : -1;
            int i3 = this.f1964p;
            r0Var3.f5009d = i3;
            r0Var3.e = new int[i3];
            for (int i4 = 0; i4 < this.f1964p; i4++) {
                if (this.f1958D) {
                    i = this.f1965q[i4].g(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        iM = this.f1966r.i();
                        i -= iM;
                    }
                } else {
                    i = this.f1965q[i4].i(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        iM = this.f1966r.m();
                        i -= iM;
                    }
                }
                r0Var3.e[i4] = i;
            }
        } else {
            r0Var3.f5007b = -1;
            r0Var3.f5008c = -1;
            r0Var3.f5009d = 0;
        }
        return r0Var3;
    }

    @Override // p0.V
    public final void h(int i, int i3, h0 h0Var, h hVar) {
        C0394z c0394z;
        int iG;
        int i4;
        if (this.f1968t != 0) {
            i = i3;
        }
        if (v() == 0 || i == 0) {
            return;
        }
        X0(i, h0Var);
        int[] iArr = this.f1963J;
        if (iArr == null || iArr.length < this.f1964p) {
            this.f1963J = new int[this.f1964p];
        }
        int i5 = 0;
        int i6 = 0;
        while (true) {
            int i7 = this.f1964p;
            c0394z = this.f1970v;
            if (i5 >= i7) {
                break;
            }
            if (c0394z.f5077d == -1) {
                iG = c0394z.f5078f;
                i4 = this.f1965q[i5].i(iG);
            } else {
                iG = this.f1965q[i5].g(c0394z.f5079g);
                i4 = c0394z.f5079g;
            }
            int i8 = iG - i4;
            if (i8 >= 0) {
                this.f1963J[i6] = i8;
                i6++;
            }
            i5++;
        }
        Arrays.sort(this.f1963J, 0, i6);
        for (int i9 = 0; i9 < i6; i9++) {
            int i10 = c0394z.f5076c;
            if (i10 < 0 || i10 >= h0Var.b()) {
                return;
            }
            hVar.b(c0394z.f5076c, this.f1963J[i9]);
            c0394z.f5076c += c0394z.f5077d;
        }
    }

    @Override // p0.V
    public final void h0(int i) {
        if (i == 0) {
            E0();
        }
    }

    @Override // p0.V
    public final int j(h0 h0Var) {
        return F0(h0Var);
    }

    @Override // p0.V
    public final int k(h0 h0Var) {
        return G0(h0Var);
    }

    @Override // p0.V
    public final int l(h0 h0Var) {
        return H0(h0Var);
    }

    @Override // p0.V
    public final int m(h0 h0Var) {
        return F0(h0Var);
    }

    @Override // p0.V
    public final int n(h0 h0Var) {
        return G0(h0Var);
    }

    @Override // p0.V
    public final int o(h0 h0Var) {
        return H0(h0Var);
    }

    @Override // p0.V
    public final int p0(int i, b0 b0Var, h0 h0Var) {
        return c1(i, b0Var, h0Var);
    }

    @Override // p0.V
    public final void q0(int i) {
        r0 r0Var = this.F;
        if (r0Var != null && r0Var.f5007b != i) {
            r0Var.e = null;
            r0Var.f5009d = 0;
            r0Var.f5007b = -1;
            r0Var.f5008c = -1;
        }
        this.f1974z = i;
        this.f1955A = Integer.MIN_VALUE;
        o0();
    }

    @Override // p0.V
    public final W r() {
        return this.f1968t == 0 ? new p0(-2, -1) : new p0(-1, -2);
    }

    @Override // p0.V
    public final int r0(int i, b0 b0Var, h0 h0Var) {
        return c1(i, b0Var, h0Var);
    }

    @Override // p0.V
    public final W s(Context context, AttributeSet attributeSet) {
        return new p0(context, attributeSet);
    }

    @Override // p0.V
    public final W t(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new p0((ViewGroup.MarginLayoutParams) layoutParams) : new p0(layoutParams);
    }

    @Override // p0.V
    public final void u0(Rect rect, int i, int i3) {
        int iG;
        int iG2;
        int i4 = this.f1964p;
        int iE = E() + D();
        int iC = C() + F();
        if (this.f1968t == 1) {
            int iHeight = rect.height() + iC;
            RecyclerView recyclerView = this.f4840b;
            WeakHashMap weakHashMap = O.f854a;
            iG2 = V.g(i3, iHeight, recyclerView.getMinimumHeight());
            iG = V.g(i, (this.f1969u * i4) + iE, this.f4840b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iE;
            RecyclerView recyclerView2 = this.f4840b;
            WeakHashMap weakHashMap2 = O.f854a;
            iG = V.g(i, iWidth, recyclerView2.getMinimumWidth());
            iG2 = V.g(i3, (this.f1969u * i4) + iC, this.f4840b.getMinimumHeight());
        }
        this.f4840b.setMeasuredDimension(iG, iG2);
    }

    @Override // p0.V
    public final int x(b0 b0Var, h0 h0Var) {
        if (this.f1968t == 1) {
            return Math.min(this.f1964p, h0Var.b());
        }
        return -1;
    }
}
