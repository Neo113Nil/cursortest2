package androidx.recyclerview.widget;

import A.i;
import K0.h;
import K1.m;
import L1.d;
import P.C0019g;
import P.C0025m;
import P.C0028p;
import P.G;
import P.InterfaceC0024l;
import P.O;
import Q0.b;
import T.a;
import V.e;
import Y.g;
import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import n.r;
import o0.AbstractC0359a;
import p0.C0370a;
import p0.C0376g;
import p0.C0383n;
import p0.C0390v;
import p0.E;
import p0.I;
import p0.J;
import p0.K;
import p0.L;
import p0.P;
import p0.Q;
import p0.RunnableC0392x;
import p0.S;
import p0.V;
import p0.W;
import p0.X;
import p0.Y;
import p0.Z;
import p0.a0;
import p0.b0;
import p0.c0;
import p0.d0;
import p0.e0;
import p0.g0;
import p0.h0;
import p0.i0;
import p0.j0;
import p0.k0;
import p0.l0;
import p0.m0;
import p0.u0;
import s.C0437h;
import s.C0439j;
import v.AbstractC0470e;

/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements InterfaceC0024l {

    /* renamed from: C0, reason: collision with root package name */
    public static boolean f1875C0 = false;

    /* renamed from: D0, reason: collision with root package name */
    public static boolean f1876D0 = false;

    /* renamed from: E0, reason: collision with root package name */
    public static final int[] f1877E0 = {R.attr.nestedScrollingEnabled};

    /* renamed from: F0, reason: collision with root package name */
    public static final float f1878F0 = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* renamed from: G0, reason: collision with root package name */
    public static final boolean f1879G0 = true;
    public static final boolean H0 = true;

    /* renamed from: I0, reason: collision with root package name */
    public static final Class[] f1880I0;

    /* renamed from: J0, reason: collision with root package name */
    public static final e f1881J0;

    /* renamed from: K0, reason: collision with root package name */
    public static final i0 f1882K0;

    /* renamed from: A, reason: collision with root package name */
    public int f1883A;

    /* renamed from: A0, reason: collision with root package name */
    public final K f1884A0;

    /* renamed from: B, reason: collision with root package name */
    public boolean f1885B;

    /* renamed from: B0, reason: collision with root package name */
    public final C0019g f1886B0;

    /* renamed from: C, reason: collision with root package name */
    public final AccessibilityManager f1887C;

    /* renamed from: D, reason: collision with root package name */
    public boolean f1888D;

    /* renamed from: E, reason: collision with root package name */
    public boolean f1889E;
    public int F;

    /* renamed from: G, reason: collision with root package name */
    public int f1890G;

    /* renamed from: H, reason: collision with root package name */
    public P f1891H;

    /* renamed from: I, reason: collision with root package name */
    public EdgeEffect f1892I;

    /* renamed from: J, reason: collision with root package name */
    public EdgeEffect f1893J;
    public EdgeEffect K;

    /* renamed from: L, reason: collision with root package name */
    public EdgeEffect f1894L;

    /* renamed from: M, reason: collision with root package name */
    public Q f1895M;

    /* renamed from: N, reason: collision with root package name */
    public int f1896N;

    /* renamed from: O, reason: collision with root package name */
    public int f1897O;

    /* renamed from: P, reason: collision with root package name */
    public VelocityTracker f1898P;

    /* renamed from: Q, reason: collision with root package name */
    public int f1899Q;

    /* renamed from: R, reason: collision with root package name */
    public int f1900R;

    /* renamed from: S, reason: collision with root package name */
    public int f1901S;

    /* renamed from: T, reason: collision with root package name */
    public int f1902T;

    /* renamed from: U, reason: collision with root package name */
    public int f1903U;

    /* renamed from: V, reason: collision with root package name */
    public X f1904V;

    /* renamed from: W, reason: collision with root package name */
    public final int f1905W;

    /* renamed from: a0, reason: collision with root package name */
    public final int f1906a0;

    /* renamed from: b, reason: collision with root package name */
    public final float f1907b;

    /* renamed from: b0, reason: collision with root package name */
    public final float f1908b0;

    /* renamed from: c, reason: collision with root package name */
    public final d0 f1909c;

    /* renamed from: c0, reason: collision with root package name */
    public final float f1910c0;

    /* renamed from: d, reason: collision with root package name */
    public final b0 f1911d;

    /* renamed from: d0, reason: collision with root package name */
    public boolean f1912d0;
    public e0 e;

    /* renamed from: e0, reason: collision with root package name */
    public final k0 f1913e0;

    /* renamed from: f, reason: collision with root package name */
    public final r f1914f;

    /* renamed from: f0, reason: collision with root package name */
    public RunnableC0392x f1915f0;

    /* renamed from: g, reason: collision with root package name */
    public final C0376g f1916g;

    /* renamed from: g0, reason: collision with root package name */
    public final h f1917g0;

    /* renamed from: h, reason: collision with root package name */
    public final i f1918h;

    /* renamed from: h0, reason: collision with root package name */
    public final h0 f1919h0;
    public boolean i;

    /* renamed from: i0, reason: collision with root package name */
    public Y f1920i0;

    /* renamed from: j, reason: collision with root package name */
    public final J f1921j;

    /* renamed from: j0, reason: collision with root package name */
    public ArrayList f1922j0;

    /* renamed from: k, reason: collision with root package name */
    public final Rect f1923k;

    /* renamed from: k0, reason: collision with root package name */
    public boolean f1924k0;

    /* renamed from: l, reason: collision with root package name */
    public final Rect f1925l;

    /* renamed from: l0, reason: collision with root package name */
    public boolean f1926l0;

    /* renamed from: m, reason: collision with root package name */
    public final RectF f1927m;

    /* renamed from: m0, reason: collision with root package name */
    public final K f1928m0;

    /* renamed from: n, reason: collision with root package name */
    public L f1929n;

    /* renamed from: n0, reason: collision with root package name */
    public boolean f1930n0;

    /* renamed from: o, reason: collision with root package name */
    public V f1931o;

    /* renamed from: o0, reason: collision with root package name */
    public m0 f1932o0;

    /* renamed from: p, reason: collision with root package name */
    public final ArrayList f1933p;

    /* renamed from: p0, reason: collision with root package name */
    public final int[] f1934p0;

    /* renamed from: q, reason: collision with root package name */
    public final ArrayList f1935q;

    /* renamed from: q0, reason: collision with root package name */
    public C0025m f1936q0;

    /* renamed from: r, reason: collision with root package name */
    public final ArrayList f1937r;

    /* renamed from: r0, reason: collision with root package name */
    public final int[] f1938r0;

    /* renamed from: s, reason: collision with root package name */
    public C0390v f1939s;

    /* renamed from: s0, reason: collision with root package name */
    public final int[] f1940s0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f1941t;

    /* renamed from: t0, reason: collision with root package name */
    public final int[] f1942t0;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1943u;

    /* renamed from: u0, reason: collision with root package name */
    public final ArrayList f1944u0;

    /* renamed from: v, reason: collision with root package name */
    public boolean f1945v;

    /* renamed from: v0, reason: collision with root package name */
    public final J f1946v0;

    /* renamed from: w, reason: collision with root package name */
    public int f1947w;

    /* renamed from: w0, reason: collision with root package name */
    public boolean f1948w0;

    /* renamed from: x, reason: collision with root package name */
    public boolean f1949x;

    /* renamed from: x0, reason: collision with root package name */
    public int f1950x0;

    /* renamed from: y, reason: collision with root package name */
    public boolean f1951y;

    /* renamed from: y0, reason: collision with root package name */
    public int f1952y0;

    /* renamed from: z, reason: collision with root package name */
    public boolean f1953z;

    /* renamed from: z0, reason: collision with root package name */
    public final boolean f1954z0;

    static {
        Class cls = Integer.TYPE;
        f1880I0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f1881J0 = new e(1);
        f1882K0 = new i0();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.recyclerViewStyle);
    }

    public static RecyclerView G(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView recyclerViewG = G(viewGroup.getChildAt(i));
            if (recyclerViewG != null) {
                return recyclerViewG;
            }
        }
        return null;
    }

    public static l0 M(View view) {
        if (view == null) {
            return null;
        }
        return ((W) view.getLayoutParams()).f4852a;
    }

    private C0025m getScrollingChildHelper() {
        if (this.f1936q0 == null) {
            this.f1936q0 = new C0025m(this);
        }
        return this.f1936q0;
    }

    public static void l(l0 l0Var) {
        WeakReference weakReference = l0Var.f4947b;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view == l0Var.f4946a) {
                    return;
                }
                Object parent = view.getParent();
                view = parent instanceof View ? (View) parent : null;
            }
            l0Var.f4947b = null;
        }
    }

    public static int o(int i, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i3) {
        if (i > 0 && edgeEffect != null && d.B(edgeEffect) != 0.0f) {
            int iRound = Math.round(d.b0(edgeEffect, ((-i) * 4.0f) / i3, 0.5f) * ((-i3) / 4.0f));
            if (iRound != i) {
                edgeEffect.finish();
            }
            return i - iRound;
        }
        if (i >= 0 || edgeEffect2 == null || d.B(edgeEffect2) == 0.0f) {
            return i;
        }
        float f3 = i3;
        int iRound2 = Math.round(d.b0(edgeEffect2, (i * 4.0f) / f3, 0.5f) * (f3 / 4.0f));
        if (iRound2 != i) {
            edgeEffect2.finish();
        }
        return i - iRound2;
    }

    public static void setDebugAssertionsEnabled(boolean z2) {
        f1875C0 = z2;
    }

    public static void setVerboseLoggingEnabled(boolean z2) {
        f1876D0 = z2;
    }

    public final void A() {
        if (this.f1893J != null) {
            return;
        }
        ((i0) this.f1891H).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f1893J = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final String B() {
        return " " + super.toString() + ", adapter:" + this.f1929n + ", layout:" + this.f1931o + ", context:" + getContext();
    }

    public final void C(h0 h0Var) {
        if (getScrollState() != 2) {
            h0Var.getClass();
            return;
        }
        OverScroller overScroller = this.f1913e0.f4936d;
        overScroller.getFinalX();
        overScroller.getCurrX();
        h0Var.getClass();
        overScroller.getFinalY();
        overScroller.getCurrY();
    }

    public final View D(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x005e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0061 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean E(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        ArrayList arrayList = this.f1937r;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0390v c0390v = (C0390v) arrayList.get(i);
            int i3 = c0390v.f5059v;
            if (i3 == 1) {
                boolean zD = c0390v.d(motionEvent.getX(), motionEvent.getY());
                boolean zC = c0390v.c(motionEvent.getX(), motionEvent.getY());
                if (motionEvent.getAction() == 0 && (zD || zC)) {
                    if (zC) {
                        c0390v.f5060w = 1;
                        c0390v.f5053p = (int) motionEvent.getX();
                    } else if (zD) {
                        c0390v.f5060w = 2;
                        c0390v.f5050m = (int) motionEvent.getY();
                    }
                    c0390v.f(2);
                    if (action == 3) {
                        this.f1939s = c0390v;
                        return true;
                    }
                }
            } else if (i3 != 2) {
                continue;
            } else if (action == 3) {
            }
        }
        return false;
    }

    public final void F(int[] iArr) {
        int iE = this.f1916g.e();
        if (iE == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MAX_VALUE;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < iE; i4++) {
            l0 l0VarM = M(this.f1916g.d(i4));
            if (!l0VarM.p()) {
                int iB = l0VarM.b();
                if (iB < i) {
                    i = iB;
                }
                if (iB > i3) {
                    i3 = iB;
                }
            }
        }
        iArr[0] = i;
        iArr[1] = i3;
    }

    public final l0 H(int i) {
        l0 l0Var = null;
        if (this.f1888D) {
            return null;
        }
        int iH = this.f1916g.h();
        for (int i3 = 0; i3 < iH; i3++) {
            l0 l0VarM = M(this.f1916g.g(i3));
            if (l0VarM != null && !l0VarM.i() && J(l0VarM) == i) {
                if (!this.f1916g.f4904c.contains(l0VarM.f4946a)) {
                    return l0VarM;
                }
                l0Var = l0VarM;
            }
        }
        return l0Var;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:161:0x0202  */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean I(int i, int i3, int i4, int i5) {
        int iMax;
        int i6;
        ?? r12;
        int minFlingVelocity;
        boolean z2;
        int iG;
        PointF pointFA;
        int i7;
        V v2 = this.f1931o;
        if (v2 == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        }
        if (this.f1951y) {
            return false;
        }
        boolean zD = v2.d();
        boolean zE = this.f1931o.e();
        int i8 = (!zD || Math.abs(i) < i4) ? 0 : i;
        int iMax2 = (!zE || Math.abs(i3) < i4) ? 0 : i3;
        if (i8 == 0 && iMax2 == 0) {
            return false;
        }
        if (i8 == 0) {
            iMax = 0;
        } else {
            EdgeEffect edgeEffect = this.f1892I;
            if (edgeEffect == null || d.B(edgeEffect) == 0.0f) {
                EdgeEffect edgeEffect2 = this.K;
                if (edgeEffect2 != null && d.B(edgeEffect2) != 0.0f) {
                    if (h0(this.K, i8, getWidth())) {
                        this.K.onAbsorb(i8);
                        i8 = 0;
                    }
                    iMax = i8;
                    i8 = 0;
                }
                iMax = 0;
            } else {
                int i9 = -i8;
                if (h0(this.f1892I, i9, getWidth())) {
                    this.f1892I.onAbsorb(i9);
                    i8 = 0;
                }
                iMax = i8;
                i8 = 0;
            }
        }
        if (iMax2 == 0) {
            i6 = iMax2;
            iMax2 = 0;
        } else {
            EdgeEffect edgeEffect3 = this.f1893J;
            if (edgeEffect3 == null || d.B(edgeEffect3) == 0.0f) {
                EdgeEffect edgeEffect4 = this.f1894L;
                if (edgeEffect4 != null && d.B(edgeEffect4) != 0.0f) {
                    if (h0(this.f1894L, iMax2, getHeight())) {
                        this.f1894L.onAbsorb(iMax2);
                        iMax2 = 0;
                    }
                    i6 = 0;
                }
                i6 = iMax2;
                iMax2 = 0;
            } else {
                int i10 = -iMax2;
                if (h0(this.f1893J, i10, getHeight())) {
                    this.f1893J.onAbsorb(i10);
                    iMax2 = 0;
                }
                i6 = 0;
            }
        }
        k0 k0Var = this.f1913e0;
        if (iMax != 0 || iMax2 != 0) {
            int i11 = -i5;
            iMax = Math.max(i11, Math.min(iMax, i5));
            iMax2 = Math.max(i11, Math.min(iMax2, i5));
            l0(1);
            k0Var.a(iMax, iMax2);
        }
        if (i8 == 0 && i6 == 0) {
            return (iMax == 0 && iMax2 == 0) ? false : true;
        }
        float f3 = i8;
        float f4 = i6;
        if (dispatchNestedPreFling(f3, f4)) {
            return false;
        }
        boolean z3 = zD || zE;
        dispatchNestedFling(f3, f4, z3);
        X x2 = this.f1904V;
        if (x2 != null) {
            I i12 = (I) x2;
            V layoutManager = i12.f4818a.getLayoutManager();
            if (layoutManager != 0 && i12.f4818a.getAdapter() != null && ((Math.abs(i6) > (minFlingVelocity = i12.f4818a.getMinFlingVelocity()) || Math.abs(i8) > minFlingVelocity) && ((z2 = layoutManager instanceof g0)))) {
                b bVar = !z2 ? null : new b(i12, i12.f4818a.getContext(), 1);
                if (bVar != null) {
                    int iB = layoutManager.B();
                    if (iB != 0) {
                        g gVarE = layoutManager.e() ? i12.e(layoutManager) : layoutManager.d() ? i12.d(layoutManager) : null;
                        if (gVarE == null) {
                            iG = -1;
                            if (iG != -1) {
                                bVar.f4801a = iG;
                                layoutManager.B0(bVar);
                                return true;
                            }
                        } else {
                            int iV = layoutManager.v();
                            int i13 = 0;
                            int i14 = Integer.MIN_VALUE;
                            int i15 = Integer.MAX_VALUE;
                            View view = null;
                            View view2 = null;
                            while (i13 < iV) {
                                View viewU = layoutManager.u(i13);
                                if (viewU == null) {
                                    i7 = iV;
                                } else {
                                    i7 = iV;
                                    int iB2 = I.b(viewU, gVarE);
                                    if (iB2 <= 0 && iB2 > i14) {
                                        view2 = viewU;
                                        i14 = iB2;
                                    }
                                    if (iB2 >= 0 && iB2 < i15) {
                                        view = viewU;
                                        i15 = iB2;
                                    }
                                }
                                i13++;
                                iV = i7;
                            }
                            boolean z4 = !layoutManager.d() ? i6 <= 0 : i8 <= 0;
                            if (z4 && view != null) {
                                iG = V.G(view);
                            } else if (z4 || view2 == null) {
                                if (z4) {
                                    view = view2;
                                }
                                if (view != null) {
                                    iG = V.G(view) + ((z2 && (pointFA = ((g0) layoutManager).a(layoutManager.B() - 1)) != null && ((pointFA.x > 0.0f ? 1 : (pointFA.x == 0.0f ? 0 : -1)) < 0 || (pointFA.y > 0.0f ? 1 : (pointFA.y == 0.0f ? 0 : -1)) < 0)) == z4 ? -1 : 1);
                                    if (iG < 0 || iG >= iB) {
                                    }
                                }
                            } else {
                                iG = V.G(view2);
                            }
                            if (iG != -1) {
                            }
                        }
                    }
                }
            }
            r12 = 1;
        } else {
            r12 = 1;
        }
        if (!z3) {
            return false;
        }
        l0(r12);
        int i16 = -i5;
        k0Var.a(Math.max(i16, Math.min(i8, i5)), Math.max(i16, Math.min(i6, i5)));
        return r12;
    }

    public final int J(l0 l0Var) {
        if (l0Var.d(524) || !l0Var.f()) {
            return -1;
        }
        r rVar = this.f1914f;
        int i = l0Var.f4948c;
        ArrayList arrayList = (ArrayList) rVar.f4584c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            C0370a c0370a = (C0370a) arrayList.get(i3);
            int i4 = c0370a.f4860a;
            if (i4 != 1) {
                if (i4 == 2) {
                    int i5 = c0370a.f4861b;
                    if (i5 <= i) {
                        int i6 = c0370a.f4863d;
                        if (i5 + i6 > i) {
                            return -1;
                        }
                        i -= i6;
                    } else {
                        continue;
                    }
                } else if (i4 == 8) {
                    int i7 = c0370a.f4861b;
                    if (i7 == i) {
                        i = c0370a.f4863d;
                    } else {
                        if (i7 < i) {
                            i--;
                        }
                        if (c0370a.f4863d <= i) {
                            i++;
                        }
                    }
                }
            } else if (c0370a.f4861b <= i) {
                i += c0370a.f4863d;
            }
        }
        return i;
    }

    public final long K(l0 l0Var) {
        return this.f1929n.f4826b ? l0Var.e : l0Var.f4948c;
    }

    public final l0 L(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return M(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public final Rect N(View view) {
        W w2 = (W) view.getLayoutParams();
        boolean z2 = w2.f4854c;
        Rect rect = w2.f4853b;
        if (!z2) {
            return rect;
        }
        if (this.f1919h0.f4914g && (w2.f4852a.l() || w2.f4852a.g())) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.f1935q;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            Rect rect2 = this.f1923k;
            rect2.set(0, 0, 0, 0);
            ((S) arrayList.get(i)).getClass();
            ((W) view.getLayoutParams()).f4852a.getClass();
            rect2.set(0, 0, 0, 0);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        w2.f4854c = false;
        return rect;
    }

    public final boolean O() {
        return !this.f1945v || this.f1888D || this.f1914f.j();
    }

    public final boolean P() {
        return this.F > 0;
    }

    public final void Q(int i) {
        if (this.f1931o == null) {
            return;
        }
        setScrollState(2);
        this.f1931o.q0(i);
        awakenScrollBars();
    }

    public final void R() {
        int iH = this.f1916g.h();
        for (int i = 0; i < iH; i++) {
            ((W) this.f1916g.g(i).getLayoutParams()).f4854c = true;
        }
        ArrayList arrayList = this.f1911d.f4872c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            W w2 = (W) ((l0) arrayList.get(i3)).f4946a.getLayoutParams();
            if (w2 != null) {
                w2.f4854c = true;
            }
        }
    }

    public final void S(int i, int i3, boolean z2) {
        int i4 = i + i3;
        int iH = this.f1916g.h();
        for (int i5 = 0; i5 < iH; i5++) {
            l0 l0VarM = M(this.f1916g.g(i5));
            if (l0VarM != null && !l0VarM.p()) {
                int i6 = l0VarM.f4948c;
                h0 h0Var = this.f1919h0;
                if (i6 >= i4) {
                    if (f1876D0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + l0VarM + " now at position " + (l0VarM.f4948c - i3));
                    }
                    l0VarM.m(-i3, z2);
                    h0Var.f4913f = true;
                } else if (i6 >= i) {
                    if (f1876D0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + l0VarM + " now REMOVED");
                    }
                    l0VarM.a(8);
                    l0VarM.m(-i3, z2);
                    l0VarM.f4948c = i - 1;
                    h0Var.f4913f = true;
                }
            }
        }
        b0 b0Var = this.f1911d;
        ArrayList arrayList = b0Var.f4872c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            l0 l0Var = (l0) arrayList.get(size);
            if (l0Var != null) {
                int i7 = l0Var.f4948c;
                if (i7 >= i4) {
                    if (f1876D0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove cached " + size + " holder " + l0Var + " now at position " + (l0Var.f4948c - i3));
                    }
                    l0Var.m(-i3, z2);
                } else if (i7 >= i) {
                    l0Var.a(8);
                    b0Var.g(size);
                }
            }
        }
        requestLayout();
    }

    public final void T() {
        this.F++;
    }

    public final void U(boolean z2) {
        int i;
        AccessibilityManager accessibilityManager;
        int i3 = this.F - 1;
        this.F = i3;
        if (i3 < 1) {
            if (f1875C0 && i3 < 0) {
                throw new IllegalStateException(H.e.f(this, new StringBuilder("layout or scroll counter cannot go below zero.Some calls are not matching")));
            }
            this.F = 0;
            if (z2) {
                int i4 = this.f1883A;
                this.f1883A = 0;
                if (i4 != 0 && (accessibilityManager = this.f1887C) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                    accessibilityEventObtain.setEventType(2048);
                    accessibilityEventObtain.setContentChangeTypes(i4);
                    sendAccessibilityEventUnchecked(accessibilityEventObtain);
                }
                ArrayList arrayList = this.f1944u0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    l0 l0Var = (l0) arrayList.get(size);
                    if (l0Var.f4946a.getParent() == this && !l0Var.p() && (i = l0Var.f4960q) != -1) {
                        l0Var.f4946a.setImportantForAccessibility(i);
                        l0Var.f4960q = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    public final void V(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1897O) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1897O = motionEvent.getPointerId(i);
            int x2 = (int) (motionEvent.getX(i) + 0.5f);
            this.f1901S = x2;
            this.f1899Q = x2;
            int y2 = (int) (motionEvent.getY(i) + 0.5f);
            this.f1902T = y2;
            this.f1900R = y2;
        }
    }

    public final void W() {
        if (this.f1930n0 || !this.f1941t) {
            return;
        }
        WeakHashMap weakHashMap = O.f854a;
        postOnAnimation(this.f1946v0);
        this.f1930n0 = true;
    }

    public final void X() {
        boolean z2;
        boolean z3 = false;
        if (this.f1888D) {
            r rVar = this.f1914f;
            rVar.q((ArrayList) rVar.f4584c);
            rVar.q((ArrayList) rVar.f4585d);
            rVar.f4582a = 0;
            if (this.f1889E) {
                this.f1931o.Z();
            }
        }
        if (this.f1895M == null || !this.f1931o.C0()) {
            this.f1914f.d();
        } else {
            this.f1914f.p();
        }
        boolean z4 = this.f1924k0 || this.f1926l0;
        boolean z5 = this.f1945v && this.f1895M != null && ((z2 = this.f1888D) || z4 || this.f1931o.f4843f) && (!z2 || this.f1929n.f4826b);
        h0 h0Var = this.f1919h0;
        h0Var.f4916j = z5;
        if (z5 && z4 && !this.f1888D && this.f1895M != null && this.f1931o.C0()) {
            z3 = true;
        }
        h0Var.f4917k = z3;
    }

    public final void Y(boolean z2) {
        this.f1889E = z2 | this.f1889E;
        this.f1888D = true;
        int iH = this.f1916g.h();
        for (int i = 0; i < iH; i++) {
            l0 l0VarM = M(this.f1916g.g(i));
            if (l0VarM != null && !l0VarM.p()) {
                l0VarM.a(6);
            }
        }
        R();
        b0 b0Var = this.f1911d;
        ArrayList arrayList = b0Var.f4872c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            l0 l0Var = (l0) arrayList.get(i3);
            if (l0Var != null) {
                l0Var.a(6);
                l0Var.a(1024);
            }
        }
        L l3 = b0Var.f4876h.f1929n;
        if (l3 == null || !l3.f4826b) {
            b0Var.f();
        }
    }

    public final void Z(l0 l0Var, C0028p c0028p) {
        l0Var.f4953j &= -8193;
        boolean z2 = this.f1919h0.f4915h;
        i iVar = this.f1918h;
        if (z2 && l0Var.l() && !l0Var.i() && !l0Var.p()) {
            ((C0437h) iVar.f95d).d(K(l0Var), l0Var);
        }
        C0439j c0439j = (C0439j) iVar.f94c;
        u0 u0VarA = (u0) c0439j.get(l0Var);
        if (u0VarA == null) {
            u0VarA = u0.a();
            c0439j.put(l0Var, u0VarA);
        }
        u0VarA.f5034b = c0028p;
        u0VarA.f5033a |= 4;
    }

    public final void a0() {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f1892I;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.f1892I.isFinished();
        } else {
            zIsFinished = false;
        }
        EdgeEffect edgeEffect2 = this.f1893J;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.f1893J.isFinished();
        }
        EdgeEffect edgeEffect3 = this.K;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.K.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f1894L;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.f1894L.isFinished();
        }
        if (zIsFinished) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i, int i3) {
        V v2 = this.f1931o;
        if (v2 != null) {
            v2.getClass();
        }
        super.addFocusables(arrayList, i, i3);
    }

    public final int b0(int i, float f3) {
        float height = f3 / getHeight();
        float width = i / getWidth();
        EdgeEffect edgeEffect = this.f1892I;
        float f4 = 0.0f;
        if (edgeEffect == null || d.B(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.K;
            if (edgeEffect2 != null && d.B(edgeEffect2) != 0.0f) {
                if (canScrollHorizontally(1)) {
                    this.K.onRelease();
                } else {
                    float fB0 = d.b0(this.K, width, height);
                    if (d.B(this.K) == 0.0f) {
                        this.K.onRelease();
                    }
                    f4 = fB0;
                }
                invalidate();
            }
        } else {
            if (canScrollHorizontally(-1)) {
                this.f1892I.onRelease();
            } else {
                float f5 = -d.b0(this.f1892I, -width, 1.0f - height);
                if (d.B(this.f1892I) == 0.0f) {
                    this.f1892I.onRelease();
                }
                f4 = f5;
            }
            invalidate();
        }
        return Math.round(f4 * getWidth());
    }

    public final int c0(int i, float f3) {
        float width = f3 / getWidth();
        float height = i / getHeight();
        EdgeEffect edgeEffect = this.f1893J;
        float f4 = 0.0f;
        if (edgeEffect == null || d.B(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.f1894L;
            if (edgeEffect2 != null && d.B(edgeEffect2) != 0.0f) {
                if (canScrollVertically(1)) {
                    this.f1894L.onRelease();
                } else {
                    float fB0 = d.b0(this.f1894L, height, 1.0f - width);
                    if (d.B(this.f1894L) == 0.0f) {
                        this.f1894L.onRelease();
                    }
                    f4 = fB0;
                }
                invalidate();
            }
        } else {
            if (canScrollVertically(-1)) {
                this.f1893J.onRelease();
            } else {
                float f5 = -d.b0(this.f1893J, -height, width);
                if (d.B(this.f1893J) == 0.0f) {
                    this.f1893J.onRelease();
                }
                f4 = f5;
            }
            invalidate();
        }
        return Math.round(f4 * getHeight());
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof W) && this.f1931o.f((W) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        V v2 = this.f1931o;
        if (v2 != null && v2.d()) {
            return this.f1931o.j(this.f1919h0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        V v2 = this.f1931o;
        if (v2 != null && v2.d()) {
            return this.f1931o.k(this.f1919h0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        V v2 = this.f1931o;
        if (v2 != null && v2.d()) {
            return this.f1931o.l(this.f1919h0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        V v2 = this.f1931o;
        if (v2 != null && v2.e()) {
            return this.f1931o.m(this.f1919h0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        V v2 = this.f1931o;
        if (v2 != null && v2.e()) {
            return this.f1931o.n(this.f1919h0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        V v2 = this.f1931o;
        if (v2 != null && v2.e()) {
            return this.f1931o.o(this.f1919h0);
        }
        return 0;
    }

    public final void d0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f1923k;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof W) {
            W w2 = (W) layoutParams;
            if (!w2.f4854c) {
                int i = rect.left;
                Rect rect2 = w2.f4853b;
                rect.left = i - rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f1931o.n0(this, view, this.f1923k, !this.f1945v, view2 == null);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (super.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        V layoutManager = getLayoutManager();
        int iA = 0;
        if (layoutManager == null) {
            return false;
        }
        if (layoutManager.e()) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 92 || keyCode == 93) {
                int measuredHeight = getMeasuredHeight();
                if (keyCode == 93) {
                    i0(0, measuredHeight, false);
                } else {
                    i0(0, -measuredHeight, false);
                }
                return true;
            }
            if (keyCode == 122 || keyCode == 123) {
                boolean zL = layoutManager.L();
                if (keyCode == 122) {
                    if (zL) {
                        iA = getAdapter().a();
                    }
                } else if (!zL) {
                    iA = getAdapter().a();
                }
                j0(iA);
                return true;
            }
        } else if (layoutManager.d()) {
            int keyCode2 = keyEvent.getKeyCode();
            if (keyCode2 == 92 || keyCode2 == 93) {
                int measuredWidth = getMeasuredWidth();
                if (keyCode2 == 93) {
                    i0(measuredWidth, 0, false);
                } else {
                    i0(-measuredWidth, 0, false);
                }
                return true;
            }
            if (keyCode2 == 122 || keyCode2 == 123) {
                boolean zL2 = layoutManager.L();
                if (keyCode2 == 122) {
                    if (zL2) {
                        iA = getAdapter().a();
                    }
                } else if (!zL2) {
                    iA = getAdapter().a();
                }
                j0(iA);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f3, float f4, boolean z2) {
        return getScrollingChildHelper().a(f3, f4, z2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f3, float f4) {
        return getScrollingChildHelper().b(f3, f4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i, i3, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().d(i, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        ArrayList arrayList = this.f1935q;
        int size = arrayList.size();
        boolean z3 = false;
        for (int i = 0; i < size; i++) {
            ((S) arrayList.get(i)).b(canvas, this);
        }
        EdgeEffect edgeEffect = this.f1892I;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.i ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f1892I;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.f1893J;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.i) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f1893J;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.K;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.i ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.K;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.f1894L;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.i) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f1894L;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(iSave4);
        }
        if ((z2 || this.f1895M == null || arrayList.size() <= 0 || !this.f1895M.f()) ? z2 : true) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j3) {
        return super.drawChild(canvas, view, j3);
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0112  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean e0(int i, int i3, MotionEvent motionEvent, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        boolean z2;
        p();
        L l3 = this.f1929n;
        int[] iArr = this.f1942t0;
        if (l3 != null) {
            iArr[0] = 0;
            iArr[1] = 0;
            f0(i, i3, iArr);
            int i9 = iArr[0];
            int i10 = iArr[1];
            i6 = i9;
            i5 = i10;
            i7 = i - i9;
            i8 = i3 - i10;
        } else {
            i5 = 0;
            i6 = 0;
            i7 = 0;
            i8 = 0;
        }
        if (!this.f1935q.isEmpty()) {
            invalidate();
        }
        iArr[0] = 0;
        iArr[1] = 0;
        int i11 = i5;
        v(i6, i5, i7, i8, this.f1938r0, i4, iArr);
        int i12 = iArr[0];
        int i13 = i7 - i12;
        int i14 = iArr[1];
        int i15 = i8 - i14;
        boolean z3 = (i12 == 0 && i14 == 0) ? false : true;
        int i16 = this.f1901S;
        int[] iArr2 = this.f1938r0;
        int i17 = iArr2[0];
        this.f1901S = i16 - i17;
        int i18 = this.f1902T;
        int i19 = iArr2[1];
        this.f1902T = i18 - i19;
        int[] iArr3 = this.f1940s0;
        iArr3[0] = iArr3[0] + i17;
        iArr3[1] = iArr3[1] + i19;
        if (getOverScrollMode() != 2) {
            if (motionEvent != null && !d.R(motionEvent, 8194)) {
                float x2 = motionEvent.getX();
                float f3 = i13;
                float y2 = motionEvent.getY();
                float f4 = i15;
                if (f3 < 0.0f) {
                    y();
                    d.b0(this.f1892I, (-f3) / getWidth(), 1.0f - (y2 / getHeight()));
                } else if (f3 > 0.0f) {
                    z();
                    d.b0(this.K, f3 / getWidth(), y2 / getHeight());
                } else {
                    z2 = false;
                    if (f4 >= 0.0f) {
                        A();
                        d.b0(this.f1893J, (-f4) / getHeight(), x2 / getWidth());
                    } else {
                        if (f4 > 0.0f) {
                            x();
                            d.b0(this.f1894L, f4 / getHeight(), 1.0f - (x2 / getWidth()));
                        }
                        if (z2 || f3 != 0.0f || f4 != 0.0f) {
                            postInvalidateOnAnimation();
                        }
                        if (Build.VERSION.SDK_INT >= 31 && d.R(motionEvent, 4194304)) {
                            a0();
                        }
                    }
                    z2 = true;
                    if (z2) {
                        postInvalidateOnAnimation();
                        if (Build.VERSION.SDK_INT >= 31) {
                            a0();
                        }
                    }
                }
                z2 = true;
                if (f4 >= 0.0f) {
                }
                z2 = true;
                if (z2) {
                }
            }
            n(i, i3);
        }
        if (i6 != 0 || i11 != 0) {
            w(i6, i11);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        return (!z3 && i6 == 0 && i11 == 0) ? false : true;
    }

    public final void f0(int i, int i3, int[] iArr) {
        l0 l0Var;
        k0();
        T();
        Trace.beginSection("RV Scroll");
        h0 h0Var = this.f1919h0;
        C(h0Var);
        b0 b0Var = this.f1911d;
        int iP0 = i != 0 ? this.f1931o.p0(i, b0Var, h0Var) : 0;
        int iR0 = i3 != 0 ? this.f1931o.r0(i3, b0Var, h0Var) : 0;
        Trace.endSection();
        int iE = this.f1916g.e();
        for (int i4 = 0; i4 < iE; i4++) {
            View viewD = this.f1916g.d(i4);
            l0 l0VarL = L(viewD);
            if (l0VarL != null && (l0Var = l0VarL.i) != null) {
                int left = viewD.getLeft();
                int top = viewD.getTop();
                View view = l0Var.f4946a;
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        U(true);
        m0(false);
        if (iArr != null) {
            iArr[0] = iP0;
            iArr[1] = iR0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:136:0x0194  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x007b  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final View focusSearch(View view, int i) {
        View viewT;
        int i3;
        char c3;
        boolean z2;
        this.f1931o.getClass();
        boolean z3 = true;
        boolean z4 = (this.f1929n == null || this.f1931o == null || P() || this.f1951y) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        h0 h0Var = this.f1919h0;
        b0 b0Var = this.f1911d;
        if (!z4 || (i != 2 && i != 1)) {
            View viewFindNextFocus = focusFinder.findNextFocus(this, view, i);
            if (viewFindNextFocus == null && z4) {
                p();
                if (D(view) == null) {
                    return null;
                }
                k0();
                viewT = this.f1931o.T(view, i, b0Var, h0Var);
                m0(false);
            } else {
                viewT = viewFindNextFocus;
            }
        } else if (this.f1931o.e()) {
            if (focusFinder.findNextFocus(this, view, i == 2 ? 130 : 33) == null) {
                z2 = true;
            }
            if (!z2) {
                if (focusFinder.findNextFocus(this, view, !((this.f1931o.f4840b.getLayoutDirection() != 1) ^ (i != 2)) ? 66 : 17) != null) {
                }
            }
            if (z2) {
            }
            viewT = focusFinder.findNextFocus(this, view, i);
        } else {
            z2 = false;
            if (!z2 && this.f1931o.d()) {
                z2 = focusFinder.findNextFocus(this, view, !((this.f1931o.f4840b.getLayoutDirection() != 1) ^ (i != 2)) ? 66 : 17) != null;
            }
            if (z2) {
                p();
                if (D(view) == null) {
                    return null;
                }
                k0();
                this.f1931o.T(view, i, b0Var, h0Var);
                m0(false);
            }
            viewT = focusFinder.findNextFocus(this, view, i);
        }
        if (viewT != null && !viewT.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i);
            }
            d0(viewT, null);
            return view;
        }
        if (viewT == null || viewT == this || viewT == view) {
            z3 = false;
        } else if (D(viewT) == null) {
            z3 = false;
        } else if (view != null && D(view) != null) {
            int width = view.getWidth();
            int height = view.getHeight();
            Rect rect = this.f1923k;
            rect.set(0, 0, width, height);
            int width2 = viewT.getWidth();
            int height2 = viewT.getHeight();
            Rect rect2 = this.f1925l;
            rect2.set(0, 0, width2, height2);
            offsetDescendantRectToMyCoords(view, rect);
            offsetDescendantRectToMyCoords(viewT, rect2);
            int i4 = this.f1931o.f4840b.getLayoutDirection() == 1 ? -1 : 1;
            int i5 = rect.left;
            int i6 = rect2.left;
            if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
                i3 = 1;
            } else {
                int i7 = rect.right;
                int i8 = rect2.right;
                i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
            }
            int i9 = rect.top;
            int i10 = rect2.top;
            if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
                c3 = 1;
            } else {
                int i11 = rect.bottom;
                int i12 = rect2.bottom;
                c3 = ((i11 > i12 || i9 >= i12) && i9 > i10) ? (char) 65535 : (char) 0;
            }
            if (i != 1) {
                if (i != 2) {
                    if (i != 17) {
                        if (i != 33) {
                            if (i != 66) {
                                if (i != 130) {
                                    StringBuilder sb = new StringBuilder("Invalid direction: ");
                                    sb.append(i);
                                    throw new IllegalArgumentException(H.e.f(this, sb));
                                }
                                if (c3 <= 0) {
                                }
                            } else if (i3 <= 0) {
                            }
                        } else if (c3 >= 0) {
                        }
                    } else if (i3 >= 0) {
                    }
                } else if (c3 <= 0 && (c3 != 0 || i3 * i4 <= 0)) {
                }
            } else if (c3 >= 0 && (c3 != 0 || i3 * i4 >= 0)) {
            }
        }
        return z3 ? viewT : super.focusSearch(view, i);
    }

    public final void g0(int i) {
        if (this.f1951y) {
            return;
        }
        o0();
        V v2 = this.f1931o;
        if (v2 == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            v2.q0(i);
            awakenScrollBars();
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        V v2 = this.f1931o;
        if (v2 != null) {
            return v2.r();
        }
        throw new IllegalStateException(H.e.f(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        V v2 = this.f1931o;
        if (v2 != null) {
            return v2.s(getContext(), attributeSet);
        }
        throw new IllegalStateException(H.e.f(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public L getAdapter() {
        return this.f1929n;
    }

    @Override // android.view.View
    public int getBaseline() {
        V v2 = this.f1931o;
        if (v2 == null) {
            return super.getBaseline();
        }
        v2.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i, int i3) {
        return super.getChildDrawingOrder(i, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.i;
    }

    public m0 getCompatAccessibilityDelegate() {
        return this.f1932o0;
    }

    public P getEdgeEffectFactory() {
        return this.f1891H;
    }

    public Q getItemAnimator() {
        return this.f1895M;
    }

    public int getItemDecorationCount() {
        return this.f1935q.size();
    }

    public V getLayoutManager() {
        return this.f1931o;
    }

    public int getMaxFlingVelocity() {
        return this.f1906a0;
    }

    public int getMinFlingVelocity() {
        return this.f1905W;
    }

    public long getNanoTime() {
        if (H0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public X getOnFlingListener() {
        return this.f1904V;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f1912d0;
    }

    public a0 getRecycledViewPool() {
        return this.f1911d.c();
    }

    public int getScrollState() {
        return this.f1896N;
    }

    public final void h(l0 l0Var) {
        View view = l0Var.f4946a;
        boolean z2 = view.getParent() == this;
        this.f1911d.l(L(view));
        if (l0Var.k()) {
            this.f1916g.b(view, -1, view.getLayoutParams(), true);
            return;
        }
        if (!z2) {
            this.f1916g.a(view, -1, true);
            return;
        }
        C0376g c0376g = this.f1916g;
        int iIndexOfChild = c0376g.f4902a.f4824b.indexOfChild(view);
        if (iIndexOfChild >= 0) {
            c0376g.f4903b.h(iIndexOfChild);
            c0376g.i(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public final boolean h0(EdgeEffect edgeEffect, int i, int i3) {
        if (i > 0) {
            return true;
        }
        float fB = d.B(edgeEffect) * i3;
        float fAbs = Math.abs(-i) * 0.35f;
        float f3 = this.f1907b * 0.015f;
        double dLog = Math.log(fAbs / f3);
        double d3 = f1878F0;
        return ((float) (Math.exp((d3 / (d3 - 1.0d)) * dLog) * ((double) f3))) < fB;
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    public final void i(S s2) {
        V v2 = this.f1931o;
        if (v2 != null) {
            v2.c("Cannot add item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f1935q;
        if (arrayList.isEmpty()) {
            setWillNotDraw(false);
        }
        arrayList.add(s2);
        R();
        requestLayout();
    }

    public final void i0(int i, int i3, boolean z2) {
        V v2 = this.f1931o;
        if (v2 == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f1951y) {
            return;
        }
        if (!v2.d()) {
            i = 0;
        }
        if (!this.f1931o.e()) {
            i3 = 0;
        }
        if (i == 0 && i3 == 0) {
            return;
        }
        if (z2) {
            int i4 = i != 0 ? 1 : 0;
            if (i3 != 0) {
                i4 |= 2;
            }
            getScrollingChildHelper().g(i4, 1);
        }
        this.f1913e0.c(i, i3, Integer.MIN_VALUE, null);
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f1941t;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f1951y;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f928d;
    }

    public final void j(Y y2) {
        if (this.f1922j0 == null) {
            this.f1922j0 = new ArrayList();
        }
        this.f1922j0.add(y2);
    }

    public final void j0(int i) {
        if (this.f1951y) {
            return;
        }
        V v2 = this.f1931o;
        if (v2 == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            v2.A0(this, i);
        }
    }

    public final void k(String str) {
        if (P()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException(H.e.f(this, new StringBuilder("Cannot call this method while RecyclerView is computing a layout or scrolling")));
        }
        if (this.f1890G > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(H.e.f(this, new StringBuilder(""))));
        }
    }

    public final void k0() {
        int i = this.f1947w + 1;
        this.f1947w = i;
        if (i != 1 || this.f1951y) {
            return;
        }
        this.f1949x = false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void l0(int i) {
        boolean zD = this.f1931o.d();
        int i3 = zD;
        if (this.f1931o.e()) {
            i3 = (zD ? 1 : 0) | 2;
        }
        getScrollingChildHelper().g(i3, i);
    }

    public final void m() {
        int iH = this.f1916g.h();
        for (int i = 0; i < iH; i++) {
            l0 l0VarM = M(this.f1916g.g(i));
            if (!l0VarM.p()) {
                l0VarM.f4949d = -1;
                l0VarM.f4951g = -1;
            }
        }
        b0 b0Var = this.f1911d;
        ArrayList arrayList = b0Var.f4872c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            l0 l0Var = (l0) arrayList.get(i3);
            l0Var.f4949d = -1;
            l0Var.f4951g = -1;
        }
        ArrayList arrayList2 = b0Var.f4870a;
        int size2 = arrayList2.size();
        for (int i4 = 0; i4 < size2; i4++) {
            l0 l0Var2 = (l0) arrayList2.get(i4);
            l0Var2.f4949d = -1;
            l0Var2.f4951g = -1;
        }
        ArrayList arrayList3 = b0Var.f4871b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i5 = 0; i5 < size3; i5++) {
                l0 l0Var3 = (l0) b0Var.f4871b.get(i5);
                l0Var3.f4949d = -1;
                l0Var3.f4951g = -1;
            }
        }
    }

    public final void m0(boolean z2) {
        if (this.f1947w < 1) {
            if (f1875C0) {
                throw new IllegalStateException(H.e.f(this, new StringBuilder("stopInterceptRequestLayout was called more times than startInterceptRequestLayout.")));
            }
            this.f1947w = 1;
        }
        if (!z2 && !this.f1951y) {
            this.f1949x = false;
        }
        if (this.f1947w == 1) {
            if (z2 && this.f1949x && !this.f1951y && this.f1931o != null && this.f1929n != null) {
                r();
            }
            if (!this.f1951y) {
                this.f1949x = false;
            }
        }
        this.f1947w--;
    }

    public final void n(int i, int i3) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f1892I;
        if (edgeEffect == null || edgeEffect.isFinished() || i <= 0) {
            zIsFinished = false;
        } else {
            this.f1892I.onRelease();
            zIsFinished = this.f1892I.isFinished();
        }
        EdgeEffect edgeEffect2 = this.K;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.K.onRelease();
            zIsFinished |= this.K.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f1893J;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.f1893J.onRelease();
            zIsFinished |= this.f1893J.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f1894L;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.f1894L.onRelease();
            zIsFinished |= this.f1894L.isFinished();
        }
        if (zIsFinished) {
            postInvalidateOnAnimation();
        }
    }

    public final void n0(int i) {
        getScrollingChildHelper().h(i);
    }

    public final void o0() {
        E e;
        setScrollState(0);
        k0 k0Var = this.f1913e0;
        k0Var.f4939h.removeCallbacks(k0Var);
        k0Var.f4936d.abortAnimation();
        V v2 = this.f1931o;
        if (v2 == null || (e = v2.e) == null) {
            return;
        }
        e.i();
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0058  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.F = 0;
        this.f1941t = true;
        this.f1945v = this.f1945v && !isLayoutRequested();
        this.f1911d.d();
        V v2 = this.f1931o;
        if (v2 != null) {
            v2.f4844g = true;
            v2.R(this);
        }
        this.f1930n0 = false;
        if (H0) {
            ThreadLocal threadLocal = RunnableC0392x.f5068f;
            RunnableC0392x runnableC0392x = (RunnableC0392x) threadLocal.get();
            this.f1915f0 = runnableC0392x;
            if (runnableC0392x == null) {
                this.f1915f0 = new RunnableC0392x();
                WeakHashMap weakHashMap = O.f854a;
                Display display = getDisplay();
                if (isInEditMode() || display == null) {
                    refreshRate = 60.0f;
                    RunnableC0392x runnableC0392x2 = this.f1915f0;
                    runnableC0392x2.f5072d = (long) (1.0E9f / refreshRate);
                    threadLocal.set(runnableC0392x2);
                } else {
                    refreshRate = display.getRefreshRate();
                    if (refreshRate < 30.0f) {
                    }
                    RunnableC0392x runnableC0392x22 = this.f1915f0;
                    runnableC0392x22.f5072d = (long) (1.0E9f / refreshRate);
                    threadLocal.set(runnableC0392x22);
                }
            }
            RunnableC0392x runnableC0392x3 = this.f1915f0;
            runnableC0392x3.getClass();
            boolean z2 = f1875C0;
            ArrayList arrayList = runnableC0392x3.f5070b;
            if (z2 && arrayList.contains(this)) {
                throw new IllegalStateException("RecyclerView already present in worker list!");
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        b0 b0Var;
        RunnableC0392x runnableC0392x;
        super.onDetachedFromWindow();
        Q q2 = this.f1895M;
        if (q2 != null) {
            q2.e();
        }
        o0();
        int i = 0;
        this.f1941t = false;
        V v2 = this.f1931o;
        if (v2 != null) {
            v2.f4844g = false;
            v2.S(this);
        }
        this.f1944u0.clear();
        removeCallbacks(this.f1946v0);
        this.f1918h.getClass();
        while (u0.f5032d.a() != null) {
        }
        int i3 = 0;
        while (true) {
            b0Var = this.f1911d;
            ArrayList arrayList = b0Var.f4872c;
            if (i3 >= arrayList.size()) {
                break;
            }
            d.h(((l0) arrayList.get(i3)).f4946a);
            i3++;
        }
        b0Var.e(b0Var.f4876h.f1929n, false);
        while (i < getChildCount()) {
            int i4 = i + 1;
            View childAt = getChildAt(i);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            a aVar = (a) childAt.getTag(com.kortosi.kluani.qorzanis.R.id.pooling_container_listener_holder_tag);
            if (aVar == null) {
                aVar = new a();
                childAt.setTag(com.kortosi.kluani.qorzanis.R.id.pooling_container_listener_holder_tag, aVar);
            }
            ArrayList arrayList2 = aVar.f1141a;
            int iO = m.O(arrayList2);
            if (-1 < iO) {
                arrayList2.get(iO).getClass();
                throw new ClassCastException();
            }
            i = i4;
        }
        if (!H0 || (runnableC0392x = this.f1915f0) == null) {
            return;
        }
        boolean zRemove = runnableC0392x.f5070b.remove(this);
        if (f1875C0 && !zRemove) {
            throw new IllegalStateException("RecyclerView removal failed!");
        }
        this.f1915f0 = null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f1935q;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((S) arrayList.get(i)).a(this);
        }
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float axisValue;
        int i;
        boolean z2;
        if (this.f1931o != null && !this.f1951y && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                float f3 = this.f1931o.e() ? -motionEvent.getAxisValue(9) : 0.0f;
                axisValue = this.f1931o.d() ? motionEvent.getAxisValue(10) : 0.0f;
                i = 0;
                z2 = false;
                f = f3;
            } else if ((motionEvent.getSource() & 4194304) != 0) {
                axisValue = motionEvent.getAxisValue(26);
                if (this.f1931o.e()) {
                    float f4 = -axisValue;
                    axisValue = 0.0f;
                    f = f4;
                } else if (!this.f1931o.d()) {
                    axisValue = 0.0f;
                }
                i = 26;
                z2 = this.f1954z0;
            } else {
                axisValue = 0.0f;
                i = 0;
                z2 = false;
            }
            int i3 = (int) (f * this.f1910c0);
            int i4 = (int) (axisValue * this.f1908b0);
            if (z2) {
                OverScroller overScroller = this.f1913e0.f4936d;
                i0((overScroller.getFinalX() - overScroller.getCurrX()) + i4, (overScroller.getFinalY() - overScroller.getCurrY()) + i3, true);
            } else {
                V v2 = this.f1931o;
                if (v2 == null) {
                    Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                } else if (!this.f1951y) {
                    int[] iArr = this.f1942t0;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    boolean zD = v2.d();
                    boolean zE = this.f1931o.e();
                    int i5 = zE ? (zD ? 1 : 0) | 2 : zD ? 1 : 0;
                    float y2 = motionEvent.getY();
                    float x2 = motionEvent.getX();
                    int iB0 = i4 - b0(i4, y2);
                    int iC0 = i3 - c0(i3, x2);
                    getScrollingChildHelper().g(i5, 1);
                    if (u(zD ? iB0 : 0, zE ? iC0 : 0, 1, this.f1942t0, this.f1938r0)) {
                        iB0 -= iArr[0];
                        iC0 -= iArr[1];
                    }
                    int i6 = iC0;
                    e0(zD ? iB0 : 0, zE ? i6 : 0, motionEvent, 1);
                    RunnableC0392x runnableC0392x = this.f1915f0;
                    if (runnableC0392x != null && (iB0 != 0 || i6 != 0)) {
                        runnableC0392x.a(this, iB0, i6);
                    }
                    n0(1);
                }
            }
            if (i != 0 && !z2) {
                this.f1886B0.a(motionEvent, i);
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        boolean z3;
        if (this.f1951y) {
            return false;
        }
        this.f1939s = null;
        if (E(motionEvent)) {
            VelocityTracker velocityTracker = this.f1898P;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
            n0(0);
            a0();
            setScrollState(0);
            return true;
        }
        V v2 = this.f1931o;
        if (v2 == null) {
            return false;
        }
        boolean zD = v2.d();
        boolean zE = this.f1931o.e();
        if (this.f1898P == null) {
            this.f1898P = VelocityTracker.obtain();
        }
        this.f1898P.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f1953z) {
                this.f1953z = false;
            }
            this.f1897O = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.f1901S = x2;
            this.f1899Q = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.f1902T = y2;
            this.f1900R = y2;
            EdgeEffect edgeEffect = this.f1892I;
            if (edgeEffect == null || d.B(edgeEffect) == 0.0f || canScrollHorizontally(-1)) {
                z2 = false;
            } else {
                d.b0(this.f1892I, 0.0f, 1.0f - (motionEvent.getY() / getHeight()));
                z2 = true;
            }
            EdgeEffect edgeEffect2 = this.K;
            if (edgeEffect2 != null && d.B(edgeEffect2) != 0.0f && !canScrollHorizontally(1)) {
                d.b0(this.K, 0.0f, motionEvent.getY() / getHeight());
                z2 = true;
            }
            EdgeEffect edgeEffect3 = this.f1893J;
            if (edgeEffect3 != null && d.B(edgeEffect3) != 0.0f && !canScrollVertically(-1)) {
                d.b0(this.f1893J, 0.0f, motionEvent.getX() / getWidth());
                z2 = true;
            }
            EdgeEffect edgeEffect4 = this.f1894L;
            if (edgeEffect4 != null && d.B(edgeEffect4) != 0.0f && !canScrollVertically(1)) {
                d.b0(this.f1894L, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
                z2 = true;
            }
            if (z2 || this.f1896N == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                n0(1);
            }
            int[] iArr = this.f1940s0;
            iArr[1] = 0;
            iArr[0] = 0;
            l0(0);
        } else if (actionMasked == 1) {
            this.f1898P.clear();
            n0(0);
        } else if (actionMasked == 2) {
            int iFindPointerIndex = motionEvent.findPointerIndex(this.f1897O);
            if (iFindPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f1897O + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
            if (this.f1896N != 1) {
                int i = x3 - this.f1899Q;
                int i3 = y3 - this.f1900R;
                if (!zD || Math.abs(i) <= this.f1903U) {
                    z3 = false;
                } else {
                    this.f1901S = x3;
                    z3 = true;
                }
                if (zE && Math.abs(i3) > this.f1903U) {
                    this.f1902T = y3;
                    z3 = true;
                }
                if (z3) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            VelocityTracker velocityTracker2 = this.f1898P;
            if (velocityTracker2 != null) {
                velocityTracker2.clear();
            }
            n0(0);
            a0();
            setScrollState(0);
        } else if (actionMasked == 5) {
            this.f1897O = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.f1901S = x4;
            this.f1899Q = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.f1902T = y4;
            this.f1900R = y4;
        } else if (actionMasked == 6) {
            V(motionEvent);
        }
        return this.f1896N == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        Trace.beginSection("RV OnLayout");
        r();
        Trace.endSection();
        this.f1945v = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i3) {
        V v2 = this.f1931o;
        if (v2 == null) {
            q(i, i3);
            return;
        }
        boolean zK = v2.K();
        boolean z2 = false;
        h0 h0Var = this.f1919h0;
        if (zK) {
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f1931o.f4840b.q(i, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            this.f1948w0 = z2;
            if (z2 || this.f1929n == null) {
                return;
            }
            if (h0Var.f4912d == 1) {
                s();
            }
            this.f1931o.t0(i, i3);
            h0Var.i = true;
            t();
            this.f1931o.v0(i, i3);
            if (this.f1931o.y0()) {
                this.f1931o.t0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                h0Var.i = true;
                t();
                this.f1931o.v0(i, i3);
            }
            this.f1950x0 = getMeasuredWidth();
            this.f1952y0 = getMeasuredHeight();
            return;
        }
        if (this.f1943u) {
            this.f1931o.f4840b.q(i, i3);
            return;
        }
        if (this.f1885B) {
            k0();
            T();
            X();
            U(true);
            if (h0Var.f4917k) {
                h0Var.f4914g = true;
            } else {
                this.f1914f.d();
                h0Var.f4914g = false;
            }
            this.f1885B = false;
            m0(false);
        } else if (h0Var.f4917k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        L l3 = this.f1929n;
        if (l3 != null) {
            h0Var.e = l3.a();
        } else {
            h0Var.e = 0;
        }
        k0();
        this.f1931o.f4840b.q(i, i3);
        m0(false);
        h0Var.f4914g = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (P()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof e0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e0 e0Var = (e0) parcelable;
        this.e = e0Var;
        super.onRestoreInstanceState(e0Var.f1144b);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        e0 e0Var = new e0(super.onSaveInstanceState());
        e0 e0Var2 = this.e;
        if (e0Var2 != null) {
            e0Var.f4893d = e0Var2.f4893d;
        } else {
            V v2 = this.f1931o;
            if (v2 != null) {
                e0Var.f4893d = v2.g0();
            } else {
                e0Var.f4893d = null;
            }
        }
        return e0Var;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i3, int i4, int i5) {
        super.onSizeChanged(i, i3, i4, i5);
        if (i == i4 && i3 == i5) {
            return;
        }
        this.f1894L = null;
        this.f1893J = null;
        this.K = null;
        this.f1892I = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x020c A[PHI: r0
      0x020c: PHI (r0v49 int) = (r0v34 int), (r0v53 int) binds: [B:95:0x01f5, B:99:0x0208] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:103:0x020f  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x0225  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zE;
        boolean z2;
        if (this.f1951y || this.f1953z) {
            return false;
        }
        C0390v c0390v = this.f1939s;
        if (c0390v == null) {
            zE = motionEvent.getAction() == 0 ? false : E(motionEvent);
        } else {
            if (c0390v.f5059v != 0) {
                if (motionEvent.getAction() == 0) {
                    boolean zD = c0390v.d(motionEvent.getX(), motionEvent.getY());
                    boolean zC = c0390v.c(motionEvent.getX(), motionEvent.getY());
                    if (zD || zC) {
                        if (zC) {
                            c0390v.f5060w = 1;
                            c0390v.f5053p = (int) motionEvent.getX();
                        } else if (zD) {
                            c0390v.f5060w = 2;
                            c0390v.f5050m = (int) motionEvent.getY();
                        }
                        c0390v.f(2);
                    }
                } else if (motionEvent.getAction() == 1 && c0390v.f5059v == 2) {
                    c0390v.f5050m = 0.0f;
                    c0390v.f5053p = 0.0f;
                    c0390v.f(1);
                    c0390v.f5060w = 0;
                } else if (motionEvent.getAction() == 2 && c0390v.f5059v == 2) {
                    c0390v.g();
                    int i = c0390v.f5060w;
                    int i3 = c0390v.f5041b;
                    if (i == 1) {
                        float x2 = motionEvent.getX();
                        int[] iArr = c0390v.f5062y;
                        iArr[0] = i3;
                        int i4 = c0390v.f5054q - i3;
                        iArr[1] = i4;
                        float fMax = Math.max(i3, Math.min(i4, x2));
                        if (Math.abs(c0390v.f5052o - fMax) >= 2.0f) {
                            int iE = C0390v.e(c0390v.f5053p, fMax, iArr, c0390v.f5056s.computeHorizontalScrollRange(), c0390v.f5056s.computeHorizontalScrollOffset(), c0390v.f5054q);
                            if (iE != 0) {
                                c0390v.f5056s.scrollBy(iE, 0);
                            }
                            c0390v.f5053p = fMax;
                        }
                    }
                    if (c0390v.f5060w == 2) {
                        float y2 = motionEvent.getY();
                        int[] iArr2 = c0390v.f5061x;
                        iArr2[0] = i3;
                        int i5 = c0390v.f5055r - i3;
                        iArr2[1] = i5;
                        float fMax2 = Math.max(i3, Math.min(i5, y2));
                        if (Math.abs(c0390v.f5049l - fMax2) >= 2.0f) {
                            int iE2 = C0390v.e(c0390v.f5050m, fMax2, iArr2, c0390v.f5056s.computeVerticalScrollRange(), c0390v.f5056s.computeVerticalScrollOffset(), c0390v.f5055r);
                            if (iE2 != 0) {
                                c0390v.f5056s.scrollBy(0, iE2);
                            }
                            c0390v.f5050m = fMax2;
                        }
                    }
                }
            }
            int action = motionEvent.getAction();
            if (action == 3 || action == 1) {
                this.f1939s = null;
            }
            zE = true;
        }
        if (zE) {
            VelocityTracker velocityTracker = this.f1898P;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
            n0(0);
            a0();
            setScrollState(0);
            return true;
        }
        V v2 = this.f1931o;
        if (v2 == null) {
            return false;
        }
        boolean zD2 = v2.d();
        boolean zE2 = this.f1931o.e();
        if (this.f1898P == null) {
            this.f1898P = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        int[] iArr3 = this.f1940s0;
        if (actionMasked == 0) {
            iArr3[1] = 0;
            iArr3[0] = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(iArr3[0], iArr3[1]);
        if (actionMasked == 0) {
            this.f1897O = motionEvent.getPointerId(0);
            int x3 = (int) (motionEvent.getX() + 0.5f);
            this.f1901S = x3;
            this.f1899Q = x3;
            int y3 = (int) (motionEvent.getY() + 0.5f);
            this.f1902T = y3;
            this.f1900R = y3;
            l0(0);
        } else {
            if (actionMasked == 1) {
                this.f1898P.addMovement(motionEventObtain);
                VelocityTracker velocityTracker2 = this.f1898P;
                int i6 = this.f1906a0;
                velocityTracker2.computeCurrentVelocity(1000, i6);
                float f3 = zD2 ? -this.f1898P.getXVelocity(this.f1897O) : 0.0f;
                float f4 = zE2 ? -this.f1898P.getYVelocity(this.f1897O) : 0.0f;
                if ((f3 == 0.0f && f4 == 0.0f) || !I((int) f3, (int) f4, this.f1905W, i6)) {
                    setScrollState(0);
                }
                VelocityTracker velocityTracker3 = this.f1898P;
                if (velocityTracker3 != null) {
                    velocityTracker3.clear();
                }
                n0(0);
                a0();
                motionEventObtain.recycle();
                return true;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f1897O);
                if (iFindPointerIndex < 0) {
                    Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f1897O + " not found. Did any MotionEvents get skipped?");
                    return false;
                }
                int x4 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                int y4 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                int iMax = this.f1901S - x4;
                int iMax2 = this.f1902T - y4;
                if (this.f1896N != 1) {
                    if (zD2) {
                        iMax = iMax > 0 ? Math.max(0, iMax - this.f1903U) : Math.min(0, iMax + this.f1903U);
                        if (iMax != 0) {
                            z2 = true;
                        }
                        if (zE2) {
                        }
                        if (z2) {
                        }
                    } else {
                        z2 = false;
                        if (zE2) {
                            iMax2 = iMax2 > 0 ? Math.max(0, iMax2 - this.f1903U) : Math.min(0, iMax2 + this.f1903U);
                            if (iMax2 != 0) {
                                z2 = true;
                            }
                        }
                        if (z2) {
                            setScrollState(1);
                        }
                    }
                    motionEventObtain.recycle();
                    return true;
                }
                if (this.f1896N == 1) {
                    int[] iArr4 = this.f1942t0;
                    iArr4[0] = 0;
                    iArr4[1] = 0;
                    int iB0 = iMax - b0(iMax, motionEvent.getY());
                    int iC0 = iMax2 - c0(iMax2, motionEvent.getX());
                    boolean zU = u(zD2 ? iB0 : 0, zE2 ? iC0 : 0, 0, this.f1942t0, this.f1938r0);
                    int[] iArr5 = this.f1938r0;
                    if (zU) {
                        iB0 -= iArr4[0];
                        iC0 -= iArr4[1];
                        iArr3[0] = iArr3[0] + iArr5[0];
                        iArr3[1] = iArr3[1] + iArr5[1];
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    int i7 = iB0;
                    int i8 = iC0;
                    this.f1901S = x4 - iArr5[0];
                    this.f1902T = y4 - iArr5[1];
                    if (e0(zD2 ? i7 : 0, zE2 ? i8 : 0, motionEvent, 0)) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    RunnableC0392x runnableC0392x = this.f1915f0;
                    if (runnableC0392x != null && (i7 != 0 || i8 != 0)) {
                        runnableC0392x.a(this, i7, i8);
                    }
                }
            } else if (actionMasked == 3) {
                VelocityTracker velocityTracker4 = this.f1898P;
                if (velocityTracker4 != null) {
                    velocityTracker4.clear();
                }
                n0(0);
                a0();
                setScrollState(0);
            } else if (actionMasked == 5) {
                this.f1897O = motionEvent.getPointerId(actionIndex);
                int x5 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                this.f1901S = x5;
                this.f1899Q = x5;
                int y5 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                this.f1902T = y5;
                this.f1900R = y5;
            } else if (actionMasked == 6) {
                V(motionEvent);
            }
        }
        this.f1898P.addMovement(motionEventObtain);
        motionEventObtain.recycle();
        return true;
    }

    public final void p() {
        if (!this.f1945v || this.f1888D) {
            Trace.beginSection("RV FullInvalidate");
            r();
            Trace.endSection();
            return;
        }
        if (this.f1914f.j()) {
            r rVar = this.f1914f;
            int i = rVar.f4582a;
            if ((i & 4) == 0 || (i & 11) != 0) {
                if (rVar.j()) {
                    Trace.beginSection("RV FullInvalidate");
                    r();
                    Trace.endSection();
                    return;
                }
                return;
            }
            Trace.beginSection("RV PartialInvalidate");
            k0();
            T();
            this.f1914f.p();
            if (!this.f1949x) {
                int iE = this.f1916g.e();
                int i3 = 0;
                while (true) {
                    if (i3 < iE) {
                        l0 l0VarM = M(this.f1916g.d(i3));
                        if (l0VarM != null && !l0VarM.p() && l0VarM.l()) {
                            r();
                            break;
                        }
                        i3++;
                    } else {
                        this.f1914f.c();
                        break;
                    }
                }
            }
            m0(true);
            U(true);
            Trace.endSection();
        }
    }

    public final void q(int i, int i3) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap weakHashMap = O.f854a;
        setMeasuredDimension(V.g(i, paddingRight, getMinimumWidth()), V.g(i3, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:164:0x0332  */
    /* JADX WARN: Removed duplicated region for block: B:191:0x038e  */
    /* JADX WARN: Type inference failed for: r3v13 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21, types: [int] */
    /* JADX WARN: Type inference failed for: r3v24 */
    /* JADX WARN: Type inference failed for: r3v27 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v30 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void r() {
        l0 l0Var;
        View viewFindViewById;
        boolean z2;
        C0028p c0028p;
        ?? r3;
        RecyclerView recyclerView;
        boolean zG;
        if (this.f1929n == null) {
            Log.w("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.f1931o == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        h0 h0Var = this.f1919h0;
        boolean z3 = false;
        h0Var.i = false;
        int i = 1;
        boolean z4 = this.f1948w0 && !(this.f1950x0 == getWidth() && this.f1952y0 == getHeight());
        this.f1950x0 = 0;
        this.f1952y0 = 0;
        this.f1948w0 = false;
        if (h0Var.f4912d == 1) {
            s();
            this.f1931o.s0(this);
            t();
        } else {
            r rVar = this.f1914f;
            if ((((ArrayList) rVar.f4585d).isEmpty() || ((ArrayList) rVar.f4584c).isEmpty()) && !z4 && this.f1931o.f4850n == getWidth() && this.f1931o.f4851o == getHeight()) {
                this.f1931o.s0(this);
            } else {
                this.f1931o.s0(this);
                t();
            }
        }
        h0Var.a(4);
        k0();
        T();
        h0Var.f4912d = 1;
        boolean z5 = h0Var.f4916j;
        b0 b0Var = this.f1911d;
        i iVar = this.f1918h;
        if (z5) {
            int iE = this.f1916g.e() - 1;
            while (iE >= 0) {
                l0 l0VarM = M(this.f1916g.d(iE));
                if (!l0VarM.p()) {
                    long jK = K(l0VarM);
                    this.f1895M.getClass();
                    C0028p c0028p2 = new C0028p();
                    c0028p2.a(l0VarM);
                    l0 l0Var2 = (l0) ((C0437h) iVar.f95d).b(jK);
                    if (l0Var2 == null || l0Var2.p()) {
                        iVar.c(l0VarM, c0028p2);
                    } else {
                        C0439j c0439j = (C0439j) iVar.f94c;
                        u0 u0Var = (u0) c0439j.get(l0Var2);
                        int i3 = (u0Var == null || (u0Var.f5033a & i) == 0) ? 0 : i;
                        u0 u0Var2 = (u0) c0439j.get(l0VarM);
                        int i4 = (u0Var2 == null || (u0Var2.f5033a & i) == 0) ? 0 : i;
                        if (i3 == 0 || l0Var2 != l0VarM) {
                            C0028p c0028pN = iVar.N(l0Var2, 4);
                            iVar.c(l0VarM, c0028p2);
                            C0028p c0028pN2 = iVar.N(l0VarM, 8);
                            if (c0028pN == null) {
                                int iE2 = this.f1916g.e();
                                for (int i5 = 0; i5 < iE2; i5++) {
                                    l0 l0VarM2 = M(this.f1916g.d(i5));
                                    if (l0VarM2 != l0VarM && K(l0VarM2) == jK) {
                                        L l3 = this.f1929n;
                                        if (l3 == null || !l3.f4826b) {
                                            StringBuilder sb = new StringBuilder("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                                            sb.append(l0VarM2);
                                            sb.append(" \n View Holder 2:");
                                            sb.append(l0VarM);
                                            throw new IllegalStateException(H.e.f(this, sb));
                                        }
                                        StringBuilder sb2 = new StringBuilder("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                                        sb2.append(l0VarM2);
                                        sb2.append(" \n View Holder 2:");
                                        sb2.append(l0VarM);
                                        throw new IllegalStateException(H.e.f(this, sb2));
                                    }
                                }
                                Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + l0Var2 + " cannot be found but it is necessary for " + l0VarM + B());
                            } else {
                                l0Var2.o(false);
                                if (i3 != 0) {
                                    h(l0Var2);
                                }
                                if (l0Var2 != l0VarM) {
                                    if (i4 != 0) {
                                        h(l0VarM);
                                    }
                                    l0Var2.f4952h = l0VarM;
                                    h(l0Var2);
                                    b0Var.l(l0Var2);
                                    l0VarM.o(false);
                                    l0VarM.i = l0Var2;
                                }
                                if (this.f1895M.a(l0Var2, l0VarM, c0028pN, c0028pN2)) {
                                    W();
                                }
                            }
                        } else {
                            iVar.c(l0VarM, c0028p2);
                        }
                    }
                }
                iE--;
                i = 1;
            }
            C0439j c0439j2 = (C0439j) iVar.f94c;
            int i6 = c0439j2.f5433d - 1;
            while (i6 >= 0) {
                l0 l0Var3 = (l0) c0439j2.f(i6);
                u0 u0Var3 = (u0) c0439j2.g(i6);
                int i7 = u0Var3.f5033a;
                int i8 = i7 & 3;
                K k3 = this.f1884A0;
                if (i8 == 3) {
                    RecyclerView recyclerView2 = k3.f4824b;
                    recyclerView2.f1931o.l0(l0Var3.f4946a, recyclerView2.f1911d);
                    r3 = z3;
                } else if ((i7 & 1) != 0) {
                    C0028p c0028p3 = u0Var3.f5034b;
                    if (c0028p3 == null) {
                        RecyclerView recyclerView3 = k3.f4824b;
                        recyclerView3.f1931o.l0(l0Var3.f4946a, recyclerView3.f1911d);
                        r3 = z3;
                    } else {
                        k3.h(l0Var3, c0028p3, u0Var3.f5035c);
                        r3 = z3;
                    }
                } else if ((i7 & 14) == 14) {
                    k3.g(l0Var3, u0Var3.f5034b, u0Var3.f5035c);
                    r3 = z3;
                } else if ((i7 & 12) == 12) {
                    C0028p c0028p4 = u0Var3.f5034b;
                    C0028p c0028p5 = u0Var3.f5035c;
                    k3.getClass();
                    l0Var3.o(z3);
                    RecyclerView recyclerView4 = k3.f4824b;
                    if (!recyclerView4.f1888D) {
                        C0383n c0383n = (C0383n) recyclerView4.f1895M;
                        c0383n.getClass();
                        int i9 = c0028p4.f933a;
                        int i10 = c0028p5.f933a;
                        if (i9 == i10 && c0028p4.f934b == c0028p5.f934b) {
                            c0383n.c(l0Var3);
                            recyclerView = recyclerView4;
                            zG = false;
                        } else {
                            recyclerView = recyclerView4;
                            zG = c0383n.g(l0Var3, i9, c0028p4.f934b, i10, c0028p5.f934b);
                        }
                        if (zG) {
                            recyclerView.W();
                        }
                    } else if (recyclerView4.f1895M.a(l0Var3, l0Var3, c0028p4, c0028p5)) {
                        recyclerView4.W();
                    }
                    r3 = 0;
                } else {
                    if ((i7 & 4) != 0) {
                        c0028p = null;
                        k3.h(l0Var3, u0Var3.f5034b, null);
                    } else {
                        c0028p = null;
                        if ((i7 & 8) != 0) {
                            k3.g(l0Var3, u0Var3.f5034b, u0Var3.f5035c);
                        }
                    }
                    r3 = 0;
                    u0Var3.f5033a = r3;
                    u0Var3.f5034b = c0028p;
                    u0Var3.f5035c = c0028p;
                    u0.f5032d.c(u0Var3);
                    i6--;
                    z3 = false;
                }
                c0028p = null;
                u0Var3.f5033a = r3;
                u0Var3.f5034b = c0028p;
                u0Var3.f5035c = c0028p;
                u0.f5032d.c(u0Var3);
                i6--;
                z3 = false;
            }
        }
        View view = null;
        this.f1931o.k0(b0Var);
        h0Var.f4910b = h0Var.e;
        this.f1888D = false;
        this.f1889E = false;
        h0Var.f4916j = false;
        h0Var.f4917k = false;
        this.f1931o.f4843f = false;
        ArrayList arrayList = b0Var.f4871b;
        if (arrayList != null) {
            arrayList.clear();
        }
        V v2 = this.f1931o;
        if (v2.f4847k) {
            v2.f4846j = 0;
            v2.f4847k = false;
            b0Var.m();
        }
        this.f1931o.e0(h0Var);
        U(true);
        m0(false);
        ((C0439j) iVar.f94c).clear();
        ((C0437h) iVar.f95d).a();
        int[] iArr = this.f1934p0;
        int i11 = iArr[0];
        int i12 = iArr[1];
        F(iArr);
        if ((iArr[0] == i11 && iArr[1] == i12) ? false : true) {
            w(0, 0);
        }
        if (this.f1912d0 && this.f1929n != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
            if (!isFocused()) {
                if (this.f1916g.f4904c.contains(getFocusedChild())) {
                    long j3 = h0Var.f4919m;
                    if (j3 != -1 && (z2 = this.f1929n.f4826b) && z2) {
                        int iH = this.f1916g.h();
                        int i13 = 0;
                        l0Var = null;
                        while (true) {
                            if (i13 >= iH) {
                                break;
                            }
                            l0 l0VarM3 = M(this.f1916g.g(i13));
                            if (l0VarM3 != null && !l0VarM3.i() && l0VarM3.e == j3) {
                                if (!this.f1916g.f4904c.contains(l0VarM3.f4946a)) {
                                    l0Var = l0VarM3;
                                    break;
                                }
                                l0Var = l0VarM3;
                            }
                            i13++;
                        }
                    } else {
                        l0Var = null;
                    }
                    if (l0Var != null) {
                        ArrayList arrayList2 = this.f1916g.f4904c;
                        View view2 = l0Var.f4946a;
                        if (!arrayList2.contains(view2) && view2.hasFocusable()) {
                            view = view2;
                        } else if (this.f1916g.e() > 0) {
                            int i14 = h0Var.f4918l;
                            int i15 = i14 != -1 ? i14 : 0;
                            int iB = h0Var.b();
                            for (int i16 = i15; i16 < iB; i16++) {
                                l0 l0VarH = H(i16);
                                if (l0VarH == null) {
                                    break;
                                }
                                View view3 = l0VarH.f4946a;
                                if (view3.hasFocusable()) {
                                    view = view3;
                                    break;
                                }
                            }
                            int iMin = Math.min(iB, i15) - 1;
                            while (true) {
                                if (iMin < 0) {
                                    break;
                                }
                                l0 l0VarH2 = H(iMin);
                                if (l0VarH2 == null) {
                                    break;
                                }
                                View view4 = l0VarH2.f4946a;
                                if (view4.hasFocusable()) {
                                    view = view4;
                                    break;
                                }
                                iMin--;
                            }
                        }
                        if (view != null) {
                            int i17 = h0Var.f4920n;
                            if (i17 != -1 && (viewFindViewById = view.findViewById(i17)) != null && viewFindViewById.isFocusable()) {
                                view = viewFindViewById;
                            }
                            view.requestFocus();
                        }
                    }
                }
            }
        }
        h0Var.f4919m = -1L;
        h0Var.f4918l = -1;
        h0Var.f4920n = -1;
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z2) {
        l0 l0VarM = M(view);
        if (l0VarM != null) {
            if (l0VarM.k()) {
                l0VarM.f4953j &= -257;
            } else if (!l0VarM.p()) {
                StringBuilder sb = new StringBuilder("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(l0VarM);
                throw new IllegalArgumentException(H.e.f(this, sb));
            }
        } else if (f1875C0) {
            StringBuilder sb2 = new StringBuilder("No ViewHolder found for child: ");
            sb2.append(view);
            throw new IllegalArgumentException(H.e.f(this, sb2));
        }
        view.clearAnimation();
        M(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        E e = this.f1931o.e;
        if ((e == null || !e.e) && !P() && view2 != null) {
            d0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f1931o.n0(this, view, rect, z2, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        ArrayList arrayList = this.f1937r;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((C0390v) arrayList.get(i)).getClass();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f1947w != 0 || this.f1951y) {
            this.f1949x = true;
        } else {
            super.requestLayout();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void s() {
        int iJ;
        u0 u0Var;
        View viewD;
        h0 h0Var = this.f1919h0;
        h0Var.a(1);
        C(h0Var);
        h0Var.i = false;
        k0();
        i iVar = this.f1918h;
        ((C0439j) iVar.f94c).clear();
        C0437h c0437h = (C0437h) iVar.f95d;
        c0437h.a();
        T();
        X();
        l0 l0VarL = null;
        View focusedChild = (this.f1912d0 && hasFocus() && this.f1929n != null) ? getFocusedChild() : null;
        if (focusedChild != null && (viewD = D(focusedChild)) != null) {
            l0VarL = L(viewD);
        }
        if (l0VarL == null) {
            h0Var.f4919m = -1L;
            h0Var.f4918l = -1;
            h0Var.f4920n = -1;
        } else {
            h0Var.f4919m = this.f1929n.f4826b ? l0VarL.e : -1L;
            if (!this.f1888D) {
                if (l0VarL.i()) {
                    iJ = l0VarL.f4949d;
                } else {
                    RecyclerView recyclerView = l0VarL.f4961r;
                    iJ = recyclerView == null ? -1 : recyclerView.J(l0VarL);
                }
                h0Var.f4918l = iJ;
                View focusedChild2 = l0VarL.f4946a;
                int id = focusedChild2.getId();
                while (!focusedChild2.isFocused() && (focusedChild2 instanceof ViewGroup) && focusedChild2.hasFocus()) {
                    focusedChild2 = ((ViewGroup) focusedChild2).getFocusedChild();
                    if (focusedChild2.getId() != -1) {
                        id = focusedChild2.getId();
                    }
                }
                h0Var.f4920n = id;
            }
        }
        h0Var.f4915h = h0Var.f4916j && this.f1926l0;
        this.f1926l0 = false;
        this.f1924k0 = false;
        h0Var.f4914g = h0Var.f4917k;
        h0Var.e = this.f1929n.a();
        F(this.f1934p0);
        boolean z2 = h0Var.f4916j;
        C0439j c0439j = (C0439j) iVar.f94c;
        if (z2) {
            int iE = this.f1916g.e();
            for (int i = 0; i < iE; i++) {
                l0 l0VarM = M(this.f1916g.d(i));
                if (!l0VarM.p() && (!l0VarM.g() || this.f1929n.f4826b)) {
                    Q q2 = this.f1895M;
                    Q.b(l0VarM);
                    l0VarM.c();
                    q2.getClass();
                    C0028p c0028p = new C0028p();
                    c0028p.a(l0VarM);
                    u0 u0VarA = (u0) c0439j.get(l0VarM);
                    if (u0VarA == null) {
                        u0VarA = u0.a();
                        c0439j.put(l0VarM, u0VarA);
                    }
                    u0VarA.f5034b = c0028p;
                    u0VarA.f5033a |= 4;
                    if (h0Var.f4915h && l0VarM.l() && !l0VarM.i() && !l0VarM.p() && !l0VarM.g()) {
                        c0437h.d(K(l0VarM), l0VarM);
                    }
                }
            }
        }
        if (h0Var.f4917k) {
            int iH = this.f1916g.h();
            for (int i3 = 0; i3 < iH; i3++) {
                l0 l0VarM2 = M(this.f1916g.g(i3));
                if (f1875C0 && l0VarM2.f4948c == -1 && !l0VarM2.i()) {
                    throw new IllegalStateException(H.e.f(this, new StringBuilder("view holder cannot have position -1 unless it is removed")));
                }
                if (!l0VarM2.p() && l0VarM2.f4949d == -1) {
                    l0VarM2.f4949d = l0VarM2.f4948c;
                }
            }
            boolean z3 = h0Var.f4913f;
            h0Var.f4913f = false;
            this.f1931o.d0(this.f1911d, h0Var);
            h0Var.f4913f = z3;
            for (int i4 = 0; i4 < this.f1916g.e(); i4++) {
                l0 l0VarM3 = M(this.f1916g.d(i4));
                if (!l0VarM3.p() && ((u0Var = (u0) c0439j.get(l0VarM3)) == null || (u0Var.f5033a & 4) == 0)) {
                    Q.b(l0VarM3);
                    boolean zD = l0VarM3.d(8192);
                    Q q3 = this.f1895M;
                    l0VarM3.c();
                    q3.getClass();
                    C0028p c0028p2 = new C0028p();
                    c0028p2.a(l0VarM3);
                    if (zD) {
                        Z(l0VarM3, c0028p2);
                    } else {
                        u0 u0VarA2 = (u0) c0439j.get(l0VarM3);
                        if (u0VarA2 == null) {
                            u0VarA2 = u0.a();
                            c0439j.put(l0VarM3, u0VarA2);
                        }
                        u0VarA2.f5033a |= 2;
                        u0VarA2.f5034b = c0028p2;
                    }
                }
            }
            m();
        } else {
            m();
        }
        U(true);
        m0(false);
        h0Var.f4912d = 2;
    }

    @Override // android.view.View
    public final void scrollBy(int i, int i3) {
        V v2 = this.f1931o;
        if (v2 == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f1951y) {
            return;
        }
        boolean zD = v2.d();
        boolean zE = this.f1931o.e();
        if (zD || zE) {
            if (!zD) {
                i = 0;
            }
            if (!zE) {
                i3 = 0;
            }
            e0(i, i3, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!P()) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.f1883A |= contentChangeTypes != 0 ? contentChangeTypes : 0;
        }
    }

    public void setAccessibilityDelegateCompat(m0 m0Var) {
        this.f1932o0 = m0Var;
        O.m(this, m0Var);
    }

    public void setAdapter(L l3) {
        setLayoutFrozen(false);
        L l4 = this.f1929n;
        d0 d0Var = this.f1909c;
        if (l4 != null) {
            l4.f4825a.unregisterObserver(d0Var);
            this.f1929n.getClass();
        }
        Q q2 = this.f1895M;
        if (q2 != null) {
            q2.e();
        }
        V v2 = this.f1931o;
        b0 b0Var = this.f1911d;
        if (v2 != null) {
            v2.j0(b0Var);
            this.f1931o.k0(b0Var);
        }
        b0Var.f4870a.clear();
        b0Var.f();
        r rVar = this.f1914f;
        rVar.q((ArrayList) rVar.f4584c);
        rVar.q((ArrayList) rVar.f4585d);
        rVar.f4582a = 0;
        L l5 = this.f1929n;
        this.f1929n = l3;
        if (l3 != null) {
            l3.f4825a.registerObserver(d0Var);
        }
        V v3 = this.f1931o;
        if (v3 != null) {
            v3.Q();
        }
        L l6 = this.f1929n;
        b0Var.f4870a.clear();
        b0Var.f();
        b0Var.e(l5, true);
        a0 a0VarC = b0Var.c();
        if (l5 != null) {
            a0VarC.f4865b--;
        }
        if (a0VarC.f4865b == 0) {
            int i = 0;
            while (true) {
                SparseArray sparseArray = a0VarC.f4864a;
                if (i >= sparseArray.size()) {
                    break;
                }
                Z z2 = (Z) sparseArray.valueAt(i);
                Iterator it = z2.f4856a.iterator();
                while (it.hasNext()) {
                    d.h(((l0) it.next()).f4946a);
                }
                z2.f4856a.clear();
                i++;
            }
        }
        if (l6 != null) {
            a0VarC.f4865b++;
        }
        b0Var.d();
        this.f1919h0.f4913f = true;
        Y(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(p0.O o3) {
        if (o3 == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.i) {
            this.f1894L = null;
            this.f1893J = null;
            this.K = null;
            this.f1892I = null;
        }
        this.i = z2;
        super.setClipToPadding(z2);
        if (this.f1945v) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(P p2) {
        p2.getClass();
        this.f1891H = p2;
        this.f1894L = null;
        this.f1893J = null;
        this.K = null;
        this.f1892I = null;
    }

    public void setHasFixedSize(boolean z2) {
        this.f1943u = z2;
    }

    public void setItemAnimator(Q q2) {
        Q q3 = this.f1895M;
        if (q3 != null) {
            q3.e();
            this.f1895M.f4828a = null;
        }
        this.f1895M = q2;
        if (q2 != null) {
            q2.f4828a = this.f1928m0;
        }
    }

    public void setItemViewCacheSize(int i) {
        b0 b0Var = this.f1911d;
        b0Var.e = i;
        b0Var.m();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(V v2) {
        RecyclerView recyclerView;
        if (v2 == this.f1931o) {
            return;
        }
        o0();
        V v3 = this.f1931o;
        b0 b0Var = this.f1911d;
        if (v3 != null) {
            Q q2 = this.f1895M;
            if (q2 != null) {
                q2.e();
            }
            this.f1931o.j0(b0Var);
            this.f1931o.k0(b0Var);
            b0Var.f4870a.clear();
            b0Var.f();
            if (this.f1941t) {
                V v4 = this.f1931o;
                v4.f4844g = false;
                v4.S(this);
            }
            this.f1931o.w0(null);
            this.f1931o = null;
        } else {
            b0Var.f4870a.clear();
            b0Var.f();
        }
        C0376g c0376g = this.f1916g;
        c0376g.f4903b.g();
        ArrayList arrayList = c0376g.f4904c;
        int size = arrayList.size() - 1;
        while (true) {
            recyclerView = c0376g.f4902a.f4824b;
            if (size < 0) {
                break;
            }
            l0 l0VarM = M((View) arrayList.get(size));
            if (l0VarM != null) {
                int i = l0VarM.f4959p;
                if (recyclerView.P()) {
                    l0VarM.f4960q = i;
                    recyclerView.f1944u0.add(l0VarM);
                } else {
                    l0VarM.f4946a.setImportantForAccessibility(i);
                }
                l0VarM.f4959p = 0;
            }
            arrayList.remove(size);
            size--;
        }
        int childCount = recyclerView.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = recyclerView.getChildAt(i3);
            M(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f1931o = v2;
        if (v2 != null) {
            if (v2.f4840b != null) {
                StringBuilder sb = new StringBuilder("LayoutManager ");
                sb.append(v2);
                sb.append(" is already attached to a RecyclerView:");
                throw new IllegalArgumentException(H.e.f(v2.f4840b, sb));
            }
            v2.w0(this);
            if (this.f1941t) {
                V v5 = this.f1931o;
                v5.f4844g = true;
                v5.R(this);
            }
        }
        b0Var.m();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        C0025m scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f928d) {
            WeakHashMap weakHashMap = O.f854a;
            G.m(scrollingChildHelper.f927c);
        }
        scrollingChildHelper.f928d = z2;
    }

    public void setOnFlingListener(X x2) {
        this.f1904V = x2;
    }

    @Deprecated
    public void setOnScrollListener(Y y2) {
        this.f1920i0 = y2;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f1912d0 = z2;
    }

    public void setRecycledViewPool(a0 a0Var) {
        b0 b0Var = this.f1911d;
        RecyclerView recyclerView = b0Var.f4876h;
        b0Var.e(recyclerView.f1929n, false);
        if (b0Var.f4875g != null) {
            r2.f4865b--;
        }
        b0Var.f4875g = a0Var;
        if (a0Var != null && recyclerView.getAdapter() != null) {
            b0Var.f4875g.f4865b++;
        }
        b0Var.d();
    }

    @Deprecated
    public void setRecyclerListener(c0 c0Var) {
    }

    public void setScrollState(int i) {
        E e;
        if (i == this.f1896N) {
            return;
        }
        if (f1876D0) {
            Log.d("RecyclerView", "setting scroll state to " + i + " from " + this.f1896N, new Exception());
        }
        this.f1896N = i;
        if (i != 2) {
            k0 k0Var = this.f1913e0;
            k0Var.f4939h.removeCallbacks(k0Var);
            k0Var.f4936d.abortAnimation();
            V v2 = this.f1931o;
            if (v2 != null && (e = v2.e) != null) {
                e.i();
            }
        }
        V v3 = this.f1931o;
        if (v3 != null) {
            v3.h0(i);
        }
        Y y2 = this.f1920i0;
        if (y2 != null) {
            y2.a(this, i);
        }
        ArrayList arrayList = this.f1922j0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Y) this.f1922j0.get(size)).a(this, i);
            }
        }
    }

    public void setScrollingTouchSlop(int i) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i != 0) {
            if (i == 1) {
                this.f1903U = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i + "; using default value");
        }
        this.f1903U = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(j0 j0Var) {
        this.f1911d.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return getScrollingChildHelper().g(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z2) {
        if (z2 != this.f1951y) {
            k("Do not suppressLayout in layout or scroll");
            if (z2) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
                this.f1951y = true;
                this.f1953z = true;
                o0();
                return;
            }
            this.f1951y = false;
            if (this.f1949x && this.f1931o != null && this.f1929n != null) {
                requestLayout();
            }
            this.f1949x = false;
        }
    }

    public final void t() {
        k0();
        T();
        h0 h0Var = this.f1919h0;
        h0Var.a(6);
        this.f1914f.d();
        h0Var.e = this.f1929n.a();
        h0Var.f4911c = 0;
        if (this.e != null) {
            L l3 = this.f1929n;
            int iA = AbstractC0470e.a(l3.f4827c);
            if (iA == 1 ? l3.a() > 0 : iA != 2) {
                Parcelable parcelable = this.e.f4893d;
                if (parcelable != null) {
                    this.f1931o.f0(parcelable);
                }
                this.e = null;
            }
        }
        h0Var.f4914g = false;
        this.f1931o.d0(this.f1911d, h0Var);
        h0Var.f4913f = false;
        h0Var.f4916j = h0Var.f4916j && this.f1895M != null;
        h0Var.f4912d = 4;
        U(true);
        m0(false);
    }

    public final boolean u(int i, int i3, int i4, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i, i3, i4, iArr, iArr2);
    }

    public final void v(int i, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().d(i, i3, i4, i5, iArr, i6, iArr2);
    }

    public final void w(int i, int i3) {
        this.f1890G++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i3);
        Y y2 = this.f1920i0;
        if (y2 != null) {
            y2.b(this, i, i3);
        }
        ArrayList arrayList = this.f1922j0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Y) this.f1922j0.get(size)).b(this, i, i3);
            }
        }
        this.f1890G--;
    }

    public final void x() {
        if (this.f1894L != null) {
            return;
        }
        ((i0) this.f1891H).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f1894L = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final void y() {
        if (this.f1892I != null) {
            return;
        }
        ((i0) this.f1891H).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f1892I = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void z() {
        if (this.K != null) {
            return;
        }
        ((i0) this.f1891H).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.K = edgeEffect;
        if (this.i) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public RecyclerView(Context context, AttributeSet attributeSet, int i) throws NoSuchMethodException, SecurityException {
        int i3;
        char c3;
        Object[] objArr;
        Constructor constructor;
        super(context, attributeSet, i);
        int i4 = 1;
        this.f1909c = new d0(this);
        this.f1911d = new b0(this);
        this.f1918h = new i(20);
        this.f1921j = new J(this, 0);
        this.f1923k = new Rect();
        this.f1925l = new Rect();
        this.f1927m = new RectF();
        this.f1933p = new ArrayList();
        this.f1935q = new ArrayList();
        this.f1937r = new ArrayList();
        this.f1947w = 0;
        this.f1888D = false;
        this.f1889E = false;
        this.F = 0;
        this.f1890G = 0;
        this.f1891H = f1882K0;
        C0383n c0383n = new C0383n();
        c0383n.f4828a = null;
        c0383n.f4829b = new ArrayList();
        c0383n.f4830c = 120L;
        c0383n.f4831d = 120L;
        c0383n.e = 250L;
        c0383n.f4832f = 250L;
        c0383n.f4969g = true;
        c0383n.f4970h = new ArrayList();
        c0383n.i = new ArrayList();
        c0383n.f4971j = new ArrayList();
        c0383n.f4972k = new ArrayList();
        c0383n.f4973l = new ArrayList();
        c0383n.f4974m = new ArrayList();
        c0383n.f4975n = new ArrayList();
        c0383n.f4976o = new ArrayList();
        c0383n.f4977p = new ArrayList();
        c0383n.f4978q = new ArrayList();
        c0383n.f4979r = new ArrayList();
        this.f1895M = c0383n;
        this.f1896N = 0;
        this.f1897O = -1;
        this.f1908b0 = Float.MIN_VALUE;
        this.f1910c0 = Float.MIN_VALUE;
        this.f1912d0 = true;
        this.f1913e0 = new k0(this);
        this.f1917g0 = H0 ? new h() : null;
        h0 h0Var = new h0();
        h0Var.f4909a = -1;
        h0Var.f4910b = 0;
        h0Var.f4911c = 0;
        h0Var.f4912d = 1;
        h0Var.e = 0;
        h0Var.f4913f = false;
        h0Var.f4914g = false;
        h0Var.f4915h = false;
        h0Var.i = false;
        h0Var.f4916j = false;
        h0Var.f4917k = false;
        this.f1919h0 = h0Var;
        this.f1924k0 = false;
        this.f1926l0 = false;
        K k3 = new K(this);
        this.f1928m0 = k3;
        this.f1930n0 = false;
        this.f1934p0 = new int[2];
        this.f1938r0 = new int[2];
        this.f1940s0 = new int[2];
        this.f1942t0 = new int[2];
        this.f1944u0 = new ArrayList();
        this.f1946v0 = new J(this, i4);
        this.f1950x0 = 0;
        this.f1952y0 = 0;
        this.f1884A0 = new K(this);
        this.f1886B0 = new C0019g(getContext(), new K(this));
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f1903U = viewConfiguration.getScaledTouchSlop();
        this.f1908b0 = viewConfiguration.getScaledHorizontalScrollFactor();
        this.f1910c0 = viewConfiguration.getScaledVerticalScrollFactor();
        this.f1905W = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1906a0 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f1907b = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        setWillNotDraw(getOverScrollMode() == 2);
        this.f1895M.f4828a = k3;
        this.f1914f = new r(new K(this));
        this.f1916g = new C0376g(new K(this));
        WeakHashMap weakHashMap = O.f854a;
        if (P.I.a(this) == 0) {
            P.I.b(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f1887C = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new m0(this));
        int[] iArr = AbstractC0359a.f4717a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        O.l(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i);
        String string = typedArrayObtainStyledAttributes.getString(8);
        if (typedArrayObtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.i = typedArrayObtainStyledAttributes.getBoolean(1, true);
        if (typedArrayObtainStyledAttributes.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(6);
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = typedArrayObtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                throw new IllegalArgumentException(H.e.f(this, new StringBuilder("Trying to set fast scroller without both required drawables.")));
            }
            Resources resources = getContext().getResources();
            i3 = 4;
            c3 = 2;
            new C0390v(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(com.kortosi.kluani.qorzanis.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(com.kortosi.kluani.qorzanis.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(com.kortosi.kluani.qorzanis.R.dimen.fastscroll_margin));
        } else {
            i3 = 4;
            c3 = 2;
        }
        typedArrayObtainStyledAttributes.recycle();
        this.f1954z0 = context.getPackageManager().hasSystemFeature("android.hardware.rotaryencoder.lowres");
        if (string != null) {
            String strTrim = string.trim();
            if (!strTrim.isEmpty()) {
                if (strTrim.charAt(0) == '.') {
                    strTrim = context.getPackageName() + strTrim;
                } else if (!strTrim.contains(".")) {
                    strTrim = RecyclerView.class.getPackage().getName() + '.' + strTrim;
                }
                try {
                    Class<? extends U> clsAsSubclass = Class.forName(strTrim, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(V.class);
                    try {
                        constructor = clsAsSubclass.getConstructor(f1880I0);
                        objArr = new Object[i3];
                        objArr[0] = context;
                        objArr[1] = attributeSet;
                        objArr[c3] = Integer.valueOf(i);
                        objArr[3] = 0;
                    } catch (NoSuchMethodException e) {
                        try {
                            objArr = null;
                            constructor = clsAsSubclass.getConstructor(null);
                        } catch (NoSuchMethodException e3) {
                            e3.initCause(e);
                            throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + strTrim, e3);
                        }
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((V) constructor.newInstance(objArr));
                } catch (ClassCastException e4) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + strTrim, e4);
                } catch (ClassNotFoundException e5) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + strTrim, e5);
                } catch (IllegalAccessException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + strTrim, e6);
                } catch (InstantiationException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strTrim, e7);
                } catch (InvocationTargetException e8) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strTrim, e8);
                }
            }
        }
        int[] iArr2 = f1877E0;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i, 0);
        O.l(this, context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i);
        boolean z2 = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z2);
        setTag(com.kortosi.kluani.qorzanis.R.id.is_pooling_container_tag, Boolean.TRUE);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        V v2 = this.f1931o;
        if (v2 != null) {
            return v2.t(layoutParams);
        }
        throw new IllegalStateException(H.e.f(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }
}
