package androidx.recyclerview.widget;

import K0.h;
import Q.e;
import Y.g;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;
import p0.AbstractC0371b;
import p0.C0367A;
import p0.C0368B;
import p0.C0369C;
import p0.D;
import p0.E;
import p0.L;
import p0.U;
import p0.V;
import p0.W;
import p0.b0;
import p0.g0;
import p0.h0;
import p0.l0;

/* loaded from: classes.dex */
public class LinearLayoutManager extends V implements g0 {

    /* renamed from: A, reason: collision with root package name */
    public final C0367A f1860A;

    /* renamed from: B, reason: collision with root package name */
    public final C0368B f1861B;

    /* renamed from: C, reason: collision with root package name */
    public final int f1862C;

    /* renamed from: D, reason: collision with root package name */
    public final int[] f1863D;

    /* renamed from: p, reason: collision with root package name */
    public int f1864p;

    /* renamed from: q, reason: collision with root package name */
    public C0369C f1865q;

    /* renamed from: r, reason: collision with root package name */
    public g f1866r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f1867s;

    /* renamed from: t, reason: collision with root package name */
    public final boolean f1868t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1869u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f1870v;

    /* renamed from: w, reason: collision with root package name */
    public final boolean f1871w;

    /* renamed from: x, reason: collision with root package name */
    public int f1872x;

    /* renamed from: y, reason: collision with root package name */
    public int f1873y;

    /* renamed from: z, reason: collision with root package name */
    public D f1874z;

    public LinearLayoutManager(int i) {
        this.f1864p = 1;
        this.f1868t = false;
        this.f1869u = false;
        this.f1870v = false;
        this.f1871w = true;
        this.f1872x = -1;
        this.f1873y = Integer.MIN_VALUE;
        this.f1874z = null;
        this.f1860A = new C0367A();
        this.f1861B = new C0368B();
        this.f1862C = 2;
        this.f1863D = new int[2];
        c1(i);
        c(null);
        if (this.f1868t) {
            this.f1868t = false;
            o0();
        }
    }

    @Override // p0.V
    public void A0(RecyclerView recyclerView, int i) {
        E e = new E(recyclerView.getContext());
        e.f4801a = i;
        B0(e);
    }

    @Override // p0.V
    public boolean C0() {
        return this.f1874z == null && this.f1867s == this.f1870v;
    }

    public void D0(h0 h0Var, int[] iArr) {
        int i;
        int iN = h0Var.f4909a != -1 ? this.f1866r.n() : 0;
        if (this.f1865q.f4792f == -1) {
            i = 0;
        } else {
            i = iN;
            iN = 0;
        }
        iArr[0] = iN;
        iArr[1] = i;
    }

    public void E0(h0 h0Var, C0369C c0369c, h hVar) {
        int i = c0369c.f4791d;
        if (i < 0 || i >= h0Var.b()) {
            return;
        }
        hVar.b(i, Math.max(0, c0369c.f4793g));
    }

    public final int F0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        J0();
        g gVar = this.f1866r;
        boolean z2 = !this.f1871w;
        return AbstractC0371b.c(h0Var, gVar, M0(z2), L0(z2), this, this.f1871w);
    }

    public final int G0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        J0();
        g gVar = this.f1866r;
        boolean z2 = !this.f1871w;
        return AbstractC0371b.d(h0Var, gVar, M0(z2), L0(z2), this, this.f1871w, this.f1869u);
    }

    public final int H0(h0 h0Var) {
        if (v() == 0) {
            return 0;
        }
        J0();
        g gVar = this.f1866r;
        boolean z2 = !this.f1871w;
        return AbstractC0371b.e(h0Var, gVar, M0(z2), L0(z2), this, this.f1871w);
    }

    public final int I0(int i) {
        return i != 1 ? i != 2 ? i != 17 ? i != 33 ? i != 66 ? (i == 130 && this.f1864p == 1) ? 1 : Integer.MIN_VALUE : this.f1864p == 0 ? 1 : Integer.MIN_VALUE : this.f1864p == 1 ? -1 : Integer.MIN_VALUE : this.f1864p == 0 ? -1 : Integer.MIN_VALUE : (this.f1864p != 1 && V0()) ? -1 : 1 : (this.f1864p != 1 && V0()) ? 1 : -1;
    }

    public final void J0() {
        if (this.f1865q == null) {
            C0369C c0369c = new C0369C();
            c0369c.f4788a = true;
            c0369c.f4794h = 0;
            c0369c.i = 0;
            c0369c.f4796k = null;
            this.f1865q = c0369c;
        }
    }

    @Override // p0.V
    public final boolean K() {
        return true;
    }

    public final int K0(b0 b0Var, C0369C c0369c, h0 h0Var, boolean z2) {
        int i;
        int i3 = c0369c.f4790c;
        int i4 = c0369c.f4793g;
        if (i4 != Integer.MIN_VALUE) {
            if (i3 < 0) {
                c0369c.f4793g = i4 + i3;
            }
            Y0(b0Var, c0369c);
        }
        int i5 = c0369c.f4790c + c0369c.f4794h;
        while (true) {
            if ((!c0369c.f4797l && i5 <= 0) || (i = c0369c.f4791d) < 0 || i >= h0Var.b()) {
                break;
            }
            C0368B c0368b = this.f1861B;
            c0368b.f4784a = 0;
            c0368b.f4785b = false;
            c0368b.f4786c = false;
            c0368b.f4787d = false;
            W0(b0Var, h0Var, c0369c, c0368b);
            if (!c0368b.f4785b) {
                int i6 = c0369c.f4789b;
                int i7 = c0368b.f4784a;
                c0369c.f4789b = (c0369c.f4792f * i7) + i6;
                if (!c0368b.f4786c || c0369c.f4796k != null || !h0Var.f4914g) {
                    c0369c.f4790c -= i7;
                    i5 -= i7;
                }
                int i8 = c0369c.f4793g;
                if (i8 != Integer.MIN_VALUE) {
                    int i9 = i8 + i7;
                    c0369c.f4793g = i9;
                    int i10 = c0369c.f4790c;
                    if (i10 < 0) {
                        c0369c.f4793g = i9 + i10;
                    }
                    Y0(b0Var, c0369c);
                }
                if (z2 && c0368b.f4787d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i3 - c0369c.f4790c;
    }

    @Override // p0.V
    public final boolean L() {
        return this.f1868t;
    }

    public final View L0(boolean z2) {
        return this.f1869u ? P0(0, v(), z2) : P0(v() - 1, -1, z2);
    }

    public final View M0(boolean z2) {
        return this.f1869u ? P0(v() - 1, -1, z2) : P0(0, v(), z2);
    }

    public final int N0() {
        View viewP0 = P0(v() - 1, -1, false);
        if (viewP0 == null) {
            return -1;
        }
        return V.G(viewP0);
    }

    public final View O0(int i, int i3) {
        int i4;
        int i5;
        J0();
        if (i3 <= i && i3 >= i) {
            return u(i);
        }
        if (this.f1866r.g(u(i)) < this.f1866r.m()) {
            i4 = 16644;
            i5 = 16388;
        } else {
            i4 = 4161;
            i5 = 4097;
        }
        return this.f1864p == 0 ? this.f4841c.x(i, i3, i4, i5) : this.f4842d.x(i, i3, i4, i5);
    }

    public final View P0(int i, int i3, boolean z2) {
        J0();
        int i4 = z2 ? 24579 : 320;
        return this.f1864p == 0 ? this.f4841c.x(i, i3, i4, 320) : this.f4842d.x(i, i3, i4, 320);
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0079  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public View Q0(b0 b0Var, h0 h0Var, boolean z2, boolean z3) {
        int i;
        int iV;
        int i3;
        J0();
        int iV2 = v();
        if (z3) {
            iV = v() - 1;
            i = -1;
            i3 = -1;
        } else {
            i = iV2;
            iV = 0;
            i3 = 1;
        }
        int iB = h0Var.b();
        int iM = this.f1866r.m();
        int i4 = this.f1866r.i();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (iV != i) {
            View viewU = u(iV);
            int iG = V.G(viewU);
            int iG2 = this.f1866r.g(viewU);
            int iD = this.f1866r.d(viewU);
            if (iG >= 0 && iG < iB) {
                if (!((W) viewU.getLayoutParams()).f4852a.i()) {
                    boolean z4 = iD <= iM && iG2 < iM;
                    boolean z5 = iG2 >= i4 && iD > i4;
                    if (!z4 && !z5) {
                        return viewU;
                    }
                    if (z2) {
                        if (z5) {
                            view2 = viewU;
                        } else if (view == null) {
                            view = viewU;
                        }
                    } else if (!z4) {
                        if (view == null) {
                        }
                    }
                } else if (view3 == null) {
                    view3 = viewU;
                }
            }
            iV += i3;
        }
        return view != null ? view : view2 != null ? view2 : view3;
    }

    public final int R0(int i, b0 b0Var, h0 h0Var, boolean z2) {
        int i3;
        int i4 = this.f1866r.i() - i;
        if (i4 <= 0) {
            return 0;
        }
        int i5 = -b1(-i4, b0Var, h0Var);
        int i6 = i + i5;
        if (!z2 || (i3 = this.f1866r.i() - i6) <= 0) {
            return i5;
        }
        this.f1866r.r(i3);
        return i3 + i5;
    }

    @Override // p0.V
    public final void S(RecyclerView recyclerView) {
    }

    public final int S0(int i, b0 b0Var, h0 h0Var, boolean z2) {
        int iM;
        int iM2 = i - this.f1866r.m();
        if (iM2 <= 0) {
            return 0;
        }
        int i3 = -b1(iM2, b0Var, h0Var);
        int i4 = i + i3;
        if (!z2 || (iM = i4 - this.f1866r.m()) <= 0) {
            return i3;
        }
        this.f1866r.r(-iM);
        return i3 - iM;
    }

    @Override // p0.V
    public View T(View view, int i, b0 b0Var, h0 h0Var) {
        int iI0;
        a1();
        if (v() == 0 || (iI0 = I0(i)) == Integer.MIN_VALUE) {
            return null;
        }
        J0();
        e1(iI0, (int) (this.f1866r.n() * 0.33333334f), false, h0Var);
        C0369C c0369c = this.f1865q;
        c0369c.f4793g = Integer.MIN_VALUE;
        c0369c.f4788a = false;
        K0(b0Var, c0369c, h0Var, true);
        View viewO0 = iI0 == -1 ? this.f1869u ? O0(v() - 1, -1) : O0(0, v()) : this.f1869u ? O0(0, v()) : O0(v() - 1, -1);
        View viewU0 = iI0 == -1 ? U0() : T0();
        if (!viewU0.hasFocusable()) {
            return viewO0;
        }
        if (viewO0 == null) {
            return null;
        }
        return viewU0;
    }

    public final View T0() {
        return u(this.f1869u ? 0 : v() - 1);
    }

    @Override // p0.V
    public final void U(AccessibilityEvent accessibilityEvent) {
        super.U(accessibilityEvent);
        if (v() > 0) {
            View viewP0 = P0(0, v(), false);
            accessibilityEvent.setFromIndex(viewP0 == null ? -1 : V.G(viewP0));
            accessibilityEvent.setToIndex(N0());
        }
    }

    public final View U0() {
        return u(this.f1869u ? v() - 1 : 0);
    }

    @Override // p0.V
    public void V(b0 b0Var, h0 h0Var, Q.g gVar) {
        super.V(b0Var, h0Var, gVar);
        L l3 = this.f4840b.f1929n;
        if (l3 == null || l3.a() <= 0) {
            return;
        }
        gVar.b(e.f990m);
    }

    public final boolean V0() {
        return this.f4840b.getLayoutDirection() == 1;
    }

    public void W0(b0 b0Var, h0 h0Var, C0369C c0369c, C0368B c0368b) {
        int iD;
        int i;
        int i3;
        int iF;
        View viewB = c0369c.b(b0Var);
        if (viewB == null) {
            c0368b.f4785b = true;
            return;
        }
        W w2 = (W) viewB.getLayoutParams();
        if (c0369c.f4796k == null) {
            if (this.f1869u == (c0369c.f4792f == -1)) {
                b(viewB, -1, false);
            } else {
                b(viewB, 0, false);
            }
        } else {
            if (this.f1869u == (c0369c.f4792f == -1)) {
                b(viewB, -1, true);
            } else {
                b(viewB, 0, true);
            }
        }
        W w3 = (W) viewB.getLayoutParams();
        Rect rectN = this.f4840b.N(viewB);
        int i4 = rectN.left + rectN.right;
        int i5 = rectN.top + rectN.bottom;
        int iW = V.w(d(), this.f4850n, this.f4848l, E() + D() + ((ViewGroup.MarginLayoutParams) w3).leftMargin + ((ViewGroup.MarginLayoutParams) w3).rightMargin + i4, ((ViewGroup.MarginLayoutParams) w3).width);
        int iW2 = V.w(e(), this.f4851o, this.f4849m, C() + F() + ((ViewGroup.MarginLayoutParams) w3).topMargin + ((ViewGroup.MarginLayoutParams) w3).bottomMargin + i5, ((ViewGroup.MarginLayoutParams) w3).height);
        if (x0(viewB, iW, iW2, w3)) {
            viewB.measure(iW, iW2);
        }
        c0368b.f4784a = this.f1866r.e(viewB);
        if (this.f1864p == 1) {
            if (V0()) {
                iF = this.f4850n - E();
                iD = iF - this.f1866r.f(viewB);
            } else {
                iD = D();
                iF = this.f1866r.f(viewB) + iD;
            }
            if (c0369c.f4792f == -1) {
                i = c0369c.f4789b;
                i3 = i - c0368b.f4784a;
            } else {
                i3 = c0369c.f4789b;
                i = c0368b.f4784a + i3;
            }
        } else {
            int iF2 = F();
            int iF3 = this.f1866r.f(viewB) + iF2;
            if (c0369c.f4792f == -1) {
                int i6 = c0369c.f4789b;
                int i7 = i6 - c0368b.f4784a;
                iF = i6;
                i = iF3;
                iD = i7;
                i3 = iF2;
            } else {
                int i8 = c0369c.f4789b;
                int i9 = c0368b.f4784a + i8;
                iD = i8;
                i = iF3;
                i3 = iF2;
                iF = i9;
            }
        }
        V.N(viewB, iD, i3, iF, i);
        if (w2.f4852a.i() || w2.f4852a.l()) {
            c0368b.f4786c = true;
        }
        c0368b.f4787d = viewB.hasFocusable();
    }

    public void X0(b0 b0Var, h0 h0Var, C0367A c0367a, int i) {
    }

    public final void Y0(b0 b0Var, C0369C c0369c) {
        if (!c0369c.f4788a || c0369c.f4797l) {
            return;
        }
        int i = c0369c.f4793g;
        int i3 = c0369c.i;
        if (c0369c.f4792f == -1) {
            int iV = v();
            if (i < 0) {
                return;
            }
            int iH = (this.f1866r.h() - i) + i3;
            if (this.f1869u) {
                for (int i4 = 0; i4 < iV; i4++) {
                    View viewU = u(i4);
                    if (this.f1866r.g(viewU) < iH || this.f1866r.q(viewU) < iH) {
                        Z0(b0Var, 0, i4);
                        return;
                    }
                }
                return;
            }
            int i5 = iV - 1;
            for (int i6 = i5; i6 >= 0; i6--) {
                View viewU2 = u(i6);
                if (this.f1866r.g(viewU2) < iH || this.f1866r.q(viewU2) < iH) {
                    Z0(b0Var, i5, i6);
                    return;
                }
            }
            return;
        }
        if (i < 0) {
            return;
        }
        int i7 = i - i3;
        int iV2 = v();
        if (!this.f1869u) {
            for (int i8 = 0; i8 < iV2; i8++) {
                View viewU3 = u(i8);
                if (this.f1866r.d(viewU3) > i7 || this.f1866r.p(viewU3) > i7) {
                    Z0(b0Var, 0, i8);
                    return;
                }
            }
            return;
        }
        int i9 = iV2 - 1;
        for (int i10 = i9; i10 >= 0; i10--) {
            View viewU4 = u(i10);
            if (this.f1866r.d(viewU4) > i7 || this.f1866r.p(viewU4) > i7) {
                Z0(b0Var, i9, i10);
                return;
            }
        }
    }

    public final void Z0(b0 b0Var, int i, int i3) {
        if (i == i3) {
            return;
        }
        if (i3 <= i) {
            while (i > i3) {
                View viewU = u(i);
                m0(i);
                b0Var.h(viewU);
                i--;
            }
            return;
        }
        for (int i4 = i3 - 1; i4 >= i; i4--) {
            View viewU2 = u(i4);
            m0(i4);
            b0Var.h(viewU2);
        }
    }

    @Override // p0.g0
    public final PointF a(int i) {
        if (v() == 0) {
            return null;
        }
        int i3 = (i < V.G(u(0))) != this.f1869u ? -1 : 1;
        return this.f1864p == 0 ? new PointF(i3, 0.0f) : new PointF(0.0f, i3);
    }

    public final void a1() {
        if (this.f1864p == 1 || !V0()) {
            this.f1869u = this.f1868t;
        } else {
            this.f1869u = !this.f1868t;
        }
    }

    public final int b1(int i, b0 b0Var, h0 h0Var) {
        if (v() == 0 || i == 0) {
            return 0;
        }
        J0();
        this.f1865q.f4788a = true;
        int i3 = i > 0 ? 1 : -1;
        int iAbs = Math.abs(i);
        e1(i3, iAbs, true, h0Var);
        C0369C c0369c = this.f1865q;
        int iK0 = K0(b0Var, c0369c, h0Var, false) + c0369c.f4793g;
        if (iK0 < 0) {
            return 0;
        }
        if (iAbs > iK0) {
            i = i3 * iK0;
        }
        this.f1866r.r(-i);
        this.f1865q.f4795j = i;
        return i;
    }

    @Override // p0.V
    public final void c(String str) {
        if (this.f1874z == null) {
            super.c(str);
        }
    }

    public final void c1(int i) {
        if (i != 0 && i != 1) {
            throw new IllegalArgumentException(H.e.g("invalid orientation:", i));
        }
        c(null);
        if (i != this.f1864p || this.f1866r == null) {
            g gVarB = g.b(this, i);
            this.f1866r = gVarB;
            this.f1860A.f4780a = gVarB;
            this.f1864p = i;
            o0();
        }
    }

    @Override // p0.V
    public final boolean d() {
        return this.f1864p == 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:107:0x01ce  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0220  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x018a  */
    @Override // p0.V
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void d0(b0 b0Var, h0 h0Var) {
        View focusedChild;
        View focusedChild2;
        View viewQ0;
        int i;
        int i3;
        int i4;
        List list;
        int i5;
        int i6;
        int iR0;
        int i7;
        View viewQ;
        int iG;
        int i8;
        int i9;
        int i10 = -1;
        if (!(this.f1874z == null && this.f1872x == -1) && h0Var.b() == 0) {
            j0(b0Var);
            return;
        }
        D d3 = this.f1874z;
        if (d3 != null && (i9 = d3.f4798b) >= 0) {
            this.f1872x = i9;
        }
        J0();
        this.f1865q.f4788a = false;
        a1();
        RecyclerView recyclerView = this.f4840b;
        if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.f4839a.f4904c.contains(focusedChild)) {
            focusedChild = null;
        }
        C0367A c0367a = this.f1860A;
        if (!c0367a.e || this.f1872x != -1 || this.f1874z != null) {
            c0367a.d();
            c0367a.f4783d = this.f1869u ^ this.f1870v;
            if (h0Var.f4914g || (i = this.f1872x) == -1) {
                if (v() != 0) {
                    RecyclerView recyclerView2 = this.f4840b;
                    if (recyclerView2 == null || (focusedChild2 = recyclerView2.getFocusedChild()) == null || this.f4839a.f4904c.contains(focusedChild2)) {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        W w2 = (W) focusedChild2.getLayoutParams();
                        if (w2.f4852a.i() || w2.f4852a.b() < 0 || w2.f4852a.b() >= h0Var.b()) {
                            boolean z2 = this.f1867s;
                            boolean z3 = this.f1870v;
                            if (z2 == z3 && (viewQ0 = Q0(b0Var, h0Var, c0367a.f4783d, z3)) != null) {
                                c0367a.b(viewQ0, V.G(viewQ0));
                                if (!h0Var.f4914g && C0()) {
                                    int iG2 = this.f1866r.g(viewQ0);
                                    int iD = this.f1866r.d(viewQ0);
                                    int iM = this.f1866r.m();
                                    int i11 = this.f1866r.i();
                                    boolean z4 = iD <= iM && iG2 < iM;
                                    boolean z5 = iG2 >= i11 && iD > i11;
                                    if (z4 || z5) {
                                        if (c0367a.f4783d) {
                                            iM = i11;
                                        }
                                        c0367a.f4782c = iM;
                                    }
                                }
                            } else {
                                c0367a.a();
                                c0367a.f4781b = this.f1870v ? h0Var.b() - 1 : 0;
                            }
                        } else {
                            c0367a.c(focusedChild2, V.G(focusedChild2));
                        }
                        c0367a.e = true;
                    }
                }
            } else if (i < 0 || i >= h0Var.b()) {
                this.f1872x = -1;
                this.f1873y = Integer.MIN_VALUE;
                if (v() != 0) {
                }
            } else {
                int i12 = this.f1872x;
                c0367a.f4781b = i12;
                D d4 = this.f1874z;
                if (d4 != null && d4.f4798b >= 0) {
                    boolean z6 = d4.f4800d;
                    c0367a.f4783d = z6;
                    if (z6) {
                        c0367a.f4782c = this.f1866r.i() - this.f1874z.f4799c;
                    } else {
                        c0367a.f4782c = this.f1866r.m() + this.f1874z.f4799c;
                    }
                } else if (this.f1873y == Integer.MIN_VALUE) {
                    View viewQ2 = q(i12);
                    if (viewQ2 == null) {
                        if (v() > 0) {
                            c0367a.f4783d = (this.f1872x < V.G(u(0))) == this.f1869u;
                        }
                        c0367a.a();
                    } else if (this.f1866r.e(viewQ2) > this.f1866r.n()) {
                        c0367a.a();
                    } else if (this.f1866r.g(viewQ2) - this.f1866r.m() < 0) {
                        c0367a.f4782c = this.f1866r.m();
                        c0367a.f4783d = false;
                    } else if (this.f1866r.i() - this.f1866r.d(viewQ2) < 0) {
                        c0367a.f4782c = this.f1866r.i();
                        c0367a.f4783d = true;
                    } else {
                        c0367a.f4782c = c0367a.f4783d ? this.f1866r.o() + this.f1866r.d(viewQ2) : this.f1866r.g(viewQ2);
                    }
                } else {
                    boolean z7 = this.f1869u;
                    c0367a.f4783d = z7;
                    if (z7) {
                        c0367a.f4782c = this.f1866r.i() - this.f1873y;
                    } else {
                        c0367a.f4782c = this.f1866r.m() + this.f1873y;
                    }
                }
                c0367a.e = true;
            }
        } else if (focusedChild != null && (this.f1866r.g(focusedChild) >= this.f1866r.i() || this.f1866r.d(focusedChild) <= this.f1866r.m())) {
            c0367a.c(focusedChild, V.G(focusedChild));
        }
        C0369C c0369c = this.f1865q;
        c0369c.f4792f = c0369c.f4795j >= 0 ? 1 : -1;
        int[] iArr = this.f1863D;
        iArr[0] = 0;
        iArr[1] = 0;
        D0(h0Var, iArr);
        int iM2 = this.f1866r.m() + Math.max(0, iArr[0]);
        int iJ = this.f1866r.j() + Math.max(0, iArr[1]);
        if (h0Var.f4914g && (i7 = this.f1872x) != -1 && this.f1873y != Integer.MIN_VALUE && (viewQ = q(i7)) != null) {
            if (this.f1869u) {
                i8 = this.f1866r.i() - this.f1866r.d(viewQ);
                iG = this.f1873y;
            } else {
                iG = this.f1866r.g(viewQ) - this.f1866r.m();
                i8 = this.f1873y;
            }
            int i13 = i8 - iG;
            if (i13 > 0) {
                iM2 += i13;
            } else {
                iJ -= i13;
            }
        }
        if (!c0367a.f4783d ? !this.f1869u : this.f1869u) {
            i10 = 1;
        }
        X0(b0Var, h0Var, c0367a, i10);
        p(b0Var);
        this.f1865q.f4797l = this.f1866r.k() == 0 && this.f1866r.h() == 0;
        this.f1865q.getClass();
        this.f1865q.i = 0;
        if (c0367a.f4783d) {
            g1(c0367a.f4781b, c0367a.f4782c);
            C0369C c0369c2 = this.f1865q;
            c0369c2.f4794h = iM2;
            K0(b0Var, c0369c2, h0Var, false);
            C0369C c0369c3 = this.f1865q;
            i4 = c0369c3.f4789b;
            int i14 = c0369c3.f4791d;
            int i15 = c0369c3.f4790c;
            if (i15 > 0) {
                iJ += i15;
            }
            f1(c0367a.f4781b, c0367a.f4782c);
            C0369C c0369c4 = this.f1865q;
            c0369c4.f4794h = iJ;
            c0369c4.f4791d += c0369c4.e;
            K0(b0Var, c0369c4, h0Var, false);
            C0369C c0369c5 = this.f1865q;
            i3 = c0369c5.f4789b;
            int i16 = c0369c5.f4790c;
            if (i16 > 0) {
                g1(i14, i4);
                C0369C c0369c6 = this.f1865q;
                c0369c6.f4794h = i16;
                K0(b0Var, c0369c6, h0Var, false);
                i4 = this.f1865q.f4789b;
            }
        } else {
            f1(c0367a.f4781b, c0367a.f4782c);
            C0369C c0369c7 = this.f1865q;
            c0369c7.f4794h = iJ;
            K0(b0Var, c0369c7, h0Var, false);
            C0369C c0369c8 = this.f1865q;
            i3 = c0369c8.f4789b;
            int i17 = c0369c8.f4791d;
            int i18 = c0369c8.f4790c;
            if (i18 > 0) {
                iM2 += i18;
            }
            g1(c0367a.f4781b, c0367a.f4782c);
            C0369C c0369c9 = this.f1865q;
            c0369c9.f4794h = iM2;
            c0369c9.f4791d += c0369c9.e;
            K0(b0Var, c0369c9, h0Var, false);
            C0369C c0369c10 = this.f1865q;
            int i19 = c0369c10.f4789b;
            int i20 = c0369c10.f4790c;
            if (i20 > 0) {
                f1(i17, i3);
                C0369C c0369c11 = this.f1865q;
                c0369c11.f4794h = i20;
                K0(b0Var, c0369c11, h0Var, false);
                i3 = this.f1865q.f4789b;
            }
            i4 = i19;
        }
        if (v() > 0) {
            if (this.f1869u ^ this.f1870v) {
                int iR02 = R0(i3, b0Var, h0Var, true);
                i5 = i4 + iR02;
                i6 = i3 + iR02;
                iR0 = S0(i5, b0Var, h0Var, false);
            } else {
                int iS0 = S0(i4, b0Var, h0Var, true);
                i5 = i4 + iS0;
                i6 = i3 + iS0;
                iR0 = R0(i6, b0Var, h0Var, false);
            }
            i4 = i5 + iR0;
            i3 = i6 + iR0;
        }
        if (h0Var.f4917k && v() != 0 && !h0Var.f4914g && C0()) {
            List list2 = b0Var.f4873d;
            int size = list2.size();
            int iG3 = V.G(u(0));
            int iE = 0;
            int iE2 = 0;
            for (int i21 = 0; i21 < size; i21++) {
                l0 l0Var = (l0) list2.get(i21);
                if (!l0Var.i()) {
                    boolean z8 = l0Var.b() < iG3;
                    boolean z9 = this.f1869u;
                    View view = l0Var.f4946a;
                    if (z8 != z9) {
                        iE += this.f1866r.e(view);
                    } else {
                        iE2 += this.f1866r.e(view);
                    }
                }
            }
            this.f1865q.f4796k = list2;
            if (iE > 0) {
                g1(V.G(U0()), i4);
                C0369C c0369c12 = this.f1865q;
                c0369c12.f4794h = iE;
                c0369c12.f4790c = 0;
                c0369c12.a(null);
                K0(b0Var, this.f1865q, h0Var, false);
            }
            if (iE2 > 0) {
                f1(V.G(T0()), i3);
                C0369C c0369c13 = this.f1865q;
                c0369c13.f4794h = iE2;
                c0369c13.f4790c = 0;
                list = null;
                c0369c13.a(null);
                K0(b0Var, this.f1865q, h0Var, false);
            } else {
                list = null;
            }
            this.f1865q.f4796k = list;
        }
        if (h0Var.f4914g) {
            c0367a.d();
        } else {
            g gVar = this.f1866r;
            gVar.f1374a = gVar.n();
        }
        this.f1867s = this.f1870v;
    }

    public void d1(boolean z2) {
        c(null);
        if (this.f1870v == z2) {
            return;
        }
        this.f1870v = z2;
        o0();
    }

    @Override // p0.V
    public final boolean e() {
        return this.f1864p == 1;
    }

    @Override // p0.V
    public void e0(h0 h0Var) {
        this.f1874z = null;
        this.f1872x = -1;
        this.f1873y = Integer.MIN_VALUE;
        this.f1860A.d();
    }

    public final void e1(int i, int i3, boolean z2, h0 h0Var) {
        int iM;
        this.f1865q.f4797l = this.f1866r.k() == 0 && this.f1866r.h() == 0;
        this.f1865q.f4792f = i;
        int[] iArr = this.f1863D;
        iArr[0] = 0;
        iArr[1] = 0;
        D0(h0Var, iArr);
        int iMax = Math.max(0, iArr[0]);
        int iMax2 = Math.max(0, iArr[1]);
        boolean z3 = i == 1;
        C0369C c0369c = this.f1865q;
        int i4 = z3 ? iMax2 : iMax;
        c0369c.f4794h = i4;
        if (!z3) {
            iMax = iMax2;
        }
        c0369c.i = iMax;
        if (z3) {
            c0369c.f4794h = this.f1866r.j() + i4;
            View viewT0 = T0();
            C0369C c0369c2 = this.f1865q;
            c0369c2.e = this.f1869u ? -1 : 1;
            int iG = V.G(viewT0);
            C0369C c0369c3 = this.f1865q;
            c0369c2.f4791d = iG + c0369c3.e;
            c0369c3.f4789b = this.f1866r.d(viewT0);
            iM = this.f1866r.d(viewT0) - this.f1866r.i();
        } else {
            View viewU0 = U0();
            C0369C c0369c4 = this.f1865q;
            c0369c4.f4794h = this.f1866r.m() + c0369c4.f4794h;
            C0369C c0369c5 = this.f1865q;
            c0369c5.e = this.f1869u ? 1 : -1;
            int iG2 = V.G(viewU0);
            C0369C c0369c6 = this.f1865q;
            c0369c5.f4791d = iG2 + c0369c6.e;
            c0369c6.f4789b = this.f1866r.g(viewU0);
            iM = (-this.f1866r.g(viewU0)) + this.f1866r.m();
        }
        C0369C c0369c7 = this.f1865q;
        c0369c7.f4790c = i3;
        if (z2) {
            c0369c7.f4790c = i3 - iM;
        }
        c0369c7.f4793g = iM;
    }

    @Override // p0.V
    public final void f0(Parcelable parcelable) {
        if (parcelable instanceof D) {
            D d3 = (D) parcelable;
            this.f1874z = d3;
            if (this.f1872x != -1) {
                d3.f4798b = -1;
            }
            o0();
        }
    }

    public final void f1(int i, int i3) {
        this.f1865q.f4790c = this.f1866r.i() - i3;
        C0369C c0369c = this.f1865q;
        c0369c.e = this.f1869u ? -1 : 1;
        c0369c.f4791d = i;
        c0369c.f4792f = 1;
        c0369c.f4789b = i3;
        c0369c.f4793g = Integer.MIN_VALUE;
    }

    @Override // p0.V
    public final Parcelable g0() {
        D d3 = this.f1874z;
        if (d3 != null) {
            D d4 = new D();
            d4.f4798b = d3.f4798b;
            d4.f4799c = d3.f4799c;
            d4.f4800d = d3.f4800d;
            return d4;
        }
        D d5 = new D();
        if (v() > 0) {
            J0();
            boolean z2 = this.f1867s ^ this.f1869u;
            d5.f4800d = z2;
            if (z2) {
                View viewT0 = T0();
                d5.f4799c = this.f1866r.i() - this.f1866r.d(viewT0);
                d5.f4798b = V.G(viewT0);
            } else {
                View viewU0 = U0();
                d5.f4798b = V.G(viewU0);
                d5.f4799c = this.f1866r.g(viewU0) - this.f1866r.m();
            }
        } else {
            d5.f4798b = -1;
        }
        return d5;
    }

    public final void g1(int i, int i3) {
        this.f1865q.f4790c = i3 - this.f1866r.m();
        C0369C c0369c = this.f1865q;
        c0369c.f4791d = i;
        c0369c.e = this.f1869u ? 1 : -1;
        c0369c.f4792f = -1;
        c0369c.f4789b = i3;
        c0369c.f4793g = Integer.MIN_VALUE;
    }

    @Override // p0.V
    public final void h(int i, int i3, h0 h0Var, h hVar) {
        if (this.f1864p != 0) {
            i = i3;
        }
        if (v() == 0 || i == 0) {
            return;
        }
        J0();
        e1(i > 0 ? 1 : -1, Math.abs(i), true, h0Var);
        E0(h0Var, this.f1865q, hVar);
    }

    @Override // p0.V
    public final void i(int i, h hVar) {
        boolean z2;
        int i3;
        D d3 = this.f1874z;
        if (d3 == null || (i3 = d3.f4798b) < 0) {
            a1();
            z2 = this.f1869u;
            i3 = this.f1872x;
            if (i3 == -1) {
                i3 = z2 ? i - 1 : 0;
            }
        } else {
            z2 = d3.f4800d;
        }
        int i4 = z2 ? -1 : 1;
        for (int i5 = 0; i5 < this.f1862C && i3 >= 0 && i3 < i; i5++) {
            hVar.b(i3, 0);
            i3 += i4;
        }
    }

    @Override // p0.V
    public boolean i0(int i, Bundle bundle) {
        int iMin;
        if (super.i0(i, bundle)) {
            return true;
        }
        if (i == 16908343 && bundle != null) {
            if (this.f1864p == 1) {
                int i3 = bundle.getInt("android.view.accessibility.action.ARGUMENT_ROW_INT", -1);
                if (i3 < 0) {
                    return false;
                }
                RecyclerView recyclerView = this.f4840b;
                iMin = Math.min(i3, I(recyclerView.f1911d, recyclerView.f1919h0) - 1);
            } else {
                int i4 = bundle.getInt("android.view.accessibility.action.ARGUMENT_COLUMN_INT", -1);
                if (i4 < 0) {
                    return false;
                }
                RecyclerView recyclerView2 = this.f4840b;
                iMin = Math.min(i4, x(recyclerView2.f1911d, recyclerView2.f1919h0) - 1);
            }
            if (iMin >= 0) {
                this.f1872x = iMin;
                this.f1873y = 0;
                D d3 = this.f1874z;
                if (d3 != null) {
                    d3.f4798b = -1;
                }
                o0();
                return true;
            }
        }
        return false;
    }

    @Override // p0.V
    public final int j(h0 h0Var) {
        return F0(h0Var);
    }

    @Override // p0.V
    public int k(h0 h0Var) {
        return G0(h0Var);
    }

    @Override // p0.V
    public int l(h0 h0Var) {
        return H0(h0Var);
    }

    @Override // p0.V
    public final int m(h0 h0Var) {
        return F0(h0Var);
    }

    @Override // p0.V
    public int n(h0 h0Var) {
        return G0(h0Var);
    }

    @Override // p0.V
    public int o(h0 h0Var) {
        return H0(h0Var);
    }

    @Override // p0.V
    public int p0(int i, b0 b0Var, h0 h0Var) {
        if (this.f1864p == 1) {
            return 0;
        }
        return b1(i, b0Var, h0Var);
    }

    @Override // p0.V
    public final View q(int i) {
        int iV = v();
        if (iV == 0) {
            return null;
        }
        int iG = i - V.G(u(0));
        if (iG >= 0 && iG < iV) {
            View viewU = u(iG);
            if (V.G(viewU) == i) {
                return viewU;
            }
        }
        return super.q(i);
    }

    @Override // p0.V
    public final void q0(int i) {
        this.f1872x = i;
        this.f1873y = Integer.MIN_VALUE;
        D d3 = this.f1874z;
        if (d3 != null) {
            d3.f4798b = -1;
        }
        o0();
    }

    @Override // p0.V
    public W r() {
        return new W(-2, -2);
    }

    @Override // p0.V
    public int r0(int i, b0 b0Var, h0 h0Var) {
        if (this.f1864p == 0) {
            return 0;
        }
        return b1(i, b0Var, h0Var);
    }

    @Override // p0.V
    public final boolean y0() {
        if (this.f4849m == 1073741824 || this.f4848l == 1073741824) {
            return false;
        }
        int iV = v();
        for (int i = 0; i < iV; i++) {
            ViewGroup.LayoutParams layoutParams = u(i).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
                return true;
            }
        }
        return false;
    }

    @SuppressLint({"UnknownNullness"})
    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i3) {
        this.f1864p = 1;
        this.f1868t = false;
        this.f1869u = false;
        this.f1870v = false;
        this.f1871w = true;
        this.f1872x = -1;
        this.f1873y = Integer.MIN_VALUE;
        this.f1874z = null;
        this.f1860A = new C0367A();
        this.f1861B = new C0368B();
        this.f1862C = 2;
        this.f1863D = new int[2];
        U uH = V.H(context, attributeSet, i, i3);
        c1(uH.f4835a);
        boolean z2 = uH.f4837c;
        c(null);
        if (z2 != this.f1868t) {
            this.f1868t = z2;
            o0();
        }
        d1(uH.f4838d);
    }
}
