package androidx.drawerlayout.widget;

import A0.f;
import P.C0023k;
import P.G;
import P.O;
import P.u0;
import S.e;
import V.d;
import X.a;
import X.b;
import X.c;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.Objects;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class DrawerLayout extends ViewGroup implements d {

    /* renamed from: E, reason: collision with root package name */
    public static final int[] f1705E = {R.attr.colorPrimaryDark};
    public static final int[] F = {R.attr.layout_gravity};

    /* renamed from: G, reason: collision with root package name */
    public static final boolean f1706G;

    /* renamed from: H, reason: collision with root package name */
    public static final boolean f1707H;

    /* renamed from: I, reason: collision with root package name */
    public static final boolean f1708I;

    /* renamed from: A, reason: collision with root package name */
    public final ArrayList f1709A;

    /* renamed from: B, reason: collision with root package name */
    public Rect f1710B;

    /* renamed from: C, reason: collision with root package name */
    public Matrix f1711C;

    /* renamed from: D, reason: collision with root package name */
    public final f f1712D;

    /* renamed from: b, reason: collision with root package name */
    public final e f1713b;

    /* renamed from: c, reason: collision with root package name */
    public float f1714c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1715d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public float f1716f;

    /* renamed from: g, reason: collision with root package name */
    public final Paint f1717g;

    /* renamed from: h, reason: collision with root package name */
    public final V.f f1718h;
    public final V.f i;

    /* renamed from: j, reason: collision with root package name */
    public final X.f f1719j;

    /* renamed from: k, reason: collision with root package name */
    public final X.f f1720k;

    /* renamed from: l, reason: collision with root package name */
    public int f1721l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1722m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f1723n;

    /* renamed from: o, reason: collision with root package name */
    public int f1724o;

    /* renamed from: p, reason: collision with root package name */
    public int f1725p;

    /* renamed from: q, reason: collision with root package name */
    public int f1726q;

    /* renamed from: r, reason: collision with root package name */
    public int f1727r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f1728s;

    /* renamed from: t, reason: collision with root package name */
    public c f1729t;

    /* renamed from: u, reason: collision with root package name */
    public ArrayList f1730u;

    /* renamed from: v, reason: collision with root package name */
    public float f1731v;

    /* renamed from: w, reason: collision with root package name */
    public float f1732w;

    /* renamed from: x, reason: collision with root package name */
    public Drawable f1733x;

    /* renamed from: y, reason: collision with root package name */
    public WindowInsets f1734y;

    /* renamed from: z, reason: collision with root package name */
    public boolean f1735z;

    static {
        int i = Build.VERSION.SDK_INT;
        f1706G = true;
        f1707H = true;
        f1708I = i >= 29;
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.drawerLayoutStyle);
        this.f1713b = new e(1);
        this.e = -1728053248;
        this.f1717g = new Paint();
        this.f1723n = true;
        this.f1724o = 3;
        this.f1725p = 3;
        this.f1726q = 3;
        this.f1727r = 3;
        this.f1712D = new f(14, this);
        setDescendantFocusability(262144);
        float f3 = getResources().getDisplayMetrics().density;
        this.f1715d = (int) ((64.0f * f3) + 0.5f);
        float f4 = f3 * 400.0f;
        X.f fVar = new X.f(this, 3);
        this.f1719j = fVar;
        X.f fVar2 = new X.f(this, 5);
        this.f1720k = fVar2;
        V.f fVar3 = new V.f(getContext(), this, fVar);
        fVar3.f1167b = (int) (fVar3.f1167b * 1.0f);
        this.f1718h = fVar3;
        fVar3.f1180q = 1;
        fVar3.f1177n = f4;
        fVar.f1203f = fVar3;
        V.f fVar4 = new V.f(getContext(), this, fVar2);
        fVar4.f1167b = (int) (1.0f * fVar4.f1167b);
        this.i = fVar4;
        fVar4.f1180q = 2;
        fVar4.f1177n = f4;
        fVar2.f1203f = fVar4;
        setFocusableInTouchMode(true);
        WeakHashMap weakHashMap = O.f854a;
        setImportantForAccessibility(1);
        O.m(this, new b(this));
        setMotionEventSplittingEnabled(false);
        if (getFitsSystemWindows()) {
            setOnApplyWindowInsetsListener(new a());
            setSystemUiVisibility(1280);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(f1705E);
            try {
                this.f1733x = typedArrayObtainStyledAttributes.getDrawable(0);
            } finally {
                typedArrayObtainStyledAttributes.recycle();
            }
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, W.a.f1187a, com.kortosi.kluani.qorzanis.R.attr.drawerLayoutStyle, 0);
        try {
            if (typedArrayObtainStyledAttributes2.hasValue(0)) {
                this.f1714c = typedArrayObtainStyledAttributes2.getDimension(0, 0.0f);
            } else {
                this.f1714c = getResources().getDimension(com.kortosi.kluani.qorzanis.R.dimen.def_drawer_elevation);
            }
            typedArrayObtainStyledAttributes2.recycle();
            this.f1709A = new ArrayList();
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes2.recycle();
            throw th;
        }
    }

    public static String j(int i) {
        return (i & 3) == 3 ? "LEFT" : (i & 5) == 5 ? "RIGHT" : Integer.toHexString(i);
    }

    public static boolean k(View view) {
        WeakHashMap weakHashMap = O.f854a;
        return (view.getImportantForAccessibility() == 4 || view.getImportantForAccessibility() == 2) ? false : true;
    }

    public static boolean l(View view) {
        return ((X.d) view.getLayoutParams()).f1195a == 0;
    }

    public static boolean m(View view) {
        if (n(view)) {
            return (((X.d) view.getLayoutParams()).f1198d & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public static boolean n(View view) {
        int i = ((X.d) view.getLayoutParams()).f1195a;
        WeakHashMap weakHashMap = O.f854a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, view.getLayoutDirection());
        return ((absoluteGravity & 3) == 0 && (absoluteGravity & 5) == 0) ? false : true;
    }

    public final boolean a(View view, int i) {
        return (i(view) & i) == i;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i, int i3) {
        ArrayList arrayList2;
        if (getDescendantFocusability() == 393216) {
            return;
        }
        int childCount = getChildCount();
        int i4 = 0;
        boolean z2 = false;
        while (true) {
            arrayList2 = this.f1709A;
            if (i4 >= childCount) {
                break;
            }
            View childAt = getChildAt(i4);
            if (!n(childAt)) {
                arrayList2.add(childAt);
            } else if (m(childAt)) {
                childAt.addFocusables(arrayList, i, i3);
                z2 = true;
            }
            i4++;
        }
        if (!z2) {
            int size = arrayList2.size();
            for (int i5 = 0; i5 < size; i5++) {
                View view = (View) arrayList2.get(i5);
                if (view.getVisibility() == 0) {
                    view.addFocusables(arrayList, i, i3);
                }
            }
        }
        arrayList2.clear();
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (f() != null || n(view)) {
            WeakHashMap weakHashMap = O.f854a;
            view.setImportantForAccessibility(4);
        } else {
            WeakHashMap weakHashMap2 = O.f854a;
            view.setImportantForAccessibility(1);
        }
        if (f1706G) {
            return;
        }
        O.m(view, this.f1713b);
    }

    public final void b(View view, boolean z2) {
        if (!n(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        X.d dVar = (X.d) view.getLayoutParams();
        if (this.f1723n) {
            dVar.f1196b = 0.0f;
            dVar.f1198d = 0;
        } else if (z2) {
            dVar.f1198d |= 4;
            if (a(view, 3)) {
                this.f1718h.s(view, -view.getWidth(), view.getTop());
            } else {
                this.i.s(view, getWidth(), view.getTop());
            }
        } else {
            float f3 = ((X.d) view.getLayoutParams()).f1196b;
            float width = view.getWidth();
            int i = ((int) (width * 0.0f)) - ((int) (f3 * width));
            if (!a(view, 3)) {
                i = -i;
            }
            view.offsetLeftAndRight(i);
            q(view, 0.0f);
            t(view, 0);
            view.setVisibility(4);
        }
        invalidate();
    }

    public final void c() {
        View viewE = e(8388611);
        if (viewE != null) {
            b(viewE, true);
        } else {
            throw new IllegalArgumentException("No drawer view found with gravity " + j(8388611));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof X.d) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public final void computeScroll() {
        int childCount = getChildCount();
        float fMax = 0.0f;
        for (int i = 0; i < childCount; i++) {
            fMax = Math.max(fMax, ((X.d) getChildAt(i).getLayoutParams()).f1196b);
        }
        this.f1716f = fMax;
        boolean zG = this.f1718h.g();
        boolean zG2 = this.i.g();
        if (zG || zG2) {
            WeakHashMap weakHashMap = O.f854a;
            postInvalidateOnAnimation();
        }
    }

    public final void d(boolean z2) {
        int childCount = getChildCount();
        boolean zS = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            X.d dVar = (X.d) childAt.getLayoutParams();
            if (n(childAt) && (!z2 || dVar.f1197c)) {
                zS |= a(childAt, 3) ? this.f1718h.s(childAt, -childAt.getWidth(), childAt.getTop()) : this.i.s(childAt, getWidth(), childAt.getTop());
                dVar.f1197c = false;
            }
        }
        X.f fVar = this.f1719j;
        fVar.f1205h.removeCallbacks(fVar.f1204g);
        X.f fVar2 = this.f1720k;
        fVar2.f1205h.removeCallbacks(fVar2.f1204g);
        if (zS) {
            invalidate();
        }
    }

    @Override // android.view.View
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        boolean zDispatchGenericMotionEvent;
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f1716f <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x2 = motionEvent.getX();
        float y2 = motionEvent.getY();
        for (int i = childCount - 1; i >= 0; i--) {
            View childAt = getChildAt(i);
            if (this.f1710B == null) {
                this.f1710B = new Rect();
            }
            childAt.getHitRect(this.f1710B);
            if (this.f1710B.contains((int) x2, (int) y2) && !l(childAt)) {
                if (childAt.getMatrix().isIdentity()) {
                    float scrollX = getScrollX() - childAt.getLeft();
                    float scrollY = getScrollY() - childAt.getTop();
                    motionEvent.offsetLocation(scrollX, scrollY);
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEvent);
                    motionEvent.offsetLocation(-scrollX, -scrollY);
                } else {
                    float scrollX2 = getScrollX() - childAt.getLeft();
                    float scrollY2 = getScrollY() - childAt.getTop();
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(scrollX2, scrollY2);
                    Matrix matrix = childAt.getMatrix();
                    if (!matrix.isIdentity()) {
                        if (this.f1711C == null) {
                            this.f1711C = new Matrix();
                        }
                        matrix.invert(this.f1711C);
                        motionEventObtain.transform(this.f1711C);
                    }
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zDispatchGenericMotionEvent) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j3) {
        Drawable background;
        int height = getHeight();
        boolean zL = l(view);
        int width = getWidth();
        int iSave = canvas.save();
        int i = 0;
        if (zL) {
            int childCount = getChildCount();
            int i3 = 0;
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                if (childAt != view && childAt.getVisibility() == 0 && (background = childAt.getBackground()) != null && background.getOpacity() == -1 && n(childAt) && childAt.getHeight() >= height) {
                    if (a(childAt, 3)) {
                        int right = childAt.getRight();
                        if (right > i3) {
                            i3 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i3, 0, width, getHeight());
            i = i3;
        }
        boolean zDrawChild = super.drawChild(canvas, view, j3);
        canvas.restoreToCount(iSave);
        float f3 = this.f1716f;
        if (f3 > 0.0f && zL) {
            int i5 = this.e;
            Paint paint = this.f1717g;
            paint.setColor((((int) ((((-16777216) & i5) >>> 24) * f3)) << 24) | (i5 & 16777215));
            canvas.drawRect(i, 0.0f, width, getHeight(), paint);
        }
        return zDrawChild;
    }

    public final View e(int i) {
        WeakHashMap weakHashMap = O.f854a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection()) & 7;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if ((i(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    public final View f() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((((X.d) childAt.getLayoutParams()).f1198d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    public final View g() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (n(childAt)) {
                if (!n(childAt)) {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
                if (((X.d) childAt.getLayoutParams()).f1196b > 0.0f) {
                    return childAt;
                }
            }
        }
        return null;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        X.d dVar = new X.d(-1, -1);
        dVar.f1195a = 0;
        return dVar;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof X.d) {
            X.d dVar = (X.d) layoutParams;
            X.d dVar2 = new X.d(dVar);
            dVar2.f1195a = 0;
            dVar2.f1195a = dVar.f1195a;
            return dVar2;
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            X.d dVar3 = new X.d((ViewGroup.MarginLayoutParams) layoutParams);
            dVar3.f1195a = 0;
            return dVar3;
        }
        X.d dVar4 = new X.d(layoutParams);
        dVar4.f1195a = 0;
        return dVar4;
    }

    public float getDrawerElevation() {
        if (f1707H) {
            return this.f1714c;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f1733x;
    }

    public final int h(View view) {
        if (!n(view)) {
            throw new IllegalArgumentException("View " + view + " is not a drawer");
        }
        int i = ((X.d) view.getLayoutParams()).f1195a;
        WeakHashMap weakHashMap = O.f854a;
        int layoutDirection = getLayoutDirection();
        if (i == 3) {
            int i3 = this.f1724o;
            if (i3 != 3) {
                return i3;
            }
            int i4 = layoutDirection == 0 ? this.f1726q : this.f1727r;
            if (i4 != 3) {
                return i4;
            }
        } else if (i == 5) {
            int i5 = this.f1725p;
            if (i5 != 3) {
                return i5;
            }
            int i6 = layoutDirection == 0 ? this.f1727r : this.f1726q;
            if (i6 != 3) {
                return i6;
            }
        } else if (i == 8388611) {
            int i7 = this.f1726q;
            if (i7 != 3) {
                return i7;
            }
            int i8 = layoutDirection == 0 ? this.f1724o : this.f1725p;
            if (i8 != 3) {
                return i8;
            }
        } else if (i == 8388613) {
            int i9 = this.f1727r;
            if (i9 != 3) {
                return i9;
            }
            int i10 = layoutDirection == 0 ? this.f1725p : this.f1724o;
            if (i10 != 3) {
                return i10;
            }
        }
        return 0;
    }

    public final int i(View view) {
        int i = ((X.d) view.getLayoutParams()).f1195a;
        WeakHashMap weakHashMap = O.f854a;
        return Gravity.getAbsoluteGravity(i, getLayoutDirection());
    }

    public final void o(View view) {
        if (!n(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        X.d dVar = (X.d) view.getLayoutParams();
        if (this.f1723n) {
            dVar.f1196b = 1.0f;
            dVar.f1198d = 1;
            s(view, true);
            r(view);
        } else {
            dVar.f1198d |= 2;
            if (a(view, 3)) {
                this.f1718h.s(view, 0, view.getTop());
            } else {
                this.i.s(view, getWidth() - view.getWidth(), view.getTop());
            }
        }
        invalidate();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1723n = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f1723n = true;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f1735z || this.f1733x == null) {
            return;
        }
        WindowInsets windowInsets = this.f1734y;
        int systemWindowInsetTop = windowInsets != null ? windowInsets.getSystemWindowInsetTop() : 0;
        if (systemWindowInsetTop > 0) {
            this.f1733x.setBounds(0, 0, getWidth(), systemWindowInsetTop);
            this.f1733x.draw(canvas);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x005e  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        View viewH;
        int actionMasked = motionEvent.getActionMasked();
        V.f fVar = this.f1718h;
        boolean zR = fVar.r(motionEvent) | this.i.r(motionEvent);
        if (actionMasked == 0) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            this.f1731v = x2;
            this.f1732w = y2;
            z2 = this.f1716f > 0.0f && (viewH = fVar.h((int) x2, (int) y2)) != null && l(viewH);
            this.f1728s = false;
        } else if (actionMasked == 1) {
            d(true);
            this.f1728s = false;
            z2 = false;
        } else {
            if (actionMasked == 2) {
                int length = fVar.f1169d.length;
                int i = 0;
                while (true) {
                    if (i >= length) {
                        break;
                    }
                    if ((fVar.f1174k & (1 << i)) != 0) {
                        float f3 = fVar.f1170f[i] - fVar.f1169d[i];
                        float f4 = fVar.f1171g[i] - fVar.e[i];
                        float f5 = (f4 * f4) + (f3 * f3);
                        int i3 = fVar.f1167b;
                        if (f5 > i3 * i3) {
                            X.f fVar2 = this.f1719j;
                            fVar2.f1205h.removeCallbacks(fVar2.f1204g);
                            X.f fVar3 = this.f1720k;
                            fVar3.f1205h.removeCallbacks(fVar3.f1204g);
                            break;
                        }
                    }
                    i++;
                }
            } else if (actionMasked == 3) {
            }
            z2 = false;
        }
        if (zR || z2) {
            return true;
        }
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            if (((X.d) getChildAt(i4).getLayoutParams()).f1197c) {
                return true;
            }
        }
        return this.f1728s;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || g() == null) {
            return super.onKeyDown(i, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View viewG = g();
        if (viewG != null && h(viewG) == 0) {
            d(false);
        }
        return viewG != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        WindowInsets rootWindowInsets;
        float f3;
        int i6;
        boolean z3 = true;
        this.f1722m = true;
        int i7 = i4 - i;
        int childCount = getChildCount();
        int i8 = 0;
        while (i8 < childCount) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                X.d dVar = (X.d) childAt.getLayoutParams();
                if (l(childAt)) {
                    int i9 = ((ViewGroup.MarginLayoutParams) dVar).leftMargin;
                    childAt.layout(i9, ((ViewGroup.MarginLayoutParams) dVar).topMargin, childAt.getMeasuredWidth() + i9, childAt.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) dVar).topMargin);
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (a(childAt, 3)) {
                        float f4 = measuredWidth;
                        i6 = (-measuredWidth) + ((int) (dVar.f1196b * f4));
                        f3 = (measuredWidth + i6) / f4;
                    } else {
                        float f5 = measuredWidth;
                        f3 = (i7 - r11) / f5;
                        i6 = i7 - ((int) (dVar.f1196b * f5));
                    }
                    boolean z4 = f3 != dVar.f1196b ? z3 : false;
                    int i10 = dVar.f1195a & 112;
                    if (i10 == 16) {
                        int i11 = i5 - i3;
                        int i12 = (i11 - measuredHeight) / 2;
                        int i13 = ((ViewGroup.MarginLayoutParams) dVar).topMargin;
                        if (i12 < i13) {
                            i12 = i13;
                        } else {
                            int i14 = i12 + measuredHeight;
                            int i15 = i11 - ((ViewGroup.MarginLayoutParams) dVar).bottomMargin;
                            if (i14 > i15) {
                                i12 = i15 - measuredHeight;
                            }
                        }
                        childAt.layout(i6, i12, measuredWidth + i6, measuredHeight + i12);
                    } else if (i10 != 80) {
                        int i16 = ((ViewGroup.MarginLayoutParams) dVar).topMargin;
                        childAt.layout(i6, i16, measuredWidth + i6, measuredHeight + i16);
                    } else {
                        int i17 = i5 - i3;
                        childAt.layout(i6, (i17 - ((ViewGroup.MarginLayoutParams) dVar).bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i6, i17 - ((ViewGroup.MarginLayoutParams) dVar).bottomMargin);
                    }
                    if (z4) {
                        q(childAt, f3);
                    }
                    int i18 = dVar.f1196b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i18) {
                        childAt.setVisibility(i18);
                    }
                }
            }
            i8++;
            z3 = true;
        }
        if (f1708I && (rootWindowInsets = getRootWindowInsets()) != null) {
            H.c cVarI = u0.g(null, rootWindowInsets).f943a.i();
            V.f fVar = this.f1718h;
            fVar.f1178o = Math.max(fVar.f1179p, cVarI.f551a);
            V.f fVar2 = this.i;
            fVar2.f1178o = Math.max(fVar2.f1179p, cVarI.f553c);
        }
        this.f1722m = false;
        this.f1723n = false;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0038  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMeasure(int i, int i3) {
        boolean z2;
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i3);
        if (mode != 1073741824 || mode2 != 1073741824) {
            if (!isInEditMode()) {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
            if (mode == 0) {
                size = 300;
            }
            if (mode2 == 0) {
                size2 = 300;
            }
        }
        setMeasuredDimension(size, size2);
        int i4 = 0;
        if (this.f1734y != null) {
            WeakHashMap weakHashMap = O.f854a;
            z2 = getFitsSystemWindows();
        }
        WeakHashMap weakHashMap2 = O.f854a;
        int layoutDirection = getLayoutDirection();
        int childCount = getChildCount();
        int i5 = 0;
        boolean z3 = false;
        boolean z4 = false;
        while (i5 < childCount) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                X.d dVar = (X.d) childAt.getLayoutParams();
                if (z2) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(dVar.f1195a, layoutDirection);
                    if (childAt.getFitsSystemWindows()) {
                        WindowInsets windowInsetsReplaceSystemWindowInsets = this.f1734y;
                        if (absoluteGravity == 3) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), i4, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(i4, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsetsReplaceSystemWindowInsets);
                    } else {
                        WindowInsets windowInsetsReplaceSystemWindowInsets2 = this.f1734y;
                        if (absoluteGravity == 3) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), i4, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(i4, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        }
                        ((ViewGroup.MarginLayoutParams) dVar).leftMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft();
                        ((ViewGroup.MarginLayoutParams) dVar).topMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop();
                        ((ViewGroup.MarginLayoutParams) dVar).rightMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight();
                        ((ViewGroup.MarginLayoutParams) dVar).bottomMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom();
                    }
                }
                if (l(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - ((ViewGroup.MarginLayoutParams) dVar).leftMargin) - ((ViewGroup.MarginLayoutParams) dVar).rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - ((ViewGroup.MarginLayoutParams) dVar).topMargin) - ((ViewGroup.MarginLayoutParams) dVar).bottomMargin, 1073741824));
                } else {
                    if (!n(childAt)) {
                        throw new IllegalStateException("Child " + childAt + " at index " + i5 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    }
                    if (f1707H) {
                        float fE = G.e(childAt);
                        float f3 = this.f1714c;
                        if (fE != f3) {
                            G.k(childAt, f3);
                        }
                    }
                    int i6 = i(childAt) & 7;
                    int i7 = i6 == 3 ? 1 : i4;
                    if ((i7 != 0 && z3) || (i7 == 0 && z4)) {
                        throw new IllegalStateException("Child drawer has absolute gravity " + j(i6) + " but this DrawerLayout already has a drawer view along that edge");
                    }
                    if (i7 != 0) {
                        z3 = true;
                    } else {
                        z4 = true;
                    }
                    childAt.measure(ViewGroup.getChildMeasureSpec(i, this.f1715d + ((ViewGroup.MarginLayoutParams) dVar).leftMargin + ((ViewGroup.MarginLayoutParams) dVar).rightMargin, ((ViewGroup.MarginLayoutParams) dVar).width), ViewGroup.getChildMeasureSpec(i3, ((ViewGroup.MarginLayoutParams) dVar).topMargin + ((ViewGroup.MarginLayoutParams) dVar).bottomMargin, ((ViewGroup.MarginLayoutParams) dVar).height));
                }
            }
            i5++;
            i4 = 0;
        }
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        View viewE;
        if (!(parcelable instanceof X.e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        X.e eVar = (X.e) parcelable;
        super.onRestoreInstanceState(eVar.f1144b);
        int i = eVar.f1199d;
        if (i != 0 && (viewE = e(i)) != null) {
            o(viewE);
        }
        int i3 = eVar.e;
        if (i3 != 3) {
            p(i3, 3);
        }
        int i4 = eVar.f1200f;
        if (i4 != 3) {
            p(i4, 5);
        }
        int i5 = eVar.f1201g;
        if (i5 != 3) {
            p(i5, 8388611);
        }
        int i6 = eVar.f1202h;
        if (i6 != 3) {
            p(i6, 8388613);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        if (f1707H) {
            return;
        }
        WeakHashMap weakHashMap = O.f854a;
        getLayoutDirection();
        getLayoutDirection();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        X.e eVar = new X.e(super.onSaveInstanceState());
        eVar.f1199d = 0;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            X.d dVar = (X.d) getChildAt(i).getLayoutParams();
            int i3 = dVar.f1198d;
            boolean z2 = i3 == 1;
            boolean z3 = i3 == 2;
            if (z2 || z3) {
                eVar.f1199d = dVar.f1195a;
                break;
            }
        }
        eVar.e = this.f1724o;
        eVar.f1200f = this.f1725p;
        eVar.f1201g = this.f1726q;
        eVar.f1202h = this.f1727r;
        return eVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0054  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        View viewF;
        V.f fVar = this.f1718h;
        fVar.k(motionEvent);
        this.i.k(motionEvent);
        int action = motionEvent.getAction() & 255;
        boolean z2 = false;
        if (action == 0) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            this.f1731v = x2;
            this.f1732w = y2;
            this.f1728s = false;
        } else if (action == 1) {
            float x3 = motionEvent.getX();
            float y3 = motionEvent.getY();
            View viewH = fVar.h((int) x3, (int) y3);
            if (viewH == null || !l(viewH)) {
                z2 = true;
                d(z2);
            } else {
                float f3 = x3 - this.f1731v;
                float f4 = y3 - this.f1732w;
                int i = fVar.f1167b;
                if ((f4 * f4) + (f3 * f3) >= i * i || (viewF = f()) == null || h(viewF) == 2) {
                }
                d(z2);
            }
        } else if (action == 3) {
            d(true);
            this.f1728s = false;
        }
        return true;
    }

    public final void p(int i, int i3) {
        View viewE;
        WeakHashMap weakHashMap = O.f854a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i3, getLayoutDirection());
        if (i3 == 3) {
            this.f1724o = i;
        } else if (i3 == 5) {
            this.f1725p = i;
        } else if (i3 == 8388611) {
            this.f1726q = i;
        } else if (i3 == 8388613) {
            this.f1727r = i;
        }
        if (i != 0) {
            (absoluteGravity == 3 ? this.f1718h : this.i).a();
        }
        if (i != 1) {
            if (i == 2 && (viewE = e(absoluteGravity)) != null) {
                o(viewE);
                return;
            }
            return;
        }
        View viewE2 = e(absoluteGravity);
        if (viewE2 != null) {
            b(viewE2, true);
        }
    }

    public final void q(View view, float f3) {
        X.d dVar = (X.d) view.getLayoutParams();
        if (f3 == dVar.f1196b) {
            return;
        }
        dVar.f1196b = f3;
        ArrayList arrayList = this.f1730u;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((c) this.f1730u.get(size)).getClass();
            }
        }
    }

    public final void r(View view) {
        Q.e eVar = Q.e.f989l;
        O.j(view, eVar.a());
        O.h(view, 0);
        if (!m(view) || h(view) == 2) {
            return;
        }
        O.k(view, eVar, this.f1712D);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        super.requestDisallowInterceptTouchEvent(z2);
        if (z2) {
            d(true);
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f1722m) {
            return;
        }
        super.requestLayout();
    }

    public final void s(View view, boolean z2) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((z2 || n(childAt)) && !(z2 && childAt == view)) {
                WeakHashMap weakHashMap = O.f854a;
                childAt.setImportantForAccessibility(4);
            } else {
                WeakHashMap weakHashMap2 = O.f854a;
                childAt.setImportantForAccessibility(1);
            }
        }
    }

    public void setDrawerElevation(float f3) {
        this.f1714c = f3;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (n(childAt)) {
                float f4 = this.f1714c;
                WeakHashMap weakHashMap = O.f854a;
                G.k(childAt, f4);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(c cVar) {
        ArrayList arrayList;
        c cVar2 = this.f1729t;
        if (cVar2 != null && (arrayList = this.f1730u) != null) {
            arrayList.remove(cVar2);
        }
        if (cVar != null) {
            if (this.f1730u == null) {
                this.f1730u = new ArrayList();
            }
            this.f1730u.add(cVar);
        }
        this.f1729t = cVar;
    }

    public void setDrawerLockMode(int i) {
        p(i, 3);
        p(i, 5);
    }

    public void setScrimColor(int i) {
        this.e = i;
        invalidate();
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f1733x = drawable;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i) {
        this.f1733x = new ColorDrawable(i);
        invalidate();
    }

    public final void t(View view, int i) {
        int i3;
        View rootView;
        int i4 = this.f1718h.f1166a;
        int i5 = this.i.f1166a;
        if (i4 == 1 || i5 == 1) {
            i3 = 1;
        } else {
            i3 = 2;
            if (i4 != 2 && i5 != 2) {
                i3 = 0;
            }
        }
        if (view != null && i == 0) {
            float f3 = ((X.d) view.getLayoutParams()).f1196b;
            if (f3 == 0.0f) {
                X.d dVar = (X.d) view.getLayoutParams();
                if ((dVar.f1198d & 1) == 1) {
                    dVar.f1198d = 0;
                    ArrayList arrayList = this.f1730u;
                    if (arrayList != null) {
                        for (int size = arrayList.size() - 1; size >= 0; size--) {
                            NavigationView navigationView = ((Z0.b) ((c) this.f1730u.get(size))).f1439a;
                            if (view == navigationView) {
                                C0023k c0023k = navigationView.f2636w;
                                Y0.d dVar2 = (Y0.d) c0023k.f912b;
                                if (dVar2 != null) {
                                    dVar2.c((NavigationView) c0023k.f914d);
                                }
                                if (navigationView.f2632s && navigationView.f2631r != 0) {
                                    navigationView.f2631r = 0;
                                    navigationView.g(navigationView.getWidth(), navigationView.getHeight());
                                }
                            }
                        }
                    }
                    s(view, false);
                    r(view);
                    if (hasWindowFocus() && (rootView = getRootView()) != null) {
                        rootView.sendAccessibilityEvent(32);
                    }
                }
            } else if (f3 == 1.0f) {
                X.d dVar3 = (X.d) view.getLayoutParams();
                if ((dVar3.f1198d & 1) == 0) {
                    dVar3.f1198d = 1;
                    ArrayList arrayList2 = this.f1730u;
                    if (arrayList2 != null) {
                        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
                            NavigationView navigationView2 = ((Z0.b) ((c) this.f1730u.get(size2))).f1439a;
                            if (view == navigationView2) {
                                C0023k c0023k2 = navigationView2.f2636w;
                                Objects.requireNonNull(c0023k2);
                                view.post(new E.a(4, c0023k2));
                            }
                        }
                    }
                    s(view, true);
                    r(view);
                    if (hasWindowFocus()) {
                        sendAccessibilityEvent(32);
                    }
                }
            }
        }
        if (i3 != this.f1721l) {
            this.f1721l = i3;
            ArrayList arrayList3 = this.f1730u;
            if (arrayList3 != null) {
                for (int size3 = arrayList3.size() - 1; size3 >= 0; size3--) {
                    ((c) this.f1730u.get(size3)).getClass();
                }
            }
        }
    }

    public void setStatusBarBackground(int i) {
        this.f1733x = i != 0 ? getContext().getDrawable(i) : null;
        invalidate();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        X.d dVar = new X.d(context, attributeSet);
        dVar.f1195a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, F);
        dVar.f1195a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        return dVar;
    }
}
