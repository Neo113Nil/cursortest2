package androidx.room;

import X1.i;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.LinkedHashMap;
import q0.BinderC0419p;
import q0.RemoteCallbackListC0420q;

/* loaded from: classes.dex */
public final class MultiInstanceInvalidationService extends Service {

    /* renamed from: b, reason: collision with root package name */
    public int f1975b;

    /* renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f1976c = new LinkedHashMap();

    /* renamed from: d, reason: collision with root package name */
    public final RemoteCallbackListC0420q f1977d = new RemoteCallbackListC0420q(this);
    public final BinderC0419p e = new BinderC0419p(this);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        i.e(intent, "intent");
        return this.e;
    }
}
