package androidx.profileinstaller;

import C0.b;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import h.RunnableC0182k;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import n0.C0353e;

/* loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // C0.b
    public final List a() {
        return Collections.emptyList();
    }

    @Override // C0.b
    public final Object b(Context context) {
        final Context applicationContext = context.getApplicationContext();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() { // from class: n0.h
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j3) {
                this.f4664a.getClass();
                (Build.VERSION.SDK_INT >= 28 ? Handler.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new RunnableC0182k(applicationContext, 1), new Random().nextInt(Math.max(1000, 1)) + 5000);
            }
        });
        return new C0353e(2);
    }
}
