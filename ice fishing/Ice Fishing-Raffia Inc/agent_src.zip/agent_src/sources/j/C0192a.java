package j;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;

/* renamed from: j.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0192a extends Drawable {

    /* renamed from: l, reason: collision with root package name */
    public static final float f3568l = (float) Math.toRadians(45.0d);

    /* renamed from: a, reason: collision with root package name */
    public final Paint f3569a;

    /* renamed from: b, reason: collision with root package name */
    public final float f3570b;

    /* renamed from: c, reason: collision with root package name */
    public final float f3571c;

    /* renamed from: d, reason: collision with root package name */
    public final float f3572d;
    public final float e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f3573f;

    /* renamed from: g, reason: collision with root package name */
    public final Path f3574g;

    /* renamed from: h, reason: collision with root package name */
    public final int f3575h;
    public float i;

    /* renamed from: j, reason: collision with root package name */
    public final float f3576j;

    /* renamed from: k, reason: collision with root package name */
    public final int f3577k;

    public C0192a(Context context) {
        Paint paint = new Paint();
        this.f3569a = paint;
        this.f3574g = new Path();
        this.f3577k = 2;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.MITER);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setAntiAlias(true);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, AbstractC0131a.f3075n, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
        int color = typedArrayObtainStyledAttributes.getColor(3, 0);
        if (color != paint.getColor()) {
            paint.setColor(color);
            invalidateSelf();
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(7, 0.0f);
        if (paint.getStrokeWidth() != dimension) {
            paint.setStrokeWidth(dimension);
            this.f3576j = (float) (Math.cos(f3568l) * (dimension / 2.0f));
            invalidateSelf();
        }
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(6, true);
        if (this.f3573f != z2) {
            this.f3573f = z2;
            invalidateSelf();
        }
        float fRound = Math.round(typedArrayObtainStyledAttributes.getDimension(5, 0.0f));
        if (fRound != this.e) {
            this.e = fRound;
            invalidateSelf();
        }
        this.f3575h = typedArrayObtainStyledAttributes.getDimensionPixelSize(4, 0);
        this.f3571c = Math.round(typedArrayObtainStyledAttributes.getDimension(2, 0.0f));
        this.f3570b = Math.round(typedArrayObtainStyledAttributes.getDimension(0, 0.0f));
        this.f3572d = typedArrayObtainStyledAttributes.getDimension(1, 0.0f);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static float a(float f3, float f4, float f5) {
        return ((f4 - f3) * f5) + f3;
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) {
        Rect bounds = getBounds();
        int i = this.f3577k;
        boolean z2 = false;
        if (i != 0 && (i == 1 || (i == 3 ? getLayoutDirection() == 0 : getLayoutDirection() == 1))) {
            z2 = true;
        }
        float f3 = this.f3570b;
        float fSqrt = (float) Math.sqrt(f3 * f3 * 2.0f);
        float f4 = this.i;
        float f5 = this.f3571c;
        float fA = a(f5, fSqrt, f4);
        float fA2 = a(f5, this.f3572d, this.i);
        float fRound = Math.round(a(0.0f, this.f3576j, this.i));
        float fA3 = a(0.0f, f3568l, this.i);
        float fA4 = a(z2 ? 0.0f : -180.0f, z2 ? 180.0f : 0.0f, this.i);
        double d3 = fA;
        double d4 = fA3;
        boolean z3 = z2;
        float fRound2 = Math.round(Math.cos(d4) * d3);
        float fRound3 = Math.round(Math.sin(d4) * d3);
        Path path = this.f3574g;
        path.rewind();
        float f6 = this.e;
        Paint paint = this.f3569a;
        float fA5 = a(paint.getStrokeWidth() + f6, -this.f3576j, this.i);
        float f7 = (-fA2) / 2.0f;
        path.moveTo(f7 + fRound, 0.0f);
        path.rLineTo(fA2 - (fRound * 2.0f), 0.0f);
        path.moveTo(f7, fA5);
        path.rLineTo(fRound2, fRound3);
        path.moveTo(f7, -fA5);
        path.rLineTo(fRound2, -fRound3);
        path.close();
        canvas.save();
        float strokeWidth = paint.getStrokeWidth();
        float fHeight = bounds.height() - (3.0f * strokeWidth);
        canvas.translate(bounds.centerX(), (strokeWidth * 1.5f) + this.e + ((((int) (fHeight - (2.0f * r5))) / 4) * 2));
        if (this.f3573f) {
            canvas.rotate(fA4 * (z3 ? -1 : 1));
        } else if (z3) {
            canvas.rotate(180.0f);
        }
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicHeight() {
        return this.f3575h;
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicWidth() {
        return this.f3575h;
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        Paint paint = this.f3569a;
        if (i != paint.getAlpha()) {
            paint.setAlpha(i);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.f3569a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public void setProgress(float f3) {
        if (this.i != f3) {
            this.i = f3;
            invalidateSelf();
        }
    }
}
