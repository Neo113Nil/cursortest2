package p1;

import H.e;
import r1.l;

/* renamed from: p1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0396b {

    /* renamed from: a, reason: collision with root package name */
    public final String f5082a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5083b;

    /* renamed from: c, reason: collision with root package name */
    public final l f5084c;

    /* renamed from: d, reason: collision with root package name */
    public final int f5085d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final int f5086f;

    /* renamed from: g, reason: collision with root package name */
    public final int f5087g;

    /* renamed from: h, reason: collision with root package name */
    public final String f5088h;
    public final String i;

    /* renamed from: j, reason: collision with root package name */
    public final String f5089j;

    /* renamed from: k, reason: collision with root package name */
    public final String f5090k;

    /* renamed from: l, reason: collision with root package name */
    public final String f5091l;

    /* renamed from: m, reason: collision with root package name */
    public final String f5092m;

    public C0396b(String str, String str2, l lVar, int i, int i3, int i4, int i5, String str3, String str4, String str5, String str6, String str7, String str8) {
        this.f5082a = str;
        this.f5083b = str2;
        this.f5084c = lVar;
        this.f5085d = i;
        this.e = i3;
        this.f5086f = i4;
        this.f5087g = i5;
        this.f5088h = str3;
        this.i = str4;
        this.f5089j = str5;
        this.f5090k = str6;
        this.f5091l = str7;
        this.f5092m = str8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0396b)) {
            return false;
        }
        C0396b c0396b = (C0396b) obj;
        return this.f5082a.equals(c0396b.f5082a) && this.f5083b.equals(c0396b.f5083b) && this.f5084c == c0396b.f5084c && this.f5085d == c0396b.f5085d && this.e == c0396b.e && this.f5086f == c0396b.f5086f && this.f5087g == c0396b.f5087g && this.f5088h.equals(c0396b.f5088h) && this.i.equals(c0396b.i) && this.f5089j.equals(c0396b.f5089j) && this.f5090k.equals(c0396b.f5090k) && this.f5091l.equals(c0396b.f5091l) && this.f5092m.equals(c0396b.f5092m);
    }

    public final int hashCode() {
        return this.f5092m.hashCode() + e.c(this.f5091l, e.c(this.f5090k, e.c(this.f5089j, e.c(this.i, e.c(this.f5088h, e.b(this.f5087g, e.b(this.f5086f, e.b(this.e, e.b(this.f5085d, (this.f5084c.hashCode() + e.c(this.f5083b, this.f5082a.hashCode() * 31, 31)) * 31, 31), 31), 31), 31), 31), 31), 31), 31), 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("TrickSeedRow(id=");
        sb.append(this.f5082a);
        sb.append(", name=");
        sb.append(this.f5083b);
        sb.append(", family=");
        sb.append(this.f5084c);
        sb.append(", rung=");
        sb.append(this.f5085d);
        sb.append(", spinDeg=");
        sb.append(this.e);
        sb.append(", flips=");
        sb.append(this.f5086f);
        sb.append(", yearLanded=");
        sb.append(this.f5087g);
        sb.append(", originator=");
        sb.append(this.f5088h);
        sb.append(", terrain=");
        sb.append(this.i);
        sb.append(", line=");
        sb.append(this.f5089j);
        sb.append(", account=");
        sb.append(this.f5090k);
        sb.append(", commitCue=");
        sb.append(this.f5091l);
        sb.append(", bailWatch=");
        return e.j(sb, this.f5092m, ")");
    }
}
