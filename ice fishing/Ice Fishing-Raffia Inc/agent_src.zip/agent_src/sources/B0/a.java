package B0;

import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public final class a {
    public static final HashMap e = new HashMap();

    /* renamed from: a, reason: collision with root package name */
    public final boolean f248a;

    /* renamed from: b, reason: collision with root package name */
    public final File f249b;

    /* renamed from: c, reason: collision with root package name */
    public final Lock f250c;

    /* renamed from: d, reason: collision with root package name */
    public FileChannel f251d;

    public a(String str, File file, boolean z2) {
        Lock lock;
        this.f248a = z2;
        this.f249b = file != null ? new File(file, str.concat(".lck")) : null;
        HashMap map = e;
        synchronized (map) {
            try {
                Object reentrantLock = map.get(str);
                if (reentrantLock == null) {
                    reentrantLock = new ReentrantLock();
                    map.put(str, reentrantLock);
                }
                lock = (Lock) reentrantLock;
            } catch (Throwable th) {
                throw th;
            }
        }
        this.f250c = lock;
    }

    public final void a(boolean z2) throws IOException {
        this.f250c.lock();
        if (z2) {
            File file = this.f249b;
            try {
                if (file == null) {
                    throw new IOException("No lock directory was provided.");
                }
                File parentFile = file.getParentFile();
                if (parentFile != null) {
                    parentFile.mkdirs();
                }
                FileChannel channel = new FileOutputStream(file).getChannel();
                channel.lock();
                this.f251d = channel;
            } catch (IOException e3) {
                this.f251d = null;
                Log.w("SupportSQLiteLock", "Unable to grab file lock.", e3);
            }
        }
    }

    public final void b() throws IOException {
        try {
            FileChannel fileChannel = this.f251d;
            if (fileChannel != null) {
                fileChannel.close();
            }
        } catch (IOException unused) {
        }
        this.f250c.unlock();
    }
}
