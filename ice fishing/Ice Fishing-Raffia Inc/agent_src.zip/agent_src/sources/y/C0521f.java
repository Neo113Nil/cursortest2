package y;

import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: y.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0521f implements InterfaceC0519d {

    /* renamed from: d, reason: collision with root package name */
    public final AbstractC0530o f5995d;

    /* renamed from: f, reason: collision with root package name */
    public int f5996f;

    /* renamed from: g, reason: collision with root package name */
    public int f5997g;

    /* renamed from: a, reason: collision with root package name */
    public AbstractC0530o f5992a = null;

    /* renamed from: b, reason: collision with root package name */
    public boolean f5993b = false;

    /* renamed from: c, reason: collision with root package name */
    public boolean f5994c = false;
    public int e = 1;

    /* renamed from: h, reason: collision with root package name */
    public int f5998h = 1;
    public C0522g i = null;

    /* renamed from: j, reason: collision with root package name */
    public boolean f5999j = false;

    /* renamed from: k, reason: collision with root package name */
    public final ArrayList f6000k = new ArrayList();

    /* renamed from: l, reason: collision with root package name */
    public final ArrayList f6001l = new ArrayList();

    public C0521f(AbstractC0530o abstractC0530o) {
        this.f5995d = abstractC0530o;
    }

    @Override // y.InterfaceC0519d
    public final void a(InterfaceC0519d interfaceC0519d) {
        ArrayList arrayList = this.f6001l;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            if (!((C0521f) it.next()).f5999j) {
                return;
            }
        }
        this.f5994c = true;
        AbstractC0530o abstractC0530o = this.f5992a;
        if (abstractC0530o != null) {
            abstractC0530o.a(this);
        }
        if (this.f5993b) {
            this.f5995d.a(this);
            return;
        }
        Iterator it2 = arrayList.iterator();
        C0521f c0521f = null;
        int i = 0;
        while (it2.hasNext()) {
            C0521f c0521f2 = (C0521f) it2.next();
            if (!(c0521f2 instanceof C0522g)) {
                i++;
                c0521f = c0521f2;
            }
        }
        if (c0521f != null && i == 1 && c0521f.f5999j) {
            C0522g c0522g = this.i;
            if (c0522g != null) {
                if (!c0522g.f5999j) {
                    return;
                } else {
                    this.f5996f = this.f5998h * c0522g.f5997g;
                }
            }
            d(c0521f.f5997g + this.f5996f);
        }
        AbstractC0530o abstractC0530o2 = this.f5992a;
        if (abstractC0530o2 != null) {
            abstractC0530o2.a(this);
        }
    }

    public final void b(AbstractC0530o abstractC0530o) {
        this.f6000k.add(abstractC0530o);
        if (this.f5999j) {
            abstractC0530o.a(abstractC0530o);
        }
    }

    public final void c() {
        this.f6001l.clear();
        this.f6000k.clear();
        this.f5999j = false;
        this.f5997g = 0;
        this.f5994c = false;
        this.f5993b = false;
    }

    public void d(int i) {
        if (this.f5999j) {
            return;
        }
        this.f5999j = true;
        this.f5997g = i;
        Iterator it = this.f6000k.iterator();
        while (it.hasNext()) {
            InterfaceC0519d interfaceC0519d = (InterfaceC0519d) it.next();
            interfaceC0519d.a(interfaceC0519d);
        }
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(this.f5995d.f6015b.f5827h0);
        sb.append(":");
        switch (this.e) {
            case 1:
                str = "UNKNOWN";
                break;
            case 2:
                str = "HORIZONTAL_DIMENSION";
                break;
            case 3:
                str = "VERTICAL_DIMENSION";
                break;
            case 4:
                str = "LEFT";
                break;
            case 5:
                str = "RIGHT";
                break;
            case 6:
                str = "TOP";
                break;
            case 7:
                str = "BOTTOM";
                break;
            case 8:
                str = "BASELINE";
                break;
            default:
                str = "null";
                break;
        }
        sb.append(str);
        sb.append("(");
        sb.append(this.f5999j ? Integer.valueOf(this.f5997g) : "unresolved");
        sb.append(") <t=");
        sb.append(this.f6001l.size());
        sb.append(":d=");
        sb.append(this.f6000k.size());
        sb.append(">");
        return sb.toString();
    }
}
