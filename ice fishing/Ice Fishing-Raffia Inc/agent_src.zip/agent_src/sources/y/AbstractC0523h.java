package y;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import x.C0494c;
import x.C0495d;
import x.C0496e;

/* renamed from: y.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0523h {

    /* renamed from: a, reason: collision with root package name */
    public static final C0517b f6003a = new C0517b();

    public static boolean a(C0495d c0495d) {
        int[] iArr = c0495d.f5842p0;
        int i = iArr[0];
        int i3 = iArr[1];
        C0495d c0495d2 = c0495d.f5806T;
        C0496e c0496e = c0495d2 != null ? (C0496e) c0495d2 : null;
        if (c0496e != null) {
            int i4 = c0496e.f5842p0[0];
        }
        if (c0496e != null) {
            int i5 = c0496e.f5842p0[1];
        }
        boolean z2 = i == 1 || c0495d.A() || i == 2 || (i == 3 && c0495d.f5844r == 0 && c0495d.f5809W == 0.0f && c0495d.t(0)) || (i == 3 && c0495d.f5844r == 1 && c0495d.u(0, c0495d.q()));
        boolean z3 = i3 == 1 || c0495d.B() || i3 == 2 || (i3 == 3 && c0495d.f5845s == 0 && c0495d.f5809W == 0.0f && c0495d.t(1)) || (i3 == 3 && c0495d.f5845s == 1 && c0495d.u(1, c0495d.k()));
        if (c0495d.f5809W <= 0.0f || !(z2 || z3)) {
            return z2 && z3;
        }
        return true;
    }

    public static C0529n b(C0495d c0495d, int i, ArrayList arrayList, C0529n c0529n) {
        int i3;
        int i4 = i == 0 ? c0495d.f5838n0 : c0495d.f5840o0;
        if (i4 != -1 && (c0529n == null || i4 != c0529n.f6011b)) {
            int i5 = 0;
            while (true) {
                if (i5 >= arrayList.size()) {
                    break;
                }
                C0529n c0529n2 = (C0529n) arrayList.get(i5);
                if (c0529n2.f6011b == i4) {
                    if (c0529n != null) {
                        c0529n.c(i, c0529n2);
                        arrayList.remove(c0529n);
                    }
                    c0529n = c0529n2;
                } else {
                    i5++;
                }
            }
        } else if (i4 != -1) {
            return c0529n;
        }
        if (c0529n == null) {
            if (c0495d instanceof x.i) {
                x.i iVar = (x.i) c0495d;
                int i6 = 0;
                while (true) {
                    if (i6 >= iVar.f5931r0) {
                        i3 = -1;
                        break;
                    }
                    C0495d c0495d2 = iVar.f5930q0[i6];
                    if ((i == 0 && (i3 = c0495d2.f5838n0) != -1) || (i == 1 && (i3 = c0495d2.f5840o0) != -1)) {
                        break;
                    }
                    i6++;
                }
                if (i3 != -1) {
                    int i7 = 0;
                    while (true) {
                        if (i7 >= arrayList.size()) {
                            break;
                        }
                        C0529n c0529n3 = (C0529n) arrayList.get(i7);
                        if (c0529n3.f6011b == i3) {
                            c0529n = c0529n3;
                            break;
                        }
                        i7++;
                    }
                }
            }
            if (c0529n == null) {
                c0529n = new C0529n();
                c0529n.f6010a = new ArrayList();
                c0529n.f6013d = null;
                c0529n.e = -1;
                int i8 = C0529n.f6009f;
                C0529n.f6009f = i8 + 1;
                c0529n.f6011b = i8;
                c0529n.f6012c = i;
            }
            arrayList.add(c0529n);
        }
        ArrayList arrayList2 = c0529n.f6010a;
        if (!arrayList2.contains(c0495d)) {
            arrayList2.add(c0495d);
            if (c0495d instanceof x.h) {
                x.h hVar = (x.h) c0495d;
                hVar.f5927t0.c(hVar.f5928u0 == 0 ? 1 : 0, arrayList, c0529n);
            }
            int i9 = c0529n.f6011b;
            if (i == 0) {
                c0495d.f5838n0 = i9;
                c0495d.f5796I.c(i, arrayList, c0529n);
                c0495d.K.c(i, arrayList, c0529n);
            } else {
                c0495d.f5840o0 = i9;
                c0495d.f5797J.c(i, arrayList, c0529n);
                c0495d.f5799M.c(i, arrayList, c0529n);
                c0495d.f5798L.c(i, arrayList, c0529n);
            }
            c0495d.f5802P.c(i, arrayList, c0529n);
        }
        return c0529n;
    }

    public static void c(int i, A.f fVar, C0495d c0495d, boolean z2) {
        C0494c c0494c;
        C0494c c0494c2;
        C0494c c0494c3;
        C0494c c0494c4;
        if (c0495d.f5835m) {
            return;
        }
        if (!(c0495d instanceof C0496e) && c0495d.z() && a(c0495d)) {
            C0496e.V(c0495d, fVar, new C0517b());
        }
        C0494c c0494cI = c0495d.i(2);
        C0494c c0494cI2 = c0495d.i(4);
        int iD = c0494cI.d();
        int iD2 = c0494cI2.d();
        HashSet hashSet = c0494cI.f5782a;
        char c3 = 0;
        if (hashSet != null && c0494cI.f5784c) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                C0494c c0494c5 = (C0494c) it.next();
                C0495d c0495d2 = c0494c5.f5785d;
                int i3 = i + 1;
                boolean zA = a(c0495d2);
                if (c0495d2.z() && zA) {
                    C0496e.V(c0495d2, fVar, new C0517b());
                }
                C0494c c0494c6 = c0495d2.f5796I;
                C0494c c0494c7 = c0495d2.K;
                char c4 = ((c0494c5 == c0494c6 && (c0494c4 = c0494c7.f5786f) != null && c0494c4.f5784c) || (c0494c5 == c0494c7 && (c0494c3 = c0494c6.f5786f) != null && c0494c3.f5784c)) ? (char) 1 : c3;
                int i4 = c0495d2.f5842p0[c3];
                if (i4 != 3 || zA) {
                    if (!c0495d2.z()) {
                        if (c0494c5 == c0494c6 && c0494c7.f5786f == null) {
                            int iE = c0494c6.e() + iD;
                            c0495d2.J(iE, c0495d2.q() + iE);
                            c(i3, fVar, c0495d2, z2);
                        } else if (c0494c5 == c0494c7 && c0494c6.f5786f == null) {
                            int iE2 = iD - c0494c7.e();
                            c0495d2.J(iE2 - c0495d2.q(), iE2);
                            c(i3, fVar, c0495d2, z2);
                        } else if (c4 != 0 && !c0495d2.x()) {
                            d(i3, fVar, c0495d2, z2);
                        }
                    }
                } else if (i4 == 3 && c0495d2.f5848v >= 0 && c0495d2.f5847u >= 0 && ((c0495d2.f5825g0 == 8 || (c0495d2.f5844r == 0 && c0495d2.f5809W == 0.0f)) && !c0495d2.x() && !c0495d2.F && c4 != 0 && !c0495d2.x())) {
                    e(i3, c0495d, fVar, c0495d2, z2);
                }
                c3 = 0;
            }
        }
        if (c0495d instanceof x.h) {
            return;
        }
        HashSet hashSet2 = c0494cI2.f5782a;
        if (hashSet2 != null && c0494cI2.f5784c) {
            Iterator it2 = hashSet2.iterator();
            while (it2.hasNext()) {
                C0494c c0494c8 = (C0494c) it2.next();
                C0495d c0495d3 = c0494c8.f5785d;
                int i5 = i + 1;
                boolean zA2 = a(c0495d3);
                if (c0495d3.z() && zA2) {
                    C0496e.V(c0495d3, fVar, new C0517b());
                }
                C0494c c0494c9 = c0495d3.f5796I;
                C0494c c0494c10 = c0495d3.K;
                boolean z3 = (c0494c8 == c0494c9 && (c0494c2 = c0494c10.f5786f) != null && c0494c2.f5784c) || (c0494c8 == c0494c10 && (c0494c = c0494c9.f5786f) != null && c0494c.f5784c);
                int i6 = c0495d3.f5842p0[0];
                if (i6 != 3 || zA2) {
                    if (!c0495d3.z()) {
                        if (c0494c8 == c0494c9 && c0494c10.f5786f == null) {
                            int iE3 = c0494c9.e() + iD2;
                            c0495d3.J(iE3, c0495d3.q() + iE3);
                            c(i5, fVar, c0495d3, z2);
                        } else if (c0494c8 == c0494c10 && c0494c9.f5786f == null) {
                            int iE4 = iD2 - c0494c10.e();
                            c0495d3.J(iE4 - c0495d3.q(), iE4);
                            c(i5, fVar, c0495d3, z2);
                        } else if (z3 && !c0495d3.x()) {
                            d(i5, fVar, c0495d3, z2);
                        }
                    }
                } else if (i6 == 3 && c0495d3.f5848v >= 0 && c0495d3.f5847u >= 0) {
                    if (c0495d3.f5825g0 != 8) {
                        if (c0495d3.f5844r == 0) {
                            if (c0495d3.f5809W == 0.0f) {
                            }
                        }
                    }
                    if (!c0495d3.x() && !c0495d3.F && z3 && !c0495d3.x()) {
                        e(i5, c0495d, fVar, c0495d3, z2);
                    }
                }
            }
        }
        c0495d.f5835m = true;
    }

    public static void d(int i, A.f fVar, C0495d c0495d, boolean z2) {
        float f3 = c0495d.f5820d0;
        C0494c c0494c = c0495d.f5796I;
        int iD = c0494c.f5786f.d();
        C0494c c0494c2 = c0495d.K;
        int iD2 = c0494c2.f5786f.d();
        int iE = c0494c.e() + iD;
        int iE2 = iD2 - c0494c2.e();
        if (iD == iD2) {
            f3 = 0.5f;
        } else {
            iD = iE;
            iD2 = iE2;
        }
        int iQ = c0495d.q();
        int i3 = (iD2 - iD) - iQ;
        if (iD > iD2) {
            i3 = (iD - iD2) - iQ;
        }
        int i4 = ((int) (i3 > 0 ? (f3 * i3) + 0.5f : f3 * i3)) + iD;
        int i5 = i4 + iQ;
        if (iD > iD2) {
            i5 = i4 - iQ;
        }
        c0495d.J(i4, i5);
        c(i + 1, fVar, c0495d, z2);
    }

    public static void e(int i, C0495d c0495d, A.f fVar, C0495d c0495d2, boolean z2) {
        float f3 = c0495d2.f5820d0;
        C0494c c0494c = c0495d2.f5796I;
        int iE = c0494c.e() + c0494c.f5786f.d();
        C0494c c0494c2 = c0495d2.K;
        int iD = c0494c2.f5786f.d() - c0494c2.e();
        if (iD >= iE) {
            int iQ = c0495d2.q();
            if (c0495d2.f5825g0 != 8) {
                int i3 = c0495d2.f5844r;
                if (i3 == 2) {
                    iQ = (int) (c0495d2.f5820d0 * 0.5f * (c0495d instanceof C0496e ? c0495d.q() : c0495d.f5806T.q()));
                } else if (i3 == 0) {
                    iQ = iD - iE;
                }
                iQ = Math.max(c0495d2.f5847u, iQ);
                int i4 = c0495d2.f5848v;
                if (i4 > 0) {
                    iQ = Math.min(i4, iQ);
                }
            }
            int i5 = iE + ((int) ((f3 * ((iD - iE) - iQ)) + 0.5f));
            c0495d2.J(i5, iQ + i5);
            c(i + 1, fVar, c0495d2, z2);
        }
    }

    public static void f(int i, A.f fVar, C0495d c0495d) {
        float f3 = c0495d.f5821e0;
        C0494c c0494c = c0495d.f5797J;
        int iD = c0494c.f5786f.d();
        C0494c c0494c2 = c0495d.f5798L;
        int iD2 = c0494c2.f5786f.d();
        int iE = c0494c.e() + iD;
        int iE2 = iD2 - c0494c2.e();
        if (iD == iD2) {
            f3 = 0.5f;
        } else {
            iD = iE;
            iD2 = iE2;
        }
        int iK = c0495d.k();
        int i3 = (iD2 - iD) - iK;
        if (iD > iD2) {
            i3 = (iD - iD2) - iK;
        }
        int i4 = (int) (i3 > 0 ? (f3 * i3) + 0.5f : f3 * i3);
        int i5 = iD + i4;
        int i6 = i5 + iK;
        if (iD > iD2) {
            i5 = iD - i4;
            i6 = i5 - iK;
        }
        c0495d.K(i5, i6);
        i(i + 1, fVar, c0495d);
    }

    public static void g(int i, C0495d c0495d, A.f fVar, C0495d c0495d2) {
        float f3 = c0495d2.f5821e0;
        C0494c c0494c = c0495d2.f5797J;
        int iE = c0494c.e() + c0494c.f5786f.d();
        C0494c c0494c2 = c0495d2.f5798L;
        int iD = c0494c2.f5786f.d() - c0494c2.e();
        if (iD >= iE) {
            int iK = c0495d2.k();
            if (c0495d2.f5825g0 != 8) {
                int i3 = c0495d2.f5845s;
                if (i3 == 2) {
                    iK = (int) (f3 * 0.5f * (c0495d instanceof C0496e ? c0495d.k() : c0495d.f5806T.k()));
                } else if (i3 == 0) {
                    iK = iD - iE;
                }
                iK = Math.max(c0495d2.f5850x, iK);
                int i4 = c0495d2.f5851y;
                if (i4 > 0) {
                    iK = Math.min(i4, iK);
                }
            }
            int i5 = iE + ((int) ((f3 * ((iD - iE) - iK)) + 0.5f));
            c0495d2.K(i5, iK + i5);
            i(i + 1, fVar, c0495d2);
        }
    }

    public static boolean h(int i, int i3, int i4, int i5) {
        return (i4 == 1 || i4 == 2 || (i4 == 4 && i != 2)) || (i5 == 1 || i5 == 2 || (i5 == 4 && i3 != 2));
    }

    public static void i(int i, A.f fVar, C0495d c0495d) {
        C0494c c0494c;
        C0494c c0494c2;
        C0494c c0494c3;
        C0494c c0494c4;
        C0494c c0494c5;
        if (c0495d.f5837n) {
            return;
        }
        if (!(c0495d instanceof C0496e) && c0495d.z() && a(c0495d)) {
            C0496e.V(c0495d, fVar, new C0517b());
        }
        C0494c c0494cI = c0495d.i(3);
        C0494c c0494cI2 = c0495d.i(5);
        int iD = c0494cI.d();
        int iD2 = c0494cI2.d();
        HashSet hashSet = c0494cI.f5782a;
        if (hashSet != null && c0494cI.f5784c) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                C0494c c0494c6 = (C0494c) it.next();
                C0495d c0495d2 = c0494c6.f5785d;
                int i3 = i + 1;
                boolean zA = a(c0495d2);
                if (c0495d2.z() && zA) {
                    C0496e.V(c0495d2, fVar, new C0517b());
                }
                C0494c c0494c7 = c0495d2.f5797J;
                C0494c c0494c8 = c0495d2.f5798L;
                boolean z2 = (c0494c6 == c0494c7 && (c0494c5 = c0494c8.f5786f) != null && c0494c5.f5784c) || (c0494c6 == c0494c8 && (c0494c4 = c0494c7.f5786f) != null && c0494c4.f5784c);
                int i4 = c0495d2.f5842p0[1];
                if (i4 != 3 || zA) {
                    if (!c0495d2.z()) {
                        if (c0494c6 == c0494c7 && c0494c8.f5786f == null) {
                            int iE = c0494c7.e() + iD;
                            c0495d2.K(iE, c0495d2.k() + iE);
                            i(i3, fVar, c0495d2);
                        } else if (c0494c6 == c0494c8 && c0494c7.f5786f == null) {
                            int iE2 = iD - c0494c8.e();
                            c0495d2.K(iE2 - c0495d2.k(), iE2);
                            i(i3, fVar, c0495d2);
                        } else if (z2 && !c0495d2.y()) {
                            f(i3, fVar, c0495d2);
                        }
                    }
                } else if (i4 == 3 && c0495d2.f5851y >= 0 && c0495d2.f5850x >= 0 && (c0495d2.f5825g0 == 8 || (c0495d2.f5845s == 0 && c0495d2.f5809W == 0.0f))) {
                    if (!c0495d2.y() && !c0495d2.F && z2 && !c0495d2.y()) {
                        g(i3, c0495d, fVar, c0495d2);
                    }
                }
            }
        }
        if (c0495d instanceof x.h) {
            return;
        }
        HashSet hashSet2 = c0494cI2.f5782a;
        if (hashSet2 != null && c0494cI2.f5784c) {
            Iterator it2 = hashSet2.iterator();
            while (it2.hasNext()) {
                C0494c c0494c9 = (C0494c) it2.next();
                C0495d c0495d3 = c0494c9.f5785d;
                int i5 = i + 1;
                boolean zA2 = a(c0495d3);
                if (c0495d3.z() && zA2) {
                    C0496e.V(c0495d3, fVar, new C0517b());
                }
                C0494c c0494c10 = c0495d3.f5797J;
                C0494c c0494c11 = c0495d3.f5798L;
                boolean z3 = (c0494c9 == c0494c10 && (c0494c3 = c0494c11.f5786f) != null && c0494c3.f5784c) || (c0494c9 == c0494c11 && (c0494c2 = c0494c10.f5786f) != null && c0494c2.f5784c);
                int i6 = c0495d3.f5842p0[1];
                if (i6 != 3 || zA2) {
                    if (!c0495d3.z()) {
                        if (c0494c9 == c0494c10 && c0494c11.f5786f == null) {
                            int iE3 = c0494c10.e() + iD2;
                            c0495d3.K(iE3, c0495d3.k() + iE3);
                            i(i5, fVar, c0495d3);
                        } else if (c0494c9 == c0494c11 && c0494c10.f5786f == null) {
                            int iE4 = iD2 - c0494c11.e();
                            c0495d3.K(iE4 - c0495d3.k(), iE4);
                            i(i5, fVar, c0495d3);
                        } else if (z3 && !c0495d3.y()) {
                            f(i5, fVar, c0495d3);
                        }
                    }
                } else if (i6 == 3 && c0495d3.f5851y >= 0 && c0495d3.f5850x >= 0) {
                    if (c0495d3.f5825g0 != 8) {
                        if (c0495d3.f5845s == 0) {
                            if (c0495d3.f5809W == 0.0f) {
                            }
                        }
                    }
                    if (!c0495d3.y() && !c0495d3.F && z3 && !c0495d3.y()) {
                        g(i5, c0495d, fVar, c0495d3);
                    }
                }
            }
        }
        C0494c c0494cI3 = c0495d.i(6);
        if (c0494cI3.f5782a != null && c0494cI3.f5784c) {
            int iD3 = c0494cI3.d();
            Iterator it3 = c0494cI3.f5782a.iterator();
            while (it3.hasNext()) {
                C0494c c0494c12 = (C0494c) it3.next();
                C0495d c0495d4 = c0494c12.f5785d;
                int i7 = i + 1;
                boolean zA3 = a(c0495d4);
                if (c0495d4.z() && zA3) {
                    C0496e.V(c0495d4, fVar, new C0517b());
                }
                if (c0495d4.f5842p0[1] != 3 || zA3) {
                    if (!c0495d4.z() && c0494c12 == (c0494c = c0495d4.f5799M)) {
                        int iE5 = c0494c12.e() + iD3;
                        if (c0495d4.f5793E) {
                            int i8 = iE5 - c0495d4.f5814a0;
                            int i9 = c0495d4.f5808V + i8;
                            c0495d4.f5812Z = i8;
                            c0495d4.f5797J.l(i8);
                            c0495d4.f5798L.l(i9);
                            c0494c.l(iE5);
                            c0495d4.f5833l = true;
                        }
                        i(i7, fVar, c0495d4);
                    }
                }
            }
        }
        c0495d.f5837n = true;
    }
}
