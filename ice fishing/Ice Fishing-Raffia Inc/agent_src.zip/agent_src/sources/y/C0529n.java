package y;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import n0.C0353e;
import v.C0468c;
import x.C0495d;
import x.C0496e;

/* renamed from: y.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0529n {

    /* renamed from: f, reason: collision with root package name */
    public static int f6009f;

    /* renamed from: a, reason: collision with root package name */
    public ArrayList f6010a;

    /* renamed from: b, reason: collision with root package name */
    public int f6011b;

    /* renamed from: c, reason: collision with root package name */
    public int f6012c;

    /* renamed from: d, reason: collision with root package name */
    public ArrayList f6013d;
    public int e;

    public final void a(ArrayList arrayList) {
        int size = this.f6010a.size();
        if (this.e != -1 && size > 0) {
            for (int i = 0; i < arrayList.size(); i++) {
                C0529n c0529n = (C0529n) arrayList.get(i);
                if (this.e == c0529n.f6011b) {
                    c(this.f6012c, c0529n);
                }
            }
        }
        if (size == 0) {
            arrayList.remove(this);
        }
    }

    public final int b(C0468c c0468c, int i) {
        int iN;
        int iN2;
        ArrayList arrayList = this.f6010a;
        if (arrayList.size() == 0) {
            return 0;
        }
        C0496e c0496e = (C0496e) ((C0495d) arrayList.get(0)).f5806T;
        c0468c.t();
        c0496e.b(c0468c, false);
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            ((C0495d) arrayList.get(i3)).b(c0468c, false);
        }
        if (i == 0 && c0496e.f5873z0 > 0) {
            x.j.a(c0496e, c0468c, arrayList, 0);
        }
        if (i == 1 && c0496e.f5853A0 > 0) {
            x.j.a(c0496e, c0468c, arrayList, 1);
        }
        try {
            c0468c.p();
        } catch (Exception e) {
            System.err.println(e.toString() + "\n" + Arrays.toString(e.getStackTrace()).replace("[", "   at ").replace(",", "\n   at").replace("]", ""));
        }
        this.f6013d = new ArrayList();
        for (int i4 = 0; i4 < arrayList.size(); i4++) {
            C0495d c0495d = (C0495d) arrayList.get(i4);
            C0353e c0353e = new C0353e(11);
            new WeakReference(c0495d);
            C0468c.n(c0495d.f5796I);
            C0468c.n(c0495d.f5797J);
            C0468c.n(c0495d.K);
            C0468c.n(c0495d.f5798L);
            C0468c.n(c0495d.f5799M);
            this.f6013d.add(c0353e);
        }
        if (i == 0) {
            iN = C0468c.n(c0496e.f5796I);
            iN2 = C0468c.n(c0496e.K);
            c0468c.t();
        } else {
            iN = C0468c.n(c0496e.f5797J);
            iN2 = C0468c.n(c0496e.f5798L);
            c0468c.t();
        }
        return iN2 - iN;
    }

    public final void c(int i, C0529n c0529n) {
        Iterator it = this.f6010a.iterator();
        while (it.hasNext()) {
            C0495d c0495d = (C0495d) it.next();
            ArrayList arrayList = c0529n.f6010a;
            if (!arrayList.contains(c0495d)) {
                arrayList.add(c0495d);
            }
            int i3 = c0529n.f6011b;
            if (i == 0) {
                c0495d.f5838n0 = i3;
            } else {
                c0495d.f5840o0 = i3;
            }
        }
        this.e = c0529n.f6011b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        int i = this.f6012c;
        sb.append(i == 0 ? "Horizontal" : i == 1 ? "Vertical" : i == 2 ? "Both" : "Unknown");
        sb.append(" [");
        sb.append(this.f6011b);
        sb.append("] <");
        String string = sb.toString();
        Iterator it = this.f6010a.iterator();
        while (it.hasNext()) {
            string = string + " " + ((C0495d) it.next()).f5827h0;
        }
        return H.e.h(string, " >");
    }
}
