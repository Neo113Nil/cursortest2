package y;

import java.util.Iterator;
import x.C0492a;
import x.C0495d;

/* renamed from: y.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0525j extends AbstractC0530o {
    @Override // y.InterfaceC0519d
    public final void a(InterfaceC0519d interfaceC0519d) {
        C0492a c0492a = (C0492a) this.f6015b;
        int i = c0492a.f5763s0;
        C0521f c0521f = this.f6020h;
        Iterator it = c0521f.f6001l.iterator();
        int i3 = 0;
        int i4 = -1;
        while (it.hasNext()) {
            int i5 = ((C0521f) it.next()).f5997g;
            if (i4 == -1 || i5 < i4) {
                i4 = i5;
            }
            if (i3 < i5) {
                i3 = i5;
            }
        }
        if (i == 0 || i == 2) {
            c0521f.d(i4 + c0492a.f5765u0);
        } else {
            c0521f.d(i3 + c0492a.f5765u0);
        }
    }

    @Override // y.AbstractC0530o
    public final void d() {
        C0495d c0495d = this.f6015b;
        if (c0495d instanceof C0492a) {
            C0521f c0521f = this.f6020h;
            c0521f.f5993b = true;
            C0492a c0492a = (C0492a) c0495d;
            int i = c0492a.f5763s0;
            boolean z2 = c0492a.f5764t0;
            int i3 = 0;
            if (i == 0) {
                c0521f.e = 4;
                while (i3 < c0492a.f5931r0) {
                    C0495d c0495d2 = c0492a.f5930q0[i3];
                    if (z2 || c0495d2.f5825g0 != 8) {
                        C0521f c0521f2 = c0495d2.f5819d.f6020h;
                        c0521f2.f6000k.add(c0521f);
                        c0521f.f6001l.add(c0521f2);
                    }
                    i3++;
                }
                m(this.f6015b.f5819d.f6020h);
                m(this.f6015b.f5819d.i);
                return;
            }
            if (i == 1) {
                c0521f.e = 5;
                while (i3 < c0492a.f5931r0) {
                    C0495d c0495d3 = c0492a.f5930q0[i3];
                    if (z2 || c0495d3.f5825g0 != 8) {
                        C0521f c0521f3 = c0495d3.f5819d.i;
                        c0521f3.f6000k.add(c0521f);
                        c0521f.f6001l.add(c0521f3);
                    }
                    i3++;
                }
                m(this.f6015b.f5819d.f6020h);
                m(this.f6015b.f5819d.i);
                return;
            }
            if (i == 2) {
                c0521f.e = 6;
                while (i3 < c0492a.f5931r0) {
                    C0495d c0495d4 = c0492a.f5930q0[i3];
                    if (z2 || c0495d4.f5825g0 != 8) {
                        C0521f c0521f4 = c0495d4.e.f6020h;
                        c0521f4.f6000k.add(c0521f);
                        c0521f.f6001l.add(c0521f4);
                    }
                    i3++;
                }
                m(this.f6015b.e.f6020h);
                m(this.f6015b.e.i);
                return;
            }
            if (i != 3) {
                return;
            }
            c0521f.e = 7;
            while (i3 < c0492a.f5931r0) {
                C0495d c0495d5 = c0492a.f5930q0[i3];
                if (z2 || c0495d5.f5825g0 != 8) {
                    C0521f c0521f5 = c0495d5.e.i;
                    c0521f5.f6000k.add(c0521f);
                    c0521f.f6001l.add(c0521f5);
                }
                i3++;
            }
            m(this.f6015b.e.f6020h);
            m(this.f6015b.e.i);
        }
    }

    @Override // y.AbstractC0530o
    public final void e() {
        C0495d c0495d = this.f6015b;
        if (c0495d instanceof C0492a) {
            int i = ((C0492a) c0495d).f5763s0;
            C0521f c0521f = this.f6020h;
            if (i == 0 || i == 1) {
                c0495d.f5811Y = c0521f.f5997g;
            } else {
                c0495d.f5812Z = c0521f.f5997g;
            }
        }
    }

    @Override // y.AbstractC0530o
    public final void f() {
        this.f6016c = null;
        this.f6020h.c();
    }

    @Override // y.AbstractC0530o
    public final boolean k() {
        return false;
    }

    public final void m(C0521f c0521f) {
        C0521f c0521f2 = this.f6020h;
        c0521f2.f6000k.add(c0521f);
        c0521f.f6001l.add(c0521f2);
    }
}
