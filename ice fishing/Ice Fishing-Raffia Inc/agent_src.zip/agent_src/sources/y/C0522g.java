package y;

import java.util.Iterator;

/* renamed from: y.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0522g extends C0521f {

    /* renamed from: m, reason: collision with root package name */
    public int f6002m;

    public C0522g(AbstractC0530o abstractC0530o) {
        super(abstractC0530o);
        if (abstractC0530o instanceof C0526k) {
            this.e = 2;
        } else {
            this.e = 3;
        }
    }

    @Override // y.C0521f
    public final void d(int i) {
        if (this.f5999j) {
            return;
        }
        this.f5999j = true;
        this.f5997g = i;
        Iterator it = this.f6000k.iterator();
        while (it.hasNext()) {
            InterfaceC0519d interfaceC0519d = (InterfaceC0519d) it.next();
            interfaceC0519d.a(interfaceC0519d);
        }
    }
}
