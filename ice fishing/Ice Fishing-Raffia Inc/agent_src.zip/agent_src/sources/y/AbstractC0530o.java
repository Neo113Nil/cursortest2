package y;

import v.AbstractC0470e;
import x.C0494c;
import x.C0495d;

/* renamed from: y.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0530o implements InterfaceC0519d {

    /* renamed from: a, reason: collision with root package name */
    public int f6014a;

    /* renamed from: b, reason: collision with root package name */
    public C0495d f6015b;

    /* renamed from: c, reason: collision with root package name */
    public C0527l f6016c;

    /* renamed from: d, reason: collision with root package name */
    public int f6017d;
    public final C0522g e = new C0522g(this);

    /* renamed from: f, reason: collision with root package name */
    public int f6018f = 0;

    /* renamed from: g, reason: collision with root package name */
    public boolean f6019g = false;

    /* renamed from: h, reason: collision with root package name */
    public final C0521f f6020h = new C0521f(this);
    public final C0521f i = new C0521f(this);

    /* renamed from: j, reason: collision with root package name */
    public int f6021j = 1;

    public AbstractC0530o(C0495d c0495d) {
        this.f6015b = c0495d;
    }

    public static void b(C0521f c0521f, C0521f c0521f2, int i) {
        c0521f.f6001l.add(c0521f2);
        c0521f.f5996f = i;
        c0521f2.f6000k.add(c0521f);
    }

    public static C0521f h(C0494c c0494c) {
        C0494c c0494c2 = c0494c.f5786f;
        if (c0494c2 == null) {
            return null;
        }
        int iA = AbstractC0470e.a(c0494c2.e);
        C0495d c0495d = c0494c2.f5785d;
        if (iA == 1) {
            return c0495d.f5819d.f6020h;
        }
        if (iA == 2) {
            return c0495d.e.f6020h;
        }
        if (iA == 3) {
            return c0495d.f5819d.i;
        }
        if (iA == 4) {
            return c0495d.e.i;
        }
        if (iA != 5) {
            return null;
        }
        return c0495d.e.f6007k;
    }

    public static C0521f i(C0494c c0494c, int i) {
        C0494c c0494c2 = c0494c.f5786f;
        if (c0494c2 == null) {
            return null;
        }
        C0495d c0495d = c0494c2.f5785d;
        AbstractC0530o abstractC0530o = i == 0 ? c0495d.f5819d : c0495d.e;
        int iA = AbstractC0470e.a(c0494c2.e);
        if (iA == 1 || iA == 2) {
            return abstractC0530o.f6020h;
        }
        if (iA == 3 || iA == 4) {
            return abstractC0530o.i;
        }
        return null;
    }

    public final void c(C0521f c0521f, C0521f c0521f2, int i, C0522g c0522g) {
        c0521f.f6001l.add(c0521f2);
        c0521f.f6001l.add(this.e);
        c0521f.f5998h = i;
        c0521f.i = c0522g;
        c0521f2.f6000k.add(c0521f);
        c0522g.f6000k.add(c0521f);
    }

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public final int g(int i, int i3) {
        int iMax;
        if (i3 == 0) {
            C0495d c0495d = this.f6015b;
            int i4 = c0495d.f5848v;
            iMax = Math.max(c0495d.f5847u, i);
            if (i4 > 0) {
                iMax = Math.min(i4, i);
            }
            if (iMax == i) {
                return i;
            }
        } else {
            C0495d c0495d2 = this.f6015b;
            int i5 = c0495d2.f5851y;
            iMax = Math.max(c0495d2.f5850x, i);
            if (i5 > 0) {
                iMax = Math.min(i5, i);
            }
            if (iMax == i) {
                return i;
            }
        }
        return iMax;
    }

    public long j() {
        if (this.e.f5999j) {
            return r0.f5997g;
        }
        return 0L;
    }

    public abstract boolean k();

    /* JADX WARN: Removed duplicated region for block: B:28:0x0054  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void l(C0494c c0494c, C0494c c0494c2, int i) {
        C0521f c0521fH = h(c0494c);
        C0521f c0521fH2 = h(c0494c2);
        if (c0521fH.f5999j && c0521fH2.f5999j) {
            int iE = c0494c.e() + c0521fH.f5997g;
            int iE2 = c0521fH2.f5997g - c0494c2.e();
            int i3 = iE2 - iE;
            C0522g c0522g = this.e;
            if (!c0522g.f5999j && this.f6017d == 3) {
                int i4 = this.f6014a;
                if (i4 == 0) {
                    c0522g.d(g(i3, i));
                } else if (i4 == 1) {
                    c0522g.d(Math.min(g(c0522g.f6002m, i), i3));
                } else if (i4 == 2) {
                    C0495d c0495d = this.f6015b;
                    C0495d c0495d2 = c0495d.f5806T;
                    if (c0495d2 != null) {
                        if ((i == 0 ? c0495d2.f5819d : c0495d2.e).e.f5999j) {
                            c0522g.d(g((int) ((r6.f5997g * (i == 0 ? c0495d.f5849w : c0495d.f5852z)) + 0.5f), i));
                        }
                    }
                } else if (i4 == 3) {
                    C0495d c0495d3 = this.f6015b;
                    AbstractC0530o abstractC0530o = c0495d3.f5819d;
                    if (abstractC0530o.f6017d == 3 && abstractC0530o.f6014a == 3) {
                        C0528m c0528m = c0495d3.e;
                        if (c0528m.f6017d != 3 || c0528m.f6014a != 3) {
                        }
                    } else {
                        if (i == 0) {
                            abstractC0530o = c0495d3.e;
                        }
                        if (abstractC0530o.e.f5999j) {
                            float f3 = c0495d3.f5809W;
                            c0522g.d(i == 1 ? (int) ((r6.f5997g / f3) + 0.5f) : (int) ((f3 * r6.f5997g) + 0.5f));
                        }
                    }
                }
            }
            if (c0522g.f5999j) {
                int i5 = c0522g.f5997g;
                C0521f c0521f = this.i;
                C0521f c0521f2 = this.f6020h;
                if (i5 == i3) {
                    c0521f2.d(iE);
                    c0521f.d(iE2);
                    return;
                }
                float f4 = i == 0 ? this.f6015b.f5820d0 : this.f6015b.f5821e0;
                if (c0521fH == c0521fH2) {
                    iE = c0521fH.f5997g;
                    iE2 = c0521fH2.f5997g;
                    f4 = 0.5f;
                }
                c0521f2.d((int) ((((iE2 - iE) - i5) * f4) + iE + 0.5f));
                c0521f.d(c0521f2.f5997g + c0522g.f5997g);
            }
        }
    }
}
