package y;

import v.AbstractC0470e;
import x.C0494c;
import x.C0495d;

/* renamed from: y.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0528m extends AbstractC0530o {

    /* renamed from: k, reason: collision with root package name */
    public C0521f f6007k;

    /* renamed from: l, reason: collision with root package name */
    public C0516a f6008l;

    @Override // y.InterfaceC0519d
    public final void a(InterfaceC0519d interfaceC0519d) {
        float f3;
        float f4;
        float f5;
        int i;
        if (AbstractC0470e.a(this.f6021j) == 3) {
            C0495d c0495d = this.f6015b;
            l(c0495d.f5797J, c0495d.f5798L, 1);
            return;
        }
        C0522g c0522g = this.e;
        if (c0522g.f5994c && !c0522g.f5999j && this.f6017d == 3) {
            C0495d c0495d2 = this.f6015b;
            int i3 = c0495d2.f5845s;
            if (i3 == 2) {
                C0495d c0495d3 = c0495d2.f5806T;
                if (c0495d3 != null) {
                    if (c0495d3.e.e.f5999j) {
                        c0522g.d((int) ((r5.f5997g * c0495d2.f5852z) + 0.5f));
                    }
                }
            } else if (i3 == 3) {
                C0522g c0522g2 = c0495d2.f5819d.e;
                if (c0522g2.f5999j) {
                    int i4 = c0495d2.f5810X;
                    if (i4 == -1) {
                        f3 = c0522g2.f5997g;
                        f4 = c0495d2.f5809W;
                    } else if (i4 == 0) {
                        f5 = c0522g2.f5997g * c0495d2.f5809W;
                        i = (int) (f5 + 0.5f);
                        c0522g.d(i);
                    } else if (i4 != 1) {
                        i = 0;
                        c0522g.d(i);
                    } else {
                        f3 = c0522g2.f5997g;
                        f4 = c0495d2.f5809W;
                    }
                    f5 = f3 / f4;
                    i = (int) (f5 + 0.5f);
                    c0522g.d(i);
                }
            }
        }
        C0521f c0521f = this.f6020h;
        if (c0521f.f5994c) {
            C0521f c0521f2 = this.i;
            if (c0521f2.f5994c) {
                if (c0521f.f5999j && c0521f2.f5999j && c0522g.f5999j) {
                    return;
                }
                if (!c0522g.f5999j && this.f6017d == 3) {
                    C0495d c0495d4 = this.f6015b;
                    if (c0495d4.f5844r == 0 && !c0495d4.y()) {
                        C0521f c0521f3 = (C0521f) c0521f.f6001l.get(0);
                        C0521f c0521f4 = (C0521f) c0521f2.f6001l.get(0);
                        int i5 = c0521f3.f5997g + c0521f.f5996f;
                        int i6 = c0521f4.f5997g + c0521f2.f5996f;
                        c0521f.d(i5);
                        c0521f2.d(i6);
                        c0522g.d(i6 - i5);
                        return;
                    }
                }
                if (!c0522g.f5999j && this.f6017d == 3 && this.f6014a == 1 && c0521f.f6001l.size() > 0 && c0521f2.f6001l.size() > 0) {
                    C0521f c0521f5 = (C0521f) c0521f.f6001l.get(0);
                    int i7 = (((C0521f) c0521f2.f6001l.get(0)).f5997g + c0521f2.f5996f) - (c0521f5.f5997g + c0521f.f5996f);
                    int i8 = c0522g.f6002m;
                    if (i7 < i8) {
                        c0522g.d(i7);
                    } else {
                        c0522g.d(i8);
                    }
                }
                if (c0522g.f5999j && c0521f.f6001l.size() > 0 && c0521f2.f6001l.size() > 0) {
                    C0521f c0521f6 = (C0521f) c0521f.f6001l.get(0);
                    C0521f c0521f7 = (C0521f) c0521f2.f6001l.get(0);
                    int i9 = c0521f6.f5997g;
                    int i10 = c0521f.f5996f + i9;
                    int i11 = c0521f7.f5997g;
                    int i12 = c0521f2.f5996f + i11;
                    float f6 = this.f6015b.f5821e0;
                    if (c0521f6 == c0521f7) {
                        f6 = 0.5f;
                    } else {
                        i9 = i10;
                        i11 = i12;
                    }
                    c0521f.d((int) ((((i11 - i9) - c0522g.f5997g) * f6) + i9 + 0.5f));
                    c0521f2.d(c0521f.f5997g + c0522g.f5997g);
                }
            }
        }
    }

    @Override // y.AbstractC0530o
    public final void d() {
        C0495d c0495d;
        C0495d c0495d2;
        C0495d c0495d3;
        C0495d c0495d4;
        C0495d c0495d5 = this.f6015b;
        boolean z2 = c0495d5.f5813a;
        C0522g c0522g = this.e;
        if (z2) {
            c0522g.d(c0495d5.k());
        }
        boolean z3 = c0522g.f5999j;
        C0521f c0521f = this.i;
        C0521f c0521f2 = this.f6020h;
        if (!z3) {
            C0495d c0495d6 = this.f6015b;
            this.f6017d = c0495d6.f5842p0[1];
            if (c0495d6.f5793E) {
                this.f6008l = new C0516a(this);
            }
            int i = this.f6017d;
            if (i != 3) {
                if (i == 4 && (c0495d4 = this.f6015b.f5806T) != null && c0495d4.f5842p0[1] == 1) {
                    int iK = (c0495d4.k() - this.f6015b.f5797J.e()) - this.f6015b.f5798L.e();
                    AbstractC0530o.b(c0521f2, c0495d4.e.f6020h, this.f6015b.f5797J.e());
                    AbstractC0530o.b(c0521f, c0495d4.e.i, -this.f6015b.f5798L.e());
                    c0522g.d(iK);
                    return;
                }
                if (i == 1) {
                    c0522g.d(this.f6015b.k());
                }
            }
        } else if (this.f6017d == 4 && (c0495d2 = (c0495d = this.f6015b).f5806T) != null && c0495d2.f5842p0[1] == 1) {
            AbstractC0530o.b(c0521f2, c0495d2.e.f6020h, c0495d.f5797J.e());
            AbstractC0530o.b(c0521f, c0495d2.e.i, -this.f6015b.f5798L.e());
            return;
        }
        boolean z4 = c0522g.f5999j;
        C0521f c0521f3 = this.f6007k;
        if (z4) {
            C0495d c0495d7 = this.f6015b;
            if (c0495d7.f5813a) {
                C0494c[] c0494cArr = c0495d7.f5803Q;
                C0494c c0494c = c0494cArr[2];
                C0494c c0494c2 = c0494c.f5786f;
                if (c0494c2 != null && c0494cArr[3].f5786f != null) {
                    if (c0495d7.y()) {
                        c0521f2.f5996f = this.f6015b.f5803Q[2].e();
                        c0521f.f5996f = -this.f6015b.f5803Q[3].e();
                    } else {
                        C0521f c0521fH = AbstractC0530o.h(this.f6015b.f5803Q[2]);
                        if (c0521fH != null) {
                            AbstractC0530o.b(c0521f2, c0521fH, this.f6015b.f5803Q[2].e());
                        }
                        C0521f c0521fH2 = AbstractC0530o.h(this.f6015b.f5803Q[3]);
                        if (c0521fH2 != null) {
                            AbstractC0530o.b(c0521f, c0521fH2, -this.f6015b.f5803Q[3].e());
                        }
                        c0521f2.f5993b = true;
                        c0521f.f5993b = true;
                    }
                    C0495d c0495d8 = this.f6015b;
                    if (c0495d8.f5793E) {
                        AbstractC0530o.b(c0521f3, c0521f2, c0495d8.f5814a0);
                        return;
                    }
                    return;
                }
                if (c0494c2 != null) {
                    C0521f c0521fH3 = AbstractC0530o.h(c0494c);
                    if (c0521fH3 != null) {
                        AbstractC0530o.b(c0521f2, c0521fH3, this.f6015b.f5803Q[2].e());
                        AbstractC0530o.b(c0521f, c0521f2, c0522g.f5997g);
                        C0495d c0495d9 = this.f6015b;
                        if (c0495d9.f5793E) {
                            AbstractC0530o.b(c0521f3, c0521f2, c0495d9.f5814a0);
                            return;
                        }
                        return;
                    }
                    return;
                }
                C0494c c0494c3 = c0494cArr[3];
                if (c0494c3.f5786f != null) {
                    C0521f c0521fH4 = AbstractC0530o.h(c0494c3);
                    if (c0521fH4 != null) {
                        AbstractC0530o.b(c0521f, c0521fH4, -this.f6015b.f5803Q[3].e());
                        AbstractC0530o.b(c0521f2, c0521f, -c0522g.f5997g);
                    }
                    C0495d c0495d10 = this.f6015b;
                    if (c0495d10.f5793E) {
                        AbstractC0530o.b(c0521f3, c0521f2, c0495d10.f5814a0);
                        return;
                    }
                    return;
                }
                C0494c c0494c4 = c0494cArr[4];
                if (c0494c4.f5786f != null) {
                    C0521f c0521fH5 = AbstractC0530o.h(c0494c4);
                    if (c0521fH5 != null) {
                        AbstractC0530o.b(c0521f3, c0521fH5, 0);
                        AbstractC0530o.b(c0521f2, c0521f3, -this.f6015b.f5814a0);
                        AbstractC0530o.b(c0521f, c0521f2, c0522g.f5997g);
                        return;
                    }
                    return;
                }
                if ((c0495d7 instanceof x.i) || c0495d7.f5806T == null || c0495d7.i(7).f5786f != null) {
                    return;
                }
                C0495d c0495d11 = this.f6015b;
                AbstractC0530o.b(c0521f2, c0495d11.f5806T.e.f6020h, c0495d11.s());
                AbstractC0530o.b(c0521f, c0521f2, c0522g.f5997g);
                C0495d c0495d12 = this.f6015b;
                if (c0495d12.f5793E) {
                    AbstractC0530o.b(c0521f3, c0521f2, c0495d12.f5814a0);
                    return;
                }
                return;
            }
        }
        if (z4 || this.f6017d != 3) {
            c0522g.b(this);
        } else {
            C0495d c0495d13 = this.f6015b;
            int i3 = c0495d13.f5845s;
            if (i3 == 2) {
                C0495d c0495d14 = c0495d13.f5806T;
                if (c0495d14 != null) {
                    C0522g c0522g2 = c0495d14.e.e;
                    c0522g.f6001l.add(c0522g2);
                    c0522g2.f6000k.add(c0522g);
                    c0522g.f5993b = true;
                    c0522g.f6000k.add(c0521f2);
                    c0522g.f6000k.add(c0521f);
                }
            } else if (i3 == 3 && !c0495d13.y()) {
                C0495d c0495d15 = this.f6015b;
                if (c0495d15.f5844r != 3) {
                    C0522g c0522g3 = c0495d15.f5819d.e;
                    c0522g.f6001l.add(c0522g3);
                    c0522g3.f6000k.add(c0522g);
                    c0522g.f5993b = true;
                    c0522g.f6000k.add(c0521f2);
                    c0522g.f6000k.add(c0521f);
                }
            }
        }
        C0495d c0495d16 = this.f6015b;
        C0494c[] c0494cArr2 = c0495d16.f5803Q;
        C0494c c0494c5 = c0494cArr2[2];
        C0494c c0494c6 = c0494c5.f5786f;
        if (c0494c6 != null && c0494cArr2[3].f5786f != null) {
            if (c0495d16.y()) {
                c0521f2.f5996f = this.f6015b.f5803Q[2].e();
                c0521f.f5996f = -this.f6015b.f5803Q[3].e();
            } else {
                C0521f c0521fH6 = AbstractC0530o.h(this.f6015b.f5803Q[2]);
                C0521f c0521fH7 = AbstractC0530o.h(this.f6015b.f5803Q[3]);
                if (c0521fH6 != null) {
                    c0521fH6.b(this);
                }
                if (c0521fH7 != null) {
                    c0521fH7.b(this);
                }
                this.f6021j = 4;
            }
            if (this.f6015b.f5793E) {
                c(c0521f3, c0521f2, 1, this.f6008l);
            }
        } else if (c0494c6 != null) {
            C0521f c0521fH8 = AbstractC0530o.h(c0494c5);
            if (c0521fH8 != null) {
                AbstractC0530o.b(c0521f2, c0521fH8, this.f6015b.f5803Q[2].e());
                c(c0521f, c0521f2, 1, c0522g);
                if (this.f6015b.f5793E) {
                    c(c0521f3, c0521f2, 1, this.f6008l);
                }
                if (this.f6017d == 3) {
                    C0495d c0495d17 = this.f6015b;
                    if (c0495d17.f5809W > 0.0f) {
                        C0526k c0526k = c0495d17.f5819d;
                        if (c0526k.f6017d == 3) {
                            c0526k.e.f6000k.add(c0522g);
                            c0522g.f6001l.add(this.f6015b.f5819d.e);
                            c0522g.f5992a = this;
                        }
                    }
                }
            }
        } else {
            C0494c c0494c7 = c0494cArr2[3];
            if (c0494c7.f5786f != null) {
                C0521f c0521fH9 = AbstractC0530o.h(c0494c7);
                if (c0521fH9 != null) {
                    AbstractC0530o.b(c0521f, c0521fH9, -this.f6015b.f5803Q[3].e());
                    c(c0521f2, c0521f, -1, c0522g);
                    if (this.f6015b.f5793E) {
                        c(c0521f3, c0521f2, 1, this.f6008l);
                    }
                }
            } else {
                C0494c c0494c8 = c0494cArr2[4];
                if (c0494c8.f5786f != null) {
                    C0521f c0521fH10 = AbstractC0530o.h(c0494c8);
                    if (c0521fH10 != null) {
                        AbstractC0530o.b(c0521f3, c0521fH10, 0);
                        c(c0521f2, c0521f3, -1, this.f6008l);
                        c(c0521f, c0521f2, 1, c0522g);
                    }
                } else if (!(c0495d16 instanceof x.i) && (c0495d3 = c0495d16.f5806T) != null) {
                    AbstractC0530o.b(c0521f2, c0495d3.e.f6020h, c0495d16.s());
                    c(c0521f, c0521f2, 1, c0522g);
                    if (this.f6015b.f5793E) {
                        c(c0521f3, c0521f2, 1, this.f6008l);
                    }
                    if (this.f6017d == 3) {
                        C0495d c0495d18 = this.f6015b;
                        if (c0495d18.f5809W > 0.0f) {
                            C0526k c0526k2 = c0495d18.f5819d;
                            if (c0526k2.f6017d == 3) {
                                c0526k2.e.f6000k.add(c0522g);
                                c0522g.f6001l.add(this.f6015b.f5819d.e);
                                c0522g.f5992a = this;
                            }
                        }
                    }
                }
            }
        }
        if (c0522g.f6001l.size() == 0) {
            c0522g.f5994c = true;
        }
    }

    @Override // y.AbstractC0530o
    public final void e() {
        C0521f c0521f = this.f6020h;
        if (c0521f.f5999j) {
            this.f6015b.f5812Z = c0521f.f5997g;
        }
    }

    @Override // y.AbstractC0530o
    public final void f() {
        this.f6016c = null;
        this.f6020h.c();
        this.i.c();
        this.f6007k.c();
        this.e.c();
        this.f6019g = false;
    }

    @Override // y.AbstractC0530o
    public final boolean k() {
        return this.f6017d != 3 || this.f6015b.f5845s == 0;
    }

    public final void m() {
        this.f6019g = false;
        C0521f c0521f = this.f6020h;
        c0521f.c();
        c0521f.f5999j = false;
        C0521f c0521f2 = this.i;
        c0521f2.c();
        c0521f2.f5999j = false;
        C0521f c0521f3 = this.f6007k;
        c0521f3.c();
        c0521f3.f5999j = false;
        this.e.f5999j = false;
    }

    public final String toString() {
        return "VerticalRun " + this.f6015b.f5827h0;
    }
}
