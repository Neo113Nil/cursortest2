package y;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import x.C0494c;
import x.C0495d;
import x.C0496e;

/* renamed from: y.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0520e {

    /* renamed from: a, reason: collision with root package name */
    public C0496e f5985a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f5986b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f5987c;

    /* renamed from: d, reason: collision with root package name */
    public C0496e f5988d;
    public ArrayList e;

    /* renamed from: f, reason: collision with root package name */
    public A.f f5989f;

    /* renamed from: g, reason: collision with root package name */
    public C0517b f5990g;

    /* renamed from: h, reason: collision with root package name */
    public ArrayList f5991h;

    public final void a(C0521f c0521f, int i, ArrayList arrayList, C0527l c0527l) {
        AbstractC0530o abstractC0530o = c0521f.f5995d;
        if (abstractC0530o.f6016c == null) {
            C0496e c0496e = this.f5985a;
            if (abstractC0530o == c0496e.f5819d || abstractC0530o == c0496e.e) {
                return;
            }
            if (c0527l == null) {
                c0527l = new C0527l();
                c0527l.f6005a = null;
                c0527l.f6006b = new ArrayList();
                c0527l.f6005a = abstractC0530o;
                arrayList.add(c0527l);
            }
            abstractC0530o.f6016c = c0527l;
            c0527l.f6006b.add(abstractC0530o);
            C0521f c0521f2 = abstractC0530o.f6020h;
            Iterator it = c0521f2.f6000k.iterator();
            while (it.hasNext()) {
                InterfaceC0519d interfaceC0519d = (InterfaceC0519d) it.next();
                if (interfaceC0519d instanceof C0521f) {
                    a((C0521f) interfaceC0519d, i, arrayList, c0527l);
                }
            }
            C0521f c0521f3 = abstractC0530o.i;
            Iterator it2 = c0521f3.f6000k.iterator();
            while (it2.hasNext()) {
                InterfaceC0519d interfaceC0519d2 = (InterfaceC0519d) it2.next();
                if (interfaceC0519d2 instanceof C0521f) {
                    a((C0521f) interfaceC0519d2, i, arrayList, c0527l);
                }
            }
            if (i == 1 && (abstractC0530o instanceof C0528m)) {
                Iterator it3 = ((C0528m) abstractC0530o).f6007k.f6000k.iterator();
                while (it3.hasNext()) {
                    InterfaceC0519d interfaceC0519d3 = (InterfaceC0519d) it3.next();
                    if (interfaceC0519d3 instanceof C0521f) {
                        a((C0521f) interfaceC0519d3, i, arrayList, c0527l);
                    }
                }
            }
            Iterator it4 = c0521f2.f6001l.iterator();
            while (it4.hasNext()) {
                a((C0521f) it4.next(), i, arrayList, c0527l);
            }
            Iterator it5 = c0521f3.f6001l.iterator();
            while (it5.hasNext()) {
                a((C0521f) it5.next(), i, arrayList, c0527l);
            }
            if (i == 1 && (abstractC0530o instanceof C0528m)) {
                Iterator it6 = ((C0528m) abstractC0530o).f6007k.f6001l.iterator();
                while (it6.hasNext()) {
                    a((C0521f) it6.next(), i, arrayList, c0527l);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:162:0x0260 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:171:0x01f9 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:187:0x0008 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0185  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void b(C0496e c0496e) {
        int iQ;
        int iK;
        int i;
        int i3;
        int i4;
        int i5;
        Iterator it = c0496e.f5864q0.iterator();
        while (it.hasNext()) {
            C0495d c0495d = (C0495d) it.next();
            int[] iArr = c0495d.f5842p0;
            int i6 = iArr[0];
            int i7 = iArr[1];
            if (c0495d.f5825g0 == 8) {
                c0495d.f5813a = true;
            } else {
                float f3 = c0495d.f5849w;
                if (f3 < 1.0f && i6 == 3) {
                    c0495d.f5844r = 2;
                }
                float f4 = c0495d.f5852z;
                if (f4 < 1.0f && i7 == 3) {
                    c0495d.f5845s = 2;
                }
                if (c0495d.f5809W > 0.0f) {
                    if (i6 == 3 && (i7 == 2 || i7 == 1)) {
                        c0495d.f5844r = 3;
                    } else if (i7 == 3 && (i6 == 2 || i6 == 1)) {
                        c0495d.f5845s = 3;
                    } else if (i6 == 3 && i7 == 3) {
                        if (c0495d.f5844r == 0) {
                            c0495d.f5844r = 3;
                        }
                        if (c0495d.f5845s == 0) {
                            c0495d.f5845s = 3;
                        }
                    }
                }
                C0494c c0494c = c0495d.K;
                C0494c c0494c2 = c0495d.f5796I;
                if (i6 == 3 && c0495d.f5844r == 1 && (c0494c2.f5786f == null || c0494c.f5786f == null)) {
                    i6 = 2;
                }
                C0494c c0494c3 = c0495d.f5798L;
                C0494c c0494c4 = c0495d.f5797J;
                int i8 = (i7 == 3 && c0495d.f5845s == 1 && (c0494c4.f5786f == null || c0494c3.f5786f == null)) ? 2 : i7;
                C0526k c0526k = c0495d.f5819d;
                c0526k.f6017d = i6;
                int i9 = c0495d.f5844r;
                c0526k.f6014a = i9;
                C0528m c0528m = c0495d.e;
                c0528m.f6017d = i8;
                int i10 = c0495d.f5845s;
                c0528m.f6014a = i10;
                if ((i6 == 4 || i6 == 1 || i6 == 2) && (i8 == 4 || i8 == 1 || i8 == 2)) {
                    int iQ2 = c0495d.q();
                    if (i6 == 4) {
                        iQ = (c0496e.q() - c0494c2.f5787g) - c0494c.f5787g;
                        i6 = 1;
                    } else {
                        iQ = iQ2;
                    }
                    int iK2 = c0495d.k();
                    if (i8 == 4) {
                        iK = (c0496e.k() - c0494c4.f5787g) - c0494c3.f5787g;
                        i = 1;
                    } else {
                        iK = iK2;
                        i = i8;
                    }
                    f(i6, iQ, i, iK, c0495d);
                    c0495d.f5819d.e.d(c0495d.q());
                    c0495d.e.e.d(c0495d.k());
                    c0495d.f5813a = true;
                } else {
                    int[] iArr2 = c0496e.f5842p0;
                    C0494c[] c0494cArr = c0495d.f5803Q;
                    if (i6 != 3 || (i8 != 2 && i8 != 1)) {
                        i3 = 3;
                        if (i8 == i3) {
                            if (i6 != 2 && i6 != 1) {
                                i5 = i3;
                                i4 = 1;
                                if (i6 != i5) {
                                }
                            } else if (i10 == i3) {
                                if (i6 == 2) {
                                    f(2, 0, 2, 0, c0495d);
                                }
                                int iQ3 = c0495d.q();
                                float f5 = c0495d.f5809W;
                                if (c0495d.f5810X == -1) {
                                    f5 = 1.0f / f5;
                                }
                                f(1, iQ3, 1, (int) ((iQ3 * f5) + 0.5f), c0495d);
                                c0495d.f5819d.e.d(c0495d.q());
                                c0495d.e.e.d(c0495d.k());
                                c0495d.f5813a = true;
                            } else if (i10 == 1) {
                                f(i6, 0, 2, 0, c0495d);
                                c0495d.e.e.f6002m = c0495d.k();
                            } else {
                                if (i10 == 2) {
                                    int i11 = iArr2[1];
                                    if (i11 == 1 || i11 == 4) {
                                        f(i6, c0495d.q(), 1, (int) ((f4 * c0496e.k()) + 0.5f), c0495d);
                                        c0495d.f5819d.e.d(c0495d.q());
                                        c0495d.e.e.d(c0495d.k());
                                        c0495d.f5813a = true;
                                    }
                                } else if (c0494cArr[2].f5786f == null || c0494cArr[3].f5786f == null) {
                                    f(2, 0, i8, 0, c0495d);
                                    c0495d.f5819d.e.d(c0495d.q());
                                    c0495d.e.e.d(c0495d.k());
                                    c0495d.f5813a = true;
                                }
                                if (i6 != i5 && i8 == i5) {
                                    if (i9 == i4 || i10 == i4) {
                                        f(2, 0, 2, 0, c0495d);
                                        c0495d.f5819d.e.f6002m = c0495d.q();
                                        c0495d.e.e.f6002m = c0495d.k();
                                    } else if (i10 == 2 && i9 == 2 && iArr2[0] == 1 && iArr2[i4] == 1) {
                                        f(1, (int) ((f3 * c0496e.q()) + 0.5f), 1, (int) ((f4 * c0496e.k()) + 0.5f), c0495d);
                                        c0495d.f5819d.e.d(c0495d.q());
                                        c0495d.e.e.d(c0495d.k());
                                        c0495d.f5813a = true;
                                    }
                                }
                            }
                        }
                        i4 = 1;
                        i5 = 3;
                        if (i6 != i5) {
                        }
                    } else if (i9 == 3) {
                        if (i8 == 2) {
                            f(2, 0, 2, 0, c0495d);
                        }
                        int iK3 = c0495d.k();
                        f(1, (int) ((iK3 * c0495d.f5809W) + 0.5f), 1, iK3, c0495d);
                        c0495d.f5819d.e.d(c0495d.q());
                        c0495d.e.e.d(c0495d.k());
                        c0495d.f5813a = true;
                    } else if (i9 == 1) {
                        f(2, 0, i8, 0, c0495d);
                        c0495d.f5819d.e.f6002m = c0495d.q();
                    } else {
                        if (i9 == 2) {
                            int i12 = iArr2[0];
                            if (i12 == 1 || i12 == 4) {
                                f(1, (int) ((f3 * c0496e.q()) + 0.5f), i8, c0495d.k(), c0495d);
                                c0495d.f5819d.e.d(c0495d.q());
                                c0495d.e.e.d(c0495d.k());
                                c0495d.f5813a = true;
                            } else {
                                i3 = 3;
                            }
                        } else if (c0494cArr[0].f5786f == null || c0494cArr[1].f5786f == null) {
                            f(2, 0, i8, 0, c0495d);
                            c0495d.f5819d.e.d(c0495d.q());
                            c0495d.e.e.d(c0495d.k());
                            c0495d.f5813a = true;
                        } else {
                            i3 = 3;
                        }
                        if (i8 == i3) {
                        }
                        i4 = 1;
                        i5 = 3;
                        if (i6 != i5) {
                        }
                    }
                }
            }
        }
    }

    public final void c() {
        ArrayList arrayList = this.e;
        arrayList.clear();
        C0496e c0496e = this.f5988d;
        c0496e.f5819d.f();
        c0496e.e.f();
        arrayList.add(c0496e.f5819d);
        arrayList.add(c0496e.e);
        Iterator it = c0496e.f5864q0.iterator();
        HashSet hashSet = null;
        while (it.hasNext()) {
            C0495d c0495d = (C0495d) it.next();
            if (c0495d instanceof x.h) {
                C0524i c0524i = new C0524i(c0495d);
                c0495d.f5819d.f();
                c0495d.e.f();
                c0524i.f6018f = ((x.h) c0495d).f5928u0;
                arrayList.add(c0524i);
            } else {
                if (c0495d.x()) {
                    if (c0495d.f5815b == null) {
                        c0495d.f5815b = new C0518c(c0495d, 0);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(c0495d.f5815b);
                } else {
                    arrayList.add(c0495d.f5819d);
                }
                if (c0495d.y()) {
                    if (c0495d.f5817c == null) {
                        c0495d.f5817c = new C0518c(c0495d, 1);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(c0495d.f5817c);
                } else {
                    arrayList.add(c0495d.e);
                }
                if (c0495d instanceof x.i) {
                    arrayList.add(new C0525j(c0495d));
                }
            }
        }
        if (hashSet != null) {
            arrayList.addAll(hashSet);
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            ((AbstractC0530o) it2.next()).f();
        }
        Iterator it3 = arrayList.iterator();
        while (it3.hasNext()) {
            AbstractC0530o abstractC0530o = (AbstractC0530o) it3.next();
            if (abstractC0530o.f6015b != c0496e) {
                abstractC0530o.d();
            }
        }
        ArrayList arrayList2 = this.f5991h;
        arrayList2.clear();
        C0496e c0496e2 = this.f5985a;
        e(c0496e2.f5819d, 0, arrayList2);
        e(c0496e2.e, 1, arrayList2);
        this.f5986b = false;
    }

    public final int d(C0496e c0496e, int i) {
        ArrayList arrayList;
        int i3;
        int i4;
        long jMax;
        float f3;
        C0496e c0496e2 = c0496e;
        ArrayList arrayList2 = this.f5991h;
        int size = arrayList2.size();
        int i5 = 0;
        long jMax2 = 0;
        while (i5 < size) {
            AbstractC0530o abstractC0530o = ((C0527l) arrayList2.get(i5)).f6005a;
            if (!(abstractC0530o instanceof C0518c) ? !(i != 0 ? (abstractC0530o instanceof C0528m) : (abstractC0530o instanceof C0526k)) : ((C0518c) abstractC0530o).f6018f != i) {
                C0521f c0521f = (i == 0 ? c0496e2.f5819d : c0496e2.e).f6020h;
                C0521f c0521f2 = (i == 0 ? c0496e2.f5819d : c0496e2.e).i;
                boolean zContains = abstractC0530o.f6020h.f6001l.contains(c0521f);
                C0521f c0521f3 = abstractC0530o.i;
                boolean zContains2 = c0521f3.f6001l.contains(c0521f2);
                long j3 = abstractC0530o.j();
                C0521f c0521f4 = abstractC0530o.f6020h;
                if (zContains && zContains2) {
                    long jB = C0527l.b(c0521f4, 0L);
                    ArrayList arrayList3 = arrayList2;
                    i3 = size;
                    long jA = C0527l.a(c0521f3, 0L);
                    long j4 = jB - j3;
                    int i6 = c0521f3.f5996f;
                    arrayList = arrayList3;
                    i4 = i5;
                    if (j4 >= (-i6)) {
                        j4 += i6;
                    }
                    long j5 = (-jA) - j3;
                    long j6 = c0521f4.f5996f;
                    long j7 = j5 - j6;
                    if (j7 >= j6) {
                        j7 -= j6;
                    }
                    C0495d c0495d = abstractC0530o.f6015b;
                    if (i == 0) {
                        f3 = c0495d.f5820d0;
                    } else if (i == 1) {
                        f3 = c0495d.f5821e0;
                    } else {
                        c0495d.getClass();
                        f3 = -1.0f;
                    }
                    float f4 = f3 > 0.0f ? (long) ((j4 / (1.0f - f3)) + (j7 / f3)) : 0L;
                    jMax = (c0521f4.f5996f + ((((long) ((f4 * f3) + 0.5f)) + j3) + ((long) (((1.0f - f3) * f4) + 0.5f)))) - c0521f3.f5996f;
                } else {
                    arrayList = arrayList2;
                    i3 = size;
                    i4 = i5;
                    jMax = zContains ? Math.max(C0527l.b(c0521f4, c0521f4.f5996f), c0521f4.f5996f + j3) : zContains2 ? Math.max(-C0527l.a(c0521f3, c0521f3.f5996f), (-c0521f3.f5996f) + j3) : (abstractC0530o.j() + c0521f4.f5996f) - c0521f3.f5996f;
                }
            } else {
                arrayList = arrayList2;
                i3 = size;
                i4 = i5;
                jMax = 0;
            }
            jMax2 = Math.max(jMax2, jMax);
            i5 = i4 + 1;
            c0496e2 = c0496e;
            size = i3;
            arrayList2 = arrayList;
        }
        return (int) jMax2;
    }

    public final void e(AbstractC0530o abstractC0530o, int i, ArrayList arrayList) {
        C0521f c0521f;
        Iterator it = abstractC0530o.f6020h.f6000k.iterator();
        while (true) {
            boolean zHasNext = it.hasNext();
            c0521f = abstractC0530o.i;
            if (!zHasNext) {
                break;
            }
            InterfaceC0519d interfaceC0519d = (InterfaceC0519d) it.next();
            if (interfaceC0519d instanceof C0521f) {
                a((C0521f) interfaceC0519d, i, arrayList, null);
            } else if (interfaceC0519d instanceof AbstractC0530o) {
                a(((AbstractC0530o) interfaceC0519d).f6020h, i, arrayList, null);
            }
        }
        Iterator it2 = c0521f.f6000k.iterator();
        while (it2.hasNext()) {
            InterfaceC0519d interfaceC0519d2 = (InterfaceC0519d) it2.next();
            if (interfaceC0519d2 instanceof C0521f) {
                a((C0521f) interfaceC0519d2, i, arrayList, null);
            } else if (interfaceC0519d2 instanceof AbstractC0530o) {
                a(((AbstractC0530o) interfaceC0519d2).i, i, arrayList, null);
            }
        }
        if (i == 1) {
            Iterator it3 = ((C0528m) abstractC0530o).f6007k.f6000k.iterator();
            while (it3.hasNext()) {
                InterfaceC0519d interfaceC0519d3 = (InterfaceC0519d) it3.next();
                if (interfaceC0519d3 instanceof C0521f) {
                    a((C0521f) interfaceC0519d3, i, arrayList, null);
                }
            }
        }
    }

    public final void f(int i, int i3, int i4, int i5, C0495d c0495d) {
        C0517b c0517b = this.f5990g;
        c0517b.f5975a = i;
        c0517b.f5976b = i4;
        c0517b.f5977c = i3;
        c0517b.f5978d = i5;
        this.f5989f.b(c0495d, c0517b);
        c0495d.O(c0517b.e);
        c0495d.L(c0517b.f5979f);
        c0495d.f5793E = c0517b.f5981h;
        c0495d.I(c0517b.f5980g);
    }

    public final void g() {
        C0516a c0516a;
        Iterator it = this.f5985a.f5864q0.iterator();
        while (it.hasNext()) {
            C0495d c0495d = (C0495d) it.next();
            if (!c0495d.f5813a) {
                int[] iArr = c0495d.f5842p0;
                boolean z2 = false;
                int i = iArr[0];
                int i3 = iArr[1];
                int i4 = c0495d.f5844r;
                int i5 = c0495d.f5845s;
                boolean z3 = i == 2 || (i == 3 && i4 == 1);
                if (i3 == 2 || (i3 == 3 && i5 == 1)) {
                    z2 = true;
                }
                C0522g c0522g = c0495d.f5819d.e;
                boolean z4 = c0522g.f5999j;
                C0522g c0522g2 = c0495d.e.e;
                boolean z5 = c0522g2.f5999j;
                if (z4 && z5) {
                    f(1, c0522g.f5997g, 1, c0522g2.f5997g, c0495d);
                    c0495d.f5813a = true;
                } else if (z4 && z2) {
                    f(1, c0522g.f5997g, 2, c0522g2.f5997g, c0495d);
                    if (i3 == 3) {
                        c0495d.e.e.f6002m = c0495d.k();
                    } else {
                        c0495d.e.e.d(c0495d.k());
                        c0495d.f5813a = true;
                    }
                } else if (z5 && z3) {
                    f(2, c0522g.f5997g, 1, c0522g2.f5997g, c0495d);
                    if (i == 3) {
                        c0495d.f5819d.e.f6002m = c0495d.q();
                    } else {
                        c0495d.f5819d.e.d(c0495d.q());
                        c0495d.f5813a = true;
                    }
                }
                if (c0495d.f5813a && (c0516a = c0495d.e.f6008l) != null) {
                    c0516a.d(c0495d.f5814a0);
                }
            }
        }
    }
}
