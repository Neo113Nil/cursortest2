package y;

import x.C0495d;

/* renamed from: y.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0524i extends AbstractC0530o {
    @Override // y.InterfaceC0519d
    public final void a(InterfaceC0519d interfaceC0519d) {
        C0521f c0521f = this.f6020h;
        if (c0521f.f5994c && !c0521f.f5999j) {
            c0521f.d((int) ((((C0521f) c0521f.f6001l.get(0)).f5997g * ((x.h) this.f6015b).f5924q0) + 0.5f));
        }
    }

    @Override // y.AbstractC0530o
    public final void d() {
        C0495d c0495d = this.f6015b;
        x.h hVar = (x.h) c0495d;
        int i = hVar.f5925r0;
        int i3 = hVar.f5926s0;
        int i4 = hVar.f5928u0;
        C0521f c0521f = this.f6020h;
        if (i4 == 1) {
            if (i != -1) {
                c0521f.f6001l.add(c0495d.f5806T.f5819d.f6020h);
                this.f6015b.f5806T.f5819d.f6020h.f6000k.add(c0521f);
                c0521f.f5996f = i;
            } else if (i3 != -1) {
                c0521f.f6001l.add(c0495d.f5806T.f5819d.i);
                this.f6015b.f5806T.f5819d.i.f6000k.add(c0521f);
                c0521f.f5996f = -i3;
            } else {
                c0521f.f5993b = true;
                c0521f.f6001l.add(c0495d.f5806T.f5819d.i);
                this.f6015b.f5806T.f5819d.i.f6000k.add(c0521f);
            }
            m(this.f6015b.f5819d.f6020h);
            m(this.f6015b.f5819d.i);
            return;
        }
        if (i != -1) {
            c0521f.f6001l.add(c0495d.f5806T.e.f6020h);
            this.f6015b.f5806T.e.f6020h.f6000k.add(c0521f);
            c0521f.f5996f = i;
        } else if (i3 != -1) {
            c0521f.f6001l.add(c0495d.f5806T.e.i);
            this.f6015b.f5806T.e.i.f6000k.add(c0521f);
            c0521f.f5996f = -i3;
        } else {
            c0521f.f5993b = true;
            c0521f.f6001l.add(c0495d.f5806T.e.i);
            this.f6015b.f5806T.e.i.f6000k.add(c0521f);
        }
        m(this.f6015b.e.f6020h);
        m(this.f6015b.e.i);
    }

    @Override // y.AbstractC0530o
    public final void e() {
        C0495d c0495d = this.f6015b;
        int i = ((x.h) c0495d).f5928u0;
        C0521f c0521f = this.f6020h;
        if (i == 1) {
            c0495d.f5811Y = c0521f.f5997g;
        } else {
            c0495d.f5812Z = c0521f.f5997g;
        }
    }

    @Override // y.AbstractC0530o
    public final void f() {
        this.f6020h.c();
    }

    @Override // y.AbstractC0530o
    public final boolean k() {
        return false;
    }

    public final void m(C0521f c0521f) {
        C0521f c0521f2 = this.f6020h;
        c0521f2.f6000k.add(c0521f);
        c0521f.f6001l.add(c0521f2);
    }
}
