package y;

/* renamed from: y.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0517b {

    /* renamed from: a, reason: collision with root package name */
    public int f5975a;

    /* renamed from: b, reason: collision with root package name */
    public int f5976b;

    /* renamed from: c, reason: collision with root package name */
    public int f5977c;

    /* renamed from: d, reason: collision with root package name */
    public int f5978d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f5979f;

    /* renamed from: g, reason: collision with root package name */
    public int f5980g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f5981h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public int f5982j;
}
