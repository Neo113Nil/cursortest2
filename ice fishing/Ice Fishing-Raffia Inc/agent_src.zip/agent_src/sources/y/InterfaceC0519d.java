package y;

/* renamed from: y.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0519d {
    void a(InterfaceC0519d interfaceC0519d);
}
