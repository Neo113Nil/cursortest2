package y;

import java.util.ArrayList;
import v.AbstractC0470e;
import x.C0494c;
import x.C0495d;

/* renamed from: y.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0526k extends AbstractC0530o {

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f6004k = new int[2];

    public static void m(int[] iArr, int i, int i3, int i4, int i5, float f3, int i6) {
        int i7 = i3 - i;
        int i8 = i5 - i4;
        if (i6 != -1) {
            if (i6 == 0) {
                iArr[0] = (int) ((i8 * f3) + 0.5f);
                iArr[1] = i8;
                return;
            } else {
                if (i6 != 1) {
                    return;
                }
                iArr[0] = i7;
                iArr[1] = (int) ((i7 * f3) + 0.5f);
                return;
            }
        }
        int i9 = (int) ((i8 * f3) + 0.5f);
        int i10 = (int) ((i7 / f3) + 0.5f);
        if (i9 <= i7) {
            iArr[0] = i9;
            iArr[1] = i8;
        } else if (i10 <= i8) {
            iArr[0] = i7;
            iArr[1] = i10;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:118:0x0267  */
    @Override // y.InterfaceC0519d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(InterfaceC0519d interfaceC0519d) {
        float f3;
        float f4;
        float f5;
        int i;
        if (AbstractC0470e.a(this.f6021j) == 3) {
            C0495d c0495d = this.f6015b;
            l(c0495d.f5796I, c0495d.K, 0);
            return;
        }
        C0522g c0522g = this.e;
        boolean z2 = c0522g.f5999j;
        C0521f c0521f = this.f6020h;
        C0521f c0521f2 = this.i;
        if (!z2 && this.f6017d == 3) {
            C0495d c0495d2 = this.f6015b;
            int i3 = c0495d2.f5844r;
            if (i3 == 2) {
                C0495d c0495d3 = c0495d2.f5806T;
                if (c0495d3 != null) {
                    if (c0495d3.f5819d.e.f5999j) {
                        c0522g.d((int) ((r3.f5997g * c0495d2.f5849w) + 0.5f));
                    }
                }
            } else if (i3 == 3) {
                int i4 = c0495d2.f5845s;
                if (i4 == 0 || i4 == 3) {
                    C0528m c0528m = c0495d2.e;
                    C0521f c0521f3 = c0528m.f6020h;
                    C0521f c0521f4 = c0528m.i;
                    boolean z3 = c0495d2.f5796I.f5786f != null;
                    boolean z4 = c0495d2.f5797J.f5786f != null;
                    boolean z5 = c0495d2.K.f5786f != null;
                    boolean z6 = c0495d2.f5798L.f5786f != null;
                    int i5 = c0495d2.f5810X;
                    if (z3 && z4 && z5 && z6) {
                        float f6 = c0495d2.f5809W;
                        boolean z7 = c0521f3.f5999j;
                        int[] iArr = f6004k;
                        if (z7 && c0521f4.f5999j) {
                            if (c0521f.f5994c && c0521f2.f5994c) {
                                m(iArr, ((C0521f) c0521f.f6001l.get(0)).f5997g + c0521f.f5996f, ((C0521f) c0521f2.f6001l.get(0)).f5997g - c0521f2.f5996f, c0521f3.f5997g + c0521f3.f5996f, c0521f4.f5997g - c0521f4.f5996f, f6, i5);
                                c0522g.d(iArr[0]);
                                this.f6015b.e.e.d(iArr[1]);
                                return;
                            }
                            return;
                        }
                        boolean z8 = c0521f.f5999j;
                        ArrayList arrayList = c0521f3.f6001l;
                        if (z8 && c0521f2.f5999j) {
                            if (!c0521f3.f5994c || !c0521f4.f5994c) {
                                return;
                            }
                            m(iArr, c0521f.f5997g + c0521f.f5996f, c0521f2.f5997g - c0521f2.f5996f, ((C0521f) arrayList.get(0)).f5997g + c0521f3.f5996f, ((C0521f) c0521f4.f6001l.get(0)).f5997g - c0521f4.f5996f, f6, i5);
                            c0522g.d(iArr[0]);
                            this.f6015b.e.e.d(iArr[1]);
                        }
                        if (!c0521f.f5994c || !c0521f2.f5994c || !c0521f3.f5994c || !c0521f4.f5994c) {
                            return;
                        }
                        m(iArr, ((C0521f) c0521f.f6001l.get(0)).f5997g + c0521f.f5996f, ((C0521f) c0521f2.f6001l.get(0)).f5997g - c0521f2.f5996f, ((C0521f) arrayList.get(0)).f5997g + c0521f3.f5996f, ((C0521f) c0521f4.f6001l.get(0)).f5997g - c0521f4.f5996f, f6, i5);
                        c0522g.d(iArr[0]);
                        this.f6015b.e.e.d(iArr[1]);
                    } else if (z3 && z5) {
                        if (!c0521f.f5994c || !c0521f2.f5994c) {
                            return;
                        }
                        float f7 = c0495d2.f5809W;
                        int i6 = ((C0521f) c0521f.f6001l.get(0)).f5997g + c0521f.f5996f;
                        int i7 = ((C0521f) c0521f2.f6001l.get(0)).f5997g - c0521f2.f5996f;
                        if (i5 == -1 || i5 == 0) {
                            int iG = g(i7 - i6, 0);
                            int i8 = (int) ((iG * f7) + 0.5f);
                            int iG2 = g(i8, 1);
                            if (i8 != iG2) {
                                iG = (int) ((iG2 / f7) + 0.5f);
                            }
                            c0522g.d(iG);
                            this.f6015b.e.e.d(iG2);
                        } else if (i5 == 1) {
                            int iG3 = g(i7 - i6, 0);
                            int i9 = (int) ((iG3 / f7) + 0.5f);
                            int iG4 = g(i9, 1);
                            if (i9 != iG4) {
                                iG3 = (int) ((iG4 * f7) + 0.5f);
                            }
                            c0522g.d(iG3);
                            this.f6015b.e.e.d(iG4);
                        }
                    } else if (z4 && z6) {
                        if (!c0521f3.f5994c || !c0521f4.f5994c) {
                            return;
                        }
                        float f8 = c0495d2.f5809W;
                        int i10 = ((C0521f) c0521f3.f6001l.get(0)).f5997g + c0521f3.f5996f;
                        int i11 = ((C0521f) c0521f4.f6001l.get(0)).f5997g - c0521f4.f5996f;
                        if (i5 == -1) {
                            int iG5 = g(i11 - i10, 1);
                            int i12 = (int) ((iG5 / f8) + 0.5f);
                            int iG6 = g(i12, 0);
                            if (i12 != iG6) {
                                iG5 = (int) ((iG6 * f8) + 0.5f);
                            }
                            c0522g.d(iG6);
                            this.f6015b.e.e.d(iG5);
                        } else if (i5 == 0) {
                            int iG7 = g(i11 - i10, 1);
                            int i13 = (int) ((iG7 * f8) + 0.5f);
                            int iG8 = g(i13, 0);
                            if (i13 != iG8) {
                                iG7 = (int) ((iG8 / f8) + 0.5f);
                            }
                            c0522g.d(iG8);
                            this.f6015b.e.e.d(iG7);
                        } else if (i5 == 1) {
                        }
                    }
                } else {
                    int i14 = c0495d2.f5810X;
                    if (i14 == -1) {
                        f3 = c0495d2.e.e.f5997g;
                        f4 = c0495d2.f5809W;
                    } else if (i14 == 0) {
                        f5 = c0495d2.e.e.f5997g / c0495d2.f5809W;
                        i = (int) (f5 + 0.5f);
                        c0522g.d(i);
                    } else if (i14 != 1) {
                        i = 0;
                        c0522g.d(i);
                    } else {
                        f3 = c0495d2.e.e.f5997g;
                        f4 = c0495d2.f5809W;
                    }
                    f5 = f3 * f4;
                    i = (int) (f5 + 0.5f);
                    c0522g.d(i);
                }
            }
        }
        if (c0521f.f5994c && c0521f2.f5994c) {
            if (c0521f.f5999j && c0521f2.f5999j && c0522g.f5999j) {
                return;
            }
            if (!c0522g.f5999j && this.f6017d == 3) {
                C0495d c0495d4 = this.f6015b;
                if (c0495d4.f5844r == 0 && !c0495d4.x()) {
                    C0521f c0521f5 = (C0521f) c0521f.f6001l.get(0);
                    C0521f c0521f6 = (C0521f) c0521f2.f6001l.get(0);
                    int i15 = c0521f5.f5997g + c0521f.f5996f;
                    int i16 = c0521f6.f5997g + c0521f2.f5996f;
                    c0521f.d(i15);
                    c0521f2.d(i16);
                    c0522g.d(i16 - i15);
                    return;
                }
            }
            if (!c0522g.f5999j && this.f6017d == 3 && this.f6014a == 1 && c0521f.f6001l.size() > 0 && c0521f2.f6001l.size() > 0) {
                int iMin = Math.min((((C0521f) c0521f2.f6001l.get(0)).f5997g + c0521f2.f5996f) - (((C0521f) c0521f.f6001l.get(0)).f5997g + c0521f.f5996f), c0522g.f6002m);
                C0495d c0495d5 = this.f6015b;
                int i17 = c0495d5.f5848v;
                int iMax = Math.max(c0495d5.f5847u, iMin);
                if (i17 > 0) {
                    iMax = Math.min(i17, iMax);
                }
                c0522g.d(iMax);
            }
            if (c0522g.f5999j) {
                C0521f c0521f7 = (C0521f) c0521f.f6001l.get(0);
                C0521f c0521f8 = (C0521f) c0521f2.f6001l.get(0);
                int i18 = c0521f7.f5997g;
                int i19 = c0521f.f5996f + i18;
                int i20 = c0521f8.f5997g;
                int i21 = c0521f2.f5996f + i20;
                float f9 = this.f6015b.f5820d0;
                if (c0521f7 == c0521f8) {
                    f9 = 0.5f;
                } else {
                    i18 = i19;
                    i20 = i21;
                }
                c0521f.d((int) ((((i20 - i18) - c0522g.f5997g) * f9) + i18 + 0.5f));
                c0521f2.d(c0521f.f5997g + c0522g.f5997g);
            }
        }
    }

    @Override // y.AbstractC0530o
    public final void d() {
        C0495d c0495d;
        C0495d c0495d2;
        int i;
        C0495d c0495d3;
        C0495d c0495d4;
        int i3;
        C0495d c0495d5 = this.f6015b;
        boolean z2 = c0495d5.f5813a;
        C0522g c0522g = this.e;
        if (z2) {
            c0522g.d(c0495d5.q());
        }
        boolean z3 = c0522g.f5999j;
        C0521f c0521f = this.i;
        C0521f c0521f2 = this.f6020h;
        if (!z3) {
            C0495d c0495d6 = this.f6015b;
            int i4 = c0495d6.f5842p0[0];
            this.f6017d = i4;
            if (i4 != 3) {
                if (i4 == 4 && (c0495d4 = c0495d6.f5806T) != null && ((i3 = c0495d4.f5842p0[0]) == 1 || i3 == 4)) {
                    int iQ = (c0495d4.q() - this.f6015b.f5796I.e()) - this.f6015b.K.e();
                    AbstractC0530o.b(c0521f2, c0495d4.f5819d.f6020h, this.f6015b.f5796I.e());
                    AbstractC0530o.b(c0521f, c0495d4.f5819d.i, -this.f6015b.K.e());
                    c0522g.d(iQ);
                    return;
                }
                if (i4 == 1) {
                    c0522g.d(c0495d6.q());
                }
            }
        } else if (this.f6017d == 4 && (c0495d2 = (c0495d = this.f6015b).f5806T) != null && ((i = c0495d2.f5842p0[0]) == 1 || i == 4)) {
            AbstractC0530o.b(c0521f2, c0495d2.f5819d.f6020h, c0495d.f5796I.e());
            AbstractC0530o.b(c0521f, c0495d2.f5819d.i, -this.f6015b.K.e());
            return;
        }
        if (c0522g.f5999j) {
            C0495d c0495d7 = this.f6015b;
            if (c0495d7.f5813a) {
                C0494c[] c0494cArr = c0495d7.f5803Q;
                C0494c c0494c = c0494cArr[0];
                C0494c c0494c2 = c0494c.f5786f;
                if (c0494c2 != null && c0494cArr[1].f5786f != null) {
                    if (c0495d7.x()) {
                        c0521f2.f5996f = this.f6015b.f5803Q[0].e();
                        c0521f.f5996f = -this.f6015b.f5803Q[1].e();
                        return;
                    }
                    C0521f c0521fH = AbstractC0530o.h(this.f6015b.f5803Q[0]);
                    if (c0521fH != null) {
                        AbstractC0530o.b(c0521f2, c0521fH, this.f6015b.f5803Q[0].e());
                    }
                    C0521f c0521fH2 = AbstractC0530o.h(this.f6015b.f5803Q[1]);
                    if (c0521fH2 != null) {
                        AbstractC0530o.b(c0521f, c0521fH2, -this.f6015b.f5803Q[1].e());
                    }
                    c0521f2.f5993b = true;
                    c0521f.f5993b = true;
                    return;
                }
                if (c0494c2 != null) {
                    C0521f c0521fH3 = AbstractC0530o.h(c0494c);
                    if (c0521fH3 != null) {
                        AbstractC0530o.b(c0521f2, c0521fH3, this.f6015b.f5803Q[0].e());
                        AbstractC0530o.b(c0521f, c0521f2, c0522g.f5997g);
                        return;
                    }
                    return;
                }
                C0494c c0494c3 = c0494cArr[1];
                if (c0494c3.f5786f != null) {
                    C0521f c0521fH4 = AbstractC0530o.h(c0494c3);
                    if (c0521fH4 != null) {
                        AbstractC0530o.b(c0521f, c0521fH4, -this.f6015b.f5803Q[1].e());
                        AbstractC0530o.b(c0521f2, c0521f, -c0522g.f5997g);
                        return;
                    }
                    return;
                }
                if ((c0495d7 instanceof x.i) || c0495d7.f5806T == null || c0495d7.i(7).f5786f != null) {
                    return;
                }
                C0495d c0495d8 = this.f6015b;
                AbstractC0530o.b(c0521f2, c0495d8.f5806T.f5819d.f6020h, c0495d8.r());
                AbstractC0530o.b(c0521f, c0521f2, c0522g.f5997g);
                return;
            }
        }
        if (this.f6017d == 3) {
            C0495d c0495d9 = this.f6015b;
            int i5 = c0495d9.f5844r;
            if (i5 == 2) {
                C0495d c0495d10 = c0495d9.f5806T;
                if (c0495d10 != null) {
                    C0522g c0522g2 = c0495d10.e.e;
                    c0522g.f6001l.add(c0522g2);
                    c0522g2.f6000k.add(c0522g);
                    c0522g.f5993b = true;
                    c0522g.f6000k.add(c0521f2);
                    c0522g.f6000k.add(c0521f);
                }
            } else if (i5 == 3) {
                if (c0495d9.f5845s == 3) {
                    c0521f2.f5992a = this;
                    c0521f.f5992a = this;
                    C0528m c0528m = c0495d9.e;
                    c0528m.f6020h.f5992a = this;
                    c0528m.i.f5992a = this;
                    c0522g.f5992a = this;
                    if (c0495d9.y()) {
                        c0522g.f6001l.add(this.f6015b.e.e);
                        this.f6015b.e.e.f6000k.add(c0522g);
                        C0528m c0528m2 = this.f6015b.e;
                        c0528m2.e.f5992a = this;
                        c0522g.f6001l.add(c0528m2.f6020h);
                        c0522g.f6001l.add(this.f6015b.e.i);
                        this.f6015b.e.f6020h.f6000k.add(c0522g);
                        this.f6015b.e.i.f6000k.add(c0522g);
                    } else if (this.f6015b.x()) {
                        this.f6015b.e.e.f6001l.add(c0522g);
                        c0522g.f6000k.add(this.f6015b.e.e);
                    } else {
                        this.f6015b.e.e.f6001l.add(c0522g);
                    }
                } else {
                    C0522g c0522g3 = c0495d9.e.e;
                    c0522g.f6001l.add(c0522g3);
                    c0522g3.f6000k.add(c0522g);
                    this.f6015b.e.f6020h.f6000k.add(c0522g);
                    this.f6015b.e.i.f6000k.add(c0522g);
                    c0522g.f5993b = true;
                    c0522g.f6000k.add(c0521f2);
                    c0522g.f6000k.add(c0521f);
                    c0521f2.f6001l.add(c0522g);
                    c0521f.f6001l.add(c0522g);
                }
            }
        }
        C0495d c0495d11 = this.f6015b;
        C0494c[] c0494cArr2 = c0495d11.f5803Q;
        C0494c c0494c4 = c0494cArr2[0];
        C0494c c0494c5 = c0494c4.f5786f;
        if (c0494c5 != null && c0494cArr2[1].f5786f != null) {
            if (c0495d11.x()) {
                c0521f2.f5996f = this.f6015b.f5803Q[0].e();
                c0521f.f5996f = -this.f6015b.f5803Q[1].e();
                return;
            }
            C0521f c0521fH5 = AbstractC0530o.h(this.f6015b.f5803Q[0]);
            C0521f c0521fH6 = AbstractC0530o.h(this.f6015b.f5803Q[1]);
            if (c0521fH5 != null) {
                c0521fH5.b(this);
            }
            if (c0521fH6 != null) {
                c0521fH6.b(this);
            }
            this.f6021j = 4;
            return;
        }
        if (c0494c5 != null) {
            C0521f c0521fH7 = AbstractC0530o.h(c0494c4);
            if (c0521fH7 != null) {
                AbstractC0530o.b(c0521f2, c0521fH7, this.f6015b.f5803Q[0].e());
                c(c0521f, c0521f2, 1, c0522g);
                return;
            }
            return;
        }
        C0494c c0494c6 = c0494cArr2[1];
        if (c0494c6.f5786f != null) {
            C0521f c0521fH8 = AbstractC0530o.h(c0494c6);
            if (c0521fH8 != null) {
                AbstractC0530o.b(c0521f, c0521fH8, -this.f6015b.f5803Q[1].e());
                c(c0521f2, c0521f, -1, c0522g);
                return;
            }
            return;
        }
        if ((c0495d11 instanceof x.i) || (c0495d3 = c0495d11.f5806T) == null) {
            return;
        }
        AbstractC0530o.b(c0521f2, c0495d3.f5819d.f6020h, c0495d11.r());
        c(c0521f, c0521f2, 1, c0522g);
    }

    @Override // y.AbstractC0530o
    public final void e() {
        C0521f c0521f = this.f6020h;
        if (c0521f.f5999j) {
            this.f6015b.f5811Y = c0521f.f5997g;
        }
    }

    @Override // y.AbstractC0530o
    public final void f() {
        this.f6016c = null;
        this.f6020h.c();
        this.i.c();
        this.e.c();
        this.f6019g = false;
    }

    @Override // y.AbstractC0530o
    public final boolean k() {
        return this.f6017d != 3 || this.f6015b.f5844r == 0;
    }

    public final void n() {
        this.f6019g = false;
        C0521f c0521f = this.f6020h;
        c0521f.c();
        c0521f.f5999j = false;
        C0521f c0521f2 = this.i;
        c0521f2.c();
        c0521f2.f5999j = false;
        this.e.f5999j = false;
    }

    public final String toString() {
        return "HorizontalRun " + this.f6015b.f5827h0;
    }
}
