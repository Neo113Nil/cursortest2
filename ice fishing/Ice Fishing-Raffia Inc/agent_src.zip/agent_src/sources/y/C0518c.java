package y;

import java.util.ArrayList;
import java.util.Iterator;
import x.C0494c;
import x.C0495d;
import x.C0496e;

/* renamed from: y.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0518c extends AbstractC0530o {

    /* renamed from: k, reason: collision with root package name */
    public final ArrayList f5983k;

    /* renamed from: l, reason: collision with root package name */
    public int f5984l;

    public C0518c(C0495d c0495d, int i) {
        C0495d c0495d2;
        super(c0495d);
        this.f5983k = new ArrayList();
        this.f6018f = i;
        C0495d c0495d3 = this.f6015b;
        C0495d c0495dM = c0495d3.m(i);
        while (true) {
            C0495d c0495d4 = c0495dM;
            c0495d2 = c0495d3;
            c0495d3 = c0495d4;
            if (c0495d3 == null) {
                break;
            } else {
                c0495dM = c0495d3.m(this.f6018f);
            }
        }
        this.f6015b = c0495d2;
        int i3 = this.f6018f;
        Object obj = i3 == 0 ? c0495d2.f5819d : i3 == 1 ? c0495d2.e : null;
        ArrayList arrayList = this.f5983k;
        arrayList.add(obj);
        C0495d c0495dL = c0495d2.l(this.f6018f);
        while (c0495dL != null) {
            int i4 = this.f6018f;
            arrayList.add(i4 == 0 ? c0495dL.f5819d : i4 == 1 ? c0495dL.e : null);
            c0495dL = c0495dL.l(this.f6018f);
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            AbstractC0530o abstractC0530o = (AbstractC0530o) it.next();
            int i5 = this.f6018f;
            if (i5 == 0) {
                abstractC0530o.f6015b.f5815b = this;
            } else if (i5 == 1) {
                abstractC0530o.f6015b.f5817c = this;
            }
        }
        if (this.f6018f == 0 && ((C0496e) this.f6015b.f5806T).f5869v0 && arrayList.size() > 1) {
            this.f6015b = ((AbstractC0530o) arrayList.get(arrayList.size() - 1)).f6015b;
        }
        this.f5984l = this.f6018f == 0 ? this.f6015b.f5828i0 : this.f6015b.f5830j0;
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x0153  */
    @Override // y.InterfaceC0519d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(InterfaceC0519d interfaceC0519d) {
        int i;
        int i3;
        ArrayList arrayList;
        int i4;
        int i5;
        int i6;
        int i7;
        float f3;
        int i8;
        boolean z2;
        ArrayList arrayList2;
        int i9;
        int i10;
        int i11;
        int i12;
        boolean z3;
        int i13;
        int i14;
        int i15;
        float f4;
        int i16;
        boolean z4;
        int i17;
        C0521f c0521f = this.f6020h;
        if (c0521f.f5999j) {
            C0521f c0521f2 = this.i;
            if (c0521f2.f5999j) {
                C0495d c0495d = this.f6015b.f5806T;
                boolean z5 = c0495d instanceof C0496e ? ((C0496e) c0495d).f5869v0 : false;
                int i18 = c0521f2.f5997g - c0521f.f5997g;
                ArrayList arrayList3 = this.f5983k;
                int size = arrayList3.size();
                int i19 = 0;
                while (true) {
                    i = -1;
                    i3 = 8;
                    if (i19 >= size) {
                        i19 = -1;
                        break;
                    } else if (((AbstractC0530o) arrayList3.get(i19)).f6015b.f5825g0 != 8) {
                        break;
                    } else {
                        i19++;
                    }
                }
                int i20 = size - 1;
                int i21 = i20;
                while (true) {
                    if (i21 < 0) {
                        break;
                    }
                    if (((AbstractC0530o) arrayList3.get(i21)).f6015b.f5825g0 != 8) {
                        i = i21;
                        break;
                    }
                    i21--;
                }
                int i22 = 0;
                while (i22 < 2) {
                    int i23 = 0;
                    i7 = 0;
                    int i24 = 0;
                    int i25 = 0;
                    f3 = 0.0f;
                    while (i23 < size) {
                        AbstractC0530o abstractC0530o = (AbstractC0530o) arrayList3.get(i23);
                        C0495d c0495d2 = abstractC0530o.f6015b;
                        ArrayList arrayList4 = arrayList3;
                        if (c0495d2.f5825g0 == i3) {
                            i16 = i19;
                        } else {
                            i25++;
                            if (i23 > 0 && i23 >= i19) {
                                i7 += abstractC0530o.f6020h.f5996f;
                            }
                            C0522g c0522g = abstractC0530o.e;
                            int i26 = c0522g.f5997g;
                            i16 = i19;
                            boolean z6 = abstractC0530o.f6017d != 3;
                            if (z6) {
                                int i27 = this.f6018f;
                                if (i27 == 0 && !c0495d2.f5819d.e.f5999j) {
                                    return;
                                }
                                if (i27 == 1 && !c0495d2.e.e.f5999j) {
                                    return;
                                } else {
                                    z4 = z6;
                                }
                            } else {
                                z4 = z6;
                                if (abstractC0530o.f6014a == 1 && i22 == 0) {
                                    i17 = c0522g.f6002m;
                                    i24++;
                                } else if (c0522g.f5999j) {
                                    i17 = i26;
                                }
                                z4 = true;
                                if (z4) {
                                    i24++;
                                    float f5 = c0495d2.f5832k0[this.f6018f];
                                    if (f5 >= 0.0f) {
                                        f3 += f5;
                                    }
                                } else {
                                    i7 += i17;
                                }
                                if (i23 >= i20 && i23 < i) {
                                    i7 += -abstractC0530o.i.f5996f;
                                }
                            }
                            i17 = i26;
                            if (z4) {
                            }
                            if (i23 >= i20) {
                            }
                        }
                        i23++;
                        arrayList3 = arrayList4;
                        i19 = i16;
                        i3 = 8;
                    }
                    arrayList = arrayList3;
                    i4 = i19;
                    if (i7 < i18 || i24 == 0) {
                        i5 = i24;
                        i6 = i25;
                        break;
                    } else {
                        i22++;
                        arrayList3 = arrayList;
                        i19 = i4;
                        i3 = 8;
                    }
                }
                arrayList = arrayList3;
                i4 = i19;
                i5 = 0;
                i6 = 0;
                i7 = 0;
                f3 = 0.0f;
                int i28 = c0521f.f5997g;
                if (z5) {
                    i28 = c0521f2.f5997g;
                }
                if (i7 > i18) {
                    i28 = z5 ? i28 + ((int) (((i7 - i18) / 2.0f) + 0.5f)) : i28 - ((int) (((i7 - i18) / 2.0f) + 0.5f));
                }
                if (i5 > 0) {
                    float f6 = i18 - i7;
                    int i29 = (int) ((f6 / i5) + 0.5f);
                    int i30 = 0;
                    int i31 = 0;
                    while (i30 < size) {
                        ArrayList arrayList5 = arrayList;
                        AbstractC0530o abstractC0530o2 = (AbstractC0530o) arrayList5.get(i30);
                        int i32 = i29;
                        C0495d c0495d3 = abstractC0530o2.f6015b;
                        int i33 = i7;
                        int i34 = i28;
                        if (c0495d3.f5825g0 != 8 && abstractC0530o2.f6017d == 3) {
                            C0522g c0522g2 = abstractC0530o2.e;
                            if (c0522g2.f5999j) {
                                z3 = z5;
                                f4 = f6;
                            } else {
                                if (f3 > 0.0f) {
                                    z3 = z5;
                                    i13 = (int) (((c0495d3.f5832k0[this.f6018f] * f6) / f3) + 0.5f);
                                } else {
                                    z3 = z5;
                                    i13 = i32;
                                }
                                if (this.f6018f == 0) {
                                    i14 = c0495d3.f5848v;
                                    i15 = c0495d3.f5847u;
                                } else {
                                    i14 = c0495d3.f5851y;
                                    i15 = c0495d3.f5850x;
                                }
                                f4 = f6;
                                int iMax = Math.max(i15, abstractC0530o2.f6014a == 1 ? Math.min(i13, c0522g2.f6002m) : i13);
                                if (i14 > 0) {
                                    iMax = Math.min(i14, iMax);
                                }
                                if (iMax != i13) {
                                    i31++;
                                    i13 = iMax;
                                }
                                c0522g2.d(i13);
                            }
                        }
                        i30++;
                        i29 = i32;
                        i7 = i33;
                        i28 = i34;
                        z5 = z3;
                        f6 = f4;
                        arrayList = arrayList5;
                    }
                    i8 = i28;
                    z2 = z5;
                    arrayList2 = arrayList;
                    int i35 = i7;
                    if (i31 > 0) {
                        i5 -= i31;
                        int i36 = 0;
                        i7 = 0;
                        while (i36 < size) {
                            AbstractC0530o abstractC0530o3 = (AbstractC0530o) arrayList2.get(i36);
                            if (abstractC0530o3.f6015b.f5825g0 == 8) {
                                i12 = i4;
                            } else {
                                i12 = i4;
                                if (i36 > 0 && i36 >= i12) {
                                    i7 += abstractC0530o3.f6020h.f5996f;
                                }
                                i7 += abstractC0530o3.e.f5997g;
                                if (i36 < i20 && i36 < i) {
                                    i7 += -abstractC0530o3.i.f5996f;
                                }
                            }
                            i36++;
                            i4 = i12;
                        }
                        i9 = i4;
                    } else {
                        i9 = i4;
                        i7 = i35;
                    }
                    i11 = 2;
                    if (this.f5984l == 2 && i31 == 0) {
                        i10 = 0;
                        this.f5984l = 0;
                    } else {
                        i10 = 0;
                    }
                } else {
                    i8 = i28;
                    z2 = z5;
                    arrayList2 = arrayList;
                    i9 = i4;
                    i10 = 0;
                    i11 = 2;
                }
                if (i7 > i18) {
                    this.f5984l = i11;
                }
                if (i6 > 0 && i5 == 0 && i9 == i) {
                    this.f5984l = i11;
                }
                int i37 = this.f5984l;
                if (i37 == 1) {
                    int i38 = i6 > 1 ? (i18 - i7) / (i6 - 1) : i6 == 1 ? (i18 - i7) / 2 : i10;
                    if (i5 > 0) {
                        i38 = i10;
                    }
                    int i39 = i8;
                    for (int i40 = i10; i40 < size; i40++) {
                        AbstractC0530o abstractC0530o4 = (AbstractC0530o) arrayList2.get(z2 ? size - (i40 + 1) : i40);
                        int i41 = abstractC0530o4.f6015b.f5825g0;
                        C0521f c0521f3 = abstractC0530o4.i;
                        C0521f c0521f4 = abstractC0530o4.f6020h;
                        if (i41 == 8) {
                            c0521f4.d(i39);
                            c0521f3.d(i39);
                        } else {
                            if (i40 > 0) {
                                i39 = z2 ? i39 - i38 : i39 + i38;
                            }
                            if (i40 > 0 && i40 >= i9) {
                                i39 = z2 ? i39 - c0521f4.f5996f : i39 + c0521f4.f5996f;
                            }
                            if (z2) {
                                c0521f3.d(i39);
                            } else {
                                c0521f4.d(i39);
                            }
                            C0522g c0522g3 = abstractC0530o4.e;
                            int i42 = c0522g3.f5997g;
                            if (abstractC0530o4.f6017d == 3 && abstractC0530o4.f6014a == 1) {
                                i42 = c0522g3.f6002m;
                            }
                            i39 = z2 ? i39 - i42 : i39 + i42;
                            if (z2) {
                                c0521f4.d(i39);
                            } else {
                                c0521f3.d(i39);
                            }
                            abstractC0530o4.f6019g = true;
                            if (i40 < i20 && i40 < i) {
                                i39 = z2 ? i39 - (-c0521f3.f5996f) : i39 + (-c0521f3.f5996f);
                            }
                        }
                    }
                    return;
                }
                if (i37 == 0) {
                    int i43 = (i18 - i7) / (i6 + 1);
                    if (i5 > 0) {
                        i43 = i10;
                    }
                    int i44 = i8;
                    for (int i45 = i10; i45 < size; i45++) {
                        AbstractC0530o abstractC0530o5 = (AbstractC0530o) arrayList2.get(z2 ? size - (i45 + 1) : i45);
                        int i46 = abstractC0530o5.f6015b.f5825g0;
                        C0521f c0521f5 = abstractC0530o5.i;
                        C0521f c0521f6 = abstractC0530o5.f6020h;
                        if (i46 == 8) {
                            c0521f6.d(i44);
                            c0521f5.d(i44);
                        } else {
                            int i47 = z2 ? i44 - i43 : i44 + i43;
                            if (i45 > 0 && i45 >= i9) {
                                i47 = z2 ? i47 - c0521f6.f5996f : i47 + c0521f6.f5996f;
                            }
                            if (z2) {
                                c0521f5.d(i47);
                            } else {
                                c0521f6.d(i47);
                            }
                            C0522g c0522g4 = abstractC0530o5.e;
                            int iMin = c0522g4.f5997g;
                            if (abstractC0530o5.f6017d == 3 && abstractC0530o5.f6014a == 1) {
                                iMin = Math.min(iMin, c0522g4.f6002m);
                            }
                            i44 = z2 ? i47 - iMin : i47 + iMin;
                            if (z2) {
                                c0521f6.d(i44);
                            } else {
                                c0521f5.d(i44);
                            }
                            if (i45 < i20 && i45 < i) {
                                i44 = z2 ? i44 - (-c0521f5.f5996f) : i44 + (-c0521f5.f5996f);
                            }
                        }
                    }
                    return;
                }
                if (i37 == 2) {
                    float f7 = this.f6018f == 0 ? this.f6015b.f5820d0 : this.f6015b.f5821e0;
                    if (z2) {
                        f7 = 1.0f - f7;
                    }
                    int i48 = (int) (((i18 - i7) * f7) + 0.5f);
                    if (i48 < 0 || i5 > 0) {
                        i48 = i10;
                    }
                    int i49 = z2 ? i8 - i48 : i8 + i48;
                    for (int i50 = i10; i50 < size; i50++) {
                        AbstractC0530o abstractC0530o6 = (AbstractC0530o) arrayList2.get(z2 ? size - (i50 + 1) : i50);
                        int i51 = abstractC0530o6.f6015b.f5825g0;
                        C0521f c0521f7 = abstractC0530o6.i;
                        C0521f c0521f8 = abstractC0530o6.f6020h;
                        if (i51 == 8) {
                            c0521f8.d(i49);
                            c0521f7.d(i49);
                        } else {
                            if (i50 > 0 && i50 >= i9) {
                                i49 = z2 ? i49 - c0521f8.f5996f : i49 + c0521f8.f5996f;
                            }
                            if (z2) {
                                c0521f7.d(i49);
                            } else {
                                c0521f8.d(i49);
                            }
                            C0522g c0522g5 = abstractC0530o6.e;
                            int i52 = c0522g5.f5997g;
                            if (abstractC0530o6.f6017d == 3 && abstractC0530o6.f6014a == 1) {
                                i52 = c0522g5.f6002m;
                            }
                            i49 = z2 ? i49 - i52 : i49 + i52;
                            if (z2) {
                                c0521f8.d(i49);
                            } else {
                                c0521f7.d(i49);
                            }
                            if (i50 < i20 && i50 < i) {
                                i49 = z2 ? i49 - (-c0521f7.f5996f) : i49 + (-c0521f7.f5996f);
                            }
                        }
                    }
                }
            }
        }
    }

    @Override // y.AbstractC0530o
    public final void d() {
        ArrayList arrayList = this.f5983k;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((AbstractC0530o) it.next()).d();
        }
        int size = arrayList.size();
        if (size < 1) {
            return;
        }
        C0495d c0495d = ((AbstractC0530o) arrayList.get(0)).f6015b;
        C0495d c0495d2 = ((AbstractC0530o) arrayList.get(size - 1)).f6015b;
        int i = this.f6018f;
        C0521f c0521f = this.i;
        C0521f c0521f2 = this.f6020h;
        if (i == 0) {
            C0494c c0494c = c0495d.f5796I;
            C0494c c0494c2 = c0495d2.K;
            C0521f c0521fI = AbstractC0530o.i(c0494c, 0);
            int iE = c0494c.e();
            C0495d c0495dM = m();
            if (c0495dM != null) {
                iE = c0495dM.f5796I.e();
            }
            if (c0521fI != null) {
                AbstractC0530o.b(c0521f2, c0521fI, iE);
            }
            C0521f c0521fI2 = AbstractC0530o.i(c0494c2, 0);
            int iE2 = c0494c2.e();
            C0495d c0495dN = n();
            if (c0495dN != null) {
                iE2 = c0495dN.K.e();
            }
            if (c0521fI2 != null) {
                AbstractC0530o.b(c0521f, c0521fI2, -iE2);
            }
        } else {
            C0494c c0494c3 = c0495d.f5797J;
            C0494c c0494c4 = c0495d2.f5798L;
            C0521f c0521fI3 = AbstractC0530o.i(c0494c3, 1);
            int iE3 = c0494c3.e();
            C0495d c0495dM2 = m();
            if (c0495dM2 != null) {
                iE3 = c0495dM2.f5797J.e();
            }
            if (c0521fI3 != null) {
                AbstractC0530o.b(c0521f2, c0521fI3, iE3);
            }
            C0521f c0521fI4 = AbstractC0530o.i(c0494c4, 1);
            int iE4 = c0494c4.e();
            C0495d c0495dN2 = n();
            if (c0495dN2 != null) {
                iE4 = c0495dN2.f5798L.e();
            }
            if (c0521fI4 != null) {
                AbstractC0530o.b(c0521f, c0521fI4, -iE4);
            }
        }
        c0521f2.f5992a = this;
        c0521f.f5992a = this;
    }

    @Override // y.AbstractC0530o
    public final void e() {
        int i = 0;
        while (true) {
            ArrayList arrayList = this.f5983k;
            if (i >= arrayList.size()) {
                return;
            }
            ((AbstractC0530o) arrayList.get(i)).e();
            i++;
        }
    }

    @Override // y.AbstractC0530o
    public final void f() {
        this.f6016c = null;
        Iterator it = this.f5983k.iterator();
        while (it.hasNext()) {
            ((AbstractC0530o) it.next()).f();
        }
    }

    @Override // y.AbstractC0530o
    public final long j() {
        ArrayList arrayList = this.f5983k;
        int size = arrayList.size();
        long j3 = 0;
        for (int i = 0; i < size; i++) {
            j3 = r5.i.f5996f + ((AbstractC0530o) arrayList.get(i)).j() + j3 + r5.f6020h.f5996f;
        }
        return j3;
    }

    @Override // y.AbstractC0530o
    public final boolean k() {
        ArrayList arrayList = this.f5983k;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (!((AbstractC0530o) arrayList.get(i)).k()) {
                return false;
            }
        }
        return true;
    }

    public final C0495d m() {
        int i = 0;
        while (true) {
            ArrayList arrayList = this.f5983k;
            if (i >= arrayList.size()) {
                return null;
            }
            C0495d c0495d = ((AbstractC0530o) arrayList.get(i)).f6015b;
            if (c0495d.f5825g0 != 8) {
                return c0495d;
            }
            i++;
        }
    }

    public final C0495d n() {
        ArrayList arrayList = this.f5983k;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            C0495d c0495d = ((AbstractC0530o) arrayList.get(size)).f6015b;
            if (c0495d.f5825g0 != 8) {
                return c0495d;
            }
        }
        return null;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("ChainRun ");
        sb.append(this.f6018f == 0 ? "horizontal : " : "vertical : ");
        Iterator it = this.f5983k.iterator();
        while (it.hasNext()) {
            AbstractC0530o abstractC0530o = (AbstractC0530o) it.next();
            sb.append("<");
            sb.append(abstractC0530o);
            sb.append("> ");
        }
        return sb.toString();
    }
}
