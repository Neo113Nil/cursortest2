package y;

import java.util.ArrayList;

/* renamed from: y.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0527l {

    /* renamed from: a, reason: collision with root package name */
    public AbstractC0530o f6005a;

    /* renamed from: b, reason: collision with root package name */
    public ArrayList f6006b;

    public static long a(C0521f c0521f, long j3) {
        AbstractC0530o abstractC0530o = c0521f.f5995d;
        if (abstractC0530o instanceof C0525j) {
            return j3;
        }
        ArrayList arrayList = c0521f.f6000k;
        int size = arrayList.size();
        long jMin = j3;
        for (int i = 0; i < size; i++) {
            InterfaceC0519d interfaceC0519d = (InterfaceC0519d) arrayList.get(i);
            if (interfaceC0519d instanceof C0521f) {
                C0521f c0521f2 = (C0521f) interfaceC0519d;
                if (c0521f2.f5995d != abstractC0530o) {
                    jMin = Math.min(jMin, a(c0521f2, c0521f2.f5996f + j3));
                }
            }
        }
        if (c0521f != abstractC0530o.i) {
            return jMin;
        }
        long j4 = abstractC0530o.j();
        long j5 = j3 - j4;
        return Math.min(Math.min(jMin, a(abstractC0530o.f6020h, j5)), j5 - r9.f5996f);
    }

    public static long b(C0521f c0521f, long j3) {
        AbstractC0530o abstractC0530o = c0521f.f5995d;
        if (abstractC0530o instanceof C0525j) {
            return j3;
        }
        ArrayList arrayList = c0521f.f6000k;
        int size = arrayList.size();
        long jMax = j3;
        for (int i = 0; i < size; i++) {
            InterfaceC0519d interfaceC0519d = (InterfaceC0519d) arrayList.get(i);
            if (interfaceC0519d instanceof C0521f) {
                C0521f c0521f2 = (C0521f) interfaceC0519d;
                if (c0521f2.f5995d != abstractC0530o) {
                    jMax = Math.max(jMax, b(c0521f2, c0521f2.f5996f + j3));
                }
            }
        }
        if (c0521f != abstractC0530o.f6020h) {
            return jMax;
        }
        long j4 = abstractC0530o.j();
        long j5 = j3 + j4;
        return Math.max(Math.max(jMax, b(abstractC0530o.i, j5)), j5 - r9.f5996f);
    }
}
