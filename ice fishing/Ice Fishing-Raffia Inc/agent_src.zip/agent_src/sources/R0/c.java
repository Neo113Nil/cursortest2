package R0;

import E0.k;
import F0.e;
import F0.f;
import G.n;
import L1.d;
import P.C0023k;
import X0.E;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedStateListDrawable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.autofill.AutofillManager;
import android.widget.CompoundButton;
import com.kortosi.kluani.qorzanis.R;
import j1.AbstractC0218a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import n.C0335t;

/* loaded from: classes.dex */
public final class c extends C0335t {

    /* renamed from: f, reason: collision with root package name */
    public final LinkedHashSet f1021f;

    /* renamed from: g, reason: collision with root package name */
    public final LinkedHashSet f1022g;

    /* renamed from: h, reason: collision with root package name */
    public ColorStateList f1023h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1024j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f1025k;

    /* renamed from: l, reason: collision with root package name */
    public CharSequence f1026l;

    /* renamed from: m, reason: collision with root package name */
    public Drawable f1027m;

    /* renamed from: n, reason: collision with root package name */
    public Drawable f1028n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1029o;

    /* renamed from: p, reason: collision with root package name */
    public ColorStateList f1030p;

    /* renamed from: q, reason: collision with root package name */
    public ColorStateList f1031q;

    /* renamed from: r, reason: collision with root package name */
    public PorterDuff.Mode f1032r;

    /* renamed from: s, reason: collision with root package name */
    public int f1033s;

    /* renamed from: t, reason: collision with root package name */
    public int[] f1034t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1035u;

    /* renamed from: v, reason: collision with root package name */
    public CharSequence f1036v;

    /* renamed from: w, reason: collision with root package name */
    public CompoundButton.OnCheckedChangeListener f1037w;

    /* renamed from: x, reason: collision with root package name */
    public final f f1038x;

    /* renamed from: y, reason: collision with root package name */
    public final a f1039y;

    /* renamed from: z, reason: collision with root package name */
    public static final int[] f1020z = {R.attr.state_indeterminate};

    /* renamed from: A, reason: collision with root package name */
    public static final int[] f1017A = {R.attr.state_error};

    /* renamed from: B, reason: collision with root package name */
    public static final int[][] f1018B = {new int[]{android.R.attr.state_enabled, R.attr.state_error}, new int[]{android.R.attr.state_enabled, android.R.attr.state_checked}, new int[]{android.R.attr.state_enabled, -16842912}, new int[]{-16842910, android.R.attr.state_checked}, new int[]{-16842910, -16842912}};

    /* renamed from: C, reason: collision with root package name */
    public static final int f1019C = Resources.getSystem().getIdentifier("btn_check_material_anim", "drawable", "android");

    public c(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        super(AbstractC0218a.a(context, attributeSet, R.attr.checkboxStyle, R.style.Widget_MaterialComponents_CompoundButton_CheckBox), attributeSet, R.attr.checkboxStyle);
        this.f1021f = new LinkedHashSet();
        this.f1022g = new LinkedHashSet();
        Context context2 = getContext();
        f fVar = new f(context2);
        Resources resources = context2.getResources();
        Resources.Theme theme = context2.getTheme();
        ThreadLocal threadLocal = n.f527a;
        Drawable drawable = resources.getDrawable(R.drawable.mtrl_checkbox_button_checked_unchecked, theme);
        fVar.f426b = drawable;
        drawable.setCallback(fVar.f425g);
        new e(fVar.f426b.getConstantState());
        this.f1038x = fVar;
        this.f1039y = new a(this);
        Context context3 = getContext();
        this.f1027m = getButtonDrawable();
        this.f1030p = getSuperButtonTintList();
        setSupportButtonTintList(null);
        C0023k c0023kG = E.g(context3, attributeSet, I0.a.f599u, R.attr.checkboxStyle, R.style.Widget_MaterialComponents_CompoundButton_CheckBox, new int[0]);
        this.f1028n = c0023kG.c(2);
        Drawable drawable2 = this.f1027m;
        TypedArray typedArray = (TypedArray) c0023kG.f913c;
        if (drawable2 != null && d.k0(context3, R.attr.isMaterial3Theme, false)) {
            int resourceId = typedArray.getResourceId(0, 0);
            int resourceId2 = typedArray.getResourceId(1, 0);
            if (resourceId == f1019C && resourceId2 == 0) {
                super.setButtonDrawable((Drawable) null);
                this.f1027m = b1.e.A(context3, R.drawable.mtrl_checkbox_button);
                this.f1029o = true;
                if (this.f1028n == null) {
                    this.f1028n = b1.e.A(context3, R.drawable.mtrl_checkbox_button_icon);
                }
            }
        }
        this.f1031q = d.y(context3, c0023kG, 3);
        this.f1032r = E.h(typedArray.getInt(4, -1), PorterDuff.Mode.SRC_IN);
        this.i = typedArray.getBoolean(10, false);
        this.f1024j = typedArray.getBoolean(6, true);
        this.f1025k = typedArray.getBoolean(9, false);
        this.f1026l = typedArray.getText(8);
        if (typedArray.hasValue(7)) {
            setCheckedState(typedArray.getInt(7, 0));
        }
        c0023kG.j();
        a();
    }

    private String getButtonStateDescription() {
        int i = this.f1033s;
        return i == 1 ? getResources().getString(R.string.mtrl_checkbox_state_description_checked) : i == 0 ? getResources().getString(R.string.mtrl_checkbox_state_description_unchecked) : getResources().getString(R.string.mtrl_checkbox_state_description_indeterminate);
    }

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f1023h == null) {
            int iX = d.x(this, R.attr.colorControlActivated);
            int iX2 = d.x(this, R.attr.colorError);
            int iX3 = d.x(this, R.attr.colorSurface);
            int iX4 = d.x(this, R.attr.colorOnSurface);
            this.f1023h = new ColorStateList(f1018B, new int[]{d.T(iX3, iX2, 1.0f), d.T(iX3, iX, 1.0f), d.T(iX3, iX4, 0.54f), d.T(iX3, iX4, 0.38f), d.T(iX3, iX4, 0.38f)});
        }
        return this.f1023h;
    }

    private ColorStateList getSuperButtonTintList() {
        ColorStateList colorStateList = this.f1030p;
        return colorStateList != null ? colorStateList : super.getButtonTintList() != null ? super.getButtonTintList() : getSupportButtonTintList();
    }

    public final void a() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        k kVar;
        this.f1027m = d.r(this.f1027m, this.f1030p, getButtonTintMode());
        this.f1028n = d.r(this.f1028n, this.f1031q, this.f1032r);
        if (this.f1029o) {
            f fVar = this.f1038x;
            if (fVar != null) {
                Drawable drawable = fVar.f426b;
                a aVar = this.f1039y;
                if (drawable != null) {
                    AnimatedVectorDrawable animatedVectorDrawable = (AnimatedVectorDrawable) drawable;
                    if (aVar.f1014a == null) {
                        aVar.f1014a = new F0.b(aVar);
                    }
                    animatedVectorDrawable.unregisterAnimationCallback(aVar.f1014a);
                }
                ArrayList arrayList = fVar.f424f;
                F0.d dVar = fVar.f422c;
                if (arrayList != null && aVar != null) {
                    arrayList.remove(aVar);
                    if (fVar.f424f.size() == 0 && (kVar = fVar.e) != null) {
                        dVar.f418b.removeListener(kVar);
                        fVar.e = null;
                    }
                }
                Drawable drawable2 = fVar.f426b;
                if (drawable2 != null) {
                    AnimatedVectorDrawable animatedVectorDrawable2 = (AnimatedVectorDrawable) drawable2;
                    if (aVar.f1014a == null) {
                        aVar.f1014a = new F0.b(aVar);
                    }
                    animatedVectorDrawable2.registerAnimationCallback(aVar.f1014a);
                } else if (aVar != null) {
                    if (fVar.f424f == null) {
                        fVar.f424f = new ArrayList();
                    }
                    if (!fVar.f424f.contains(aVar)) {
                        fVar.f424f.add(aVar);
                        if (fVar.e == null) {
                            fVar.e = new k(1, fVar);
                        }
                        dVar.f418b.addListener(fVar.e);
                    }
                }
            }
            Drawable drawable3 = this.f1027m;
            if ((drawable3 instanceof AnimatedStateListDrawable) && fVar != null) {
                ((AnimatedStateListDrawable) drawable3).addTransition(R.id.checked, R.id.unchecked, fVar, false);
                ((AnimatedStateListDrawable) this.f1027m).addTransition(R.id.indeterminate, R.id.unchecked, fVar, false);
            }
        }
        Drawable drawable4 = this.f1027m;
        if (drawable4 != null && (colorStateList2 = this.f1030p) != null) {
            drawable4.setTintList(colorStateList2);
        }
        Drawable drawable5 = this.f1028n;
        if (drawable5 != null && (colorStateList = this.f1031q) != null) {
            drawable5.setTintList(colorStateList);
        }
        super.setButtonDrawable(d.p(this.f1027m, this.f1028n, -1, -1));
        refreshDrawableState();
    }

    @Override // android.widget.CompoundButton
    public Drawable getButtonDrawable() {
        return this.f1027m;
    }

    public Drawable getButtonIconDrawable() {
        return this.f1028n;
    }

    public ColorStateList getButtonIconTintList() {
        return this.f1031q;
    }

    public PorterDuff.Mode getButtonIconTintMode() {
        return this.f1032r;
    }

    @Override // android.widget.CompoundButton
    public ColorStateList getButtonTintList() {
        return this.f1030p;
    }

    public int getCheckedState() {
        return this.f1033s;
    }

    public CharSequence getErrorAccessibilityLabel() {
        return this.f1026l;
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final boolean isChecked() {
        return this.f1033s == 1;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.i && this.f1030p == null && this.f1031q == null) {
            setUseMaterialThemeColors(true);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (getCheckedState() == 2) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f1020z);
        }
        if (this.f1025k) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f1017A);
        }
        this.f1034t = d.v(iArrOnCreateDrawableState);
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) {
        Drawable buttonDrawable;
        if (!this.f1024j || !TextUtils.isEmpty(getText()) || (buttonDrawable = getButtonDrawable()) == null) {
            super.onDraw(canvas);
            return;
        }
        int width = ((getWidth() - buttonDrawable.getIntrinsicWidth()) / 2) * (E.e(this) ? -1 : 1);
        int iSave = canvas.save();
        canvas.translate(width, 0.0f);
        super.onDraw(canvas);
        canvas.restoreToCount(iSave);
        if (getBackground() != null) {
            Rect bounds = buttonDrawable.getBounds();
            getBackground().setHotspotBounds(bounds.left + width, bounds.top, bounds.right + width, bounds.bottom);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        if (accessibilityNodeInfo != null && this.f1025k) {
            accessibilityNodeInfo.setText(((Object) accessibilityNodeInfo.getText()) + ", " + ((Object) this.f1026l));
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.getSuperState());
        setCheckedState(bVar.f1016b);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        bVar.f1016b = getCheckedState();
        return bVar;
    }

    @Override // n.C0335t, android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(b1.e.A(getContext(), i));
    }

    public void setButtonIconDrawable(Drawable drawable) {
        this.f1028n = drawable;
        a();
    }

    public void setButtonIconDrawableResource(int i) {
        setButtonIconDrawable(b1.e.A(getContext(), i));
    }

    public void setButtonIconTintList(ColorStateList colorStateList) {
        if (this.f1031q == colorStateList) {
            return;
        }
        this.f1031q = colorStateList;
        a();
    }

    public void setButtonIconTintMode(PorterDuff.Mode mode) {
        if (this.f1032r == mode) {
            return;
        }
        this.f1032r = mode;
        a();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintList(ColorStateList colorStateList) {
        if (this.f1030p == colorStateList) {
            return;
        }
        this.f1030p = colorStateList;
        a();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintMode(PorterDuff.Mode mode) {
        setSupportButtonTintMode(mode);
        a();
    }

    public void setCenterIfNoTextEnabled(boolean z2) {
        this.f1024j = z2;
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z2) {
        setCheckedState(z2 ? 1 : 0);
    }

    public void setCheckedState(int i) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        if (this.f1033s != i) {
            this.f1033s = i;
            super.setChecked(i == 1);
            refreshDrawableState();
            if (Build.VERSION.SDK_INT >= 30 && this.f1036v == null) {
                super.setStateDescription(getButtonStateDescription());
            }
            if (this.f1035u) {
                return;
            }
            this.f1035u = true;
            LinkedHashSet linkedHashSet = this.f1022g;
            if (linkedHashSet != null) {
                Iterator it = linkedHashSet.iterator();
                if (it.hasNext()) {
                    it.next().getClass();
                    throw new ClassCastException();
                }
            }
            if (this.f1033s != 2 && (onCheckedChangeListener = this.f1037w) != null) {
                onCheckedChangeListener.onCheckedChanged(this, isChecked());
            }
            AutofillManager autofillManager = (AutofillManager) getContext().getSystemService(AutofillManager.class);
            if (autofillManager != null) {
                autofillManager.notifyValueChanged(this);
            }
            this.f1035u = false;
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void setEnabled(boolean z2) {
        super.setEnabled(z2);
    }

    public void setErrorAccessibilityLabel(CharSequence charSequence) {
        this.f1026l = charSequence;
    }

    public void setErrorAccessibilityLabelResource(int i) {
        setErrorAccessibilityLabel(i != 0 ? getResources().getText(i) : null);
    }

    public void setErrorShown(boolean z2) {
        if (this.f1025k == z2) {
            return;
        }
        this.f1025k = z2;
        refreshDrawableState();
        Iterator it = this.f1021f.iterator();
        if (it.hasNext()) {
            it.next().getClass();
            throw new ClassCastException();
        }
    }

    @Override // android.widget.CompoundButton
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f1037w = onCheckedChangeListener;
    }

    @Override // android.widget.CompoundButton, android.view.View
    public void setStateDescription(CharSequence charSequence) {
        this.f1036v = charSequence;
        if (charSequence != null) {
            super.setStateDescription(charSequence);
        } else {
            if (Build.VERSION.SDK_INT < 30 || charSequence != null) {
                return;
            }
            super.setStateDescription(getButtonStateDescription());
        }
    }

    public void setUseMaterialThemeColors(boolean z2) {
        this.i = z2;
        if (z2) {
            setButtonTintList(getMaterialThemeColorsTintList());
        } else {
            setButtonTintList(null);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // n.C0335t, android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        this.f1027m = drawable;
        this.f1029o = false;
        a();
    }
}
