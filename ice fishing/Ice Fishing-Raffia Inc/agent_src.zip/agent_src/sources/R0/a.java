package R0;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public F0.b f1014a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c f1015b;

    public a(c cVar) {
        this.f1015b = cVar;
    }
}
