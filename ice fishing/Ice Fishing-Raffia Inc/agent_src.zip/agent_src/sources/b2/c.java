package b2;

/* loaded from: classes.dex */
public final class c extends a {
    static {
        new c(1, 0, 1);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof c) {
            if (!isEmpty() || !((c) obj).isEmpty()) {
                c cVar = (c) obj;
                if (this.f2065b == cVar.f2065b) {
                    if (this.f2066c == cVar.f2066c) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.f2065b * 31) + this.f2066c;
    }

    public final boolean isEmpty() {
        return this.f2065b > this.f2066c;
    }

    public final String toString() {
        return this.f2065b + ".." + this.f2066c;
    }
}
