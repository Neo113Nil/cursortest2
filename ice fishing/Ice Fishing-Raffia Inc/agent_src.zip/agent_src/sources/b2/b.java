package b2;

import K1.y;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class b extends y {

    /* renamed from: b, reason: collision with root package name */
    public final int f2068b;

    /* renamed from: c, reason: collision with root package name */
    public final int f2069c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f2070d;
    public int e;

    public b(int i, int i3, int i4) {
        this.f2068b = i4;
        this.f2069c = i3;
        boolean z2 = false;
        if (i4 <= 0 ? i >= i3 : i <= i3) {
            z2 = true;
        }
        this.f2070d = z2;
        this.e = z2 ? i : i3;
    }

    @Override // K1.y
    public final int a() {
        int i = this.e;
        if (i != this.f2069c) {
            this.e = this.f2068b + i;
        } else {
            if (!this.f2070d) {
                throw new NoSuchElementException();
            }
            this.f2070d = false;
        }
        return i;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f2070d;
    }
}
