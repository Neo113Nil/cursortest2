package C;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public final class f extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public c f253a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f254b;

    /* renamed from: c, reason: collision with root package name */
    public final int f255c;

    /* renamed from: d, reason: collision with root package name */
    public final int f256d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final int f257f;

    /* renamed from: g, reason: collision with root package name */
    public final int f258g;

    /* renamed from: h, reason: collision with root package name */
    public int f259h;
    public int i;

    /* renamed from: j, reason: collision with root package name */
    public int f260j;

    /* renamed from: k, reason: collision with root package name */
    public View f261k;

    /* renamed from: l, reason: collision with root package name */
    public View f262l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f263m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f264n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f265o;

    /* renamed from: p, reason: collision with root package name */
    public final Rect f266p;

    public f() {
        super(-2, -2);
        this.f254b = false;
        this.f255c = 0;
        this.f256d = 0;
        this.e = -1;
        this.f257f = -1;
        this.f258g = 0;
        this.f259h = 0;
        this.f266p = new Rect();
    }

    public final boolean a(int i) {
        if (i == 0) {
            return this.f263m;
        }
        if (i != 1) {
            return false;
        }
        return this.f264n;
    }

    public f(Context context, AttributeSet attributeSet) throws NoSuchMethodException, SecurityException {
        c cVar;
        super(context, attributeSet);
        this.f254b = false;
        this.f255c = 0;
        this.f256d = 0;
        this.e = -1;
        this.f257f = -1;
        this.f258g = 0;
        this.f259h = 0;
        this.f266p = new Rect();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, B.a.f247b);
        this.f255c = typedArrayObtainStyledAttributes.getInteger(0, 0);
        this.f257f = typedArrayObtainStyledAttributes.getResourceId(1, -1);
        this.f256d = typedArrayObtainStyledAttributes.getInteger(2, 0);
        this.e = typedArrayObtainStyledAttributes.getInteger(6, -1);
        this.f258g = typedArrayObtainStyledAttributes.getInt(5, 0);
        this.f259h = typedArrayObtainStyledAttributes.getInt(4, 0);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(3);
        this.f254b = zHasValue;
        if (zHasValue) {
            String string = typedArrayObtainStyledAttributes.getString(3);
            String str = CoordinatorLayout.f1641u;
            if (TextUtils.isEmpty(string)) {
                cVar = null;
            } else {
                if (string.startsWith(".")) {
                    string = context.getPackageName() + string;
                } else if (string.indexOf(46) < 0) {
                    String str2 = CoordinatorLayout.f1641u;
                    if (!TextUtils.isEmpty(str2)) {
                        string = str2 + '.' + string;
                    }
                }
                try {
                    ThreadLocal threadLocal = CoordinatorLayout.f1643w;
                    Map map = (Map) threadLocal.get();
                    if (map == null) {
                        map = new HashMap();
                        threadLocal.set(map);
                    }
                    Constructor<?> constructor = (Constructor) map.get(string);
                    if (constructor == null) {
                        constructor = Class.forName(string, false, context.getClassLoader()).getConstructor(CoordinatorLayout.f1642v);
                        constructor.setAccessible(true);
                        map.put(string, constructor);
                    }
                    cVar = (c) constructor.newInstance(context, attributeSet);
                } catch (Exception e) {
                    throw new RuntimeException("Could not inflate Behavior subclass " + string, e);
                }
            }
            this.f253a = cVar;
        }
        typedArrayObtainStyledAttributes.recycle();
        c cVar2 = this.f253a;
        if (cVar2 != null) {
            cVar2.g(this);
        }
    }

    public f(f fVar) {
        super((ViewGroup.MarginLayoutParams) fVar);
        this.f254b = false;
        this.f255c = 0;
        this.f256d = 0;
        this.e = -1;
        this.f257f = -1;
        this.f258g = 0;
        this.f259h = 0;
        this.f266p = new Rect();
    }

    public f(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f254b = false;
        this.f255c = 0;
        this.f256d = 0;
        this.e = -1;
        this.f257f = -1;
        this.f258g = 0;
        this.f259h = 0;
        this.f266p = new Rect();
    }

    public f(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f254b = false;
        this.f255c = 0;
        this.f256d = 0;
        this.e = -1;
        this.f257f = -1;
        this.f258g = 0;
        this.f259h = 0;
        this.f266p = new Rect();
    }
}
