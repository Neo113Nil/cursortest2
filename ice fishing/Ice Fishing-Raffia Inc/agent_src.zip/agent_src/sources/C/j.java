package C;

import P.G;
import P.O;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Comparator;
import java.util.Map;
import java.util.WeakHashMap;
import p0.C0384o;
import p0.C0391w;
import v.C0471f;
import v0.n;

/* loaded from: classes.dex */
public final class j implements Comparator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f270a;

    public /* synthetic */ j(int i) {
        this.f270a = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x008e  */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int compare(Object obj, Object obj2) {
        int i = -1;
        switch (this.f270a) {
            case 0:
                WeakHashMap weakHashMap = O.f854a;
                float fG = G.g((View) obj);
                float fG2 = G.g((View) obj2);
                if (fG > fG2) {
                    return -1;
                }
                return fG < fG2 ? 1 : 0;
            case 1:
                return ((View) obj).getTop() - ((View) obj2).getTop();
            case 2:
                return ((C0384o) obj).f4982a - ((C0384o) obj2).f4982a;
            case 3:
                C0391w c0391w = (C0391w) obj;
                C0391w c0391w2 = (C0391w) obj2;
                RecyclerView recyclerView = c0391w.f5067d;
                if ((recyclerView == null) == (c0391w2.f5067d == null)) {
                    boolean z2 = c0391w.f5064a;
                    if (z2 == c0391w2.f5064a) {
                        i = c0391w2.f5065b - c0391w.f5065b;
                        if (i == 0) {
                            int i3 = c0391w.f5066c - c0391w2.f5066c;
                            if (i3 != 0) {
                                return i3;
                            }
                            return 0;
                        }
                    } else if (!z2) {
                    }
                } else if (recyclerView == null) {
                    i = 1;
                }
                return i;
            case 4:
                return ((C0471f) obj).f5655c - ((C0471f) obj2).f5655c;
            case 5:
                return L1.d.o((Integer) ((Map.Entry) obj).getKey(), (Integer) ((Map.Entry) obj2).getKey());
            case 6:
                return L1.d.o((Integer) ((Map.Entry) obj).getKey(), (Integer) ((Map.Entry) obj2).getKey());
            case 7:
                return L1.d.o(((v0.l) obj).f5703a, ((v0.l) obj2).f5703a);
            case 8:
                return L1.d.o(((n) obj).f5713a, ((n) obj2).f5713a);
            case 9:
                return L1.d.o(Integer.valueOf(((r1.j) obj2).f5394d), Integer.valueOf(((r1.j) obj).f5394d));
            default:
                return L1.d.o(((r1.j) obj).f5391a, ((r1.j) obj2).f5391a);
        }
    }
}
