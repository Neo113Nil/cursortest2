package C;

import X0.C0039b;
import X0.w;
import android.os.Parcel;
import android.os.Parcelable;
import f1.C0130d;
import h1.C0187A;
import n.h1;
import p0.e0;

/* loaded from: classes.dex */
public final class h implements Parcelable.ClassLoaderCreator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f268a;

    public /* synthetic */ h(int i) {
        this.f268a = i;
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        switch (this.f268a) {
            case 0:
                return new i(parcel, classLoader);
            case 1:
                return new N0.e(parcel, classLoader);
            case 2:
                return new O0.b(parcel, classLoader);
            case 3:
                if (parcel.readParcelable(classLoader) == null) {
                    return U.b.f1143c;
                }
                throw new IllegalStateException("superState must be null");
            case 4:
                return new X.e(parcel, classLoader);
            case 5:
                return new C0039b(parcel, classLoader);
            case 6:
                return new w(parcel, classLoader);
            case 7:
                return new Z0.e(parcel, classLoader);
            case 8:
                return new C0130d(parcel, classLoader);
            case 9:
                return new C0187A(parcel, classLoader);
            case 10:
                return new h1(parcel, classLoader);
            default:
                return new e0(parcel, classLoader);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        switch (this.f268a) {
            case 0:
                return new i[i];
            case 1:
                return new N0.e[i];
            case 2:
                return new O0.b[i];
            case 3:
                return new U.b[i];
            case 4:
                return new X.e[i];
            case 5:
                return new C0039b[i];
            case 6:
                return new w[i];
            case 7:
                return new Z0.e[i];
            case 8:
                return new C0130d[i];
            case 9:
                return new C0187A[i];
            case 10:
                return new h1[i];
            default:
                return new e0[i];
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f268a) {
            case 0:
                return new i(parcel, null);
            case 1:
                return new N0.e(parcel, (ClassLoader) null);
            case 2:
                return new O0.b(parcel, null);
            case 3:
                if (parcel.readParcelable(null) == null) {
                    return U.b.f1143c;
                }
                throw new IllegalStateException("superState must be null");
            case 4:
                return new X.e(parcel, null);
            case 5:
                return new C0039b(parcel, null);
            case 6:
                return new w(parcel, null);
            case 7:
                return new Z0.e(parcel, null);
            case 8:
                return new C0130d(parcel, (ClassLoader) null);
            case 9:
                return new C0187A(parcel, null);
            case 10:
                return new h1(parcel, null);
            default:
                return new e0(parcel, null);
        }
    }
}
