package C;

import Y.u;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.lifecycle.C0078w;
import androidx.lifecycle.T;
import androidx.lifecycle.W;
import androidx.lifecycle.Y;
import androidx.lifecycle.b0;
import androidx.lifecycle.d0;
import c0.AbstractComponentCallbacksC0110w;
import c0.X;
import e1.C0123e;
import g0.AbstractC0133b;
import g0.C0134c;
import j0.AbstractC0193A;
import j0.C0195C;
import j0.C0198c;
import j0.D;
import j0.F;
import j0.x;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import l.AbstractC0257a;
import m.MenuC0270A;
import m.MenuC0285l;
import m.s;
import s.C0435f;
import s.C0437h;
import s.C0439j;

/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public final Object f271a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f272b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f273c;

    /* renamed from: d, reason: collision with root package name */
    public Object f274d;

    public /* synthetic */ k(ViewGroup viewGroup, TextView textView, TextView textView2, View view) {
        this.f271a = viewGroup;
        this.f272b = textView;
        this.f273c = textView2;
        this.f274d = view;
    }

    public void a(AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w) {
        if (((ArrayList) this.f273c).contains(abstractComponentCallbacksC0110w)) {
            throw new IllegalStateException("Fragment already added: " + abstractComponentCallbacksC0110w);
        }
        synchronized (((ArrayList) this.f273c)) {
            ((ArrayList) this.f273c).add(abstractComponentCallbacksC0110w);
        }
        abstractComponentCallbacksC0110w.f2317l = true;
    }

    public E.i b() {
        D d3 = (D) this.f274d;
        if (d3 == null) {
            throw new IllegalStateException("You must call setGraph() before constructing the deep link");
        }
        ArrayList arrayList = (ArrayList) this.f273c;
        if (arrayList.isEmpty()) {
            throw new IllegalStateException("You must call setDestination() or addDestination() before constructing the deep link");
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList<? extends Parcelable> arrayList3 = new ArrayList<>();
        Iterator it = arrayList.iterator();
        AbstractC0193A abstractC0193A = null;
        while (true) {
            boolean zHasNext = it.hasNext();
            Context context = (Context) this.f271a;
            int i = 0;
            if (!zHasNext) {
                int[] iArrN0 = K1.l.n0(arrayList2);
                Intent intent = (Intent) this.f272b;
                intent.putExtra("android-support-nav:controller:deepLinkIds", iArrN0);
                intent.putParcelableArrayListExtra("android-support-nav:controller:deepLinkArgs", arrayList3);
                E.i iVar = new E.i(context);
                Intent intent2 = new Intent(intent);
                ComponentName component = intent2.getComponent();
                if (component == null) {
                    component = intent2.resolveActivity(iVar.f305c.getPackageManager());
                }
                if (component != null) {
                    iVar.a(component);
                }
                ArrayList arrayList4 = iVar.f304b;
                arrayList4.add(intent2);
                int size = arrayList4.size();
                while (i < size) {
                    Intent intent3 = (Intent) arrayList4.get(i);
                    if (intent3 != null) {
                        intent3.putExtra("android-support-nav:controller:deepLinkIntent", intent);
                    }
                    i++;
                }
                return iVar;
            }
            x xVar = (x) it.next();
            int i3 = xVar.f3766a;
            AbstractC0193A abstractC0193AE = e(i3);
            if (abstractC0193AE == null) {
                int i4 = AbstractC0193A.f3578k;
                throw new IllegalArgumentException("Navigation destination " + b1.e.y(context, i3) + " cannot be found in the navigation graph " + d3);
            }
            int[] iArrB = abstractC0193AE.b(abstractC0193A);
            int length = iArrB.length;
            while (i < length) {
                arrayList2.add(Integer.valueOf(iArrB[i]));
                arrayList3.add(xVar.f3767b);
                i++;
            }
            abstractC0193A = abstractC0193AE;
        }
    }

    public void c(Object obj, ArrayList arrayList, HashSet hashSet) {
        if (arrayList.contains(obj)) {
            return;
        }
        if (hashSet.contains(obj)) {
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
        hashSet.add(obj);
        ArrayList arrayList2 = (ArrayList) ((C0439j) this.f272b).get(obj);
        if (arrayList2 != null) {
            int size = arrayList2.size();
            for (int i = 0; i < size; i++) {
                c(arrayList2.get(i), arrayList, hashSet);
            }
        }
        hashSet.remove(obj);
        arrayList.add(obj);
    }

    public AbstractComponentCallbacksC0110w d(String str) {
        X x2 = (X) ((HashMap) this.f271a).get(str);
        if (x2 != null) {
            return x2.f2168c;
        }
        return null;
    }

    public AbstractC0193A e(int i) {
        K1.i iVar = new K1.i();
        D d3 = (D) this.f274d;
        X1.i.b(d3);
        iVar.addLast(d3);
        while (!iVar.isEmpty()) {
            AbstractC0193A abstractC0193A = (AbstractC0193A) iVar.removeFirst();
            if (abstractC0193A.i == i) {
                return abstractC0193A;
            }
            if (abstractC0193A instanceof D) {
                C0195C c0195c = new C0195C((D) abstractC0193A);
                while (c0195c.hasNext()) {
                    iVar.addLast((AbstractC0193A) c0195c.next());
                }
            }
        }
        return null;
    }

    public AbstractComponentCallbacksC0110w f(String str) {
        for (X x2 : ((HashMap) this.f271a).values()) {
            if (x2 != null) {
                AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110wF = x2.f2168c;
                if (!str.equals(abstractComponentCallbacksC0110wF.f2312f)) {
                    abstractComponentCallbacksC0110wF = abstractComponentCallbacksC0110wF.f2329x.f2116c.f(str);
                }
                if (abstractComponentCallbacksC0110wF != null) {
                    return abstractComponentCallbacksC0110wF;
                }
            }
        }
        return null;
    }

    public l.e g(AbstractC0257a abstractC0257a) {
        ArrayList arrayList = (ArrayList) this.f273c;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            l.e eVar = (l.e) arrayList.get(i);
            if (eVar != null && eVar.f3980b == abstractC0257a) {
                return eVar;
            }
        }
        l.e eVar2 = new l.e((Context) this.f274d, abstractC0257a);
        arrayList.add(eVar2);
        return eVar2;
    }

    public ArrayList h() {
        ArrayList arrayList = new ArrayList();
        for (X x2 : ((HashMap) this.f271a).values()) {
            if (x2 != null) {
                arrayList.add(x2);
            }
        }
        return arrayList;
    }

    public ArrayList i() {
        ArrayList arrayList = new ArrayList();
        for (X x2 : ((HashMap) this.f271a).values()) {
            if (x2 != null) {
                arrayList.add(x2.f2168c);
            } else {
                arrayList.add(null);
            }
        }
        return arrayList;
    }

    public List j() {
        ArrayList arrayList;
        if (((ArrayList) this.f273c).isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (((ArrayList) this.f273c)) {
            arrayList = new ArrayList((ArrayList) this.f273c);
        }
        return arrayList;
    }

    public Y k(X1.e eVar, String str) {
        Y y2;
        Y yA;
        X1.i.e(str, "key");
        synchronized (((C0123e) this.f274d)) {
            try {
                d0 d0Var = (d0) this.f271a;
                d0Var.getClass();
                y2 = (Y) d0Var.f1816a.get(str);
                if (eVar.c(y2)) {
                    b0 b0Var = (b0) this.f272b;
                    if (b0Var instanceof W) {
                        W w2 = (W) b0Var;
                        X1.i.b(y2);
                        C0078w c0078w = w2.f1797d;
                        if (c0078w != null) {
                            A.i iVar = w2.e;
                            X1.i.b(iVar);
                            T.a(y2, iVar, c0078w);
                        }
                    }
                    X1.i.c(y2, "null cannot be cast to non-null type T of androidx.lifecycle.viewmodel.ViewModelProviderImpl.getViewModel");
                } else {
                    C0134c c0134c = new C0134c((AbstractC0133b) this.f273c);
                    c0134c.f3089a.put(T.e, str);
                    b0 b0Var2 = (b0) this.f272b;
                    try {
                        try {
                            yA = b0Var2.b(eVar, c0134c);
                        } catch (AbstractMethodError unused) {
                            yA = b0Var2.c(L1.d.F(eVar), c0134c);
                        }
                    } catch (AbstractMethodError unused2) {
                        yA = b0Var2.a(L1.d.F(eVar));
                    }
                    y2 = yA;
                    d0 d0Var2 = (d0) this.f271a;
                    d0Var2.getClass();
                    X1.i.e(y2, "viewModel");
                    Y y3 = (Y) d0Var2.f1816a.put(str, y2);
                    if (y3 != null) {
                        y3.b();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return y2;
    }

    public void l(X x2) {
        AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w = x2.f2168c;
        String str = abstractComponentCallbacksC0110w.f2312f;
        HashMap map = (HashMap) this.f271a;
        if (map.get(str) != null) {
            return;
        }
        map.put(abstractComponentCallbacksC0110w.f2312f, x2);
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Added fragment to active set " + abstractComponentCallbacksC0110w);
        }
    }

    public void m(X x2) {
        AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w = x2.f2168c;
        if (abstractComponentCallbacksC0110w.f2292E) {
            ((c0.T) this.f274d).h(abstractComponentCallbacksC0110w);
        }
        HashMap map = (HashMap) this.f271a;
        if (map.get(abstractComponentCallbacksC0110w.f2312f) == x2 && ((X) map.put(abstractComponentCallbacksC0110w.f2312f, null)) != null && Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Removed fragment from active set " + abstractComponentCallbacksC0110w);
        }
    }

    public boolean n(AbstractC0257a abstractC0257a, MenuItem menuItem) {
        return ((ActionMode.Callback) this.f271a).onActionItemClicked(g(abstractC0257a), new s((Context) this.f274d, (J.a) menuItem));
    }

    public boolean o(AbstractC0257a abstractC0257a, MenuC0285l menuC0285l) {
        l.e eVarG = g(abstractC0257a);
        C0439j c0439j = (C0439j) this.f272b;
        Menu menuC0270A = (Menu) c0439j.get(menuC0285l);
        if (menuC0270A == null) {
            menuC0270A = new MenuC0270A((Context) this.f274d, menuC0285l);
            c0439j.put(menuC0285l, menuC0270A);
        }
        return ((ActionMode.Callback) this.f271a).onCreateActionMode(eVarG, menuC0270A);
    }

    public Bundle p(Bundle bundle, String str) {
        HashMap map = (HashMap) this.f272b;
        return bundle != null ? (Bundle) map.put(str, bundle) : (Bundle) map.remove(str);
    }

    public void q() {
        Iterator it = ((ArrayList) this.f273c).iterator();
        while (it.hasNext()) {
            int i = ((x) it.next()).f3766a;
            if (e(i) == null) {
                int i3 = AbstractC0193A.f3578k;
                StringBuilder sbK = H.e.k("Navigation destination ", b1.e.y((Context) this.f271a, i), " cannot be found in the navigation graph ");
                sbK.append((D) this.f274d);
                throw new IllegalArgumentException(sbK.toString());
            }
        }
    }

    public k(F f3) {
        Intent launchIntentForPackage;
        Context context = f3.f3597a;
        this.f271a = context;
        d2.c cVar = new d2.c(new d2.d(new d2.d(d2.h.t0(context, C0198c.f3680k), C0198c.f3681l, 3), new d2.j(0), 0));
        Activity activity = (Activity) (!cVar.hasNext() ? null : cVar.next());
        if (activity != null) {
            launchIntentForPackage = new Intent(context, activity.getClass());
        } else {
            launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            if (launchIntentForPackage == null) {
                launchIntentForPackage = new Intent();
            }
        }
        launchIntentForPackage.addFlags(268468224);
        this.f272b = launchIntentForPackage;
        this.f273c = new ArrayList();
        this.f274d = f3.i();
    }

    public k(d0 d0Var, b0 b0Var, AbstractC0133b abstractC0133b) {
        X1.i.e(d0Var, "store");
        X1.i.e(abstractC0133b, "defaultExtras");
        this.f271a = d0Var;
        this.f272b = b0Var;
        this.f273c = abstractC0133b;
        this.f274d = new C0123e();
    }

    public k(int i) {
        switch (i) {
            case 1:
                this.f271a = new C0435f(0);
                this.f272b = new SparseArray();
                this.f273c = new C0437h();
                this.f274d = new C0435f(0);
                break;
            case 2:
            default:
                this.f271a = new O.b(10);
                this.f272b = new C0439j(0);
                this.f273c = new ArrayList();
                this.f274d = new HashSet();
                break;
            case 3:
                this.f273c = new ArrayList();
                this.f271a = new HashMap();
                this.f272b = new HashMap();
                break;
        }
    }

    public k(Typeface typeface, Z.b bVar) {
        int i;
        int i3;
        this.f274d = typeface;
        this.f271a = bVar;
        this.f273c = new u(1024);
        int iA = bVar.a(6);
        if (iA != 0) {
            int i4 = iA + bVar.f714b;
            i = ((ByteBuffer) bVar.e).getInt(((ByteBuffer) bVar.e).getInt(i4) + i4);
        } else {
            i = 0;
        }
        this.f272b = new char[i * 2];
        int iA2 = bVar.a(6);
        if (iA2 != 0) {
            int i5 = iA2 + bVar.f714b;
            i3 = ((ByteBuffer) bVar.e).getInt(((ByteBuffer) bVar.e).getInt(i5) + i5);
        } else {
            i3 = 0;
        }
        for (int i6 = 0; i6 < i3; i6++) {
            Y.x xVar = new Y.x(this, i6);
            Z.a aVarC = xVar.c();
            int iA3 = aVarC.a(4);
            Character.toChars(iA3 != 0 ? ((ByteBuffer) aVarC.e).getInt(iA3 + aVarC.f714b) : 0, (char[]) this.f272b, i6 * 2);
            L1.d.i("invalid metadata codepoint length", xVar.b() > 0);
            ((u) this.f273c).a(xVar, 0, xVar.b() - 1);
        }
    }

    public k(Context context, ActionMode.Callback callback) {
        this.f274d = context;
        this.f271a = callback;
        this.f273c = new ArrayList();
        this.f272b = new C0439j(0);
    }
}
