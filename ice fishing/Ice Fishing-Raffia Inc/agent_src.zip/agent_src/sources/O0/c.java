package O0;

import P.O;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import c1.AbstractC0114a;
import com.google.android.material.button.MaterialButton;
import com.kortosi.kluani.qorzanis.R;
import e1.C0124f;
import e1.C0125g;
import e1.k;
import e1.v;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final MaterialButton f814a;

    /* renamed from: b, reason: collision with root package name */
    public k f815b;

    /* renamed from: c, reason: collision with root package name */
    public int f816c;

    /* renamed from: d, reason: collision with root package name */
    public int f817d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f818f;

    /* renamed from: g, reason: collision with root package name */
    public int f819g;

    /* renamed from: h, reason: collision with root package name */
    public int f820h;
    public PorterDuff.Mode i;

    /* renamed from: j, reason: collision with root package name */
    public ColorStateList f821j;

    /* renamed from: k, reason: collision with root package name */
    public ColorStateList f822k;

    /* renamed from: l, reason: collision with root package name */
    public ColorStateList f823l;

    /* renamed from: m, reason: collision with root package name */
    public C0125g f824m;

    /* renamed from: q, reason: collision with root package name */
    public boolean f828q;

    /* renamed from: s, reason: collision with root package name */
    public RippleDrawable f830s;

    /* renamed from: t, reason: collision with root package name */
    public int f831t;

    /* renamed from: n, reason: collision with root package name */
    public boolean f825n = false;

    /* renamed from: o, reason: collision with root package name */
    public boolean f826o = false;

    /* renamed from: p, reason: collision with root package name */
    public boolean f827p = false;

    /* renamed from: r, reason: collision with root package name */
    public boolean f829r = true;

    public c(MaterialButton materialButton, k kVar) {
        this.f814a = materialButton;
        this.f815b = kVar;
    }

    public final v a() {
        RippleDrawable rippleDrawable = this.f830s;
        if (rippleDrawable == null || rippleDrawable.getNumberOfLayers() <= 1) {
            return null;
        }
        return this.f830s.getNumberOfLayers() > 2 ? (v) this.f830s.getDrawable(2) : (v) this.f830s.getDrawable(1);
    }

    public final C0125g b(boolean z2) {
        RippleDrawable rippleDrawable = this.f830s;
        if (rippleDrawable == null || rippleDrawable.getNumberOfLayers() <= 0) {
            return null;
        }
        return (C0125g) ((LayerDrawable) ((InsetDrawable) this.f830s.getDrawable(0)).getDrawable()).getDrawable(!z2 ? 1 : 0);
    }

    public final void c(k kVar) {
        this.f815b = kVar;
        if (b(false) != null) {
            b(false).setShapeAppearanceModel(kVar);
        }
        if (b(true) != null) {
            b(true).setShapeAppearanceModel(kVar);
        }
        if (a() != null) {
            a().setShapeAppearanceModel(kVar);
        }
    }

    public final void d(int i, int i3) {
        WeakHashMap weakHashMap = O.f854a;
        MaterialButton materialButton = this.f814a;
        int paddingStart = materialButton.getPaddingStart();
        int paddingTop = materialButton.getPaddingTop();
        int paddingEnd = materialButton.getPaddingEnd();
        int paddingBottom = materialButton.getPaddingBottom();
        int i4 = this.e;
        int i5 = this.f818f;
        this.f818f = i3;
        this.e = i;
        if (!this.f826o) {
            e();
        }
        materialButton.setPaddingRelative(paddingStart, (paddingTop + i) - i4, paddingEnd, (paddingBottom + i3) - i5);
    }

    public final void e() {
        C0125g c0125g = new C0125g(this.f815b);
        MaterialButton materialButton = this.f814a;
        c0125g.i(materialButton.getContext());
        c0125g.setTintList(this.f821j);
        PorterDuff.Mode mode = this.i;
        if (mode != null) {
            c0125g.setTintMode(mode);
        }
        float f3 = this.f820h;
        ColorStateList colorStateList = this.f822k;
        c0125g.f2959b.f2951j = f3;
        c0125g.invalidateSelf();
        C0124f c0124f = c0125g.f2959b;
        if (c0124f.f2947d != colorStateList) {
            c0124f.f2947d = colorStateList;
            c0125g.onStateChange(c0125g.getState());
        }
        C0125g c0125g2 = new C0125g(this.f815b);
        c0125g2.setTint(0);
        float f4 = this.f820h;
        int iX = this.f825n ? L1.d.x(materialButton, R.attr.colorSurface) : 0;
        c0125g2.f2959b.f2951j = f4;
        c0125g2.invalidateSelf();
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(iX);
        C0124f c0124f2 = c0125g2.f2959b;
        if (c0124f2.f2947d != colorStateListValueOf) {
            c0124f2.f2947d = colorStateListValueOf;
            c0125g2.onStateChange(c0125g2.getState());
        }
        C0125g c0125g3 = new C0125g(this.f815b);
        this.f824m = c0125g3;
        c0125g3.setTint(-1);
        RippleDrawable rippleDrawable = new RippleDrawable(AbstractC0114a.a(this.f823l), new InsetDrawable((Drawable) new LayerDrawable(new Drawable[]{c0125g2, c0125g}), this.f816c, this.e, this.f817d, this.f818f), this.f824m);
        this.f830s = rippleDrawable;
        materialButton.setInternalBackground(rippleDrawable);
        C0125g c0125gB = b(false);
        if (c0125gB != null) {
            c0125gB.k(this.f831t);
            c0125gB.setState(materialButton.getDrawableState());
        }
    }

    public final void f() {
        C0125g c0125gB = b(false);
        C0125g c0125gB2 = b(true);
        if (c0125gB != null) {
            float f3 = this.f820h;
            ColorStateList colorStateList = this.f822k;
            c0125gB.f2959b.f2951j = f3;
            c0125gB.invalidateSelf();
            C0124f c0124f = c0125gB.f2959b;
            if (c0124f.f2947d != colorStateList) {
                c0124f.f2947d = colorStateList;
                c0125gB.onStateChange(c0125gB.getState());
            }
            if (c0125gB2 != null) {
                float f4 = this.f820h;
                int iX = this.f825n ? L1.d.x(this.f814a, R.attr.colorSurface) : 0;
                c0125gB2.f2959b.f2951j = f4;
                c0125gB2.invalidateSelf();
                ColorStateList colorStateListValueOf = ColorStateList.valueOf(iX);
                C0124f c0124f2 = c0125gB2.f2959b;
                if (c0124f2.f2947d != colorStateListValueOf) {
                    c0124f2.f2947d = colorStateListValueOf;
                    c0125gB2.onStateChange(c0125gB2.getState());
                }
            }
        }
    }
}
