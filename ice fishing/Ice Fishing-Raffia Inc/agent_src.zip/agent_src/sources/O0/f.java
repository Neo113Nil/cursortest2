package O0;

import e1.C0119a;
import e1.InterfaceC0121c;

/* loaded from: classes.dex */
public final class f {
    public static final C0119a e = new C0119a(0.0f);

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0121c f835a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0121c f836b;

    /* renamed from: c, reason: collision with root package name */
    public final InterfaceC0121c f837c;

    /* renamed from: d, reason: collision with root package name */
    public final InterfaceC0121c f838d;

    public f(InterfaceC0121c interfaceC0121c, InterfaceC0121c interfaceC0121c2, InterfaceC0121c interfaceC0121c3, InterfaceC0121c interfaceC0121c4) {
        this.f835a = interfaceC0121c;
        this.f836b = interfaceC0121c3;
        this.f837c = interfaceC0121c4;
        this.f838d = interfaceC0121c2;
    }
}
