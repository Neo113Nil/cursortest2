package O0;

import C.h;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class b extends U.b {
    public static final Parcelable.Creator<b> CREATOR = new h(2);

    /* renamed from: d, reason: collision with root package name */
    public boolean f813d;

    public b(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        if (classLoader == null) {
            b.class.getClassLoader();
        }
        this.f813d = parcel.readInt() == 1;
    }

    @Override // U.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeInt(this.f813d ? 1 : 0);
    }
}
