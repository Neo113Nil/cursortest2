package O0;

import X1.i;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import java.util.Comparator;
import java.util.Locale;
import r1.j;
import t1.g;

/* loaded from: classes.dex */
public final class d implements Comparator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f832a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f833b;

    public /* synthetic */ d(int i, Object obj) {
        this.f832a = i;
        this.f833b = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f832a) {
            case 0:
                MaterialButton materialButton = (MaterialButton) obj;
                MaterialButton materialButton2 = (MaterialButton) obj2;
                int iCompareTo = Boolean.valueOf(materialButton.f2463p).compareTo(Boolean.valueOf(materialButton2.f2463p));
                if (iCompareTo != 0) {
                    return iCompareTo;
                }
                int iCompareTo2 = Boolean.valueOf(materialButton.isPressed()).compareTo(Boolean.valueOf(materialButton2.isPressed()));
                if (iCompareTo2 != 0) {
                    return iCompareTo2;
                }
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) this.f833b;
                return Integer.valueOf(materialButtonToggleGroup.indexOfChild(materialButton)).compareTo(Integer.valueOf(materialButtonToggleGroup.indexOfChild(materialButton2)));
            case 1:
                int iCompare = ((g) this.f833b).compare(obj, obj2);
                if (iCompare != 0) {
                    return iCompare;
                }
                String str = ((j) obj).f5392b;
                Locale locale = Locale.ROOT;
                String lowerCase = str.toLowerCase(locale);
                i.d(lowerCase, "toLowerCase(...)");
                String lowerCase2 = ((j) obj2).f5392b.toLowerCase(locale);
                i.d(lowerCase2, "toLowerCase(...)");
                return L1.d.o(lowerCase, lowerCase2);
            default:
                int iCompare2 = ((C.j) this.f833b).compare(obj, obj2);
                return iCompare2 != 0 ? iCompare2 : L1.d.o(((j) obj).f5392b, ((j) obj2).f5392b);
        }
    }
}
