package O0;

import P.C0014b;
import Q.g;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.datepicker.j;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.internal.NavigationMenuItemView;
import com.kortosi.kluani.qorzanis.R;

/* loaded from: classes.dex */
public final class e extends C0014b {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f834d;
    public final /* synthetic */ Object e;

    public /* synthetic */ e(int i, Object obj) {
        this.f834d = i;
        this.e = obj;
    }

    @Override // P.C0014b
    public void c(View view, AccessibilityEvent accessibilityEvent) {
        switch (this.f834d) {
            case 1:
                super.c(view, accessibilityEvent);
                accessibilityEvent.setChecked(((CheckableImageButton) this.e).e);
                break;
            default:
                super.c(view, accessibilityEvent);
                break;
        }
    }

    @Override // P.C0014b
    public final void d(View view, g gVar) {
        int i;
        Object obj = this.e;
        View.AccessibilityDelegate accessibilityDelegate = this.f878a;
        switch (this.f834d) {
            case 0:
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, gVar.f998a);
                int i3 = MaterialButtonToggleGroup.f2466l;
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) obj;
                materialButtonToggleGroup.getClass();
                if (view instanceof MaterialButton) {
                    int i4 = 0;
                    for (int i5 = 0; i5 < materialButtonToggleGroup.getChildCount(); i5++) {
                        if (materialButtonToggleGroup.getChildAt(i5) == view) {
                            i = i4;
                        } else {
                            if ((materialButtonToggleGroup.getChildAt(i5) instanceof MaterialButton) && materialButtonToggleGroup.c(i5)) {
                                i4++;
                            }
                        }
                    }
                    i = -1;
                } else {
                    i = -1;
                }
                gVar.j(A0.f.u(0, 1, i, 1, false, ((MaterialButton) view).f2463p));
                break;
            case 1:
                AccessibilityNodeInfo accessibilityNodeInfo = gVar.f998a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
                CheckableImageButton checkableImageButton = (CheckableImageButton) obj;
                accessibilityNodeInfo.setCheckable(checkableImageButton.f2593f);
                accessibilityNodeInfo.setChecked(checkableImageButton.e);
                break;
            case 2:
                AccessibilityNodeInfo accessibilityNodeInfo2 = gVar.f998a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo2);
                accessibilityNodeInfo2.setCheckable(((NavigationMenuItemView) obj).f2604y);
                break;
            default:
                AccessibilityNodeInfo accessibilityNodeInfo3 = gVar.f998a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo3);
                j jVar = (j) obj;
                accessibilityNodeInfo3.setHintText(jVar.f2543j0.getVisibility() == 0 ? jVar.n(R.string.mtrl_picker_toggle_to_year_selection) : jVar.n(R.string.mtrl_picker_toggle_to_day_selection));
                break;
        }
    }
}
