package L0;

import E.b;
import L1.d;
import P.O;
import android.view.View;
import android.view.ViewParent;
import com.google.android.material.behavior.SwipeDismissBehavior;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class a extends d {
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f693f = -1;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ SwipeDismissBehavior f694g;

    public a(SwipeDismissBehavior swipeDismissBehavior) {
        this.f694g = swipeDismissBehavior;
    }

    @Override // L1.d
    public final int J(View view) {
        return view.getWidth();
    }

    @Override // L1.d
    public final void c0(View view, int i) {
        this.f693f = i;
        this.e = view.getLeft();
        ViewParent parent = view.getParent();
        if (parent != null) {
            SwipeDismissBehavior swipeDismissBehavior = this.f694g;
            swipeDismissBehavior.f2395d = true;
            parent.requestDisallowInterceptTouchEvent(true);
            swipeDismissBehavior.f2395d = false;
        }
    }

    @Override // L1.d
    public final void d0(int i) {
        this.f694g.getClass();
    }

    @Override // L1.d
    public final void e0(View view, int i, int i3) {
        float width = view.getWidth();
        SwipeDismissBehavior swipeDismissBehavior = this.f694g;
        float f3 = width * swipeDismissBehavior.f2396f;
        float width2 = view.getWidth() * swipeDismissBehavior.f2397g;
        float fAbs = Math.abs(i - this.e);
        if (fAbs <= f3) {
            view.setAlpha(1.0f);
        } else if (fAbs >= width2) {
            view.setAlpha(0.0f);
        } else {
            view.setAlpha(Math.min(Math.max(0.0f, 1.0f - ((fAbs - f3) / (width2 - f3))), 1.0f));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0069  */
    @Override // L1.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void f0(View view, float f3, float f4) {
        int i;
        this.f693f = -1;
        int width = view.getWidth();
        boolean z2 = true;
        SwipeDismissBehavior swipeDismissBehavior = this.f694g;
        if (f3 != 0.0f) {
            WeakHashMap weakHashMap = O.f854a;
            boolean z3 = view.getLayoutDirection() == 1;
            int i3 = swipeDismissBehavior.e;
            if (i3 != 2 && (i3 != 0 ? i3 != 1 || (!z3 ? f3 < 0.0f : f3 > 0.0f) : !z3 ? f3 > 0.0f : f3 < 0.0f)) {
                i = this.e;
                z2 = false;
            } else if (f3 >= 0.0f) {
                int left = view.getLeft();
                int i4 = this.e;
                i = left < i4 ? this.e - width : i4 + width;
            }
        } else {
            int left2 = view.getLeft() - this.e;
            float width2 = view.getWidth();
            swipeDismissBehavior.getClass();
            if (Math.abs(left2) >= Math.round(width2 * 0.5f)) {
            }
        }
        if (swipeDismissBehavior.f2393b.q(i, view.getTop())) {
            b bVar = new b(swipeDismissBehavior, view, z2);
            WeakHashMap weakHashMap2 = O.f854a;
            view.postOnAnimation(bVar);
        }
    }

    @Override // L1.d
    public final int l(View view, int i) {
        int width;
        int width2;
        int width3;
        WeakHashMap weakHashMap = O.f854a;
        boolean z2 = view.getLayoutDirection() == 1;
        int i3 = this.f694g.e;
        if (i3 == 0) {
            if (z2) {
                width = this.e - view.getWidth();
                width2 = this.e;
            } else {
                width = this.e;
                width3 = view.getWidth();
                width2 = width3 + width;
            }
        } else if (i3 != 1) {
            width = this.e - view.getWidth();
            width2 = view.getWidth() + this.e;
        } else if (z2) {
            width = this.e;
            width3 = view.getWidth();
            width2 = width3 + width;
        } else {
            width = this.e - view.getWidth();
            width2 = this.e;
        }
        return Math.min(Math.max(width, i), width2);
    }

    @Override // L1.d
    public final int m(View view, int i) {
        return view.getTop();
    }

    @Override // L1.d
    public final boolean x0(View view, int i) {
        int i3 = this.f693f;
        return (i3 == -1 || i3 == i) && this.f694g.w(view);
    }
}
