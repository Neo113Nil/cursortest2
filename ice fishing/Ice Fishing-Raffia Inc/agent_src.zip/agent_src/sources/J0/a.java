package J0;

import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import e0.C0117a;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final LinearInterpolator f610a = new LinearInterpolator();

    /* renamed from: b, reason: collision with root package name */
    public static final C0117a f611b = new C0117a(1);

    /* renamed from: c, reason: collision with root package name */
    public static final C0117a f612c = new C0117a(0);

    /* renamed from: d, reason: collision with root package name */
    public static final C0117a f613d = new C0117a(C0117a.e);
    public static final DecelerateInterpolator e = new DecelerateInterpolator();

    public static float a(float f3, float f4, float f5) {
        return ((f4 - f3) * f5) + f3;
    }

    public static float b(float f3, float f4, float f5, float f6, float f7) {
        return f7 <= f5 ? f3 : f7 >= f6 ? f4 : a(f3, f4, (f7 - f5) / (f6 - f5));
    }

    public static int c(int i, int i3, float f3) {
        return Math.round(f3 * (i3 - i)) + i;
    }
}
