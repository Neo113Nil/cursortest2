package J0;

import android.animation.TimeInterpolator;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public long f616a;

    /* renamed from: b, reason: collision with root package name */
    public long f617b;

    /* renamed from: c, reason: collision with root package name */
    public TimeInterpolator f618c;

    /* renamed from: d, reason: collision with root package name */
    public int f619d;
    public int e;

    public final TimeInterpolator a() {
        TimeInterpolator timeInterpolator = this.f618c;
        return timeInterpolator != null ? timeInterpolator : a.f611b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        if (this.f616a == cVar.f616a && this.f617b == cVar.f617b && this.f619d == cVar.f619d && this.e == cVar.e) {
            return a().getClass().equals(cVar.a().getClass());
        }
        return false;
    }

    public final int hashCode() {
        long j3 = this.f616a;
        long j4 = this.f617b;
        return ((((a().getClass().hashCode() + (((((int) (j3 ^ (j3 >>> 32))) * 31) + ((int) ((j4 >>> 32) ^ j4))) * 31)) * 31) + this.f619d) * 31) + this.e;
    }

    public final String toString() {
        return "\n" + c.class.getName() + '{' + Integer.toHexString(System.identityHashCode(this)) + " delay: " + this.f616a + " duration: " + this.f617b + " interpolator: " + a().getClass() + " repeatCount: " + this.f619d + " repeatMode: " + this.e + "}\n";
    }
}
