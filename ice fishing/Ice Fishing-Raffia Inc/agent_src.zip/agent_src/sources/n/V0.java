package n;

import l.InterfaceC0258b;

/* loaded from: classes.dex */
public abstract class V0 extends C0 implements InterfaceC0258b {
}
