package n;

import E0.C0001b;
import P.C0023k;
import a.AbstractC0046a;
import a0.C0054h;
import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import g.AbstractC0131a;
import java.lang.reflect.InvocationTargetException;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public abstract class W0 extends CompoundButton {

    /* renamed from: S, reason: collision with root package name */
    public static final C0001b f4420S = new C0001b(Float.class, "thumbPos", 7);

    /* renamed from: T, reason: collision with root package name */
    public static final int[] f4421T = {R.attr.state_checked};

    /* renamed from: A, reason: collision with root package name */
    public float f4422A;

    /* renamed from: B, reason: collision with root package name */
    public int f4423B;

    /* renamed from: C, reason: collision with root package name */
    public int f4424C;

    /* renamed from: D, reason: collision with root package name */
    public int f4425D;

    /* renamed from: E, reason: collision with root package name */
    public int f4426E;
    public int F;

    /* renamed from: G, reason: collision with root package name */
    public int f4427G;

    /* renamed from: H, reason: collision with root package name */
    public int f4428H;

    /* renamed from: I, reason: collision with root package name */
    public boolean f4429I;

    /* renamed from: J, reason: collision with root package name */
    public final TextPaint f4430J;
    public final ColorStateList K;

    /* renamed from: L, reason: collision with root package name */
    public StaticLayout f4431L;

    /* renamed from: M, reason: collision with root package name */
    public StaticLayout f4432M;

    /* renamed from: N, reason: collision with root package name */
    public final k.a f4433N;

    /* renamed from: O, reason: collision with root package name */
    public ObjectAnimator f4434O;

    /* renamed from: P, reason: collision with root package name */
    public C0290A f4435P;

    /* renamed from: Q, reason: collision with root package name */
    public C0054h f4436Q;

    /* renamed from: R, reason: collision with root package name */
    public final Rect f4437R;

    /* renamed from: b, reason: collision with root package name */
    public Drawable f4438b;

    /* renamed from: c, reason: collision with root package name */
    public ColorStateList f4439c;

    /* renamed from: d, reason: collision with root package name */
    public PorterDuff.Mode f4440d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4441f;

    /* renamed from: g, reason: collision with root package name */
    public Drawable f4442g;

    /* renamed from: h, reason: collision with root package name */
    public ColorStateList f4443h;
    public PorterDuff.Mode i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f4444j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f4445k;

    /* renamed from: l, reason: collision with root package name */
    public int f4446l;

    /* renamed from: m, reason: collision with root package name */
    public int f4447m;

    /* renamed from: n, reason: collision with root package name */
    public int f4448n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f4449o;

    /* renamed from: p, reason: collision with root package name */
    public CharSequence f4450p;

    /* renamed from: q, reason: collision with root package name */
    public CharSequence f4451q;

    /* renamed from: r, reason: collision with root package name */
    public CharSequence f4452r;

    /* renamed from: s, reason: collision with root package name */
    public CharSequence f4453s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f4454t;

    /* renamed from: u, reason: collision with root package name */
    public int f4455u;

    /* renamed from: v, reason: collision with root package name */
    public final int f4456v;

    /* renamed from: w, reason: collision with root package name */
    public float f4457w;

    /* renamed from: x, reason: collision with root package name */
    public float f4458x;

    /* renamed from: y, reason: collision with root package name */
    public final VelocityTracker f4459y;

    /* renamed from: z, reason: collision with root package name */
    public final int f4460z;

    public W0(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        int resourceId;
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.materialSwitchStyle);
        this.f4439c = null;
        this.f4440d = null;
        this.e = false;
        this.f4441f = false;
        this.f4443h = null;
        this.i = null;
        this.f4444j = false;
        this.f4445k = false;
        this.f4459y = VelocityTracker.obtain();
        this.f4429I = true;
        this.f4437R = new Rect();
        X0.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.f4430J = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = AbstractC0131a.f3084w;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, com.kortosi.kluani.qorzanis.R.attr.materialSwitchStyle, 0);
        C0023k c0023k = new C0023k(context, typedArrayObtainStyledAttributes);
        P.O.l(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, com.kortosi.kluani.qorzanis.R.attr.materialSwitchStyle);
        Drawable drawableC = c0023k.c(2);
        this.f4438b = drawableC;
        if (drawableC != null) {
            drawableC.setCallback(this);
        }
        Drawable drawableC2 = c0023k.c(11);
        this.f4442g = drawableC2;
        if (drawableC2 != null) {
            drawableC2.setCallback(this);
        }
        setTextOnInternal(typedArrayObtainStyledAttributes.getText(0));
        setTextOffInternal(typedArrayObtainStyledAttributes.getText(1));
        this.f4454t = typedArrayObtainStyledAttributes.getBoolean(3, true);
        this.f4446l = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        this.f4447m = typedArrayObtainStyledAttributes.getDimensionPixelSize(5, 0);
        this.f4448n = typedArrayObtainStyledAttributes.getDimensionPixelSize(6, 0);
        this.f4449o = typedArrayObtainStyledAttributes.getBoolean(4, false);
        ColorStateList colorStateListB = c0023k.b(9);
        if (colorStateListB != null) {
            this.f4439c = colorStateListB;
            this.e = true;
        }
        PorterDuff.Mode modeC = AbstractC0332r0.c(typedArrayObtainStyledAttributes.getInt(10, -1), null);
        if (this.f4440d != modeC) {
            this.f4440d = modeC;
            this.f4441f = true;
        }
        if (this.e || this.f4441f) {
            a();
        }
        ColorStateList colorStateListB2 = c0023k.b(12);
        if (colorStateListB2 != null) {
            this.f4443h = colorStateListB2;
            this.f4444j = true;
        }
        PorterDuff.Mode modeC2 = AbstractC0332r0.c(typedArrayObtainStyledAttributes.getInt(13, -1), null);
        if (this.i != modeC2) {
            this.i = modeC2;
            this.f4445k = true;
        }
        if (this.f4444j || this.f4445k) {
            b();
        }
        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(7, 0);
        if (resourceId2 != 0) {
            TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(resourceId2, AbstractC0131a.f3085x);
            ColorStateList colorStateList = (!typedArrayObtainStyledAttributes2.hasValue(3) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(3, 0)) == 0 || (colorStateList = AbstractC0046a.z(context, resourceId)) == null) ? typedArrayObtainStyledAttributes2.getColorStateList(3) : colorStateList;
            if (colorStateList != null) {
                this.K = colorStateList;
            } else {
                this.K = getTextColors();
            }
            int dimensionPixelSize = typedArrayObtainStyledAttributes2.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f3 = dimensionPixelSize;
                if (f3 != textPaint.getTextSize()) {
                    textPaint.setTextSize(f3);
                    requestLayout();
                }
            }
            int i = typedArrayObtainStyledAttributes2.getInt(1, -1);
            int i3 = typedArrayObtainStyledAttributes2.getInt(2, -1);
            Typeface typeface = i != 1 ? i != 2 ? i != 3 ? null : Typeface.MONOSPACE : Typeface.SERIF : Typeface.SANS_SERIF;
            if (i3 > 0) {
                Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i3) : Typeface.create(typeface, i3);
                setSwitchTypeface(typefaceDefaultFromStyle);
                int i4 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i3;
                textPaint.setFakeBoldText((i4 & 1) != 0);
                textPaint.setTextSkewX((2 & i4) != 0 ? -0.25f : 0.0f);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                setSwitchTypeface(typeface);
            }
            if (typedArrayObtainStyledAttributes2.getBoolean(14, false)) {
                Context context2 = getContext();
                k.a aVar = new k.a();
                aVar.f3867a = context2.getResources().getConfiguration().locale;
                this.f4433N = aVar;
            } else {
                this.f4433N = null;
            }
            setTextOnInternal(this.f4450p);
            setTextOffInternal(this.f4452r);
            typedArrayObtainStyledAttributes2.recycle();
        }
        new C0299a0(this).f(attributeSet, com.kortosi.kluani.qorzanis.R.attr.materialSwitchStyle);
        c0023k.j();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f4456v = viewConfiguration.getScaledTouchSlop();
        this.f4460z = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().b(attributeSet, com.kortosi.kluani.qorzanis.R.attr.materialSwitchStyle);
        refreshDrawableState();
        setChecked(isChecked());
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.f4435P == null) {
            this.f4435P = new C0290A(this);
        }
        return this.f4435P;
    }

    private boolean getTargetCheckedState() {
        return this.f4422A > 0.5f;
    }

    private int getThumbOffset() {
        boolean z2 = o1.f4571a;
        return (int) (((getLayoutDirection() == 1 ? 1.0f - this.f4422A : this.f4422A) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f4442g;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.f4437R;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f4438b;
        Rect rectB = drawable2 != null ? AbstractC0332r0.b(drawable2) : AbstractC0332r0.f4589c;
        return ((((this.f4423B - this.f4425D) - rect.left) - rect.right) - rectB.left) - rectB.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f4452r = charSequence;
        C0290A emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod transformationMethodA0 = ((L1.d) emojiTextViewHelper.f4301b.f224c).A0(this.f4433N);
        if (transformationMethodA0 != null) {
            charSequence = transformationMethodA0.getTransformation(charSequence, this);
        }
        this.f4453s = charSequence;
        this.f4432M = null;
        if (this.f4454t) {
            d();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f4450p = charSequence;
        C0290A emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod transformationMethodA0 = ((L1.d) emojiTextViewHelper.f4301b.f224c).A0(this.f4433N);
        if (transformationMethodA0 != null) {
            charSequence = transformationMethodA0.getTransformation(charSequence, this);
        }
        this.f4451q = charSequence;
        this.f4431L = null;
        if (this.f4454t) {
            d();
        }
    }

    public final void a() {
        Drawable drawable = this.f4438b;
        if (drawable != null) {
            if (this.e || this.f4441f) {
                Drawable drawableMutate = drawable.mutate();
                this.f4438b = drawableMutate;
                if (this.e) {
                    drawableMutate.setTintList(this.f4439c);
                }
                if (this.f4441f) {
                    this.f4438b.setTintMode(this.f4440d);
                }
                if (this.f4438b.isStateful()) {
                    this.f4438b.setState(getDrawableState());
                }
            }
        }
    }

    public final void b() {
        Drawable drawable = this.f4442g;
        if (drawable != null) {
            if (this.f4444j || this.f4445k) {
                Drawable drawableMutate = drawable.mutate();
                this.f4442g = drawableMutate;
                if (this.f4444j) {
                    drawableMutate.setTintList(this.f4443h);
                }
                if (this.f4445k) {
                    this.f4442g.setTintMode(this.i);
                }
                if (this.f4442g.isStateful()) {
                    this.f4442g.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        setTextOnInternal(this.f4450p);
        setTextOffInternal(this.f4452r);
        requestLayout();
    }

    public final void d() {
        if (this.f4436Q == null && ((L1.d) this.f4435P.f4301b.f224c).P() && Y.j.f1378k != null) {
            Y.j jVarA = Y.j.a();
            int iB = jVarA.b();
            if (iB == 3 || iB == 0) {
                C0054h c0054h = new C0054h(this);
                this.f4436Q = c0054h;
                jVarA.f(c0054h);
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i;
        int i3;
        int i4 = this.f4426E;
        int i5 = this.F;
        int i6 = this.f4427G;
        int i7 = this.f4428H;
        int thumbOffset = getThumbOffset() + i4;
        Drawable drawable = this.f4438b;
        Rect rectB = drawable != null ? AbstractC0332r0.b(drawable) : AbstractC0332r0.f4589c;
        Drawable drawable2 = this.f4442g;
        Rect rect = this.f4437R;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i8 = rect.left;
            thumbOffset += i8;
            if (rectB != null) {
                int i9 = rectB.left;
                if (i9 > i8) {
                    i4 += i9 - i8;
                }
                int i10 = rectB.top;
                int i11 = rect.top;
                i = i10 > i11 ? (i10 - i11) + i5 : i5;
                int i12 = rectB.right;
                int i13 = rect.right;
                if (i12 > i13) {
                    i6 -= i12 - i13;
                }
                int i14 = rectB.bottom;
                int i15 = rect.bottom;
                if (i14 > i15) {
                    i3 = i7 - (i14 - i15);
                }
                this.f4442g.setBounds(i4, i, i6, i3);
            } else {
                i = i5;
            }
            i3 = i7;
            this.f4442g.setBounds(i4, i, i6, i3);
        }
        Drawable drawable3 = this.f4438b;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i16 = thumbOffset - rect.left;
            int i17 = thumbOffset + this.f4425D + rect.right;
            this.f4438b.setBounds(i16, i5, i17, i7);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i16, i5, i17, i7);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableHotspotChanged(float f3, float f4) {
        super.drawableHotspotChanged(f3, f4);
        Drawable drawable = this.f4438b;
        if (drawable != null) {
            drawable.setHotspot(f3, f4);
        }
        Drawable drawable2 = this.f4442g;
        if (drawable2 != null) {
            drawable2.setHotspot(f3, f4);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f4438b;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f4442g;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        boolean z2 = o1.f4571a;
        if (getLayoutDirection() != 1) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.f4423B;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f4448n : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        boolean z2 = o1.f4571a;
        if (getLayoutDirection() == 1) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.f4423B;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f4448n : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f4454t;
    }

    public boolean getSplitTrack() {
        return this.f4449o;
    }

    public int getSwitchMinWidth() {
        return this.f4447m;
    }

    public int getSwitchPadding() {
        return this.f4448n;
    }

    public CharSequence getTextOff() {
        return this.f4452r;
    }

    public CharSequence getTextOn() {
        return this.f4450p;
    }

    public Drawable getThumbDrawable() {
        return this.f4438b;
    }

    public final float getThumbPosition() {
        return this.f4422A;
    }

    public int getThumbTextPadding() {
        return this.f4446l;
    }

    public ColorStateList getThumbTintList() {
        return this.f4439c;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f4440d;
    }

    public Drawable getTrackDrawable() {
        return this.f4442g;
    }

    public ColorStateList getTrackTintList() {
        return this.f4443h;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.i;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f4438b;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f4442g;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.f4434O;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.f4434O.end();
        this.f4434O = null;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f4421T);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int width;
        super.onDraw(canvas);
        Drawable drawable = this.f4442g;
        Rect rect = this.f4437R;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.F;
        int i3 = this.f4428H;
        int i4 = i + rect.top;
        int i5 = i3 - rect.bottom;
        Drawable drawable2 = this.f4438b;
        if (drawable != null) {
            if (!this.f4449o || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectB = AbstractC0332r0.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectB.left;
                rect.right -= rectB.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        StaticLayout staticLayout = getTargetCheckedState() ? this.f4431L : this.f4432M;
        if (staticLayout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.K;
            TextPaint textPaint = this.f4430J;
            if (colorStateList != null) {
                textPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            textPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (staticLayout.getWidth() / 2), ((i4 + i5) / 2) - (staticLayout.getHeight() / 2));
            staticLayout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f4450p : this.f4452r;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int iMax;
        int width;
        int paddingLeft;
        int height;
        int paddingTop;
        super.onLayout(z2, i, i3, i4, i5);
        int iMax2 = 0;
        if (this.f4438b != null) {
            Drawable drawable = this.f4442g;
            Rect rect = this.f4437R;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectB = AbstractC0332r0.b(this.f4438b);
            iMax = Math.max(0, rectB.left - rect.left);
            iMax2 = Math.max(0, rectB.right - rect.right);
        } else {
            iMax = 0;
        }
        boolean z3 = o1.f4571a;
        if (getLayoutDirection() == 1) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.f4423B + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.f4423B) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int height2 = ((getHeight() + getPaddingTop()) - getPaddingBottom()) / 2;
            int i6 = this.f4424C;
            int i7 = height2 - (i6 / 2);
            height = i6 + i7;
            paddingTop = i7;
        } else if (gravity != 80) {
            paddingTop = getPaddingTop();
            height = this.f4424C + paddingTop;
        } else {
            height = getHeight() - getPaddingBottom();
            paddingTop = height - this.f4424C;
        }
        this.f4426E = paddingLeft;
        this.F = paddingTop;
        this.f4428H = height;
        this.f4427G = width;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int intrinsicWidth;
        int intrinsicHeight;
        int intrinsicHeight2 = 0;
        if (this.f4454t) {
            StaticLayout staticLayout = this.f4431L;
            TextPaint textPaint = this.f4430J;
            if (staticLayout == null) {
                CharSequence charSequence = this.f4451q;
                this.f4431L = new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
            if (this.f4432M == null) {
                CharSequence charSequence2 = this.f4453s;
                this.f4432M = new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
        }
        Drawable drawable = this.f4438b;
        Rect rect = this.f4437R;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f4438b.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f4438b.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.f4425D = Math.max(this.f4454t ? (this.f4446l * 2) + Math.max(this.f4431L.getWidth(), this.f4432M.getWidth()) : 0, intrinsicWidth);
        Drawable drawable2 = this.f4442g;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f4442g.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.f4438b;
        if (drawable3 != null) {
            Rect rectB = AbstractC0332r0.b(drawable3);
            iMax = Math.max(iMax, rectB.left);
            iMax2 = Math.max(iMax2, rectB.right);
        }
        int iMax3 = this.f4429I ? Math.max(this.f4447m, (this.f4425D * 2) + iMax + iMax2) : this.f4447m;
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.f4423B = iMax3;
        this.f4424C = iMax4;
        super.onMeasure(i, i3);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f4450p : this.f4452r;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x008e  */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) throws Resources.NotFoundException {
        boolean targetCheckedState;
        VelocityTracker velocityTracker = this.f4459y;
        velocityTracker.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int i = this.f4456v;
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                if (this.f4455u == 2) {
                    this.f4455u = 0;
                    boolean z2 = motionEvent.getAction() == 1 && isEnabled();
                    boolean zIsChecked = isChecked();
                    if (z2) {
                        velocityTracker.computeCurrentVelocity(1000);
                        float xVelocity = velocityTracker.getXVelocity();
                        if (Math.abs(xVelocity) > this.f4460z) {
                            boolean z3 = o1.f4571a;
                            targetCheckedState = getLayoutDirection() != 1 ? xVelocity > 0.0f : xVelocity < 0.0f;
                        } else {
                            targetCheckedState = getTargetCheckedState();
                        }
                    } else {
                        targetCheckedState = zIsChecked;
                    }
                    if (targetCheckedState != zIsChecked) {
                        playSoundEffect(0);
                    }
                    setChecked(targetCheckedState);
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.setAction(3);
                    super.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    super.onTouchEvent(motionEvent);
                    return true;
                }
                this.f4455u = 0;
                velocityTracker.clear();
            } else if (actionMasked == 2) {
                int i3 = this.f4455u;
                if (i3 == 1) {
                    float x2 = motionEvent.getX();
                    float y2 = motionEvent.getY();
                    float f3 = i;
                    if (Math.abs(x2 - this.f4457w) > f3 || Math.abs(y2 - this.f4458x) > f3) {
                        this.f4455u = 2;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        this.f4457w = x2;
                        this.f4458x = y2;
                        return true;
                    }
                } else if (i3 == 2) {
                    float x3 = motionEvent.getX();
                    int thumbScrollRange = getThumbScrollRange();
                    float f4 = x3 - this.f4457w;
                    float f5 = thumbScrollRange != 0 ? f4 / thumbScrollRange : f4 > 0.0f ? 1.0f : -1.0f;
                    boolean z4 = o1.f4571a;
                    if (getLayoutDirection() == 1) {
                        f5 = -f5;
                    }
                    float f6 = this.f4422A;
                    float f7 = f5 + f6;
                    float f8 = f7 >= 0.0f ? f7 > 1.0f ? 1.0f : f7 : 0.0f;
                    if (f8 != f6) {
                        this.f4457w = x3;
                        setThumbPosition(f8);
                    }
                    return true;
                }
            } else if (actionMasked == 3) {
            }
        } else {
            float x4 = motionEvent.getX();
            float y3 = motionEvent.getY();
            if (isEnabled() && this.f4438b != null) {
                int thumbOffset = getThumbOffset();
                Drawable drawable = this.f4438b;
                Rect rect = this.f4437R;
                drawable.getPadding(rect);
                int i4 = this.F - i;
                int i5 = (this.f4426E + thumbOffset) - i;
                int i6 = this.f4425D + i5 + rect.left + rect.right + i;
                int i7 = this.f4428H + i;
                if (x4 > i5 && x4 < i6 && y3 > i4 && y3 < i7) {
                    this.f4455u = 1;
                    this.f4457w = x4;
                    this.f4458x = y3;
                }
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z2) throws Resources.NotFoundException {
        super.setChecked(z2);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            if (Build.VERSION.SDK_INT >= 30) {
                Object string = this.f4450p;
                if (string == null) {
                    string = getResources().getString(com.kortosi.kluani.qorzanis.R.string.abc_capital_on);
                }
                Object obj = string;
                WeakHashMap weakHashMap = P.O.f854a;
                new P.C(com.kortosi.kluani.qorzanis.R.id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, obj);
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            Object string2 = this.f4452r;
            if (string2 == null) {
                string2 = getResources().getString(com.kortosi.kluani.qorzanis.R.string.abc_capital_off);
            }
            Object obj2 = string2;
            WeakHashMap weakHashMap2 = P.O.f854a;
            new P.C(com.kortosi.kluani.qorzanis.R.id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, obj2);
        }
        if (getWindowToken() == null || !isLaidOut()) {
            ObjectAnimator objectAnimator = this.f4434O;
            if (objectAnimator != null) {
                objectAnimator.cancel();
            }
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
            return;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, f4420S, zIsChecked ? 1.0f : 0.0f);
        this.f4434O = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.f4434O.setAutoCancel(true);
        this.f4434O.start();
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
        setTextOnInternal(this.f4450p);
        setTextOffInternal(this.f4452r);
        requestLayout();
    }

    public final void setEnforceSwitchWidth(boolean z2) {
        this.f4429I = z2;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z2) {
        if (this.f4454t != z2) {
            this.f4454t = z2;
            requestLayout();
            if (z2) {
                d();
            }
        }
    }

    public void setSplitTrack(boolean z2) {
        this.f4449o = z2;
        invalidate();
    }

    public void setSwitchMinWidth(int i) {
        this.f4447m = i;
        requestLayout();
    }

    public void setSwitchPadding(int i) {
        this.f4448n = i;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        TextPaint textPaint = this.f4430J;
        if ((textPaint.getTypeface() == null || textPaint.getTypeface().equals(typeface)) && (textPaint.getTypeface() != null || typeface == null)) {
            return;
        }
        textPaint.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) throws Resources.NotFoundException {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f4452r;
        if (string == null) {
            string = getResources().getString(com.kortosi.kluani.qorzanis.R.string.abc_capital_off);
        }
        WeakHashMap weakHashMap = P.O.f854a;
        new P.C(com.kortosi.kluani.qorzanis.R.id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, string);
    }

    public void setTextOn(CharSequence charSequence) throws Resources.NotFoundException {
        setTextOnInternal(charSequence);
        requestLayout();
        if (!isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f4450p;
        if (string == null) {
            string = getResources().getString(com.kortosi.kluani.qorzanis.R.string.abc_capital_on);
        }
        WeakHashMap weakHashMap = P.O.f854a;
        new P.C(com.kortosi.kluani.qorzanis.R.id.tag_state_description, CharSequence.class, 64, 30, 2).f(this, string);
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f4438b;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f4438b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f3) {
        this.f4422A = f3;
        invalidate();
    }

    public void setThumbResource(int i) {
        setThumbDrawable(b1.e.A(getContext(), i));
    }

    public void setThumbTextPadding(int i) {
        this.f4446l = i;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f4439c = colorStateList;
        this.e = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f4440d = mode;
        this.f4441f = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f4442g;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f4442g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i) {
        setTrackDrawable(b1.e.A(getContext(), i));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f4443h = colorStateList;
        this.f4444j = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.i = mode;
        this.f4445k = true;
        b();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() throws Resources.NotFoundException {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f4438b || drawable == this.f4442g;
    }
}
