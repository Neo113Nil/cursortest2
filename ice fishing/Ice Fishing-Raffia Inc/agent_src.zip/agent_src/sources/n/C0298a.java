package n;

import androidx.appcompat.widget.ActionBarContextView;

/* renamed from: n.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0298a implements P.V {

    /* renamed from: a, reason: collision with root package name */
    public boolean f4472a = false;

    /* renamed from: b, reason: collision with root package name */
    public int f4473b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f4474c;

    public C0298a(ActionBarContextView actionBarContextView) {
        this.f4474c = actionBarContextView;
    }

    @Override // P.V
    public final void a() {
        if (this.f4472a) {
            return;
        }
        ActionBarContextView actionBarContextView = this.f4474c;
        actionBarContextView.f1514g = null;
        super/*android.view.View*/.setVisibility(this.f4473b);
    }

    @Override // P.V
    public final void b() {
        this.f4472a = true;
    }

    @Override // P.V
    public final void c() {
        super/*android.view.View*/.setVisibility(0);
        this.f4472a = false;
    }
}
