package n;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* renamed from: n.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0302c implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4489b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ActionBarOverlayLayout f4490c;

    public /* synthetic */ RunnableC0302c(ActionBarOverlayLayout actionBarOverlayLayout, int i) {
        this.f4489b = i;
        this.f4490c = actionBarOverlayLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f4489b) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.f4490c;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f1553x = actionBarOverlayLayout.e.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f1554y);
                break;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.f4490c;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f1553x = actionBarOverlayLayout2.e.animate().translationY(-actionBarOverlayLayout2.e.getHeight()).setListener(actionBarOverlayLayout2.f1554y);
                break;
        }
    }
}
