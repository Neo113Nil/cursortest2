package n;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

/* loaded from: classes.dex */
public final class S extends View.BaseSavedState {
    public static final Parcelable.Creator<S> CREATOR = new G0.a(14);

    /* renamed from: b, reason: collision with root package name */
    public boolean f4402b;

    @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeByte(this.f4402b ? (byte) 1 : (byte) 0);
    }
}
