package n;

/* loaded from: classes.dex */
public abstract class l1 extends S0 {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f4563a = 0;
}
