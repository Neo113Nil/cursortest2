package n;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* renamed from: n.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0343x {

    /* renamed from: b, reason: collision with root package name */
    public static final PorterDuff.Mode f4616b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    public static C0343x f4617c;

    /* renamed from: a, reason: collision with root package name */
    public R0 f4618a;

    public static synchronized C0343x a() {
        try {
            if (f4617c == null) {
                d();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f4617c;
    }

    public static synchronized PorterDuffColorFilter c(int i, PorterDuff.Mode mode) {
        return R0.e(i, mode);
    }

    public static synchronized void d() {
        if (f4617c == null) {
            C0343x c0343x = new C0343x();
            f4617c = c0343x;
            c0343x.f4618a = R0.b();
            R0 r02 = f4617c.f4618a;
            C0341w c0341w = new C0341w();
            synchronized (r02) {
                r02.e = c0341w;
            }
        }
    }

    public static void e(Drawable drawable, Z0 z02, int[] iArr) {
        PorterDuff.Mode mode = R0.f4395f;
        int[] state = drawable.getState();
        if (drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
            drawable.setState(new int[0]);
            drawable.setState(state);
        }
        boolean z2 = z02.f4471d;
        if (!z2 && !z02.f4470c) {
            drawable.clearColorFilter();
            return;
        }
        PorterDuffColorFilter porterDuffColorFilterE = null;
        ColorStateList colorStateList = z2 ? z02.f4468a : null;
        PorterDuff.Mode mode2 = z02.f4470c ? z02.f4469b : R0.f4395f;
        if (colorStateList != null && mode2 != null) {
            porterDuffColorFilterE = R0.e(colorStateList.getColorForState(iArr, 0), mode2);
        }
        drawable.setColorFilter(porterDuffColorFilterE);
    }

    public final synchronized Drawable b(Context context, int i) {
        return this.f4618a.c(context, i);
    }
}
