package n;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import h.C0170I;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import m.InterfaceC0283j;
import m.MenuC0285l;

/* loaded from: classes.dex */
public final class c1 implements InterfaceC0328p, InterfaceC0283j {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Toolbar f4492b;

    public /* synthetic */ c1(Toolbar toolbar) {
        this.f4492b = toolbar;
    }

    @Override // m.InterfaceC0283j
    public boolean c(MenuC0285l menuC0285l, MenuItem menuItem) {
        C0170I c0170i = this.f4492b.f1594P;
        return false;
    }

    @Override // m.InterfaceC0283j
    public void g(MenuC0285l menuC0285l) {
        Toolbar toolbar = this.f4492b;
        C0320l c0320l = toolbar.f1600b.f1562u;
        if (c0320l == null || !c0320l.h()) {
            Iterator it = ((CopyOnWriteArrayList) toolbar.f1587H.f913c).iterator();
            while (it.hasNext()) {
                ((c0.G) it.next()).f2086a.t();
            }
        }
        C0170I c0170i = toolbar.f1594P;
        if (c0170i != null) {
            c0170i.g(menuC0285l);
        }
    }
}
