package n;

/* renamed from: n.c0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0303c0 extends C0326o {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0307e0 f4491d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0303c0(C0307e0 c0307e0) {
        super(1, c0307e0);
        this.f4491d = c0307e0;
    }

    @Override // n.C0326o, n.InterfaceC0301b0
    public final void a(int i) {
        super/*android.widget.TextView*/.setFirstBaselineToTopHeight(i);
    }

    @Override // n.C0326o, n.InterfaceC0301b0
    public final void h(int i) {
        super/*android.widget.TextView*/.setLastBaselineToBottomHeight(i);
    }
}
