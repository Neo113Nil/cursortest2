package n;

/* renamed from: n.h0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0313h0 {
}
