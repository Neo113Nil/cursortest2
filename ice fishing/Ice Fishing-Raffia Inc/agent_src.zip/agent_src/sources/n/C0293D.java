package n;

import P.C0023k;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import k1.AbstractC0239g;

/* renamed from: n.D, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0293D extends MultiAutoCompleteTextView {
    public static final int[] e = {R.attr.popupBackground};

    /* renamed from: b, reason: collision with root package name */
    public final r f4328b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4329c;

    /* renamed from: d, reason: collision with root package name */
    public final C0295F f4330d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0293D(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        Y0.a(context);
        X0.a(this, getContext());
        C0023k c0023kH = C0023k.h(getContext(), attributeSet, e, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) c0023kH.f913c).hasValue(0)) {
            setDropDownBackgroundDrawable(c0023kH.c(0));
        }
        c0023kH.j();
        r rVar = new r(this);
        this.f4328b = rVar;
        rVar.k(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4329c = c0299a0;
        c0299a0.f(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        c0299a0.b();
        C0295F c0295f = new C0295F(this);
        this.f4330d = c0295f;
        c0295f.b(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = isFocusable();
        boolean zIsClickable = isClickable();
        boolean zIsLongClickable = isLongClickable();
        int inputType = getInputType();
        KeyListener keyListenerA = c0295f.a(keyListener);
        if (keyListenerA == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerA);
        setRawInputType(inputType);
        setFocusable(zIsFocusable);
        setClickable(zIsClickable);
        setLongClickable(zIsLongClickable);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4328b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4329c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4328b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4328b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4329c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4329c.e();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        AbstractC0239g.t(editorInfo, inputConnectionOnCreateInputConnection, this);
        return this.f4330d.c(inputConnectionOnCreateInputConnection, editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4328b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4328b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4329c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4329c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(b1.e.A(getContext(), i));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f4330d.d(z2);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f4330d.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4328b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4328b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4329c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4329c;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4329c;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }
}
