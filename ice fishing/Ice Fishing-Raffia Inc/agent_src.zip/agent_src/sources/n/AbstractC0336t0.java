package n;

import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import java.lang.reflect.Method;

/* renamed from: n.t0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0336t0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Method f4596a;

    /* renamed from: b, reason: collision with root package name */
    public static final Method f4597b;

    /* renamed from: c, reason: collision with root package name */
    public static final Method f4598c;

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f4599d;

    static {
        try {
            Class cls = Integer.TYPE;
            Class cls2 = Boolean.TYPE;
            Class cls3 = Float.TYPE;
            Method declaredMethod = AbsListView.class.getDeclaredMethod("positionSelector", cls, View.class, cls2, cls3, cls3);
            f4596a = declaredMethod;
            declaredMethod.setAccessible(true);
            Method declaredMethod2 = AdapterView.class.getDeclaredMethod("setSelectedPositionInt", cls);
            f4597b = declaredMethod2;
            declaredMethod2.setAccessible(true);
            Method declaredMethod3 = AdapterView.class.getDeclaredMethod("setNextSelectedPositionInt", cls);
            f4598c = declaredMethod3;
            declaredMethod3.setAccessible(true);
            f4599d = true;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
