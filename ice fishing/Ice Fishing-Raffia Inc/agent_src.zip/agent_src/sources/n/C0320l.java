package n;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import com.kortosi.kluani.qorzanis.R;
import java.util.ArrayList;
import m.C0287n;
import m.MenuC0285l;
import m.SubMenuC0273D;

/* renamed from: n.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0320l implements m.x {

    /* renamed from: b, reason: collision with root package name */
    public final Context f4537b;

    /* renamed from: c, reason: collision with root package name */
    public Context f4538c;

    /* renamed from: d, reason: collision with root package name */
    public MenuC0285l f4539d;
    public final LayoutInflater e;

    /* renamed from: f, reason: collision with root package name */
    public m.w f4540f;
    public m.z i;

    /* renamed from: j, reason: collision with root package name */
    public int f4543j;

    /* renamed from: k, reason: collision with root package name */
    public C0316j f4544k;

    /* renamed from: l, reason: collision with root package name */
    public Drawable f4545l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f4546m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f4547n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f4548o;

    /* renamed from: p, reason: collision with root package name */
    public int f4549p;

    /* renamed from: q, reason: collision with root package name */
    public int f4550q;

    /* renamed from: r, reason: collision with root package name */
    public int f4551r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f4552s;

    /* renamed from: u, reason: collision with root package name */
    public C0310g f4554u;

    /* renamed from: v, reason: collision with root package name */
    public C0310g f4555v;

    /* renamed from: w, reason: collision with root package name */
    public RunnableC0314i f4556w;

    /* renamed from: x, reason: collision with root package name */
    public C0312h f4557x;

    /* renamed from: z, reason: collision with root package name */
    public int f4559z;

    /* renamed from: g, reason: collision with root package name */
    public final int f4541g = R.layout.abc_action_menu_layout;

    /* renamed from: h, reason: collision with root package name */
    public final int f4542h = R.layout.abc_action_menu_item_layout;

    /* renamed from: t, reason: collision with root package name */
    public final SparseBooleanArray f4553t = new SparseBooleanArray();

    /* renamed from: y, reason: collision with root package name */
    public final A0.f f4558y = new A0.f(29, this);

    public C0320l(Context context) {
        this.f4537b = context;
        this.e = LayoutInflater.from(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r5v4, types: [m.y] */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    public final View a(C0287n c0287n, View view, ViewGroup viewGroup) {
        View actionView = c0287n.getActionView();
        if (actionView == null || c0287n.e()) {
            ActionMenuItemView actionMenuItemView = view instanceof m.y ? (m.y) view : (m.y) this.e.inflate(this.f4542h, viewGroup, false);
            actionMenuItemView.a(c0287n);
            ActionMenuItemView actionMenuItemView2 = actionMenuItemView;
            actionMenuItemView2.setItemInvoker((ActionMenuView) this.i);
            if (this.f4557x == null) {
                this.f4557x = new C0312h(this);
            }
            actionMenuItemView2.setPopupCallback(this.f4557x);
            actionView = actionMenuItemView;
        }
        actionView.setVisibility(c0287n.f4231C ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof C0324n)) {
            actionView.setLayoutParams(ActionMenuView.k(layoutParams));
        }
        return actionView;
    }

    @Override // m.x
    public final void b(MenuC0285l menuC0285l, boolean z2) {
        e();
        C0310g c0310g = this.f4555v;
        if (c0310g != null && c0310g.b()) {
            c0310g.i.dismiss();
        }
        m.w wVar = this.f4540f;
        if (wVar != null) {
            wVar.b(menuC0285l, z2);
        }
    }

    @Override // m.x
    public final boolean c(C0287n c0287n) {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // m.x
    public final void d() {
        int i;
        ViewGroup viewGroup = (ViewGroup) this.i;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            MenuC0285l menuC0285l = this.f4539d;
            if (menuC0285l != null) {
                menuC0285l.i();
                ArrayList arrayListL = this.f4539d.l();
                int size = arrayListL.size();
                i = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    C0287n c0287n = (C0287n) arrayListL.get(i3);
                    if (c0287n.f()) {
                        View childAt = viewGroup.getChildAt(i);
                        C0287n itemData = childAt instanceof m.y ? ((m.y) childAt).getItemData() : null;
                        View viewA = a(c0287n, childAt, viewGroup);
                        if (c0287n != itemData) {
                            viewA.setPressed(false);
                            viewA.jumpDrawablesToCurrentState();
                        }
                        if (viewA != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewA.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewA);
                            }
                            ((ViewGroup) this.i).addView(viewA, i);
                        }
                        i++;
                    }
                }
            } else {
                i = 0;
            }
            while (i < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i) == this.f4544k) {
                    i++;
                } else {
                    viewGroup.removeViewAt(i);
                }
            }
        }
        ((View) this.i).requestLayout();
        MenuC0285l menuC0285l2 = this.f4539d;
        if (menuC0285l2 != null) {
            menuC0285l2.i();
            ArrayList arrayList2 = menuC0285l2.i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                m.o oVar = ((C0287n) arrayList2.get(i4)).f4229A;
            }
        }
        MenuC0285l menuC0285l3 = this.f4539d;
        if (menuC0285l3 != null) {
            menuC0285l3.i();
            arrayList = menuC0285l3.f4211j;
        }
        if (this.f4547n && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((C0287n) arrayList.get(0)).f4231C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f4544k == null) {
                this.f4544k = new C0316j(this, this.f4537b);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f4544k.getParent();
            if (viewGroup3 != this.i) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f4544k);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.i;
                C0316j c0316j = this.f4544k;
                actionMenuView.getClass();
                C0324n c0324nJ = ActionMenuView.j();
                c0324nJ.f4564a = true;
                actionMenuView.addView(c0316j, c0324nJ);
            }
        } else {
            C0316j c0316j2 = this.f4544k;
            if (c0316j2 != null) {
                Object parent = c0316j2.getParent();
                Object obj = this.i;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f4544k);
                }
            }
        }
        ((ActionMenuView) this.i).setOverflowReserved(this.f4547n);
    }

    public final boolean e() {
        Object obj;
        RunnableC0314i runnableC0314i = this.f4556w;
        if (runnableC0314i != null && (obj = this.i) != null) {
            ((View) obj).removeCallbacks(runnableC0314i);
            this.f4556w = null;
            return true;
        }
        C0310g c0310g = this.f4554u;
        if (c0310g == null) {
            return false;
        }
        if (c0310g.b()) {
            c0310g.i.dismiss();
        }
        return true;
    }

    @Override // m.x
    public final void f(Context context, MenuC0285l menuC0285l) {
        this.f4538c = context;
        LayoutInflater.from(context);
        this.f4539d = menuC0285l;
        Resources resources = context.getResources();
        if (!this.f4548o) {
            this.f4547n = true;
        }
        int i = 2;
        this.f4549p = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i = 4;
        } else if (i3 >= 360) {
            i = 3;
        }
        this.f4551r = i;
        int measuredWidth = this.f4549p;
        if (this.f4547n) {
            if (this.f4544k == null) {
                C0316j c0316j = new C0316j(this, this.f4537b);
                this.f4544k = c0316j;
                if (this.f4546m) {
                    c0316j.setImageDrawable(this.f4545l);
                    this.f4545l = null;
                    this.f4546m = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f4544k.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f4544k.getMeasuredWidth();
        } else {
            this.f4544k = null;
        }
        this.f4550q = measuredWidth;
        float f3 = resources.getDisplayMetrics().density;
    }

    @Override // m.x
    public final boolean g() {
        int size;
        ArrayList arrayListL;
        int i;
        boolean z2;
        MenuC0285l menuC0285l = this.f4539d;
        if (menuC0285l != null) {
            arrayListL = menuC0285l.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i3 = this.f4551r;
        int i4 = this.f4550q;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.i;
        int i5 = 0;
        boolean z3 = false;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            i = 2;
            z2 = true;
            if (i5 >= size) {
                break;
            }
            C0287n c0287n = (C0287n) arrayListL.get(i5);
            int i8 = c0287n.f4254y;
            if ((i8 & 2) == 2) {
                i6++;
            } else if ((i8 & 1) == 1) {
                i7++;
            } else {
                z3 = true;
            }
            if (this.f4552s && c0287n.f4231C) {
                i3 = 0;
            }
            i5++;
        }
        if (this.f4547n && (z3 || i7 + i6 > i3)) {
            i3--;
        }
        int i9 = i3 - i6;
        SparseBooleanArray sparseBooleanArray = this.f4553t;
        sparseBooleanArray.clear();
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            C0287n c0287n2 = (C0287n) arrayListL.get(i10);
            int i12 = c0287n2.f4254y;
            boolean z4 = (i12 & 2) == i ? z2 : false;
            int i13 = c0287n2.f4233b;
            if (z4) {
                View viewA = a(c0287n2, null, viewGroup);
                viewA.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewA.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                if (i13 != 0) {
                    sparseBooleanArray.put(i13, z2);
                }
                c0287n2.h(z2);
            } else if ((i12 & 1) == z2) {
                boolean z5 = sparseBooleanArray.get(i13);
                boolean z6 = ((i9 > 0 || z5) && i4 > 0) ? z2 : false;
                if (z6) {
                    View viewA2 = a(c0287n2, null, viewGroup);
                    viewA2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    int measuredWidth2 = viewA2.getMeasuredWidth();
                    i4 -= measuredWidth2;
                    if (i11 == 0) {
                        i11 = measuredWidth2;
                    }
                    z6 &= i4 + i11 > 0;
                }
                if (z6 && i13 != 0) {
                    sparseBooleanArray.put(i13, true);
                } else if (z5) {
                    sparseBooleanArray.put(i13, false);
                    for (int i14 = 0; i14 < i10; i14++) {
                        C0287n c0287n3 = (C0287n) arrayListL.get(i14);
                        if (c0287n3.f4233b == i13) {
                            if (c0287n3.f()) {
                                i9++;
                            }
                            c0287n3.h(false);
                        }
                    }
                }
                if (z6) {
                    i9--;
                }
                c0287n2.h(z6);
            } else {
                c0287n2.h(false);
                i10++;
                i = 2;
                z2 = true;
            }
            i10++;
            i = 2;
            z2 = true;
        }
        return z2;
    }

    @Override // m.x
    public final int getId() {
        return this.f4543j;
    }

    public final boolean h() {
        C0310g c0310g = this.f4554u;
        return c0310g != null && c0310g.b();
    }

    @Override // m.x
    public final void i(m.w wVar) {
        throw null;
    }

    @Override // m.x
    public final boolean j(C0287n c0287n) {
        return false;
    }

    @Override // m.x
    public final Parcelable k() {
        C0318k c0318k = new C0318k();
        c0318k.f4525b = this.f4559z;
        return c0318k;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // m.x
    public final boolean l(SubMenuC0273D subMenuC0273D) {
        boolean z2;
        if (!subMenuC0273D.hasVisibleItems()) {
            return false;
        }
        SubMenuC0273D subMenuC0273D2 = subMenuC0273D;
        while (true) {
            MenuC0285l menuC0285l = subMenuC0273D2.f4144z;
            if (menuC0285l == this.f4539d) {
                break;
            }
            subMenuC0273D2 = (SubMenuC0273D) menuC0285l;
        }
        ViewGroup viewGroup = (ViewGroup) this.i;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof m.y) && ((m.y) childAt).getItemData() == subMenuC0273D2.f4143A) {
                    view = childAt;
                    break;
                }
                i++;
            }
        }
        if (view == null) {
            return false;
        }
        this.f4559z = subMenuC0273D.f4143A.f4232a;
        int size = subMenuC0273D.f4208f.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                z2 = false;
                break;
            }
            MenuItem item = subMenuC0273D.getItem(i3);
            if (item.isVisible() && item.getIcon() != null) {
                z2 = true;
                break;
            }
            i3++;
        }
        C0310g c0310g = new C0310g(this, this.f4538c, subMenuC0273D, view);
        this.f4555v = c0310g;
        c0310g.f4273g = z2;
        m.t tVar = c0310g.i;
        if (tVar != null) {
            tVar.q(z2);
        }
        C0310g c0310g2 = this.f4555v;
        if (!c0310g2.b()) {
            if (c0310g2.e == null) {
                throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
            }
            c0310g2.d(0, 0, false, false);
        }
        m.w wVar = this.f4540f;
        if (wVar != null) {
            wVar.g(subMenuC0273D);
        }
        return true;
    }

    @Override // m.x
    public final void m(Parcelable parcelable) {
        int i;
        MenuItem menuItemFindItem;
        if ((parcelable instanceof C0318k) && (i = ((C0318k) parcelable).f4525b) > 0 && (menuItemFindItem = this.f4539d.findItem(i)) != null) {
            l((SubMenuC0273D) menuItemFindItem.getSubMenu());
        }
    }

    public final boolean n() {
        MenuC0285l menuC0285l;
        if (!this.f4547n || h() || (menuC0285l = this.f4539d) == null || this.i == null || this.f4556w != null) {
            return false;
        }
        menuC0285l.i();
        if (menuC0285l.f4211j.isEmpty()) {
            return false;
        }
        RunnableC0314i runnableC0314i = new RunnableC0314i(this, new C0310g(this, this.f4538c, this.f4539d, this.f4544k));
        this.f4556w = runnableC0314i;
        ((View) this.i).post(runnableC0314i);
        return true;
    }
}
