package n;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: n.C, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0292C extends ImageView {

    /* renamed from: b, reason: collision with root package name */
    public final r f4312b;

    /* renamed from: c, reason: collision with root package name */
    public final G.d f4313c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4314d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0292C(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Y0.a(context);
        this.f4314d = false;
        X0.a(this, getContext());
        r rVar = new r(this);
        this.f4312b = rVar;
        rVar.k(attributeSet, i);
        G.d dVar = new G.d(this);
        this.f4313c = dVar;
        dVar.d(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4312b;
        if (rVar != null) {
            rVar.a();
        }
        G.d dVar = this.f4313c;
        if (dVar != null) {
            dVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4312b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4312b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        Z0 z02;
        G.d dVar = this.f4313c;
        if (dVar == null || (z02 = (Z0) dVar.f505c) == null) {
            return null;
        }
        return z02.f4468a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        Z0 z02;
        G.d dVar = this.f4313c;
        if (dVar == null || (z02 = (Z0) dVar.f505c) == null) {
            return null;
        }
        return z02.f4469b;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(((ImageView) this.f4313c.f504b).getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4312b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4312b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        G.d dVar = this.f4313c;
        if (dVar != null) {
            dVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        G.d dVar = this.f4313c;
        if (dVar != null && drawable != null && !this.f4314d) {
            dVar.f503a = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (dVar != null) {
            dVar.a();
            if (this.f4314d) {
                return;
            }
            ImageView imageView = (ImageView) dVar.f504b;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(dVar.f503a);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.f4314d = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        G.d dVar = this.f4313c;
        if (dVar != null) {
            ImageView imageView = (ImageView) dVar.f504b;
            if (i != 0) {
                Drawable drawableA = b1.e.A(imageView.getContext(), i);
                if (drawableA != null) {
                    AbstractC0332r0.a(drawableA);
                }
                imageView.setImageDrawable(drawableA);
            } else {
                imageView.setImageDrawable(null);
            }
            dVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        G.d dVar = this.f4313c;
        if (dVar != null) {
            dVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4312b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4312b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        G.d dVar = this.f4313c;
        if (dVar != null) {
            if (((Z0) dVar.f505c) == null) {
                dVar.f505c = new Z0();
            }
            Z0 z02 = (Z0) dVar.f505c;
            z02.f4468a = colorStateList;
            z02.f4471d = true;
            dVar.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        G.d dVar = this.f4313c;
        if (dVar != null) {
            if (((Z0) dVar.f505c) == null) {
                dVar.f505c = new Z0();
            }
            Z0 z02 = (Z0) dVar.f505c;
            z02.f4469b = mode;
            z02.f4470c = true;
            dVar.a();
        }
    }
}
