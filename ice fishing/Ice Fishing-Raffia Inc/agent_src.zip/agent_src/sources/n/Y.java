package n;

import android.widget.TextView;

/* loaded from: classes.dex */
public abstract class Y {
    public static int a(TextView textView) {
        return textView.getAutoSizeStepGranularity();
    }

    public static void b(TextView textView, int i, int i3, int i4, int i5) {
        textView.setAutoSizeTextTypeUniformWithConfiguration(i, i3, i4, i5);
    }

    public static void c(TextView textView, int[] iArr, int i) {
        textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
    }

    public static boolean d(TextView textView, String str) {
        return textView.setFontVariationSettings(str);
    }
}
