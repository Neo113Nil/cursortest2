package n;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* renamed from: n.z0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0348z0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4635b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ A0 f4636c;

    public /* synthetic */ RunnableC0348z0(A0 a02, int i) {
        this.f4635b = i;
        this.f4636c = a02;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f4635b) {
            case 0:
                ViewParent parent = this.f4636c.e.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    break;
                }
                break;
            default:
                A0 a02 = this.f4636c;
                a02.a();
                View view = a02.e;
                if (view.isEnabled() && !view.isLongClickable() && a02.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    a02.f4307h = true;
                    break;
                }
                break;
        }
    }
}
