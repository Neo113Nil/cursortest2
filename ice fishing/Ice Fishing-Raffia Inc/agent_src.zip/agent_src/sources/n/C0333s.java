package n;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import java.lang.reflect.InvocationTargetException;

/* renamed from: n.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0333s extends Button {

    /* renamed from: b, reason: collision with root package name */
    public final r f4590b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4591c;

    /* renamed from: d, reason: collision with root package name */
    public C0290A f4592d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0333s(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Y0.a(context);
        X0.a(this, getContext());
        r rVar = new r(this);
        this.f4590b = rVar;
        rVar.k(attributeSet, i);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4591c = c0299a0;
        c0299a0.f(attributeSet, i);
        c0299a0.b();
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.f4592d == null) {
            this.f4592d = new C0290A(this);
        }
        return this.f4592d;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4590b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (o1.f4573c) {
            return super.getAutoSizeMaxTextSize();
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (o1.f4573c) {
            return super.getAutoSizeMinTextSize();
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.f4531d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (o1.f4573c) {
            return super.getAutoSizeStepGranularity();
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.f4530c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (o1.f4573c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0299a0 c0299a0 = this.f4591c;
        return c0299a0 != null ? c0299a0.i.f4532f : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (o1.f4573c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            return c0299a0.i.f4528a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4590b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4590b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4591c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4591c.e();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        super.onLayout(z2, i, i3, i4, i5);
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 == null || o1.f4573c) {
            return;
        }
        c0299a0.i.a();
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i, int i3, int i4) {
        super.onTextChanged(charSequence, i, i3, i4);
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 == null || o1.f4573c) {
            return;
        }
        C0319k0 c0319k0 = c0299a0.i;
        if (c0319k0.f()) {
            c0319k0.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i, int i3, int i4, int i5) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i3, i4, i5);
            return;
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.i(i, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.j(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.k(i);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4590b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4590b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.f4475a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4590b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4590b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4591c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4591c;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        boolean z2 = o1.f4573c;
        if (z2) {
            super.setTextSize(i, f3);
            return;
        }
        C0299a0 c0299a0 = this.f4591c;
        if (c0299a0 == null || z2) {
            return;
        }
        C0319k0 c0319k0 = c0299a0.i;
        if (c0319k0.f()) {
            return;
        }
        c0319k0.g(i, f3);
    }
}
