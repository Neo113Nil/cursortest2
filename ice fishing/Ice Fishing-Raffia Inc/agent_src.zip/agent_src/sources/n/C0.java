package n;

import P.C0023k;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import g.AbstractC0131a;

/* loaded from: classes.dex */
public abstract class C0 extends ViewGroup {

    /* renamed from: b, reason: collision with root package name */
    public boolean f4315b;

    /* renamed from: c, reason: collision with root package name */
    public int f4316c;

    /* renamed from: d, reason: collision with root package name */
    public int f4317d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f4318f;

    /* renamed from: g, reason: collision with root package name */
    public int f4319g;

    /* renamed from: h, reason: collision with root package name */
    public float f4320h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public int[] f4321j;

    /* renamed from: k, reason: collision with root package name */
    public int[] f4322k;

    /* renamed from: l, reason: collision with root package name */
    public Drawable f4323l;

    /* renamed from: m, reason: collision with root package name */
    public int f4324m;

    /* renamed from: n, reason: collision with root package name */
    public int f4325n;

    /* renamed from: o, reason: collision with root package name */
    public int f4326o;

    /* renamed from: p, reason: collision with root package name */
    public int f4327p;

    public C0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f4315b = true;
        this.f4316c = -1;
        this.f4317d = 0;
        this.f4318f = 8388659;
        int[] iArr = AbstractC0131a.f3076o;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, 0);
        P.O.l(this, context, iArr, attributeSet, (TypedArray) c0023kH.f913c, 0);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        int i = typedArray.getInt(1, -1);
        if (i >= 0) {
            setOrientation(i);
        }
        int i3 = typedArray.getInt(0, -1);
        if (i3 >= 0) {
            setGravity(i3);
        }
        boolean z2 = typedArray.getBoolean(2, true);
        if (!z2) {
            setBaselineAligned(z2);
        }
        this.f4320h = typedArray.getFloat(4, -1.0f);
        this.f4316c = typedArray.getInt(3, -1);
        this.i = typedArray.getBoolean(7, false);
        setDividerDrawable(c0023kH.c(5));
        this.f4326o = typedArray.getInt(8, 0);
        this.f4327p = typedArray.getDimensionPixelSize(6, 0);
        c0023kH.j();
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof B0;
    }

    public final void d(Canvas canvas, int i) {
        this.f4323l.setBounds(getPaddingLeft() + this.f4327p, i, (getWidth() - getPaddingRight()) - this.f4327p, this.f4325n + i);
        this.f4323l.draw(canvas);
    }

    public final void e(Canvas canvas, int i) {
        this.f4323l.setBounds(i, getPaddingTop() + this.f4327p, this.f4324m + i, (getHeight() - getPaddingBottom()) - this.f4327p);
        this.f4323l.draw(canvas);
    }

    @Override // android.view.ViewGroup
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public B0 generateDefaultLayoutParams() {
        int i = this.e;
        if (i == 0) {
            return new B0(-2, -2);
        }
        if (i == 1) {
            return new B0(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public B0 generateLayoutParams(AttributeSet attributeSet) {
        return new B0(getContext(), attributeSet);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i;
        if (this.f4316c < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i3 = this.f4316c;
        if (childCount <= i3) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i3);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.f4316c == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int bottom = this.f4317d;
        if (this.e == 1 && (i = this.f4318f & 112) != 48) {
            if (i == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f4319g) / 2;
            } else if (i == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.f4319g;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((B0) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.f4316c;
    }

    public Drawable getDividerDrawable() {
        return this.f4323l;
    }

    public int getDividerPadding() {
        return this.f4327p;
    }

    public int getDividerWidth() {
        return this.f4324m;
    }

    public int getGravity() {
        return this.f4318f;
    }

    public int getOrientation() {
        return this.e;
    }

    public int getShowDividers() {
        return this.f4326o;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f4320h;
    }

    @Override // android.view.ViewGroup
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public B0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof B0 ? new B0((B0) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new B0((ViewGroup.MarginLayoutParams) layoutParams) : new B0(layoutParams);
    }

    public final boolean i(int i) {
        if (i == 0) {
            return (this.f4326o & 1) != 0;
        }
        if (i == getChildCount()) {
            return (this.f4326o & 4) != 0;
        }
        if ((this.f4326o & 2) == 0) {
            return false;
        }
        for (int i3 = i - 1; i3 >= 0; i3--) {
            if (getChildAt(i3).getVisibility() != 8) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int right;
        int left;
        int i;
        if (this.f4323l == null) {
            return;
        }
        int i3 = 0;
        if (this.e == 1) {
            int virtualChildCount = getVirtualChildCount();
            while (i3 < virtualChildCount) {
                View childAt = getChildAt(i3);
                if (childAt != null && childAt.getVisibility() != 8 && i(i3)) {
                    d(canvas, (childAt.getTop() - ((LinearLayout.LayoutParams) ((B0) childAt.getLayoutParams())).topMargin) - this.f4325n);
                }
                i3++;
            }
            if (i(virtualChildCount)) {
                View childAt2 = getChildAt(virtualChildCount - 1);
                d(canvas, childAt2 == null ? (getHeight() - getPaddingBottom()) - this.f4325n : childAt2.getBottom() + ((LinearLayout.LayoutParams) ((B0) childAt2.getLayoutParams())).bottomMargin);
                return;
            }
            return;
        }
        int virtualChildCount2 = getVirtualChildCount();
        boolean z2 = o1.f4571a;
        boolean z3 = getLayoutDirection() == 1;
        while (i3 < virtualChildCount2) {
            View childAt3 = getChildAt(i3);
            if (childAt3 != null && childAt3.getVisibility() != 8 && i(i3)) {
                B0 b02 = (B0) childAt3.getLayoutParams();
                e(canvas, z3 ? childAt3.getRight() + ((LinearLayout.LayoutParams) b02).rightMargin : (childAt3.getLeft() - ((LinearLayout.LayoutParams) b02).leftMargin) - this.f4324m);
            }
            i3++;
        }
        if (i(virtualChildCount2)) {
            View childAt4 = getChildAt(virtualChildCount2 - 1);
            if (childAt4 != null) {
                B0 b03 = (B0) childAt4.getLayoutParams();
                if (z3) {
                    left = childAt4.getLeft() - ((LinearLayout.LayoutParams) b03).leftMargin;
                    i = this.f4324m;
                    right = left - i;
                } else {
                    right = childAt4.getRight() + ((LinearLayout.LayoutParams) b03).rightMargin;
                }
            } else if (z3) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i = this.f4324m;
                right = left - i;
            }
            e(canvas, right);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0156  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x018f  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x01a1  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int measuredHeight;
        int i15;
        int i16;
        int i17;
        int i18 = 8;
        if (this.e == 1) {
            int paddingLeft = getPaddingLeft();
            int i19 = i4 - i;
            int paddingRight = i19 - getPaddingRight();
            int paddingRight2 = (i19 - paddingLeft) - getPaddingRight();
            int virtualChildCount = getVirtualChildCount();
            int i20 = this.f4318f;
            int i21 = i20 & 112;
            int i22 = 8388615 & i20;
            int paddingTop = i21 != 16 ? i21 != 80 ? getPaddingTop() : ((getPaddingTop() + i5) - i3) - this.f4319g : getPaddingTop() + (((i5 - i3) - this.f4319g) / 2);
            int i23 = 0;
            while (i23 < virtualChildCount) {
                View childAt = getChildAt(i23);
                if (childAt != null && childAt.getVisibility() != i18) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight2 = childAt.getMeasuredHeight();
                    B0 b02 = (B0) childAt.getLayoutParams();
                    int i24 = ((LinearLayout.LayoutParams) b02).gravity;
                    if (i24 < 0) {
                        i24 = i22;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i24, getLayoutDirection()) & 7;
                    if (absoluteGravity == 1) {
                        i15 = ((paddingRight2 - measuredWidth) / 2) + paddingLeft + ((LinearLayout.LayoutParams) b02).leftMargin;
                        i16 = ((LinearLayout.LayoutParams) b02).rightMargin;
                    } else if (absoluteGravity != 5) {
                        i17 = ((LinearLayout.LayoutParams) b02).leftMargin + paddingLeft;
                        if (i(i23)) {
                            paddingTop += this.f4325n;
                        }
                        int i25 = paddingTop + ((LinearLayout.LayoutParams) b02).topMargin;
                        childAt.layout(i17, i25, measuredWidth + i17, i25 + measuredHeight2);
                        paddingTop = measuredHeight2 + ((LinearLayout.LayoutParams) b02).bottomMargin + i25;
                    } else {
                        i15 = paddingRight - measuredWidth;
                        i16 = ((LinearLayout.LayoutParams) b02).rightMargin;
                    }
                    i17 = i15 - i16;
                    if (i(i23)) {
                    }
                    int i252 = paddingTop + ((LinearLayout.LayoutParams) b02).topMargin;
                    childAt.layout(i17, i252, measuredWidth + i17, i252 + measuredHeight2);
                    paddingTop = measuredHeight2 + ((LinearLayout.LayoutParams) b02).bottomMargin + i252;
                }
                i23++;
                i18 = 8;
            }
            return;
        }
        boolean z3 = o1.f4571a;
        boolean z4 = getLayoutDirection() == 1;
        int paddingTop2 = getPaddingTop();
        int i26 = i5 - i3;
        int paddingBottom = i26 - getPaddingBottom();
        int paddingBottom2 = (i26 - paddingTop2) - getPaddingBottom();
        int virtualChildCount2 = getVirtualChildCount();
        int i27 = this.f4318f;
        int i28 = 8388615 & i27;
        int i29 = i27 & 112;
        boolean z5 = this.f4315b;
        int[] iArr = this.f4321j;
        int[] iArr2 = this.f4322k;
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i28, getLayoutDirection());
        int paddingLeft2 = absoluteGravity2 != 1 ? absoluteGravity2 != 5 ? getPaddingLeft() : ((getPaddingLeft() + i4) - i) - this.f4319g : getPaddingLeft() + (((i4 - i) - this.f4319g) / 2);
        if (z4) {
            i7 = virtualChildCount2 - 1;
            i6 = -1;
        } else {
            i6 = 1;
            i7 = 0;
        }
        int i30 = 0;
        while (i30 < virtualChildCount2) {
            int i31 = (i6 * i30) + i7;
            View childAt2 = getChildAt(i31);
            if (childAt2 == null) {
                i8 = i7;
                i9 = i6;
                i10 = virtualChildCount2;
                i11 = i29;
                i12 = 1;
            } else {
                i8 = i7;
                if (childAt2.getVisibility() != 8) {
                    int measuredWidth2 = childAt2.getMeasuredWidth();
                    int measuredHeight3 = childAt2.getMeasuredHeight();
                    B0 b03 = (B0) childAt2.getLayoutParams();
                    i9 = i6;
                    if (z5) {
                        i10 = virtualChildCount2;
                        int baseline = ((LinearLayout.LayoutParams) b03).height != -1 ? childAt2.getBaseline() : -1;
                        i13 = ((LinearLayout.LayoutParams) b03).gravity;
                        if (i13 < 0) {
                            i13 = i29;
                        }
                        i14 = i13 & 112;
                        i11 = i29;
                        if (i14 != 16) {
                            measuredHeight = ((((paddingBottom2 - measuredHeight3) / 2) + paddingTop2) + ((LinearLayout.LayoutParams) b03).topMargin) - ((LinearLayout.LayoutParams) b03).bottomMargin;
                        } else if (i14 == 48) {
                            measuredHeight = ((LinearLayout.LayoutParams) b03).topMargin + paddingTop2;
                            if (baseline != -1) {
                                measuredHeight = (iArr[1] - baseline) + measuredHeight;
                            }
                        } else if (i14 != 80) {
                            measuredHeight = paddingTop2;
                        } else {
                            measuredHeight = (paddingBottom - measuredHeight3) - ((LinearLayout.LayoutParams) b03).bottomMargin;
                            if (baseline != -1) {
                                measuredHeight -= iArr2[2] - (childAt2.getMeasuredHeight() - baseline);
                            }
                        }
                        if (i(i31)) {
                            paddingLeft2 += this.f4324m;
                        }
                        int i32 = paddingLeft2 + ((LinearLayout.LayoutParams) b03).leftMargin;
                        childAt2.layout(i32, measuredHeight, i32 + measuredWidth2, measuredHeight + measuredHeight3);
                        paddingLeft2 = measuredWidth2 + ((LinearLayout.LayoutParams) b03).rightMargin + i32;
                    } else {
                        i10 = virtualChildCount2;
                    }
                    i13 = ((LinearLayout.LayoutParams) b03).gravity;
                    if (i13 < 0) {
                    }
                    i14 = i13 & 112;
                    i11 = i29;
                    if (i14 != 16) {
                    }
                    if (i(i31)) {
                    }
                    int i322 = paddingLeft2 + ((LinearLayout.LayoutParams) b03).leftMargin;
                    childAt2.layout(i322, measuredHeight, i322 + measuredWidth2, measuredHeight + measuredHeight3);
                    paddingLeft2 = measuredWidth2 + ((LinearLayout.LayoutParams) b03).rightMargin + i322;
                } else {
                    i9 = i6;
                    i10 = virtualChildCount2;
                    i11 = i29;
                }
                i12 = 1;
            }
            i30 += i12;
            i7 = i8;
            i6 = i9;
            virtualChildCount2 = i10;
            i29 = i11;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:153:0x02f4  */
    /* JADX WARN: Removed duplicated region for block: B:213:0x0486  */
    /* JADX WARN: Removed duplicated region for block: B:214:0x048b  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x04b3  */
    /* JADX WARN: Removed duplicated region for block: B:218:0x04b8  */
    /* JADX WARN: Removed duplicated region for block: B:221:0x04c0  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x04cc  */
    /* JADX WARN: Removed duplicated region for block: B:224:0x04de  */
    /* JADX WARN: Removed duplicated region for block: B:230:0x04f2  */
    /* JADX WARN: Removed duplicated region for block: B:240:0x0537  */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0548  */
    /* JADX WARN: Removed duplicated region for block: B:249:0x0550  */
    /* JADX WARN: Removed duplicated region for block: B:252:0x055b  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x05e4  */
    /* JADX WARN: Removed duplicated region for block: B:313:0x0691  */
    /* JADX WARN: Removed duplicated region for block: B:315:0x0698  */
    /* JADX WARN: Removed duplicated region for block: B:318:0x06b4  */
    /* JADX WARN: Removed duplicated region for block: B:368:0x07cb  */
    /* JADX WARN: Removed duplicated region for block: B:381:0x0806  */
    /* JADX WARN: Removed duplicated region for block: B:388:0x083d  */
    /* JADX WARN: Removed duplicated region for block: B:391:0x0860  */
    /* JADX WARN: Removed duplicated region for block: B:442:? A[RETURN, SYNTHETIC] */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onMeasure(int i, int i3) {
        char c3;
        int i4;
        int iMax;
        float f3;
        int i5;
        int i6;
        int i7;
        int i8;
        char c4;
        int i9;
        int i10;
        int i11;
        int i12;
        float f4;
        int i13;
        int i14;
        int baseline;
        int i15;
        int i16;
        float f5;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        boolean z2;
        boolean z3;
        B0 b02;
        boolean z4;
        int i22;
        boolean z5;
        int i23;
        int i24;
        int baseline2;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        int i30;
        int i31;
        int i32;
        int i33;
        boolean z6;
        B0 b03;
        boolean z7;
        int i34;
        boolean z8;
        int iMax2;
        int i35 = -2;
        int i36 = 1073741824;
        int i37 = 8;
        int i38 = Integer.MIN_VALUE;
        float f6 = 0.0f;
        boolean z9 = true;
        if (this.e == 1) {
            this.f4319g = 0;
            int virtualChildCount = getVirtualChildCount();
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i3);
            int i39 = this.f4316c;
            boolean z10 = this.i;
            boolean z11 = true;
            int i40 = 0;
            int iMax3 = 0;
            int iMax4 = 0;
            boolean z12 = false;
            int iMax5 = 0;
            int i41 = 0;
            int i42 = 0;
            boolean z13 = false;
            float f7 = 0.0f;
            while (i40 < virtualChildCount) {
                View childAt = getChildAt(i40);
                if (childAt == null) {
                    this.f4319g = this.f4319g;
                } else {
                    if (childAt.getVisibility() != i37) {
                        if (i(i40)) {
                            this.f4319g += this.f4325n;
                        }
                        B0 b04 = (B0) childAt.getLayoutParams();
                        float f8 = ((LinearLayout.LayoutParams) b04).weight;
                        f7 += f8;
                        if (mode2 == i36 && ((LinearLayout.LayoutParams) b04).height == 0 && f8 > f6) {
                            int i43 = this.f4319g;
                            this.f4319g = Math.max(i43, ((LinearLayout.LayoutParams) b04).topMargin + i43 + ((LinearLayout.LayoutParams) b04).bottomMargin);
                            i30 = i39;
                            i31 = mode2;
                            i32 = mode;
                            i33 = virtualChildCount;
                            b03 = b04;
                            z7 = true;
                            z6 = true;
                        } else {
                            if (((LinearLayout.LayoutParams) b04).height != 0 || f8 <= f6) {
                                i29 = i38;
                            } else {
                                ((LinearLayout.LayoutParams) b04).height = i35;
                                i29 = 0;
                            }
                            int i44 = f7 == f6 ? this.f4319g : 0;
                            i30 = i39;
                            i31 = mode2;
                            i32 = mode;
                            i33 = virtualChildCount;
                            z6 = true;
                            b03 = b04;
                            measureChildWithMargins(childAt, i, 0, i3, i44);
                            if (i29 != i38) {
                                ((LinearLayout.LayoutParams) b03).height = i29;
                            }
                            int measuredHeight = childAt.getMeasuredHeight();
                            int i45 = this.f4319g;
                            this.f4319g = Math.max(i45, i45 + measuredHeight + ((LinearLayout.LayoutParams) b03).topMargin + ((LinearLayout.LayoutParams) b03).bottomMargin);
                            int i46 = iMax5;
                            if (z10) {
                                iMax5 = Math.max(measuredHeight, i46);
                            }
                            z7 = z12;
                        }
                        if (i30 >= 0 && i30 == i40 + 1) {
                            this.f4317d = this.f4319g;
                        }
                        if (i40 < i30 && ((LinearLayout.LayoutParams) b03).weight > 0.0f) {
                            throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                        }
                        i34 = i32;
                        if (i34 == 1073741824 || ((LinearLayout.LayoutParams) b03).width != -1) {
                            z8 = false;
                        } else {
                            z8 = z6;
                            z13 = z8;
                        }
                        int i47 = ((LinearLayout.LayoutParams) b03).leftMargin + ((LinearLayout.LayoutParams) b03).rightMargin;
                        int measuredWidth = childAt.getMeasuredWidth() + i47;
                        iMax2 = Math.max(i41, measuredWidth);
                        int iCombineMeasuredStates = View.combineMeasuredStates(i42, childAt.getMeasuredState());
                        boolean z14 = (z11 && ((LinearLayout.LayoutParams) b03).width == -1) ? z6 : false;
                        if (((LinearLayout.LayoutParams) b03).weight > 0.0f) {
                            if (!z8) {
                                i47 = measuredWidth;
                            }
                            iMax4 = Math.max(iMax4, i47);
                        } else {
                            int i48 = iMax4;
                            if (!z8) {
                                i47 = measuredWidth;
                            }
                            iMax3 = Math.max(iMax3, i47);
                            iMax4 = i48;
                        }
                        z12 = z7;
                        i42 = iCombineMeasuredStates;
                        z11 = z14;
                    }
                    i40++;
                    mode = i34;
                    i41 = iMax2;
                    i39 = i30;
                    z9 = z6;
                    mode2 = i31;
                    virtualChildCount = i33;
                    i35 = -2;
                    i36 = 1073741824;
                    i37 = 8;
                    i38 = Integer.MIN_VALUE;
                    f6 = 0.0f;
                }
                i30 = i39;
                i31 = mode2;
                i34 = mode;
                i33 = virtualChildCount;
                iMax2 = i41;
                z6 = true;
                i40++;
                mode = i34;
                i41 = iMax2;
                i39 = i30;
                z9 = z6;
                mode2 = i31;
                virtualChildCount = i33;
                i35 = -2;
                i36 = 1073741824;
                i37 = 8;
                i38 = Integer.MIN_VALUE;
                f6 = 0.0f;
            }
            int i49 = mode2;
            int i50 = mode;
            int i51 = virtualChildCount;
            boolean z15 = z9;
            int iMax6 = iMax3;
            int i52 = iMax4;
            int i53 = iMax5;
            int i54 = i41;
            int iCombineMeasuredStates2 = i42;
            if (this.f4319g > 0 && i(i51)) {
                this.f4319g += this.f4325n;
            }
            int i55 = i49;
            if (z10 && (i55 == Integer.MIN_VALUE || i55 == 0)) {
                this.f4319g = 0;
                for (int i56 = 0; i56 < i51; i56++) {
                    View childAt2 = getChildAt(i56);
                    if (childAt2 == null) {
                        this.f4319g = this.f4319g;
                    } else if (childAt2.getVisibility() != 8) {
                        B0 b05 = (B0) childAt2.getLayoutParams();
                        int i57 = this.f4319g;
                        this.f4319g = Math.max(i57, i57 + i53 + ((LinearLayout.LayoutParams) b05).topMargin + ((LinearLayout.LayoutParams) b05).bottomMargin);
                    }
                }
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop() + this.f4319g;
            this.f4319g = paddingBottom;
            int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, 0);
            int i58 = (16777215 & iResolveSizeAndState) - this.f4319g;
            if (z12 || (i58 != 0 && f7 > 0.0f)) {
                float f9 = this.f4320h;
                if (f9 > 0.0f) {
                    f7 = f9;
                }
                this.f4319g = 0;
                int i59 = 0;
                while (i59 < i51) {
                    View childAt3 = getChildAt(i59);
                    if (childAt3.getVisibility() == 8) {
                        i26 = i55;
                    } else {
                        B0 b06 = (B0) childAt3.getLayoutParams();
                        float f10 = ((LinearLayout.LayoutParams) b06).weight;
                        if (f10 > 0.0f) {
                            int i60 = (int) ((i58 * f10) / f7);
                            f7 -= f10;
                            int i61 = i58 - i60;
                            int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + ((LinearLayout.LayoutParams) b06).leftMargin + ((LinearLayout.LayoutParams) b06).rightMargin, ((LinearLayout.LayoutParams) b06).width);
                            if (((LinearLayout.LayoutParams) b06).height == 0) {
                                i28 = 1073741824;
                                if (i55 == 1073741824) {
                                    if (i60 <= 0) {
                                        i60 = 0;
                                    }
                                    childAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(i60, 1073741824));
                                }
                                iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, childAt3.getMeasuredState() & (-256));
                                i58 = i61;
                            } else {
                                i28 = 1073741824;
                            }
                            int measuredHeight2 = childAt3.getMeasuredHeight() + i60;
                            if (measuredHeight2 < 0) {
                                measuredHeight2 = 0;
                            }
                            childAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(measuredHeight2, i28));
                            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, childAt3.getMeasuredState() & (-256));
                            i58 = i61;
                        }
                        int i62 = ((LinearLayout.LayoutParams) b06).leftMargin + ((LinearLayout.LayoutParams) b06).rightMargin;
                        int measuredWidth2 = childAt3.getMeasuredWidth() + i62;
                        int iMax7 = Math.max(i54, measuredWidth2);
                        if (i50 != 1073741824) {
                            i26 = i55;
                            i27 = -1;
                            if (((LinearLayout.LayoutParams) b06).width != -1) {
                            }
                            iMax6 = Math.max(iMax6, i62);
                            boolean z16 = (z11 || ((LinearLayout.LayoutParams) b06).width != i27) ? false : z15;
                            int i63 = this.f4319g;
                            this.f4319g = Math.max(i63, childAt3.getMeasuredHeight() + i63 + ((LinearLayout.LayoutParams) b06).topMargin + ((LinearLayout.LayoutParams) b06).bottomMargin);
                            z11 = z16;
                            i54 = iMax7;
                        } else {
                            i26 = i55;
                            i27 = -1;
                        }
                        i62 = measuredWidth2;
                        iMax6 = Math.max(iMax6, i62);
                        if (z11) {
                            int i632 = this.f4319g;
                            this.f4319g = Math.max(i632, childAt3.getMeasuredHeight() + i632 + ((LinearLayout.LayoutParams) b06).topMargin + ((LinearLayout.LayoutParams) b06).bottomMargin);
                            z11 = z16;
                            i54 = iMax7;
                        }
                    }
                    i59++;
                    i55 = i26;
                }
                this.f4319g = getPaddingBottom() + getPaddingTop() + this.f4319g;
            } else {
                iMax6 = Math.max(iMax6, i52);
                if (z10 && i55 != 1073741824) {
                    for (int i64 = 0; i64 < i51; i64++) {
                        View childAt4 = getChildAt(i64);
                        if (childAt4 != null && childAt4.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((B0) childAt4.getLayoutParams())).weight > 0.0f) {
                            childAt4.measure(View.MeasureSpec.makeMeasureSpec(childAt4.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i53, 1073741824));
                        }
                    }
                }
            }
            int i65 = i54;
            if (z11 || i50 == 1073741824) {
                iMax6 = i65;
            }
            setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax6, getSuggestedMinimumWidth()), i, iCombineMeasuredStates2), iResolveSizeAndState);
            if (z13) {
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
                for (int i66 = 0; i66 < i51; i66++) {
                    View childAt5 = getChildAt(i66);
                    if (childAt5.getVisibility() != 8) {
                        B0 b07 = (B0) childAt5.getLayoutParams();
                        if (((LinearLayout.LayoutParams) b07).width == -1) {
                            int i67 = ((LinearLayout.LayoutParams) b07).height;
                            ((LinearLayout.LayoutParams) b07).height = childAt5.getMeasuredHeight();
                            measureChildWithMargins(childAt5, iMakeMeasureSpec, 0, i3, 0);
                            ((LinearLayout.LayoutParams) b07).height = i67;
                        }
                    }
                }
                return;
            }
            return;
        }
        this.f4319g = 0;
        int virtualChildCount2 = getVirtualChildCount();
        int mode3 = View.MeasureSpec.getMode(i);
        int mode4 = View.MeasureSpec.getMode(i3);
        if (this.f4321j == null || this.f4322k == null) {
            this.f4321j = new int[4];
            this.f4322k = new int[4];
        }
        int[] iArr = this.f4321j;
        int[] iArr2 = this.f4322k;
        iArr[3] = -1;
        iArr[2] = -1;
        iArr[1] = -1;
        iArr[0] = -1;
        iArr2[3] = -1;
        iArr2[2] = -1;
        iArr2[1] = -1;
        iArr2[0] = -1;
        boolean z17 = this.f4315b;
        boolean z18 = this.i;
        boolean z19 = mode3 == 1073741824;
        boolean z20 = true;
        int iMax8 = 0;
        float f11 = 0.0f;
        int i68 = 0;
        int i69 = 0;
        int i70 = 0;
        int iMax9 = 0;
        int iMax10 = 0;
        boolean z21 = false;
        boolean z22 = false;
        while (i69 < virtualChildCount2) {
            View childAt6 = getChildAt(i69);
            if (childAt6 == null) {
                this.f4319g = this.f4319g;
                i21 = i69;
                z2 = z18;
                z3 = z17;
            } else {
                int i71 = iMax8;
                int i72 = i68;
                if (childAt6.getVisibility() == 8) {
                    z3 = z17;
                    iMax8 = i71;
                    i68 = i72;
                    i21 = i69;
                    z2 = z18;
                } else {
                    if (i(i69)) {
                        this.f4319g += this.f4324m;
                    }
                    B0 b08 = (B0) childAt6.getLayoutParams();
                    float f12 = ((LinearLayout.LayoutParams) b08).weight;
                    float f13 = f11 + f12;
                    if (mode3 == 1073741824 && ((LinearLayout.LayoutParams) b08).width == 0 && f12 > 0.0f) {
                        if (z19) {
                            i25 = i69;
                            this.f4319g = ((LinearLayout.LayoutParams) b08).leftMargin + ((LinearLayout.LayoutParams) b08).rightMargin + this.f4319g;
                        } else {
                            i25 = i69;
                            int i73 = this.f4319g;
                            this.f4319g = Math.max(i73, ((LinearLayout.LayoutParams) b08).leftMargin + i73 + ((LinearLayout.LayoutParams) b08).rightMargin);
                        }
                        if (z17) {
                            int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
                            childAt6.measure(iMakeMeasureSpec2, iMakeMeasureSpec2);
                            b02 = b08;
                            i18 = i71;
                            i19 = i72;
                            i21 = i25;
                            z2 = z18;
                            z3 = z17;
                        } else {
                            b02 = b08;
                            i18 = i71;
                            i19 = i72;
                            i21 = i25;
                            i22 = 1073741824;
                            z2 = z18;
                            z3 = z17;
                            z4 = true;
                            if (mode4 == i22 && ((LinearLayout.LayoutParams) b02).height == -1) {
                                z5 = true;
                                z22 = true;
                            } else {
                                z5 = false;
                            }
                            i23 = ((LinearLayout.LayoutParams) b02).topMargin + ((LinearLayout.LayoutParams) b02).bottomMargin;
                            int measuredHeight3 = childAt6.getMeasuredHeight() + i23;
                            int iCombineMeasuredStates3 = View.combineMeasuredStates(i70, childAt6.getMeasuredState());
                            if (z3 || (baseline2 = childAt6.getBaseline()) == -1) {
                                i24 = i23;
                            } else {
                                int i74 = ((LinearLayout.LayoutParams) b02).gravity;
                                if (i74 < 0) {
                                    i74 = this.f4318f;
                                }
                                int i75 = (((i74 & 112) >> 4) & (-2)) >> 1;
                                i24 = i23;
                                iArr[i75] = Math.max(iArr[i75], baseline2);
                                iArr2[i75] = Math.max(iArr2[i75], measuredHeight3 - baseline2);
                            }
                            int iMax11 = Math.max(i19, measuredHeight3);
                            boolean z23 = !z20 && ((LinearLayout.LayoutParams) b02).height == -1;
                            if (((LinearLayout.LayoutParams) b02).weight <= 0.0f) {
                                if (z5) {
                                    measuredHeight3 = i24;
                                }
                                iMax10 = Math.max(iMax10, measuredHeight3);
                                iMax8 = i18;
                            } else {
                                if (z5) {
                                    measuredHeight3 = i24;
                                }
                                iMax8 = Math.max(i18, measuredHeight3);
                            }
                            i68 = iMax11;
                            i70 = iCombineMeasuredStates3;
                            z21 = z4;
                            z20 = z23;
                            f11 = f13;
                        }
                    } else {
                        int i76 = i69;
                        if (((LinearLayout.LayoutParams) b08).width == 0) {
                            f5 = 0.0f;
                            if (f12 > 0.0f) {
                                ((LinearLayout.LayoutParams) b08).width = -2;
                                i17 = 0;
                            }
                            i18 = i71;
                            i19 = i72;
                            i20 = i17;
                            i21 = i76;
                            z2 = z18;
                            z3 = z17;
                            measureChildWithMargins(childAt6, i, f13 != f5 ? this.f4319g : 0, i3, 0);
                            if (i20 == Integer.MIN_VALUE) {
                                b02 = b08;
                                ((LinearLayout.LayoutParams) b02).width = i20;
                            } else {
                                b02 = b08;
                            }
                            int measuredWidth3 = childAt6.getMeasuredWidth();
                            if (z19) {
                                int i77 = this.f4319g;
                                this.f4319g = Math.max(i77, i77 + measuredWidth3 + ((LinearLayout.LayoutParams) b02).leftMargin + ((LinearLayout.LayoutParams) b02).rightMargin);
                            } else {
                                this.f4319g = ((LinearLayout.LayoutParams) b02).leftMargin + measuredWidth3 + ((LinearLayout.LayoutParams) b02).rightMargin + this.f4319g;
                            }
                            if (z2) {
                                iMax9 = Math.max(measuredWidth3, iMax9);
                            }
                        } else {
                            f5 = 0.0f;
                        }
                        i17 = Integer.MIN_VALUE;
                        i18 = i71;
                        i19 = i72;
                        i20 = i17;
                        i21 = i76;
                        z2 = z18;
                        z3 = z17;
                        measureChildWithMargins(childAt6, i, f13 != f5 ? this.f4319g : 0, i3, 0);
                        if (i20 == Integer.MIN_VALUE) {
                        }
                        int measuredWidth32 = childAt6.getMeasuredWidth();
                        if (z19) {
                        }
                        if (z2) {
                        }
                    }
                    z4 = z21;
                    i22 = 1073741824;
                    if (mode4 == i22) {
                        z5 = false;
                        i23 = ((LinearLayout.LayoutParams) b02).topMargin + ((LinearLayout.LayoutParams) b02).bottomMargin;
                        int measuredHeight32 = childAt6.getMeasuredHeight() + i23;
                        int iCombineMeasuredStates32 = View.combineMeasuredStates(i70, childAt6.getMeasuredState());
                        if (z3) {
                            i24 = i23;
                            int iMax112 = Math.max(i19, measuredHeight32);
                            if (z20) {
                                if (((LinearLayout.LayoutParams) b02).weight <= 0.0f) {
                                }
                                i68 = iMax112;
                                i70 = iCombineMeasuredStates32;
                                z21 = z4;
                                z20 = z23;
                                f11 = f13;
                            }
                        }
                    }
                }
            }
            i69 = i21 + 1;
            z18 = z2;
            z17 = z3;
        }
        int i78 = i68;
        boolean z24 = z18;
        boolean z25 = z17;
        if (this.f4319g > 0 && i(virtualChildCount2)) {
            this.f4319g += this.f4324m;
        }
        int i79 = iArr[1];
        if (i79 == -1 && iArr[0] == -1 && iArr[2] == -1) {
            c3 = 3;
            if (iArr[3] == -1) {
                iMax = i78;
                i4 = i70;
            }
            if (z24 && (mode3 == Integer.MIN_VALUE || mode3 == 0)) {
                this.f4319g = 0;
                for (i16 = 0; i16 < virtualChildCount2; i16++) {
                    View childAt7 = getChildAt(i16);
                    if (childAt7 == null) {
                        this.f4319g = this.f4319g;
                    } else if (childAt7.getVisibility() != 8) {
                        B0 b09 = (B0) childAt7.getLayoutParams();
                        if (z19) {
                            this.f4319g = ((LinearLayout.LayoutParams) b09).leftMargin + iMax9 + ((LinearLayout.LayoutParams) b09).rightMargin + this.f4319g;
                        } else {
                            int i80 = this.f4319g;
                            this.f4319g = Math.max(i80, i80 + iMax9 + ((LinearLayout.LayoutParams) b09).leftMargin + ((LinearLayout.LayoutParams) b09).rightMargin);
                        }
                    }
                }
            }
            int paddingRight = getPaddingRight() + getPaddingLeft() + this.f4319g;
            this.f4319g = paddingRight;
            int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i, 0);
            int i81 = (16777215 & iResolveSizeAndState2) - this.f4319g;
            if (!z21 || (i81 != 0 && f11 > 0.0f)) {
                f3 = this.f4320h;
                if (f3 > 0.0f) {
                    f11 = f3;
                }
                iArr[3] = -1;
                iArr[2] = -1;
                iArr[1] = -1;
                iArr[0] = -1;
                iArr2[3] = -1;
                iArr2[2] = -1;
                iArr2[1] = -1;
                iArr2[0] = -1;
                this.f4319g = 0;
                int iCombineMeasuredStates4 = i4;
                iMax = -1;
                i5 = 0;
                while (i5 < virtualChildCount2) {
                    View childAt8 = getChildAt(i5);
                    if (childAt8 == null || childAt8.getVisibility() == 8) {
                        i10 = i81;
                        i11 = virtualChildCount2;
                    } else {
                        B0 b010 = (B0) childAt8.getLayoutParams();
                        float f14 = ((LinearLayout.LayoutParams) b010).weight;
                        if (f14 > 0.0f) {
                            i11 = virtualChildCount2;
                            int i82 = (int) ((i81 * f14) / f11);
                            float f15 = f11 - f14;
                            int i83 = i81 - i82;
                            int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + ((LinearLayout.LayoutParams) b010).topMargin + ((LinearLayout.LayoutParams) b010).bottomMargin, ((LinearLayout.LayoutParams) b010).height);
                            if (((LinearLayout.LayoutParams) b010).width == 0) {
                                i15 = 1073741824;
                                if (mode3 == 1073741824) {
                                    if (i82 <= 0) {
                                        i82 = 0;
                                    }
                                    childAt8.measure(View.MeasureSpec.makeMeasureSpec(i82, 1073741824), childMeasureSpec2);
                                }
                                iCombineMeasuredStates4 = View.combineMeasuredStates(iCombineMeasuredStates4, childAt8.getMeasuredState() & (-16777216));
                                f11 = f15;
                                i12 = i83;
                            } else {
                                i15 = 1073741824;
                            }
                            int measuredWidth4 = childAt8.getMeasuredWidth() + i82;
                            if (measuredWidth4 < 0) {
                                measuredWidth4 = 0;
                            }
                            childAt8.measure(View.MeasureSpec.makeMeasureSpec(measuredWidth4, i15), childMeasureSpec2);
                            iCombineMeasuredStates4 = View.combineMeasuredStates(iCombineMeasuredStates4, childAt8.getMeasuredState() & (-16777216));
                            f11 = f15;
                            i12 = i83;
                        } else {
                            i12 = i81;
                            i11 = virtualChildCount2;
                        }
                        if (z19) {
                            f4 = f11;
                            this.f4319g = childAt8.getMeasuredWidth() + ((LinearLayout.LayoutParams) b010).leftMargin + ((LinearLayout.LayoutParams) b010).rightMargin + this.f4319g;
                            i13 = i12;
                        } else {
                            f4 = f11;
                            int i84 = this.f4319g;
                            i13 = i12;
                            this.f4319g = Math.max(i84, childAt8.getMeasuredWidth() + i84 + ((LinearLayout.LayoutParams) b010).leftMargin + ((LinearLayout.LayoutParams) b010).rightMargin);
                        }
                        boolean z26 = mode4 != 1073741824 && ((LinearLayout.LayoutParams) b010).height == -1;
                        int i85 = ((LinearLayout.LayoutParams) b010).topMargin + ((LinearLayout.LayoutParams) b010).bottomMargin;
                        int measuredHeight4 = childAt8.getMeasuredHeight() + i85;
                        iMax = Math.max(iMax, measuredHeight4);
                        if (!z26) {
                            i85 = measuredHeight4;
                        }
                        iMax8 = Math.max(iMax8, i85);
                        if (z20) {
                            i14 = -1;
                            boolean z27 = ((LinearLayout.LayoutParams) b010).height == -1;
                            if (!z25 && (baseline = childAt8.getBaseline()) != i14) {
                                int i86 = ((LinearLayout.LayoutParams) b010).gravity;
                                if (i86 < 0) {
                                    i86 = this.f4318f;
                                }
                                int i87 = (((i86 & 112) >> 4) & (-2)) >> 1;
                                iArr[i87] = Math.max(iArr[i87], baseline);
                                iArr2[i87] = Math.max(iArr2[i87], measuredHeight4 - baseline);
                            }
                            z20 = z27;
                            i10 = i13;
                            f11 = f4;
                        } else {
                            i14 = -1;
                        }
                        if (!z25) {
                            z20 = z27;
                            i10 = i13;
                            f11 = f4;
                        }
                    }
                    i5++;
                    i81 = i10;
                    virtualChildCount2 = i11;
                }
                i6 = i3;
                i7 = virtualChildCount2;
                this.f4319g = getPaddingRight() + getPaddingLeft() + this.f4319g;
                i8 = iArr[1];
                if (i8 != -1 && iArr[0] == -1 && iArr[2] == -1) {
                    c4 = 3;
                    if (iArr[3] == -1) {
                        i9 = 0;
                    }
                    i4 = iCombineMeasuredStates4;
                } else {
                    c4 = 3;
                }
                i9 = 0;
                iMax = Math.max(iMax, Math.max(iArr2[c4], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))) + Math.max(iArr[c4], Math.max(iArr[0], Math.max(i8, iArr[2]))));
                i4 = iCombineMeasuredStates4;
            } else {
                iMax8 = Math.max(iMax8, iMax10);
                if (z24 && mode3 != 1073741824) {
                    for (int i88 = 0; i88 < virtualChildCount2; i88++) {
                        View childAt9 = getChildAt(i88);
                        if (childAt9 != null && childAt9.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((B0) childAt9.getLayoutParams())).weight > 0.0f) {
                            childAt9.measure(View.MeasureSpec.makeMeasureSpec(iMax9, 1073741824), View.MeasureSpec.makeMeasureSpec(childAt9.getMeasuredHeight(), 1073741824));
                        }
                    }
                }
                i6 = i3;
                i7 = virtualChildCount2;
                i9 = 0;
            }
            if (!z20 || mode4 == 1073741824) {
                iMax8 = iMax;
            }
            setMeasuredDimension((i4 & (-16777216)) | iResolveSizeAndState2, View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax8, getSuggestedMinimumHeight()), i6, i4 << 16));
            if (z22) {
                return;
            }
            int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
            int i89 = i7;
            while (i9 < i89) {
                View childAt10 = getChildAt(i9);
                if (childAt10.getVisibility() != 8) {
                    B0 b011 = (B0) childAt10.getLayoutParams();
                    if (((LinearLayout.LayoutParams) b011).height == -1) {
                        int i90 = ((LinearLayout.LayoutParams) b011).width;
                        ((LinearLayout.LayoutParams) b011).width = childAt10.getMeasuredWidth();
                        measureChildWithMargins(childAt10, i, 0, iMakeMeasureSpec3, 0);
                        ((LinearLayout.LayoutParams) b011).width = i90;
                    }
                }
                i9++;
            }
            return;
        }
        c3 = 3;
        i4 = i70;
        iMax = Math.max(i78, Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))) + Math.max(iArr[c3], Math.max(iArr[0], Math.max(i79, iArr[2]))));
        if (z24) {
            this.f4319g = 0;
            while (i16 < virtualChildCount2) {
            }
        }
        int paddingRight2 = getPaddingRight() + getPaddingLeft() + this.f4319g;
        this.f4319g = paddingRight2;
        int iResolveSizeAndState22 = View.resolveSizeAndState(Math.max(paddingRight2, getSuggestedMinimumWidth()), i, 0);
        int i812 = (16777215 & iResolveSizeAndState22) - this.f4319g;
        if (z21) {
            f3 = this.f4320h;
            if (f3 > 0.0f) {
            }
            iArr[3] = -1;
            iArr[2] = -1;
            iArr[1] = -1;
            iArr[0] = -1;
            iArr2[3] = -1;
            iArr2[2] = -1;
            iArr2[1] = -1;
            iArr2[0] = -1;
            this.f4319g = 0;
            int iCombineMeasuredStates42 = i4;
            iMax = -1;
            i5 = 0;
            while (i5 < virtualChildCount2) {
            }
            i6 = i3;
            i7 = virtualChildCount2;
            this.f4319g = getPaddingRight() + getPaddingLeft() + this.f4319g;
            i8 = iArr[1];
            if (i8 != -1) {
                c4 = 3;
                i9 = 0;
                iMax = Math.max(iMax, Math.max(iArr2[c4], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))) + Math.max(iArr[c4], Math.max(iArr[0], Math.max(i8, iArr[2]))));
                i4 = iCombineMeasuredStates42;
            }
        }
        if (!z20) {
            iMax8 = iMax;
        }
        setMeasuredDimension((i4 & (-16777216)) | iResolveSizeAndState22, View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax8, getSuggestedMinimumHeight()), i6, i4 << 16));
        if (z22) {
        }
    }

    public void setBaselineAligned(boolean z2) {
        this.f4315b = z2;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i >= 0 && i < getChildCount()) {
            this.f4316c = i;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f4323l) {
            return;
        }
        this.f4323l = drawable;
        if (drawable != null) {
            this.f4324m = drawable.getIntrinsicWidth();
            this.f4325n = drawable.getIntrinsicHeight();
        } else {
            this.f4324m = 0;
            this.f4325n = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i) {
        this.f4327p = i;
    }

    public void setGravity(int i) {
        if (this.f4318f != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.f4318f = i;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        int i3 = i & 8388615;
        int i4 = this.f4318f;
        if ((8388615 & i4) != i3) {
            this.f4318f = i3 | ((-8388616) & i4);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z2) {
        this.i = z2;
    }

    public void setOrientation(int i) {
        if (this.e != i) {
            this.e = i;
            requestLayout();
        }
    }

    public void setShowDividers(int i) {
        if (i != this.f4326o) {
            requestLayout();
        }
        this.f4326o = i;
    }

    public void setVerticalGravity(int i) {
        int i3 = i & 112;
        int i4 = this.f4318f;
        if ((i4 & 112) != i3) {
            this.f4318f = i3 | (i4 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f3) {
        this.f4320h = Math.max(0.0f, f3);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
