package n;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.kortosi.kluani.qorzanis.R;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

/* renamed from: n.x0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0344x0 extends ListView {

    /* renamed from: b, reason: collision with root package name */
    public final Rect f4619b;

    /* renamed from: c, reason: collision with root package name */
    public int f4620c;

    /* renamed from: d, reason: collision with root package name */
    public int f4621d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f4622f;

    /* renamed from: g, reason: collision with root package name */
    public int f4623g;

    /* renamed from: h, reason: collision with root package name */
    public C0340v0 f4624h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final boolean f4625j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f4626k;

    /* renamed from: l, reason: collision with root package name */
    public S.d f4627l;

    /* renamed from: m, reason: collision with root package name */
    public N0.f f4628m;

    public C0344x0(Context context, boolean z2) {
        super(context, null, R.attr.dropDownListViewStyle);
        this.f4619b = new Rect();
        this.f4620c = 0;
        this.f4621d = 0;
        this.e = 0;
        this.f4622f = 0;
        this.f4625j = z2;
        setCacheColorHint(0);
    }

    public final int a(int i, int i3) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        if (adapter == null) {
            return listPaddingTop + listPaddingBottom;
        }
        int measuredHeight = listPaddingTop + listPaddingBottom;
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        int i4 = 0;
        View view = null;
        for (int i5 = 0; i5 < count; i5++) {
            int itemViewType = adapter.getItemViewType(i5);
            if (itemViewType != i4) {
                view = null;
                i4 = itemViewType;
            }
            view = adapter.getView(i5, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i6 = layoutParams.height;
            view.measure(i, i6 > 0 ? View.MeasureSpec.makeMeasureSpec(i6, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i5 > 0) {
                measuredHeight += dividerHeight;
            }
            measuredHeight += view.getMeasuredHeight();
            if (measuredHeight >= i3) {
                return i3;
            }
        }
        return measuredHeight;
    }

    /* JADX WARN: Removed duplicated region for block: B:84:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x0160  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean b(MotionEvent motionEvent, int i) throws IllegalAccessException, IllegalArgumentException {
        boolean z2;
        boolean zA;
        View childAt;
        View childAt2;
        int actionMasked = motionEvent.getActionMasked();
        boolean z3 = false;
        if (actionMasked == 1) {
            z2 = false;
        } else {
            if (actionMasked != 2) {
                z2 = actionMasked != 3;
                if (z2 || z3) {
                    this.f4626k = false;
                    setPressed(false);
                    drawableStateChanged();
                    childAt2 = getChildAt(this.f4623g - getFirstVisiblePosition());
                    if (childAt2 != null) {
                        childAt2.setPressed(false);
                    }
                }
                if (z2) {
                    S.d dVar = this.f4627l;
                    if (dVar != null) {
                        if (dVar.f1062q) {
                            dVar.d();
                        }
                        dVar.f1062q = false;
                    }
                } else {
                    if (this.f4627l == null) {
                        this.f4627l = new S.d(this);
                    }
                    S.d dVar2 = this.f4627l;
                    boolean z4 = dVar2.f1062q;
                    dVar2.f1062q = true;
                    dVar2.onTouch(this, motionEvent);
                }
                return z2;
            }
            z2 = true;
        }
        int iFindPointerIndex = motionEvent.findPointerIndex(i);
        if (iFindPointerIndex >= 0) {
            int x2 = (int) motionEvent.getX(iFindPointerIndex);
            int y2 = (int) motionEvent.getY(iFindPointerIndex);
            int iPointToPosition = pointToPosition(x2, y2);
            if (iPointToPosition == -1) {
                z3 = true;
            } else {
                View childAt3 = getChildAt(iPointToPosition - getFirstVisiblePosition());
                float f3 = x2;
                float f4 = y2;
                this.f4626k = true;
                int i3 = Build.VERSION.SDK_INT;
                AbstractC0334s0.a(this, f3, f4);
                if (!isPressed()) {
                    setPressed(true);
                }
                layoutChildren();
                int i4 = this.f4623g;
                if (i4 != -1 && (childAt = getChildAt(i4 - getFirstVisiblePosition())) != null && childAt != childAt3 && childAt.isPressed()) {
                    childAt.setPressed(false);
                }
                this.f4623g = iPointToPosition;
                AbstractC0334s0.a(childAt3, f3 - childAt3.getLeft(), f4 - childAt3.getTop());
                if (!childAt3.isPressed()) {
                    childAt3.setPressed(true);
                }
                Drawable selector = getSelector();
                boolean z5 = (selector == null || iPointToPosition == -1) ? false : true;
                if (z5) {
                    selector.setVisible(false, false);
                }
                int left = childAt3.getLeft();
                int top = childAt3.getTop();
                int right = childAt3.getRight();
                int bottom = childAt3.getBottom();
                Rect rect = this.f4619b;
                rect.set(left, top, right, bottom);
                rect.left -= this.f4620c;
                rect.top -= this.f4621d;
                rect.right += this.e;
                rect.bottom += this.f4622f;
                if (i3 >= 33) {
                    zA = AbstractC0338u0.a(this);
                } else {
                    Field field = AbstractC0342w0.f4615a;
                    if (field != null) {
                        try {
                            zA = field.getBoolean(this);
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    } else {
                        zA = false;
                    }
                }
                if (childAt3.isEnabled() != zA) {
                    boolean z6 = !zA;
                    if (Build.VERSION.SDK_INT >= 33) {
                        AbstractC0338u0.b(this, z6);
                    } else {
                        Field field2 = AbstractC0342w0.f4615a;
                        if (field2 != null) {
                            try {
                                field2.set(this, Boolean.valueOf(z6));
                            } catch (IllegalAccessException e3) {
                                e3.printStackTrace();
                            }
                        }
                    }
                    if (iPointToPosition != -1) {
                        refreshDrawableState();
                    }
                }
                if (z5) {
                    float fExactCenterX = rect.exactCenterX();
                    float fExactCenterY = rect.exactCenterY();
                    selector.setVisible(getVisibility() == 0, false);
                    selector.setHotspot(fExactCenterX, fExactCenterY);
                }
                Drawable selector2 = getSelector();
                if (selector2 != null && iPointToPosition != -1) {
                    selector2.setHotspot(f3, f4);
                }
                C0340v0 c0340v0 = this.f4624h;
                if (c0340v0 != null) {
                    c0340v0.f4609c = false;
                }
                refreshDrawableState();
                if (actionMasked == 1) {
                    performItemClick(childAt3, iPointToPosition, getItemIdAtPosition(iPointToPosition));
                }
                z2 = true;
                z3 = false;
            }
        }
        if (z2) {
            this.f4626k = false;
            setPressed(false);
            drawableStateChanged();
            childAt2 = getChildAt(this.f4623g - getFirstVisiblePosition());
            if (childAt2 != null) {
            }
        }
        if (z2) {
        }
        return z2;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        Drawable selector;
        Rect rect = this.f4619b;
        if (!rect.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(rect);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.widget.AbsListView, android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        if (this.f4628m != null) {
            return;
        }
        super.drawableStateChanged();
        C0340v0 c0340v0 = this.f4624h;
        if (c0340v0 != null) {
            c0340v0.f4609c = true;
        }
        Drawable selector = getSelector();
        if (selector != null && this.f4626k && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean hasFocus() {
        return this.f4625j || super.hasFocus();
    }

    @Override // android.view.View
    public final boolean hasWindowFocus() {
        return this.f4625j || super.hasWindowFocus();
    }

    @Override // android.view.View
    public final boolean isFocused() {
        return this.f4625j || super.isFocused();
    }

    @Override // android.view.View
    public final boolean isInTouchMode() {
        return (this.f4625j && this.i) || super.isInTouchMode();
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        this.f4628m = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int i = Build.VERSION.SDK_INT;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f4628m == null) {
            N0.f fVar = new N0.f(10, this);
            this.f4628m = fVar;
            post(fVar);
        }
        boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (iPointToPosition != -1 && iPointToPosition != getSelectedItemPosition()) {
                View childAt = getChildAt(iPointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    requestFocus();
                    if (i < 30 || !AbstractC0336t0.f4599d) {
                        setSelectionFromTop(iPointToPosition, childAt.getTop() - getTop());
                    } else {
                        try {
                            AbstractC0336t0.f4596a.invoke(this, Integer.valueOf(iPointToPosition), childAt, Boolean.FALSE, -1, -1);
                            AbstractC0336t0.f4597b.invoke(this, Integer.valueOf(iPointToPosition));
                            AbstractC0336t0.f4598c.invoke(this, Integer.valueOf(iPointToPosition));
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        } catch (InvocationTargetException e3) {
                            e3.printStackTrace();
                        }
                    }
                }
                Drawable selector = getSelector();
                if (selector != null && this.f4626k && isPressed()) {
                    selector.setState(getDrawableState());
                }
            }
        } else {
            setSelection(-1);
        }
        return zOnHoverEvent;
    }

    @Override // android.widget.AbsListView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f4623g = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        N0.f fVar = this.f4628m;
        if (fVar != null) {
            C0344x0 c0344x0 = (C0344x0) fVar.f799c;
            c0344x0.f4628m = null;
            c0344x0.removeCallbacks(fVar);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setListSelectionHidden(boolean z2) {
        this.i = z2;
    }

    @Override // android.widget.AbsListView
    public void setSelector(Drawable drawable) {
        C0340v0 c0340v0 = null;
        if (drawable != null) {
            C0340v0 c0340v02 = new C0340v0();
            Drawable drawable2 = c0340v02.f4608b;
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            c0340v02.f4608b = drawable;
            drawable.setCallback(c0340v02);
            c0340v02.f4609c = true;
            c0340v0 = c0340v02;
        }
        this.f4624h = c0340v0;
        super.setSelector(c0340v0);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f4620c = rect.left;
        this.f4621d = rect.top;
        this.e = rect.right;
        this.f4622f = rect.bottom;
    }
}
