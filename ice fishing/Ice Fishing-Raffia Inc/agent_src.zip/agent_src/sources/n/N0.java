package n;

import android.widget.PopupWindow;

/* loaded from: classes.dex */
public abstract class N0 {
    public static void a(PopupWindow popupWindow, boolean z2) {
        popupWindow.setTouchModal(z2);
    }
}
