package n;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController$RecycleListView;
import h.C0173b;
import h.DialogInterfaceC0177f;

/* loaded from: classes.dex */
public final class N implements T, DialogInterface.OnClickListener {

    /* renamed from: b, reason: collision with root package name */
    public DialogInterfaceC0177f f4378b;

    /* renamed from: c, reason: collision with root package name */
    public O f4379c;

    /* renamed from: d, reason: collision with root package name */
    public CharSequence f4380d;
    public final /* synthetic */ U e;

    public N(U u2) {
        this.e = u2;
    }

    @Override // n.T
    public final boolean a() {
        DialogInterfaceC0177f dialogInterfaceC0177f = this.f4378b;
        if (dialogInterfaceC0177f != null) {
            return dialogInterfaceC0177f.isShowing();
        }
        return false;
    }

    @Override // n.T
    public final CharSequence b() {
        return this.f4380d;
    }

    @Override // n.T
    public final void c(int i) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    @Override // n.T
    public final int d() {
        return 0;
    }

    @Override // n.T
    public final void dismiss() {
        DialogInterfaceC0177f dialogInterfaceC0177f = this.f4378b;
        if (dialogInterfaceC0177f != null) {
            dialogInterfaceC0177f.dismiss();
            this.f4378b = null;
        }
    }

    @Override // n.T
    public final void f(int i, int i3) {
        if (this.f4379c == null) {
            return;
        }
        U u2 = this.e;
        M.j jVar = new M.j(u2.getPopupContext());
        CharSequence charSequence = this.f4380d;
        C0173b c0173b = (C0173b) jVar.f759c;
        if (charSequence != null) {
            c0173b.f3313d = charSequence;
        }
        O o3 = this.f4379c;
        int selectedItemPosition = u2.getSelectedItemPosition();
        c0173b.f3318k = o3;
        c0173b.f3319l = this;
        c0173b.f3321n = selectedItemPosition;
        c0173b.f3320m = true;
        DialogInterfaceC0177f dialogInterfaceC0177fA = jVar.a();
        this.f4378b = dialogInterfaceC0177fA;
        AlertController$RecycleListView alertController$RecycleListView = dialogInterfaceC0177fA.f3352g.f3331f;
        alertController$RecycleListView.setTextDirection(i);
        alertController$RecycleListView.setTextAlignment(i3);
        this.f4378b.show();
    }

    @Override // n.T
    public final void g(CharSequence charSequence) {
        this.f4380d = charSequence;
    }

    @Override // n.T
    public final int i() {
        return 0;
    }

    @Override // n.T
    public final void k(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    @Override // n.T
    public final void l(int i) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    @Override // n.T
    public final Drawable m() {
        return null;
    }

    @Override // n.T
    public final void o(ListAdapter listAdapter) {
        this.f4379c = (O) listAdapter;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        U u2 = this.e;
        u2.setSelection(i);
        if (u2.getOnItemClickListener() != null) {
            u2.performItemClick(null, i, this.f4379c.getItemId(i));
        }
        dismiss();
    }

    @Override // n.T
    public final void p(int i) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
}
