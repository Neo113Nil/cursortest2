package n;

import android.content.Context;
import android.os.Parcelable;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import l.InterfaceC0258b;
import m.C0287n;
import m.MenuC0285l;
import m.SubMenuC0273D;

/* loaded from: classes.dex */
public final class e1 implements m.x {

    /* renamed from: b, reason: collision with root package name */
    public MenuC0285l f4499b;

    /* renamed from: c, reason: collision with root package name */
    public C0287n f4500c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Toolbar f4501d;

    public e1(Toolbar toolbar) {
        this.f4501d = toolbar;
    }

    @Override // m.x
    public final void b(MenuC0285l menuC0285l, boolean z2) {
    }

    @Override // m.x
    public final boolean c(C0287n c0287n) {
        Toolbar toolbar = this.f4501d;
        toolbar.c();
        ViewParent parent = toolbar.i.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.i);
            }
            toolbar.addView(toolbar.i);
        }
        View actionView = c0287n.getActionView();
        toolbar.f1606j = actionView;
        this.f4500c = c0287n;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f1606j);
            }
            f1 f1VarH = Toolbar.h();
            f1VarH.f4502a = (toolbar.f1611o & 112) | 8388611;
            f1VarH.f4503b = 2;
            toolbar.f1606j.setLayoutParams(f1VarH);
            toolbar.addView(toolbar.f1606j);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((f1) childAt.getLayoutParams()).f4503b != 2 && childAt != toolbar.f1600b) {
                toolbar.removeViewAt(childCount);
                toolbar.F.add(childAt);
            }
        }
        toolbar.requestLayout();
        c0287n.f4231C = true;
        c0287n.f4243n.p(false);
        KeyEvent.Callback callback = toolbar.f1606j;
        if (callback instanceof InterfaceC0258b) {
            ((m.p) ((InterfaceC0258b) callback)).f4259b.onActionViewExpanded();
        }
        toolbar.w();
        return true;
    }

    @Override // m.x
    public final void d() {
        if (this.f4500c != null) {
            MenuC0285l menuC0285l = this.f4499b;
            if (menuC0285l != null) {
                int size = menuC0285l.f4208f.size();
                for (int i = 0; i < size; i++) {
                    if (this.f4499b.getItem(i) == this.f4500c) {
                        return;
                    }
                }
            }
            j(this.f4500c);
        }
    }

    @Override // m.x
    public final void f(Context context, MenuC0285l menuC0285l) {
        C0287n c0287n;
        MenuC0285l menuC0285l2 = this.f4499b;
        if (menuC0285l2 != null && (c0287n = this.f4500c) != null) {
            menuC0285l2.d(c0287n);
        }
        this.f4499b = menuC0285l;
    }

    @Override // m.x
    public final boolean g() {
        return false;
    }

    @Override // m.x
    public final int getId() {
        return 0;
    }

    @Override // m.x
    public final boolean j(C0287n c0287n) {
        Toolbar toolbar = this.f4501d;
        KeyEvent.Callback callback = toolbar.f1606j;
        if (callback instanceof InterfaceC0258b) {
            ((m.p) ((InterfaceC0258b) callback)).f4259b.onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.f1606j);
        toolbar.removeView(toolbar.i);
        toolbar.f1606j = null;
        ArrayList arrayList = toolbar.F;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.f4500c = null;
        toolbar.requestLayout();
        c0287n.f4231C = false;
        c0287n.f4243n.p(false);
        toolbar.w();
        return true;
    }

    @Override // m.x
    public final Parcelable k() {
        return null;
    }

    @Override // m.x
    public final boolean l(SubMenuC0273D subMenuC0273D) {
        return false;
    }

    @Override // m.x
    public final void m(Parcelable parcelable) {
    }
}
