package n;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;
import com.kortosi.kluani.qorzanis.R;

/* renamed from: n.H, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0297H extends RatingBar {

    /* renamed from: b, reason: collision with root package name */
    public final C0295F f4341b;

    public C0297H(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.ratingBarStyle);
        X0.a(this, getContext());
        C0295F c0295f = new C0295F(this);
        this.f4341b = c0295f;
        c0295f.b(attributeSet, R.attr.ratingBarStyle);
    }

    @Override // android.widget.RatingBar, android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onMeasure(int i, int i3) {
        super.onMeasure(i, i3);
        Bitmap bitmap = (Bitmap) this.f4341b.f4335c;
        if (bitmap != null) {
            setMeasuredDimension(View.resolveSizeAndState(bitmap.getWidth() * getNumStars(), i, 0), getMeasuredHeight());
        }
    }
}
