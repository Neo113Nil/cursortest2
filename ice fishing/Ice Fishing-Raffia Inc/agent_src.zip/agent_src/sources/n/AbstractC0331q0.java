package n;

import android.graphics.Insets;
import android.graphics.drawable.Drawable;

/* renamed from: n.q0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0331q0 {
    public static Insets a(Drawable drawable) {
        return drawable.getOpticalInsets();
    }
}
