package n;

import P.C0023k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import android.widget.TextView;
import g.AbstractC0131a;

/* renamed from: n.v, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0339v {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f4603a = null;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f4604b = null;

    /* renamed from: c, reason: collision with root package name */
    public boolean f4605c = false;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4606d = false;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public final TextView f4607f;

    public /* synthetic */ C0339v(TextView textView) {
        this.f4607f = textView;
    }

    public void a() {
        CompoundButton compoundButton = (CompoundButton) this.f4607f;
        Drawable buttonDrawable = compoundButton.getButtonDrawable();
        if (buttonDrawable != null) {
            if (this.f4605c || this.f4606d) {
                Drawable drawableMutate = buttonDrawable.mutate();
                if (this.f4605c) {
                    drawableMutate.setTintList(this.f4603a);
                }
                if (this.f4606d) {
                    drawableMutate.setTintMode(this.f4604b);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(compoundButton.getDrawableState());
                }
                compoundButton.setButtonDrawable(drawableMutate);
            }
        }
    }

    public void b() {
        C0337u c0337u = (C0337u) this.f4607f;
        Drawable checkMarkDrawable = c0337u.getCheckMarkDrawable();
        if (checkMarkDrawable != null) {
            if (this.f4605c || this.f4606d) {
                Drawable drawableMutate = checkMarkDrawable.mutate();
                if (this.f4605c) {
                    drawableMutate.setTintList(this.f4603a);
                }
                if (this.f4606d) {
                    drawableMutate.setTintMode(this.f4604b);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(c0337u.getDrawableState());
                }
                c0337u.setCheckMarkDrawable(drawableMutate);
            }
        }
    }

    public void c(AttributeSet attributeSet, int i) {
        int resourceId;
        int resourceId2;
        CompoundButton compoundButton = (CompoundButton) this.f4607f;
        Context context = compoundButton.getContext();
        int[] iArr = AbstractC0131a.f3074m;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, i);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        P.O.l(compoundButton, compoundButton.getContext(), iArr, attributeSet, (TypedArray) c0023kH.f913c, i);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    compoundButton.setButtonDrawable(b1.e.A(compoundButton.getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                compoundButton.setButtonDrawable(b1.e.A(compoundButton.getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                compoundButton.setButtonTintList(c0023kH.b(2));
            }
            if (typedArray.hasValue(3)) {
                compoundButton.setButtonTintMode(AbstractC0332r0.c(typedArray.getInt(3, -1), null));
            }
        } finally {
            c0023kH.j();
        }
    }
}
