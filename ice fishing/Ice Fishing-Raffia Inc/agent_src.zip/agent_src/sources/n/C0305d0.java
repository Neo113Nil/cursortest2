package n;

/* renamed from: n.d0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0305d0 extends C0303c0 {
    public final /* synthetic */ C0307e0 e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0305d0(C0307e0 c0307e0) {
        super(c0307e0);
        this.e = c0307e0;
    }

    @Override // n.C0326o, n.InterfaceC0301b0
    public final void e(int i, float f3) {
        super/*android.widget.TextView*/.setLineHeight(i, f3);
    }
}
