package n;

/* renamed from: n.y0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0346y0 {
}
