package n;

import android.graphics.drawable.Drawable;
import android.widget.ListAdapter;

/* loaded from: classes.dex */
public interface T {
    boolean a();

    CharSequence b();

    void c(int i);

    int d();

    void dismiss();

    void f(int i, int i3);

    void g(CharSequence charSequence);

    int i();

    void k(Drawable drawable);

    void l(int i);

    Drawable m();

    void o(ListAdapter listAdapter);

    void p(int i);
}
