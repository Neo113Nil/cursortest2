package n;

import android.os.Build;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public abstract class o1 {

    /* renamed from: a, reason: collision with root package name */
    public static boolean f4571a;

    /* renamed from: b, reason: collision with root package name */
    public static Method f4572b;

    /* renamed from: c, reason: collision with root package name */
    public static final boolean f4573c;

    static {
        f4573c = Build.VERSION.SDK_INT >= 27;
    }
}
