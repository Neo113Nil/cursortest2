package n;

import android.graphics.Typeface;
import android.os.Build;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public final class W extends G.b {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f4417h;
    public final /* synthetic */ int i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ WeakReference f4418j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ C0299a0 f4419k;

    public W(C0299a0 c0299a0, int i, int i3, WeakReference weakReference) {
        this.f4419k = c0299a0;
        this.f4417h = i;
        this.i = i3;
        this.f4418j = weakReference;
    }

    @Override // G.b
    public final void g(int i) {
    }

    @Override // G.b
    public final void h(Typeface typeface) {
        int i;
        if (Build.VERSION.SDK_INT >= 28 && (i = this.f4417h) != -1) {
            typeface = Z.a(typeface, i, (this.i & 2) != 0);
        }
        C0299a0 c0299a0 = this.f4419k;
        if (c0299a0.f4485m) {
            c0299a0.f4484l = typeface;
            TextView textView = (TextView) this.f4418j.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new N0.b(textView, typeface, c0299a0.f4482j));
                } else {
                    textView.setTypeface(typeface, c0299a0.f4482j);
                }
            }
        }
    }
}
