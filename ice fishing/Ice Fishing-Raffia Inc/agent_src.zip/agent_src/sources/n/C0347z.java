package n;

import P.C0016d;
import P.C0018f;
import P.InterfaceC0015c;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import com.kortosi.kluani.qorzanis.R;
import k1.AbstractC0239g;

/* renamed from: n.z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0347z extends EditText implements P.r {

    /* renamed from: b, reason: collision with root package name */
    public final r f4630b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4631c;

    /* renamed from: d, reason: collision with root package name */
    public final C0295F f4632d;
    public final S.j e;

    /* renamed from: f, reason: collision with root package name */
    public final C0295F f4633f;

    /* renamed from: g, reason: collision with root package name */
    public C0345y f4634g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0347z(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.editTextStyle);
        Y0.a(context);
        X0.a(this, getContext());
        r rVar = new r(this);
        this.f4630b = rVar;
        rVar.k(attributeSet, R.attr.editTextStyle);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4631c = c0299a0;
        c0299a0.f(attributeSet, R.attr.editTextStyle);
        c0299a0.b();
        C0295F c0295f = new C0295F();
        c0295f.f4334b = this;
        this.f4632d = c0295f;
        this.e = new S.j();
        C0295F c0295f2 = new C0295F(this);
        this.f4633f = c0295f2;
        c0295f2.b(attributeSet, R.attr.editTextStyle);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = super.isFocusable();
        boolean zIsClickable = super.isClickable();
        boolean zIsLongClickable = super.isLongClickable();
        int inputType = super.getInputType();
        KeyListener keyListenerA = c0295f2.a(keyListener);
        if (keyListenerA == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerA);
        super.setRawInputType(inputType);
        super.setFocusable(zIsFocusable);
        super.setClickable(zIsClickable);
        super.setLongClickable(zIsLongClickable);
    }

    private C0345y getSuperCaller() {
        if (this.f4634g == null) {
            this.f4634g = new C0345y(this);
        }
        return this.f4634g;
    }

    @Override // P.r
    public final C0018f a(C0018f c0018f) {
        this.e.getClass();
        return S.j.a(this, c0018f);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4630b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4631c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4630b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4630b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4631c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4631c.e();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        C0295F c0295f;
        if (Build.VERSION.SDK_INT >= 28 || (c0295f = this.f4632d) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) c0295f.f4335c;
        return textClassifier == null ? V.a((TextView) c0295f.f4334b) : textClassifier;
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        String[] strArrG;
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f4631c.getClass();
        C0299a0.h(editorInfo, inputConnectionOnCreateInputConnection, this);
        AbstractC0239g.t(editorInfo, inputConnectionOnCreateInputConnection, this);
        if (inputConnectionOnCreateInputConnection != null && Build.VERSION.SDK_INT <= 30 && (strArrG = P.O.g(this)) != null) {
            editorInfo.contentMimeTypes = strArrG;
            inputConnectionOnCreateInputConnection = new R.b(inputConnectionOnCreateInputConnection, new R.a(this));
        }
        return this.f4633f.c(inputConnectionOnCreateInputConnection, editorInfo);
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30 || i >= 33) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onDragEvent(DragEvent dragEvent) {
        Activity activity;
        boolean zA = false;
        if (Build.VERSION.SDK_INT < 31 && dragEvent.getLocalState() == null && P.O.g(this) != null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                }
                if (context instanceof Activity) {
                    activity = (Activity) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (activity == null) {
                Log.i("ReceiveContent", "Can't handle drop: no activity: view=" + this);
            } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3) {
                zA = I.a(dragEvent, this, activity);
            }
        }
        if (zA) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public final boolean onTextContextMenuItem(int i) {
        InterfaceC0015c fVar;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 31 || P.O.g(this) == null || !(i == 16908322 || i == 16908337)) {
            return super.onTextContextMenuItem(i);
        }
        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
        ClipData primaryClip = clipboardManager == null ? null : clipboardManager.getPrimaryClip();
        if (primaryClip != null && primaryClip.getItemCount() > 0) {
            if (i3 >= 31) {
                fVar = new A0.f(primaryClip, 1);
            } else {
                C0016d c0016d = new C0016d();
                c0016d.f885c = primaryClip;
                c0016d.f886d = 1;
                fVar = c0016d;
            }
            fVar.q(i == 16908322 ? 0 : 1);
            P.O.i(this, fVar.i());
        }
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4630b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4630b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4631c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4631c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f4633f.d(z2);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f4633f.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4630b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4630b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4631c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4631c;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4631c;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        C0295F c0295f;
        if (Build.VERSION.SDK_INT >= 28 || (c0295f = this.f4632d) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            c0295f.f4335c = textClassifier;
        }
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }
}
