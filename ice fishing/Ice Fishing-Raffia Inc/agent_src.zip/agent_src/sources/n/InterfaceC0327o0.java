package n;

/* renamed from: n.o0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0327o0 {
}
