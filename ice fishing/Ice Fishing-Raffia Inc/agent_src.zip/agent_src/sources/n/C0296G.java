package n;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;
import com.kortosi.kluani.qorzanis.R;

/* renamed from: n.G, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0296G extends RadioButton implements S.k {

    /* renamed from: b, reason: collision with root package name */
    public final C0339v f4336b;

    /* renamed from: c, reason: collision with root package name */
    public final r f4337c;

    /* renamed from: d, reason: collision with root package name */
    public final C0299a0 f4338d;
    public C0290A e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0296G(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.radioButtonStyle);
        Y0.a(context);
        X0.a(this, getContext());
        C0339v c0339v = new C0339v(this);
        this.f4336b = c0339v;
        c0339v.c(attributeSet, R.attr.radioButtonStyle);
        r rVar = new r(this);
        this.f4337c = rVar;
        rVar.k(attributeSet, R.attr.radioButtonStyle);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4338d = c0299a0;
        c0299a0.f(attributeSet, R.attr.radioButtonStyle);
        getEmojiTextViewHelper().b(attributeSet, R.attr.radioButtonStyle);
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.e == null) {
            this.e = new C0290A(this);
        }
        return this.e;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4337c;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4338d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4337c;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4337c;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    @Override // S.k
    public ColorStateList getSupportButtonTintList() {
        C0339v c0339v = this.f4336b;
        if (c0339v != null) {
            return c0339v.f4603a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0339v c0339v = this.f4336b;
        if (c0339v != null) {
            return c0339v.f4604b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4338d.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4338d.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4337c;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4337c;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0339v c0339v = this.f4336b;
        if (c0339v != null) {
            if (c0339v.e) {
                c0339v.e = false;
            } else {
                c0339v.e = true;
                c0339v.a();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4338d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4338d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4337c;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4337c;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    @Override // S.k
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0339v c0339v = this.f4336b;
        if (c0339v != null) {
            c0339v.f4603a = colorStateList;
            c0339v.f4605c = true;
            c0339v.a();
        }
    }

    @Override // S.k
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0339v c0339v = this.f4336b;
        if (c0339v != null) {
            c0339v.f4604b = mode;
            c0339v.f4606d = true;
            c0339v.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4338d;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4338d;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(b1.e.A(getContext(), i));
    }
}
