package n;

/* loaded from: classes.dex */
public final class T0 {

    /* renamed from: a, reason: collision with root package name */
    public int f4403a;

    /* renamed from: b, reason: collision with root package name */
    public int f4404b;

    /* renamed from: c, reason: collision with root package name */
    public int f4405c;

    /* renamed from: d, reason: collision with root package name */
    public int f4406d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public int f4407f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f4408g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f4409h;

    public final void a(int i, int i3) {
        this.f4405c = i;
        this.f4406d = i3;
        this.f4409h = true;
        if (this.f4408g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f4403a = i3;
            }
            if (i != Integer.MIN_VALUE) {
                this.f4404b = i;
                return;
            }
            return;
        }
        if (i != Integer.MIN_VALUE) {
            this.f4403a = i;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f4404b = i3;
        }
    }
}
