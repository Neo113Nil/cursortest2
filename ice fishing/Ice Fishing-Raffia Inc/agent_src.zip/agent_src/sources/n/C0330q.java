package n;

import P.C0023k;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import k1.AbstractC0239g;

/* renamed from: n.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0330q extends AutoCompleteTextView {
    public static final int[] e = {R.attr.popupBackground};

    /* renamed from: b, reason: collision with root package name */
    public final r f4579b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4580c;

    /* renamed from: d, reason: collision with root package name */
    public final C0295F f4581d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0330q(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        Y0.a(context);
        X0.a(this, getContext());
        C0023k c0023kH = C0023k.h(getContext(), attributeSet, e, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) c0023kH.f913c).hasValue(0)) {
            setDropDownBackgroundDrawable(c0023kH.c(0));
        }
        c0023kH.j();
        r rVar = new r(this);
        this.f4579b = rVar;
        rVar.k(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4580c = c0299a0;
        c0299a0.f(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        c0299a0.b();
        C0295F c0295f = new C0295F(this);
        this.f4581d = c0295f;
        c0295f.b(attributeSet, com.kortosi.kluani.qorzanis.R.attr.autoCompleteTextViewStyle);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = super.isFocusable();
        boolean zIsClickable = super.isClickable();
        boolean zIsLongClickable = super.isLongClickable();
        int inputType = super.getInputType();
        KeyListener keyListenerA = c0295f.a(keyListener);
        if (keyListenerA == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerA);
        super.setRawInputType(inputType);
        super.setFocusable(zIsFocusable);
        super.setClickable(zIsClickable);
        super.setLongClickable(zIsLongClickable);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4579b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4580c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4579b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4579b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4580c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4580c.e();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        AbstractC0239g.t(editorInfo, inputConnectionOnCreateInputConnection, this);
        return this.f4581d.c(inputConnectionOnCreateInputConnection, editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4579b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4579b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4580c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4580c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(b1.e.A(getContext(), i));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f4581d.d(z2);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f4581d.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4579b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4579b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4580c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4580c;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4580c;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }
}
