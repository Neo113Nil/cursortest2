package n;

import android.R;
import android.graphics.Insets;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.lang.reflect.InvocationTargetException;

/* renamed from: n.r0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0332r0 {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f4587a = {R.attr.state_checked};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f4588b = new int[0];

    /* renamed from: c, reason: collision with root package name */
    public static final Rect f4589c = new Rect();

    public static void a(Drawable drawable) {
        String name = drawable.getClass().getName();
        int i = Build.VERSION.SDK_INT;
        if (i < 29 || i >= 31 || !"android.graphics.drawable.ColorStateListDrawable".equals(name)) {
            return;
        }
        int[] state = drawable.getState();
        if (state == null || state.length == 0) {
            drawable.setState(f4587a);
        } else {
            drawable.setState(f4588b);
        }
        drawable.setState(state);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Rect b(Drawable drawable) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            Insets insetsA = AbstractC0331q0.a(drawable);
            return new Rect(insetsA.left, insetsA.top, insetsA.right, insetsA.bottom);
        }
        boolean z2 = drawable instanceof I.b;
        Object obj = drawable;
        if (z2) {
            ((I.c) ((I.b) drawable)).getClass();
            obj = null;
        }
        if (i >= 29) {
            boolean z3 = AbstractC0329p0.f4574a;
        } else if (AbstractC0329p0.f4574a) {
            try {
                Object objInvoke = AbstractC0329p0.f4575b.invoke(obj, null);
                if (objInvoke != null) {
                    return new Rect(AbstractC0329p0.f4576c.getInt(objInvoke), AbstractC0329p0.f4577d.getInt(objInvoke), AbstractC0329p0.e.getInt(objInvoke), AbstractC0329p0.f4578f.getInt(objInvoke));
                }
            } catch (IllegalAccessException | InvocationTargetException unused) {
            }
        }
        return f4589c;
    }

    public static PorterDuff.Mode c(int i, PorterDuff.Mode mode) {
        if (i == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        switch (i) {
            case 14:
                return PorterDuff.Mode.MULTIPLY;
            case 15:
                return PorterDuff.Mode.SCREEN;
            case 16:
                return PorterDuff.Mode.ADD;
            default:
                return mode;
        }
    }
}
