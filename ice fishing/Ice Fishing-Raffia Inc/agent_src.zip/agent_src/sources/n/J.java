package n;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import com.kortosi.kluani.qorzanis.R;

/* loaded from: classes.dex */
public final class J extends SeekBar {

    /* renamed from: b, reason: collision with root package name */
    public final K f4344b;

    public J(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarStyle);
        X0.a(this, getContext());
        K k3 = new K(this);
        this.f4344b = k3;
        k3.b(attributeSet, R.attr.seekBarStyle);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        K k3 = this.f4344b;
        Drawable drawable = k3.f4346f;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        J j3 = k3.e;
        if (drawable.setState(j3.getDrawableState())) {
            j3.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f4344b.f4346f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f4344b.g(canvas);
    }
}
