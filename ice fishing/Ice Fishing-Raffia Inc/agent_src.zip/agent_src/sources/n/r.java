package n;

import P.C0023k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import g.AbstractC0131a;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p0.C0370a;

/* loaded from: classes.dex */
public final class r {

    /* renamed from: a, reason: collision with root package name */
    public int f4582a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f4583b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f4584c;

    /* renamed from: d, reason: collision with root package name */
    public Object f4585d;
    public Object e;

    /* renamed from: f, reason: collision with root package name */
    public Object f4586f;

    public r(View view) {
        this.f4582a = -1;
        this.f4583b = view;
        this.f4584c = C0343x.a();
    }

    public void a() {
        View view = (View) this.f4583b;
        Drawable background = view.getBackground();
        if (background != null) {
            if (((Z0) this.f4585d) != null) {
                if (((Z0) this.f4586f) == null) {
                    this.f4586f = new Z0();
                }
                Z0 z02 = (Z0) this.f4586f;
                z02.f4468a = null;
                z02.f4471d = false;
                z02.f4469b = null;
                z02.f4470c = false;
                WeakHashMap weakHashMap = P.O.f854a;
                ColorStateList colorStateListC = P.G.c(view);
                if (colorStateListC != null) {
                    z02.f4471d = true;
                    z02.f4468a = colorStateListC;
                }
                PorterDuff.Mode modeD = P.G.d(view);
                if (modeD != null) {
                    z02.f4470c = true;
                    z02.f4469b = modeD;
                }
                if (z02.f4471d || z02.f4470c) {
                    C0343x.e(background, z02, view.getDrawableState());
                    return;
                }
            }
            Z0 z03 = (Z0) this.e;
            if (z03 != null) {
                C0343x.e(background, z03, view.getDrawableState());
                return;
            }
            Z0 z04 = (Z0) this.f4585d;
            if (z04 != null) {
                C0343x.e(background, z04, view.getDrawableState());
            }
        }
    }

    public boolean b(int i) {
        ArrayList arrayList = (ArrayList) this.f4585d;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            C0370a c0370a = (C0370a) arrayList.get(i3);
            int i4 = c0370a.f4860a;
            if (i4 == 8) {
                if (g(c0370a.f4863d, i3 + 1) == i) {
                    return true;
                }
            } else if (i4 == 1) {
                int i5 = c0370a.f4861b;
                int i6 = c0370a.f4863d + i5;
                while (i5 < i6) {
                    if (g(i5, i3 + 1) == i) {
                        return true;
                    }
                    i5++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    public void c() {
        ArrayList arrayList = (ArrayList) this.f4585d;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((p0.K) this.e).a((C0370a) arrayList.get(i));
        }
        q(arrayList);
        this.f4582a = 0;
    }

    public void d() {
        c();
        ArrayList arrayList = (ArrayList) this.f4584c;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0370a c0370a = (C0370a) arrayList.get(i);
            int i3 = c0370a.f4860a;
            p0.K k3 = (p0.K) this.e;
            if (i3 == 1) {
                k3.a(c0370a);
                k3.d(c0370a.f4861b, c0370a.f4863d);
            } else if (i3 == 2) {
                k3.a(c0370a);
                int i4 = c0370a.f4861b;
                int i5 = c0370a.f4863d;
                RecyclerView recyclerView = k3.f4824b;
                recyclerView.S(i4, i5, true);
                recyclerView.f1924k0 = true;
                recyclerView.f1919h0.f4911c += i5;
            } else if (i3 == 4) {
                k3.a(c0370a);
                k3.c(c0370a.f4861b, c0370a.f4863d, c0370a.f4862c);
            } else if (i3 == 8) {
                k3.a(c0370a);
                k3.f(c0370a.f4861b, c0370a.f4863d);
            }
        }
        q(arrayList);
        this.f4582a = 0;
    }

    public void e(C0370a c0370a) {
        int i;
        O.b bVar;
        int i3 = c0370a.f4860a;
        if (i3 == 1 || i3 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int iU = u(c0370a.f4861b, i3);
        int i4 = c0370a.f4861b;
        int i5 = c0370a.f4860a;
        if (i5 == 2) {
            i = 0;
        } else {
            if (i5 != 4) {
                throw new IllegalArgumentException("op should be remove or update." + c0370a);
            }
            i = 1;
        }
        int i6 = 1;
        int i7 = 1;
        while (true) {
            int i8 = c0370a.f4863d;
            bVar = (O.b) this.f4583b;
            if (i6 >= i8) {
                break;
            }
            int iU2 = u((i * i6) + c0370a.f4861b, c0370a.f4860a);
            int i9 = c0370a.f4860a;
            if (i9 == 2 ? iU2 != iU : !(i9 == 4 && iU2 == iU + 1)) {
                C0370a c0370aL = l(c0370a.f4862c, i9, iU, i7);
                f(c0370aL, i4);
                c0370aL.f4862c = null;
                bVar.c(c0370aL);
                if (c0370a.f4860a == 4) {
                    i4 += i7;
                }
                i7 = 1;
                iU = iU2;
            } else {
                i7++;
            }
            i6++;
        }
        Object obj = c0370a.f4862c;
        c0370a.f4862c = null;
        bVar.c(c0370a);
        if (i7 > 0) {
            C0370a c0370aL2 = l(obj, c0370a.f4860a, iU, i7);
            f(c0370aL2, i4);
            c0370aL2.f4862c = null;
            bVar.c(c0370aL2);
        }
    }

    public void f(C0370a c0370a, int i) {
        p0.K k3 = (p0.K) this.e;
        k3.a(c0370a);
        int i3 = c0370a.f4860a;
        if (i3 != 2) {
            if (i3 != 4) {
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
            }
            k3.c(i, c0370a.f4863d, c0370a.f4862c);
        } else {
            int i4 = c0370a.f4863d;
            RecyclerView recyclerView = k3.f4824b;
            recyclerView.S(i, i4, true);
            recyclerView.f1924k0 = true;
            recyclerView.f1919h0.f4911c += i4;
        }
    }

    public int g(int i, int i3) {
        ArrayList arrayList = (ArrayList) this.f4585d;
        int size = arrayList.size();
        while (i3 < size) {
            C0370a c0370a = (C0370a) arrayList.get(i3);
            int i4 = c0370a.f4860a;
            if (i4 == 8) {
                int i5 = c0370a.f4861b;
                if (i5 == i) {
                    i = c0370a.f4863d;
                } else {
                    if (i5 < i) {
                        i--;
                    }
                    if (c0370a.f4863d <= i) {
                        i++;
                    }
                }
            } else {
                int i6 = c0370a.f4861b;
                if (i6 > i) {
                    continue;
                } else if (i4 == 2) {
                    int i7 = c0370a.f4863d;
                    if (i < i6 + i7) {
                        return -1;
                    }
                    i -= i7;
                } else if (i4 == 1) {
                    i += c0370a.f4863d;
                }
            }
            i3++;
        }
        return i;
    }

    public ColorStateList h() {
        Z0 z02 = (Z0) this.e;
        if (z02 != null) {
            return z02.f4468a;
        }
        return null;
    }

    public PorterDuff.Mode i() {
        Z0 z02 = (Z0) this.e;
        if (z02 != null) {
            return z02.f4469b;
        }
        return null;
    }

    public boolean j() {
        return ((ArrayList) this.f4584c).size() > 0;
    }

    public void k(AttributeSet attributeSet, int i) {
        ColorStateList colorStateListF;
        View view = (View) this.f4583b;
        Context context = view.getContext();
        int[] iArr = AbstractC0131a.f3062A;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, i);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        View view2 = (View) this.f4583b;
        P.O.l(view2, view2.getContext(), iArr, attributeSet, (TypedArray) c0023kH.f913c, i);
        try {
            if (typedArray.hasValue(0)) {
                this.f4582a = typedArray.getResourceId(0, -1);
                C0343x c0343x = (C0343x) this.f4584c;
                Context context2 = view.getContext();
                int i3 = this.f4582a;
                synchronized (c0343x) {
                    colorStateListF = c0343x.f4618a.f(context2, i3);
                }
                if (colorStateListF != null) {
                    r(colorStateListF);
                }
            }
            if (typedArray.hasValue(1)) {
                P.G.i(view, c0023kH.b(1));
            }
            if (typedArray.hasValue(2)) {
                P.G.j(view, AbstractC0332r0.c(typedArray.getInt(2, -1), null));
            }
        } finally {
            c0023kH.j();
        }
    }

    public C0370a l(Object obj, int i, int i3, int i4) {
        C0370a c0370a = (C0370a) ((O.b) this.f4583b).a();
        if (c0370a != null) {
            c0370a.f4860a = i;
            c0370a.f4861b = i3;
            c0370a.f4863d = i4;
            c0370a.f4862c = obj;
            return c0370a;
        }
        C0370a c0370a2 = new C0370a();
        c0370a2.f4860a = i;
        c0370a2.f4861b = i3;
        c0370a2.f4863d = i4;
        c0370a2.f4862c = obj;
        return c0370a2;
    }

    public void m() {
        this.f4582a = -1;
        r(null);
        a();
    }

    public void n(int i) {
        ColorStateList colorStateListF;
        this.f4582a = i;
        C0343x c0343x = (C0343x) this.f4584c;
        if (c0343x != null) {
            Context context = ((View) this.f4583b).getContext();
            synchronized (c0343x) {
                colorStateListF = c0343x.f4618a.f(context, i);
            }
        } else {
            colorStateListF = null;
        }
        r(colorStateListF);
        a();
    }

    public void o(C0370a c0370a) {
        ((ArrayList) this.f4585d).add(c0370a);
        int i = c0370a.f4860a;
        p0.K k3 = (p0.K) this.e;
        if (i == 1) {
            k3.d(c0370a.f4861b, c0370a.f4863d);
            return;
        }
        if (i == 2) {
            int i3 = c0370a.f4861b;
            int i4 = c0370a.f4863d;
            RecyclerView recyclerView = k3.f4824b;
            recyclerView.S(i3, i4, false);
            recyclerView.f1924k0 = true;
            return;
        }
        if (i == 4) {
            k3.c(c0370a.f4861b, c0370a.f4863d, c0370a.f4862c);
        } else if (i == 8) {
            k3.f(c0370a.f4861b, c0370a.f4863d);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + c0370a);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:184:0x00aa A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:185:0x0135 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:188:0x0121 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:202:0x000d A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0090  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00a5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void p() {
        char c3;
        int i;
        boolean z2;
        char c4;
        C0370a c0370aL;
        int i3;
        int i4;
        C0370a c0370aL2;
        boolean z3;
        boolean z4;
        C0370a c0370aL3;
        ArrayList arrayList = (ArrayList) this.f4584c;
        C0326o c0326o = (C0326o) this.f4586f;
        c0326o.getClass();
        while (true) {
            int size = arrayList.size() - 1;
            boolean z5 = false;
            while (true) {
                c3 = 65535;
                i = 8;
                if (size < 0) {
                    size = -1;
                    break;
                }
                if (((C0370a) arrayList.get(size)).f4860a != 8) {
                    z5 = true;
                } else if (z5) {
                    break;
                }
                size--;
            }
            if (size == -1) {
                break;
            }
            int i5 = size + 1;
            C0370a c0370a = (C0370a) arrayList.get(size);
            C0370a c0370a2 = (C0370a) arrayList.get(i5);
            int i6 = c0370a2.f4860a;
            if (i6 != 1) {
                r rVar = (r) c0326o.f4570c;
                if (i6 == 2) {
                    int i7 = c0370a.f4861b;
                    int i8 = c0370a.f4863d;
                    if (i7 < i8) {
                        z4 = c0370a2.f4861b == i7 && c0370a2.f4863d == i8 - i7;
                        z3 = false;
                    } else if (c0370a2.f4861b == i8 + 1 && c0370a2.f4863d == i7 - i8) {
                        z4 = true;
                        z3 = true;
                    } else {
                        z3 = true;
                        z4 = false;
                    }
                    int i9 = c0370a2.f4861b;
                    if (i8 < i9) {
                        c0370a2.f4861b = i9 - 1;
                    } else {
                        int i10 = c0370a2.f4863d;
                        if (i8 < i9 + i10) {
                            c0370a2.f4863d = i10 - 1;
                            c0370a.f4860a = 2;
                            c0370a.f4863d = 1;
                            if (c0370a2.f4863d == 0) {
                                arrayList.remove(i5);
                                rVar.getClass();
                                c0370a2.f4862c = null;
                                ((O.b) rVar.f4583b).c(c0370a2);
                            }
                        }
                    }
                    int i11 = c0370a.f4861b;
                    int i12 = c0370a2.f4861b;
                    if (i11 <= i12) {
                        c0370a2.f4861b = i12 + 1;
                    } else {
                        int i13 = i12 + c0370a2.f4863d;
                        if (i11 < i13) {
                            c0370aL3 = rVar.l(null, 2, i11 + 1, i13 - i11);
                            c0370a2.f4863d = c0370a.f4861b - c0370a2.f4861b;
                        }
                        if (z4) {
                            if (z3) {
                                if (c0370aL3 != null) {
                                    int i14 = c0370a.f4861b;
                                    if (i14 > c0370aL3.f4861b) {
                                        c0370a.f4861b = i14 - c0370aL3.f4863d;
                                    }
                                    int i15 = c0370a.f4863d;
                                    if (i15 > c0370aL3.f4861b) {
                                        c0370a.f4863d = i15 - c0370aL3.f4863d;
                                    }
                                }
                                int i16 = c0370a.f4861b;
                                if (i16 > c0370a2.f4861b) {
                                    c0370a.f4861b = i16 - c0370a2.f4863d;
                                }
                                int i17 = c0370a.f4863d;
                                if (i17 > c0370a2.f4861b) {
                                    c0370a.f4863d = i17 - c0370a2.f4863d;
                                }
                            } else {
                                if (c0370aL3 != null) {
                                    int i18 = c0370a.f4861b;
                                    if (i18 >= c0370aL3.f4861b) {
                                        c0370a.f4861b = i18 - c0370aL3.f4863d;
                                    }
                                    int i19 = c0370a.f4863d;
                                    if (i19 >= c0370aL3.f4861b) {
                                        c0370a.f4863d = i19 - c0370aL3.f4863d;
                                    }
                                }
                                int i20 = c0370a.f4861b;
                                if (i20 >= c0370a2.f4861b) {
                                    c0370a.f4861b = i20 - c0370a2.f4863d;
                                }
                                int i21 = c0370a.f4863d;
                                if (i21 >= c0370a2.f4861b) {
                                    c0370a.f4863d = i21 - c0370a2.f4863d;
                                }
                            }
                            arrayList.set(size, c0370a2);
                            if (c0370a.f4861b != c0370a.f4863d) {
                                arrayList.set(i5, c0370a);
                            } else {
                                arrayList.remove(i5);
                            }
                            if (c0370aL3 != null) {
                                arrayList.add(size, c0370aL3);
                            }
                        } else {
                            arrayList.set(size, c0370a2);
                            arrayList.remove(i5);
                            rVar.getClass();
                            c0370a.f4862c = null;
                            ((O.b) rVar.f4583b).c(c0370a);
                        }
                    }
                    c0370aL3 = null;
                    if (z4) {
                    }
                } else if (i6 == 4) {
                    int i22 = c0370a.f4863d;
                    int i23 = c0370a2.f4861b;
                    if (i22 < i23) {
                        c0370a2.f4861b = i23 - 1;
                    } else {
                        int i24 = c0370a2.f4863d;
                        if (i22 < i23 + i24) {
                            c0370a2.f4863d = i24 - 1;
                            c0370aL = rVar.l(c0370a2.f4862c, 4, c0370a.f4861b, 1);
                        }
                        i3 = c0370a.f4861b;
                        i4 = c0370a2.f4861b;
                        if (i3 > i4) {
                            c0370a2.f4861b = i4 + 1;
                        } else {
                            int i25 = i4 + c0370a2.f4863d;
                            if (i3 < i25) {
                                int i26 = i25 - i3;
                                c0370aL2 = rVar.l(c0370a2.f4862c, 4, i3 + 1, i26);
                                c0370a2.f4863d -= i26;
                            }
                            arrayList.set(i5, c0370a);
                            if (c0370a2.f4863d > 0) {
                                arrayList.set(size, c0370a2);
                            } else {
                                arrayList.remove(size);
                                rVar.getClass();
                                c0370a2.f4862c = null;
                                ((O.b) rVar.f4583b).c(c0370a2);
                            }
                            if (c0370aL != null) {
                                arrayList.add(size, c0370aL);
                            }
                            if (c0370aL2 != null) {
                                arrayList.add(size, c0370aL2);
                            }
                        }
                        c0370aL2 = null;
                        arrayList.set(i5, c0370a);
                        if (c0370a2.f4863d > 0) {
                        }
                        if (c0370aL != null) {
                        }
                        if (c0370aL2 != null) {
                        }
                    }
                    c0370aL = null;
                    i3 = c0370a.f4861b;
                    i4 = c0370a2.f4861b;
                    if (i3 > i4) {
                    }
                    c0370aL2 = null;
                    arrayList.set(i5, c0370a);
                    if (c0370a2.f4863d > 0) {
                    }
                    if (c0370aL != null) {
                    }
                    if (c0370aL2 != null) {
                    }
                }
            } else {
                int i27 = c0370a.f4863d;
                int i28 = c0370a2.f4861b;
                int i29 = i27 < i28 ? -1 : 0;
                int i30 = c0370a.f4861b;
                if (i30 < i28) {
                    i29++;
                }
                if (i28 <= i30) {
                    c0370a.f4861b = i30 + c0370a2.f4863d;
                }
                int i31 = c0370a2.f4861b;
                if (i31 <= i27) {
                    c0370a.f4863d = i27 + c0370a2.f4863d;
                }
                c0370a2.f4861b = i31 + i29;
                arrayList.set(size, c0370a2);
                arrayList.set(i5, c0370a);
            }
        }
        int size2 = arrayList.size();
        int i32 = 0;
        while (i32 < size2) {
            C0370a c0370aL4 = (C0370a) arrayList.get(i32);
            int i33 = c0370aL4.f4860a;
            if (i33 != 1) {
                O.b bVar = (O.b) this.f4583b;
                p0.K k3 = (p0.K) this.e;
                if (i33 == 2) {
                    int i34 = c0370aL4.f4861b;
                    int i35 = c0370aL4.f4863d + i34;
                    int i36 = i34;
                    int i37 = 0;
                    char c5 = 65535;
                    while (i36 < i35) {
                        if (k3.b(i36) != null || b(i36)) {
                            if (c5 == 0) {
                                e(l(null, 2, i34, i37));
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            c4 = 1;
                        } else {
                            if (c5 == 1) {
                                o(l(null, 2, i34, i37));
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            c4 = 0;
                        }
                        if (z2) {
                            i36 -= i37;
                            i35 -= i37;
                            i37 = 1;
                        } else {
                            i37++;
                        }
                        i36++;
                        c5 = c4;
                    }
                    if (i37 != c0370aL4.f4863d) {
                        c0370aL4.f4862c = null;
                        bVar.c(c0370aL4);
                        c0370aL4 = l(null, 2, i34, i37);
                    }
                    if (c5 == 0) {
                        e(c0370aL4);
                    } else {
                        o(c0370aL4);
                    }
                } else if (i33 == 4) {
                    int i38 = c0370aL4.f4861b;
                    int i39 = c0370aL4.f4863d + i38;
                    char c6 = c3;
                    int i40 = i38;
                    int i41 = 0;
                    while (i38 < i39) {
                        if (k3.b(i38) != null || b(i38)) {
                            if (c6 == 0) {
                                e(l(c0370aL4.f4862c, 4, i40, i41));
                                i40 = i38;
                                i41 = 0;
                            }
                            c6 = 1;
                        } else {
                            if (c6 == 1) {
                                o(l(c0370aL4.f4862c, 4, i40, i41));
                                i40 = i38;
                                i41 = 0;
                            }
                            c6 = 0;
                        }
                        i41++;
                        i38++;
                    }
                    if (i41 != c0370aL4.f4863d) {
                        Object obj = c0370aL4.f4862c;
                        c0370aL4.f4862c = null;
                        bVar.c(c0370aL4);
                        c0370aL4 = l(obj, 4, i40, i41);
                    }
                    if (c6 == 0) {
                        e(c0370aL4);
                    } else {
                        o(c0370aL4);
                    }
                } else if (i33 == i) {
                    o(c0370aL4);
                }
            } else {
                o(c0370aL4);
            }
            i32++;
            c3 = 65535;
            i = 8;
        }
        arrayList.clear();
    }

    public void q(ArrayList arrayList) {
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0370a c0370a = (C0370a) arrayList.get(i);
            c0370a.f4862c = null;
            ((O.b) this.f4583b).c(c0370a);
        }
        arrayList.clear();
    }

    public void r(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (((Z0) this.f4585d) == null) {
                this.f4585d = new Z0();
            }
            Z0 z02 = (Z0) this.f4585d;
            z02.f4468a = colorStateList;
            z02.f4471d = true;
        } else {
            this.f4585d = null;
        }
        a();
    }

    public void s(ColorStateList colorStateList) {
        if (((Z0) this.e) == null) {
            this.e = new Z0();
        }
        Z0 z02 = (Z0) this.e;
        z02.f4468a = colorStateList;
        z02.f4471d = true;
        a();
    }

    public void t(PorterDuff.Mode mode) {
        if (((Z0) this.e) == null) {
            this.e = new Z0();
        }
        Z0 z02 = (Z0) this.e;
        z02.f4469b = mode;
        z02.f4470c = true;
        a();
    }

    public int u(int i, int i3) {
        int i4;
        int i5;
        ArrayList arrayList = (ArrayList) this.f4585d;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            C0370a c0370a = (C0370a) arrayList.get(size);
            int i6 = c0370a.f4860a;
            if (i6 == 8) {
                int i7 = c0370a.f4861b;
                int i8 = c0370a.f4863d;
                if (i7 < i8) {
                    i5 = i7;
                    i4 = i8;
                } else {
                    i4 = i7;
                    i5 = i8;
                }
                if (i < i5 || i > i4) {
                    if (i < i7) {
                        if (i3 == 1) {
                            c0370a.f4861b = i7 + 1;
                            c0370a.f4863d = i8 + 1;
                        } else if (i3 == 2) {
                            c0370a.f4861b = i7 - 1;
                            c0370a.f4863d = i8 - 1;
                        }
                    }
                } else if (i5 == i7) {
                    if (i3 == 1) {
                        c0370a.f4863d = i8 + 1;
                    } else if (i3 == 2) {
                        c0370a.f4863d = i8 - 1;
                    }
                    i++;
                } else {
                    if (i3 == 1) {
                        c0370a.f4861b = i7 + 1;
                    } else if (i3 == 2) {
                        c0370a.f4861b = i7 - 1;
                    }
                    i--;
                }
            } else {
                int i9 = c0370a.f4861b;
                if (i9 <= i) {
                    if (i6 == 1) {
                        i -= c0370a.f4863d;
                    } else if (i6 == 2) {
                        i += c0370a.f4863d;
                    }
                } else if (i3 == 1) {
                    c0370a.f4861b = i9 + 1;
                } else if (i3 == 2) {
                    c0370a.f4861b = i9 - 1;
                }
            }
        }
        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
            C0370a c0370a2 = (C0370a) arrayList.get(size2);
            int i10 = c0370a2.f4860a;
            O.b bVar = (O.b) this.f4583b;
            if (i10 == 8) {
                int i11 = c0370a2.f4863d;
                if (i11 == c0370a2.f4861b || i11 < 0) {
                    arrayList.remove(size2);
                    c0370a2.f4862c = null;
                    bVar.c(c0370a2);
                }
            } else if (c0370a2.f4863d <= 0) {
                arrayList.remove(size2);
                c0370a2.f4862c = null;
                bVar.c(c0370a2);
            }
        }
        return i;
    }

    public r(p0.K k3) {
        this.f4583b = new O.b(30);
        this.f4584c = new ArrayList();
        this.f4585d = new ArrayList();
        this.f4582a = 0;
        this.e = k3;
        this.f4586f = new C0326o(7, this);
    }
}
