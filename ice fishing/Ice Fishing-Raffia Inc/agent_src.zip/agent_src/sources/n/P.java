package n;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;

/* loaded from: classes.dex */
public final class P implements PopupWindow.OnDismissListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z0.c f4387b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Q f4388c;

    public P(Q q2, Z0.c cVar) {
        this.f4388c = q2;
        this.f4387b = cVar;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.f4388c.f4394H.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f4387b);
        }
    }
}
