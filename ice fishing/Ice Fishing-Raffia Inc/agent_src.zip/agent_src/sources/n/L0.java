package n;

import m.C0287n;
import m.MenuC0285l;

/* loaded from: classes.dex */
public interface L0 {
    void j(MenuC0285l menuC0285l, C0287n c0287n);

    void n(MenuC0285l menuC0285l, C0287n c0287n);
}
