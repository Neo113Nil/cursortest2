package n;

import android.view.Window;

/* renamed from: n.n0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0325n0 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
