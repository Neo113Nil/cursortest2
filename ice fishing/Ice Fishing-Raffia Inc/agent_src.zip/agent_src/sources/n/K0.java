package n;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import g.AbstractC0131a;
import java.lang.reflect.Method;
import m.InterfaceC0271B;

/* loaded from: classes.dex */
public class K0 implements InterfaceC0271B {

    /* renamed from: B, reason: collision with root package name */
    public static final Method f4350B;

    /* renamed from: C, reason: collision with root package name */
    public static final Method f4351C;

    /* renamed from: A, reason: collision with root package name */
    public final C0294E f4352A;

    /* renamed from: b, reason: collision with root package name */
    public final Context f4353b;

    /* renamed from: c, reason: collision with root package name */
    public ListAdapter f4354c;

    /* renamed from: d, reason: collision with root package name */
    public C0344x0 f4355d;

    /* renamed from: g, reason: collision with root package name */
    public int f4357g;

    /* renamed from: h, reason: collision with root package name */
    public int f4358h;

    /* renamed from: j, reason: collision with root package name */
    public boolean f4359j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f4360k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f4361l;

    /* renamed from: o, reason: collision with root package name */
    public H0 f4364o;

    /* renamed from: p, reason: collision with root package name */
    public View f4365p;

    /* renamed from: q, reason: collision with root package name */
    public AdapterView.OnItemClickListener f4366q;

    /* renamed from: r, reason: collision with root package name */
    public AdapterView.OnItemSelectedListener f4367r;

    /* renamed from: w, reason: collision with root package name */
    public final Handler f4372w;

    /* renamed from: y, reason: collision with root package name */
    public Rect f4374y;

    /* renamed from: z, reason: collision with root package name */
    public boolean f4375z;
    public final int e = -2;

    /* renamed from: f, reason: collision with root package name */
    public int f4356f = -2;
    public final int i = 1002;

    /* renamed from: m, reason: collision with root package name */
    public int f4362m = 0;

    /* renamed from: n, reason: collision with root package name */
    public final int f4363n = Integer.MAX_VALUE;

    /* renamed from: s, reason: collision with root package name */
    public final G0 f4368s = new G0(this, 1);

    /* renamed from: t, reason: collision with root package name */
    public final J0 f4369t = new J0(this);

    /* renamed from: u, reason: collision with root package name */
    public final I0 f4370u = new I0(this);

    /* renamed from: v, reason: collision with root package name */
    public final G0 f4371v = new G0(this, 0);

    /* renamed from: x, reason: collision with root package name */
    public final Rect f4373x = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f4350B = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f4351C = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    public K0(Context context, AttributeSet attributeSet, int i) {
        int resourceId;
        this.f4353b = context;
        this.f4372w = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3077p, i, 0);
        this.f4357g = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f4358h = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f4359j = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        C0294E c0294e = new C0294E(context, attributeSet, i, 0);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3081t, i, 0);
        if (typedArrayObtainStyledAttributes2.hasValue(2)) {
            c0294e.setOverlapAnchor(typedArrayObtainStyledAttributes2.getBoolean(2, false));
        }
        c0294e.setBackgroundDrawable((!typedArrayObtainStyledAttributes2.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes2.getDrawable(0) : b1.e.A(context, resourceId));
        typedArrayObtainStyledAttributes2.recycle();
        this.f4352A = c0294e;
        c0294e.setInputMethodMode(1);
    }

    @Override // m.InterfaceC0271B
    public final boolean a() {
        return this.f4352A.isShowing();
    }

    public final void c(int i) {
        this.f4357g = i;
    }

    public final int d() {
        return this.f4357g;
    }

    @Override // m.InterfaceC0271B
    public final void dismiss() {
        C0294E c0294e = this.f4352A;
        c0294e.dismiss();
        c0294e.setContentView(null);
        this.f4355d = null;
        this.f4372w.removeCallbacks(this.f4368s);
    }

    @Override // m.InterfaceC0271B
    public final C0344x0 e() {
        return this.f4355d;
    }

    @Override // m.InterfaceC0271B
    public final void h() {
        int i;
        int paddingBottom;
        C0344x0 c0344x0;
        C0344x0 c0344x02 = this.f4355d;
        C0294E c0294e = this.f4352A;
        Context context = this.f4353b;
        if (c0344x02 == null) {
            C0344x0 c0344x0Q = q(context, !this.f4375z);
            this.f4355d = c0344x0Q;
            c0344x0Q.setAdapter(this.f4354c);
            this.f4355d.setOnItemClickListener(this.f4366q);
            this.f4355d.setFocusable(true);
            this.f4355d.setFocusableInTouchMode(true);
            this.f4355d.setOnItemSelectedListener(new D0(this));
            this.f4355d.setOnScrollListener(this.f4370u);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f4367r;
            if (onItemSelectedListener != null) {
                this.f4355d.setOnItemSelectedListener(onItemSelectedListener);
            }
            c0294e.setContentView(this.f4355d);
        }
        Drawable background = c0294e.getBackground();
        Rect rect = this.f4373x;
        if (background != null) {
            background.getPadding(rect);
            int i3 = rect.top;
            i = rect.bottom + i3;
            if (!this.f4359j) {
                this.f4358h = -i3;
            }
        } else {
            rect.setEmpty();
            i = 0;
        }
        int iA = E0.a(c0294e, this.f4365p, this.f4358h, c0294e.getInputMethodMode() == 2);
        int i4 = this.e;
        if (i4 == -1) {
            paddingBottom = iA + i;
        } else {
            int i5 = this.f4356f;
            int iA2 = this.f4355d.a(i5 != -2 ? i5 != -1 ? View.MeasureSpec.makeMeasureSpec(i5, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.f4355d.getPaddingBottom() + this.f4355d.getPaddingTop() + i : 0);
        }
        boolean z2 = this.f4352A.getInputMethodMode() == 2;
        c0294e.setWindowLayoutType(this.i);
        if (c0294e.isShowing()) {
            if (this.f4365p.isAttachedToWindow()) {
                int width = this.f4356f;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.f4365p.getWidth();
                }
                if (i4 == -1) {
                    i4 = z2 ? paddingBottom : -1;
                    if (z2) {
                        c0294e.setWidth(this.f4356f == -1 ? -1 : 0);
                        c0294e.setHeight(0);
                    } else {
                        c0294e.setWidth(this.f4356f == -1 ? -1 : 0);
                        c0294e.setHeight(-1);
                    }
                } else if (i4 == -2) {
                    i4 = paddingBottom;
                }
                c0294e.setOutsideTouchable(true);
                View view = this.f4365p;
                int i6 = this.f4357g;
                int i7 = this.f4358h;
                if (width < 0) {
                    width = -1;
                }
                c0294e.update(view, i6, i7, width, i4 < 0 ? -1 : i4);
                return;
            }
            return;
        }
        int width2 = this.f4356f;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.f4365p.getWidth();
        }
        if (i4 == -1) {
            i4 = -1;
        } else if (i4 == -2) {
            i4 = paddingBottom;
        }
        c0294e.setWidth(width2);
        c0294e.setHeight(i4);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f4350B;
            if (method != null) {
                try {
                    method.invoke(c0294e, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            F0.b(c0294e, true);
        }
        c0294e.setOutsideTouchable(true);
        c0294e.setTouchInterceptor(this.f4369t);
        if (this.f4361l) {
            c0294e.setOverlapAnchor(this.f4360k);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f4351C;
            if (method2 != null) {
                try {
                    method2.invoke(c0294e, this.f4374y);
                } catch (Exception e) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
        } else {
            F0.a(c0294e, this.f4374y);
        }
        c0294e.showAsDropDown(this.f4365p, this.f4357g, this.f4358h, this.f4362m);
        this.f4355d.setSelection(-1);
        if ((!this.f4375z || this.f4355d.isInTouchMode()) && (c0344x0 = this.f4355d) != null) {
            c0344x0.setListSelectionHidden(true);
            c0344x0.requestLayout();
        }
        if (this.f4375z) {
            return;
        }
        this.f4372w.post(this.f4371v);
    }

    public final int i() {
        if (this.f4359j) {
            return this.f4358h;
        }
        return 0;
    }

    public final void k(Drawable drawable) {
        this.f4352A.setBackgroundDrawable(drawable);
    }

    public final void l(int i) {
        this.f4358h = i;
        this.f4359j = true;
    }

    public final Drawable m() {
        return this.f4352A.getBackground();
    }

    public void o(ListAdapter listAdapter) {
        H0 h02 = this.f4364o;
        if (h02 == null) {
            this.f4364o = new H0(this);
        } else {
            ListAdapter listAdapter2 = this.f4354c;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(h02);
            }
        }
        this.f4354c = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f4364o);
        }
        C0344x0 c0344x0 = this.f4355d;
        if (c0344x0 != null) {
            c0344x0.setAdapter(this.f4354c);
        }
    }

    public C0344x0 q(Context context, boolean z2) {
        return new C0344x0(context, z2);
    }

    public final void r(int i) {
        Drawable background = this.f4352A.getBackground();
        if (background == null) {
            this.f4356f = i;
            return;
        }
        Rect rect = this.f4373x;
        background.getPadding(rect);
        this.f4356f = rect.left + rect.right + i;
    }
}
