package n;

import android.content.Context;
import android.view.View;
import com.kortosi.kluani.qorzanis.R;
import m.MenuC0285l;
import m.SubMenuC0273D;

/* renamed from: n.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0310g extends m.v {

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4504l = 0;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0320l f4505m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0310g(C0320l c0320l, Context context, MenuC0285l menuC0285l, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, menuC0285l, true);
        this.f4505m = c0320l;
        this.f4272f = 8388613;
        A0.f fVar = c0320l.f4558y;
        this.f4274h = fVar;
        m.t tVar = this.i;
        if (tVar != null) {
            tVar.i(fVar);
        }
    }

    @Override // m.v
    public final void c() {
        switch (this.f4504l) {
            case 0:
                C0320l c0320l = this.f4505m;
                c0320l.f4555v = null;
                c0320l.f4559z = 0;
                super.c();
                break;
            default:
                C0320l c0320l2 = this.f4505m;
                MenuC0285l menuC0285l = c0320l2.f4539d;
                if (menuC0285l != null) {
                    menuC0285l.c(true);
                }
                c0320l2.f4554u = null;
                super.c();
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0310g(C0320l c0320l, Context context, SubMenuC0273D subMenuC0273D, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, subMenuC0273D, false);
        this.f4505m = c0320l;
        if (!subMenuC0273D.f4143A.f()) {
            View view2 = c0320l.f4544k;
            this.e = view2 == null ? (View) c0320l.i : view2;
        }
        A0.f fVar = c0320l.f4558y;
        this.f4274h = fVar;
        m.t tVar = this.i;
        if (tVar != null) {
            tVar.i(fVar);
        }
    }
}
