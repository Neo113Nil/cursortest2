package n;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import com.kortosi.kluani.qorzanis.R;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import s.AbstractC0438i;
import s.C0437h;
import s.C0440k;
import t.AbstractC0452a;

/* loaded from: classes.dex */
public final class R0 {

    /* renamed from: g, reason: collision with root package name */
    public static R0 f4396g;

    /* renamed from: a, reason: collision with root package name */
    public WeakHashMap f4398a;

    /* renamed from: b, reason: collision with root package name */
    public final WeakHashMap f4399b = new WeakHashMap(0);

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f4400c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4401d;
    public C0341w e;

    /* renamed from: f, reason: collision with root package name */
    public static final PorterDuff.Mode f4395f = PorterDuff.Mode.SRC_IN;

    /* renamed from: h, reason: collision with root package name */
    public static final Q0 f4397h = new Q0(6);

    public static synchronized R0 b() {
        try {
            if (f4396g == null) {
                f4396g = new R0();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f4396g;
    }

    public static synchronized PorterDuffColorFilter e(int i, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        Q0 q02 = f4397h;
        q02.getClass();
        int i3 = (31 + i) * 31;
        porterDuffColorFilter = (PorterDuffColorFilter) q02.f(Integer.valueOf(mode.hashCode() + i3));
        if (porterDuffColorFilter == null) {
            porterDuffColorFilter = new PorterDuffColorFilter(i, mode);
        }
        return porterDuffColorFilter;
    }

    public final Drawable a(Context context, int i) throws Resources.NotFoundException {
        Drawable drawableNewDrawable;
        WeakReference weakReference;
        if (this.f4400c == null) {
            this.f4400c = new TypedValue();
        }
        TypedValue typedValue = this.f4400c;
        context.getResources().getValue(i, typedValue, true);
        long j3 = (typedValue.assetCookie << 32) | typedValue.data;
        synchronized (this) {
            C0437h c0437h = (C0437h) this.f4399b.get(context);
            drawableNewDrawable = null;
            if (c0437h != null && (weakReference = (WeakReference) c0437h.b(j3)) != null) {
                Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
                if (constantState != null) {
                    drawableNewDrawable = constantState.newDrawable(context.getResources());
                } else {
                    int iB = AbstractC0452a.b(c0437h.f5427c, c0437h.e, j3);
                    if (iB >= 0) {
                        Object[] objArr = c0437h.f5428d;
                        Object obj = objArr[iB];
                        Object obj2 = AbstractC0438i.f5429a;
                        if (obj != obj2) {
                            objArr[iB] = obj2;
                            c0437h.f5426b = true;
                        }
                    }
                }
            }
        }
        if (drawableNewDrawable != null) {
            return drawableNewDrawable;
        }
        LayerDrawable layerDrawableC = null;
        if (this.e != null) {
            if (i == R.drawable.abc_cab_background_top_material) {
                layerDrawableC = new LayerDrawable(new Drawable[]{c(context, R.drawable.abc_cab_background_internal_bg), c(context, 2131165242)});
            } else if (i == R.drawable.abc_ratingbar_material) {
                layerDrawableC = C0341w.c(this, context, R.dimen.abc_star_big);
            } else if (i == R.drawable.abc_ratingbar_indicator_material) {
                layerDrawableC = C0341w.c(this, context, R.dimen.abc_star_medium);
            } else if (i == R.drawable.abc_ratingbar_small_material) {
                layerDrawableC = C0341w.c(this, context, R.dimen.abc_star_small);
            }
        }
        if (layerDrawableC != null) {
            layerDrawableC.setChangingConfigurations(typedValue.changingConfigurations);
            synchronized (this) {
                try {
                    Drawable.ConstantState constantState2 = layerDrawableC.getConstantState();
                    if (constantState2 != null) {
                        C0437h c0437h2 = (C0437h) this.f4399b.get(context);
                        if (c0437h2 == null) {
                            c0437h2 = new C0437h();
                            this.f4399b.put(context, c0437h2);
                        }
                        c0437h2.d(j3, new WeakReference(constantState2));
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return layerDrawableC;
    }

    public final synchronized Drawable c(Context context, int i) {
        return d(context, i, false);
    }

    public final synchronized Drawable d(Context context, int i, boolean z2) {
        Drawable drawableA;
        try {
            if (!this.f4401d) {
                this.f4401d = true;
                Drawable drawableC = c(context, R.drawable.abc_vector_test);
                if (drawableC == null || (!(drawableC instanceof F0.p) && !"android.graphics.drawable.VectorDrawable".equals(drawableC.getClass().getName()))) {
                    this.f4401d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            drawableA = a(context, i);
            if (drawableA == null) {
                drawableA = context.getDrawable(i);
            }
            if (drawableA != null) {
                drawableA = g(context, i, z2, drawableA);
            }
            if (drawableA != null) {
                AbstractC0332r0.a(drawableA);
            }
        } catch (Throwable th) {
            throw th;
        }
        return drawableA;
    }

    public final synchronized ColorStateList f(Context context, int i) {
        ColorStateList colorStateList;
        C0440k c0440k;
        WeakHashMap weakHashMap = this.f4398a;
        ColorStateList colorStateListD = null;
        colorStateList = (weakHashMap == null || (c0440k = (C0440k) weakHashMap.get(context)) == null) ? null : (ColorStateList) c0440k.b(i);
        if (colorStateList == null) {
            C0341w c0341w = this.e;
            if (c0341w != null) {
                colorStateListD = c0341w.d(context, i);
            }
            if (colorStateListD != null) {
                if (this.f4398a == null) {
                    this.f4398a = new WeakHashMap();
                }
                C0440k c0440k2 = (C0440k) this.f4398a.get(context);
                if (c0440k2 == null) {
                    c0440k2 = new C0440k(0);
                    this.f4398a.put(context, c0440k2);
                }
                c0440k2.a(i, colorStateListD);
            }
            colorStateList = colorStateListD;
        }
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00e8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Drawable g(Context context, int i, boolean z2, Drawable drawable) {
        int i3;
        boolean z3;
        int iRound;
        ColorStateList colorStateListF = f(context, i);
        PorterDuff.Mode mode = null;
        if (colorStateListF != null) {
            Drawable drawableMutate = drawable.mutate();
            drawableMutate.setTintList(colorStateListF);
            if (this.e != null && i == R.drawable.abc_switch_thumb_material) {
                mode = PorterDuff.Mode.MULTIPLY;
            }
            if (mode == null) {
                return drawableMutate;
            }
            drawableMutate.setTintMode(mode);
            return drawableMutate;
        }
        if (this.e != null) {
            if (i == R.drawable.abc_seekbar_track_material) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable drawableFindDrawableByLayerId = layerDrawable.findDrawableByLayerId(android.R.id.background);
                int iC = X0.c(context, R.attr.colorControlNormal);
                PorterDuff.Mode mode2 = C0343x.f4616b;
                C0341w.e(drawableFindDrawableByLayerId, iC, mode2);
                C0341w.e(layerDrawable.findDrawableByLayerId(android.R.id.secondaryProgress), X0.c(context, R.attr.colorControlNormal), mode2);
                C0341w.e(layerDrawable.findDrawableByLayerId(android.R.id.progress), X0.c(context, R.attr.colorControlActivated), mode2);
                return drawable;
            }
            if (i == R.drawable.abc_ratingbar_material || i == R.drawable.abc_ratingbar_indicator_material || i == R.drawable.abc_ratingbar_small_material) {
                LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
                Drawable drawableFindDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(android.R.id.background);
                int iB = X0.b(context, R.attr.colorControlNormal);
                PorterDuff.Mode mode3 = C0343x.f4616b;
                C0341w.e(drawableFindDrawableByLayerId2, iB, mode3);
                C0341w.e(layerDrawable2.findDrawableByLayerId(android.R.id.secondaryProgress), X0.c(context, R.attr.colorControlActivated), mode3);
                C0341w.e(layerDrawable2.findDrawableByLayerId(android.R.id.progress), X0.c(context, R.attr.colorControlActivated), mode3);
                return drawable;
            }
        }
        C0341w c0341w = this.e;
        boolean z4 = false;
        if (c0341w != null) {
            PorterDuff.Mode mode4 = C0343x.f4616b;
            if (C0341w.a(c0341w.f4610a, i)) {
                i3 = R.attr.colorControlNormal;
            } else if (C0341w.a(c0341w.f4612c, i)) {
                i3 = R.attr.colorControlActivated;
            } else {
                if (C0341w.a(c0341w.f4613d, i)) {
                    mode4 = PorterDuff.Mode.MULTIPLY;
                } else if (i == 2131165262) {
                    z3 = true;
                    iRound = Math.round(40.8f);
                    i3 = 16842800;
                    if (z3) {
                        Drawable drawableMutate2 = drawable.mutate();
                        drawableMutate2.setColorFilter(C0343x.c(X0.c(context, i3), mode4));
                        if (iRound != -1) {
                            drawableMutate2.setAlpha(iRound);
                        }
                        z4 = true;
                    }
                } else if (i != R.drawable.abc_dialog_material_background) {
                    i3 = 0;
                    z3 = false;
                    iRound = -1;
                    if (z3) {
                    }
                }
                i3 = 16842801;
            }
            z3 = true;
            iRound = -1;
            if (z3) {
            }
        }
        if (z4 || !z2) {
            return drawable;
        }
        return null;
    }
}
