package n;

import m.AbstractC0276c;

/* renamed from: n.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0312h extends AbstractC0276c {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0320l f4506a;

    public C0312h(C0320l c0320l) {
        this.f4506a = c0320l;
    }
}
