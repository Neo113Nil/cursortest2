package n;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class h1 extends U.b {
    public static final Parcelable.Creator<h1> CREATOR = new C.h(10);

    /* renamed from: d, reason: collision with root package name */
    public int f4507d;
    public boolean e;

    public h1(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f4507d = parcel.readInt();
        this.e = parcel.readInt() != 0;
    }

    @Override // U.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeInt(this.f4507d);
        parcel.writeInt(this.e ? 1 : 0);
    }
}
