package n;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: classes.dex */
public final class Z0 {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f4468a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f4469b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f4470c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4471d;
}
