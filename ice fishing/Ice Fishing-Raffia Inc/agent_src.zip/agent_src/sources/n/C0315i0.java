package n;

import android.text.StaticLayout;
import android.widget.TextView;

/* renamed from: n.i0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0315i0 extends C0311g0 {
    @Override // n.C0311g0, n.AbstractC0317j0
    public void a(StaticLayout.Builder builder, TextView textView) {
        builder.setTextDirection(textView.getTextDirectionHeuristic());
    }

    @Override // n.AbstractC0317j0
    public boolean b(TextView textView) {
        return textView.isHorizontallyScrollable();
    }
}
