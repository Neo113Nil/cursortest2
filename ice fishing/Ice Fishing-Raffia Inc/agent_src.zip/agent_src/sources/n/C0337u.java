package n;

import P.C0023k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;
import k1.AbstractC0239g;

/* renamed from: n.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0337u extends CheckedTextView {

    /* renamed from: b, reason: collision with root package name */
    public final C0339v f4600b;

    /* renamed from: c, reason: collision with root package name */
    public final r f4601c;

    /* renamed from: d, reason: collision with root package name */
    public final C0299a0 f4602d;
    public C0290A e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0337u(Context context, AttributeSet attributeSet) {
        int resourceId;
        int resourceId2;
        super(context, attributeSet, R.attr.checkedTextViewStyle);
        Y0.a(context);
        X0.a(this, getContext());
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4602d = c0299a0;
        c0299a0.f(attributeSet, R.attr.checkedTextViewStyle);
        c0299a0.b();
        r rVar = new r(this);
        this.f4601c = rVar;
        rVar.k(attributeSet, R.attr.checkedTextViewStyle);
        this.f4600b = new C0339v(this);
        Context context2 = getContext();
        int[] iArr = AbstractC0131a.f3073l;
        C0023k c0023kH = C0023k.h(context2, attributeSet, iArr, R.attr.checkedTextViewStyle);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        P.O.l(this, getContext(), iArr, attributeSet, (TypedArray) c0023kH.f913c, R.attr.checkedTextViewStyle);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    setCheckMarkDrawable(b1.e.A(getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                setCheckMarkDrawable(b1.e.A(getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                setCheckMarkTintList(c0023kH.b(2));
            }
            if (typedArray.hasValue(3)) {
                setCheckMarkTintMode(AbstractC0332r0.c(typedArray.getInt(3, -1), null));
            }
            c0023kH.j();
            getEmojiTextViewHelper().b(attributeSet, R.attr.checkedTextViewStyle);
        } catch (Throwable th) {
            c0023kH.j();
            throw th;
        }
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.e == null) {
            this.e = new C0290A(this);
        }
        return this.e;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0299a0 c0299a0 = this.f4602d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
        r rVar = this.f4601c;
        if (rVar != null) {
            rVar.a();
        }
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            c0339v.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4601c;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4601c;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            return c0339v.f4603a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            return c0339v.f4604b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4602d.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4602d.e();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        AbstractC0239g.t(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4601c;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4601c;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            if (c0339v.e) {
                c0339v.e = false;
            } else {
                c0339v.e = true;
                c0339v.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4602d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4602d;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4601c;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4601c;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            c0339v.f4603a = colorStateList;
            c0339v.f4605c = true;
            c0339v.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        C0339v c0339v = this.f4600b;
        if (c0339v != null) {
            c0339v.f4604b = mode;
            c0339v.f4606d = true;
            c0339v.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4602d;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4602d;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4602d;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(b1.e.A(getContext(), i));
    }
}
