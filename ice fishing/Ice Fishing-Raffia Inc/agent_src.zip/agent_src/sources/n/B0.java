package n;

import android.widget.LinearLayout;

/* loaded from: classes.dex */
public class B0 extends LinearLayout.LayoutParams {
}
