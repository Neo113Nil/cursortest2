package n;

import P.C0023k;
import a0.C0048b;
import a0.C0051e;
import a0.C0054h;
import a0.C0055i;
import android.R;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AbsSeekBar;
import android.widget.EditText;
import g.AbstractC0131a;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* renamed from: n.F, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0295F {

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f4332d = {R.attr.indeterminateDrawable, R.attr.progressDrawable};

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4333a = 2;

    /* renamed from: b, reason: collision with root package name */
    public View f4334b;

    /* renamed from: c, reason: collision with root package name */
    public Object f4335c;

    public /* synthetic */ C0295F() {
    }

    public KeyListener a(KeyListener keyListener) {
        if (keyListener instanceof NumberKeyListener) {
            return keyListener;
        }
        ((A.i) ((A0.f) this.f4335c).f224c).getClass();
        if (keyListener instanceof C0051e) {
            return keyListener;
        }
        if (keyListener == null) {
            return null;
        }
        return keyListener instanceof NumberKeyListener ? keyListener : new C0051e(keyListener);
    }

    public void b(AttributeSet attributeSet, int i) {
        switch (this.f4333a) {
            case 0:
                AbsSeekBar absSeekBar = (AbsSeekBar) this.f4334b;
                C0023k c0023kH = C0023k.h(absSeekBar.getContext(), attributeSet, f4332d, i);
                Drawable drawableD = c0023kH.d(0);
                if (drawableD != null) {
                    if (drawableD instanceof AnimationDrawable) {
                        AnimationDrawable animationDrawable = (AnimationDrawable) drawableD;
                        int numberOfFrames = animationDrawable.getNumberOfFrames();
                        AnimationDrawable animationDrawable2 = new AnimationDrawable();
                        animationDrawable2.setOneShot(animationDrawable.isOneShot());
                        for (int i3 = 0; i3 < numberOfFrames; i3++) {
                            Drawable drawableE = e(animationDrawable.getFrame(i3), true);
                            drawableE.setLevel(10000);
                            animationDrawable2.addFrame(drawableE, animationDrawable.getDuration(i3));
                        }
                        animationDrawable2.setLevel(10000);
                        drawableD = animationDrawable2;
                    }
                    absSeekBar.setIndeterminateDrawable(drawableD);
                }
                Drawable drawableD2 = c0023kH.d(1);
                if (drawableD2 != null) {
                    absSeekBar.setProgressDrawable(e(drawableD2, false));
                }
                c0023kH.j();
                return;
            default:
                TypedArray typedArrayObtainStyledAttributes = ((EditText) this.f4334b).getContext().obtainStyledAttributes(attributeSet, AbstractC0131a.i, i, 0);
                try {
                    boolean z2 = typedArrayObtainStyledAttributes.hasValue(14) ? typedArrayObtainStyledAttributes.getBoolean(14, true) : true;
                    typedArrayObtainStyledAttributes.recycle();
                    d(z2);
                    return;
                } catch (Throwable th) {
                    typedArrayObtainStyledAttributes.recycle();
                    throw th;
                }
        }
    }

    public C0048b c(InputConnection inputConnection, EditorInfo editorInfo) {
        A0.f fVar = (A0.f) this.f4335c;
        if (inputConnection == null) {
            fVar.getClass();
            inputConnection = null;
        } else {
            A.i iVar = (A.i) fVar.f224c;
            iVar.getClass();
            if (!(inputConnection instanceof C0048b)) {
                inputConnection = new C0048b((EditText) iVar.f94c, inputConnection, editorInfo);
            }
        }
        return (C0048b) inputConnection;
    }

    public void d(boolean z2) {
        C0055i c0055i = (C0055i) ((A.i) ((A0.f) this.f4335c).f224c).f95d;
        if (c0055i.f1469d != z2) {
            if (c0055i.f1468c != null) {
                Y.j jVarA = Y.j.a();
                C0054h c0054h = c0055i.f1468c;
                jVarA.getClass();
                L1.d.k(c0054h, "initCallback cannot be null");
                ReentrantReadWriteLock reentrantReadWriteLock = jVarA.f1379a;
                reentrantReadWriteLock.writeLock().lock();
                try {
                    jVarA.f1380b.remove(c0054h);
                } finally {
                    reentrantReadWriteLock.writeLock().unlock();
                }
            }
            c0055i.f1469d = z2;
            if (z2) {
                C0055i.a(c0055i.f1467b, Y.j.a().b());
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Drawable e(Drawable drawable, boolean z2) {
        if (drawable instanceof I.b) {
            ((I.c) ((I.b) drawable)).getClass();
        } else {
            if (drawable instanceof LayerDrawable) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                int numberOfLayers = layerDrawable.getNumberOfLayers();
                Drawable[] drawableArr = new Drawable[numberOfLayers];
                for (int i = 0; i < numberOfLayers; i++) {
                    int id = layerDrawable.getId(i);
                    drawableArr[i] = e(layerDrawable.getDrawable(i), id == 16908301 || id == 16908303);
                }
                LayerDrawable layerDrawable2 = new LayerDrawable(drawableArr);
                for (int i3 = 0; i3 < numberOfLayers; i3++) {
                    layerDrawable2.setId(i3, layerDrawable.getId(i3));
                    layerDrawable2.setLayerGravity(i3, layerDrawable.getLayerGravity(i3));
                    layerDrawable2.setLayerWidth(i3, layerDrawable.getLayerWidth(i3));
                    layerDrawable2.setLayerHeight(i3, layerDrawable.getLayerHeight(i3));
                    layerDrawable2.setLayerInsetLeft(i3, layerDrawable.getLayerInsetLeft(i3));
                    layerDrawable2.setLayerInsetRight(i3, layerDrawable.getLayerInsetRight(i3));
                    layerDrawable2.setLayerInsetTop(i3, layerDrawable.getLayerInsetTop(i3));
                    layerDrawable2.setLayerInsetBottom(i3, layerDrawable.getLayerInsetBottom(i3));
                    layerDrawable2.setLayerInsetStart(i3, layerDrawable.getLayerInsetStart(i3));
                    layerDrawable2.setLayerInsetEnd(i3, layerDrawable.getLayerInsetEnd(i3));
                }
                return layerDrawable2;
            }
            if (drawable instanceof BitmapDrawable) {
                BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
                Bitmap bitmap = bitmapDrawable.getBitmap();
                if (((Bitmap) this.f4335c) == null) {
                    this.f4335c = bitmap;
                }
                ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, null, null));
                shapeDrawable.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
                shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
                return z2 ? new ClipDrawable(shapeDrawable, 3, 1) : shapeDrawable;
            }
        }
        return drawable;
    }

    public C0295F(AbsSeekBar absSeekBar) {
        this.f4334b = absSeekBar;
    }

    public C0295F(EditText editText) {
        this.f4334b = editText;
        this.f4335c = new A0.f(editText);
    }
}
