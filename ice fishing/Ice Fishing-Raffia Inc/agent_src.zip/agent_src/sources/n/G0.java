package n;

/* loaded from: classes.dex */
public final class G0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4339b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ K0 f4340c;

    public /* synthetic */ G0(K0 k02, int i) {
        this.f4339b = i;
        this.f4340c = k02;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f4339b) {
            case 0:
                C0344x0 c0344x0 = this.f4340c.f4355d;
                if (c0344x0 != null) {
                    c0344x0.setListSelectionHidden(true);
                    c0344x0.requestLayout();
                    break;
                }
                break;
            default:
                K0 k02 = this.f4340c;
                C0344x0 c0344x02 = k02.f4355d;
                if (c0344x02 != null && c0344x02.isAttachedToWindow() && k02.f4355d.getCount() > k02.f4355d.getChildCount() && k02.f4355d.getChildCount() <= k02.f4363n) {
                    k02.f4352A.setInputMethodMode(2);
                    k02.h();
                    break;
                }
                break;
        }
    }
}
