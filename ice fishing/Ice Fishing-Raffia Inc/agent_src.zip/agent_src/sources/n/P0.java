package n;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import m.C0287n;
import m.MenuC0285l;

/* loaded from: classes.dex */
public final class P0 extends K0 implements L0 {

    /* renamed from: E, reason: collision with root package name */
    public static final Method f4389E;

    /* renamed from: D, reason: collision with root package name */
    public A0.f f4390D;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f4389E = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    @Override // n.L0
    public final void j(MenuC0285l menuC0285l, C0287n c0287n) {
        A0.f fVar = this.f4390D;
        if (fVar != null) {
            fVar.j(menuC0285l, c0287n);
        }
    }

    @Override // n.L0
    public final void n(MenuC0285l menuC0285l, C0287n c0287n) {
        A0.f fVar = this.f4390D;
        if (fVar != null) {
            fVar.n(menuC0285l, c0287n);
        }
    }

    @Override // n.K0
    public final C0344x0 q(Context context, boolean z2) {
        O0 o02 = new O0(context, z2);
        o02.setHoverListener(this);
        return o02;
    }
}
