package n;

import P.C0023k;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import g.AbstractC0131a;
import l.C0259c;

/* loaded from: classes.dex */
public final class U extends Spinner {

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f4410j = {R.attr.spinnerMode};

    /* renamed from: b, reason: collision with root package name */
    public final r f4411b;

    /* renamed from: c, reason: collision with root package name */
    public final Context f4412c;

    /* renamed from: d, reason: collision with root package name */
    public final L f4413d;
    public SpinnerAdapter e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f4414f;

    /* renamed from: g, reason: collision with root package name */
    public final T f4415g;

    /* renamed from: h, reason: collision with root package name */
    public int f4416h;
    public final Rect i;

    /* JADX WARN: Removed duplicated region for block: B:26:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00d7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public U(Context context, AttributeSet attributeSet) throws Throwable {
        TypedArray typedArrayObtainStyledAttributes;
        CharSequence[] textArray;
        SpinnerAdapter spinnerAdapter;
        super(context, attributeSet, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle);
        this.i = new Rect();
        X0.a(this, getContext());
        int[] iArr = AbstractC0131a.f3083v;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle);
        this.f4411b = new r(this);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        int resourceId = typedArray.getResourceId(4, 0);
        if (resourceId != 0) {
            this.f4412c = new C0259c(context, resourceId);
        } else {
            this.f4412c = context;
        }
        int i = -1;
        TypedArray typedArray2 = null;
        try {
            typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f4410j, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle, 0);
            try {
                try {
                    if (typedArrayObtainStyledAttributes.hasValue(0)) {
                        i = typedArrayObtainStyledAttributes.getInt(0, 0);
                    }
                } catch (Exception e) {
                    e = e;
                    Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
                    if (typedArrayObtainStyledAttributes != null) {
                        typedArrayObtainStyledAttributes.recycle();
                    }
                    if (i != 0) {
                    }
                    textArray = typedArray.getTextArray(0);
                    if (textArray != null) {
                    }
                    c0023kH.j();
                    this.f4414f = true;
                    spinnerAdapter = this.e;
                    if (spinnerAdapter != null) {
                    }
                    this.f4411b.k(attributeSet, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle);
                }
            } catch (Throwable th) {
                th = th;
                typedArray2 = typedArrayObtainStyledAttributes;
                if (typedArray2 != null) {
                    typedArray2.recycle();
                }
                throw th;
            }
        } catch (Exception e3) {
            e = e3;
            typedArrayObtainStyledAttributes = null;
        } catch (Throwable th2) {
            th = th2;
            if (typedArray2 != null) {
            }
            throw th;
        }
        typedArrayObtainStyledAttributes.recycle();
        if (i != 0) {
            N n3 = new N(this);
            this.f4415g = n3;
            n3.f4380d = typedArray.getString(2);
        } else if (i == 1) {
            Q q2 = new Q(this, this.f4412c, attributeSet);
            C0023k c0023kH2 = C0023k.h(this.f4412c, attributeSet, iArr, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle);
            this.f4416h = ((TypedArray) c0023kH2.f913c).getLayoutDimension(3, -2);
            q2.k(c0023kH2.c(1));
            q2.f4391D = typedArray.getString(2);
            c0023kH2.j();
            this.f4415g = q2;
            this.f4413d = new L(this, this, q2);
        }
        textArray = typedArray.getTextArray(0);
        if (textArray != null) {
            ArrayAdapter arrayAdapter = new ArrayAdapter(context, R.layout.simple_spinner_item, textArray);
            arrayAdapter.setDropDownViewResource(com.kortosi.kluani.qorzanis.R.layout.support_simple_spinner_dropdown_item);
            setAdapter((SpinnerAdapter) arrayAdapter);
        }
        c0023kH.j();
        this.f4414f = true;
        spinnerAdapter = this.e;
        if (spinnerAdapter != null) {
            setAdapter(spinnerAdapter);
            this.e = null;
        }
        this.f4411b.k(attributeSet, com.kortosi.kluani.qorzanis.R.attr.spinnerStyle);
    }

    public final int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int iMax = Math.max(0, getSelectedItemPosition());
        int iMin = Math.min(spinnerAdapter.getCount(), iMax + 15);
        View view = null;
        int iMax2 = 0;
        for (int iMax3 = Math.max(0, iMax - (15 - (iMin - iMax))); iMax3 < iMin; iMax3++) {
            int itemViewType = spinnerAdapter.getItemViewType(iMax3);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(iMax3, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
            iMax2 = Math.max(iMax2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return iMax2;
        }
        Rect rect = this.i;
        drawable.getPadding(rect);
        return iMax2 + rect.left + rect.right;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4411b;
        if (rVar != null) {
            rVar.a();
        }
    }

    @Override // android.widget.Spinner
    public int getDropDownHorizontalOffset() {
        T t2 = this.f4415g;
        return t2 != null ? t2.d() : super.getDropDownHorizontalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownVerticalOffset() {
        T t2 = this.f4415g;
        return t2 != null ? t2.i() : super.getDropDownVerticalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownWidth() {
        return this.f4415g != null ? this.f4416h : super.getDropDownWidth();
    }

    public final T getInternalPopup() {
        return this.f4415g;
    }

    @Override // android.widget.Spinner
    public Drawable getPopupBackground() {
        T t2 = this.f4415g;
        return t2 != null ? t2.m() : super.getPopupBackground();
    }

    @Override // android.widget.Spinner
    public Context getPopupContext() {
        return this.f4412c;
    }

    @Override // android.widget.Spinner
    public CharSequence getPrompt() {
        T t2 = this.f4415g;
        return t2 != null ? t2.b() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4411b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4411b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    @Override // android.widget.Spinner, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        T t2 = this.f4415g;
        if (t2 == null || !t2.a()) {
            return;
        }
        t2.dismiss();
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final void onMeasure(int i, int i3) {
        super.onMeasure(i, i3);
        if (this.f4415g == null || View.MeasureSpec.getMode(i) != Integer.MIN_VALUE) {
            return;
        }
        setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i)), getMeasuredHeight());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        S s2 = (S) parcelable;
        super.onRestoreInstanceState(s2.getSuperState());
        if (!s2.f4402b || (viewTreeObserver = getViewTreeObserver()) == null) {
            return;
        }
        viewTreeObserver.addOnGlobalLayoutListener(new Z0.c(3, this));
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final Parcelable onSaveInstanceState() {
        S s2 = new S(super.onSaveInstanceState());
        T t2 = this.f4415g;
        s2.f4402b = t2 != null && t2.a();
        return s2;
    }

    @Override // android.widget.Spinner, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        L l3 = this.f4413d;
        if (l3 == null || !l3.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.widget.Spinner, android.view.View
    public final boolean performClick() {
        T t2 = this.f4415g;
        if (t2 == null) {
            return super.performClick();
        }
        if (t2.a()) {
            return true;
        }
        this.f4415g.f(getTextDirection(), getTextAlignment());
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4411b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4411b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownHorizontalOffset(int i) {
        T t2 = this.f4415g;
        if (t2 == null) {
            super.setDropDownHorizontalOffset(i);
        } else {
            t2.p(i);
            t2.c(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownVerticalOffset(int i) {
        T t2 = this.f4415g;
        if (t2 != null) {
            t2.l(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownWidth(int i) {
        if (this.f4415g != null) {
            this.f4416h = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundDrawable(Drawable drawable) {
        T t2 = this.f4415g;
        if (t2 != null) {
            t2.k(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(b1.e.A(getPopupContext(), i));
    }

    @Override // android.widget.Spinner
    public void setPrompt(CharSequence charSequence) {
        T t2 = this.f4415g;
        if (t2 != null) {
            t2.g(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4411b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4411b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    @Override // android.widget.AdapterView
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f4414f) {
            this.e = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        T t2 = this.f4415g;
        if (t2 != null) {
            Context context = this.f4412c;
            if (context == null) {
                context = getContext();
            }
            Resources.Theme theme = context.getTheme();
            O o3 = new O();
            o3.f4381a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                o3.f4382b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                M.a((ThemedSpinnerAdapter) spinnerAdapter, theme);
            }
            t2.o(o3);
        }
    }
}
