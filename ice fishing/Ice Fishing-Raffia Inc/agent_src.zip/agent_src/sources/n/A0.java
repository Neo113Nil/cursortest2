package n;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import m.InterfaceC0271B;

/* loaded from: classes.dex */
public abstract class A0 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* renamed from: b, reason: collision with root package name */
    public final float f4302b;

    /* renamed from: c, reason: collision with root package name */
    public final int f4303c;

    /* renamed from: d, reason: collision with root package name */
    public final int f4304d;
    public final View e;

    /* renamed from: f, reason: collision with root package name */
    public RunnableC0348z0 f4305f;

    /* renamed from: g, reason: collision with root package name */
    public RunnableC0348z0 f4306g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f4307h;
    public int i;

    /* renamed from: j, reason: collision with root package name */
    public final int[] f4308j = new int[2];

    public A0(View view) {
        this.e = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f4302b = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.f4303c = tapTimeout;
        this.f4304d = (ViewConfiguration.getLongPressTimeout() + tapTimeout) / 2;
    }

    public final void a() {
        RunnableC0348z0 runnableC0348z0 = this.f4306g;
        View view = this.e;
        if (runnableC0348z0 != null) {
            view.removeCallbacks(runnableC0348z0);
        }
        RunnableC0348z0 runnableC0348z02 = this.f4305f;
        if (runnableC0348z02 != null) {
            view.removeCallbacks(runnableC0348z02);
        }
    }

    public abstract InterfaceC0271B b();

    public abstract boolean c();

    public boolean d() {
        InterfaceC0271B interfaceC0271BB = b();
        if (interfaceC0271BB == null || !interfaceC0271BB.a()) {
            return true;
        }
        interfaceC0271BB.dismiss();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0100  */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouch(View view, MotionEvent motionEvent) throws IllegalAccessException, IllegalArgumentException {
        boolean z2;
        C0344x0 c0344x0E;
        boolean z3 = this.f4307h;
        View view2 = this.e;
        if (z3) {
            InterfaceC0271B interfaceC0271BB = b();
            if (interfaceC0271BB == null || !interfaceC0271BB.a() || (c0344x0E = interfaceC0271BB.e()) == null || !c0344x0E.isShown()) {
                z2 = !d();
            } else {
                MotionEvent motionEventObtainNoHistory = MotionEvent.obtainNoHistory(motionEvent);
                int[] iArr = this.f4308j;
                view2.getLocationOnScreen(iArr);
                motionEventObtainNoHistory.offsetLocation(iArr[0], iArr[1]);
                c0344x0E.getLocationOnScreen(iArr);
                motionEventObtainNoHistory.offsetLocation(-iArr[0], -iArr[1]);
                boolean zB = c0344x0E.b(motionEventObtainNoHistory, this.i);
                motionEventObtainNoHistory.recycle();
                int actionMasked = motionEvent.getActionMasked();
                boolean z4 = (actionMasked == 1 || actionMasked == 3) ? false : true;
                if (!zB || !z4) {
                }
            }
        } else if (view2.isEnabled()) {
            int actionMasked2 = motionEvent.getActionMasked();
            if (actionMasked2 == 0) {
                this.i = motionEvent.getPointerId(0);
                if (this.f4305f == null) {
                    this.f4305f = new RunnableC0348z0(this, 0);
                }
                view2.postDelayed(this.f4305f, this.f4303c);
                if (this.f4306g == null) {
                    this.f4306g = new RunnableC0348z0(this, 1);
                }
                view2.postDelayed(this.f4306g, this.f4304d);
            } else if (actionMasked2 == 1) {
                a();
            } else if (actionMasked2 == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.i);
                if (iFindPointerIndex >= 0) {
                    float x2 = motionEvent.getX(iFindPointerIndex);
                    float y2 = motionEvent.getY(iFindPointerIndex);
                    float f3 = this.f4302b;
                    float f4 = -f3;
                    if (x2 < f4 || y2 < f4 || x2 >= (view2.getRight() - view2.getLeft()) + f3 || y2 >= (view2.getBottom() - view2.getTop()) + f3) {
                        a();
                        view2.getParent().requestDisallowInterceptTouchEvent(true);
                        if (c()) {
                            z2 = true;
                        }
                        if (z2) {
                            long jUptimeMillis = SystemClock.uptimeMillis();
                            MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                            view2.onTouchEvent(motionEventObtain);
                            motionEventObtain.recycle();
                        }
                    }
                }
            } else if (actionMasked2 == 3) {
            }
            z2 = false;
            if (z2) {
            }
        } else {
            z2 = false;
            if (z2) {
            }
        }
        this.f4307h = z2;
        return z2 || z3;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.f4307h = false;
        this.i = -1;
        RunnableC0348z0 runnableC0348z0 = this.f4305f;
        if (runnableC0348z0 != null) {
            this.e.removeCallbacks(runnableC0348z0);
        }
    }
}
