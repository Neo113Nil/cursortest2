package n;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: n.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0318k implements Parcelable {
    public static final Parcelable.Creator<C0318k> CREATOR = new G0.a(13);

    /* renamed from: b, reason: collision with root package name */
    public int f4525b;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f4525b);
    }
}
