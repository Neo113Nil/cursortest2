package n;

import android.os.Handler;
import android.widget.AbsListView;

/* loaded from: classes.dex */
public final class I0 implements AbsListView.OnScrollListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ K0 f4343a;

    public I0(K0 k02) {
        this.f4343a = k02;
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScroll(AbsListView absListView, int i, int i3, int i4) {
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScrollStateChanged(AbsListView absListView, int i) {
        if (i == 1) {
            K0 k02 = this.f4343a;
            if (k02.f4352A.getInputMethodMode() == 2 || k02.f4352A.getContentView() == null) {
                return;
            }
            Handler handler = k02.f4372w;
            G0 g02 = k02.f4368s;
            handler.removeCallbacks(g02);
            g02.run();
        }
    }
}
