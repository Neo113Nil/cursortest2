package n;

import android.view.View;

/* renamed from: n.s0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0334s0 {
    public static void a(View view, float f3, float f4) {
        view.drawableHotspotChanged(f3, f4);
    }
}
