package n;

import a.AbstractC0046a;
import android.util.Log;
import android.view.MenuItem;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.profileinstaller.ProfileInstallReceiver;
import h.C0170I;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import m.InterfaceC0283j;
import m.MenuC0285l;
import n0.InterfaceC0354f;
import p0.AbstractC0371b;
import p0.RunnableC0372c;
import q0.C0422t;
import y0.InterfaceC0531a;
import y0.InterfaceC0532b;
import z0.InterfaceC0539b;

/* renamed from: n.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0326o implements InterfaceC0283j, InterfaceC0301b0, InterfaceC0354f, InterfaceC0532b {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4569b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f4570c;

    public /* synthetic */ C0326o(int i, Object obj) {
        this.f4569b = i;
        this.f4570c = obj;
    }

    public void a(int i) {
    }

    @Override // n0.InterfaceC0354f
    public void b(int i, Serializable serializable) {
        String str;
        switch (i) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case 2:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case 3:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case 4:
                str = "RESULT_NOT_WRITABLE";
                break;
            case 5:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case 6:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case 7:
                str = "RESULT_IO_EXCEPTION";
                break;
            case 8:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 9:
            default:
                str = "";
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case 11:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i == 6 || i == 7 || i == 8) {
            Log.e("ProfileInstaller", str, (Throwable) serializable);
        } else {
            Log.d("ProfileInstaller", str);
        }
        ((ProfileInstallReceiver) this.f4570c).setResultCode(i);
    }

    @Override // m.InterfaceC0283j
    public boolean c(MenuC0285l menuC0285l, MenuItem menuItem) {
        boolean z2;
        boolean zOnMenuItemSelected;
        InterfaceC0328p interfaceC0328p = ((ActionMenuView) this.f4570c).f1557B;
        if (interfaceC0328p == null) {
            return false;
        }
        Toolbar toolbar = ((c1) interfaceC0328p).f4492b;
        Iterator it = ((CopyOnWriteArrayList) toolbar.f1587H.f913c).iterator();
        while (true) {
            if (!it.hasNext()) {
                z2 = false;
                break;
            }
            if (((c0.G) it.next()).f2086a.p()) {
                z2 = true;
                break;
            }
        }
        if (z2) {
            zOnMenuItemSelected = true;
        } else {
            g1 g1Var = toolbar.f1589J;
            zOnMenuItemSelected = g1Var != null ? ((C0170I) g1Var).f3266b.f3268d.f3381b.onMenuItemSelected(0, menuItem) : false;
        }
        return zOnMenuItemSelected;
    }

    @Override // y0.InterfaceC0532b
    public InterfaceC0531a d(String str) {
        X1.i.e(str, "fileName");
        return new t0.a(((InterfaceC0539b) this.f4570c).w());
    }

    public void e(int i, float f3) {
    }

    @Override // n0.InterfaceC0354f
    public void f() {
        Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    @Override // m.InterfaceC0283j
    public void g(MenuC0285l menuC0285l) {
        InterfaceC0283j interfaceC0283j = ((ActionMenuView) this.f4570c).f1564w;
        if (interfaceC0283j != null) {
            interfaceC0283j.g(menuC0285l);
        }
    }

    public void h(int i) {
    }

    public boolean i(int i, int i3) {
        RunnableC0372c runnableC0372c = (RunnableC0372c) this.f4570c;
        Object obj = runnableC0372c.f4877b.get(i);
        Object obj2 = runnableC0372c.f4878c.get(i3);
        if (obj != null && obj2 != null) {
            return ((AbstractC0371b) runnableC0372c.f4880f.f4883b.f95d).a(obj, obj2);
        }
        if (obj == null && obj2 == null) {
            return true;
        }
        throw new AssertionError();
    }

    public boolean j(int i, int i3) {
        RunnableC0372c runnableC0372c = (RunnableC0372c) this.f4570c;
        Object obj = runnableC0372c.f4877b.get(i);
        Object obj2 = runnableC0372c.f4878c.get(i3);
        return (obj == null || obj2 == null) ? obj == null && obj2 == null : ((AbstractC0371b) runnableC0372c.f4880f.f4883b.f95d).b(obj, obj2);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void k(k2.m mVar, P1.c cVar) throws Throwable {
        C0422t c0422t;
        if (cVar instanceof C0422t) {
            c0422t = (C0422t) cVar;
            int i = c0422t.f5240g;
            if ((i & Integer.MIN_VALUE) != 0) {
                c0422t.f5240g = i - Integer.MIN_VALUE;
            } else {
                c0422t = new C0422t(this, cVar);
            }
        }
        Object obj = c0422t.e;
        int i3 = c0422t.f5240g;
        if (i3 != 0) {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
            throw new C0.c();
        }
        AbstractC0046a.N(obj);
        c0422t.f5240g = 1;
        ((j2.L) this.f4570c).c(mVar, c0422t);
    }

    public void l(int i, int i3) {
        RunnableC0372c runnableC0372c = (RunnableC0372c) this.f4570c;
        Object obj = runnableC0372c.f4877b.get(i);
        Object obj2 = runnableC0372c.f4878c.get(i3);
        if (obj == null || obj2 == null) {
            throw new AssertionError();
        }
        Object obj3 = runnableC0372c.f4880f.f4883b.f95d;
    }

    public void m(Set set) {
        j2.L l3;
        Object objJ;
        int[] iArr;
        X1.i.e(set, "tableIds");
        if (set.isEmpty()) {
            return;
        }
        do {
            l3 = (j2.L) this.f4570c;
            objJ = l3.j();
            int[] iArr2 = (int[]) objJ;
            int length = iArr2.length;
            iArr = new int[length];
            for (int i = 0; i < length; i++) {
                iArr[i] = set.contains(Integer.valueOf(i)) ? iArr2[i] + 1 : iArr2[i];
            }
        } while (!l3.i(objJ, iArr));
    }

    public void n(int i, int i3) {
        ((p0.G) this.f4570c).f4825a.e(i, i3);
    }

    public void o(int i, int i3) {
        ((p0.G) this.f4570c).f4825a.f(i, i3);
    }

    public C0326o(InterfaceC0539b interfaceC0539b) {
        this.f4569b = 9;
        X1.i.e(interfaceC0539b, "openHelper");
        this.f4570c = interfaceC0539b;
    }

    public C0326o(int i) {
        this.f4569b = 8;
        this.f4570c = new j2.L(new int[i]);
    }
}
