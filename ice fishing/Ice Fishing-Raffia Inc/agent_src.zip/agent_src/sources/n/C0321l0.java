package n;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;

/* renamed from: n.l0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0321l0 extends ToggleButton {

    /* renamed from: b, reason: collision with root package name */
    public final r f4560b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4561c;

    /* renamed from: d, reason: collision with root package name */
    public C0290A f4562d;

    public C0321l0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyleToggle);
        X0.a(this, getContext());
        r rVar = new r(this);
        this.f4560b = rVar;
        rVar.k(attributeSet, R.attr.buttonStyleToggle);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4561c = c0299a0;
        c0299a0.f(attributeSet, R.attr.buttonStyleToggle);
        getEmojiTextViewHelper().b(attributeSet, R.attr.buttonStyleToggle);
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.f4562d == null) {
            this.f4562d = new C0290A(this);
        }
        return this.f4562d;
    }

    @Override // android.widget.ToggleButton, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4560b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4561c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4560b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4560b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4561c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4561c.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.ToggleButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4560b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4560b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4561c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4561c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4560b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4560b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4561c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4561c;
        c0299a0.m(mode);
        c0299a0.b();
    }
}
