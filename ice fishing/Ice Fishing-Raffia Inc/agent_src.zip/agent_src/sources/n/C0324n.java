package n;

/* renamed from: n.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0324n extends B0 {

    /* renamed from: a, reason: collision with root package name */
    public boolean f4564a;

    /* renamed from: b, reason: collision with root package name */
    public int f4565b;

    /* renamed from: c, reason: collision with root package name */
    public int f4566c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f4567d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4568f;
}
