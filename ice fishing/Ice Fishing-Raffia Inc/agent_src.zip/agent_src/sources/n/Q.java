package n;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import com.kortosi.kluani.qorzanis.R;

/* loaded from: classes.dex */
public final class Q extends K0 implements T {

    /* renamed from: D, reason: collision with root package name */
    public CharSequence f4391D;

    /* renamed from: E, reason: collision with root package name */
    public O f4392E;
    public final Rect F;

    /* renamed from: G, reason: collision with root package name */
    public int f4393G;

    /* renamed from: H, reason: collision with root package name */
    public final /* synthetic */ U f4394H;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Q(U u2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.spinnerStyle);
        this.f4394H = u2;
        this.F = new Rect();
        this.f4365p = u2;
        this.f4375z = true;
        this.f4352A.setFocusable(true);
        this.f4366q = new h1.s(1, this);
    }

    @Override // n.T
    public final CharSequence b() {
        return this.f4391D;
    }

    @Override // n.T
    public final void f(int i, int i3) {
        ViewTreeObserver viewTreeObserver;
        C0294E c0294e = this.f4352A;
        boolean zIsShowing = c0294e.isShowing();
        s();
        this.f4352A.setInputMethodMode(2);
        h();
        C0344x0 c0344x0 = this.f4355d;
        c0344x0.setChoiceMode(1);
        c0344x0.setTextDirection(i);
        c0344x0.setTextAlignment(i3);
        U u2 = this.f4394H;
        int selectedItemPosition = u2.getSelectedItemPosition();
        C0344x0 c0344x02 = this.f4355d;
        if (c0294e.isShowing() && c0344x02 != null) {
            c0344x02.setListSelectionHidden(false);
            c0344x02.setSelection(selectedItemPosition);
            if (c0344x02.getChoiceMode() != 0) {
                c0344x02.setItemChecked(selectedItemPosition, true);
            }
        }
        if (zIsShowing || (viewTreeObserver = u2.getViewTreeObserver()) == null) {
            return;
        }
        Z0.c cVar = new Z0.c(4, this);
        viewTreeObserver.addOnGlobalLayoutListener(cVar);
        this.f4352A.setOnDismissListener(new P(this, cVar));
    }

    @Override // n.T
    public final void g(CharSequence charSequence) {
        this.f4391D = charSequence;
    }

    @Override // n.K0, n.T
    public final void o(ListAdapter listAdapter) {
        super.o(listAdapter);
        this.f4392E = (O) listAdapter;
    }

    @Override // n.T
    public final void p(int i) {
        this.f4393G = i;
    }

    public final void s() {
        int i;
        C0294E c0294e = this.f4352A;
        Drawable background = c0294e.getBackground();
        U u2 = this.f4394H;
        if (background != null) {
            background.getPadding(u2.i);
            boolean z2 = o1.f4571a;
            int layoutDirection = u2.getLayoutDirection();
            Rect rect = u2.i;
            i = layoutDirection == 1 ? rect.right : -rect.left;
        } else {
            Rect rect2 = u2.i;
            rect2.right = 0;
            rect2.left = 0;
            i = 0;
        }
        int paddingLeft = u2.getPaddingLeft();
        int paddingRight = u2.getPaddingRight();
        int width = u2.getWidth();
        int i3 = u2.f4416h;
        if (i3 == -2) {
            int iA = u2.a(this.f4392E, c0294e.getBackground());
            int i4 = u2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = u2.i;
            int i5 = (i4 - rect3.left) - rect3.right;
            if (iA > i5) {
                iA = i5;
            }
            r(Math.max(iA, (width - paddingLeft) - paddingRight));
        } else if (i3 == -1) {
            r((width - paddingLeft) - paddingRight);
        } else {
            r(i3);
        }
        boolean z3 = o1.f4571a;
        this.f4357g = u2.getLayoutDirection() == 1 ? (((width - paddingRight) - this.f4356f) - this.f4393G) + i : paddingLeft + this.f4393G + i;
    }
}
