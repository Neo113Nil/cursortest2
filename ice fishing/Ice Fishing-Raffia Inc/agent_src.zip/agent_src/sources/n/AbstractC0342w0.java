package n;

import android.widget.AbsListView;
import java.lang.reflect.Field;

/* renamed from: n.w0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0342w0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Field f4615a;

    static {
        Field declaredField = null;
        try {
            declaredField = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            declaredField.setAccessible(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
        f4615a = declaredField;
    }
}
