package n;

import P.C0023k;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;

/* loaded from: classes.dex */
public final class j1 implements InterfaceC0327o0 {

    /* renamed from: a, reason: collision with root package name */
    public final Toolbar f4512a;

    /* renamed from: b, reason: collision with root package name */
    public int f4513b;

    /* renamed from: c, reason: collision with root package name */
    public final View f4514c;

    /* renamed from: d, reason: collision with root package name */
    public Drawable f4515d;
    public Drawable e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f4516f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f4517g;

    /* renamed from: h, reason: collision with root package name */
    public CharSequence f4518h;
    public final CharSequence i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f4519j;

    /* renamed from: k, reason: collision with root package name */
    public Window.Callback f4520k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f4521l;

    /* renamed from: m, reason: collision with root package name */
    public C0320l f4522m;

    /* renamed from: n, reason: collision with root package name */
    public final int f4523n;

    /* renamed from: o, reason: collision with root package name */
    public final Drawable f4524o;

    public j1(Toolbar toolbar, boolean z2) {
        Drawable drawable;
        this.f4523n = 0;
        this.f4512a = toolbar;
        this.f4518h = toolbar.getTitle();
        this.i = toolbar.getSubtitle();
        this.f4517g = this.f4518h != null;
        this.f4516f = toolbar.getNavigationIcon();
        C0023k c0023kH = C0023k.h(toolbar.getContext(), null, AbstractC0131a.f3064a, R.attr.actionBarStyle);
        int i = 15;
        this.f4524o = c0023kH.c(15);
        if (z2) {
            TypedArray typedArray = (TypedArray) c0023kH.f913c;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                this.f4517g = true;
                this.f4518h = text;
                if ((this.f4513b & 8) != 0) {
                    Toolbar toolbar2 = this.f4512a;
                    toolbar2.setTitle(text);
                    if (this.f4517g) {
                        P.O.n(toolbar2.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                this.i = text2;
                if ((this.f4513b & 8) != 0) {
                    toolbar.setSubtitle(text2);
                }
            }
            Drawable drawableC = c0023kH.c(20);
            if (drawableC != null) {
                this.e = drawableC;
                d();
            }
            Drawable drawableC2 = c0023kH.c(17);
            if (drawableC2 != null) {
                this.f4515d = drawableC2;
                d();
            }
            if (this.f4516f == null && (drawable = this.f4524o) != null) {
                this.f4516f = drawable;
                int i3 = this.f4513b & 4;
                Toolbar toolbar3 = this.f4512a;
                if (i3 != 0) {
                    toolbar3.setNavigationIcon(drawable);
                } else {
                    toolbar3.setNavigationIcon((Drawable) null);
                }
            }
            a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(toolbar.getContext()).inflate(resourceId, (ViewGroup) toolbar, false);
                View view = this.f4514c;
                if (view != null && (this.f4513b & 16) != 0) {
                    toolbar.removeView(view);
                }
                this.f4514c = viewInflate;
                if (viewInflate != null && (this.f4513b & 16) != 0) {
                    toolbar.addView(viewInflate);
                }
                a(this.f4513b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
                layoutParams.height = layoutDimension;
                toolbar.setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                toolbar.d();
                toolbar.f1617u.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = toolbar.getContext();
                toolbar.f1609m = resourceId2;
                C0307e0 c0307e0 = toolbar.f1601c;
                if (c0307e0 != null) {
                    c0307e0.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = toolbar.getContext();
                toolbar.f1610n = resourceId3;
                C0307e0 c0307e02 = toolbar.f1602d;
                if (c0307e02 != null) {
                    c0307e02.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                toolbar.setPopupTheme(resourceId4);
            }
        } else {
            if (toolbar.getNavigationIcon() != null) {
                this.f4524o = toolbar.getNavigationIcon();
            } else {
                i = 11;
            }
            this.f4513b = i;
        }
        c0023kH.j();
        if (R.string.abc_action_bar_up_description != this.f4523n) {
            this.f4523n = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                b(this.f4523n);
            }
        }
        this.f4519j = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new i1(this));
    }

    public final void a(int i) {
        View view;
        int i3 = this.f4513b ^ i;
        this.f4513b = i;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i & 4) != 0) {
                    c();
                }
                int i4 = this.f4513b & 4;
                Toolbar toolbar = this.f4512a;
                if (i4 != 0) {
                    Drawable drawable = this.f4516f;
                    if (drawable == null) {
                        drawable = this.f4524o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i3 & 3) != 0) {
                d();
            }
            int i5 = i3 & 8;
            Toolbar toolbar2 = this.f4512a;
            if (i5 != 0) {
                if ((i & 8) != 0) {
                    toolbar2.setTitle(this.f4518h);
                    toolbar2.setSubtitle(this.i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f4514c) == null) {
                return;
            }
            if ((i & 16) != 0) {
                toolbar2.addView(view);
            } else {
                toolbar2.removeView(view);
            }
        }
    }

    public final void b(int i) {
        this.f4519j = i == 0 ? null : this.f4512a.getContext().getString(i);
        c();
    }

    public final void c() {
        if ((this.f4513b & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f4519j);
            Toolbar toolbar = this.f4512a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f4523n);
            } else {
                toolbar.setNavigationContentDescription(this.f4519j);
            }
        }
    }

    public final void d() {
        Drawable drawable;
        int i = this.f4513b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.e) == null) {
            drawable = this.f4515d;
        }
        this.f4512a.setLogo(drawable);
    }
}
