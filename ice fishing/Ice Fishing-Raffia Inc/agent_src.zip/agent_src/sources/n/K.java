package n;

import P.C0023k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import com.kortosi.kluani.qorzanis.R;
import g.AbstractC0131a;

/* loaded from: classes.dex */
public final class K extends C0295F {
    public final J e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f4346f;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f4347g;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f4348h;
    public boolean i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f4349j;

    public K(J j3) {
        super(j3);
        this.f4347g = null;
        this.f4348h = null;
        this.i = false;
        this.f4349j = false;
        this.e = j3;
    }

    @Override // n.C0295F
    public final void b(AttributeSet attributeSet, int i) {
        super.b(attributeSet, R.attr.seekBarStyle);
        J j3 = this.e;
        Context context = j3.getContext();
        int[] iArr = AbstractC0131a.f3069g;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, R.attr.seekBarStyle);
        P.O.l(j3, j3.getContext(), iArr, attributeSet, (TypedArray) c0023kH.f913c, R.attr.seekBarStyle);
        Drawable drawableD = c0023kH.d(0);
        if (drawableD != null) {
            j3.setThumb(drawableD);
        }
        Drawable drawableC = c0023kH.c(1);
        Drawable drawable = this.f4346f;
        if (drawable != null) {
            drawable.setCallback(null);
        }
        this.f4346f = drawableC;
        if (drawableC != null) {
            drawableC.setCallback(j3);
            drawableC.setLayoutDirection(j3.getLayoutDirection());
            if (drawableC.isStateful()) {
                drawableC.setState(j3.getDrawableState());
            }
            f();
        }
        j3.invalidate();
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        if (typedArray.hasValue(3)) {
            this.f4348h = AbstractC0332r0.c(typedArray.getInt(3, -1), this.f4348h);
            this.f4349j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f4347g = c0023kH.b(2);
            this.i = true;
        }
        c0023kH.j();
        f();
    }

    public final void f() {
        Drawable drawable = this.f4346f;
        if (drawable != null) {
            if (this.i || this.f4349j) {
                Drawable drawableMutate = drawable.mutate();
                this.f4346f = drawableMutate;
                if (this.i) {
                    drawableMutate.setTintList(this.f4347g);
                }
                if (this.f4349j) {
                    this.f4346f.setTintMode(this.f4348h);
                }
                if (this.f4346f.isStateful()) {
                    this.f4346f.setState(this.e.getDrawableState());
                }
            }
        }
    }

    public final void g(Canvas canvas) {
        if (this.f4346f != null) {
            int max = this.e.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f4346f.getIntrinsicWidth();
                int intrinsicHeight = this.f4346f.getIntrinsicHeight();
                int i = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i3 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f4346f.setBounds(-i, -i3, i, i3);
                float width = ((r0.getWidth() - r0.getPaddingLeft()) - r0.getPaddingRight()) / max;
                int iSave = canvas.save();
                canvas.translate(r0.getPaddingLeft(), r0.getHeight() / 2);
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f4346f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(iSave);
            }
        }
    }
}
