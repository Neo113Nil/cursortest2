package n;

import android.view.View;
import android.widget.AdapterView;

/* loaded from: classes.dex */
public final class D0 implements AdapterView.OnItemSelectedListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ K0 f4331b;

    public D0(K0 k02) {
        this.f4331b = k02;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onItemSelected(AdapterView adapterView, View view, int i, long j3) {
        C0344x0 c0344x0;
        if (i == -1 || (c0344x0 = this.f4331b.f4355d) == null) {
            return;
        }
        c0344x0.setListSelectionHidden(false);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onNothingSelected(AdapterView adapterView) {
    }
}
