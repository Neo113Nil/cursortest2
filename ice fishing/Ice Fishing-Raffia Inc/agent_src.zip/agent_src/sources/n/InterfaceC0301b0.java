package n;

/* renamed from: n.b0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0301b0 {
    void a(int i);

    void e(int i, float f3);

    void h(int i);
}
