package n;

/* renamed from: n.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0328p {
}
