package n;

/* renamed from: n.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0345y {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0347z f4629a;

    public C0345y(C0347z c0347z) {
        this.f4629a = c0347z;
    }
}
