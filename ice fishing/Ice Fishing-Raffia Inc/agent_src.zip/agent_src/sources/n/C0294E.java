package n;

import android.widget.PopupWindow;

/* renamed from: n.E, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0294E extends PopupWindow {
}
