package n;

import android.content.Context;
import android.graphics.drawable.Drawable;
import com.kortosi.kluani.qorzanis.R;
import m.C0275b;

/* renamed from: n.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0316j extends C0292C implements InterfaceC0322m {
    public final /* synthetic */ C0320l e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0316j(C0320l c0320l, Context context) {
        super(context, null, R.attr.actionOverflowButtonStyle);
        this.e = c0320l;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        k1.a(this, getContentDescription());
        setOnTouchListener(new C0275b(this, this));
    }

    @Override // n.InterfaceC0322m
    public final boolean b() {
        return false;
    }

    @Override // n.InterfaceC0322m
    public final boolean c() {
        return false;
    }

    @Override // android.view.View
    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.e.n();
        return true;
    }

    @Override // android.widget.ImageView
    public final boolean setFrame(int i, int i3, int i4, int i5) {
        boolean frame = super.setFrame(i, i3, i4, i5);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (drawable != null && background != null) {
            int width = getWidth();
            int height = getHeight();
            int iMax = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            background.setHotspotBounds(paddingLeft - iMax, paddingTop - iMax, paddingLeft + iMax, paddingTop + iMax);
        }
        return frame;
    }
}
