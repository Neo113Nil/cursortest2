package n;

import m.InterfaceC0271B;

/* loaded from: classes.dex */
public final class L extends A0 {

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ Q f4376k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ U f4377l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(U u2, U u3, Q q2) {
        super(u3);
        this.f4377l = u2;
        this.f4376k = q2;
    }

    @Override // n.A0
    public final InterfaceC0271B b() {
        return this.f4376k;
    }

    @Override // n.A0
    public final boolean c() {
        U u2 = this.f4377l;
        if (u2.getInternalPopup().a()) {
            return true;
        }
        u2.f4415g.f(u2.getTextDirection(), u2.getTextAlignment());
        return true;
    }
}
