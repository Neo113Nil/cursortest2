package n;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: n.k0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0319k0 {

    /* renamed from: l, reason: collision with root package name */
    public static final RectF f4526l = new RectF();

    /* renamed from: m, reason: collision with root package name */
    public static final ConcurrentHashMap f4527m = new ConcurrentHashMap();

    /* renamed from: a, reason: collision with root package name */
    public int f4528a = 0;

    /* renamed from: b, reason: collision with root package name */
    public boolean f4529b = false;

    /* renamed from: c, reason: collision with root package name */
    public float f4530c = -1.0f;

    /* renamed from: d, reason: collision with root package name */
    public float f4531d = -1.0f;
    public float e = -1.0f;

    /* renamed from: f, reason: collision with root package name */
    public int[] f4532f = new int[0];

    /* renamed from: g, reason: collision with root package name */
    public boolean f4533g = false;

    /* renamed from: h, reason: collision with root package name */
    public TextPaint f4534h;
    public final TextView i;

    /* renamed from: j, reason: collision with root package name */
    public final Context f4535j;

    /* renamed from: k, reason: collision with root package name */
    public final C0311g0 f4536k;

    public C0319k0(TextView textView) {
        this.i = textView;
        this.f4535j = textView.getContext();
        if (Build.VERSION.SDK_INT >= 29) {
            this.f4536k = new C0315i0();
        } else {
            this.f4536k = new C0311g0();
        }
    }

    public static int[] b(int[] iArr) {
        int length = iArr.length;
        if (length == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i)) < 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        if (length == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i3 = 0; i3 < size; i3++) {
            iArr2[i3] = ((Integer) arrayList.get(i3)).intValue();
        }
        return iArr2;
    }

    public static Method d(String str) throws SecurityException {
        try {
            ConcurrentHashMap concurrentHashMap = f4527m;
            Method declaredMethod = (Method) concurrentHashMap.get(str);
            if (declaredMethod == null && (declaredMethod = TextView.class.getDeclaredMethod(str, null)) != null) {
                declaredMethod.setAccessible(true);
                concurrentHashMap.put(str, declaredMethod);
            }
            return declaredMethod;
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e);
            return null;
        }
    }

    public static Object e(Object obj, String str, Object obj2) {
        try {
            return d(str).invoke(obj, null);
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e);
            return obj2;
        }
    }

    public final void a() {
        if (f()) {
            if (this.f4529b) {
                if (this.i.getMeasuredHeight() <= 0 || this.i.getMeasuredWidth() <= 0) {
                    return;
                }
                int measuredWidth = this.f4536k.b(this.i) ? 1048576 : (this.i.getMeasuredWidth() - this.i.getTotalPaddingLeft()) - this.i.getTotalPaddingRight();
                int height = (this.i.getHeight() - this.i.getCompoundPaddingBottom()) - this.i.getCompoundPaddingTop();
                if (measuredWidth <= 0 || height <= 0) {
                    return;
                }
                RectF rectF = f4526l;
                synchronized (rectF) {
                    try {
                        rectF.setEmpty();
                        rectF.right = measuredWidth;
                        rectF.bottom = height;
                        float fC = c(rectF);
                        if (fC != this.i.getTextSize()) {
                            g(0, fC);
                        }
                    } finally {
                    }
                }
            }
            this.f4529b = true;
        }
    }

    public final int c(RectF rectF) {
        CharSequence transformation;
        int length = this.f4532f.length;
        if (length == 0) {
            throw new IllegalStateException("No available text sizes to choose from.");
        }
        int i = length - 1;
        int i3 = 0;
        int i4 = 1;
        while (i4 <= i) {
            int i5 = (i4 + i) / 2;
            int i6 = this.f4532f[i5];
            TextView textView = this.i;
            CharSequence text = textView.getText();
            TransformationMethod transformationMethod = textView.getTransformationMethod();
            if (transformationMethod != null && (transformation = transformationMethod.getTransformation(text, textView)) != null) {
                text = transformation;
            }
            int maxLines = textView.getMaxLines();
            TextPaint textPaint = this.f4534h;
            if (textPaint == null) {
                this.f4534h = new TextPaint();
            } else {
                textPaint.reset();
            }
            this.f4534h.set(textView.getPaint());
            this.f4534h.setTextSize(i6);
            StaticLayout staticLayoutA = AbstractC0309f0.a(text, (Layout.Alignment) e(textView, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(rectF.right), maxLines, this.i, this.f4534h, this.f4536k);
            if ((maxLines == -1 || (staticLayoutA.getLineCount() <= maxLines && staticLayoutA.getLineEnd(staticLayoutA.getLineCount() - 1) == text.length())) && staticLayoutA.getHeight() <= rectF.bottom) {
                int i7 = i5 + 1;
                i3 = i4;
                i4 = i7;
            } else {
                i3 = i5 - 1;
                i = i3;
            }
        }
        return this.f4532f[i3];
    }

    public final boolean f() {
        return j() && this.f4528a != 0;
    }

    public final void g(int i, float f3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Context context = this.f4535j;
        float fApplyDimension = TypedValue.applyDimension(i, f3, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        TextView textView = this.i;
        if (fApplyDimension != textView.getPaint().getTextSize()) {
            textView.getPaint().setTextSize(fApplyDimension);
            boolean zIsInLayout = textView.isInLayout();
            if (textView.getLayout() != null) {
                this.f4529b = false;
                try {
                    Method methodD = d("nullLayouts");
                    if (methodD != null) {
                        methodD.invoke(textView, null);
                    }
                } catch (Exception e) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e);
                }
                if (zIsInLayout) {
                    textView.forceLayout();
                } else {
                    textView.requestLayout();
                }
                textView.invalidate();
            }
        }
    }

    public final boolean h() {
        if (j() && this.f4528a == 1) {
            if (!this.f4533g || this.f4532f.length == 0) {
                int iFloor = ((int) Math.floor((this.e - this.f4531d) / this.f4530c)) + 1;
                int[] iArr = new int[iFloor];
                for (int i = 0; i < iFloor; i++) {
                    iArr[i] = Math.round((i * this.f4530c) + this.f4531d);
                }
                this.f4532f = b(iArr);
            }
            this.f4529b = true;
        } else {
            this.f4529b = false;
        }
        return this.f4529b;
    }

    public final boolean i() {
        boolean z2 = this.f4532f.length > 0;
        this.f4533g = z2;
        if (z2) {
            this.f4528a = 1;
            this.f4531d = r0[0];
            this.e = r0[r1 - 1];
            this.f4530c = -1.0f;
        }
        return z2;
    }

    public final boolean j() {
        return !(this.i instanceof C0347z);
    }

    public final void k(float f3, float f4, float f5) {
        if (f3 <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f3 + "px) is less or equal to (0px)");
        }
        if (f4 <= f3) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f4 + "px) is less or equal to minimum auto-size text size (" + f3 + "px)");
        }
        if (f5 <= 0.0f) {
            throw new IllegalArgumentException("The auto-size step granularity (" + f5 + "px) is less or equal to (0px)");
        }
        this.f4528a = 1;
        this.f4531d = f3;
        this.e = f4;
        this.f4530c = f5;
        this.f4533g = false;
    }
}
