package n;

import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class f1 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public int f4502a;

    /* renamed from: b, reason: collision with root package name */
    public int f4503b;

    public f1(f1 f1Var) {
        super((ViewGroup.MarginLayoutParams) f1Var);
        this.f4502a = 0;
        this.f4502a = f1Var.f4502a;
    }

    public f1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f4502a = 0;
    }
}
