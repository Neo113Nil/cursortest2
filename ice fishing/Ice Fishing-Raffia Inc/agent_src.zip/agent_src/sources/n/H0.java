package n;

import android.database.DataSetObserver;

/* loaded from: classes.dex */
public final class H0 extends DataSetObserver {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ K0 f4342a;

    public H0(K0 k02) {
        this.f4342a = k02;
    }

    @Override // android.database.DataSetObserver
    public final void onChanged() {
        K0 k02 = this.f4342a;
        if (k02.f4352A.isShowing()) {
            k02.h();
        }
    }

    @Override // android.database.DataSetObserver
    public final void onInvalidated() {
        this.f4342a.dismiss();
    }
}
