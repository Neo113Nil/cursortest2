package n;

import android.content.res.Resources;

/* loaded from: classes.dex */
public abstract class S0 extends Resources {
}
