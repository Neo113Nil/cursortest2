package n;

import P.C0016d;
import P.InterfaceC0015c;
import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;

/* loaded from: classes.dex */
public abstract class I {
    public static boolean a(DragEvent dragEvent, TextView textView, Activity activity) {
        InterfaceC0015c fVar;
        activity.requestDragAndDropPermissions(dragEvent);
        int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
        textView.beginBatchEdit();
        try {
            Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                fVar = new A0.f(clipData, 3);
            } else {
                C0016d c0016d = new C0016d();
                c0016d.f885c = clipData;
                c0016d.f886d = 3;
                fVar = c0016d;
            }
            P.O.i(textView, fVar.i());
            textView.endBatchEdit();
            return true;
        } catch (Throwable th) {
            textView.endBatchEdit();
            throw th;
        }
    }

    public static boolean b(DragEvent dragEvent, View view, Activity activity) {
        InterfaceC0015c fVar;
        activity.requestDragAndDropPermissions(dragEvent);
        ClipData clipData = dragEvent.getClipData();
        if (Build.VERSION.SDK_INT >= 31) {
            fVar = new A0.f(clipData, 3);
        } else {
            C0016d c0016d = new C0016d();
            c0016d.f885c = clipData;
            c0016d.f886d = 3;
            fVar = c0016d;
        }
        P.O.i(view, fVar.i());
        return true;
    }
}
