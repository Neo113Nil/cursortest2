package n;

import androidx.appcompat.widget.Toolbar;
import m.C0287n;

/* loaded from: classes.dex */
public final /* synthetic */ class b1 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4487b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Toolbar f4488c;

    public /* synthetic */ b1(Toolbar toolbar, int i) {
        this.f4487b = i;
        this.f4488c = toolbar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f4487b) {
            case 0:
                e1 e1Var = this.f4488c.f1592N;
                C0287n c0287n = e1Var == null ? null : e1Var.f4500c;
                if (c0287n != null) {
                    c0287n.collapseActionView();
                    break;
                }
                break;
            default:
                this.f4488c.n();
                break;
        }
    }
}
