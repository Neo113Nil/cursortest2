package n;

/* loaded from: classes.dex */
public abstract class a1 extends S0 {
}
