package n;

import android.content.Context;
import android.view.View;
import android.view.Window;
import m.C0274a;

/* loaded from: classes.dex */
public final class i1 implements View.OnClickListener {

    /* renamed from: b, reason: collision with root package name */
    public final C0274a f4510b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ j1 f4511c;

    public i1(j1 j1Var) {
        this.f4511c = j1Var;
        Context context = j1Var.f4512a.getContext();
        CharSequence charSequence = j1Var.f4518h;
        C0274a c0274a = new C0274a();
        c0274a.e = 4096;
        c0274a.f4150g = 4096;
        c0274a.f4154l = null;
        c0274a.f4155m = null;
        c0274a.f4156n = false;
        c0274a.f4157o = false;
        c0274a.f4158p = 16;
        c0274a.i = context;
        c0274a.f4145a = charSequence;
        this.f4510b = c0274a;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        j1 j1Var = this.f4511c;
        Window.Callback callback = j1Var.f4520k;
        if (callback == null || !j1Var.f4521l) {
            return;
        }
        callback.onMenuItemSelected(0, this.f4510b);
    }
}
