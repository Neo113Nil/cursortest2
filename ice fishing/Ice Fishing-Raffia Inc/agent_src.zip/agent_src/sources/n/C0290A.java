package n;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.TextView;
import g.AbstractC0131a;

/* renamed from: n.A, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0290A {

    /* renamed from: a, reason: collision with root package name */
    public final TextView f4300a;

    /* renamed from: b, reason: collision with root package name */
    public final A0.f f4301b;

    public C0290A(TextView textView) {
        this.f4300a = textView;
        this.f4301b = new A0.f(textView);
    }

    public final InputFilter[] a(InputFilter[] inputFilterArr) {
        return ((L1.d) this.f4301b.f224c).E(inputFilterArr);
    }

    public final void b(AttributeSet attributeSet, int i) {
        TypedArray typedArrayObtainStyledAttributes = this.f4300a.getContext().obtainStyledAttributes(attributeSet, AbstractC0131a.i, i, 0);
        try {
            boolean z2 = typedArrayObtainStyledAttributes.hasValue(14) ? typedArrayObtainStyledAttributes.getBoolean(14, true) : true;
            typedArrayObtainStyledAttributes.recycle();
            d(z2);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void c(boolean z2) {
        ((L1.d) this.f4301b.f224c).p0(z2);
    }

    public final void d(boolean z2) {
        ((L1.d) this.f4301b.f224c).s0(z2);
    }
}
