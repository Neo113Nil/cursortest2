package n;

import P.AbstractC0036y;
import a.AbstractC0046a;
import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import k1.AbstractC0239g;

/* renamed from: n.e0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0307e0 extends TextView {

    /* renamed from: b, reason: collision with root package name */
    public final r f4493b;

    /* renamed from: c, reason: collision with root package name */
    public final C0299a0 f4494c;

    /* renamed from: d, reason: collision with root package name */
    public final C0295F f4495d;
    public C0290A e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4496f;

    /* renamed from: g, reason: collision with root package name */
    public C0326o f4497g;

    /* renamed from: h, reason: collision with root package name */
    public Future f4498h;

    public C0307e0(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    private C0290A getEmojiTextViewHelper() {
        if (this.e == null) {
            this.e = new C0290A(this);
        }
        return this.e;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        r rVar = this.f4493b;
        if (rVar != null) {
            rVar.a();
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    public final void g() {
        Future future = this.f4498h;
        if (future == null) {
            return;
        }
        try {
            this.f4498h = null;
            if (future.get() != null) {
                throw new ClassCastException();
            }
            if (Build.VERSION.SDK_INT >= 29) {
                throw null;
            }
            L1.d.I(this);
            throw null;
        } catch (InterruptedException | ExecutionException unused) {
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (o1.f4573c) {
            return super.getAutoSizeMaxTextSize();
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (o1.f4573c) {
            return super.getAutoSizeMinTextSize();
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.f4531d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (o1.f4573c) {
            return super.getAutoSizeStepGranularity();
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            return Math.round(c0299a0.i.f4530c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (o1.f4573c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0299a0 c0299a0 = this.f4494c;
        return c0299a0 != null ? c0299a0.i.f4532f : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (o1.f4573c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            return c0299a0.i.f4528a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return L1.d.y0(super.getCustomSelectionActionModeCallback());
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public InterfaceC0301b0 getSuperCaller() {
        if (this.f4497g == null) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 34) {
                this.f4497g = new C0305d0(this);
            } else if (i >= 28) {
                this.f4497g = new C0303c0(this);
            } else {
                this.f4497g = new C0326o(1, this);
            }
        }
        return this.f4497g;
    }

    public ColorStateList getSupportBackgroundTintList() {
        r rVar = this.f4493b;
        if (rVar != null) {
            return rVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        r rVar = this.f4493b;
        if (rVar != null) {
            return rVar.i();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f4494c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f4494c.e();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        g();
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        C0295F c0295f;
        if (Build.VERSION.SDK_INT >= 28 || (c0295f = this.f4495d) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) c0295f.f4335c;
        return textClassifier == null ? V.a((TextView) c0295f.f4334b) : textClassifier;
    }

    public N.d getTextMetricsParamsCompat() {
        return L1.d.I(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f4494c.getClass();
        C0299a0.h(editorInfo, inputConnectionOnCreateInputConnection, this);
        AbstractC0239g.t(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30 || i >= 33 || !onCheckIsTextEditor()) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        super.onLayout(z2, i, i3, i4, i5);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 == null || o1.f4573c) {
            return;
        }
        c0299a0.i.a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i3) {
        g();
        super.onMeasure(i, i3);
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i, int i3, int i4) {
        super.onTextChanged(charSequence, i, i3, i4);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 == null || o1.f4573c) {
            return;
        }
        C0319k0 c0319k0 = c0299a0.i;
        if (c0319k0.f()) {
            c0319k0.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i, int i3, int i4, int i5) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i3, i4, i5);
            return;
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.i(i, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.j(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (o1.f4573c) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.k(i);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        r rVar = this.f4493b;
        if (rVar != null) {
            rVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        r rVar = this.f4493b;
        if (rVar != null) {
            rVar.n(i);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(L1.d.z0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().a(i);
        } else {
            L1.d.t0(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().h(i);
        } else {
            L1.d.u0(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i) {
        L1.d.v0(this, i);
    }

    public void setPrecomputedText(N.e eVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        L1.d.I(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        r rVar = this.f4493b;
        if (rVar != null) {
            rVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        r rVar = this.f4493b;
        if (rVar != null) {
            rVar.t(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C0299a0 c0299a0 = this.f4494c;
        c0299a0.l(colorStateList);
        c0299a0.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C0299a0 c0299a0 = this.f4494c;
        c0299a0.m(mode);
        c0299a0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.g(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        C0295F c0295f;
        if (Build.VERSION.SDK_INT >= 28 || (c0295f = this.f4495d) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            c0295f.f4335c = textClassifier;
        }
    }

    public void setTextFuture(Future<N.e> future) {
        this.f4498h = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(N.d dVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = dVar.f778b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i = 1;
        if (textDirectionHeuristic2 != textDirectionHeuristic3 && textDirectionHeuristic2 != (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i = 7;
            }
        }
        setTextDirection(i);
        getPaint().set(dVar.f777a);
        setBreakStrategy(dVar.f779c);
        setHyphenationFrequency(dVar.f780d);
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i, float f3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        boolean z2 = o1.f4573c;
        if (z2) {
            super.setTextSize(i, f3);
            return;
        }
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 == null || z2) {
            return;
        }
        C0319k0 c0319k0 = c0299a0.i;
        if (c0319k0.f()) {
            return;
        }
        c0319k0.g(i, f3);
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i) {
        Typeface typefaceCreate;
        if (this.f4496f) {
            return;
        }
        if (typeface == null || i <= 0) {
            typefaceCreate = null;
        } else {
            Context context = getContext();
            AbstractC0046a abstractC0046a = H.g.f558a;
            if (context == null) {
                throw new IllegalArgumentException("Context cannot be null");
            }
            typefaceCreate = Typeface.create(typeface, i);
        }
        this.f4496f = true;
        if (typefaceCreate != null) {
            typeface = typefaceCreate;
        }
        try {
            super.setTypeface(typeface, i);
        } finally {
            this.f4496f = false;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0307e0(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Y0.a(context);
        this.f4496f = false;
        this.f4497g = null;
        X0.a(this, getContext());
        r rVar = new r(this);
        this.f4493b = rVar;
        rVar.k(attributeSet, i);
        C0299a0 c0299a0 = new C0299a0(this);
        this.f4494c = c0299a0;
        c0299a0.f(attributeSet, i);
        c0299a0.b();
        C0295F c0295f = new C0295F();
        c0295f.f4334b = this;
        this.f4495d = c0295f;
        getEmojiTextViewHelper().b(attributeSet, i);
    }

    @Override // android.widget.TextView
    public final void setLineHeight(int i, float f3) {
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 34) {
            getSuperCaller().e(i, f3);
        } else if (i3 >= 34) {
            AbstractC0036y.h(this, i, f3);
        } else {
            L1.d.v0(this, Math.round(TypedValue.applyDimension(i, f3, getResources().getDisplayMetrics())));
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i != 0 ? b1.e.A(context, i) : null, i3 != 0 ? b1.e.A(context, i3) : null, i4 != 0 ? b1.e.A(context, i4) : null, i5 != 0 ? b1.e.A(context, i5) : null);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i != 0 ? b1.e.A(context, i) : null, i3 != 0 ? b1.e.A(context, i3) : null, i4 != 0 ? b1.e.A(context, i4) : null, i5 != 0 ? b1.e.A(context, i5) : null);
        C0299a0 c0299a0 = this.f4494c;
        if (c0299a0 != null) {
            c0299a0.b();
        }
    }
}
