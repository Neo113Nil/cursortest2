package n;

import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public final class J0 implements View.OnTouchListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ K0 f4345b;

    public J0(K0 k02) {
        this.f4345b = k02;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        C0294E c0294e;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        K0 k02 = this.f4345b;
        if (action == 0 && (c0294e = k02.f4352A) != null && c0294e.isShowing() && x2 >= 0 && x2 < k02.f4352A.getWidth() && y2 >= 0 && y2 < k02.f4352A.getHeight()) {
            k02.f4372w.postDelayed(k02.f4368s, 250L);
            return false;
        }
        if (action != 1) {
            return false;
        }
        k02.f4372w.removeCallbacks(k02.f4368s);
        return false;
    }
}
