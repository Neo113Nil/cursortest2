package n;

/* loaded from: classes.dex */
public interface m1 {
}
