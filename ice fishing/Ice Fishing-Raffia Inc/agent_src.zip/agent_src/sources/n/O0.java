package n;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import m.C0282i;
import m.C0287n;
import m.MenuC0285l;

/* loaded from: classes.dex */
public final class O0 extends C0344x0 {

    /* renamed from: n, reason: collision with root package name */
    public final int f4383n;

    /* renamed from: o, reason: collision with root package name */
    public final int f4384o;

    /* renamed from: p, reason: collision with root package name */
    public L0 f4385p;

    /* renamed from: q, reason: collision with root package name */
    public C0287n f4386q;

    public O0(Context context, boolean z2) {
        super(context, z2);
        if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
            this.f4383n = 21;
            this.f4384o = 22;
        } else {
            this.f4383n = 22;
            this.f4384o = 21;
        }
    }

    @Override // n.C0344x0, android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        C0282i c0282i;
        int headersCount;
        int iPointToPosition;
        int i;
        if (this.f4385p != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                headersCount = headerViewListAdapter.getHeadersCount();
                c0282i = (C0282i) headerViewListAdapter.getWrappedAdapter();
            } else {
                c0282i = (C0282i) adapter;
                headersCount = 0;
            }
            C0287n c0287nB = (motionEvent.getAction() == 10 || (iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i = iPointToPosition - headersCount) < 0 || i >= c0282i.getCount()) ? null : c0282i.getItem(i);
            C0287n c0287n = this.f4386q;
            if (c0287n != c0287nB) {
                MenuC0285l menuC0285l = c0282i.f4198a;
                if (c0287n != null) {
                    this.f4385p.j(menuC0285l, c0287n);
                }
                this.f4386q = c0287nB;
                if (c0287nB != null) {
                    this.f4385p.n(menuC0285l, c0287nB);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i == this.f4383n) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        }
        if (listMenuItemView == null || i != this.f4384o) {
            return super.onKeyDown(i, keyEvent);
        }
        setSelection(-1);
        ListAdapter adapter = getAdapter();
        (adapter instanceof HeaderViewListAdapter ? (C0282i) ((HeaderViewListAdapter) adapter).getWrappedAdapter() : (C0282i) adapter).f4198a.c(false);
        return true;
    }

    public void setHoverListener(L0 l02) {
        this.f4385p = l02;
    }

    @Override // n.C0344x0, android.widget.AbsListView
    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
