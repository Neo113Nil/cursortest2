package n;

import android.widget.AbsListView;

/* renamed from: n.u0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0338u0 {
    public static boolean a(AbsListView absListView) {
        return absListView.isSelectedChildViewEnabled();
    }

    public static void b(AbsListView absListView, boolean z2) {
        absListView.setSelectedChildViewEnabled(z2);
    }
}
