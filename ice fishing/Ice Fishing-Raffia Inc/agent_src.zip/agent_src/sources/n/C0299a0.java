package n;

import P.AbstractC0036y;
import P.C0023k;
import a.AbstractC0046a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import g.AbstractC0131a;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* renamed from: n.a0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0299a0 {

    /* renamed from: a, reason: collision with root package name */
    public final TextView f4475a;

    /* renamed from: b, reason: collision with root package name */
    public Z0 f4476b;

    /* renamed from: c, reason: collision with root package name */
    public Z0 f4477c;

    /* renamed from: d, reason: collision with root package name */
    public Z0 f4478d;
    public Z0 e;

    /* renamed from: f, reason: collision with root package name */
    public Z0 f4479f;

    /* renamed from: g, reason: collision with root package name */
    public Z0 f4480g;

    /* renamed from: h, reason: collision with root package name */
    public Z0 f4481h;
    public final C0319k0 i;

    /* renamed from: j, reason: collision with root package name */
    public int f4482j = 0;

    /* renamed from: k, reason: collision with root package name */
    public int f4483k = -1;

    /* renamed from: l, reason: collision with root package name */
    public Typeface f4484l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f4485m;

    public C0299a0(TextView textView) {
        this.f4475a = textView;
        this.i = new C0319k0(textView);
    }

    public static Z0 c(Context context, C0343x c0343x, int i) {
        ColorStateList colorStateListF;
        synchronized (c0343x) {
            colorStateListF = c0343x.f4618a.f(context, i);
        }
        if (colorStateListF == null) {
            return null;
        }
        Z0 z02 = new Z0();
        z02.f4471d = true;
        z02.f4468a = colorStateListF;
        return z02;
    }

    public static void h(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        int i = Build.VERSION.SDK_INT;
        if (i >= 30 || inputConnection == null) {
            return;
        }
        CharSequence text = textView.getText();
        if (i >= 30) {
            P.W.d(editorInfo, text);
            return;
        }
        text.getClass();
        if (i >= 30) {
            P.W.d(editorInfo, text);
            return;
        }
        int i3 = editorInfo.initialSelStart;
        int i4 = editorInfo.initialSelEnd;
        int i5 = i3 > i4 ? i4 : i3;
        if (i3 <= i4) {
            i3 = i4;
        }
        int length = text.length();
        if (i5 < 0 || i3 > length) {
            L1.d.w0(editorInfo, null, 0, 0);
            return;
        }
        int i6 = editorInfo.inputType & 4095;
        if (i6 == 129 || i6 == 225 || i6 == 18) {
            L1.d.w0(editorInfo, null, 0, 0);
            return;
        }
        if (length <= 2048) {
            L1.d.w0(editorInfo, text, i5, i3);
            return;
        }
        int i7 = i3 - i5;
        int i8 = i7 > 1024 ? 0 : i7;
        int i9 = 2048 - i8;
        int iMin = Math.min(text.length() - i3, i9 - Math.min(i5, (int) (i9 * 0.8d)));
        int iMin2 = Math.min(i5, i9 - iMin);
        int i10 = i5 - iMin2;
        if (Character.isLowSurrogate(text.charAt(i10))) {
            i10++;
            iMin2--;
        }
        if (Character.isHighSurrogate(text.charAt((i3 + iMin) - 1))) {
            iMin--;
        }
        int i11 = iMin2 + i8;
        L1.d.w0(editorInfo, i8 != i7 ? TextUtils.concat(text.subSequence(i10, i10 + iMin2), text.subSequence(i3, iMin + i3)) : text.subSequence(i10, i11 + iMin + i10), iMin2, i11);
    }

    public final void a(Drawable drawable, Z0 z02) {
        if (drawable == null || z02 == null) {
            return;
        }
        C0343x.e(drawable, z02, this.f4475a.getDrawableState());
    }

    public final void b() {
        Z0 z02 = this.f4476b;
        TextView textView = this.f4475a;
        if (z02 != null || this.f4477c != null || this.f4478d != null || this.e != null) {
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            a(compoundDrawables[0], this.f4476b);
            a(compoundDrawables[1], this.f4477c);
            a(compoundDrawables[2], this.f4478d);
            a(compoundDrawables[3], this.e);
        }
        if (this.f4479f == null && this.f4480g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = textView.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f4479f);
        a(compoundDrawablesRelative[2], this.f4480g);
    }

    public final ColorStateList d() {
        Z0 z02 = this.f4481h;
        if (z02 != null) {
            return z02.f4468a;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        Z0 z02 = this.f4481h;
        if (z02 != null) {
            return z02.f4469b;
        }
        return null;
    }

    public final void f(AttributeSet attributeSet, int i) {
        boolean z2;
        boolean z3;
        String string;
        String string2;
        int i3;
        int i4;
        int i5;
        float dimensionPixelSize;
        ColorStateList colorStateList;
        int resourceId;
        int i6;
        int resourceId2;
        int i7;
        TextView textView = this.f4475a;
        Context context = textView.getContext();
        C0343x c0343xA = C0343x.a();
        int[] iArr = AbstractC0131a.f3070h;
        C0023k c0023kH = C0023k.h(context, attributeSet, iArr, i);
        P.O.l(textView, textView.getContext(), iArr, attributeSet, (TypedArray) c0023kH.f913c, i);
        TypedArray typedArray = (TypedArray) c0023kH.f913c;
        int resourceId3 = typedArray.getResourceId(0, -1);
        if (typedArray.hasValue(3)) {
            this.f4476b = c(context, c0343xA, typedArray.getResourceId(3, 0));
        }
        if (typedArray.hasValue(1)) {
            this.f4477c = c(context, c0343xA, typedArray.getResourceId(1, 0));
        }
        if (typedArray.hasValue(4)) {
            this.f4478d = c(context, c0343xA, typedArray.getResourceId(4, 0));
        }
        if (typedArray.hasValue(2)) {
            this.e = c(context, c0343xA, typedArray.getResourceId(2, 0));
        }
        if (typedArray.hasValue(5)) {
            this.f4479f = c(context, c0343xA, typedArray.getResourceId(5, 0));
        }
        if (typedArray.hasValue(6)) {
            this.f4480g = c(context, c0343xA, typedArray.getResourceId(6, 0));
        }
        c0023kH.j();
        boolean z4 = textView.getTransformationMethod() instanceof PasswordTransformationMethod;
        int[] iArr2 = AbstractC0131a.f3085x;
        if (resourceId3 != -1) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(resourceId3, iArr2);
            C0023k c0023k = new C0023k(context, typedArrayObtainStyledAttributes);
            if (z4 || !typedArrayObtainStyledAttributes.hasValue(14)) {
                z2 = false;
                z3 = false;
            } else {
                z2 = typedArrayObtainStyledAttributes.getBoolean(14, false);
                z3 = true;
            }
            n(context, c0023k);
            if (typedArrayObtainStyledAttributes.hasValue(15)) {
                string2 = typedArrayObtainStyledAttributes.getString(15);
                i7 = 13;
            } else {
                i7 = 13;
                string2 = null;
            }
            string = typedArrayObtainStyledAttributes.hasValue(i7) ? typedArrayObtainStyledAttributes.getString(i7) : null;
            c0023k.j();
        } else {
            z2 = false;
            z3 = false;
            string = null;
            string2 = null;
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i, 0);
        C0023k c0023k2 = new C0023k(context, typedArrayObtainStyledAttributes2);
        if (!z4 && typedArrayObtainStyledAttributes2.hasValue(14)) {
            z2 = typedArrayObtainStyledAttributes2.getBoolean(14, false);
            z3 = true;
        }
        boolean z5 = z2;
        int i8 = Build.VERSION.SDK_INT;
        if (typedArrayObtainStyledAttributes2.hasValue(15)) {
            string2 = typedArrayObtainStyledAttributes2.getString(15);
        }
        if (typedArrayObtainStyledAttributes2.hasValue(13)) {
            string = typedArrayObtainStyledAttributes2.getString(13);
        }
        if (i8 >= 28 && typedArrayObtainStyledAttributes2.hasValue(0) && typedArrayObtainStyledAttributes2.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        n(context, c0023k2);
        c0023k2.j();
        if (!z4 && z3) {
            textView.setAllCaps(z5);
        }
        Typeface typeface = this.f4484l;
        if (typeface != null) {
            if (this.f4483k == -1) {
                textView.setTypeface(typeface, this.f4482j);
            } else {
                textView.setTypeface(typeface);
            }
        }
        if (string != null) {
            Y.d(textView, string);
        }
        if (string2 != null) {
            X.b(textView, X.a(string2));
        }
        int[] iArr3 = AbstractC0131a.i;
        C0319k0 c0319k0 = this.i;
        Context context2 = c0319k0.f4535j;
        TypedArray typedArrayObtainStyledAttributes3 = context2.obtainStyledAttributes(attributeSet, iArr3, i, 0);
        TextView textView2 = c0319k0.i;
        P.O.l(textView2, textView2.getContext(), iArr3, attributeSet, typedArrayObtainStyledAttributes3, i);
        if (typedArrayObtainStyledAttributes3.hasValue(5)) {
            c0319k0.f4528a = typedArrayObtainStyledAttributes3.getInt(5, 0);
        }
        float dimension = typedArrayObtainStyledAttributes3.hasValue(4) ? typedArrayObtainStyledAttributes3.getDimension(4, -1.0f) : -1.0f;
        float dimension2 = typedArrayObtainStyledAttributes3.hasValue(2) ? typedArrayObtainStyledAttributes3.getDimension(2, -1.0f) : -1.0f;
        float dimension3 = typedArrayObtainStyledAttributes3.hasValue(1) ? typedArrayObtainStyledAttributes3.getDimension(1, -1.0f) : -1.0f;
        if (typedArrayObtainStyledAttributes3.hasValue(3) && (resourceId2 = typedArrayObtainStyledAttributes3.getResourceId(3, 0)) > 0) {
            TypedArray typedArrayObtainTypedArray = typedArrayObtainStyledAttributes3.getResources().obtainTypedArray(resourceId2);
            int length = typedArrayObtainTypedArray.length();
            int[] iArr4 = new int[length];
            if (length > 0) {
                for (int i9 = 0; i9 < length; i9++) {
                    iArr4[i9] = typedArrayObtainTypedArray.getDimensionPixelSize(i9, -1);
                }
                c0319k0.f4532f = C0319k0.b(iArr4);
                c0319k0.i();
            }
            typedArrayObtainTypedArray.recycle();
        }
        typedArrayObtainStyledAttributes3.recycle();
        if (!c0319k0.j()) {
            c0319k0.f4528a = 0;
        } else if (c0319k0.f4528a == 1) {
            if (!c0319k0.f4533g) {
                DisplayMetrics displayMetrics = context2.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    i6 = 2;
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                } else {
                    i6 = 2;
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(i6, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                c0319k0.k(dimension2, dimension3, dimension);
            }
            c0319k0.h();
        }
        if (o1.f4573c && c0319k0.f4528a != 0) {
            int[] iArr5 = c0319k0.f4532f;
            if (iArr5.length > 0) {
                if (Y.a(textView) != -1.0f) {
                    Y.b(textView, Math.round(c0319k0.f4531d), Math.round(c0319k0.e), Math.round(c0319k0.f4530c), 0);
                } else {
                    Y.c(textView, iArr5, 0);
                }
            }
        }
        TypedArray typedArrayObtainStyledAttributes4 = context.obtainStyledAttributes(attributeSet, iArr3);
        int resourceId4 = typedArrayObtainStyledAttributes4.getResourceId(8, -1);
        Drawable drawableB = resourceId4 != -1 ? c0343xA.b(context, resourceId4) : null;
        int resourceId5 = typedArrayObtainStyledAttributes4.getResourceId(13, -1);
        Drawable drawableB2 = resourceId5 != -1 ? c0343xA.b(context, resourceId5) : null;
        int resourceId6 = typedArrayObtainStyledAttributes4.getResourceId(9, -1);
        Drawable drawableB3 = resourceId6 != -1 ? c0343xA.b(context, resourceId6) : null;
        int resourceId7 = typedArrayObtainStyledAttributes4.getResourceId(6, -1);
        Drawable drawableB4 = resourceId7 != -1 ? c0343xA.b(context, resourceId7) : null;
        int resourceId8 = typedArrayObtainStyledAttributes4.getResourceId(10, -1);
        Drawable drawableB5 = resourceId8 != -1 ? c0343xA.b(context, resourceId8) : null;
        int resourceId9 = typedArrayObtainStyledAttributes4.getResourceId(7, -1);
        Drawable drawableB6 = resourceId9 != -1 ? c0343xA.b(context, resourceId9) : null;
        if (drawableB5 != null || drawableB6 != null) {
            Drawable[] compoundDrawablesRelative = textView.getCompoundDrawablesRelative();
            if (drawableB5 == null) {
                drawableB5 = compoundDrawablesRelative[0];
            }
            if (drawableB2 == null) {
                drawableB2 = compoundDrawablesRelative[1];
            }
            if (drawableB6 == null) {
                drawableB6 = compoundDrawablesRelative[2];
            }
            if (drawableB4 == null) {
                drawableB4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawableB5, drawableB2, drawableB6, drawableB4);
        } else if (drawableB != null || drawableB2 != null || drawableB3 != null || drawableB4 != null) {
            Drawable[] compoundDrawablesRelative2 = textView.getCompoundDrawablesRelative();
            Drawable drawable = compoundDrawablesRelative2[0];
            if (drawable == null && compoundDrawablesRelative2[2] == null) {
                Drawable[] compoundDrawables = textView.getCompoundDrawables();
                if (drawableB == null) {
                    drawableB = compoundDrawables[0];
                }
                if (drawableB2 == null) {
                    drawableB2 = compoundDrawables[1];
                }
                if (drawableB3 == null) {
                    drawableB3 = compoundDrawables[2];
                }
                if (drawableB4 == null) {
                    drawableB4 = compoundDrawables[3];
                }
                textView.setCompoundDrawablesWithIntrinsicBounds(drawableB, drawableB2, drawableB3, drawableB4);
            } else {
                if (drawableB2 == null) {
                    drawableB2 = compoundDrawablesRelative2[1];
                }
                if (drawableB4 == null) {
                    drawableB4 = compoundDrawablesRelative2[3];
                }
                textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawableB2, compoundDrawablesRelative2[2], drawableB4);
            }
        }
        if (typedArrayObtainStyledAttributes4.hasValue(11)) {
            if (!typedArrayObtainStyledAttributes4.hasValue(11) || (resourceId = typedArrayObtainStyledAttributes4.getResourceId(11, 0)) == 0 || (colorStateList = AbstractC0046a.z(context, resourceId)) == null) {
                colorStateList = typedArrayObtainStyledAttributes4.getColorStateList(11);
            }
            textView.setCompoundDrawableTintList(colorStateList);
        }
        if (typedArrayObtainStyledAttributes4.hasValue(12)) {
            i3 = -1;
            textView.setCompoundDrawableTintMode(AbstractC0332r0.c(typedArrayObtainStyledAttributes4.getInt(12, -1), null));
        } else {
            i3 = -1;
        }
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes4.getDimensionPixelSize(15, i3);
        int dimensionPixelSize3 = typedArrayObtainStyledAttributes4.getDimensionPixelSize(18, i3);
        if (typedArrayObtainStyledAttributes4.hasValue(19)) {
            TypedValue typedValuePeekValue = typedArrayObtainStyledAttributes4.peekValue(19);
            if (typedValuePeekValue == null || typedValuePeekValue.type != 5) {
                i4 = -1;
                dimensionPixelSize = typedArrayObtainStyledAttributes4.getDimensionPixelSize(19, -1);
                i5 = -1;
            } else {
                int i10 = typedValuePeekValue.data;
                int i11 = i10 & 15;
                dimensionPixelSize = TypedValue.complexToFloat(i10);
                i5 = i11;
                i4 = -1;
            }
        } else {
            i4 = -1;
            i5 = -1;
            dimensionPixelSize = -1.0f;
        }
        typedArrayObtainStyledAttributes4.recycle();
        if (dimensionPixelSize2 != i4) {
            L1.d.t0(textView, dimensionPixelSize2);
        }
        if (dimensionPixelSize3 != i4) {
            L1.d.u0(textView, dimensionPixelSize3);
        }
        if (dimensionPixelSize != -1.0f) {
            if (i5 == i4) {
                L1.d.v0(textView, (int) dimensionPixelSize);
            } else if (Build.VERSION.SDK_INT >= 34) {
                AbstractC0036y.h(textView, i5, dimensionPixelSize);
            } else {
                L1.d.v0(textView, Math.round(TypedValue.applyDimension(i5, dimensionPixelSize, textView.getResources().getDisplayMetrics())));
            }
        }
    }

    public final void g(Context context, int i) {
        String string;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i, AbstractC0131a.f3085x);
        C0023k c0023k = new C0023k(context, typedArrayObtainStyledAttributes);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(14);
        TextView textView = this.f4475a;
        if (zHasValue) {
            textView.setAllCaps(typedArrayObtainStyledAttributes.getBoolean(14, false));
        }
        if (typedArrayObtainStyledAttributes.hasValue(0) && typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        n(context, c0023k);
        if (typedArrayObtainStyledAttributes.hasValue(13) && (string = typedArrayObtainStyledAttributes.getString(13)) != null) {
            Y.d(textView, string);
        }
        c0023k.j();
        Typeface typeface = this.f4484l;
        if (typeface != null) {
            textView.setTypeface(typeface, this.f4482j);
        }
    }

    public final void i(int i, int i3, int i4, int i5) {
        C0319k0 c0319k0 = this.i;
        if (c0319k0.j()) {
            DisplayMetrics displayMetrics = c0319k0.f4535j.getResources().getDisplayMetrics();
            c0319k0.k(TypedValue.applyDimension(i5, i, displayMetrics), TypedValue.applyDimension(i5, i3, displayMetrics), TypedValue.applyDimension(i5, i4, displayMetrics));
            if (c0319k0.h()) {
                c0319k0.a();
            }
        }
    }

    public final void j(int[] iArr, int i) {
        C0319k0 c0319k0 = this.i;
        if (c0319k0.j()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArrCopyOf = new int[length];
                if (i == 0) {
                    iArrCopyOf = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = c0319k0.f4535j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArrCopyOf[i3] = Math.round(TypedValue.applyDimension(i, iArr[i3], displayMetrics));
                    }
                }
                c0319k0.f4532f = C0319k0.b(iArrCopyOf);
                if (!c0319k0.i()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                c0319k0.f4533g = false;
            }
            if (c0319k0.h()) {
                c0319k0.a();
            }
        }
    }

    public final void k(int i) {
        C0319k0 c0319k0 = this.i;
        if (c0319k0.j()) {
            if (i == 0) {
                c0319k0.f4528a = 0;
                c0319k0.f4531d = -1.0f;
                c0319k0.e = -1.0f;
                c0319k0.f4530c = -1.0f;
                c0319k0.f4532f = new int[0];
                c0319k0.f4529b = false;
                return;
            }
            if (i != 1) {
                throw new IllegalArgumentException(H.e.g("Unknown auto-size text type: ", i));
            }
            DisplayMetrics displayMetrics = c0319k0.f4535j.getResources().getDisplayMetrics();
            c0319k0.k(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (c0319k0.h()) {
                c0319k0.a();
            }
        }
    }

    public final void l(ColorStateList colorStateList) {
        if (this.f4481h == null) {
            this.f4481h = new Z0();
        }
        Z0 z02 = this.f4481h;
        z02.f4468a = colorStateList;
        z02.f4471d = colorStateList != null;
        this.f4476b = z02;
        this.f4477c = z02;
        this.f4478d = z02;
        this.e = z02;
        this.f4479f = z02;
        this.f4480g = z02;
    }

    public final void m(PorterDuff.Mode mode) {
        if (this.f4481h == null) {
            this.f4481h = new Z0();
        }
        Z0 z02 = this.f4481h;
        z02.f4469b = mode;
        z02.f4470c = mode != null;
        this.f4476b = z02;
        this.f4477c = z02;
        this.f4478d = z02;
        this.e = z02;
        this.f4479f = z02;
        this.f4480g = z02;
    }

    public final void n(Context context, C0023k c0023k) {
        String string;
        int i = this.f4482j;
        TypedArray typedArray = (TypedArray) c0023k.f913c;
        this.f4482j = typedArray.getInt(2, i);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 28) {
            int i4 = typedArray.getInt(11, -1);
            this.f4483k = i4;
            if (i4 != -1) {
                this.f4482j &= 2;
            }
        }
        if (!typedArray.hasValue(10) && !typedArray.hasValue(12)) {
            if (typedArray.hasValue(1)) {
                this.f4485m = false;
                int i5 = typedArray.getInt(1, 1);
                if (i5 == 1) {
                    this.f4484l = Typeface.SANS_SERIF;
                    return;
                } else if (i5 == 2) {
                    this.f4484l = Typeface.SERIF;
                    return;
                } else {
                    if (i5 != 3) {
                        return;
                    }
                    this.f4484l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.f4484l = null;
        int i6 = typedArray.hasValue(12) ? 12 : 10;
        int i7 = this.f4483k;
        int i8 = this.f4482j;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceE = c0023k.e(i6, this.f4482j, new W(this, i7, i8, new WeakReference(this.f4475a)));
                if (typefaceE != null) {
                    if (i3 < 28 || this.f4483k == -1) {
                        this.f4484l = typefaceE;
                    } else {
                        this.f4484l = Z.a(Typeface.create(typefaceE, 0), this.f4483k, (this.f4482j & 2) != 0);
                    }
                }
                this.f4485m = this.f4484l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f4484l != null || (string = typedArray.getString(i6)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.f4483k == -1) {
            this.f4484l = Typeface.create(string, this.f4482j);
        } else {
            this.f4484l = Z.a(Typeface.create(string, 0), this.f4483k, (this.f4482j & 2) != 0);
        }
    }
}
