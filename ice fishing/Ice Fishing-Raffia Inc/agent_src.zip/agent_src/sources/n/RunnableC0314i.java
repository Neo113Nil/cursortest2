package n;

import android.view.View;
import m.InterfaceC0283j;
import m.MenuC0285l;

/* renamed from: n.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0314i implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final C0310g f4508b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0320l f4509c;

    public RunnableC0314i(C0320l c0320l, C0310g c0310g) {
        this.f4509c = c0320l;
        this.f4508b = c0310g;
    }

    @Override // java.lang.Runnable
    public final void run() {
        InterfaceC0283j interfaceC0283j;
        C0320l c0320l = this.f4509c;
        MenuC0285l menuC0285l = c0320l.f4539d;
        if (menuC0285l != null && (interfaceC0283j = menuC0285l.e) != null) {
            interfaceC0283j.g(menuC0285l);
        }
        View view = (View) c0320l.i;
        if (view != null && view.getWindowToken() != null) {
            C0310g c0310g = this.f4508b;
            if (c0310g.b()) {
                c0320l.f4554u = c0310g;
            } else if (c0310g.e != null) {
                c0310g.d(0, 0, false, false);
                c0320l.f4554u = c0310g;
            }
        }
        c0320l.f4556w = null;
    }
}
