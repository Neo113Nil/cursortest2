package e0;

import android.view.animation.Interpolator;

/* renamed from: e0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractInterpolatorC0118b implements Interpolator {

    /* renamed from: a, reason: collision with root package name */
    public final float[] f2938a;

    /* renamed from: b, reason: collision with root package name */
    public final float f2939b;

    public AbstractInterpolatorC0118b(float[] fArr) {
        this.f2938a = fArr;
        this.f2939b = 1.0f / (fArr.length - 1);
    }

    @Override // android.animation.TimeInterpolator
    public final float getInterpolation(float f3) {
        if (f3 >= 1.0f) {
            return 1.0f;
        }
        if (f3 <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f2938a;
        int iMin = Math.min((int) ((fArr.length - 1) * f3), fArr.length - 2);
        float f4 = this.f2939b;
        float f5 = (f3 - (iMin * f4)) / f4;
        float f6 = fArr[iMin];
        return ((fArr[iMin + 1] - f6) * f5) + f6;
    }
}
