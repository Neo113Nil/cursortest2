package b1;

import A0.f;
import X0.C0040c;
import android.graphics.Typeface;

/* loaded from: classes.dex */
public final class a extends e {

    /* renamed from: c, reason: collision with root package name */
    public final Typeface f2046c;

    /* renamed from: d, reason: collision with root package name */
    public final f f2047d;
    public boolean e;

    public a(f fVar, Typeface typeface) {
        this.f2046c = typeface;
        this.f2047d = fVar;
    }

    @Override // b1.e
    public final void W(int i) {
        if (this.e) {
            return;
        }
        C0040c c0040c = (C0040c) this.f2047d.f224c;
        if (c0040c.j(this.f2046c)) {
            c0040c.h(false);
        }
    }

    @Override // b1.e
    public final void X(Typeface typeface, boolean z2) {
        if (this.e) {
            return;
        }
        C0040c c0040c = (C0040c) this.f2047d.f224c;
        if (c0040c.j(typeface)) {
            c0040c.h(false);
        }
    }
}
