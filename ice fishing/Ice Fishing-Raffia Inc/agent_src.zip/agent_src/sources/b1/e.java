package b1;

import P.G;
import P.O;
import S.g;
import W1.l;
import X1.i;
import a.AbstractC0046a;
import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.lifecycle.Y;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;
import d2.j;
import e1.C0122d;
import e1.C0124f;
import e1.C0125g;
import e1.u;
import i2.h;
import i2.o;
import j.C0192a;
import j0.AbstractC0193A;
import j0.C0198c;
import j0.C0203h;
import j0.D;
import j0.F;
import j0.H;
import j0.I;
import j0.J;
import j0.S;
import j0.T;
import j0.V;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.WeakHashMap;
import l.AbstractC0257a;
import n.R0;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public abstract class e implements g {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f2064b = 0;

    public static Drawable A(Context context, int i) {
        return R0.b().c(context, i);
    }

    public static String F(Class cls) {
        LinkedHashMap linkedHashMap = V.f3666b;
        String strValue = (String) linkedHashMap.get(cls);
        if (strValue == null) {
            T t2 = (T) cls.getAnnotation(T.class);
            strValue = t2 != null ? t2.value() : null;
            if (strValue == null || strValue.length() <= 0) {
                throw new IllegalArgumentException("No @Navigator.Name annotation found for ".concat(cls.getSimpleName()).toString());
            }
            linkedHashMap.put(cls, strValue);
        }
        i.b(strValue);
        return strValue;
    }

    public static boolean L(EditText editText) {
        return editText.getInputType() != 0;
    }

    public static final boolean P(char c3) {
        return Character.isWhitespace(c3) || Character.isSpaceChar(c3);
    }

    public static Typeface Q(Configuration configuration, Typeface typeface) {
        if (Build.VERSION.SDK_INT < 31 || configuration.fontWeightAdjustment == Integer.MAX_VALUE || configuration.fontWeightAdjustment == 0 || typeface == null) {
            return null;
        }
        return Typeface.create(typeface, AbstractC0046a.i(configuration.fontWeightAdjustment + typeface.getWeight(), 1, 1000), typeface.isItalic());
    }

    public static final ArrayList R(Map map, l lVar) {
        i.e(map, "<this>");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Map.Entry entry : map.entrySet()) {
            C0203h c0203h = (C0203h) entry.getValue();
            Boolean boolValueOf = c0203h != null ? Boolean.valueOf(c0203h.f3698b) : null;
            i.b(boolValueOf);
            if (!boolValueOf.booleanValue() && !c0203h.f3699c) {
                linkedHashMap.put(entry.getKey(), entry.getValue());
            }
        }
        Set setKeySet = linkedHashMap.keySet();
        ArrayList arrayList = new ArrayList();
        for (Object obj : setKeySet) {
            if (((Boolean) lVar.h((String) obj)).booleanValue()) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    public static final I S(l lVar) {
        J j3 = new J();
        lVar.h(j3);
        boolean z2 = j3.f3639b;
        H h3 = j3.f3638a;
        h3.f3624a = z2;
        h3.f3625b = j3.f3640c;
        int i = j3.f3641d;
        boolean z3 = j3.e;
        h3.f3626c = i;
        h3.f3627d = false;
        h3.e = z3;
        return h3.a();
    }

    public static i2.d d(int i, int i3, int i4) {
        i2.d oVar;
        if ((i4 & 2) != 0) {
            i3 = 1;
        }
        if (i != -2) {
            if (i == -1) {
                if (i3 == 1) {
                    return new o(1, 2, null);
                }
                throw new IllegalArgumentException("CONFLATED capacity cannot be used with non-default onBufferOverflow");
            }
            if (i != 0) {
                return i != Integer.MAX_VALUE ? i3 == 1 ? new i2.d(i, null) : new o(i, i3, null) : new i2.d(Integer.MAX_VALUE, null);
            }
            oVar = i3 == 1 ? new i2.d(0, null) : new o(1, i3, null);
        } else if (i3 == 1) {
            h.f3559a.getClass();
            oVar = new i2.d(i2.g.f3558b, null);
        } else {
            oVar = new o(1, i3, null);
        }
        return oVar;
    }

    public static void d0(TextInputLayout textInputLayout, CheckableImageButton checkableImageButton, ColorStateList colorStateList) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (checkableImageButton.getDrawable() == null || colorStateList == null || !colorStateList.isStateful()) {
            return;
        }
        int[] drawableState = textInputLayout.getDrawableState();
        int[] drawableState2 = checkableImageButton.getDrawableState();
        int length = drawableState.length;
        int[] iArrCopyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
        System.arraycopy(drawableState2, 0, iArrCopyOf, length, drawableState2.length);
        int colorForState = colorStateList.getColorForState(iArrCopyOf, colorStateList.getDefaultColor());
        Drawable drawableMutate = drawable.mutate();
        drawableMutate.setTintList(ColorStateList.valueOf(colorForState));
        checkableImageButton.setImageDrawable(drawableMutate);
    }

    public static void f(StringBuilder sb, Object obj, l lVar) {
        if (lVar != null) {
            sb.append((CharSequence) lVar.h(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) obj.toString());
        }
    }

    public static void g(TextInputLayout textInputLayout, CheckableImageButton checkableImageButton, ColorStateList colorStateList, PorterDuff.Mode mode) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (drawable != null) {
            drawable = drawable.mutate();
            if (colorStateList == null || !colorStateList.isStateful()) {
                drawable.setTintList(colorStateList);
            } else {
                int[] drawableState = textInputLayout.getDrawableState();
                int[] drawableState2 = checkableImageButton.getDrawableState();
                int length = drawableState.length;
                int[] iArrCopyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
                System.arraycopy(drawableState2, 0, iArrCopyOf, length, drawableState2.length);
                drawable.setTintList(ColorStateList.valueOf(colorStateList.getColorForState(iArrCopyOf, colorStateList.getDefaultColor())));
            }
            if (mode != null) {
                drawable.setTintMode(mode);
            }
        }
        if (checkableImageButton.getDrawable() != drawable) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public static int h(View view) {
        i.e(view, "<this>");
        if (view.getAlpha() == 0.0f && view.getVisibility() == 0) {
            return 4;
        }
        int visibility = view.getVisibility();
        if (visibility == 0) {
            return 2;
        }
        if (visibility == 4) {
            return 4;
        }
        if (visibility == 8) {
            return 3;
        }
        throw new IllegalArgumentException(H.e.g("Unknown visibility ", visibility));
    }

    public static void i0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        WeakHashMap weakHashMap = O.f854a;
        boolean zHasOnClickListeners = checkableImageButton.hasOnClickListeners();
        boolean z2 = onLongClickListener != null;
        boolean z3 = zHasOnClickListeners || z2;
        checkableImageButton.setFocusable(z3);
        checkableImageButton.setClickable(zHasOnClickListeners);
        checkableImageButton.setPressable(zHasOnClickListeners);
        checkableImageButton.setLongClickable(z2);
        checkableImageButton.setImportantForAccessibility(z3 ? 1 : 2);
    }

    public static void j0(View view, C0125g c0125g) {
        W0.a aVar = c0125g.f2959b.f2945b;
        if (aVar == null || !aVar.f1189a) {
            return;
        }
        float fE = 0.0f;
        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
            WeakHashMap weakHashMap = O.f854a;
            fE += G.e((View) parent);
        }
        C0124f c0124f = c0125g.f2959b;
        if (c0124f.f2953l != fE) {
            c0124f.f2953l = fE;
            c0125g.q();
        }
    }

    public static S k(TypedValue typedValue, S s2, S s3, String str, String str2) throws XmlPullParserException {
        if (s2 == null || s2 == s3) {
            return s2 == null ? s3 : s2;
        }
        throw new XmlPullParserException("Type is " + str + " but found " + str2 + ": " + typedValue.data);
    }

    public static void l(int i) {
        if (2 > i || i >= 37) {
            throw new IllegalArgumentException("radix " + i + " was not in valid range " + new b2.c(2, 36, 1));
        }
    }

    public static int n(int i, int i3, int i4) {
        if (i3 <= i4) {
            return i < i3 ? i3 : i > i4 ? i4 : i;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i4 + " is less than minimum " + i3 + '.');
    }

    public static final long p(long j3, f2.c cVar, f2.c cVar2) {
        i.e(cVar, "sourceUnit");
        i.e(cVar2, "targetUnit");
        return cVar2.f3061b.convert(j3, cVar.f3061b);
    }

    public static int p0(Context context, int i) throws Resources.NotFoundException {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(R.style.Animation.Activity, new int[]{i});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, -1);
        typedArrayObtainStyledAttributes.recycle();
        return resourceId;
    }

    public static ImageView.ScaleType q(int i) {
        return i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 5 ? i != 6 ? ImageView.ScaleType.CENTER : ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_END : ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.FIT_START : ImageView.ScaleType.FIT_XY;
    }

    public static e r(int i) {
        if (i != 0 && i == 1) {
            return new C0122d();
        }
        return new e1.i();
    }

    public static Y s(Class cls) throws IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException {
        try {
            Object objNewInstance = cls.getDeclaredConstructor(null).newInstance(null);
            i.b(objNewInstance);
            return (Y) objNewInstance;
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Cannot create an instance of " + cls, e);
        } catch (InstantiationException e3) {
            throw new RuntimeException("Cannot create an instance of " + cls, e3);
        } catch (NoSuchMethodException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        }
    }

    public static final F u(View view) {
        i.e(view, "view");
        d2.c cVar = new d2.c(new d2.d(new d2.d(d2.h.t0(view, C0198c.f3684o), C0198c.f3685p, 3), new j(0), 0));
        F f3 = (F) (!cVar.hasNext() ? null : cVar.next());
        if (f3 != null) {
            return f3;
        }
        throw new IllegalStateException("View " + view + " does not have a NavController set");
    }

    public static AbstractC0193A v(D d3) {
        i.e(d3, "<this>");
        Iterator it = d2.h.t0(d3, C0198c.f3683n).iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException("Sequence is empty.");
        }
        Object next = it.next();
        while (it.hasNext()) {
            next = it.next();
        }
        return (AbstractC0193A) next;
    }

    public static String y(Context context, int i) {
        String strValueOf;
        i.e(context, "context");
        if (i <= 16777215) {
            return String.valueOf(i);
        }
        try {
            strValueOf = context.getResources().getResourceName(i);
        } catch (Resources.NotFoundException unused) {
            strValueOf = String.valueOf(i);
        }
        i.d(strValueOf, "try {\n                  …tring()\n                }");
        return strValueOf;
    }

    public abstract int B();

    public abstract int C();

    public abstract int D();

    public abstract int E();

    public abstract int G(View view);

    public abstract int H(CoordinatorLayout coordinatorLayout);

    public abstract int I();

    public abstract Context J();

    public boolean K() {
        return false;
    }

    public abstract boolean M(float f3);

    public abstract boolean N(View view);

    public abstract boolean O(float f3, float f4);

    public abstract void T();

    public void U() {
    }

    public abstract View V(int i);

    public abstract void W(int i);

    public abstract void X(Typeface typeface, boolean z2);

    public abstract boolean Y();

    public abstract boolean Z(int i, KeyEvent keyEvent);

    public boolean a0(KeyEvent keyEvent) {
        return false;
    }

    public boolean b0() {
        return false;
    }

    public abstract Object c0(int i, Intent intent);

    public abstract void e0(boolean z2);

    public abstract void f0(boolean z2);

    public abstract void g0(int i);

    public abstract void h0(C0192a c0192a);

    public abstract int i(ViewGroup.MarginLayoutParams marginLayoutParams);

    public abstract float j(int i);

    public abstract void k0(boolean z2);

    public abstract void l0(String str);

    public boolean m() {
        return false;
    }

    public abstract void m0(CharSequence charSequence);

    public abstract boolean n0(View view, float f3);

    public abstract boolean o();

    public AbstractC0257a o0(A.i iVar) {
        return null;
    }

    public abstract void q0(ViewGroup.MarginLayoutParams marginLayoutParams, int i);

    public abstract void r0(ViewGroup.MarginLayoutParams marginLayoutParams, int i, int i3);

    public abstract void t(boolean z2);

    public abstract int w(ViewGroup.MarginLayoutParams marginLayoutParams);

    public abstract void x(u uVar, float f3, float f4);

    public abstract int z();
}
