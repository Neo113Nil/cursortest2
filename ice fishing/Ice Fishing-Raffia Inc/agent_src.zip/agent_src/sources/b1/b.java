package b1;

import android.graphics.Typeface;

/* loaded from: classes.dex */
public final class b extends G.b {

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ e f2048h;
    public final /* synthetic */ d i;

    public b(d dVar, e eVar) {
        this.i = dVar;
        this.f2048h = eVar;
    }

    @Override // G.b
    public final void g(int i) {
        this.i.f2062m = true;
        this.f2048h.W(i);
    }

    @Override // G.b
    public final void h(Typeface typeface) {
        d dVar = this.i;
        dVar.f2063n = Typeface.create(typeface, dVar.f2054c);
        dVar.f2062m = true;
        this.f2048h.X(dVar.f2063n, false);
    }
}
