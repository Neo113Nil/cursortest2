package b1;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextPaint;

/* loaded from: classes.dex */
public final class c extends e {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Context f2049c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ TextPaint f2050d;
    public final /* synthetic */ e e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ d f2051f;

    public c(d dVar, Context context, TextPaint textPaint, e eVar) {
        this.f2051f = dVar;
        this.f2049c = context;
        this.f2050d = textPaint;
        this.e = eVar;
    }

    @Override // b1.e
    public final void W(int i) {
        this.e.W(i);
    }

    @Override // b1.e
    public final void X(Typeface typeface, boolean z2) {
        this.f2051f.g(this.f2049c, this.f2050d, typeface);
        this.e.X(typeface, z2);
    }
}
