package b1;

import G.n;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.Log;
import android.util.TypedValue;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final ColorStateList f2052a;

    /* renamed from: b, reason: collision with root package name */
    public final String f2053b;

    /* renamed from: c, reason: collision with root package name */
    public final int f2054c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2055d;
    public final float e;

    /* renamed from: f, reason: collision with root package name */
    public final float f2056f;

    /* renamed from: g, reason: collision with root package name */
    public final float f2057g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f2058h;
    public final float i;

    /* renamed from: j, reason: collision with root package name */
    public final ColorStateList f2059j;

    /* renamed from: k, reason: collision with root package name */
    public float f2060k;

    /* renamed from: l, reason: collision with root package name */
    public final int f2061l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f2062m = false;

    /* renamed from: n, reason: collision with root package name */
    public Typeface f2063n;

    public d(Context context, int i) throws Resources.NotFoundException {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i, I0.a.f578I);
        this.f2060k = typedArrayObtainStyledAttributes.getDimension(0, 0.0f);
        this.f2059j = L1.d.z(context, typedArrayObtainStyledAttributes, 3);
        L1.d.z(context, typedArrayObtainStyledAttributes, 4);
        L1.d.z(context, typedArrayObtainStyledAttributes, 5);
        this.f2054c = typedArrayObtainStyledAttributes.getInt(2, 0);
        this.f2055d = typedArrayObtainStyledAttributes.getInt(1, 1);
        int i3 = typedArrayObtainStyledAttributes.hasValue(12) ? 12 : 10;
        this.f2061l = typedArrayObtainStyledAttributes.getResourceId(i3, 0);
        this.f2053b = typedArrayObtainStyledAttributes.getString(i3);
        typedArrayObtainStyledAttributes.getBoolean(14, false);
        this.f2052a = L1.d.z(context, typedArrayObtainStyledAttributes, 6);
        this.e = typedArrayObtainStyledAttributes.getFloat(7, 0.0f);
        this.f2056f = typedArrayObtainStyledAttributes.getFloat(8, 0.0f);
        this.f2057g = typedArrayObtainStyledAttributes.getFloat(9, 0.0f);
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(i, I0.a.f603y);
        this.f2058h = typedArrayObtainStyledAttributes2.hasValue(0);
        this.i = typedArrayObtainStyledAttributes2.getFloat(0, 0.0f);
        typedArrayObtainStyledAttributes2.recycle();
    }

    public final void a() {
        String str;
        Typeface typeface = this.f2063n;
        int i = this.f2054c;
        if (typeface == null && (str = this.f2053b) != null) {
            this.f2063n = Typeface.create(str, i);
        }
        if (this.f2063n == null) {
            int i3 = this.f2055d;
            if (i3 == 1) {
                this.f2063n = Typeface.SANS_SERIF;
            } else if (i3 == 2) {
                this.f2063n = Typeface.SERIF;
            } else if (i3 != 3) {
                this.f2063n = Typeface.DEFAULT;
            } else {
                this.f2063n = Typeface.MONOSPACE;
            }
            this.f2063n = Typeface.create(this.f2063n, i);
        }
    }

    public final Typeface b(Context context) {
        if (this.f2062m) {
            return this.f2063n;
        }
        if (!context.isRestricted()) {
            try {
                Typeface typefaceA = n.a(context, this.f2061l);
                this.f2063n = typefaceA;
                if (typefaceA != null) {
                    this.f2063n = Typeface.create(typefaceA, this.f2054c);
                }
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            } catch (Exception e) {
                Log.d("TextAppearance", "Error loading font " + this.f2053b, e);
            }
        }
        a();
        this.f2062m = true;
        return this.f2063n;
    }

    public final void c(Context context, e eVar) {
        if (d(context)) {
            b(context);
        } else {
            a();
        }
        int i = this.f2061l;
        if (i == 0) {
            this.f2062m = true;
        }
        if (this.f2062m) {
            eVar.X(this.f2063n, true);
            return;
        }
        try {
            b bVar = new b(this, eVar);
            ThreadLocal threadLocal = n.f527a;
            if (context.isRestricted()) {
                bVar.a(-4);
            } else {
                n.b(context, i, new TypedValue(), 0, bVar, false, false);
            }
        } catch (Resources.NotFoundException unused) {
            this.f2062m = true;
            eVar.W(1);
        } catch (Exception e) {
            Log.d("TextAppearance", "Error loading font " + this.f2053b, e);
            this.f2062m = true;
            eVar.W(-3);
        }
    }

    public final boolean d(Context context) throws InterruptedException, Resources.NotFoundException {
        Typeface typefaceB = null;
        int i = this.f2061l;
        if (i != 0) {
            ThreadLocal threadLocal = n.f527a;
            if (!context.isRestricted()) {
                typefaceB = n.b(context, i, new TypedValue(), 0, null, false, true);
            }
        }
        return typefaceB != null;
    }

    public final void e(Context context, TextPaint textPaint, e eVar) {
        f(context, textPaint, eVar);
        ColorStateList colorStateList = this.f2059j;
        textPaint.setColor(colorStateList != null ? colorStateList.getColorForState(textPaint.drawableState, colorStateList.getDefaultColor()) : -16777216);
        ColorStateList colorStateList2 = this.f2052a;
        textPaint.setShadowLayer(this.f2057g, this.e, this.f2056f, colorStateList2 != null ? colorStateList2.getColorForState(textPaint.drawableState, colorStateList2.getDefaultColor()) : 0);
    }

    public final void f(Context context, TextPaint textPaint, e eVar) {
        if (d(context)) {
            g(context, textPaint, b(context));
            return;
        }
        a();
        g(context, textPaint, this.f2063n);
        c(context, new c(this, context, textPaint, eVar));
    }

    public final void g(Context context, TextPaint textPaint, Typeface typeface) {
        Typeface typefaceQ = e.Q(context.getResources().getConfiguration(), typeface);
        if (typefaceQ != null) {
            typeface = typefaceQ;
        }
        textPaint.setTypeface(typeface);
        int i = (~typeface.getStyle()) & this.f2054c;
        textPaint.setFakeBoldText((i & 1) != 0);
        textPaint.setTextSkewX((i & 2) != 0 ? -0.25f : 0.0f);
        textPaint.setTextSize(this.f2060k);
        if (this.f2058h) {
            textPaint.setLetterSpacing(this.i);
        }
    }
}
