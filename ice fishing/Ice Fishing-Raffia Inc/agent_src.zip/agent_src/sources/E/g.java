package E;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f302a;

    public g(boolean z2) {
        this.f302a = z2;
    }
}
