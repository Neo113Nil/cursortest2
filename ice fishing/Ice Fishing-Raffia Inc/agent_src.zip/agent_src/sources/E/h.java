package E;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f303a;

    public h(boolean z2) {
        this.f303a = z2;
    }
}
