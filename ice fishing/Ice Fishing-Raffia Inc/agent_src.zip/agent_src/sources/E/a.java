package E;

import M.k;
import P.C0023k;
import Y.s;
import a.AbstractC0046a;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Trace;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.C0078w;
import androidx.lifecycle.EnumC0069m;
import androidx.lifecycle.G;
import b.j;
import b.l;
import c0.AbstractComponentCallbacksC0110w;
import c0.P;
import com.google.android.material.carousel.CarouselLayoutManager;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;
import com.kortosi.kluani.qorzanis.ui.home.DropInFragment;
import e1.C0123e;
import h.AbstractActivityC0180i;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import java.util.Iterator;
import l0.m;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f285b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f286c;

    public /* synthetic */ a(int i, Object obj) {
        this.f285b = i;
        this.f286c = obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r3v15 */
    /* JADX WARN: Type inference failed for: r3v16 */
    /* JADX WARN: Type inference failed for: r3v17 */
    /* JADX WARN: Type inference failed for: r3v18 */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v2, types: [android.os.Handler] */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [android.os.Handler] */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v9 */
    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        Application application;
        c cVar;
        int i = 0;
        int i3 = 1;
        switch (this.f285b) {
            case 0:
                Activity activity = (Activity) this.f286c;
                if (activity.isFinishing()) {
                    return;
                }
                int i4 = Build.VERSION.SDK_INT;
                if (i4 >= 28) {
                    Class cls = d.f295a;
                    activity.recreate();
                    return;
                }
                Class cls2 = d.f295a;
                ?? r6 = 26;
                ?? r7 = i4 == 26 || i4 == 27;
                Method method = d.f299f;
                if ((r7 == false || method != null) && (d.e != null || d.f298d != null)) {
                    try {
                        Object obj2 = d.f297c.get(activity);
                        if (obj2 != null && (obj = d.f296b.get(activity)) != null) {
                            Application application2 = activity.getApplication();
                            c cVar2 = new c(activity);
                            application2.registerActivityLifecycleCallbacks(cVar2);
                            Handler handler = d.f300g;
                            handler.post(new b(cVar2, i, obj2));
                            try {
                                if ((i4 == 26 || i4 == 27) == true) {
                                    try {
                                        Boolean bool = Boolean.FALSE;
                                        r6 = handler;
                                        cVar = cVar2;
                                        application = application2;
                                        method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                                    } catch (Throwable th) {
                                        th = th;
                                        r6 = handler;
                                        cVar = cVar2;
                                        application = application2;
                                        r6.post(new b(application, cVar, i3, 0 == true ? 1 : 0));
                                        throw th;
                                    }
                                } else {
                                    r6 = handler;
                                    cVar = cVar2;
                                    application = application2;
                                    activity.recreate();
                                }
                                r6.post(new b(application, cVar, i3, 0 == true ? 1 : 0));
                                return;
                            } catch (Throwable th2) {
                                th = th2;
                            }
                        }
                    } catch (Throwable unused) {
                    }
                }
                activity.recreate();
                return;
            case 1:
                ((CarouselLayoutManager) this.f286c).o0();
                return;
            case 2:
                View view = (View) this.f286c;
                ((InputMethodManager) view.getContext().getSystemService(InputMethodManager.class)).showSoftInput(view, 1);
                return;
            case 3:
                s sVar = (s) this.f286c;
                synchronized (sVar.f1402d) {
                    try {
                        if (sVar.f1405h == null) {
                            return;
                        }
                        try {
                            k kVarC = sVar.c();
                            int i5 = kVarC.e;
                            if (i5 == 2) {
                                synchronized (sVar.f1402d) {
                                }
                            }
                            if (i5 != 0) {
                                throw new RuntimeException("fetchFonts result is not OK. (" + i5 + ")");
                            }
                            try {
                                Method method2 = L.d.f692b;
                                Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                                C0123e c0123e = sVar.f1401c;
                                Context context = sVar.f1399a;
                                c0123e.getClass();
                                k[] kVarArr = {kVarC};
                                AbstractC0046a abstractC0046a = H.g.f558a;
                                AbstractC0046a.b("TypefaceCompat.createFromFontInfo");
                                try {
                                    Typeface typefaceP = H.g.f558a.p(context, kVarArr, 0);
                                    Trace.endSection();
                                    MappedByteBuffer mappedByteBufferI = AbstractC0046a.I(sVar.f1399a, kVarC.f760a);
                                    if (mappedByteBufferI == null || typefaceP == null) {
                                        throw new RuntimeException("Unable to open file.");
                                    }
                                    try {
                                        Trace.beginSection("EmojiCompat.MetadataRepo.create");
                                        C.k kVar = new C.k(typefaceP, L1.d.h0(mappedByteBufferI));
                                        Trace.endSection();
                                        synchronized (sVar.f1402d) {
                                            try {
                                                L1.d dVar = sVar.f1405h;
                                                if (dVar != null) {
                                                    dVar.a0(kVar);
                                                }
                                            } finally {
                                            }
                                        }
                                        sVar.b();
                                        return;
                                    } finally {
                                        Method method3 = L.d.f692b;
                                    }
                                } finally {
                                    Trace.endSection();
                                }
                            } finally {
                            }
                        } catch (Throwable th3) {
                            synchronized (sVar.f1402d) {
                                try {
                                    L1.d dVar2 = sVar.f1405h;
                                    if (dVar2 != null) {
                                        dVar2.Z(th3);
                                    }
                                    sVar.b();
                                    return;
                                } finally {
                                }
                            }
                        }
                    } finally {
                    }
                }
            case 4:
                C0023k c0023k = (C0023k) this.f286c;
                Y0.d dVar3 = (Y0.d) c0023k.f912b;
                if (dVar3 != null) {
                    dVar3.b((Y0.b) c0023k.f913c, (NavigationView) c0023k.f914d, true);
                    return;
                }
                return;
            case 5:
                G g3 = (G) this.f286c;
                int i6 = g3.f1752c;
                C0078w c0078w = g3.f1755g;
                if (i6 == 0) {
                    g3.f1753d = true;
                    c0078w.d(EnumC0069m.ON_PAUSE);
                }
                if (g3.f1751b == 0 && g3.f1753d) {
                    c0078w.d(EnumC0069m.ON_STOP);
                    g3.e = true;
                    return;
                }
                return;
            case 6:
                ((AbstractActivityC0180i) this.f286c).invalidateOptionsMenu();
                return;
            case 7:
                j jVar = (j) this.f286c;
                Runnable runnable = jVar.f1998c;
                if (runnable != null) {
                    runnable.run();
                    jVar.f1998c = null;
                    return;
                }
                return;
            case 8:
                l.a((l) this.f286c);
                return;
            case 9:
                AbstractComponentCallbacksC0110w abstractComponentCallbacksC0110w = (AbstractComponentCallbacksC0110w) this.f286c;
                abstractComponentCallbacksC0110w.f2303R.f2181g.L(abstractComponentCallbacksC0110w.e);
                abstractComponentCallbacksC0110w.e = null;
                return;
            case 10:
                Iterator it = ((P) this.f286c).f2125n.iterator();
                while (it.hasNext()) {
                    ((m) it.next()).getClass();
                }
                return;
            case 11:
                ((com.google.android.material.timepicker.e) this.f286c).m();
                return;
            case 12:
                N0.g gVar = (N0.g) this.f286c;
                gVar.f802c = false;
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) gVar.e;
                V.f fVar = sideSheetBehavior.f2645j;
                if (fVar != null && fVar.g()) {
                    gVar.a(gVar.f801b);
                    return;
                } else {
                    if (sideSheetBehavior.i == 2) {
                        sideSheetBehavior.x(gVar.f801b);
                        return;
                    }
                    return;
                }
            case 13:
                ((h1.d) this.f286c).t(true);
                return;
            case 14:
                h1.j jVar2 = (h1.j) this.f286c;
                boolean zIsPopupShowing = jVar2.f3417h.isPopupShowing();
                jVar2.t(zIsPopupShowing);
                jVar2.f3421m = zIsPopupShowing;
                return;
            case 15:
                ((TextInputLayout) this.f286c).e.requestLayout();
                return;
            default:
                DropInFragment dropInFragment = (DropInFragment) this.f286c;
                if (dropInFragment.f2856g0) {
                    return;
                }
                dropInFragment.f2856g0 = true;
                dropInFragment.P().f5291o.scheduleLayoutAnimation();
                return;
        }
    }
}
