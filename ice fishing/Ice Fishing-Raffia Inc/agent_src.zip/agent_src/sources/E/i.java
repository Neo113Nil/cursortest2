package E;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class i implements Iterable {

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f304b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    public final Context f305c;

    public i(Context context) {
        this.f305c = context;
    }

    public final void a(ComponentName componentName) {
        Context context = this.f305c;
        ArrayList arrayList = this.f304b;
        int size = arrayList.size();
        try {
            for (Intent intentA = e.a(context, componentName); intentA != null; intentA = e.a(context, intentA.getComponent())) {
                arrayList.add(size, intentA);
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
            throw new IllegalArgumentException(e);
        }
    }

    public final void b() {
        ArrayList arrayList = this.f304b;
        if (arrayList.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        this.f305c.startActivities(intentArr, null);
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return this.f304b.iterator();
    }
}
