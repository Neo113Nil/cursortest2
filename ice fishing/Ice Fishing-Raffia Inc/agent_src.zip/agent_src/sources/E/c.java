package E;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

/* loaded from: classes.dex */
public final class c implements Application.ActivityLifecycleCallbacks {

    /* renamed from: a, reason: collision with root package name */
    public Object f290a;

    /* renamed from: b, reason: collision with root package name */
    public Activity f291b;

    /* renamed from: c, reason: collision with root package name */
    public final int f292c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f293d = false;
    public boolean e = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f294f = false;

    public c(Activity activity) {
        this.f291b = activity;
        this.f292c = activity.hashCode();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
        if (this.f291b == activity) {
            this.f291b = null;
            this.e = true;
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
        if (!this.e || this.f294f || this.f293d) {
            return;
        }
        Object obj = this.f290a;
        try {
            Object obj2 = d.f297c.get(activity);
            if (obj2 == obj && activity.hashCode() == this.f292c) {
                d.f300g.postAtFrontOfQueue(new b(d.f296b.get(activity), obj2, 2, false));
                this.f294f = true;
                this.f290a = null;
            }
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while fetching field values", th);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
        if (this.f291b == activity) {
            this.f293d = true;
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
    }
}
