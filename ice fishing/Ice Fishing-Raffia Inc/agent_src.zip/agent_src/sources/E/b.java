package E;

import N1.j;
import P.O;
import android.app.Application;
import android.graphics.Typeface;
import android.util.Log;
import android.view.View;
import com.google.android.material.behavior.SwipeDismissBehavior;
import g2.AbstractC0155t;
import g2.AbstractC0160y;
import g2.C0143g;
import g2.S;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import n.C0326o;
import p0.C0373d;
import p0.C0374e;
import p0.C0384o;
import p0.C0385p;
import p0.C0386q;
import p0.RunnableC0372c;

/* loaded from: classes.dex */
public final class b implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f287b;

    /* renamed from: c, reason: collision with root package name */
    public Object f288c;

    /* renamed from: d, reason: collision with root package name */
    public final Object f289d;

    public /* synthetic */ b(Object obj, int i, Object obj2) {
        this.f287b = i;
        this.f288c = obj;
        this.f289d = obj2;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x0118  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        int i;
        C0385p c0385p;
        int i3;
        int i4;
        int i5;
        int i6;
        Object obj = this.f289d;
        switch (this.f287b) {
            case 0:
                ((c) this.f288c).f290a = obj;
                return;
            case 1:
                ((Application) obj).unregisterActivityLifecycleCallbacks((c) this.f288c);
                return;
            case 2:
                try {
                    Method method = d.f298d;
                    Object obj2 = this.f288c;
                    if (method != null) {
                        method.invoke(obj, obj2, Boolean.FALSE, "AppCompat recreation");
                    } else {
                        d.e.invoke(obj, obj2, Boolean.FALSE);
                    }
                    return;
                } catch (RuntimeException e) {
                    if (e.getClass() == RuntimeException.class && e.getMessage() != null && e.getMessage().startsWith("Unable to stop")) {
                        throw e;
                    }
                    return;
                } catch (Throwable th) {
                    Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
                    return;
                }
            case 3:
                V.f fVar = ((SwipeDismissBehavior) obj).f2393b;
                if (fVar == null || !fVar.g()) {
                    return;
                }
                WeakHashMap weakHashMap = O.f854a;
                ((View) this.f288c).postOnAnimation(this);
                return;
            case 4:
                G.b bVar = (G.b) ((A0.f) this.f288c).f224c;
                if (bVar != null) {
                    bVar.h((Typeface) obj);
                    return;
                }
                return;
            case 5:
                ((M.g) this.f288c).a(obj);
                return;
            case 6:
                ((C0143g) obj).E((S) this.f288c);
                return;
            case 7:
                ((C0143g) this.f288c).E((h2.e) obj);
                return;
            case 8:
                int i7 = 0;
                while (true) {
                    try {
                        ((Runnable) this.f288c).run();
                    } catch (Throwable th2) {
                        AbstractC0160y.h(j.f809b, th2);
                    }
                    l2.i iVar = (l2.i) obj;
                    Runnable runnableL = iVar.L();
                    if (runnableL == null) {
                        return;
                    }
                    this.f288c = runnableL;
                    i7++;
                    if (i7 >= 16) {
                        AbstractC0155t abstractC0155t = iVar.f4095d;
                        if (abstractC0155t.J()) {
                            abstractC0155t.H(iVar, this);
                            return;
                        }
                    }
                }
            default:
                RunnableC0372c runnableC0372c = (RunnableC0372c) obj;
                C0373d c0373d = runnableC0372c.f4880f;
                if (c0373d.f4887g == runnableC0372c.f4879d) {
                    List list = runnableC0372c.f4878c;
                    c0373d.e = list;
                    c0373d.f4886f = Collections.unmodifiableList(list);
                    C0385p c0385p2 = (C0385p) this.f288c;
                    C0374e c0374e = new C0374e(c0373d.f4882a);
                    ArrayDeque arrayDeque = new ArrayDeque();
                    ArrayList arrayList = c0385p2.f4991a;
                    int size = arrayList.size() - 1;
                    int i8 = c0385p2.e;
                    int i9 = c0385p2.f4995f;
                    int i10 = i8;
                    while (size >= 0) {
                        C0384o c0384o = (C0384o) arrayList.get(size);
                        int i11 = c0384o.f4982a;
                        int i12 = c0384o.f4984c;
                        int i13 = i11 + i12;
                        int i14 = c0384o.f4983b;
                        int i15 = i14 + i12;
                        while (true) {
                            int[] iArr = c0385p2.f4992b;
                            ArrayList arrayList2 = arrayList;
                            C0326o c0326o = c0385p2.f4994d;
                            if (i10 > i13) {
                                i10--;
                                int i16 = iArr[i10];
                                if ((i16 & 12) != 0) {
                                    i4 = i9;
                                    int i17 = i16 >> 4;
                                    i5 = i13;
                                    C0386q c0386qA = C0385p.a(arrayDeque, i17, false);
                                    if (c0386qA != null) {
                                        int i18 = (i8 - c0386qA.f4998b) - 1;
                                        c0374e.c(i10, i18);
                                        if ((i16 & 4) != 0) {
                                            c0326o.l(i10, i17);
                                            c0374e.b(i18, 1);
                                        }
                                    } else {
                                        arrayDeque.add(new C0386q(i10, (i8 - i10) - 1, true));
                                    }
                                } else {
                                    i4 = i9;
                                    i5 = i13;
                                    if (c0374e.f4890b != 2 || (i6 = c0374e.f4891c) < i10 || i6 > i10 + 1) {
                                        c0374e.a();
                                        c0374e.f4891c = i10;
                                        c0374e.f4892d = 1;
                                        c0374e.f4890b = 2;
                                    } else {
                                        c0374e.f4892d++;
                                        c0374e.f4891c = i10;
                                    }
                                    i8--;
                                }
                                arrayList = arrayList2;
                                i9 = i4;
                                i13 = i5;
                            } else {
                                while (i9 > i15) {
                                    i9--;
                                    int i19 = c0385p2.f4993c[i9];
                                    if ((i19 & 12) != 0) {
                                        int i20 = i19 >> 4;
                                        i = i15;
                                        c0385p = c0385p2;
                                        C0386q c0386qA2 = C0385p.a(arrayDeque, i20, true);
                                        if (c0386qA2 == null) {
                                            arrayDeque.add(new C0386q(i9, i8 - i10, false));
                                        } else {
                                            c0374e.c((i8 - c0386qA2.f4998b) - 1, i10);
                                            if ((i19 & 4) != 0) {
                                                c0326o.l(i20, i9);
                                                c0374e.b(i10, 1);
                                            }
                                        }
                                    } else {
                                        i = i15;
                                        c0385p = c0385p2;
                                        if (c0374e.f4890b != 1 || i10 < (i3 = c0374e.f4891c)) {
                                            c0374e.a();
                                            c0374e.f4891c = i10;
                                            c0374e.f4892d = 1;
                                            c0374e.f4890b = 1;
                                            i8++;
                                        } else {
                                            int i21 = c0374e.f4892d;
                                            if (i10 <= i3 + i21) {
                                                c0374e.f4892d = i21 + 1;
                                                c0374e.f4891c = Math.min(i10, i3);
                                            }
                                            i8++;
                                        }
                                    }
                                    i15 = i;
                                    c0385p2 = c0385p;
                                }
                                C0385p c0385p3 = c0385p2;
                                i10 = c0384o.f4982a;
                                int i22 = i10;
                                int i23 = i14;
                                for (int i24 = 0; i24 < i12; i24++) {
                                    if ((iArr[i22] & 15) == 2) {
                                        c0326o.l(i22, i23);
                                        c0374e.b(i22, 1);
                                    }
                                    i22++;
                                    i23++;
                                }
                                size--;
                                i9 = i14;
                                arrayList = arrayList2;
                                c0385p2 = c0385p3;
                            }
                        }
                    }
                    c0374e.a();
                    c0373d.a(runnableC0372c.e);
                    return;
                }
                return;
        }
    }

    public /* synthetic */ b(Object obj, Object obj2, int i, boolean z2) {
        this.f287b = i;
        this.f289d = obj;
        this.f288c = obj2;
    }

    public b(SwipeDismissBehavior swipeDismissBehavior, View view, boolean z2) {
        this.f287b = 3;
        this.f289d = swipeDismissBehavior;
        this.f288c = view;
    }
}
