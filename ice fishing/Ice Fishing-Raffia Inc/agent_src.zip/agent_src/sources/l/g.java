package l;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import m.C0287n;
import m.o;
import m.s;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: A, reason: collision with root package name */
    public CharSequence f3984A;

    /* renamed from: B, reason: collision with root package name */
    public CharSequence f3985B;

    /* renamed from: E, reason: collision with root package name */
    public final /* synthetic */ h f3988E;

    /* renamed from: a, reason: collision with root package name */
    public final Menu f3989a;

    /* renamed from: h, reason: collision with root package name */
    public boolean f3995h;
    public int i;

    /* renamed from: j, reason: collision with root package name */
    public int f3996j;

    /* renamed from: k, reason: collision with root package name */
    public CharSequence f3997k;

    /* renamed from: l, reason: collision with root package name */
    public CharSequence f3998l;

    /* renamed from: m, reason: collision with root package name */
    public int f3999m;

    /* renamed from: n, reason: collision with root package name */
    public char f4000n;

    /* renamed from: o, reason: collision with root package name */
    public int f4001o;

    /* renamed from: p, reason: collision with root package name */
    public char f4002p;

    /* renamed from: q, reason: collision with root package name */
    public int f4003q;

    /* renamed from: r, reason: collision with root package name */
    public int f4004r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f4005s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f4006t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f4007u;

    /* renamed from: v, reason: collision with root package name */
    public int f4008v;

    /* renamed from: w, reason: collision with root package name */
    public int f4009w;

    /* renamed from: x, reason: collision with root package name */
    public String f4010x;

    /* renamed from: y, reason: collision with root package name */
    public String f4011y;

    /* renamed from: z, reason: collision with root package name */
    public o f4012z;

    /* renamed from: C, reason: collision with root package name */
    public ColorStateList f3986C = null;

    /* renamed from: D, reason: collision with root package name */
    public PorterDuff.Mode f3987D = null;

    /* renamed from: b, reason: collision with root package name */
    public int f3990b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f3991c = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f3992d = 0;
    public int e = 0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f3993f = true;

    /* renamed from: g, reason: collision with root package name */
    public boolean f3994g = true;

    public g(h hVar, Menu menu) {
        this.f3988E = hVar;
        this.f3989a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) throws NoSuchMethodException, SecurityException {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f3988E.f4016c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e);
            return null;
        }
    }

    public final void b(MenuItem menuItem) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        boolean z2 = false;
        menuItem.setChecked(this.f4005s).setVisible(this.f4006t).setEnabled(this.f4007u).setCheckable(this.f4004r >= 1).setTitleCondensed(this.f3998l).setIcon(this.f3999m);
        int i = this.f4008v;
        if (i >= 0) {
            menuItem.setShowAsAction(i);
        }
        String str = this.f4011y;
        h hVar = this.f3988E;
        if (str != null) {
            if (hVar.f4016c.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            if (hVar.f4017d == null) {
                hVar.f4017d = h.a(hVar.f4016c);
            }
            Object obj = hVar.f4017d;
            String str2 = this.f4011y;
            f fVar = new f();
            fVar.f3982a = obj;
            Class<?> cls = obj.getClass();
            try {
                fVar.f3983b = cls.getMethod(str2, f.f3981c);
                menuItem.setOnMenuItemClickListener(fVar);
            } catch (Exception e) {
                StringBuilder sbK = H.e.k("Couldn't resolve menu item onClick handler ", str2, " in class ");
                sbK.append(cls.getName());
                InflateException inflateException = new InflateException(sbK.toString());
                inflateException.initCause(e);
                throw inflateException;
            }
        }
        if (this.f4004r >= 2) {
            if (menuItem instanceof C0287n) {
                ((C0287n) menuItem).g(true);
            } else if (menuItem instanceof s) {
                s sVar = (s) menuItem;
                try {
                    Method method = sVar.f4265d;
                    J.a aVar = sVar.f4264c;
                    if (method == null) {
                        sVar.f4265d = aVar.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                    }
                    sVar.f4265d.invoke(aVar, Boolean.TRUE);
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f4010x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, h.e, hVar.f4014a));
            z2 = true;
        }
        int i3 = this.f4009w;
        if (i3 > 0) {
            if (z2) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            } else {
                menuItem.setActionView(i3);
            }
        }
        o oVar = this.f4012z;
        if (oVar != null) {
            if (menuItem instanceof J.a) {
                ((J.a) menuItem).a(oVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f3984A;
        boolean z3 = menuItem instanceof J.a;
        if (z3) {
            ((J.a) menuItem).setContentDescription(charSequence);
        } else {
            menuItem.setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f3985B;
        if (z3) {
            ((J.a) menuItem).setTooltipText(charSequence2);
        } else {
            menuItem.setTooltipText(charSequence2);
        }
        char c3 = this.f4000n;
        int i4 = this.f4001o;
        if (z3) {
            ((J.a) menuItem).setAlphabeticShortcut(c3, i4);
        } else {
            menuItem.setAlphabeticShortcut(c3, i4);
        }
        char c4 = this.f4002p;
        int i5 = this.f4003q;
        if (z3) {
            ((J.a) menuItem).setNumericShortcut(c4, i5);
        } else {
            menuItem.setNumericShortcut(c4, i5);
        }
        PorterDuff.Mode mode = this.f3987D;
        if (mode != null) {
            if (z3) {
                ((J.a) menuItem).setIconTintMode(mode);
            } else {
                menuItem.setIconTintMode(mode);
            }
        }
        ColorStateList colorStateList = this.f3986C;
        if (colorStateList != null) {
            if (z3) {
                ((J.a) menuItem).setIconTintList(colorStateList);
            } else {
                menuItem.setIconTintList(colorStateList);
            }
        }
    }
}
