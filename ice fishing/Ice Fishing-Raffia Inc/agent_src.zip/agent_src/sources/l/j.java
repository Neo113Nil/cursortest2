package l;

import P.U;
import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: c, reason: collision with root package name */
    public BaseInterpolator f4023c;

    /* renamed from: d, reason: collision with root package name */
    public L1.d f4024d;
    public boolean e;

    /* renamed from: b, reason: collision with root package name */
    public long f4022b = -1;

    /* renamed from: f, reason: collision with root package name */
    public final i f4025f = new i(this);

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f4021a = new ArrayList();

    public final void a() {
        if (this.e) {
            Iterator it = this.f4021a.iterator();
            while (it.hasNext()) {
                ((U) it.next()).b();
            }
            this.e = false;
        }
    }

    public final void b() {
        View view;
        if (this.e) {
            return;
        }
        Iterator it = this.f4021a.iterator();
        while (it.hasNext()) {
            U u2 = (U) it.next();
            long j3 = this.f4022b;
            if (j3 >= 0) {
                u2.c(j3);
            }
            BaseInterpolator baseInterpolator = this.f4023c;
            if (baseInterpolator != null && (view = (View) u2.f866a.get()) != null) {
                view.animate().setInterpolator(baseInterpolator);
            }
            if (this.f4024d != null) {
                u2.d(this.f4025f);
            }
            View view2 = (View) u2.f866a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.e = true;
    }
}
