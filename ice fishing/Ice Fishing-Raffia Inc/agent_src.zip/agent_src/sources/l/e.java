package l;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import m.MenuC0270A;

/* loaded from: classes.dex */
public final class e extends ActionMode {

    /* renamed from: a, reason: collision with root package name */
    public final Context f3979a;

    /* renamed from: b, reason: collision with root package name */
    public final AbstractC0257a f3980b;

    public e(Context context, AbstractC0257a abstractC0257a) {
        this.f3979a = context;
        this.f3980b = abstractC0257a;
    }

    @Override // android.view.ActionMode
    public final void finish() {
        this.f3980b.a();
    }

    @Override // android.view.ActionMode
    public final View getCustomView() {
        return this.f3980b.b();
    }

    @Override // android.view.ActionMode
    public final Menu getMenu() {
        return new MenuC0270A(this.f3979a, this.f3980b.d());
    }

    @Override // android.view.ActionMode
    public final MenuInflater getMenuInflater() {
        return this.f3980b.e();
    }

    @Override // android.view.ActionMode
    public final CharSequence getSubtitle() {
        return this.f3980b.f();
    }

    @Override // android.view.ActionMode
    public final Object getTag() {
        return this.f3980b.f3968b;
    }

    @Override // android.view.ActionMode
    public final CharSequence getTitle() {
        return this.f3980b.h();
    }

    @Override // android.view.ActionMode
    public final boolean getTitleOptionalHint() {
        return this.f3980b.f3969c;
    }

    @Override // android.view.ActionMode
    public final void invalidate() {
        this.f3980b.i();
    }

    @Override // android.view.ActionMode
    public final boolean isTitleOptional() {
        return this.f3980b.j();
    }

    @Override // android.view.ActionMode
    public final void setCustomView(View view) {
        this.f3980b.k(view);
    }

    @Override // android.view.ActionMode
    public final void setSubtitle(CharSequence charSequence) {
        this.f3980b.m(charSequence);
    }

    @Override // android.view.ActionMode
    public final void setTag(Object obj) {
        this.f3980b.f3968b = obj;
    }

    @Override // android.view.ActionMode
    public final void setTitle(CharSequence charSequence) {
        this.f3980b.o(charSequence);
    }

    @Override // android.view.ActionMode
    public final void setTitleOptionalHint(boolean z2) {
        this.f3980b.p(z2);
    }

    @Override // android.view.ActionMode
    public final void setSubtitle(int i) {
        this.f3980b.l(i);
    }

    @Override // android.view.ActionMode
    public final void setTitle(int i) {
        this.f3980b.n(i);
    }
}
