package l;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;
import m.InterfaceC0283j;
import m.MenuC0285l;
import n.C0320l;

/* renamed from: l.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0260d extends AbstractC0257a implements InterfaceC0283j {

    /* renamed from: d, reason: collision with root package name */
    public Context f3975d;
    public ActionBarContextView e;

    /* renamed from: f, reason: collision with root package name */
    public A.i f3976f;

    /* renamed from: g, reason: collision with root package name */
    public WeakReference f3977g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f3978h;
    public MenuC0285l i;

    @Override // l.AbstractC0257a
    public final void a() {
        if (this.f3978h) {
            return;
        }
        this.f3978h = true;
        this.f3976f.G(this);
    }

    @Override // l.AbstractC0257a
    public final View b() {
        WeakReference weakReference = this.f3977g;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // m.InterfaceC0283j
    public final boolean c(MenuC0285l menuC0285l, MenuItem menuItem) {
        return ((C.k) this.f3976f.f94c).n(this, menuItem);
    }

    @Override // l.AbstractC0257a
    public final MenuC0285l d() {
        return this.i;
    }

    @Override // l.AbstractC0257a
    public final MenuInflater e() {
        return new h(this.e.getContext());
    }

    @Override // l.AbstractC0257a
    public final CharSequence f() {
        return this.e.getSubtitle();
    }

    @Override // m.InterfaceC0283j
    public final void g(MenuC0285l menuC0285l) {
        i();
        C0320l c0320l = this.e.e;
        if (c0320l != null) {
            c0320l.n();
        }
    }

    @Override // l.AbstractC0257a
    public final CharSequence h() {
        return this.e.getTitle();
    }

    @Override // l.AbstractC0257a
    public final void i() {
        this.f3976f.H(this, this.i);
    }

    @Override // l.AbstractC0257a
    public final boolean j() {
        return this.e.f1526t;
    }

    @Override // l.AbstractC0257a
    public final void k(View view) {
        this.e.setCustomView(view);
        this.f3977g = view != null ? new WeakReference(view) : null;
    }

    @Override // l.AbstractC0257a
    public final void l(int i) {
        m(this.f3975d.getString(i));
    }

    @Override // l.AbstractC0257a
    public final void m(CharSequence charSequence) {
        this.e.setSubtitle(charSequence);
    }

    @Override // l.AbstractC0257a
    public final void n(int i) {
        o(this.f3975d.getString(i));
    }

    @Override // l.AbstractC0257a
    public final void o(CharSequence charSequence) {
        this.e.setTitle(charSequence);
    }

    @Override // l.AbstractC0257a
    public final void p(boolean z2) {
        this.f3969c = z2;
        this.e.setTitleOptional(z2);
    }
}
