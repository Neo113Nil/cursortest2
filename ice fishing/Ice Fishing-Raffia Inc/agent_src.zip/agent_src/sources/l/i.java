package l;

import n.j1;

/* loaded from: classes.dex */
public final class i extends L1.d {
    public final /* synthetic */ int e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4018f;

    /* renamed from: g, reason: collision with root package name */
    public int f4019g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f4020h;

    public i(j jVar) {
        this.e = 0;
        this.f4020h = jVar;
        this.f4018f = false;
        this.f4019g = 0;
    }

    @Override // P.V
    public final void a() {
        switch (this.e) {
            case 0:
                int i = this.f4019g + 1;
                this.f4019g = i;
                j jVar = (j) this.f4020h;
                if (i == jVar.f4021a.size()) {
                    L1.d dVar = jVar.f4024d;
                    if (dVar != null) {
                        dVar.a();
                    }
                    this.f4019g = 0;
                    this.f4018f = false;
                    jVar.e = false;
                    break;
                }
                break;
            default:
                if (!this.f4018f) {
                    ((j1) this.f4020h).f4512a.setVisibility(this.f4019g);
                    break;
                }
                break;
        }
    }

    @Override // L1.d, P.V
    public void b() {
        switch (this.e) {
            case 1:
                this.f4018f = true;
                break;
        }
    }

    @Override // L1.d, P.V
    public final void c() {
        switch (this.e) {
            case 0:
                if (!this.f4018f) {
                    this.f4018f = true;
                    L1.d dVar = ((j) this.f4020h).f4024d;
                    if (dVar != null) {
                        dVar.c();
                        break;
                    }
                }
                break;
            default:
                ((j1) this.f4020h).f4512a.setVisibility(0);
                break;
        }
    }

    public i(j1 j1Var, int i) {
        this.e = 1;
        this.f4020h = j1Var;
        this.f4019g = i;
        this.f4018f = false;
    }
}
