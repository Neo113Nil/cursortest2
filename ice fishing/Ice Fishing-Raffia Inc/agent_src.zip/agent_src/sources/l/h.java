package l;

import a.AbstractC0046a;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.SubMenu;
import g.AbstractC0131a;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import m.MenuC0285l;
import m.o;
import n.AbstractC0332r0;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class h extends MenuInflater {
    public static final Class[] e;

    /* renamed from: f, reason: collision with root package name */
    public static final Class[] f4013f;

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f4014a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f4015b;

    /* renamed from: c, reason: collision with root package name */
    public final Context f4016c;

    /* renamed from: d, reason: collision with root package name */
    public Object f4017d;

    static {
        Class[] clsArr = {Context.class};
        e = clsArr;
        f4013f = clsArr;
    }

    public h(Context context) {
        super(context);
        this.f4016c = context;
        Object[] objArr = {context};
        this.f4014a = objArr;
        this.f4015b = objArr;
    }

    public static Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v60 */
    public final void b(XmlResourceParser xmlResourceParser, AttributeSet attributeSet, Menu menu) throws XmlPullParserException, IllegalAccessException, IOException, IllegalArgumentException, InvocationTargetException {
        ?? r4;
        int i;
        boolean z2;
        ColorStateList colorStateList;
        int resourceId;
        g gVar = new g(this, menu);
        int eventType = xmlResourceParser.getEventType();
        while (true) {
            r4 = 1;
            i = 2;
            if (eventType == 2) {
                String name = xmlResourceParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException("Expecting menu, got ".concat(name));
                }
                eventType = xmlResourceParser.next();
            } else {
                eventType = xmlResourceParser.next();
                if (eventType == 1) {
                    break;
                }
            }
        }
        boolean z3 = false;
        boolean z4 = false;
        String str = null;
        while (!z3) {
            if (eventType == r4) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != i) {
                if (eventType != 3) {
                    z2 = r4;
                } else {
                    String name2 = xmlResourceParser.getName();
                    if (z4 && name2.equals(str)) {
                        z2 = r4;
                        z4 = false;
                        str = null;
                    } else {
                        if (name2.equals("group")) {
                            gVar.f3990b = 0;
                            gVar.f3991c = 0;
                            gVar.f3992d = 0;
                            gVar.e = 0;
                            gVar.f3993f = r4;
                            gVar.f3994g = r4;
                        } else if (name2.equals("item")) {
                            if (!gVar.f3995h) {
                                o oVar = gVar.f4012z;
                                if (oVar == null || !oVar.f4257b.hasSubMenu()) {
                                    gVar.f3995h = r4;
                                    gVar.b(gVar.f3989a.add(gVar.f3990b, gVar.i, gVar.f3996j, gVar.f3997k));
                                } else {
                                    gVar.f3995h = r4;
                                    gVar.b(gVar.f3989a.addSubMenu(gVar.f3990b, gVar.i, gVar.f3996j, gVar.f3997k).getItem());
                                }
                            }
                        } else if (name2.equals("menu")) {
                            z2 = r4;
                            z3 = z2;
                        }
                        z2 = r4;
                    }
                }
                eventType = xmlResourceParser.next();
                r4 = z2;
                i = 2;
                z4 = z4;
            } else {
                if (!z4) {
                    String name3 = xmlResourceParser.getName();
                    boolean zEquals = name3.equals("group");
                    h hVar = gVar.f3988E;
                    if (zEquals) {
                        TypedArray typedArrayObtainStyledAttributes = hVar.f4016c.obtainStyledAttributes(attributeSet, AbstractC0131a.f3078q);
                        gVar.f3990b = typedArrayObtainStyledAttributes.getResourceId(r4, 0);
                        gVar.f3991c = typedArrayObtainStyledAttributes.getInt(3, 0);
                        gVar.f3992d = typedArrayObtainStyledAttributes.getInt(4, 0);
                        gVar.e = typedArrayObtainStyledAttributes.getInt(5, 0);
                        gVar.f3993f = typedArrayObtainStyledAttributes.getBoolean(2, r4);
                        gVar.f3994g = typedArrayObtainStyledAttributes.getBoolean(0, r4);
                        typedArrayObtainStyledAttributes.recycle();
                    } else {
                        if (name3.equals("item")) {
                            Context context = hVar.f4016c;
                            TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0131a.f3079r);
                            gVar.i = typedArrayObtainStyledAttributes2.getResourceId(2, 0);
                            gVar.f3996j = (typedArrayObtainStyledAttributes2.getInt(5, gVar.f3991c) & (-65536)) | (typedArrayObtainStyledAttributes2.getInt(6, gVar.f3992d) & 65535);
                            gVar.f3997k = typedArrayObtainStyledAttributes2.getText(7);
                            gVar.f3998l = typedArrayObtainStyledAttributes2.getText(8);
                            gVar.f3999m = typedArrayObtainStyledAttributes2.getResourceId(0, 0);
                            String string = typedArrayObtainStyledAttributes2.getString(9);
                            gVar.f4000n = string == null ? (char) 0 : string.charAt(0);
                            gVar.f4001o = typedArrayObtainStyledAttributes2.getInt(16, 4096);
                            String string2 = typedArrayObtainStyledAttributes2.getString(10);
                            gVar.f4002p = string2 == null ? (char) 0 : string2.charAt(0);
                            gVar.f4003q = typedArrayObtainStyledAttributes2.getInt(20, 4096);
                            if (typedArrayObtainStyledAttributes2.hasValue(11)) {
                                gVar.f4004r = typedArrayObtainStyledAttributes2.getBoolean(11, false) ? 1 : 0;
                            } else {
                                gVar.f4004r = gVar.e;
                            }
                            gVar.f4005s = typedArrayObtainStyledAttributes2.getBoolean(3, false);
                            gVar.f4006t = typedArrayObtainStyledAttributes2.getBoolean(4, gVar.f3993f);
                            gVar.f4007u = typedArrayObtainStyledAttributes2.getBoolean(1, gVar.f3994g);
                            gVar.f4008v = typedArrayObtainStyledAttributes2.getInt(21, -1);
                            gVar.f4011y = typedArrayObtainStyledAttributes2.getString(12);
                            gVar.f4009w = typedArrayObtainStyledAttributes2.getResourceId(13, 0);
                            gVar.f4010x = typedArrayObtainStyledAttributes2.getString(15);
                            String string3 = typedArrayObtainStyledAttributes2.getString(14);
                            boolean z5 = string3 != null;
                            if (z5 && gVar.f4009w == 0 && gVar.f4010x == null) {
                                gVar.f4012z = (o) gVar.a(string3, f4013f, hVar.f4015b);
                            } else {
                                if (z5) {
                                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                                }
                                gVar.f4012z = null;
                            }
                            gVar.f3984A = typedArrayObtainStyledAttributes2.getText(17);
                            gVar.f3985B = typedArrayObtainStyledAttributes2.getText(22);
                            if (typedArrayObtainStyledAttributes2.hasValue(19)) {
                                gVar.f3987D = AbstractC0332r0.c(typedArrayObtainStyledAttributes2.getInt(19, -1), gVar.f3987D);
                            } else {
                                gVar.f3987D = null;
                            }
                            if (typedArrayObtainStyledAttributes2.hasValue(18)) {
                                if (!typedArrayObtainStyledAttributes2.hasValue(18) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(18, 0)) == 0 || (colorStateList = AbstractC0046a.z(context, resourceId)) == null) {
                                    colorStateList = typedArrayObtainStyledAttributes2.getColorStateList(18);
                                }
                                gVar.f3986C = colorStateList;
                            } else {
                                gVar.f3986C = null;
                            }
                            typedArrayObtainStyledAttributes2.recycle();
                            gVar.f3995h = false;
                            z2 = true;
                        } else if (name3.equals("menu")) {
                            z2 = true;
                            gVar.f3995h = true;
                            SubMenu subMenuAddSubMenu = gVar.f3989a.addSubMenu(gVar.f3990b, gVar.i, gVar.f3996j, gVar.f3997k);
                            gVar.b(subMenuAddSubMenu.getItem());
                            b(xmlResourceParser, attributeSet, subMenuAddSubMenu);
                        } else {
                            z2 = true;
                            str = name3;
                            z4 = true;
                        }
                        eventType = xmlResourceParser.next();
                        r4 = z2;
                        i = 2;
                        z4 = z4;
                    }
                }
                z2 = r4;
            }
            eventType = xmlResourceParser.next();
            r4 = z2;
            i = 2;
            z4 = z4;
        }
    }

    @Override // android.view.MenuInflater
    public final void inflate(int i, Menu menu) {
        if (!(menu instanceof MenuC0285l)) {
            super.inflate(i, menu);
            return;
        }
        XmlResourceParser layout = null;
        boolean z2 = false;
        try {
            try {
                layout = this.f4016c.getResources().getLayout(i);
                AttributeSet attributeSetAsAttributeSet = Xml.asAttributeSet(layout);
                if (menu instanceof MenuC0285l) {
                    MenuC0285l menuC0285l = (MenuC0285l) menu;
                    if (!menuC0285l.f4217p) {
                        menuC0285l.w();
                        z2 = true;
                    }
                }
                b(layout, attributeSetAsAttributeSet, menu);
                if (z2) {
                    ((MenuC0285l) menu).v();
                }
                layout.close();
            } catch (IOException e3) {
                throw new InflateException("Error inflating menu XML", e3);
            } catch (XmlPullParserException e4) {
                throw new InflateException("Error inflating menu XML", e4);
            }
        } catch (Throwable th) {
            if (z2) {
                ((MenuC0285l) menu).v();
            }
            if (layout != null) {
                layout.close();
            }
            throw th;
        }
    }
}
