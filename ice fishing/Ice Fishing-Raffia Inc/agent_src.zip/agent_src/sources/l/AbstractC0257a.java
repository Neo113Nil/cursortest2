package l;

import android.view.MenuInflater;
import android.view.View;
import m.MenuC0285l;

/* renamed from: l.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0257a {

    /* renamed from: b, reason: collision with root package name */
    public Object f3968b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f3969c;

    public abstract void a();

    public abstract View b();

    public abstract MenuC0285l d();

    public abstract MenuInflater e();

    public abstract CharSequence f();

    public abstract CharSequence h();

    public abstract void i();

    public abstract boolean j();

    public abstract void k(View view);

    public abstract void l(int i);

    public abstract void m(CharSequence charSequence);

    public abstract void n(int i);

    public abstract void o(CharSequence charSequence);

    public abstract void p(boolean z2);
}
