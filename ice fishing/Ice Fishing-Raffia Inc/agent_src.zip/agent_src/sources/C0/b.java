package C0;

import android.content.Context;
import java.util.List;

/* loaded from: classes.dex */
public interface b {
    List a();

    Object b(Context context);
}
