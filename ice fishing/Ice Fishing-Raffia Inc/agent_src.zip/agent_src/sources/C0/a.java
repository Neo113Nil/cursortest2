package C0;

import a.AbstractC0046a;
import android.content.Context;
import android.os.Bundle;
import android.os.Trace;
import com.kortosi.kluani.qorzanis.R;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: d, reason: collision with root package name */
    public static volatile a f277d;
    public static final Object e = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final Context f280c;

    /* renamed from: b, reason: collision with root package name */
    public final HashSet f279b = new HashSet();

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f278a = new HashMap();

    public a(Context context) {
        this.f280c = context.getApplicationContext();
    }

    public static a c(Context context) {
        if (f277d == null) {
            synchronized (e) {
                try {
                    if (f277d == null) {
                        f277d = new a(context);
                    }
                } finally {
                }
            }
        }
        return f277d;
    }

    public final void a(Bundle bundle) throws ClassNotFoundException {
        HashSet hashSet;
        String string = this.f280c.getString(R.string.androidx_startup);
        if (bundle != null) {
            try {
                HashSet hashSet2 = new HashSet();
                Iterator<String> it = bundle.keySet().iterator();
                while (true) {
                    boolean zHasNext = it.hasNext();
                    hashSet = this.f279b;
                    if (!zHasNext) {
                        break;
                    }
                    String next = it.next();
                    if (string.equals(bundle.getString(next, null))) {
                        Class<?> cls = Class.forName(next);
                        if (b.class.isAssignableFrom(cls)) {
                            hashSet.add(cls);
                        }
                    }
                }
                Iterator it2 = hashSet.iterator();
                while (it2.hasNext()) {
                    b((Class) it2.next(), hashSet2);
                }
            } catch (ClassNotFoundException e3) {
                throw new c(e3);
            }
        }
    }

    public final Object b(Class cls, HashSet hashSet) {
        Object objB;
        if (AbstractC0046a.E()) {
            try {
                AbstractC0046a.b(cls.getSimpleName());
            } catch (Throwable th) {
                Trace.endSection();
                throw th;
            }
        }
        if (hashSet.contains(cls)) {
            throw new IllegalStateException("Cannot initialize " + cls.getName() + ". Cycle detected.");
        }
        HashMap map = this.f278a;
        if (map.containsKey(cls)) {
            objB = map.get(cls);
        } else {
            hashSet.add(cls);
            try {
                b bVar = (b) cls.getDeclaredConstructor(null).newInstance(null);
                List<Class> listA = bVar.a();
                if (!listA.isEmpty()) {
                    for (Class cls2 : listA) {
                        if (!map.containsKey(cls2)) {
                            b(cls2, hashSet);
                        }
                    }
                }
                objB = bVar.b(this.f280c);
                hashSet.remove(cls);
                map.put(cls, objB);
            } catch (Throwable th2) {
                throw new c(th2);
            }
        }
        Trace.endSection();
        return objB;
    }
}
