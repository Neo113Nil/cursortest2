package C0;

/* loaded from: classes.dex */
public final class c extends RuntimeException {
}
