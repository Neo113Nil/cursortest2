package s0;

import y0.InterfaceC0531a;

/* loaded from: classes.dex */
public interface u {
    InterfaceC0531a b();
}
