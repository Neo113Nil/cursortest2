package s0;

import a.AbstractC0046a;
import android.database.SQLException;
import g2.AbstractC0160y;
import g2.q0;
import java.util.concurrent.atomic.AtomicBoolean;
import k1.AbstractC0239g;
import n0.C0353e;
import y0.InterfaceC0531a;

/* renamed from: s0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0448h implements InterfaceC0442b {

    /* renamed from: b, reason: collision with root package name */
    public final l f5461b;

    /* renamed from: c, reason: collision with root package name */
    public final l f5462c;

    /* renamed from: d, reason: collision with root package name */
    public final ThreadLocal f5463d;
    public final AtomicBoolean e;

    /* renamed from: f, reason: collision with root package name */
    public final long f5464f;

    /* JADX WARN: Removed duplicated region for block: B:12:0x0064 A[PHI: r3
      0x0064: PHI (r3v6 long) = (r3v2 long), (r3v3 long) binds: [B:11:0x0062, B:14:0x006d] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public C0448h(A.i iVar) {
        long jP;
        this.f5463d = new ThreadLocal();
        this.e = new AtomicBoolean(false);
        int i = f2.a.f3056d;
        f2.c cVar = f2.c.SECONDS;
        X1.i.e(cVar, "unit");
        if (cVar.compareTo(cVar) <= 0) {
            jP = b1.e.p(30, cVar, f2.c.NANOSECONDS) << 1;
            int i3 = f2.b.f3057a;
        } else {
            long j3 = 30;
            f2.c cVar2 = f2.c.NANOSECONDS;
            long jP2 = b1.e.p(4611686018426999999L, cVar2, cVar);
            if ((-jP2) > j3 || j3 > jP2) {
                f2.c cVar3 = f2.c.MILLISECONDS;
                X1.i.e(cVar3, "targetUnit");
                long jConvert = cVar3.f3061b.convert(j3, cVar.f3061b);
                long j4 = -4611686018427387903L;
                if (jConvert < -4611686018427387903L) {
                    jConvert = j4;
                    jP = (jConvert << 1) + 1;
                    int i4 = f2.b.f3057a;
                } else {
                    j4 = 4611686018427387903L;
                    if (jConvert > 4611686018427387903L) {
                    }
                    jP = (jConvert << 1) + 1;
                    int i42 = f2.b.f3057a;
                }
            } else {
                jP = b1.e.p(j3, cVar, cVar2) << 1;
                int i5 = f2.b.f3057a;
            }
        }
        this.f5464f = jP;
        l lVar = new l(1, new A0.e(5, iVar));
        this.f5461b = lVar;
        this.f5462c = lVar;
    }

    public final void a(boolean z2) {
        String str = z2 ? "reader" : "writer";
        StringBuilder sb = new StringBuilder();
        sb.append("Timed out attempting to acquire a " + str + " connection.");
        sb.append("\n\nWriter pool:\n");
        this.f5462c.c(sb);
        sb.append("Reader pool:");
        sb.append('\n');
        this.f5461b.c(sb);
        AbstractC0239g.E(sb.toString(), 5);
        throw null;
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        if (this.e.compareAndSet(false, true)) {
            this.f5461b.b();
            this.f5462c.b();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0133 A[Catch: all -> 0x0152, TryCatch #2 {all -> 0x0152, blocks: (B:68:0x012d, B:70:0x0133, B:75:0x014e, B:79:0x0158, B:83:0x0162, B:95:0x01b1, B:96:0x01b8, B:97:0x01b9, B:98:0x01ba, B:99:0x01bd), top: B:126:0x012d }] */
    /* JADX WARN: Removed duplicated region for block: B:78:0x0157  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x001b  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x015e  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x019a A[Catch: all -> 0x01b0, TRY_LEAVE, TryCatch #0 {all -> 0x01b0, blocks: (B:87:0x0194, B:89:0x019a, B:92:0x01a6, B:93:0x01a9), top: B:122:0x0194 }] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x01ba A[Catch: all -> 0x0152, TryCatch #2 {all -> 0x0152, blocks: (B:68:0x012d, B:70:0x0133, B:75:0x014e, B:79:0x0158, B:83:0x0162, B:95:0x01b1, B:96:0x01b8, B:97:0x01b9, B:98:0x01ba, B:99:0x01bd), top: B:126:0x012d }] */
    @Override // s0.InterfaceC0442b
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object e(boolean z2, W1.p pVar, P1.c cVar) throws Throwable {
        C0445e c0445e;
        X1.n nVar;
        Throwable th;
        l lVar;
        X1.n nVar2;
        Throwable th2;
        l lVar2;
        X1.n nVar3;
        N1.i iVar;
        C0448h c0448h;
        W1.p pVar2;
        X1.n nVar4;
        l lVar3;
        boolean z3;
        X1.n nVar5;
        C0449i c0449i;
        t tVar;
        t tVar2;
        boolean z4 = z2;
        W1.p pVar3 = pVar;
        if (cVar instanceof C0445e) {
            c0445e = (C0445e) cVar;
            int i = c0445e.f5454n;
            if ((i & Integer.MIN_VALUE) != 0) {
                c0445e.f5454n = i - Integer.MIN_VALUE;
            } else {
                c0445e = new C0445e(this, cVar);
            }
        }
        Object objE = c0445e.f5452l;
        O1.a aVar = O1.a.f839b;
        int i3 = c0445e.f5454n;
        try {
            if (i3 == 0) {
                AbstractC0046a.N(objE);
                if (this.e.get()) {
                    AbstractC0239g.E("Connection pool is closed", 21);
                    throw null;
                }
                ThreadLocal threadLocal = this.f5463d;
                t tVar3 = (t) threadLocal.get();
                C0353e c0353e = C0441a.f5439c;
                N1.i iVar2 = c0445e.f976c;
                if (tVar3 == null) {
                    X1.i.b(iVar2);
                    C0441a c0441a = (C0441a) iVar2.C(c0353e);
                    tVar3 = c0441a != null ? c0441a.f5440b : null;
                }
                if (tVar3 != null) {
                    if (!z4 && tVar3.f5505b) {
                        AbstractC0239g.E("Cannot upgrade connection from reader to writer", 1);
                        throw null;
                    }
                    X1.i.b(iVar2);
                    if (iVar2.C(c0353e) == null) {
                        C0441a c0441a2 = new C0441a(tVar3);
                        X1.i.e(threadLocal, "<this>");
                        N1.i iVarG0 = L1.d.g0(c0441a2, new l2.x(tVar3, threadLocal));
                        C0446f c0446f = new C0446f(pVar3, tVar3, null);
                        c0445e.f5454n = 1;
                        objE = AbstractC0160y.s(iVarG0, c0446f, c0445e);
                        if (objE == aVar) {
                            return aVar;
                        }
                    } else {
                        c0445e.f5454n = 2;
                        objE = pVar3.e(tVar3, c0445e);
                        if (objE == aVar) {
                            return aVar;
                        }
                    }
                    return objE;
                }
                l lVar4 = z4 ? this.f5461b : this.f5462c;
                nVar = new X1.n();
                try {
                    X1.i.b(iVar2);
                    nVar2 = new X1.n();
                    try {
                        long j3 = this.f5464f;
                        C0444d c0444d = new C0444d(nVar2, lVar4, null);
                        c0445e.e = this;
                        c0445e.f5447f = pVar3;
                        c0445e.f5448g = lVar4;
                        c0445e.f5449h = nVar;
                        c0445e.i = iVar2;
                        c0445e.f5450j = nVar2;
                        c0445e.f5451k = z4;
                        c0445e.f5454n = 3;
                        if (AbstractC0160y.t(j3, c0444d, c0445e) == aVar) {
                            return aVar;
                        }
                        nVar3 = nVar;
                        c0448h = this;
                        pVar2 = pVar3;
                        nVar4 = nVar2;
                        lVar3 = lVar4;
                        iVar = iVar2;
                        z3 = z4;
                        th2 = null;
                    } catch (Throwable th3) {
                        th2 = th3;
                        lVar2 = lVar4;
                        nVar3 = nVar;
                        iVar = iVar2;
                        c0448h = this;
                        pVar2 = pVar3;
                        nVar4 = nVar2;
                        lVar3 = lVar2;
                        z3 = z4;
                        nVar5 = nVar3;
                        c0449i = (C0449i) nVar4.f1364b;
                        if (c0449i != null) {
                        }
                        nVar5.f1364b = tVar;
                        if (th2 instanceof q0) {
                        }
                    }
                } catch (Throwable th4) {
                    th = th4;
                    lVar = lVar4;
                    throw th;
                }
            } else {
                if (i3 == 1 || i3 == 2) {
                    AbstractC0046a.N(objE);
                    return objE;
                }
                if (i3 == 3) {
                    z4 = c0445e.f5451k;
                    nVar4 = c0445e.f5450j;
                    iVar = c0445e.i;
                    nVar3 = c0445e.f5449h;
                    lVar3 = c0445e.f5448g;
                    pVar2 = (W1.p) c0445e.f5447f;
                    c0448h = (C0448h) c0445e.e;
                    try {
                        AbstractC0046a.N(objE);
                        z3 = z4;
                        th2 = null;
                    } catch (Throwable th5) {
                        th2 = th5;
                        lVar2 = lVar3;
                        nVar2 = nVar4;
                        pVar3 = pVar2;
                        pVar2 = pVar3;
                        nVar4 = nVar2;
                        lVar3 = lVar2;
                        z3 = z4;
                        nVar5 = nVar3;
                        c0449i = (C0449i) nVar4.f1364b;
                        if (c0449i != null) {
                        }
                        nVar5.f1364b = tVar;
                        if (th2 instanceof q0) {
                        }
                    }
                } else {
                    if (i3 != 4) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    nVar5 = (X1.n) c0445e.f5447f;
                    lVar = (l) c0445e.e;
                    try {
                        AbstractC0046a.N(objE);
                        try {
                            tVar2 = (t) nVar5.f1364b;
                            if (tVar2 != null) {
                                boolean zCompareAndSet = tVar2.f5507d.compareAndSet(false, true);
                                C0449i c0449i2 = tVar2.f5504a;
                                if (zCompareAndSet) {
                                    try {
                                        AbstractC0239g.l(c0449i2, "ROLLBACK TRANSACTION");
                                    } catch (SQLException unused) {
                                    }
                                }
                                c0449i2.f5467d = null;
                                c0449i2.e = null;
                                lVar.d(c0449i2);
                            }
                        } catch (Throwable unused2) {
                        }
                        return objE;
                    } catch (Throwable th6) {
                        th = th6;
                        nVar = nVar5;
                        th = th;
                        try {
                            throw th;
                        } finally {
                        }
                    }
                }
            }
            c0449i = (C0449i) nVar4.f1364b;
            if (c0449i != null) {
                X1.i.e(iVar, "context");
                c0449i.f5467d = iVar;
                c0449i.e = new Throwable();
                tVar = new t(c0449i, c0448h.f5461b != c0448h.f5462c && z3);
            } else {
                tVar = null;
            }
            nVar5.f1364b = tVar;
            if (th2 instanceof q0) {
                c0448h.a(z3);
                throw null;
            }
            if (th2 != null) {
                throw th2;
            }
            if (tVar == null) {
                throw new IllegalArgumentException("Required value was null.");
            }
            c0448h.getClass();
            C0441a c0441a3 = new C0441a(tVar);
            ThreadLocal threadLocal2 = c0448h.f5463d;
            X1.i.e(threadLocal2, "<this>");
            N1.i iVarG02 = L1.d.g0(c0441a3, new l2.x(tVar, threadLocal2));
            C0447g c0447g = new C0447g(pVar2, nVar5, null);
            c0445e.e = lVar3;
            c0445e.f5447f = nVar5;
            c0445e.f5448g = null;
            c0445e.f5449h = null;
            c0445e.i = null;
            c0445e.f5450j = null;
            c0445e.f5454n = 4;
            objE = AbstractC0160y.s(iVarG02, c0447g, c0445e);
            if (objE == aVar) {
                return aVar;
            }
            lVar = lVar3;
            tVar2 = (t) nVar5.f1364b;
            if (tVar2 != null) {
            }
            return objE;
        } catch (Throwable th7) {
            th = th7;
            nVar = nVar5;
            lVar = lVar3;
            th = th;
            throw th;
        }
        nVar5 = nVar3;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0069 A[PHI: r5
      0x0069: PHI (r5v6 long) = (r5v3 long), (r5v4 long) binds: [B:11:0x0067, B:14:0x0072] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public C0448h(final A.i iVar, final String str, int i) {
        long jP;
        final int i3 = 1;
        X1.i.e(str, "fileName");
        this.f5463d = new ThreadLocal();
        final int i4 = 0;
        this.e = new AtomicBoolean(false);
        int i5 = f2.a.f3056d;
        f2.c cVar = f2.c.SECONDS;
        X1.i.e(cVar, "unit");
        if (cVar.compareTo(cVar) <= 0) {
            jP = b1.e.p(30, cVar, f2.c.NANOSECONDS) << 1;
            int i6 = f2.b.f3057a;
        } else {
            long j3 = 30;
            f2.c cVar2 = f2.c.NANOSECONDS;
            long jP2 = b1.e.p(4611686018426999999L, cVar2, cVar);
            if ((-jP2) <= j3 && j3 <= jP2) {
                jP = b1.e.p(j3, cVar, cVar2) << 1;
                int i7 = f2.b.f3057a;
            } else {
                f2.c cVar3 = f2.c.MILLISECONDS;
                X1.i.e(cVar3, "targetUnit");
                long jConvert = cVar3.f3061b.convert(j3, cVar.f3061b);
                long j4 = -4611686018427387903L;
                if (jConvert < -4611686018427387903L) {
                    jConvert = j4;
                    jP = (jConvert << 1) + 1;
                    int i8 = f2.b.f3057a;
                } else {
                    j4 = 4611686018427387903L;
                    if (jConvert > 4611686018427387903L) {
                    }
                    jP = (jConvert << 1) + 1;
                    int i82 = f2.b.f3057a;
                }
            }
        }
        this.f5464f = jP;
        if (i > 0) {
            this.f5461b = new l(i, new W1.a() { // from class: s0.c
                @Override // W1.a
                public final Object a() throws Exception {
                    switch (i4) {
                        case 0:
                            InterfaceC0531a interfaceC0531aD = iVar.d(str);
                            AbstractC0239g.l(interfaceC0531aD, "PRAGMA query_only = 1");
                            return interfaceC0531aD;
                        default:
                            return iVar.d(str);
                    }
                }
            });
            this.f5462c = new l(1, new W1.a() { // from class: s0.c
                @Override // W1.a
                public final Object a() throws Exception {
                    switch (i3) {
                        case 0:
                            InterfaceC0531a interfaceC0531aD = iVar.d(str);
                            AbstractC0239g.l(interfaceC0531aD, "PRAGMA query_only = 1");
                            return interfaceC0531aD;
                        default:
                            return iVar.d(str);
                    }
                }
            });
            return;
        }
        throw new IllegalArgumentException("Maximum number of readers must be greater than 0");
    }
}
