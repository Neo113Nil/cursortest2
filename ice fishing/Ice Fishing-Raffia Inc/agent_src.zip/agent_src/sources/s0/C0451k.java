package s0;

/* renamed from: s0.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0451k extends P1.c {
    public l e;

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f5471f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ l f5472g;

    /* renamed from: h, reason: collision with root package name */
    public int f5473h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0451k(l lVar, P1.c cVar) {
        super(cVar);
        this.f5472g = lVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.f5471f = obj;
        this.f5473h |= Integer.MIN_VALUE;
        return this.f5472g.a(this);
    }
}
