package s0;

import a.AbstractC0046a;
import g2.InterfaceC0158w;

/* renamed from: s0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0446f extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5455f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ P1.g f5456g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ t f5457h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0446f(W1.p pVar, t tVar, N1.d dVar) {
        super(2, dVar);
        this.f5456g = (P1.g) pVar;
        this.f5457h = tVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((C0446f) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [P1.g, W1.p] */
    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new C0446f(this.f5456g, this.f5457h, dVar);
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [P1.g, W1.p] */
    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5455f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            this.f5455f = 1;
            obj = this.f5456g.e(this.f5457h, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
