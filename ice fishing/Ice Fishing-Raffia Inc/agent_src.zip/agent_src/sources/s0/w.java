package s0;

import a.AbstractC0046a;
import g2.AbstractC0160y;
import g2.C0141e;
import g2.C0149m;
import g2.C0151o;
import g2.I;
import g2.InterfaceC0158w;
import g2.V;
import g2.d0;

/* loaded from: classes.dex */
public final class w extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5511f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ C0149m f5512g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(N1.d dVar, C0149m c0149m) {
        super(2, dVar);
        this.f5512g = c0149m;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((w) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new w(dVar, this.f5512g);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5511f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            this.f5511f = 1;
            C0149m c0149m = this.f5512g;
            while (true) {
                Object objG = c0149m.G();
                if (objG instanceof V) {
                    if (c0149m.T(objG) >= 0) {
                        d0 d0Var = new d0(L1.d.M(this), c0149m);
                        d0Var.v();
                        d0Var.x(new C0141e(1, c0149m.K(false, true, new I(2, d0Var))));
                        obj = d0Var.u();
                        break;
                    }
                } else {
                    if (objG instanceof C0151o) {
                        throw ((C0151o) objG).f3158a;
                    }
                    obj = AbstractC0160y.q(objG);
                }
            }
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
