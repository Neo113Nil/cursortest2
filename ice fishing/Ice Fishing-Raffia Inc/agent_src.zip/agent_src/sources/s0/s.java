package s0;

/* loaded from: classes.dex */
public final class s extends P1.c {
    public t e;

    /* renamed from: f, reason: collision with root package name */
    public String f5499f;

    /* renamed from: g, reason: collision with root package name */
    public W1.l f5500g;

    /* renamed from: h, reason: collision with root package name */
    public C0449i f5501h;
    public /* synthetic */ Object i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ t f5502j;

    /* renamed from: k, reason: collision with root package name */
    public int f5503k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public s(t tVar, P1.c cVar) {
        super(cVar);
        this.f5502j = tVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.i = obj;
        this.f5503k |= Integer.MIN_VALUE;
        return this.f5502j.a(null, null, this);
    }
}
