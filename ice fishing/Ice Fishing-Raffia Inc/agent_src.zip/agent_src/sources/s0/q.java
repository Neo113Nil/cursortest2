package s0;

/* loaded from: classes.dex */
public final class q extends P1.c {
    public t e;

    /* renamed from: f, reason: collision with root package name */
    public C0449i f5491f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f5492g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f5493h;
    public final /* synthetic */ t i;

    /* renamed from: j, reason: collision with root package name */
    public int f5494j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q(t tVar, P1.c cVar) {
        super(cVar);
        this.i = tVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.f5493h = obj;
        this.f5494j |= Integer.MIN_VALUE;
        return this.i.f(false, this);
    }
}
