package s0;

import q0.EnumC0402E;

/* loaded from: classes.dex */
public final class p extends P1.c {
    public t e;

    /* renamed from: f, reason: collision with root package name */
    public EnumC0402E f5487f;

    /* renamed from: g, reason: collision with root package name */
    public C0449i f5488g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f5489h;
    public final /* synthetic */ t i;

    /* renamed from: j, reason: collision with root package name */
    public int f5490j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(t tVar, P1.c cVar) {
        super(cVar);
        this.i = tVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.f5489h = obj;
        this.f5490j |= Integer.MIN_VALUE;
        return this.i.e(null, this);
    }
}
