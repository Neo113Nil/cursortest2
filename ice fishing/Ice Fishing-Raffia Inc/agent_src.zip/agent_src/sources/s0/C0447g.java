package s0;

import a.AbstractC0046a;
import g2.InterfaceC0158w;

/* renamed from: s0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0447g extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5458f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ W1.p f5459g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ X1.n f5460h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0447g(W1.p pVar, X1.n nVar, N1.d dVar) {
        super(2, dVar);
        this.f5459g = pVar;
        this.f5460h = nVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((C0447g) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new C0447g(this.f5459g, this.f5460h, dVar);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5458f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            Object obj2 = this.f5460h.f1364b;
            this.f5458f = 1;
            obj = this.f5459g.e(obj2, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
