package s0;

/* renamed from: s0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0445e extends P1.c {
    public Object e;

    /* renamed from: f, reason: collision with root package name */
    public Object f5447f;

    /* renamed from: g, reason: collision with root package name */
    public l f5448g;

    /* renamed from: h, reason: collision with root package name */
    public X1.n f5449h;
    public N1.i i;

    /* renamed from: j, reason: collision with root package name */
    public X1.n f5450j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f5451k;

    /* renamed from: l, reason: collision with root package name */
    public /* synthetic */ Object f5452l;

    /* renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0448h f5453m;

    /* renamed from: n, reason: collision with root package name */
    public int f5454n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0445e(C0448h c0448h, P1.c cVar) {
        super(cVar);
        this.f5453m = c0448h;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.f5452l = obj;
        this.f5454n |= Integer.MIN_VALUE;
        return this.f5453m.e(false, null, this);
    }
}
