package s0;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final int f5486a;

    public o(int i) {
        this.f5486a = i;
    }
}
