package s0;

import a.AbstractC0046a;
import g2.AbstractC0160y;
import g2.C0149m;
import g2.C0151o;
import g2.InterfaceC0148l;
import g2.InterfaceC0158w;
import q0.C0412i;

/* loaded from: classes.dex */
public final class v extends P1.g implements W1.p {

    /* renamed from: f, reason: collision with root package name */
    public int f5508f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f5509g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0149m f5510h;
    public final /* synthetic */ C0412i i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v(C0149m c0149m, C0412i c0412i, N1.d dVar) {
        super(2, dVar);
        this.f5510h = c0149m;
        this.i = c0412i;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((v) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        v vVar = new v(this.f5510h, this.i, dVar);
        vVar.f5509g = obj;
        return vVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0045  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0059  */
    @Override // P1.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object o(Object obj) throws Throwable {
        InterfaceC0148l interfaceC0148l;
        Throwable thA;
        Object objV;
        Object objV2;
        O1.a aVar = O1.a.f839b;
        int i = this.f5508f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0158w interfaceC0158w = (InterfaceC0158w) this.f5509g;
            C0149m c0149m = this.f5510h;
            C0412i c0412i = this.i;
            try {
                this.f5509g = c0149m;
                this.f5508f = 1;
                obj = c0412i.e(interfaceC0158w, this);
                if (obj == aVar) {
                    return aVar;
                }
                interfaceC0148l = c0149m;
            } catch (Throwable th) {
                th = th;
                interfaceC0148l = c0149m;
                obj = AbstractC0046a.n(th);
                thA = J1.g.a(obj);
                Y.q qVar = AbstractC0160y.f3182f;
                Y.q qVar2 = AbstractC0160y.e;
                Y.q qVar3 = AbstractC0160y.f3181d;
                if (thA != null) {
                }
                return J1.k.f632a;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            interfaceC0148l = (InterfaceC0148l) this.f5509g;
            try {
                AbstractC0046a.N(obj);
            } catch (Throwable th2) {
                th = th2;
                obj = AbstractC0046a.n(th);
                thA = J1.g.a(obj);
                Y.q qVar4 = AbstractC0160y.f3182f;
                Y.q qVar22 = AbstractC0160y.e;
                Y.q qVar32 = AbstractC0160y.f3181d;
                if (thA != null) {
                }
                return J1.k.f632a;
            }
        }
        thA = J1.g.a(obj);
        Y.q qVar42 = AbstractC0160y.f3182f;
        Y.q qVar222 = AbstractC0160y.e;
        Y.q qVar322 = AbstractC0160y.f3181d;
        if (thA != null) {
            C0149m c0149m2 = (C0149m) interfaceC0148l;
            c0149m2.getClass();
            C0151o c0151o = new C0151o(thA, false);
            do {
                objV = c0149m2.V(c0149m2.G(), c0151o);
                if (objV == qVar322 || objV == qVar222) {
                    break;
                }
            } while (objV == qVar42);
        } else {
            C0149m c0149m3 = (C0149m) interfaceC0148l;
            do {
                objV2 = c0149m3.V(c0149m3.G(), obj);
                if (objV2 == qVar322 || objV2 == qVar222) {
                    break;
                }
            } while (objV2 == qVar42);
        }
        return J1.k.f632a;
    }
}
