package s0;

import n0.C0353e;

/* renamed from: s0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0441a implements N1.g {

    /* renamed from: c, reason: collision with root package name */
    public static final C0353e f5439c = new C0353e(8);

    /* renamed from: b, reason: collision with root package name */
    public final t f5440b;

    public C0441a(t tVar) {
        X1.i.e(tVar, "connectionWrapper");
        this.f5440b = tVar;
    }

    @Override // N1.i
    public final Object B(Object obj, W1.p pVar) {
        return pVar.e(obj, this);
    }

    @Override // N1.i
    public final N1.g C(N1.h hVar) {
        return L1.d.u(this, hVar);
    }

    @Override // N1.i
    public final N1.i E(N1.i iVar) {
        return L1.d.g0(this, iVar);
    }

    @Override // N1.g
    public final N1.h getKey() {
        return f5439c;
    }

    @Override // N1.i
    public final N1.i h(N1.h hVar) {
        return L1.d.W(this, hVar);
    }
}
