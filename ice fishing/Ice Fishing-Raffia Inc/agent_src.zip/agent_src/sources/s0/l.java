package s0;

import a.AbstractC0046a;
import g2.AbstractC0160y;
import g2.C0143g;
import java.util.concurrent.locks.ReentrantLock;
import k1.AbstractC0239g;
import y0.InterfaceC0531a;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public final int f5474a;

    /* renamed from: b, reason: collision with root package name */
    public final W1.a f5475b;

    /* renamed from: c, reason: collision with root package name */
    public final ReentrantLock f5476c = new ReentrantLock();

    /* renamed from: d, reason: collision with root package name */
    public int f5477d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public final C0449i[] f5478f;

    /* renamed from: g, reason: collision with root package name */
    public final o2.h f5479g;

    /* renamed from: h, reason: collision with root package name */
    public final K0.h f5480h;

    public l(int i, W1.a aVar) {
        this.f5474a = i;
        this.f5475b = aVar;
        this.f5478f = new C0449i[i];
        int i3 = o2.i.f4761a;
        this.f5479g = new o2.h(i, 0);
        K0.h hVar = new K0.h();
        if (i < 1) {
            throw new IllegalArgumentException("capacity must be >= 1");
        }
        if (i > 1073741824) {
            throw new IllegalArgumentException("capacity must be <= 2^30");
        }
        i = Integer.bitCount(i) != 1 ? Integer.highestOneBit(i - 1) << 1 : i;
        hVar.f659c = i - 1;
        hVar.f660d = new Object[i];
        this.f5480h = hVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x0064, code lost:
    
        r0.i(r5, r8.f4760c);
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object a(P1.c cVar) throws Throwable {
        C0451k c0451k;
        int andDecrement;
        int i;
        l lVar;
        if (cVar instanceof C0451k) {
            c0451k = (C0451k) cVar;
            int i3 = c0451k.f5473h;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                c0451k.f5473h = i3 - Integer.MIN_VALUE;
            } else {
                c0451k = new C0451k(this, cVar);
            }
        }
        Object obj = c0451k.f5471f;
        Object obj2 = O1.a.f839b;
        int i4 = c0451k.f5473h;
        if (i4 == 0) {
            AbstractC0046a.N(obj);
            o2.h hVar = this.f5479g;
            c0451k.e = this;
            c0451k.f5473h = 1;
            hVar.getClass();
            do {
                andDecrement = o2.h.f4758h.getAndDecrement(hVar);
                i = hVar.f4759b;
            } while (andDecrement > i);
            Object obj3 = J1.k.f632a;
            if (andDecrement <= 0) {
                C0143g c0143gG = AbstractC0160y.g(L1.d.M(c0451k));
                try {
                    if (!hVar.c(c0143gG)) {
                        while (true) {
                            int andDecrement2 = o2.h.f4758h.getAndDecrement(hVar);
                            if (andDecrement2 <= i) {
                                if (andDecrement2 > 0) {
                                    break;
                                }
                                if (hVar.c(c0143gG)) {
                                    break;
                                }
                            }
                        }
                    }
                    Object objU = c0143gG.u();
                    Object obj4 = objU;
                    if (objU != obj2) {
                        obj4 = obj3;
                    }
                    if (obj4 == obj2) {
                        obj3 = obj4;
                    }
                } catch (Throwable th) {
                    c0143gG.C();
                    throw th;
                }
            }
            if (obj3 == obj2) {
                return obj2;
            }
            lVar = this;
        } else {
            if (i4 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            lVar = c0451k.e;
            AbstractC0046a.N(obj);
        }
        try {
            ReentrantLock reentrantLock = lVar.f5476c;
            K0.h hVar2 = lVar.f5480h;
            reentrantLock.lock();
            try {
                if (lVar.e) {
                    AbstractC0239g.E("Connection pool is closed", 21);
                    throw null;
                }
                if (hVar2.f657a == hVar2.f658b && lVar.f5477d < lVar.f5474a) {
                    C0449i c0449i = new C0449i((InterfaceC0531a) lVar.f5475b.a());
                    int i5 = lVar.f5477d;
                    lVar.f5477d = i5 + 1;
                    lVar.f5478f[i5] = c0449i;
                    hVar2.a(c0449i);
                }
                int i6 = hVar2.f657a;
                if (i6 == hVar2.f658b) {
                    throw new ArrayIndexOutOfBoundsException();
                }
                Object[] objArr = (Object[]) hVar2.f660d;
                Object obj5 = objArr[i6];
                objArr[i6] = null;
                hVar2.f657a = (i6 + 1) & hVar2.f659c;
                return (C0449i) obj5;
            } finally {
                reentrantLock.unlock();
            }
        } catch (Throwable th2) {
            lVar.f5479g.d();
            throw th2;
        }
    }

    public final void b() {
        ReentrantLock reentrantLock = this.f5476c;
        reentrantLock.lock();
        try {
            this.e = true;
            for (C0449i c0449i : this.f5478f) {
                if (c0449i != null) {
                    c0449i.close();
                }
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void c(StringBuilder sb) {
        K0.h hVar = this.f5480h;
        ReentrantLock reentrantLock = this.f5476c;
        reentrantLock.lock();
        try {
            L1.c cVar = new L1.c(10);
            int i = (hVar.f658b - hVar.f657a) & hVar.f659c;
            for (int i3 = 0; i3 < i; i3++) {
                if (i3 >= 0) {
                    int i4 = hVar.f658b;
                    int i5 = hVar.f657a;
                    int i6 = hVar.f659c;
                    if (i3 < ((i4 - i5) & i6)) {
                        Object obj = ((Object[]) hVar.f660d)[(i5 + i3) & i6];
                        X1.i.b(obj);
                        cVar.add(obj);
                    }
                }
                throw new ArrayIndexOutOfBoundsException();
            }
            L1.c cVarC = AbstractC0046a.c(cVar);
            sb.append('\t' + toString() + " (");
            sb.append("capacity=" + this.f5474a + ", ");
            StringBuilder sb2 = new StringBuilder();
            sb2.append("permits=");
            o2.h hVar2 = this.f5479g;
            hVar2.getClass();
            sb2.append(Math.max(o2.h.f4758h.get(hVar2), 0));
            sb2.append(", ");
            sb.append(sb2.toString());
            sb.append("queue=(size=" + cVarC.a() + ")[" + K1.l.b0(cVarC, null, null, null, null, 63) + "], ");
            sb.append(")");
            sb.append('\n');
            C0449i[] c0449iArr = this.f5478f;
            int length = c0449iArr.length;
            int i7 = 0;
            for (int i8 = 0; i8 < length; i8++) {
                C0449i c0449i = c0449iArr[i8];
                i7++;
                StringBuilder sb3 = new StringBuilder();
                sb3.append("\t\t[");
                sb3.append(i7);
                sb3.append("] - ");
                sb3.append(c0449i != null ? c0449i.f5465b.toString() : null);
                sb.append(sb3.toString());
                sb.append('\n');
                if (c0449i != null) {
                    c0449i.h(sb);
                }
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void d(C0449i c0449i) {
        X1.i.e(c0449i, "connection");
        ReentrantLock reentrantLock = this.f5476c;
        reentrantLock.lock();
        try {
            this.f5480h.a(c0449i);
            reentrantLock.unlock();
            this.f5479g.d();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }
}
