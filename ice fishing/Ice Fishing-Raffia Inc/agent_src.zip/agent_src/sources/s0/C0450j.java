package s0;

import j2.C0222d;
import j2.InterfaceC0225g;

/* renamed from: s0.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0450j extends P1.c {
    public /* synthetic */ Object e;

    /* renamed from: f, reason: collision with root package name */
    public int f5468f;

    /* renamed from: g, reason: collision with root package name */
    public InterfaceC0225g f5469g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0222d f5470h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0450j(C0222d c0222d, N1.d dVar) {
        super(dVar);
        this.f5470h = c0222d;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.e = obj;
        this.f5468f |= Integer.MIN_VALUE;
        return this.f5470h.b(null, this);
    }
}
