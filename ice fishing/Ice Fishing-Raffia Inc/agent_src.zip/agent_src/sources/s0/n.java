package s0;

import y0.InterfaceC0531a;

/* loaded from: classes.dex */
public final class n implements u, q0.v {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5484a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f5485b;

    public /* synthetic */ n(int i, Object obj) {
        this.f5484a = i;
        this.f5485b = obj;
    }

    @Override // q0.v
    public final Object a(String str, W1.l lVar, P1.c cVar) {
        switch (this.f5484a) {
            case 0:
                return ((t) this.f5485b).a(str, lVar, cVar);
            default:
                return ((t0.d) this.f5485b).a(str, lVar, cVar);
        }
    }

    @Override // s0.u
    public final InterfaceC0531a b() {
        switch (this.f5484a) {
            case 0:
                return ((t) this.f5485b).f5504a;
            default:
                return ((t0.d) this.f5485b).f5522a;
        }
    }
}
