package j1;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import l.C0259c;

/* renamed from: j1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0218a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f3775a = {R.attr.theme, com.kortosi.kluani.qorzanis.R.attr.theme};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f3776b = {com.kortosi.kluani.qorzanis.R.attr.materialThemeOverlay};

    public static Context a(Context context, AttributeSet attributeSet, int i, int i3) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f3776b, i, i3);
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        boolean z2 = (context instanceof C0259c) && ((C0259c) context).f3971a == resourceId;
        if (resourceId == 0 || z2) {
            return context;
        }
        C0259c c0259c = new C0259c(context, resourceId);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, f3775a);
        int resourceId2 = typedArrayObtainStyledAttributes2.getResourceId(0, 0);
        int resourceId3 = typedArrayObtainStyledAttributes2.getResourceId(1, 0);
        typedArrayObtainStyledAttributes2.recycle();
        if (resourceId2 == 0) {
            resourceId2 = resourceId3;
        }
        if (resourceId2 != 0) {
            c0259c.getTheme().applyStyle(resourceId2, true);
        }
        return c0259c;
    }
}
