package q;

import android.R;

/* renamed from: q.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0397a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f5093a = {R.attr.minWidth, R.attr.minHeight, com.kortosi.kluani.qorzanis.R.attr.cardBackgroundColor, com.kortosi.kluani.qorzanis.R.attr.cardCornerRadius, com.kortosi.kluani.qorzanis.R.attr.cardElevation, com.kortosi.kluani.qorzanis.R.attr.cardMaxElevation, com.kortosi.kluani.qorzanis.R.attr.cardPreventCornerOverlap, com.kortosi.kluani.qorzanis.R.attr.cardUseCompatPadding, com.kortosi.kluani.qorzanis.R.attr.contentPadding, com.kortosi.kluani.qorzanis.R.attr.contentPaddingBottom, com.kortosi.kluani.qorzanis.R.attr.contentPaddingLeft, com.kortosi.kluani.qorzanis.R.attr.contentPaddingRight, com.kortosi.kluani.qorzanis.R.attr.contentPaddingTop};
}
