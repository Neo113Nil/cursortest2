package g1;

import P.G;
import P.O;
import X0.E;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.kortosi.kluani.qorzanis.R;
import e1.C0125g;
import e1.k;
import j1.AbstractC0218a;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public abstract class c extends FrameLayout {

    /* renamed from: j, reason: collision with root package name */
    public static final b f3091j = new b();

    /* renamed from: b, reason: collision with root package name */
    public final k f3092b;

    /* renamed from: c, reason: collision with root package name */
    public int f3093c;

    /* renamed from: d, reason: collision with root package name */
    public final float f3094d;
    public final float e;

    /* renamed from: f, reason: collision with root package name */
    public final int f3095f;

    /* renamed from: g, reason: collision with root package name */
    public final int f3096g;

    /* renamed from: h, reason: collision with root package name */
    public ColorStateList f3097h;
    public PorterDuff.Mode i;

    /* JADX WARN: Multi-variable type inference failed */
    public c(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        GradientDrawable gradientDrawable;
        super(AbstractC0218a.a(context, attributeSet, 0, 0), attributeSet);
        Context context2 = getContext();
        TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, I0.a.f577H);
        if (typedArrayObtainStyledAttributes.hasValue(6)) {
            float dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(6, 0);
            WeakHashMap weakHashMap = O.f854a;
            G.k(this, dimensionPixelSize);
        }
        this.f3093c = typedArrayObtainStyledAttributes.getInt(2, 0);
        if (typedArrayObtainStyledAttributes.hasValue(8) || typedArrayObtainStyledAttributes.hasValue(9)) {
            this.f3092b = k.b(context2, attributeSet, 0, 0).a();
        }
        this.f3094d = typedArrayObtainStyledAttributes.getFloat(3, 1.0f);
        setBackgroundTintList(L1.d.z(context2, typedArrayObtainStyledAttributes, 4));
        setBackgroundTintMode(E.h(typedArrayObtainStyledAttributes.getInt(5, -1), PorterDuff.Mode.SRC_IN));
        this.e = typedArrayObtainStyledAttributes.getFloat(1, 1.0f);
        this.f3095f = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1);
        this.f3096g = typedArrayObtainStyledAttributes.getDimensionPixelSize(7, -1);
        typedArrayObtainStyledAttributes.recycle();
        setOnTouchListener(f3091j);
        setFocusable(true);
        if (getBackground() == null) {
            int iT = L1.d.T(L1.d.x(this, R.attr.colorSurface), L1.d.x(this, R.attr.colorOnSurface), getBackgroundOverlayColorAlpha());
            k kVar = this.f3092b;
            if (kVar != null) {
                int i = d.f3098a;
                C0125g c0125g = new C0125g(kVar);
                c0125g.l(ColorStateList.valueOf(iT));
                gradientDrawable = c0125g;
            } else {
                Resources resources = getResources();
                int i3 = d.f3098a;
                float dimension = resources.getDimension(R.dimen.mtrl_snackbar_background_corner_radius);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setShape(0);
                gradientDrawable2.setCornerRadius(dimension);
                gradientDrawable2.setColor(iT);
                gradientDrawable = gradientDrawable2;
            }
            ColorStateList colorStateList = this.f3097h;
            if (colorStateList != null) {
                gradientDrawable.setTintList(colorStateList);
            }
            WeakHashMap weakHashMap2 = O.f854a;
            setBackground(gradientDrawable);
        }
    }

    private void setBaseTransientBottomBar(d dVar) {
    }

    public float getActionTextColorAlpha() {
        return this.e;
    }

    public int getAnimationMode() {
        return this.f3093c;
    }

    public float getBackgroundOverlayColorAlpha() {
        return this.f3094d;
    }

    public int getMaxInlineActionWidth() {
        return this.f3096g;
    }

    public int getMaxWidth() {
        return this.f3095f;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        WeakHashMap weakHashMap = O.f854a;
        P.E.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i, int i3, int i4, int i5) {
        super.onLayout(z2, i, i3, i4, i5);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i3) {
        super.onMeasure(i, i3);
        int i4 = this.f3095f;
        if (i4 <= 0 || getMeasuredWidth() <= i4) {
            return;
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
    }

    public void setAnimationMode(int i) {
        this.f3093c = i;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable != null && this.f3097h != null) {
            drawable = drawable.mutate();
            drawable.setTintList(this.f3097h);
            drawable.setTintMode(this.i);
        }
        super.setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        this.f3097h = colorStateList;
        if (getBackground() != null) {
            Drawable drawableMutate = getBackground().mutate();
            drawableMutate.setTintList(colorStateList);
            drawableMutate.setTintMode(this.i);
            if (drawableMutate != getBackground()) {
                super.setBackgroundDrawable(drawableMutate);
            }
        }
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        this.i = mode;
        if (getBackground() != null) {
            Drawable drawableMutate = getBackground().mutate();
            drawableMutate.setTintMode(mode);
            if (drawableMutate != getBackground()) {
                super.setBackgroundDrawable(drawableMutate);
            }
        }
    }

    @Override // android.view.View
    public void setLayoutParams(ViewGroup.LayoutParams layoutParams) {
        super.setLayoutParams(layoutParams);
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            new Rect(marginLayoutParams.leftMargin, marginLayoutParams.topMargin, marginLayoutParams.rightMargin, marginLayoutParams.bottomMargin);
        }
    }

    @Override // android.view.View
    public void setOnClickListener(View.OnClickListener onClickListener) {
        setOnTouchListener(onClickListener != null ? null : f3091j);
        super.setOnClickListener(onClickListener);
    }
}
