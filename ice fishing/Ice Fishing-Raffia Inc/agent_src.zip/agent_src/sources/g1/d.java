package g1;

import android.os.Handler;
import android.os.Looper;
import android.view.animation.LinearInterpolator;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f3098a = 0;

    static {
        LinearInterpolator linearInterpolator = J0.a.f610a;
        new Handler(Looper.getMainLooper(), new C0136a());
    }
}
