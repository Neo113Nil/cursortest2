package I1;

/* loaded from: classes.dex */
public interface d {
    Object get();
}
