package I1;

import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f609a;

    public c(int i) {
        switch (i) {
            case 1:
                this.f609a = new LinkedHashMap();
                break;
            case 2:
                this.f609a = new LinkedHashMap(0, 0.75f, true);
                break;
            default:
                this.f609a = new LinkedHashMap((int) ((5 / 0.75f) + 1.0f));
                break;
        }
    }
}
