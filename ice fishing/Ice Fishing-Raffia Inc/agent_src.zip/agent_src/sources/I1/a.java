package I1;

/* loaded from: classes.dex */
public final class a implements d {

    /* renamed from: c, reason: collision with root package name */
    public static final Object f605c = new Object();

    /* renamed from: a, reason: collision with root package name */
    public volatile d f606a;

    /* renamed from: b, reason: collision with root package name */
    public volatile Object f607b;

    public static d a(d dVar) {
        if (dVar instanceof a) {
            return dVar;
        }
        a aVar = new a();
        aVar.f607b = f605c;
        aVar.f606a = dVar;
        return aVar;
    }

    @Override // I1.d
    public final Object get() {
        Object obj = this.f607b;
        Object obj2 = f605c;
        if (obj == obj2) {
            synchronized (this) {
                try {
                    obj = this.f607b;
                    if (obj == obj2) {
                        obj = this.f606a.get();
                        Object obj3 = this.f607b;
                        if (obj3 != obj2 && obj3 != obj) {
                            throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + obj3 + " & " + obj + ". This is likely due to a circular dependency.");
                        }
                        this.f607b = obj;
                        this.f606a = null;
                    }
                } finally {
                }
            }
        }
        return obj;
    }
}
