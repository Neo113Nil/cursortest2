package k1;

import java.util.Collections;
import java.util.LinkedHashMap;

/* renamed from: k1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0233a implements InterfaceC0246n, E1.a, F1.g, H1.a {

    /* renamed from: a, reason: collision with root package name */
    public final C0238f f3872a;

    /* renamed from: b, reason: collision with root package name */
    public final C0235c f3873b;

    /* renamed from: c, reason: collision with root package name */
    public final C0233a f3874c = this;

    public C0233a(C0238f c0238f, C0235c c0235c) {
        this.f3872a = c0238f;
        this.f3873b = c0235c;
    }

    public final A.i a() {
        I1.c cVar = new I1.c(0);
        Boolean bool = Boolean.TRUE;
        LinkedHashMap linkedHashMap = cVar.f609a;
        linkedHashMap.put("com.kortosi.kluani.qorzanis.ui.home.DropInViewModel", bool);
        linkedHashMap.put("com.kortosi.kluani.qorzanis.ui.detail.LandingCardViewModel", bool);
        linkedHashMap.put("com.kortosi.kluani.qorzanis.ui.profile.RiderCrestViewModel", bool);
        linkedHashMap.put("com.kortosi.kluani.qorzanis.ui.quiz.SpotCheckViewModel", bool);
        linkedHashMap.put("com.kortosi.kluani.qorzanis.ui.catalog.TrickRosterViewModel", bool);
        return new A.i(new I1.b(linkedHashMap.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(linkedHashMap)), 1, new A.i(this.f3872a, 14, this.f3873b));
    }
}
