package k1;

/* renamed from: k1.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0242j {
}
