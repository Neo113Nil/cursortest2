package k1;

/* renamed from: k1.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0245m extends X1.j implements W1.a {

    /* renamed from: c, reason: collision with root package name */
    public static final C0245m f3898c = new C0245m(0);

    @Override // W1.a
    public final /* bridge */ /* synthetic */ Object a() {
        return Boolean.FALSE;
    }
}
