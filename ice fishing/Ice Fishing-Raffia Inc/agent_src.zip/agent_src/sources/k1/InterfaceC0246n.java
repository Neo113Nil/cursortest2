package k1;

/* renamed from: k1.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0246n {
}
