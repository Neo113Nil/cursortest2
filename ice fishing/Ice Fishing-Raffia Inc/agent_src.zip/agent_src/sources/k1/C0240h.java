package k1;

import android.content.Context;
import androidx.lifecycle.P;
import com.kortosi.kluani.qorzanis.ui.catalog.TrickRosterViewModel;
import com.kortosi.kluani.qorzanis.ui.detail.LandingCardViewModel;
import com.kortosi.kluani.qorzanis.ui.home.DropInViewModel;
import com.kortosi.kluani.qorzanis.ui.profile.RiderCrestViewModel;
import com.kortosi.kluani.qorzanis.ui.quiz.SpotCheckViewModel;
import t1.C0453a;

/* renamed from: k1.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0240h implements I1.d {

    /* renamed from: a, reason: collision with root package name */
    public final C0238f f3886a;

    /* renamed from: b, reason: collision with root package name */
    public final C0241i f3887b;

    /* renamed from: c, reason: collision with root package name */
    public final int f3888c;

    public C0240h(C0238f c0238f, C0241i c0241i, int i) {
        this.f3886a = c0238f;
        this.f3887b = c0241i;
        this.f3888c = i;
    }

    @Override // I1.d
    public final Object get() {
        C0241i c0241i = this.f3887b;
        int i = this.f3888c;
        if (i == 0) {
            return new DropInViewModel(new t1.h((o1.k) c0241i.f3890b.f3884d.get(), 0), new t1.b((o1.d) c0241i.f3890b.e.get(), 0));
        }
        if (i == 1) {
            P p2 = c0241i.f3889a;
            C0238f c0238f = c0241i.f3890b;
            return new LandingCardViewModel(p2, new t1.h((o1.k) c0238f.f3884d.get(), 1), new t1.h((o1.k) c0238f.f3884d.get(), 2), new t1.h((o1.k) c0238f.f3884d.get(), 3), new t1.h((o1.k) c0238f.f3884d.get(), 4));
        }
        if (i == 2) {
            t1.b bVar = new t1.b((o1.d) c0241i.f3890b.e.get(), 0);
            C0238f c0238f2 = c0241i.f3890b;
            return new RiderCrestViewModel(bVar, new t1.b((o1.d) c0238f2.e.get(), 2), new t1.b((o1.d) c0238f2.e.get(), 3));
        }
        if (i != 3) {
            if (i == 4) {
                return new TrickRosterViewModel(new t1.h((o1.k) c0241i.f3890b.f3884d.get(), 0), new t1.h((o1.k) c0241i.f3890b.f3884d.get(), 5));
            }
            throw new AssertionError(i);
        }
        Context context = this.f3886a.f3881a.f549a;
        if (context == null) {
            throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
        }
        t1.h hVar = new t1.h((o1.k) c0241i.f3890b.f3884d.get(), 0);
        C0238f c0238f3 = c0241i.f3890b;
        return new SpotCheckViewModel(context, hVar, new t1.b((o1.d) c0238f3.e.get(), 0), new C0453a(), new t1.b((o1.d) c0238f3.e.get(), 1));
    }
}
