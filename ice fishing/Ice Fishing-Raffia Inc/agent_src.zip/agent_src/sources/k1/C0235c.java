package k1;

/* renamed from: k1.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0235c implements F1.a, F1.e, H1.a {

    /* renamed from: a, reason: collision with root package name */
    public final C0238f f3875a;

    /* renamed from: b, reason: collision with root package name */
    public final C0235c f3876b = this;

    /* renamed from: c, reason: collision with root package name */
    public final I1.d f3877c = I1.a.a(new C0234b());

    public C0235c(C0238f c0238f) {
        this.f3875a = c0238f;
    }
}
