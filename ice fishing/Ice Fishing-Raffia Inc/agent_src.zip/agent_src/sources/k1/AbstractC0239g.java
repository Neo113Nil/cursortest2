package k1;

import W1.p;
import X1.q;
import a.AbstractC0046a;
import android.database.SQLException;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.kortosi.kluani.qorzanis.R;
import g2.AbstractC0137a;
import g2.AbstractC0160y;
import g2.C0151o;
import j0.AbstractC0193A;
import j0.C0197b;
import j0.C0198c;
import j0.D;
import j0.F;
import j0.I;
import j2.AbstractC0231m;
import j2.B;
import j2.C0228j;
import j2.InterfaceC0224f;
import j2.t;
import j2.w;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import l2.AbstractC0269a;
import l2.s;
import p1.C0396b;
import q0.AbstractC0398A;
import q0.C0401D;
import q0.C0413j;
import q0.C0418o;
import q0.J;
import q0.U;
import q0.v;
import q0.y;
import v0.o;
import y0.InterfaceC0531a;
import y0.InterfaceC0533c;
import z0.InterfaceC0539b;

/* renamed from: k1.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0239g {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f3885a = 0;

    public static final v0.n A(InterfaceC0531a interfaceC0531a, String str, boolean z2) throws Exception {
        InterfaceC0533c interfaceC0533cA = interfaceC0531a.A("PRAGMA index_xinfo(`" + str + "`)");
        try {
            int iE = e(interfaceC0533cA, "seqno");
            int iE2 = e(interfaceC0533cA, "cid");
            int iE3 = e(interfaceC0533cA, "name");
            int iE4 = e(interfaceC0533cA, "desc");
            if (iE != -1 && iE2 != -1 && iE3 != -1 && iE4 != -1) {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                while (interfaceC0533cA.t()) {
                    if (((int) interfaceC0533cA.s(iE2)) >= 0) {
                        int iS = (int) interfaceC0533cA.s(iE);
                        String strQ = interfaceC0533cA.q(iE3);
                        String str2 = interfaceC0533cA.s(iE4) > 0 ? "DESC" : "ASC";
                        linkedHashMap.put(Integer.valueOf(iS), strQ);
                        linkedHashMap2.put(Integer.valueOf(iS), str2);
                    }
                }
                List listJ0 = K1.l.j0(linkedHashMap.entrySet(), new C.j(5));
                ArrayList arrayList = new ArrayList(K1.n.S(listJ0, 10));
                Iterator it = listJ0.iterator();
                while (it.hasNext()) {
                    arrayList.add((String) ((Map.Entry) it.next()).getValue());
                }
                List listO0 = K1.l.o0(arrayList);
                List listJ02 = K1.l.j0(linkedHashMap2.entrySet(), new C.j(6));
                ArrayList arrayList2 = new ArrayList(K1.n.S(listJ02, 10));
                Iterator it2 = listJ02.iterator();
                while (it2.hasNext()) {
                    arrayList2.add((String) ((Map.Entry) it2.next()).getValue());
                }
                v0.n nVar = new v0.n(str, z2, listO0, K1.l.o0(arrayList2));
                L1.d.n(interfaceC0533cA, null);
                return nVar;
            }
            L1.d.n(interfaceC0533cA, null);
            return null;
        } finally {
        }
    }

    public static final void B(View view, w0.d dVar) {
        X1.i.e(view, "<this>");
        view.setTag(R.id.view_tree_saved_state_registry_owner, dVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void C(p pVar, AbstractC0137a abstractC0137a, AbstractC0137a abstractC0137a2) {
        try {
            AbstractC0269a.i(L1.d.M(((P1.a) pVar).m(abstractC0137a2, abstractC0137a)), J1.k.f632a, null);
        } catch (Throwable th) {
            abstractC0137a2.c(AbstractC0046a.n(th));
            throw th;
        }
    }

    public static final Object D(s sVar, s sVar2, p pVar) throws Throwable {
        Object c0151o;
        Object objM;
        try {
            q.b(2, pVar);
            c0151o = pVar.e(sVar2, sVar);
        } catch (Throwable th) {
            c0151o = new C0151o(th, false);
        }
        O1.a aVar = O1.a.f839b;
        if (c0151o == aVar || (objM = sVar.M(c0151o)) == AbstractC0160y.e) {
            return aVar;
        }
        if (objM instanceof C0151o) {
            throw ((C0151o) objM).f3158a;
        }
        return AbstractC0160y.q(objM);
    }

    public static final void E(String str, int i) {
        StringBuilder sb = new StringBuilder();
        sb.append("Error code: " + i);
        if (str != null) {
            sb.append(", message: ".concat(str));
        }
        throw new SQLException(sb.toString());
    }

    public static final r1.j F(C0396b c0396b, boolean z2) {
        return new r1.j(c0396b.f5082a, c0396b.f5083b, c0396b.f5084c, c0396b.f5085d, c0396b.e, c0396b.f5086f, c0396b.f5087g, c0396b.f5088h, c0396b.i, c0396b.f5089j, c0396b.f5090k, c0396b.f5091l, c0396b.f5092m, z2);
    }

    public static final int e(InterfaceC0533c interfaceC0533c, String str) {
        X1.i.e(interfaceC0533c, "<this>");
        int iF = f(interfaceC0533c, str);
        if (iF >= 0) {
            return iF;
        }
        int iF2 = f(interfaceC0533c, "`" + str + '`');
        if (iF2 < 0) {
            iF2 = -1;
        }
        return iF2;
    }

    public static final int f(InterfaceC0533c interfaceC0533c, String str) {
        X1.i.e(interfaceC0533c, "<this>");
        X1.i.e(str, "name");
        int iR = interfaceC0533c.r();
        for (int i = 0; i < iR; i++) {
            if (str.equals(interfaceC0533c.j(i))) {
                return i;
            }
        }
        return -1;
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.io.Serializable, java.lang.Object, java.lang.String[]] */
    public static final t g(AbstractC0398A abstractC0398A, String[] strArr, W1.l lVar) {
        X1.i.e(abstractC0398A, "db");
        C0413j c0413jD = abstractC0398A.d();
        String[] strArr2 = (String[]) Arrays.copyOf(strArr, strArr.length);
        X1.i.e(strArr2, "tables");
        U u2 = c0413jD.f5207c;
        J1.e eVarF = u2.f(strArr2);
        ?? r3 = (String[]) eVarF.f622b;
        int[] iArr = (int[]) eVarF.f623c;
        X1.i.e(r3, "resolvedTableNames");
        X1.i.e(iArr, "tableIds");
        InterfaceC0224f wVar = new w(new J(u2, iArr, r3, null));
        C0418o c0418o = c0413jD.i;
        C0228j c0228j = c0418o != null ? new C0228j(c0418o.f5226h, r3, 4) : null;
        if (c0228j != null) {
            InterfaceC0224f[] interfaceC0224fArr = {wVar, c0228j};
            int i = AbstractC0231m.f3834a;
            wVar = new k2.q(new K1.k(interfaceC0224fArr), N1.j.f809b, -2, 1);
        }
        return new t(B.c(wVar, -1), abstractC0398A, lVar);
    }

    public static final long i() {
        return Thread.currentThread().getId();
    }

    public static final boolean j(String str, String str2) {
        X1.i.e(str, "current");
        if (str.equals(str2)) {
            return true;
        }
        if (str.length() != 0) {
            int i = 0;
            int i3 = 0;
            int i4 = 0;
            while (true) {
                if (i < str.length()) {
                    char cCharAt = str.charAt(i);
                    int i5 = i4 + 1;
                    if (i4 == 0 && cCharAt != '(') {
                        break;
                    }
                    if (cCharAt == '(') {
                        i3++;
                    } else if (cCharAt == ')' && i3 - 1 == 0 && i4 != str.length() - 1) {
                        break;
                    }
                    i++;
                    i4 = i5;
                } else if (i3 == 0) {
                    String strSubstring = str.substring(1, str.length() - 1);
                    X1.i.d(strSubstring, "substring(...)");
                    return X1.i.a(e2.h.E0(strSubstring).toString(), str2);
                }
            }
        }
        return false;
    }

    public static final Object k(v vVar, String str, P1.c cVar) {
        Object objA = vVar.a(str, new d2.j(13), cVar);
        return objA == O1.a.f839b ? objA : J1.k.f632a;
    }

    public static final void l(InterfaceC0531a interfaceC0531a, String str) throws Exception {
        X1.i.e(interfaceC0531a, "<this>");
        X1.i.e(str, "sql");
        InterfaceC0533c interfaceC0533cA = interfaceC0531a.A(str);
        try {
            interfaceC0533cA.t();
            L1.d.n(interfaceC0533cA, null);
        } finally {
        }
    }

    public static final BottomSheetBehavior m(View view) {
        X1.i.e(view, "view");
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof C.f) {
            C.c cVar = ((C.f) layoutParams).f253a;
            if (cVar instanceof BottomSheetBehavior) {
                return (BottomSheetBehavior) cVar;
            }
            return null;
        }
        Object parent = view.getParent();
        if (parent instanceof View) {
            return m((View) parent);
        }
        return null;
    }

    public static final String n(Collection collection) {
        X1.i.e(collection, "collection");
        if (collection.isEmpty()) {
            return " }";
        }
        return e2.b.s0(K1.l.b0(collection, ",\n", "\n", "\n", null, 56)) + "},";
    }

    public static final int o(InterfaceC0533c interfaceC0533c, String str) {
        X1.i.e(interfaceC0533c, "stmt");
        int iE = e(interfaceC0533c, str);
        if (iE >= 0) {
            return iE;
        }
        int iR = interfaceC0533c.r();
        ArrayList arrayList = new ArrayList(iR);
        for (int i = 0; i < iR; i++) {
            arrayList.add(interfaceC0533c.j(i));
        }
        throw new IllegalArgumentException("Column '" + str + "' does not exist. Available columns: [" + K1.l.b0(arrayList, null, null, null, null, 63) + ']');
    }

    public static final N1.i p(AbstractC0398A abstractC0398A, boolean z2, P1.c cVar) {
        if (!abstractC0398A.g()) {
            l2.e eVar = abstractC0398A.f5094a;
            if (eVar != null) {
                return eVar.f4089b;
            }
            X1.i.g("coroutineScope");
            throw null;
        }
        C0401D c0401d = (C0401D) cVar.k().C(C0401D.f5109d);
        if (c0401d != null) {
            N1.f fVar = c0401d.f5110b;
            l2.e eVar2 = abstractC0398A.f5094a;
            if (eVar2 == null) {
                X1.i.g("coroutineScope");
                throw null;
            }
            N1.i iVarE = eVar2.f4089b.E(fVar);
            if (iVarE != null) {
                return iVarE;
            }
        }
        if (z2) {
            N1.i iVar = abstractC0398A.f5095b;
            if (iVar != null) {
                return iVar;
            }
            X1.i.g("transactionContext");
            throw null;
        }
        l2.e eVar3 = abstractC0398A.f5094a;
        if (eVar3 != null) {
            return eVar3.f4089b;
        }
        X1.i.g("coroutineScope");
        throw null;
    }

    public static final Bundle q(Bundle bundle, String str) {
        Bundle bundle2 = bundle.getBundle(str);
        if (bundle2 != null) {
            return bundle2;
        }
        throw new IllegalArgumentException(H.e.i("No valid saved state was found for the key '", str, "'. It may be missing, null, or not of the expected type. This can occur if the value was saved with a different type or if the saved state was modified unexpectedly."));
    }

    public static final boolean s(int i, AbstractC0193A abstractC0193A) {
        X1.i.e(abstractC0193A, "<this>");
        int i3 = AbstractC0193A.f3578k;
        Iterator it = d2.h.t0(abstractC0193A, C0198c.f3682m).iterator();
        while (it.hasNext()) {
            if (((AbstractC0193A) it.next()).i == i) {
                return true;
            }
        }
        return false;
    }

    public static void t(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        if (inputConnection == null || editorInfo.hintText != null) {
            return;
        }
        for (ViewParent parent = textView.getParent(); parent instanceof View; parent = parent.getParent()) {
        }
    }

    public static final boolean u(MenuItem menuItem, F f3) {
        int i;
        int i3;
        int i4;
        int i5;
        int i6;
        boolean z2;
        X1.i.e(menuItem, "item");
        AbstractC0193A abstractC0193AG = f3.g();
        X1.i.b(abstractC0193AG);
        D d3 = abstractC0193AG.f3580c;
        X1.i.b(d3);
        if (d3.g(menuItem.getItemId(), d3, null, false) instanceof C0197b) {
            i = R.anim.nav_default_enter_anim;
            i3 = R.anim.nav_default_exit_anim;
            i4 = R.anim.nav_default_pop_enter_anim;
            i5 = R.anim.nav_default_pop_exit_anim;
        } else {
            i = R.animator.nav_default_enter_anim;
            i3 = R.animator.nav_default_exit_anim;
            i4 = R.animator.nav_default_pop_enter_anim;
            i5 = R.animator.nav_default_pop_exit_anim;
        }
        int i7 = i;
        int i8 = i3;
        int i9 = i4;
        int i10 = i5;
        if ((menuItem.getOrder() & 196608) == 0) {
            int i11 = D.f3589o;
            i6 = b1.e.v(f3.i()).i;
            z2 = true;
        } else {
            i6 = -1;
            z2 = false;
        }
        try {
            f3.m(menuItem.getItemId(), null, new I(true, true, i6, false, z2, i7, i8, i9, i10));
            AbstractC0193A abstractC0193AG2 = f3.g();
            if (abstractC0193AG2 != null) {
                return s(menuItem.getItemId(), abstractC0193AG2);
            }
            return false;
        } catch (IllegalArgumentException e) {
            int i12 = AbstractC0193A.f3578k;
            StringBuilder sbK = H.e.k("Ignoring onNavDestinationSelected for MenuItem ", b1.e.y(f3.f3597a, menuItem.getItemId()), " as it cannot be found from the current destination ");
            sbK.append(f3.g());
            Log.i("NavigationUI", sbK.toString(), e);
            return false;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object v(N1.d dVar, W1.l lVar, AbstractC0398A abstractC0398A, boolean z2, boolean z3) throws Throwable {
        v0.h hVar;
        W1.l lVar2;
        boolean z4;
        AbstractC0398A abstractC0398A2;
        boolean z5;
        if (dVar instanceof v0.h) {
            hVar = (v0.h) dVar;
            int i = hVar.f5691j;
            if ((i & Integer.MIN_VALUE) != 0) {
                hVar.f5691j = i - Integer.MIN_VALUE;
            } else {
                hVar = new v0.h(dVar);
            }
        }
        v0.h hVar2 = hVar;
        Object objI = hVar2.i;
        O1.a aVar = O1.a.f839b;
        int i3 = hVar2.f5691j;
        if (i3 != 0) {
            if (i3 != 1) {
                if (i3 == 2) {
                    boolean z6 = hVar2.f5690h;
                    boolean z7 = hVar2.f5689g;
                    W1.l lVar3 = hVar2.f5688f;
                    AbstractC0398A abstractC0398A3 = hVar2.e;
                    AbstractC0046a.N(objI);
                    z4 = z6;
                    z5 = z7;
                    lVar2 = lVar3;
                    abstractC0398A2 = abstractC0398A3;
                    v0.g gVar = new v0.g(null, lVar2, abstractC0398A2, z5, z4);
                    hVar2.e = null;
                    hVar2.f5688f = null;
                    hVar2.f5691j = 3;
                    objI = AbstractC0160y.s((N1.i) objI, gVar, hVar2);
                    if (objI == aVar) {
                        return aVar;
                    }
                } else if (i3 != 3) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
            AbstractC0046a.N(objI);
        } else {
            AbstractC0046a.N(objI);
            if (abstractC0398A.g() && abstractC0398A.h() && abstractC0398A.h()) {
                y yVar = abstractC0398A.e;
                if (yVar == null) {
                    X1.i.g("connectionManager");
                    throw null;
                }
                InterfaceC0539b interfaceC0539bC = yVar.c();
                if (interfaceC0539bC == null) {
                    throw new IllegalStateException("Cannot return a SupportSQLiteOpenHelper since no SupportSQLiteOpenHelper.Factory was configured with Room.");
                }
                if (interfaceC0539bC.w().z()) {
                    v0.j jVar = new v0.j(null, lVar, abstractC0398A, z3, z2);
                    hVar2.f5691j = 1;
                    objI = abstractC0398A.i(z2, jVar, hVar2);
                    if (objI == aVar) {
                        return aVar;
                    }
                }
            }
            hVar2.e = abstractC0398A;
            hVar2.f5688f = lVar;
            hVar2.f5689g = z2;
            hVar2.f5690h = z3;
            hVar2.f5691j = 2;
            N1.i iVarP = p(abstractC0398A, z3, hVar2);
            if (iVarP == aVar) {
                return aVar;
            }
            lVar2 = lVar;
            objI = iVarP;
            z4 = z3;
            abstractC0398A2 = abstractC0398A;
            z5 = z2;
            v0.g gVar2 = new v0.g(null, lVar2, abstractC0398A2, z5, z4);
            hVar2.e = null;
            hVar2.f5688f = null;
            hVar2.f5691j = 3;
            objI = AbstractC0160y.s((N1.i) objI, gVar2, hVar2);
            if (objI == aVar) {
            }
        }
        return objI;
    }

    /* JADX WARN: Code restructure failed: missing block: B:66:0x01da, code lost:
    
        r0 = a.AbstractC0046a.d(r8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x01de, code lost:
    
        L1.d.n(r2, null);
        r10 = r0;
     */
    /* JADX WARN: Finally extract failed */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static o y(InterfaceC0531a interfaceC0531a, String str) throws Exception {
        Map mapB;
        L1.k kVar;
        X1.i.e(interfaceC0531a, "connection");
        InterfaceC0533c interfaceC0533cA = interfaceC0531a.A("PRAGMA table_info(`" + str + "`)");
        try {
            long j3 = 0;
            if (interfaceC0533cA.t()) {
                int iE = e(interfaceC0533cA, "name");
                int iE2 = e(interfaceC0533cA, "type");
                int iE3 = e(interfaceC0533cA, "notnull");
                int iE4 = e(interfaceC0533cA, "pk");
                int iE5 = e(interfaceC0533cA, "dflt_value");
                L1.h hVar = new L1.h();
                while (true) {
                    String strQ = interfaceC0533cA.q(iE);
                    hVar.put(strQ, new v0.l(strQ, interfaceC0533cA.q(iE2), interfaceC0533cA.s(iE3) != j3, (int) interfaceC0533cA.s(iE4), interfaceC0533cA.i(iE5) ? null : interfaceC0533cA.q(iE5), 2));
                    if (!interfaceC0533cA.t()) {
                        break;
                    }
                    j3 = 0;
                }
                mapB = hVar.b();
                L1.d.n(interfaceC0533cA, null);
            } else {
                mapB = K1.v.f683b;
                L1.d.n(interfaceC0533cA, null);
            }
            interfaceC0533cA = interfaceC0531a.A("PRAGMA foreign_key_list(`" + str + "`)");
            try {
                int iE6 = e(interfaceC0533cA, "id");
                int iE7 = e(interfaceC0533cA, "seq");
                int iE8 = e(interfaceC0533cA, "table");
                int iE9 = e(interfaceC0533cA, "on_delete");
                int iE10 = e(interfaceC0533cA, "on_update");
                List listZ = z(interfaceC0533cA);
                interfaceC0533cA.F();
                L1.k kVar2 = new L1.k();
                while (interfaceC0533cA.t()) {
                    if (interfaceC0533cA.s(iE7) == 0) {
                        int iS = (int) interfaceC0533cA.s(iE6);
                        ArrayList arrayList = new ArrayList();
                        ArrayList arrayList2 = new ArrayList();
                        int i = iE6;
                        ArrayList arrayList3 = new ArrayList();
                        for (Object obj : listZ) {
                            int i3 = iE7;
                            List list = listZ;
                            if (((v0.k) obj).f5700b == iS) {
                                arrayList3.add(obj);
                            }
                            iE7 = i3;
                            listZ = list;
                        }
                        int i4 = iE7;
                        List list2 = listZ;
                        Iterator it = arrayList3.iterator();
                        while (it.hasNext()) {
                            v0.k kVar3 = (v0.k) it.next();
                            arrayList.add(kVar3.f5702d);
                            arrayList2.add(kVar3.e);
                        }
                        kVar2.add(new v0.m(interfaceC0533cA.q(iE8), interfaceC0533cA.q(iE9), interfaceC0533cA.q(iE10), arrayList, arrayList2));
                        iE6 = i;
                        iE7 = i4;
                        listZ = list2;
                    }
                }
                L1.k kVarD = AbstractC0046a.d(kVar2);
                L1.d.n(interfaceC0533cA, null);
                interfaceC0533cA = interfaceC0531a.A("PRAGMA index_list(`" + str + "`)");
                try {
                    int iE11 = e(interfaceC0533cA, "name");
                    int iE12 = e(interfaceC0533cA, "origin");
                    int iE13 = e(interfaceC0533cA, "unique");
                    if (iE11 == -1 || iE12 == -1 || iE13 == -1) {
                        L1.d.n(interfaceC0533cA, null);
                        kVar = null;
                    } else {
                        L1.k kVar4 = new L1.k();
                        while (true) {
                            if (!interfaceC0533cA.t()) {
                                break;
                            }
                            if ("c".equals(interfaceC0533cA.q(iE12))) {
                                v0.n nVarA = A(interfaceC0531a, interfaceC0533cA.q(iE11), interfaceC0533cA.s(iE13) == 1);
                                if (nVarA == null) {
                                    L1.d.n(interfaceC0533cA, null);
                                    kVar = null;
                                    break;
                                }
                                kVar4.add(nVarA);
                            }
                        }
                    }
                    return new o(str, mapB, kVarD, kVar);
                } finally {
                }
            } catch (Throwable th) {
                try {
                    throw th;
                } finally {
                }
            }
        } finally {
            try {
                throw th;
            } finally {
            }
        }
    }

    public static final List z(InterfaceC0533c interfaceC0533c) {
        int iE = e(interfaceC0533c, "id");
        int iE2 = e(interfaceC0533c, "seq");
        int iE3 = e(interfaceC0533c, "from");
        int iE4 = e(interfaceC0533c, "to");
        L1.c cVar = new L1.c(10);
        while (interfaceC0533c.t()) {
            cVar.add(new v0.k((int) interfaceC0533c.s(iE), (int) interfaceC0533c.s(iE2), interfaceC0533c.q(iE3), interfaceC0533c.q(iE4)));
        }
        return K1.l.i0(AbstractC0046a.c(cVar));
    }

    public abstract void a(InterfaceC0533c interfaceC0533c, Object obj);

    public abstract boolean b(u.g gVar, u.c cVar);

    public abstract boolean c(u.g gVar, Object obj, Object obj2);

    public abstract boolean d(u.g gVar, u.f fVar, u.f fVar2);

    public abstract String h();

    public void r(InterfaceC0531a interfaceC0531a, Object obj) throws Exception {
        X1.i.e(interfaceC0531a, "connection");
        if (obj == null) {
            return;
        }
        InterfaceC0533c interfaceC0533cA = interfaceC0531a.A(h());
        try {
            a(interfaceC0533cA, obj);
            interfaceC0533cA.t();
            L1.d.n(interfaceC0533cA, null);
        } finally {
        }
    }

    public abstract void w(u.f fVar, u.f fVar2);

    public abstract void x(u.f fVar, Thread thread);
}
