package k1;

/* renamed from: k1.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0244l implements X1.f {
    @Override // X1.f
    public final J1.a a() {
        return C0245m.f3898c;
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof C0244l) && (obj instanceof X1.f)) {
            return C0245m.f3898c.equals(((X1.f) obj).a());
        }
        return false;
    }

    public final int hashCode() {
        return C0245m.f3898c.hashCode();
    }
}
