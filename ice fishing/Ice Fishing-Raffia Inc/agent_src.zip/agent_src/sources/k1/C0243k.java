package k1;

import P.C0023k;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.ViewParent;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.navigation.NavigationView;
import com.kortosi.kluani.qorzanis.MainActivity;
import j0.F;

/* renamed from: k1.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0243k implements Z0.d {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f3895a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ F f3896b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ KeyEvent.Callback f3897c;

    public /* synthetic */ C0243k(MainActivity mainActivity, F f3) {
        this.f3897c = mainActivity;
        this.f3896b = f3;
    }

    @Override // Z0.d
    public final boolean a(MenuItem menuItem) {
        KeyEvent.Callback callback = this.f3897c;
        F f3 = this.f3896b;
        switch (this.f3895a) {
            case 0:
                int i = MainActivity.F;
                X1.i.e(menuItem, "item");
                C0023k c0023k = ((MainActivity) callback).f2782D;
                if (c0023k != null) {
                    ((DrawerLayout) c0023k.f912b).c();
                    return AbstractC0239g.u(menuItem, f3);
                }
                X1.i.g("binding");
                throw null;
            default:
                NavigationView navigationView = (NavigationView) callback;
                X1.i.e(menuItem, "item");
                boolean zU = AbstractC0239g.u(menuItem, f3);
                if (zU) {
                    ViewParent parent = navigationView.getParent();
                    if (parent instanceof V.d) {
                        ((DrawerLayout) ((V.d) parent)).c();
                    } else {
                        BottomSheetBehavior bottomSheetBehaviorM = AbstractC0239g.m(navigationView);
                        if (bottomSheetBehaviorM != null) {
                            bottomSheetBehaviorM.G(5);
                        }
                    }
                }
                return zU;
        }
    }

    public /* synthetic */ C0243k(F f3, NavigationView navigationView) {
        this.f3896b = f3;
        this.f3897c = navigationView;
    }
}
