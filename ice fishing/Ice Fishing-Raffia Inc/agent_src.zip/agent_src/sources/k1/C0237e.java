package k1;

import X1.o;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import com.kortosi.kluani.qorzanis.data.local.DeckLoreDatabase;
import e1.C0123e;
import g2.AbstractC0155t;
import g2.C0156u;
import g2.E;
import g2.Q;
import g2.S;
import g2.Y;
import g2.b0;
import g2.o0;
import h.ExecutorC0185n;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import l1.C0268g;
import n0.ExecutorC0352d;
import o.C0356a;
import q0.AbstractC0398A;
import q0.C0404a;
import q0.C0413j;
import q0.C0418o;
import q0.InterfaceC0405b;
import q0.y;
import q0.z;
import u0.AbstractC0456a;
import u0.AbstractC0457b;
import z0.InterfaceC0539b;

/* renamed from: k1.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0237e implements I1.d {

    /* renamed from: a, reason: collision with root package name */
    public final C0238f f3879a;

    /* renamed from: b, reason: collision with root package name */
    public final int f3880b;

    public C0237e(C0238f c0238f, int i) {
        this.f3879a = c0238f;
        this.f3880b = i;
    }

    @Override // I1.d
    public final Object get() throws ClassNotFoundException {
        String name;
        Y.g gVarC;
        InterfaceC0539b interfaceC0539bA;
        InterfaceC0539b interfaceC0539bA2;
        Executor e;
        N1.i iVarE;
        C0238f c0238f = this.f3879a;
        int i = this.f3880b;
        if (i == 0) {
            DeckLoreDatabase deckLoreDatabase = (DeckLoreDatabase) c0238f.f3883c.get();
            X1.i.e(deckLoreDatabase, "db");
            C0268g c0268gJ = deckLoreDatabase.j();
            if (c0268gJ != null) {
                return new o1.k(c0268gJ);
            }
            throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
        }
        if (i != 1) {
            if (i != 2) {
                throw new AssertionError(i);
            }
            DeckLoreDatabase deckLoreDatabase2 = (DeckLoreDatabase) c0238f.f3883c.get();
            X1.i.e(deckLoreDatabase2, "db");
            C0268g c0268gJ2 = deckLoreDatabase2.j();
            if (c0268gJ2 != null) {
                return new o1.d(c0268gJ2);
            }
            throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
        }
        Context context = c0238f.f3881a.f549a;
        if (context == null) {
            throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
        }
        if (e2.h.z0("deck_lore.db")) {
            throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        I1.c cVar = new I1.c(1);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        ArrayList arrayList3 = new ArrayList();
        X1.e eVarA = o.a(DeckLoreDatabase.class);
        ExecutorC0352d executorC0352d = C0356a.f4712d;
        if (!linkedHashSet2.isEmpty()) {
            Iterator it = linkedHashSet2.iterator();
            while (it.hasNext()) {
                int iIntValue = ((Number) it.next()).intValue();
                if (linkedHashSet.contains(Integer.valueOf(iIntValue))) {
                    throw new IllegalArgumentException(H.e.g("Inconsistency detected. A Migration was supplied to addMigration() that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(). Start version is: ", iIntValue).toString());
                }
            }
        }
        C0123e c0123e = new C0123e();
        Object systemService = context.getSystemService("activity");
        ActivityManager activityManager = systemService instanceof ActivityManager ? (ActivityManager) systemService : null;
        C0404a c0404a = new C0404a(context, "deck_lore.db", c0123e, cVar, arrayList, false, (activityManager == null || activityManager.isLowRamDevice()) ? z.f5252b : z.f5253c, executorC0352d, executorC0352d, null, true, false, linkedHashSet, null, null, null, arrayList2, arrayList3, false, null, null);
        Class clsF = L1.d.F(eVarA);
        Package r02 = clsF.getPackage();
        if (r02 == null || (name = r02.getName()) == null) {
            name = "";
        }
        String canonicalName = clsF.getCanonicalName();
        X1.i.b(canonicalName);
        if (name.length() != 0) {
            canonicalName = canonicalName.substring(name.length() + 1);
            X1.i.d(canonicalName, "substring(...)");
        }
        String strReplace = canonicalName.replace('.', '_');
        X1.i.d(strReplace, "replace(...)");
        String strConcat = strReplace.concat("_Impl");
        try {
            Class<?> cls = Class.forName(name.length() == 0 ? strConcat : name + '.' + strConcat, true, clsF.getClassLoader());
            X1.i.c(cls, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.util.KClassUtil.findAndInstantiateDatabaseImpl>");
            AbstractC0398A abstractC0398A = (AbstractC0398A) cls.getDeclaredConstructor(null).newInstance(null);
            abstractC0398A.getClass();
            abstractC0398A.f5101j = true;
            try {
                gVarC = abstractC0398A.c();
                X1.i.c(gVarC, "null cannot be cast to non-null type androidx.room.RoomOpenDelegate");
            } catch (J1.d unused) {
                gVarC = null;
            }
            if (gVarC == null) {
                new y(c0404a, new d2.j(abstractC0398A));
                throw null;
            }
            abstractC0398A.e = new y(c0404a, gVarC);
            abstractC0398A.f5098f = abstractC0398A.b();
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Set setE = abstractC0398A.e();
            List list = c0404a.f5193r;
            int size = list.size();
            boolean[] zArr = new boolean[size];
            Iterator it2 = setE.iterator();
            while (true) {
                int i3 = -1;
                if (!it2.hasNext()) {
                    int size2 = list.size() - 1;
                    if (size2 >= 0) {
                        while (true) {
                            int i4 = size2 - 1;
                            if (size2 >= size || !zArr[size2]) {
                                break;
                            }
                            if (i4 < 0) {
                                break;
                            }
                            size2 = i4;
                        }
                        throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.");
                    }
                    Iterator it3 = abstractC0398A.a(linkedHashMap).iterator();
                    if (it3.hasNext()) {
                        it3.next().getClass();
                        throw new ClassCastException();
                    }
                    LinkedHashMap linkedHashMapF = abstractC0398A.f();
                    List list2 = c0404a.f5192q;
                    boolean[] zArr2 = new boolean[list2.size()];
                    for (Map.Entry entry : linkedHashMapF.entrySet()) {
                        c2.b bVar = (c2.b) entry.getKey();
                        for (c2.b bVar2 : (List) entry.getValue()) {
                            int size3 = list2.size() - 1;
                            if (size3 >= 0) {
                                while (true) {
                                    int i5 = size3 - 1;
                                    if (((X1.e) bVar2).c(list2.get(size3))) {
                                        zArr2[size3] = true;
                                        break;
                                    }
                                    if (i5 < 0) {
                                        break;
                                    }
                                    size3 = i5;
                                }
                                size3 = -1;
                            } else {
                                size3 = -1;
                            }
                            if (size3 < 0) {
                                throw new IllegalArgumentException(("A required type converter (" + ((X1.e) bVar2).b() + ") for " + ((X1.e) bVar).b() + " is missing in the database configuration.").toString());
                            }
                            Object obj = list2.get(size3);
                            X1.i.e(bVar2, "kclass");
                            X1.i.e(obj, "converter");
                            abstractC0398A.i.put(bVar2, obj);
                        }
                    }
                    int size4 = list2.size() - 1;
                    if (size4 >= 0) {
                        while (true) {
                            int i6 = size4 - 1;
                            if (!zArr2[size4]) {
                                throw new IllegalArgumentException("Unexpected type converter " + list2.get(size4) + ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                            }
                            if (i6 < 0) {
                                break;
                            }
                            size4 = i6;
                        }
                    }
                    C0156u c0156u = C0156u.f3173c;
                    N1.i iVar = c0404a.f5196u;
                    if (iVar != null) {
                        N1.g gVarC2 = iVar.C(N1.e.f808b);
                        X1.i.c(gVarC2, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
                        AbstractC0155t abstractC0155t = (AbstractC0155t) gVarC2;
                        Q q2 = abstractC0155t instanceof Q ? (Q) abstractC0155t : null;
                        if (q2 == null || (e = q2.L()) == null) {
                            e = new E(abstractC0155t);
                        }
                        abstractC0398A.f5096c = e;
                        abstractC0398A.f5097d = new ExecutorC0185n(e);
                        N1.i iVarE2 = iVar.E(new o0((Y) iVar.C(c0156u)));
                        if (iVarE2.C(c0156u) == null) {
                            iVarE2 = iVarE2.E(new b0(null));
                        }
                        abstractC0398A.f5094a = new l2.e(iVarE2);
                        if (abstractC0398A.g()) {
                            l2.e eVar = abstractC0398A.f5094a;
                            if (eVar == null) {
                                X1.i.g("coroutineScope");
                                throw null;
                            }
                            iVarE = eVar.f4089b.E(abstractC0155t.K(1));
                        } else {
                            l2.e eVar2 = abstractC0398A.f5094a;
                            if (eVar2 == null) {
                                X1.i.g("coroutineScope");
                                throw null;
                            }
                            iVarE = eVar2.f4089b;
                        }
                        abstractC0398A.f5095b = iVarE;
                    } else {
                        abstractC0398A.f5096c = c0404a.f5184h;
                        abstractC0398A.f5097d = new ExecutorC0185n(c0404a.i);
                        Executor executor = abstractC0398A.f5096c;
                        if (executor == null) {
                            X1.i.g("internalQueryExecutor");
                            throw null;
                        }
                        E e3 = executor instanceof E ? (E) executor : null;
                        N1.i iVarG0 = L1.d.g0(e3 != null ? e3.f3103b : new S(executor), new o0(null));
                        if (iVarG0.C(c0156u) == null) {
                            iVarG0 = iVarG0.E(new b0(null));
                        }
                        abstractC0398A.f5094a = new l2.e(iVarG0);
                        ExecutorC0185n executorC0185n = abstractC0398A.f5097d;
                        if (executorC0185n == null) {
                            X1.i.g("internalTransactionExecutor");
                            throw null;
                        }
                        abstractC0398A.f5095b = iVarG0.E(new S(executorC0185n));
                    }
                    y yVar = abstractC0398A.e;
                    if (yVar == null) {
                        X1.i.g("connectionManager");
                        throw null;
                    }
                    InterfaceC0539b interfaceC0539bC = yVar.c();
                    if (interfaceC0539bC == null) {
                        interfaceC0539bA = null;
                        break;
                    }
                    interfaceC0539bA = interfaceC0539bC;
                    while (!(interfaceC0539bA instanceof AbstractC0457b)) {
                        if (!(interfaceC0539bA instanceof InterfaceC0405b)) {
                            interfaceC0539bA = null;
                            break;
                        }
                        interfaceC0539bA = ((InterfaceC0405b) interfaceC0539bA).a();
                    }
                    y yVar2 = abstractC0398A.e;
                    if (yVar2 == null) {
                        X1.i.g("connectionManager");
                        throw null;
                    }
                    InterfaceC0539b interfaceC0539bC2 = yVar2.c();
                    if (interfaceC0539bC2 == null) {
                        interfaceC0539bA2 = null;
                        break;
                    }
                    interfaceC0539bA2 = interfaceC0539bC2;
                    while (!(interfaceC0539bA2 instanceof AbstractC0456a)) {
                        if (!(interfaceC0539bA2 instanceof InterfaceC0405b)) {
                            interfaceC0539bA2 = null;
                            break;
                        }
                        interfaceC0539bA2 = ((InterfaceC0405b) interfaceC0539bA2).a();
                    }
                    Intent intent = c0404a.f5185j;
                    if (intent != null) {
                        String str = c0404a.f5179b;
                        if (str == null) {
                            throw new IllegalArgumentException("Required value was null.");
                        }
                        C0413j c0413jD = abstractC0398A.d();
                        Context context2 = c0404a.f5178a;
                        X1.i.e(context2, "context");
                        c0413jD.f5211h = intent;
                        c0413jD.i = new C0418o(context2, str, c0413jD);
                    }
                    return (DeckLoreDatabase) abstractC0398A;
                }
                c2.b bVar3 = (c2.b) it2.next();
                int size5 = list.size() - 1;
                if (size5 >= 0) {
                    while (true) {
                        int i7 = size5 - 1;
                        if (((X1.e) bVar3).c(list.get(size5))) {
                            zArr[size5] = true;
                            i3 = size5;
                            break;
                        }
                        if (i7 < 0) {
                            break;
                        }
                        size5 = i7;
                    }
                }
                if (i3 < 0) {
                    throw new IllegalArgumentException(("A required auto migration spec (" + ((X1.e) bVar3).b() + ") is missing in the database configuration.").toString());
                }
                linkedHashMap.put(bVar3, list.get(i3));
            }
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("Cannot find implementation for " + clsF.getCanonicalName() + ". " + strConcat + " does not exist. Is Room annotation processor correctly configured?", e4);
        } catch (IllegalAccessException e5) {
            throw new RuntimeException("Cannot access the constructor " + clsF.getCanonicalName(), e5);
        } catch (InstantiationException e6) {
            throw new RuntimeException("Failed to create an instance of " + clsF.getCanonicalName(), e6);
        }
    }
}
