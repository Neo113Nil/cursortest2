package k1;

/* renamed from: k1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0234b implements I1.d {
    @Override // I1.d
    public final Object get() {
        return new E1.g();
    }
}
