package k1;

import androidx.lifecycle.P;

/* renamed from: k1.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0241i implements E1.e, H1.a {

    /* renamed from: a, reason: collision with root package name */
    public final P f3889a;

    /* renamed from: b, reason: collision with root package name */
    public final C0238f f3890b;

    /* renamed from: c, reason: collision with root package name */
    public final C0240h f3891c;

    /* renamed from: d, reason: collision with root package name */
    public final C0240h f3892d;
    public final C0240h e;

    /* renamed from: f, reason: collision with root package name */
    public final C0240h f3893f;

    /* renamed from: g, reason: collision with root package name */
    public final C0240h f3894g;

    public C0241i(C0238f c0238f, C0235c c0235c, P p2) {
        this.f3890b = c0238f;
        this.f3889a = p2;
        this.f3891c = new C0240h(c0238f, this, 0);
        this.f3892d = new C0240h(c0238f, this, 1);
        this.e = new C0240h(c0238f, this, 2);
        this.f3893f = new C0240h(c0238f, this, 3);
        this.f3894g = new C0240h(c0238f, this, 4);
    }
}
