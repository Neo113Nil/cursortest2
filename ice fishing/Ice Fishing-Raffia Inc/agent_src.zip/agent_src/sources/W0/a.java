package W0;

import L1.d;
import android.content.Context;
import com.kortosi.kluani.qorzanis.R;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: f, reason: collision with root package name */
    public static final int f1188f = (int) Math.round(5.1000000000000005d);

    /* renamed from: a, reason: collision with root package name */
    public final boolean f1189a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1190b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1191c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1192d;
    public final float e;

    public a(Context context) {
        boolean zK0 = d.k0(context, R.attr.elevationOverlayEnabled, false);
        int iW = d.w(context, R.attr.elevationOverlayColor, 0);
        int iW2 = d.w(context, R.attr.elevationOverlayAccentColor, 0);
        int iW3 = d.w(context, R.attr.colorSurface, 0);
        float f3 = context.getResources().getDisplayMetrics().density;
        this.f1189a = zK0;
        this.f1190b = iW;
        this.f1191c = iW2;
        this.f1192d = iW3;
        this.e = f3;
    }
}
