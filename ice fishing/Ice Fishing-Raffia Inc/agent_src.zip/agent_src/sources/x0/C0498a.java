package x0;

import A0.e;
import android.os.Bundle;
import androidx.lifecycle.EnumC0070n;
import j0.C0207l;
import java.util.LinkedHashMap;
import n0.C0353e;
import w0.d;

/* renamed from: x0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0498a {

    /* renamed from: a, reason: collision with root package name */
    public final d f5933a;

    /* renamed from: b, reason: collision with root package name */
    public final e f5934b;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public Bundle f5937f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f5938g;

    /* renamed from: c, reason: collision with root package name */
    public final C0353e f5935c = new C0353e(10);

    /* renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f5936d = new LinkedHashMap();

    /* renamed from: h, reason: collision with root package name */
    public boolean f5939h = true;

    public C0498a(d dVar, e eVar) {
        this.f5933a = dVar;
        this.f5934b = eVar;
    }

    public final void a() {
        d dVar = this.f5933a;
        if (dVar.e().f1837d != EnumC0070n.f1823c) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        if (this.e) {
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        this.f5934b.a();
        dVar.e().a(new C0207l(2, this));
        this.e = true;
    }
}
