package b0;

import android.R;

/* renamed from: b0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0083a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f2044a = {R.attr.name, R.attr.id, R.attr.tag};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f2045b = {R.attr.name, R.attr.tag};
}
