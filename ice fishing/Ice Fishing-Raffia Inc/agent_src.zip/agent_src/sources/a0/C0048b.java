package a0;

import android.os.Bundle;
import android.text.Editable;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.widget.EditText;
import e1.C0123e;
import java.nio.ByteBuffer;

/* renamed from: a0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0048b extends InputConnectionWrapper {

    /* renamed from: a, reason: collision with root package name */
    public final EditText f1455a;

    /* renamed from: b, reason: collision with root package name */
    public final C0123e f1456b;

    public C0048b(EditText editText, InputConnection inputConnection, EditorInfo editorInfo) {
        C0123e c0123e = new C0123e();
        super(inputConnection, false);
        this.f1455a = editText;
        this.f1456b = c0123e;
        if (Y.j.f1378k != null) {
            Y.j jVarA = Y.j.a();
            if (jVarA.b() != 1 || editorInfo == null) {
                return;
            }
            if (editorInfo.extras == null) {
                editorInfo.extras = new Bundle();
            }
            Y.f fVar = jVarA.e;
            fVar.getClass();
            Bundle bundle = editorInfo.extras;
            Z.b bVar = (Z.b) fVar.f1373c.f271a;
            int iA = bVar.a(4);
            bundle.putInt("android.support.text.emoji.emojiCompat_metadataVersion", iA != 0 ? ((ByteBuffer) bVar.e).getInt(iA + bVar.f714b) : 0);
            Bundle bundle2 = editorInfo.extras;
            fVar.f1371a.getClass();
            bundle2.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", false);
        }
    }

    @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
    public final boolean deleteSurroundingText(int i, int i3) {
        Editable editableText = this.f1455a.getEditableText();
        this.f1456b.getClass();
        return C0123e.i(this, editableText, i, i3, false) || super.deleteSurroundingText(i, i3);
    }

    @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
    public final boolean deleteSurroundingTextInCodePoints(int i, int i3) {
        Editable editableText = this.f1455a.getEditableText();
        this.f1456b.getClass();
        return C0123e.i(this, editableText, i, i3, true) || super.deleteSurroundingTextInCodePoints(i, i3);
    }
}
