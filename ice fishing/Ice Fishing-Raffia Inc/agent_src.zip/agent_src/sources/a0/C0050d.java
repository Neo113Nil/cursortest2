package a0;

import android.text.InputFilter;
import android.text.Spanned;
import android.widget.TextView;

/* renamed from: a0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0050d implements InputFilter {

    /* renamed from: a, reason: collision with root package name */
    public final TextView f1459a;

    /* renamed from: b, reason: collision with root package name */
    public C0049c f1460b;

    public C0050d(TextView textView) {
        this.f1459a = textView;
    }

    @Override // android.text.InputFilter
    public final CharSequence filter(CharSequence charSequence, int i, int i3, Spanned spanned, int i4, int i5) {
        TextView textView = this.f1459a;
        if (textView.isInEditMode()) {
            return charSequence;
        }
        int iB = Y.j.a().b();
        if (iB != 0) {
            if (iB == 1) {
                if ((i5 == 0 && i4 == 0 && spanned.length() == 0 && charSequence == textView.getText()) || charSequence == null) {
                    return charSequence;
                }
                if (i != 0 || i3 != charSequence.length()) {
                    charSequence = charSequence.subSequence(i, i3);
                }
                return Y.j.a().e(charSequence, 0, charSequence.length());
            }
            if (iB != 3) {
                return charSequence;
            }
        }
        Y.j jVarA = Y.j.a();
        if (this.f1460b == null) {
            this.f1460b = new C0049c(textView, this);
        }
        jVarA.f(this.f1460b);
        return charSequence;
    }
}
