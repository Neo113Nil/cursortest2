package a0;

import P.C0023k;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.View;
import e1.C0123e;

/* renamed from: a0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0051e implements KeyListener {

    /* renamed from: a, reason: collision with root package name */
    public final KeyListener f1461a;

    /* renamed from: b, reason: collision with root package name */
    public final C0123e f1462b;

    public C0051e(KeyListener keyListener) {
        C0123e c0123e = new C0123e();
        this.f1461a = keyListener;
        this.f1462b = c0123e;
    }

    @Override // android.text.method.KeyListener
    public final void clearMetaKeyState(View view, Editable editable, int i) {
        this.f1461a.clearMetaKeyState(view, editable, i);
    }

    @Override // android.text.method.KeyListener
    public final int getInputType() {
        return this.f1461a.getInputType();
    }

    @Override // android.text.method.KeyListener
    public final boolean onKeyDown(View view, Editable editable, int i, KeyEvent keyEvent) {
        boolean z2;
        this.f1462b.getClass();
        if (i != 67 ? i != 112 ? false : C0023k.a(editable, keyEvent, true) : C0023k.a(editable, keyEvent, false)) {
            MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
            z2 = true;
        } else {
            z2 = false;
        }
        return z2 || this.f1461a.onKeyDown(view, editable, i, keyEvent);
    }

    @Override // android.text.method.KeyListener
    public final boolean onKeyOther(View view, Editable editable, KeyEvent keyEvent) {
        return this.f1461a.onKeyOther(view, editable, keyEvent);
    }

    @Override // android.text.method.KeyListener
    public final boolean onKeyUp(View view, Editable editable, int i, KeyEvent keyEvent) {
        return this.f1461a.onKeyUp(view, editable, i, keyEvent);
    }
}
