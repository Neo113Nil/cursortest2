package a0;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

/* renamed from: a0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0052f extends L1.d {
    public final TextView e;

    /* renamed from: f, reason: collision with root package name */
    public final C0050d f1463f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1464g = true;

    public C0052f(TextView textView) {
        this.e = textView;
        this.f1463f = new C0050d(textView);
    }

    @Override // L1.d
    public final TransformationMethod A0(TransformationMethod transformationMethod) {
        return this.f1464g ? ((transformationMethod instanceof C0056j) || (transformationMethod instanceof PasswordTransformationMethod)) ? transformationMethod : new C0056j(transformationMethod) : transformationMethod instanceof C0056j ? ((C0056j) transformationMethod).f1470a : transformationMethod;
    }

    @Override // L1.d
    public final InputFilter[] E(InputFilter[] inputFilterArr) {
        if (!this.f1464g) {
            SparseArray sparseArray = new SparseArray(1);
            for (int i = 0; i < inputFilterArr.length; i++) {
                InputFilter inputFilter = inputFilterArr[i];
                if (inputFilter instanceof C0050d) {
                    sparseArray.put(i, inputFilter);
                }
            }
            if (sparseArray.size() == 0) {
                return inputFilterArr;
            }
            int length = inputFilterArr.length;
            InputFilter[] inputFilterArr2 = new InputFilter[inputFilterArr.length - sparseArray.size()];
            int i3 = 0;
            for (int i4 = 0; i4 < length; i4++) {
                if (sparseArray.indexOfKey(i4) < 0) {
                    inputFilterArr2[i3] = inputFilterArr[i4];
                    i3++;
                }
            }
            return inputFilterArr2;
        }
        int length2 = inputFilterArr.length;
        int i5 = 0;
        while (true) {
            C0050d c0050d = this.f1463f;
            if (i5 >= length2) {
                InputFilter[] inputFilterArr3 = new InputFilter[inputFilterArr.length + 1];
                System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                inputFilterArr3[length2] = c0050d;
                return inputFilterArr3;
            }
            if (inputFilterArr[i5] == c0050d) {
                return inputFilterArr;
            }
            i5++;
        }
    }

    @Override // L1.d
    public final boolean P() {
        return this.f1464g;
    }

    @Override // L1.d
    public final void p0(boolean z2) {
        if (z2) {
            TextView textView = this.e;
            textView.setTransformationMethod(A0(textView.getTransformationMethod()));
        }
    }

    @Override // L1.d
    public final void s0(boolean z2) {
        this.f1464g = z2;
        TextView textView = this.e;
        textView.setTransformationMethod(A0(textView.getTransformationMethod()));
        textView.setFilters(E(textView.getFilters()));
    }
}
