package a0;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.TextWatcher;
import android.widget.EditText;

/* renamed from: a0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0055i implements TextWatcher {

    /* renamed from: b, reason: collision with root package name */
    public final EditText f1467b;

    /* renamed from: c, reason: collision with root package name */
    public C0054h f1468c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1469d = true;

    public C0055i(EditText editText) {
        this.f1467b = editText;
    }

    public static void a(EditText editText, int i) {
        int length;
        if (i == 1 && editText != null && editText.isAttachedToWindow()) {
            Editable editableText = editText.getEditableText();
            int selectionStart = Selection.getSelectionStart(editableText);
            int selectionEnd = Selection.getSelectionEnd(editableText);
            Y.j jVarA = Y.j.a();
            if (editableText == null) {
                length = 0;
            } else {
                jVarA.getClass();
                length = editableText.length();
            }
            jVarA.e(editableText, 0, length);
            if (selectionStart >= 0 && selectionEnd >= 0) {
                Selection.setSelection(editableText, selectionStart, selectionEnd);
            } else if (selectionStart >= 0) {
                Selection.setSelection(editableText, selectionStart);
            } else if (selectionEnd >= 0) {
                Selection.setSelection(editableText, selectionEnd);
            }
        }
    }

    @Override // android.text.TextWatcher
    public final void afterTextChanged(Editable editable) {
    }

    @Override // android.text.TextWatcher
    public final void beforeTextChanged(CharSequence charSequence, int i, int i3, int i4) {
    }

    @Override // android.text.TextWatcher
    public final void onTextChanged(CharSequence charSequence, int i, int i3, int i4) {
        EditText editText = this.f1467b;
        if (editText.isInEditMode() || !this.f1469d || Y.j.f1378k == null || i3 > i4 || !(charSequence instanceof Spannable)) {
            return;
        }
        int iB = Y.j.a().b();
        if (iB != 0) {
            if (iB == 1) {
                Y.j.a().e((Spannable) charSequence, i, i4 + i);
                return;
            } else if (iB != 3) {
                return;
            }
        }
        Y.j jVarA = Y.j.a();
        if (this.f1468c == null) {
            this.f1468c = new C0054h(editText);
        }
        jVarA.f(this.f1468c);
    }
}
