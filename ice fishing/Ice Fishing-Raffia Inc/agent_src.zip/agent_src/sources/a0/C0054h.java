package a0;

import android.widget.EditText;
import java.lang.ref.WeakReference;
import n.W0;

/* renamed from: a0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0054h extends Y.h {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1465a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final WeakReference f1466b;

    public C0054h(EditText editText) {
        this.f1466b = new WeakReference(editText);
    }

    @Override // Y.h
    public void a() {
        switch (this.f1465a) {
            case 1:
                W0 w02 = (W0) this.f1466b.get();
                if (w02 != null) {
                    w02.c();
                    break;
                }
                break;
        }
    }

    @Override // Y.h
    public final void b() {
        switch (this.f1465a) {
            case 0:
                C0055i.a((EditText) this.f1466b.get(), 1);
                break;
            default:
                W0 w02 = (W0) this.f1466b.get();
                if (w02 != null) {
                    w02.c();
                    break;
                }
                break;
        }
    }

    public C0054h(W0 w02) {
        this.f1466b = new WeakReference(w02);
    }
}
