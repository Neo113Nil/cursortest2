package a0;

import Y.w;
import android.text.Editable;

/* renamed from: a0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0047a extends Editable.Factory {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f1452a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public static volatile C0047a f1453b;

    /* renamed from: c, reason: collision with root package name */
    public static Class f1454c;

    @Override // android.text.Editable.Factory
    public final Editable newEditable(CharSequence charSequence) {
        Class cls = f1454c;
        return cls != null ? new w(cls, charSequence) : super.newEditable(charSequence);
    }
}
