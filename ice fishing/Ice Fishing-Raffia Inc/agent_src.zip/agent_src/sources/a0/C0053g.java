package a0;

import android.text.InputFilter;
import android.text.method.TransformationMethod;
import android.widget.TextView;

/* renamed from: a0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0053g extends L1.d {
    public final C0052f e;

    public C0053g(TextView textView) {
        this.e = new C0052f(textView);
    }

    @Override // L1.d
    public final TransformationMethod A0(TransformationMethod transformationMethod) {
        return !(Y.j.f1378k != null) ? transformationMethod : this.e.A0(transformationMethod);
    }

    @Override // L1.d
    public final InputFilter[] E(InputFilter[] inputFilterArr) {
        return !(Y.j.f1378k != null) ? inputFilterArr : this.e.E(inputFilterArr);
    }

    @Override // L1.d
    public final boolean P() {
        return this.e.f1464g;
    }

    @Override // L1.d
    public final void p0(boolean z2) {
        if (Y.j.f1378k != null) {
            this.e.p0(z2);
        }
    }

    @Override // L1.d
    public final void s0(boolean z2) {
        boolean z3 = Y.j.f1378k != null;
        C0052f c0052f = this.e;
        if (z3) {
            c0052f.s0(z2);
        } else {
            c0052f.f1464g = z2;
        }
    }
}
