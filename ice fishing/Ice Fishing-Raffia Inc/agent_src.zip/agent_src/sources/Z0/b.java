package Z0;

import com.google.android.material.navigation.NavigationView;

/* loaded from: classes.dex */
public final class b implements X.c {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ NavigationView f1439a;

    public b(NavigationView navigationView) {
        this.f1439a = navigationView;
    }
}
