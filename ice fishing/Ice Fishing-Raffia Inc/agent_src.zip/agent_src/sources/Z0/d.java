package Z0;

import android.view.MenuItem;

/* loaded from: classes.dex */
public interface d {
    boolean a(MenuItem menuItem);
}
