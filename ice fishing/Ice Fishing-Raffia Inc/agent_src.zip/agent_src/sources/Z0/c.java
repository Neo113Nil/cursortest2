package Z0;

import X0.E;
import X0.u;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import com.google.android.material.internal.NavigationMenuView;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.Iterator;
import m.C0278e;
import m.ViewOnKeyListenerC0272C;
import m.ViewOnKeyListenerC0279f;
import n.P0;
import n.Q;
import n.U;

/* loaded from: classes.dex */
public final class c implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1440b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1441c;

    public /* synthetic */ c(int i, Object obj) {
        this.f1440b = i;
        this.f1441c = obj;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        Activity activity;
        Rect rect;
        Object obj = this.f1441c;
        switch (this.f1440b) {
            case 0:
                NavigationView navigationView = (NavigationView) obj;
                navigationView.getLocationOnScreen(navigationView.f2626m);
                int[] iArr = navigationView.f2626m;
                boolean z2 = iArr[1] == 0;
                u uVar = navigationView.f2623j;
                if (uVar.f1334y != z2) {
                    uVar.f1334y = z2;
                    int i = (uVar.f1314c.getChildCount() <= 0 && uVar.f1334y) ? uVar.f1309A : 0;
                    NavigationMenuView navigationMenuView = uVar.f1313b;
                    navigationMenuView.setPadding(0, i, 0, navigationMenuView.getPaddingBottom());
                }
                navigationView.setDrawTopInsetForeground(z2 && navigationView.f2629p);
                int i3 = iArr[0];
                navigationView.setDrawLeftInsetForeground(i3 == 0 || navigationView.getWidth() + i3 == 0);
                Context context = navigationView.getContext();
                while (true) {
                    if (!(context instanceof ContextWrapper)) {
                        activity = null;
                    } else if (context instanceof Activity) {
                        activity = (Activity) context;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                }
                if (activity != null) {
                    int i4 = Build.VERSION.SDK_INT;
                    int i5 = E.f1223d;
                    WindowManager windowManager = (WindowManager) activity.getSystemService("window");
                    if (i4 >= 30) {
                        rect = windowManager.getCurrentWindowMetrics().getBounds();
                    } else {
                        Display defaultDisplay = windowManager.getDefaultDisplay();
                        Point point = new Point();
                        defaultDisplay.getRealSize(point);
                        rect = new Rect();
                        rect.right = point.x;
                        rect.bottom = point.y;
                    }
                    navigationView.setDrawBottomInsetForeground((rect.height() - navigationView.getHeight() == iArr[1]) && (Color.alpha(activity.getWindow().getNavigationBarColor()) != 0) && navigationView.f2630q);
                    navigationView.setDrawRightInsetForeground(rect.width() == iArr[0] || rect.width() - navigationView.getWidth() == iArr[0]);
                    break;
                }
                break;
            case 1:
                ViewOnKeyListenerC0279f viewOnKeyListenerC0279f = (ViewOnKeyListenerC0279f) obj;
                if (viewOnKeyListenerC0279f.a()) {
                    ArrayList arrayList = viewOnKeyListenerC0279f.i;
                    if (arrayList.size() > 0 && !((C0278e) arrayList.get(0)).f4165a.f4375z) {
                        View view = viewOnKeyListenerC0279f.f4180p;
                        if (view != null && view.isShown()) {
                            Iterator it = arrayList.iterator();
                            while (it.hasNext()) {
                                ((C0278e) it.next()).f4165a.h();
                            }
                            break;
                        } else {
                            viewOnKeyListenerC0279f.dismiss();
                            break;
                        }
                    }
                }
                break;
            case 2:
                ViewOnKeyListenerC0272C viewOnKeyListenerC0272C = (ViewOnKeyListenerC0272C) obj;
                if (viewOnKeyListenerC0272C.a()) {
                    P0 p02 = viewOnKeyListenerC0272C.i;
                    if (!p02.f4375z) {
                        View view2 = viewOnKeyListenerC0272C.f4135n;
                        if (view2 != null && view2.isShown()) {
                            p02.h();
                            break;
                        } else {
                            viewOnKeyListenerC0272C.dismiss();
                            break;
                        }
                    }
                }
                break;
            case 3:
                U u2 = (U) obj;
                if (!u2.getInternalPopup().a()) {
                    u2.f4415g.f(u2.getTextDirection(), u2.getTextAlignment());
                }
                ViewTreeObserver viewTreeObserver = u2.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeOnGlobalLayoutListener(this);
                    break;
                }
                break;
            default:
                Q q2 = (Q) obj;
                U u3 = q2.f4394H;
                q2.getClass();
                if (!u3.isAttachedToWindow() || !u3.getGlobalVisibleRect(q2.F)) {
                    q2.dismiss();
                    break;
                } else {
                    q2.s();
                    q2.h();
                    break;
                }
                break;
        }
    }
}
