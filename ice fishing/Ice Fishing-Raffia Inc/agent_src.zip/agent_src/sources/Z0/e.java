package Z0;

import C.h;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class e extends U.b {
    public static final Parcelable.Creator<e> CREATOR = new h(7);

    /* renamed from: d, reason: collision with root package name */
    public Bundle f1442d;

    public e(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f1442d = parcel.readBundle(classLoader);
    }

    @Override // U.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeBundle(this.f1442d);
    }
}
