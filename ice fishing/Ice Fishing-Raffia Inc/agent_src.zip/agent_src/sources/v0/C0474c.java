package v0;

import a.AbstractC0046a;
import l1.C0267f;
import q0.AbstractC0398A;

/* renamed from: v0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0474c extends P1.g implements W1.l {

    /* renamed from: f, reason: collision with root package name */
    public int f5671f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ AbstractC0398A f5672g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0267f f5673h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0474c(N1.d dVar, C0267f c0267f, AbstractC0398A abstractC0398A) {
        super(1, dVar);
        this.f5672g = abstractC0398A;
        this.f5673h = c0267f;
    }

    @Override // W1.l
    public final Object h(Object obj) {
        return new C0474c((N1.d) obj, this.f5673h, this.f5672g).o(J1.k.f632a);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5671f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            C0267f c0267f = this.f5673h;
            AbstractC0398A abstractC0398A = this.f5672g;
            C0473b c0473b = new C0473b(null, c0267f, abstractC0398A);
            this.f5671f = 1;
            obj = abstractC0398A.i(false, c0473b, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
