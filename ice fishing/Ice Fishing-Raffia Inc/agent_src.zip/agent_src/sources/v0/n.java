package v0;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public final String f5713a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f5714b;

    /* renamed from: c, reason: collision with root package name */
    public final List f5715c;

    /* renamed from: d, reason: collision with root package name */
    public final List f5716d;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0, types: [java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.util.ArrayList] */
    public n(String str, boolean z2, List list, List list2) {
        X1.i.e(str, "name");
        this.f5713a = str;
        this.f5714b = z2;
        this.f5715c = list;
        this.f5716d = list2;
        if (list2.isEmpty()) {
            int size = list.size();
            list2 = new ArrayList(size);
            for (int i = 0; i < size; i++) {
                list2.add("ASC");
            }
        }
        this.f5716d = list2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof n) {
            n nVar = (n) obj;
            if (this.f5714b == nVar.f5714b && this.f5715c.equals(nVar.f5715c) && X1.i.a(this.f5716d, nVar.f5716d)) {
                String str = this.f5713a;
                boolean zB0 = e2.h.B0(str, "index_");
                String str2 = nVar.f5713a;
                return zB0 ? e2.h.B0(str2, "index_") : str.equals(str2);
            }
        }
        return false;
    }

    public final int hashCode() {
        String str = this.f5713a;
        return this.f5716d.hashCode() + ((this.f5715c.hashCode() + ((((e2.h.B0(str, "index_") ? -1184239155 : str.hashCode()) * 31) + (this.f5714b ? 1 : 0)) * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("\n            |Index {\n            |   name = '");
        sb.append(this.f5713a);
        sb.append("',\n            |   unique = '");
        sb.append(this.f5714b);
        sb.append("',\n            |   columns = {");
        e2.b.s0(K1.l.b0(this.f5715c, ",", null, null, null, 62));
        e2.b.s0("},");
        J1.k kVar = J1.k.f632a;
        sb.append(kVar);
        sb.append("\n            |   orders = {");
        e2.b.s0(K1.l.b0(this.f5716d, ",", null, null, null, 62));
        e2.b.s0(" }");
        sb.append(kVar);
        sb.append("\n            |}\n        ");
        return e2.b.s0(e2.b.t0(sb.toString()));
    }
}
