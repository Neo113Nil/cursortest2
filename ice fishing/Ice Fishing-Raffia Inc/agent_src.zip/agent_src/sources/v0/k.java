package v0;

/* loaded from: classes.dex */
public final class k implements Comparable {

    /* renamed from: b, reason: collision with root package name */
    public final int f5700b;

    /* renamed from: c, reason: collision with root package name */
    public final int f5701c;

    /* renamed from: d, reason: collision with root package name */
    public final String f5702d;
    public final String e;

    public k(int i, int i3, String str, String str2) {
        X1.i.e(str, "from");
        X1.i.e(str2, "to");
        this.f5700b = i;
        this.f5701c = i3;
        this.f5702d = str;
        this.e = str2;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        k kVar = (k) obj;
        X1.i.e(kVar, "other");
        int i = this.f5700b - kVar.f5700b;
        return i == 0 ? this.f5701c - kVar.f5701c : i;
    }
}
