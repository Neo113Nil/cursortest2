package v0;

import W1.p;
import a.AbstractC0046a;
import l1.C0267f;

/* loaded from: classes.dex */
public final class d extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public int f5674f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f5675g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0267f f5676h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(N1.d dVar, C0267f c0267f) {
        super(2, dVar);
        this.f5676h = c0267f;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((d) m((N1.d) obj2, (s0.n) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        d dVar2 = new d(dVar, this.f5676h);
        dVar2.f5675g = obj;
        return dVar2;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5674f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            this.f5674f = 1;
            obj = this.f5676h.h(this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
