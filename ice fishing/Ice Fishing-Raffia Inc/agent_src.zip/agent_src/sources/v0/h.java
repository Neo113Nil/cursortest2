package v0;

import k1.AbstractC0239g;
import q0.AbstractC0398A;

/* loaded from: classes.dex */
public final class h extends P1.c {
    public AbstractC0398A e;

    /* renamed from: f, reason: collision with root package name */
    public W1.l f5688f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f5689g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f5690h;
    public /* synthetic */ Object i;

    /* renamed from: j, reason: collision with root package name */
    public int f5691j;

    @Override // P1.a
    public final Object o(Object obj) {
        this.i = obj;
        this.f5691j |= Integer.MIN_VALUE;
        return AbstractC0239g.v(this, null, null, false, false);
    }
}
