package v0;

import K1.u;
import java.util.AbstractSet;
import java.util.Map;
import k1.AbstractC0239g;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final String f5717a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f5718b;

    /* renamed from: c, reason: collision with root package name */
    public final AbstractSet f5719c;

    /* renamed from: d, reason: collision with root package name */
    public final AbstractSet f5720d;

    public o(String str, Map map, AbstractSet abstractSet, AbstractSet abstractSet2) {
        X1.i.e(abstractSet, "foreignKeys");
        this.f5717a = str;
        this.f5718b = map;
        this.f5719c = abstractSet;
        this.f5720d = abstractSet2;
    }

    public final boolean equals(Object obj) {
        AbstractSet abstractSet;
        if (this == obj) {
            return true;
        }
        if (obj instanceof o) {
            o oVar = (o) obj;
            if (this.f5717a.equals(oVar.f5717a) && this.f5718b.equals(oVar.f5718b) && X1.i.a(this.f5719c, oVar.f5719c)) {
                AbstractSet abstractSet2 = this.f5720d;
                if (abstractSet2 == null || (abstractSet = oVar.f5720d) == null) {
                    return true;
                }
                return abstractSet2.equals(abstractSet);
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f5719c.hashCode() + ((this.f5718b.hashCode() + (this.f5717a.hashCode() * 31)) * 31);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [java.lang.Object, java.util.Map] */
    public final String toString() {
        StringBuilder sb = new StringBuilder("\n            |TableInfo {\n            |    name = '");
        sb.append(this.f5717a);
        sb.append("',\n            |    columns = {");
        sb.append(AbstractC0239g.n(K1.l.j0(this.f5718b.values(), new C.j(7))));
        sb.append("\n            |    foreignKeys = {");
        sb.append(AbstractC0239g.n(this.f5719c));
        sb.append("\n            |    indices = {");
        AbstractSet abstractSet = this.f5720d;
        sb.append(AbstractC0239g.n(abstractSet != null ? K1.l.j0(abstractSet, new C.j(8)) : u.f682b));
        sb.append("\n            |}\n        ");
        return e2.b.t0(sb.toString());
    }
}
