package v0;

import W1.p;
import a.AbstractC0046a;
import g2.InterfaceC0158w;
import l1.C0267f;
import q0.AbstractC0398A;

/* loaded from: classes.dex */
public final class f extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public int f5681f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ AbstractC0398A f5682g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ C0267f f5683h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(N1.d dVar, C0267f c0267f, AbstractC0398A abstractC0398A) {
        super(2, dVar);
        this.f5682g = abstractC0398A;
        this.f5683h = c0267f;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((f) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new f(dVar, this.f5683h, this.f5682g);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5681f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            C0267f c0267f = this.f5683h;
            AbstractC0398A abstractC0398A = this.f5682g;
            e eVar = new e(null, c0267f, abstractC0398A);
            this.f5681f = 1;
            obj = abstractC0398A.i(false, eVar, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
