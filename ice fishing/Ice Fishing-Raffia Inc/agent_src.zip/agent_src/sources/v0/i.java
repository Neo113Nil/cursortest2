package v0;

import W1.p;
import a.AbstractC0046a;

/* loaded from: classes.dex */
public final class i extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f5692f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ W1.l f5693g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(N1.d dVar, W1.l lVar) {
        super(2, dVar);
        this.f5693g = lVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((i) m((N1.d) obj2, (s0.n) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        i iVar = new i(dVar, this.f5693g);
        iVar.f5692f = obj;
        return iVar;
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        AbstractC0046a.N(obj);
        s0.n nVar = (s0.n) this.f5692f;
        X1.i.c(nVar, "null cannot be cast to non-null type androidx.room.coroutines.RawConnectionAccessor");
        return this.f5693g.h(nVar.b());
    }
}
