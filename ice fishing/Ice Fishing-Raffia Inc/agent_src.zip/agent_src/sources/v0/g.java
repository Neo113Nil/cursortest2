package v0;

import W1.p;
import a.AbstractC0046a;
import g2.InterfaceC0158w;
import q0.AbstractC0398A;

/* loaded from: classes.dex */
public final class g extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public int f5684f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ AbstractC0398A f5685g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ boolean f5686h;
    public final /* synthetic */ boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ W1.l f5687j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(N1.d dVar, W1.l lVar, AbstractC0398A abstractC0398A, boolean z2, boolean z3) {
        super(2, dVar);
        this.f5685g = abstractC0398A;
        this.f5686h = z2;
        this.i = z3;
        this.f5687j = lVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((g) m((N1.d) obj2, (InterfaceC0158w) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        return new g(dVar, this.f5687j, this.f5685g, this.f5686h, this.i);
    }

    @Override // P1.a
    public final Object o(Object obj) throws Throwable {
        O1.a aVar = O1.a.f839b;
        int i = this.f5684f;
        if (i == 0) {
            AbstractC0046a.N(obj);
            boolean z2 = this.i;
            boolean z3 = this.f5686h;
            AbstractC0398A abstractC0398A = this.f5685g;
            j jVar = new j(null, this.f5687j, abstractC0398A, z2, z3);
            this.f5684f = 1;
            obj = abstractC0398A.i(z3, jVar, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0046a.N(obj);
        }
        return obj;
    }
}
