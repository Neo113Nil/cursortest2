package v0;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class m {

    /* renamed from: a, reason: collision with root package name */
    public final String f5709a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5710b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5711c;

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList f5712d;
    public final ArrayList e;

    public m(String str, String str2, String str3, ArrayList arrayList, ArrayList arrayList2) {
        X1.i.e(str, "referenceTable");
        X1.i.e(str2, "onDelete");
        X1.i.e(str3, "onUpdate");
        this.f5709a = str;
        this.f5710b = str2;
        this.f5711c = str3;
        this.f5712d = arrayList;
        this.e = arrayList2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof m) {
            m mVar = (m) obj;
            if (X1.i.a(this.f5709a, mVar.f5709a) && X1.i.a(this.f5710b, mVar.f5710b) && X1.i.a(this.f5711c, mVar.f5711c) && this.f5712d.equals(mVar.f5712d)) {
                return this.e.equals(mVar.e);
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() + ((this.f5712d.hashCode() + H.e.c(this.f5711c, H.e.c(this.f5710b, this.f5709a.hashCode() * 31, 31), 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("\n            |ForeignKey {\n            |   referenceTable = '");
        sb.append(this.f5709a);
        sb.append("',\n            |   onDelete = '");
        sb.append(this.f5710b);
        sb.append("',\n            |   onUpdate = '");
        sb.append(this.f5711c);
        sb.append("',\n            |   columnNames = {");
        e2.b.s0(K1.l.b0(K1.l.i0(this.f5712d), ",", null, null, null, 62));
        e2.b.s0("},");
        J1.k kVar = J1.k.f632a;
        sb.append(kVar);
        sb.append("\n            |   referenceColumnNames = {");
        e2.b.s0(K1.l.b0(K1.l.i0(this.e), ",", null, null, null, 62));
        e2.b.s0(" }");
        sb.append(kVar);
        sb.append("\n            |}\n        ");
        return e2.b.s0(e2.b.t0(sb.toString()));
    }
}
