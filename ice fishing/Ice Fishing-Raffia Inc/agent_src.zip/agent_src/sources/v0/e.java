package v0;

import W1.p;
import a.AbstractC0046a;
import l1.C0267f;
import q0.AbstractC0398A;
import q0.C0413j;
import q0.EnumC0402E;
import q0.InterfaceC0403F;

/* loaded from: classes.dex */
public final class e extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public EnumC0402E f5677f;

    /* renamed from: g, reason: collision with root package name */
    public int f5678g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f5679h;
    public final /* synthetic */ AbstractC0398A i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ C0267f f5680j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(N1.d dVar, C0267f c0267f, AbstractC0398A abstractC0398A) {
        super(2, dVar);
        this.i = abstractC0398A;
        this.f5680j = c0267f;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((e) m((N1.d) obj2, (InterfaceC0403F) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        e eVar = new e(dVar, this.f5680j, this.i);
        eVar.f5679h = obj;
        return eVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0093 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x009e A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00a9  */
    @Override // P1.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object o(Object obj) throws Throwable {
        EnumC0402E enumC0402E;
        InterfaceC0403F interfaceC0403F;
        EnumC0402E enumC0402E2;
        InterfaceC0403F interfaceC0403F2;
        InterfaceC0403F interfaceC0403F3;
        Object objD;
        Object obj2;
        O1.a aVar = O1.a.f839b;
        int i = this.f5678g;
        C0267f c0267f = this.f5680j;
        AbstractC0398A abstractC0398A = this.i;
        if (i == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0403F interfaceC0403F4 = (InterfaceC0403F) this.f5679h;
            enumC0402E = EnumC0402E.f5113c;
            this.f5679h = interfaceC0403F4;
            this.f5677f = enumC0402E;
            this.f5678g = 1;
            Object objD2 = interfaceC0403F4.d(this);
            if (objD2 == aVar) {
                return aVar;
            }
            interfaceC0403F = interfaceC0403F4;
            obj = objD2;
        } else if (i == 1) {
            enumC0402E = this.f5677f;
            interfaceC0403F = (InterfaceC0403F) this.f5679h;
            AbstractC0046a.N(obj);
        } else {
            if (i != 2) {
                if (i != 3) {
                    if (i != 4) {
                        if (i != 5) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        AbstractC0046a.N(obj);
                        return obj;
                    }
                    obj2 = this.f5679h;
                    AbstractC0046a.N(obj);
                    if (!((Boolean) obj).booleanValue()) {
                        abstractC0398A.d().a();
                    }
                    return obj2;
                }
                interfaceC0403F2 = (InterfaceC0403F) this.f5679h;
                AbstractC0046a.N(obj);
                this.f5679h = obj;
                this.f5678g = 4;
                objD = interfaceC0403F2.d(this);
                if (objD != aVar) {
                    return aVar;
                }
                obj2 = obj;
                obj = objD;
                if (!((Boolean) obj).booleanValue()) {
                }
                return obj2;
            }
            enumC0402E = this.f5677f;
            interfaceC0403F3 = (InterfaceC0403F) this.f5679h;
            AbstractC0046a.N(obj);
            enumC0402E2 = enumC0402E;
            interfaceC0403F2 = interfaceC0403F3;
            d dVar = new d(null, c0267f);
            this.f5679h = interfaceC0403F2;
            this.f5677f = null;
            this.f5678g = 3;
            obj = interfaceC0403F2.c(enumC0402E2, dVar, this);
            if (obj == aVar) {
                return aVar;
            }
            this.f5679h = obj;
            this.f5678g = 4;
            objD = interfaceC0403F2.d(this);
            if (objD != aVar) {
            }
        }
        if (((Boolean) obj).booleanValue()) {
            enumC0402E2 = enumC0402E;
            interfaceC0403F2 = interfaceC0403F;
            d dVar2 = new d(null, c0267f);
            this.f5679h = interfaceC0403F2;
            this.f5677f = null;
            this.f5678g = 3;
            obj = interfaceC0403F2.c(enumC0402E2, dVar2, this);
            if (obj == aVar) {
            }
            this.f5679h = obj;
            this.f5678g = 4;
            objD = interfaceC0403F2.d(this);
            if (objD != aVar) {
            }
        } else {
            C0413j c0413jD = abstractC0398A.d();
            this.f5679h = interfaceC0403F;
            this.f5677f = enumC0402E;
            this.f5678g = 2;
            if (c0413jD.b(this) == aVar) {
                return aVar;
            }
            interfaceC0403F3 = interfaceC0403F;
            enumC0402E2 = enumC0402E;
            interfaceC0403F2 = interfaceC0403F3;
            d dVar22 = new d(null, c0267f);
            this.f5679h = interfaceC0403F2;
            this.f5677f = null;
            this.f5678g = 3;
            obj = interfaceC0403F2.c(enumC0402E2, dVar22, this);
            if (obj == aVar) {
            }
            this.f5679h = obj;
            this.f5678g = 4;
            objD = interfaceC0403F2.d(this);
            if (objD != aVar) {
            }
        }
    }
}
