package v0;

import W1.p;
import a.AbstractC0046a;
import q0.AbstractC0398A;
import q0.C0413j;
import q0.EnumC0402E;
import q0.InterfaceC0403F;
import s0.u;

/* loaded from: classes.dex */
public final class j extends P1.g implements p {

    /* renamed from: f, reason: collision with root package name */
    public EnumC0402E f5694f;

    /* renamed from: g, reason: collision with root package name */
    public int f5695g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f5696h;
    public final /* synthetic */ boolean i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ boolean f5697j;

    /* renamed from: k, reason: collision with root package name */
    public final /* synthetic */ AbstractC0398A f5698k;

    /* renamed from: l, reason: collision with root package name */
    public final /* synthetic */ W1.l f5699l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(N1.d dVar, W1.l lVar, AbstractC0398A abstractC0398A, boolean z2, boolean z3) {
        super(2, dVar);
        this.i = z2;
        this.f5697j = z3;
        this.f5698k = abstractC0398A;
        this.f5699l = lVar;
    }

    @Override // W1.p
    public final Object e(Object obj, Object obj2) {
        return ((j) m((N1.d) obj2, (InterfaceC0403F) obj)).o(J1.k.f632a);
    }

    @Override // P1.a
    public final N1.d m(N1.d dVar, Object obj) {
        j jVar = new j(dVar, this.f5699l, this.f5698k, this.i, this.f5697j);
        jVar.f5696h = obj;
        return jVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x009d A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:47:? A[RETURN, SYNTHETIC] */
    @Override // P1.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object o(Object obj) throws Throwable {
        EnumC0402E enumC0402E;
        InterfaceC0403F interfaceC0403F;
        EnumC0402E enumC0402E2;
        InterfaceC0403F interfaceC0403F2;
        InterfaceC0403F interfaceC0403F3;
        Object obj2;
        O1.a aVar = O1.a.f839b;
        int i = this.f5695g;
        W1.l lVar = this.f5699l;
        AbstractC0398A abstractC0398A = this.f5698k;
        boolean z2 = this.f5697j;
        if (i == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0403F interfaceC0403F4 = (InterfaceC0403F) this.f5696h;
            if (!this.i) {
                X1.i.c(interfaceC0403F4, "null cannot be cast to non-null type androidx.room.coroutines.RawConnectionAccessor");
                return lVar.h(((u) interfaceC0403F4).b());
            }
            enumC0402E = z2 ? EnumC0402E.f5112b : EnumC0402E.f5113c;
            if (z2) {
                EnumC0402E enumC0402E3 = enumC0402E;
                interfaceC0403F = interfaceC0403F4;
                enumC0402E2 = enumC0402E3;
                i iVar = new i(null, lVar);
                this.f5696h = interfaceC0403F;
                this.f5694f = null;
                this.f5695g = 3;
                obj = interfaceC0403F.c(enumC0402E2, iVar, this);
                if (obj == aVar) {
                }
                if (z2) {
                }
            } else {
                this.f5696h = interfaceC0403F4;
                this.f5694f = enumC0402E;
                this.f5695g = 1;
                Object objD = interfaceC0403F4.d(this);
                if (objD == aVar) {
                    return aVar;
                }
                interfaceC0403F2 = interfaceC0403F4;
                obj = objD;
            }
        } else if (i == 1) {
            enumC0402E = this.f5694f;
            interfaceC0403F2 = (InterfaceC0403F) this.f5696h;
            AbstractC0046a.N(obj);
        } else {
            if (i != 2) {
                if (i != 3) {
                    if (i != 4) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    obj2 = this.f5696h;
                    AbstractC0046a.N(obj);
                    if (!((Boolean) obj).booleanValue()) {
                        abstractC0398A.d().a();
                    }
                    return obj2;
                }
                interfaceC0403F = (InterfaceC0403F) this.f5696h;
                AbstractC0046a.N(obj);
                if (z2) {
                    return obj;
                }
                this.f5696h = obj;
                this.f5695g = 4;
                Object objD2 = interfaceC0403F.d(this);
                if (objD2 == aVar) {
                    return aVar;
                }
                obj2 = obj;
                obj = objD2;
                if (!((Boolean) obj).booleanValue()) {
                }
                return obj2;
            }
            enumC0402E = this.f5694f;
            interfaceC0403F3 = (InterfaceC0403F) this.f5696h;
            AbstractC0046a.N(obj);
            enumC0402E2 = enumC0402E;
            interfaceC0403F = interfaceC0403F3;
            i iVar2 = new i(null, lVar);
            this.f5696h = interfaceC0403F;
            this.f5694f = null;
            this.f5695g = 3;
            obj = interfaceC0403F.c(enumC0402E2, iVar2, this);
            if (obj == aVar) {
                return aVar;
            }
            if (z2) {
            }
        }
        if (((Boolean) obj).booleanValue()) {
            enumC0402E2 = enumC0402E;
            interfaceC0403F = interfaceC0403F2;
            i iVar22 = new i(null, lVar);
            this.f5696h = interfaceC0403F;
            this.f5694f = null;
            this.f5695g = 3;
            obj = interfaceC0403F.c(enumC0402E2, iVar22, this);
            if (obj == aVar) {
            }
            if (z2) {
            }
        } else {
            C0413j c0413jD = abstractC0398A.d();
            this.f5696h = interfaceC0403F2;
            this.f5694f = enumC0402E;
            this.f5695g = 2;
            if (c0413jD.b(this) == aVar) {
                return aVar;
            }
            interfaceC0403F3 = interfaceC0403F2;
            enumC0402E2 = enumC0402E;
            interfaceC0403F = interfaceC0403F3;
            i iVar222 = new i(null, lVar);
            this.f5696h = interfaceC0403F;
            this.f5694f = null;
            this.f5695g = 3;
            obj = interfaceC0403F.c(enumC0402E2, iVar222, this);
            if (obj == aVar) {
            }
            if (z2) {
            }
        }
    }
}
