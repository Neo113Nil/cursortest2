package v0;

import java.util.Locale;
import k1.AbstractC0239g;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public final String f5703a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5704b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f5705c;

    /* renamed from: d, reason: collision with root package name */
    public final int f5706d;
    public final String e;

    /* renamed from: f, reason: collision with root package name */
    public final int f5707f;

    /* renamed from: g, reason: collision with root package name */
    public final int f5708g;

    public l(String str, String str2, boolean z2, int i, String str3, int i3) {
        X1.i.e(str, "name");
        X1.i.e(str2, "type");
        this.f5703a = str;
        this.f5704b = str2;
        this.f5705c = z2;
        this.f5706d = i;
        this.e = str3;
        this.f5707f = i3;
        String upperCase = str2.toUpperCase(Locale.ROOT);
        X1.i.d(upperCase, "toUpperCase(...)");
        this.f5708g = e2.h.u0(upperCase, "INT") ? 3 : (e2.h.u0(upperCase, "CHAR") || e2.h.u0(upperCase, "CLOB") || e2.h.u0(upperCase, "TEXT")) ? 2 : e2.h.u0(upperCase, "BLOB") ? 5 : (e2.h.u0(upperCase, "REAL") || e2.h.u0(upperCase, "FLOA") || e2.h.u0(upperCase, "DOUB")) ? 4 : 1;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof l) {
            l lVar = (l) obj;
            if ((this.f5706d > 0) == (lVar.f5706d > 0) && X1.i.a(this.f5703a, lVar.f5703a) && this.f5705c == lVar.f5705c) {
                int i = lVar.f5707f;
                String str = lVar.e;
                int i3 = this.f5707f;
                String str2 = this.e;
                if ((i3 != 1 || i != 2 || str2 == null || AbstractC0239g.j(str2, str)) && ((i3 != 2 || i != 1 || str == null || AbstractC0239g.j(str, str2)) && ((i3 == 0 || i3 != i || (str2 == null ? str == null : AbstractC0239g.j(str2, str))) && this.f5708g == lVar.f5708g))) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.f5703a.hashCode() * 31) + this.f5708g) * 31) + (this.f5705c ? 1231 : 1237)) * 31) + this.f5706d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("\n            |Column {\n            |   name = '");
        sb.append(this.f5703a);
        sb.append("',\n            |   type = '");
        sb.append(this.f5704b);
        sb.append("',\n            |   affinity = '");
        sb.append(this.f5708g);
        sb.append("',\n            |   notNull = '");
        sb.append(this.f5705c);
        sb.append("',\n            |   primaryKeyPosition = '");
        sb.append(this.f5706d);
        sb.append("',\n            |   defaultValue = '");
        String str = this.e;
        if (str == null) {
            str = "undefined";
        }
        sb.append(str);
        sb.append("'\n            |}\n        ");
        return e2.b.s0(e2.b.t0(sb.toString()));
    }
}
