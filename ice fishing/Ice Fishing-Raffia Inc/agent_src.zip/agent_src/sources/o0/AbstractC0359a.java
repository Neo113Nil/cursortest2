package o0;

import android.R;

/* renamed from: o0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0359a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f4717a = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, com.kortosi.kluani.qorzanis.R.attr.fastScrollEnabled, com.kortosi.kluani.qorzanis.R.attr.fastScrollHorizontalThumbDrawable, com.kortosi.kluani.qorzanis.R.attr.fastScrollHorizontalTrackDrawable, com.kortosi.kluani.qorzanis.R.attr.fastScrollVerticalThumbDrawable, com.kortosi.kluani.qorzanis.R.attr.fastScrollVerticalTrackDrawable, com.kortosi.kluani.qorzanis.R.attr.layoutManager, com.kortosi.kluani.qorzanis.R.attr.reverseLayout, com.kortosi.kluani.qorzanis.R.attr.spanCount, com.kortosi.kluani.qorzanis.R.attr.stackFromEnd};
}
