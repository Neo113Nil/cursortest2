package Q;

import P.O;
import android.view.accessibility.AccessibilityManager;
import android.widget.AutoCompleteTextView;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class b implements AccessibilityManager.TouchExplorationStateChangeListener {

    /* renamed from: a, reason: collision with root package name */
    public final R.a f983a;

    public b(R.a aVar) {
        this.f983a = aVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof b) {
            return this.f983a.equals(((b) obj).f983a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f983a.hashCode();
    }

    @Override // android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener
    public final void onTouchExplorationStateChanged(boolean z2) {
        h1.j jVar = (h1.j) this.f983a.f1012a;
        AutoCompleteTextView autoCompleteTextView = jVar.f3417h;
        if (autoCompleteTextView == null || b1.e.L(autoCompleteTextView)) {
            return;
        }
        int i = z2 ? 2 : 1;
        WeakHashMap weakHashMap = O.f854a;
        jVar.f3456d.setImportantForAccessibility(i);
    }
}
