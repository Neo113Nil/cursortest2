package Q;

import android.view.View;

/* loaded from: classes.dex */
public interface p {
    boolean h(View view);
}
