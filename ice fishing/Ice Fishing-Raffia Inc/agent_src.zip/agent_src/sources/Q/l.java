package Q;

/* loaded from: classes.dex */
public abstract class l extends L1.d {
}
