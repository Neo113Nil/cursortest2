package Q;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* loaded from: classes.dex */
public final class h extends AccessibilityNodeProvider {

    /* renamed from: a, reason: collision with root package name */
    public final A0.f f1000a;

    public h(A0.f fVar) {
        this.f1000a = fVar;
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final void addExtraDataToAccessibilityNodeInfo(int i, AccessibilityNodeInfo accessibilityNodeInfo, String str, Bundle bundle) {
        this.f1000a.getClass();
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
        g gVarR = this.f1000a.r(i);
        if (gVarR == null) {
            return null;
        }
        return gVarR.f998a;
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final List findAccessibilityNodeInfosByText(String str, int i) {
        this.f1000a.getClass();
        return null;
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final AccessibilityNodeInfo findFocus(int i) {
        g gVarS = this.f1000a.s(i);
        if (gVarS == null) {
            return null;
        }
        return gVarS.f998a;
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final boolean performAction(int i, int i3, Bundle bundle) {
        return this.f1000a.v(i, i3, bundle);
    }
}
