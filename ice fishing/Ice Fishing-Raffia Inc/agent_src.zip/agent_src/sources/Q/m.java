package Q;

/* loaded from: classes.dex */
public abstract class m extends L1.d {
}
