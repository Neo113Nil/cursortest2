package Q;

/* loaded from: classes.dex */
public abstract class i extends L1.d {
}
