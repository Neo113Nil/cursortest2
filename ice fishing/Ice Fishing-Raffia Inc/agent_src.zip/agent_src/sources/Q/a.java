package Q;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* loaded from: classes.dex */
public final class a extends ClickableSpan {

    /* renamed from: a, reason: collision with root package name */
    public final int f980a;

    /* renamed from: b, reason: collision with root package name */
    public final g f981b;

    /* renamed from: c, reason: collision with root package name */
    public final int f982c;

    public a(int i, g gVar, int i3) {
        this.f980a = i;
        this.f981b = gVar;
        this.f982c = i3;
    }

    @Override // android.text.style.ClickableSpan
    public final void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f980a);
        this.f981b.f998a.performAction(this.f982c, bundle);
    }
}
