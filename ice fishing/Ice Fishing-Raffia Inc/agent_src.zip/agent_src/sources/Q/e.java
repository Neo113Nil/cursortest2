package Q;

import P.AbstractC0036y;
import android.R;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;

/* loaded from: classes.dex */
public final class e {
    public static final e e = new e(1);

    /* renamed from: f, reason: collision with root package name */
    public static final e f984f = new e(2);

    /* renamed from: g, reason: collision with root package name */
    public static final e f985g;

    /* renamed from: h, reason: collision with root package name */
    public static final e f986h;
    public static final e i;

    /* renamed from: j, reason: collision with root package name */
    public static final e f987j;

    /* renamed from: k, reason: collision with root package name */
    public static final e f988k;

    /* renamed from: l, reason: collision with root package name */
    public static final e f989l;

    /* renamed from: m, reason: collision with root package name */
    public static final e f990m;

    /* renamed from: n, reason: collision with root package name */
    public static final e f991n;

    /* renamed from: o, reason: collision with root package name */
    public static final e f992o;

    /* renamed from: p, reason: collision with root package name */
    public static final e f993p;

    /* renamed from: a, reason: collision with root package name */
    public final Object f994a;

    /* renamed from: b, reason: collision with root package name */
    public final int f995b;

    /* renamed from: c, reason: collision with root package name */
    public final Class f996c;

    /* renamed from: d, reason: collision with root package name */
    public final p f997d;

    static {
        new e(4);
        new e(8);
        f985g = new e(16);
        new e(32);
        new e(64);
        new e(128);
        new e(256, i.class);
        new e(512, i.class);
        new e(1024, j.class);
        new e(2048, j.class);
        f986h = new e(4096);
        i = new e(8192);
        new e(16384);
        new e(32768);
        new e(65536);
        new e(131072, n.class);
        f987j = new e(262144);
        f988k = new e(524288);
        f989l = new e(1048576);
        new e(2097152, o.class);
        int i3 = Build.VERSION.SDK_INT;
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN, R.id.accessibilityActionShowOnScreen, null, null, null);
        f990m = new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION, R.id.accessibilityActionScrollToPosition, null, null, l.class);
        f991n = new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP, R.id.accessibilityActionScrollUp, null, null, null);
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT, R.id.accessibilityActionScrollLeft, null, null, null);
        f992o = new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN, R.id.accessibilityActionScrollDown, null, null, null);
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT, R.id.accessibilityActionScrollRight, null, null, null);
        new e(i3 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_UP : null, R.id.accessibilityActionPageUp, null, null, null);
        new e(i3 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_DOWN : null, R.id.accessibilityActionPageDown, null, null, null);
        new e(i3 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_LEFT : null, R.id.accessibilityActionPageLeft, null, null, null);
        new e(i3 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_RIGHT : null, R.id.accessibilityActionPageRight, null, null, null);
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK, R.id.accessibilityActionContextClick, null, null, null);
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS, R.id.accessibilityActionSetProgress, null, null, m.class);
        new e(AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW, R.id.accessibilityActionMoveWindow, null, null, k.class);
        new e(i3 >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP : null, R.id.accessibilityActionShowTooltip, null, null, null);
        new e(i3 >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP : null, R.id.accessibilityActionHideTooltip, null, null, null);
        new e(i3 >= 30 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PRESS_AND_HOLD : null, R.id.accessibilityActionPressAndHold, null, null, null);
        new e(i3 >= 30 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER : null, R.id.accessibilityActionImeEnter, null, null, null);
        new e(i3 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_START : null, R.id.accessibilityActionDragStart, null, null, null);
        new e(i3 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_DROP : null, R.id.accessibilityActionDragDrop, null, null, null);
        new e(i3 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_CANCEL : null, R.id.accessibilityActionDragCancel, null, null, null);
        new e(i3 >= 33 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TEXT_SUGGESTIONS : null, R.id.accessibilityActionShowTextSuggestions, null, null, null);
        f993p = new e(i3 >= 34 ? AbstractC0036y.a() : null, R.id.accessibilityActionScrollInDirection, null, null, null);
    }

    public e(int i3) {
        this(null, i3, null, null, null);
    }

    public final int a() {
        return ((AccessibilityNodeInfo.AccessibilityAction) this.f994a).getId();
    }

    public final boolean equals(Object obj) {
        if (obj == null || !(obj instanceof e)) {
            return false;
        }
        Object obj2 = ((e) obj).f994a;
        Object obj3 = this.f994a;
        return obj3 == null ? obj2 == null : obj3.equals(obj2);
    }

    public final int hashCode() {
        Object obj = this.f994a;
        if (obj != null) {
            return obj.hashCode();
        }
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AccessibilityActionCompat: ");
        String strD = g.d(this.f995b);
        if (strD.equals("ACTION_UNKNOWN")) {
            Object obj = this.f994a;
            if (((AccessibilityNodeInfo.AccessibilityAction) obj).getLabel() != null) {
                strD = ((AccessibilityNodeInfo.AccessibilityAction) obj).getLabel().toString();
            }
        }
        sb.append(strD);
        return sb.toString();
    }

    public e(int i3, Class cls) {
        this(null, i3, null, null, cls);
    }

    public e(Object obj, int i3, String str, p pVar, Class cls) {
        this.f995b = i3;
        this.f997d = pVar;
        if (obj == null) {
            this.f994a = new AccessibilityNodeInfo.AccessibilityAction(i3, str);
        } else {
            this.f994a = obj;
        }
        this.f996c = cls;
    }
}
