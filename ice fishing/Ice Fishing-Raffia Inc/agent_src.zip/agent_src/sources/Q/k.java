package Q;

/* loaded from: classes.dex */
public abstract class k extends L1.d {
}
