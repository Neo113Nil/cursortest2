package L;

import android.os.LocaleList;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final LocaleList f690a;

    public c(LocaleList localeList) {
        this.f690a = localeList;
    }

    public final boolean equals(Object obj) {
        return this.f690a.equals(((c) obj).f690a);
    }

    public final int hashCode() {
        return this.f690a.hashCode();
    }

    public final String toString() {
        return this.f690a.toString();
    }
}
