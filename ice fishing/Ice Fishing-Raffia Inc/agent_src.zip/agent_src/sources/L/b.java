package L;

import android.os.LocaleList;
import java.util.Locale;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: b, reason: collision with root package name */
    public static final b f688b = new b(new c(new LocaleList(new Locale[0])));

    /* renamed from: a, reason: collision with root package name */
    public final c f689a;

    public b(c cVar) {
        this.f689a = cVar;
    }

    public static b a(String str) {
        if (str == null || str.isEmpty()) {
            return f688b;
        }
        String[] strArrSplit = str.split(",", -1);
        int length = strArrSplit.length;
        Locale[] localeArr = new Locale[length];
        for (int i = 0; i < length; i++) {
            String str2 = strArrSplit[i];
            int i3 = a.f687a;
            localeArr[i] = Locale.forLanguageTag(str2);
        }
        return new b(new c(new LocaleList(localeArr)));
    }

    public final boolean equals(Object obj) {
        if (obj instanceof b) {
            if (this.f689a.equals(((b) obj).f689a)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f689a.f690a.hashCode();
    }

    public final String toString() {
        return this.f689a.f690a.toString();
    }
}
