package L;

import java.util.Locale;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f687a = 0;

    static {
        new Locale("en", "XA");
        new Locale("ar", "XB");
    }
}
