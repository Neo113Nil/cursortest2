package Z;

import L1.g;

/* loaded from: classes.dex */
public final class b extends g {
}
