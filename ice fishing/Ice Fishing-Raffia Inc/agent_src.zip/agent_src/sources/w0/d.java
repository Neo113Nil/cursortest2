package w0;

import A.i;
import androidx.lifecycle.InterfaceC0076u;

/* loaded from: classes.dex */
public interface d extends InterfaceC0076u {
    i b();
}
