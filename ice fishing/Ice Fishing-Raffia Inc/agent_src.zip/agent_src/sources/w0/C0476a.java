package w0;

import F1.h;
import H.e;
import K1.l;
import X1.i;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.EnumC0069m;
import androidx.lifecycle.InterfaceC0064h;
import androidx.lifecycle.InterfaceC0074s;
import androidx.lifecycle.InterfaceC0076u;
import androidx.lifecycle.T;
import androidx.lifecycle.U;
import androidx.lifecycle.Y;
import androidx.lifecycle.d0;
import androidx.lifecycle.e0;
import b.k;
import b.v;
import c0.AbstractComponentCallbacksC0110w;
import c0.DialogInterfaceOnCancelListenerC0106s;
import j0.C0205j;
import j2.L;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;

/* renamed from: w0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0476a implements InterfaceC0074s {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f5741b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f5742c;

    public /* synthetic */ C0476a(int i, Object obj) {
        this.f5741b = i;
        this.f5742c = obj;
    }

    @Override // androidx.lifecycle.InterfaceC0074s
    public final void a(InterfaceC0076u interfaceC0076u, EnumC0069m enumC0069m) throws IllegalAccessException, NoSuchMethodException, InstantiationException, SecurityException, IllegalArgumentException, InvocationTargetException {
        View view;
        int iNextIndex;
        switch (this.f5741b) {
            case 0:
                if (enumC0069m != EnumC0069m.ON_CREATE) {
                    throw new AssertionError("Next event must be ON_CREATE");
                }
                interfaceC0076u.e().f(this);
                d dVar = (d) this.f5742c;
                Bundle bundleG = dVar.b().g("androidx.savedstate.Restarter");
                if (bundleG == null) {
                    return;
                }
                ArrayList<String> stringArrayList = bundleG.getStringArrayList("classes_to_restore");
                if (stringArrayList == null) {
                    throw new IllegalStateException("SavedState with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
                }
                for (String str : stringArrayList) {
                    try {
                        Class<? extends U> clsAsSubclass = Class.forName(str, false, C0476a.class.getClassLoader()).asSubclass(b.class);
                        i.b(clsAsSubclass);
                        try {
                            Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(null);
                            declaredConstructor.setAccessible(true);
                            try {
                                Object objNewInstance = declaredConstructor.newInstance(null);
                                i.b(objNewInstance);
                                if (!(dVar instanceof e0)) {
                                    throw new IllegalStateException(("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner. Received owner: " + dVar).toString());
                                }
                                d0 d0VarC = ((e0) dVar).c();
                                A.i iVarB = dVar.b();
                                d0VarC.getClass();
                                LinkedHashMap linkedHashMap = d0VarC.f1816a;
                                Iterator it = new HashSet(linkedHashMap.keySet()).iterator();
                                while (it.hasNext()) {
                                    String str2 = (String) it.next();
                                    i.e(str2, "key");
                                    Y y2 = (Y) linkedHashMap.get(str2);
                                    if (y2 != null) {
                                        T.a(y2, iVarB, dVar.e());
                                    }
                                }
                                if (!new HashSet(linkedHashMap.keySet()).isEmpty()) {
                                    iVarB.R();
                                }
                            } catch (Exception e) {
                                throw new RuntimeException("Failed to instantiate " + str, e);
                            }
                        } catch (NoSuchMethodException e3) {
                            throw new IllegalStateException("Class " + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e3);
                        }
                    } catch (ClassNotFoundException e4) {
                        throw new RuntimeException(e.i("Class ", str, " wasn't found"), e4);
                    }
                }
                return;
            case 1:
                if (enumC0069m == EnumC0069m.ON_DESTROY) {
                    h hVar = (h) this.f5742c;
                    hVar.getClass();
                    hVar.f489a = null;
                    hVar.f490b = null;
                    return;
                }
                return;
            case 2:
                new HashMap();
                InterfaceC0064h[] interfaceC0064hArr = (InterfaceC0064h[]) this.f5742c;
                if (interfaceC0064hArr.length > 0) {
                    InterfaceC0064h interfaceC0064h = interfaceC0064hArr[0];
                    throw null;
                }
                if (interfaceC0064hArr.length <= 0) {
                    return;
                }
                InterfaceC0064h interfaceC0064h2 = interfaceC0064hArr[0];
                throw null;
            case 3:
                if (enumC0069m != EnumC0069m.ON_CREATE) {
                    throw new IllegalStateException(("Next event must be ON_CREATE, it was " + enumC0069m).toString());
                }
                interfaceC0076u.e().f(this);
                ((U) this.f5742c).b();
                return;
            case 4:
                if (enumC0069m != EnumC0069m.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                    return;
                }
                v vVar = ((k) this.f5742c).i;
                OnBackInvokedDispatcher onBackInvokedDispatcherA = b.h.a((k) interfaceC0076u);
                vVar.getClass();
                i.e(onBackInvokedDispatcherA, "invoker");
                vVar.e = onBackInvokedDispatcherA;
                vVar.b(vVar.f2043g);
                return;
            case 5:
                if (enumC0069m != EnumC0069m.ON_STOP || (view = ((AbstractComponentCallbacksC0110w) this.f5742c).f2295I) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
                return;
            default:
                int i = l0.c.f4028a[enumC0069m.ordinal()];
                l0.d dVar2 = (l0.d) this.f5742c;
                if (i == 1) {
                    DialogInterfaceOnCancelListenerC0106s dialogInterfaceOnCancelListenerC0106s = (DialogInterfaceOnCancelListenerC0106s) interfaceC0076u;
                    Iterable iterable = (Iterable) ((L) dVar2.b().e.f3856b).j();
                    if (!(iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                        Iterator it2 = iterable.iterator();
                        while (it2.hasNext()) {
                            if (i.a(((C0205j) it2.next()).f3707g, dialogInterfaceOnCancelListenerC0106s.f2289B)) {
                                return;
                            }
                        }
                    }
                    dialogInterfaceOnCancelListenerC0106s.P(false, false);
                    return;
                }
                Object obj = null;
                if (i == 2) {
                    DialogInterfaceOnCancelListenerC0106s dialogInterfaceOnCancelListenerC0106s2 = (DialogInterfaceOnCancelListenerC0106s) interfaceC0076u;
                    for (Object obj2 : (Iterable) ((L) dVar2.b().f3722f.f3856b).j()) {
                        if (i.a(((C0205j) obj2).f3707g, dialogInterfaceOnCancelListenerC0106s2.f2289B)) {
                            obj = obj2;
                        }
                    }
                    C0205j c0205j = (C0205j) obj;
                    if (c0205j != null) {
                        dVar2.b().b(c0205j);
                        return;
                    }
                    return;
                }
                if (i != 3) {
                    if (i != 4) {
                        return;
                    }
                    DialogInterfaceOnCancelListenerC0106s dialogInterfaceOnCancelListenerC0106s3 = (DialogInterfaceOnCancelListenerC0106s) interfaceC0076u;
                    for (Object obj3 : (Iterable) ((L) dVar2.b().f3722f.f3856b).j()) {
                        if (i.a(((C0205j) obj3).f3707g, dialogInterfaceOnCancelListenerC0106s3.f2289B)) {
                            obj = obj3;
                        }
                    }
                    C0205j c0205j2 = (C0205j) obj;
                    if (c0205j2 != null) {
                        dVar2.b().b(c0205j2);
                    }
                    dialogInterfaceOnCancelListenerC0106s3.f2302Q.f(this);
                    return;
                }
                DialogInterfaceOnCancelListenerC0106s dialogInterfaceOnCancelListenerC0106s4 = (DialogInterfaceOnCancelListenerC0106s) interfaceC0076u;
                if (dialogInterfaceOnCancelListenerC0106s4.R().isShowing()) {
                    return;
                }
                List list = (List) ((L) dVar2.b().e.f3856b).j();
                ListIterator listIterator = list.listIterator(list.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        iNextIndex = -1;
                    } else if (i.a(((C0205j) listIterator.previous()).f3707g, dialogInterfaceOnCancelListenerC0106s4.f2289B)) {
                        iNextIndex = listIterator.nextIndex();
                    }
                }
                C0205j c0205j3 = (C0205j) l.Y(list, iNextIndex);
                if (!i.a(l.d0(list), c0205j3)) {
                    Log.i("DialogFragmentNavigator", "Dialog " + dialogInterfaceOnCancelListenerC0106s4 + " was dismissed while it was not the top of the back stack, popping all dialogs above this dismissed dialog");
                }
                if (c0205j3 != null) {
                    dVar2.l(iNextIndex, c0205j3, false);
                    return;
                }
                return;
        }
    }
}
