package t0;

import W1.p;
import java.io.IOException;
import n.C0326o;
import s0.InterfaceC0442b;
import z0.InterfaceC0539b;

/* loaded from: classes.dex */
public final class b implements InterfaceC0442b {

    /* renamed from: b, reason: collision with root package name */
    public final C0326o f5518b;

    public b(C0326o c0326o) {
        this.f5518b = c0326o;
    }

    @Override // java.lang.AutoCloseable
    public final void close() throws IOException {
        ((InterfaceC0539b) this.f5518b.f4570c).close();
    }

    @Override // s0.InterfaceC0442b
    public final Object e(boolean z2, p pVar, P1.c cVar) {
        InterfaceC0539b interfaceC0539b = (InterfaceC0539b) this.f5518b.f4570c;
        interfaceC0539b.getClass();
        return pVar.e(new d(new a(interfaceC0539b.w())), cVar);
    }
}
