package t0;

import k1.AbstractC0239g;
import y0.InterfaceC0533c;
import z0.InterfaceC0538a;

/* loaded from: classes.dex */
public abstract class g implements InterfaceC0533c {

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0538a f5527b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5528c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f5529d;

    public g(InterfaceC0538a interfaceC0538a, String str) {
        this.f5527b = interfaceC0538a;
        this.f5528c = str;
    }

    public final void a() {
        if (this.f5529d) {
            AbstractC0239g.E("statement is closed", 21);
            throw null;
        }
    }
}
