package t0;

import X1.i;
import android.database.Cursor;
import java.util.Arrays;
import k1.AbstractC0239g;
import n.C0326o;

/* loaded from: classes.dex */
public final class e extends g {
    public int[] e;

    /* renamed from: f, reason: collision with root package name */
    public long[] f5523f;

    /* renamed from: g, reason: collision with root package name */
    public double[] f5524g;

    /* renamed from: h, reason: collision with root package name */
    public String[] f5525h;
    public byte[][] i;

    /* renamed from: j, reason: collision with root package name */
    public Cursor f5526j;

    public static void x(Cursor cursor, int i) {
        if (i < 0 || i >= cursor.getColumnCount()) {
            AbstractC0239g.E("column index out of range", 25);
            throw null;
        }
    }

    @Override // y0.InterfaceC0533c
    public final void F() {
        a();
        Cursor cursor = this.f5526j;
        if (cursor != null) {
            cursor.close();
        }
        this.f5526j = null;
    }

    public final void b(int i, int i3) {
        int i4 = i3 + 1;
        int[] iArr = this.e;
        if (iArr.length < i4) {
            int[] iArrCopyOf = Arrays.copyOf(iArr, i4);
            i.d(iArrCopyOf, "copyOf(...)");
            this.e = iArrCopyOf;
        }
        if (i == 1) {
            long[] jArr = this.f5523f;
            if (jArr.length < i4) {
                long[] jArrCopyOf = Arrays.copyOf(jArr, i4);
                i.d(jArrCopyOf, "copyOf(...)");
                this.f5523f = jArrCopyOf;
                return;
            }
            return;
        }
        if (i == 2) {
            double[] dArr = this.f5524g;
            if (dArr.length < i4) {
                double[] dArrCopyOf = Arrays.copyOf(dArr, i4);
                i.d(dArrCopyOf, "copyOf(...)");
                this.f5524g = dArrCopyOf;
                return;
            }
            return;
        }
        if (i == 3) {
            String[] strArr = this.f5525h;
            if (strArr.length < i4) {
                Object[] objArrCopyOf = Arrays.copyOf(strArr, i4);
                i.d(objArrCopyOf, "copyOf(...)");
                this.f5525h = (String[]) objArrCopyOf;
                return;
            }
            return;
        }
        if (i != 4) {
            return;
        }
        byte[][] bArr = this.i;
        if (bArr.length < i4) {
            Object[] objArrCopyOf2 = Arrays.copyOf(bArr, i4);
            i.d(objArrCopyOf2, "copyOf(...)");
            this.i = (byte[][]) objArrCopyOf2;
        }
    }

    @Override // y0.InterfaceC0533c
    public final void c(int i, long j3) {
        a();
        b(1, i);
        this.e[i] = 1;
        this.f5523f[i] = j3;
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        if (!this.f5529d) {
            a();
            this.e = new int[0];
            this.f5523f = new long[0];
            this.f5524g = new double[0];
            this.f5525h = new String[0];
            this.i = new byte[0][];
            F();
        }
        this.f5529d = true;
    }

    public final void h() {
        if (this.f5526j == null) {
            this.f5526j = this.f5527b.v(new C0326o(10, this));
        }
    }

    @Override // y0.InterfaceC0533c
    public final boolean i(int i) {
        a();
        Cursor cursor = this.f5526j;
        if (cursor != null) {
            x(cursor, i);
            return cursor.isNull(i);
        }
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final String j(int i) {
        a();
        h();
        Cursor cursor = this.f5526j;
        if (cursor == null) {
            throw new IllegalStateException("Required value was null.");
        }
        x(cursor, i);
        String columnName = cursor.getColumnName(i);
        i.d(columnName, "getColumnName(...)");
        return columnName;
    }

    @Override // y0.InterfaceC0533c
    public final void p(String str, int i) {
        i.e(str, "value");
        a();
        b(3, i);
        this.e[i] = 3;
        this.f5525h[i] = str;
    }

    @Override // y0.InterfaceC0533c
    public final String q(int i) {
        a();
        Cursor cursor = this.f5526j;
        if (cursor == null) {
            AbstractC0239g.E("no row", 21);
            throw null;
        }
        x(cursor, i);
        String string = cursor.getString(i);
        i.d(string, "getString(...)");
        return string;
    }

    @Override // y0.InterfaceC0533c
    public final int r() {
        a();
        h();
        Cursor cursor = this.f5526j;
        if (cursor != null) {
            return cursor.getColumnCount();
        }
        return 0;
    }

    @Override // y0.InterfaceC0533c
    public final long s(int i) {
        a();
        Cursor cursor = this.f5526j;
        if (cursor != null) {
            x(cursor, i);
            return cursor.getLong(i);
        }
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final boolean t() {
        a();
        h();
        Cursor cursor = this.f5526j;
        if (cursor != null) {
            return cursor.moveToNext();
        }
        throw new IllegalStateException("Required value was null.");
    }
}
