package t0;

import A0.m;
import X1.i;
import java.io.IOException;
import k1.AbstractC0239g;
import z0.InterfaceC0538a;

/* loaded from: classes.dex */
public final class f extends g {
    public final m e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(InterfaceC0538a interfaceC0538a, String str) {
        super(interfaceC0538a, str);
        i.e(interfaceC0538a, "db");
        i.e(str, "sql");
        this.e = interfaceC0538a.G(str);
    }

    @Override // y0.InterfaceC0533c
    public final void F() {
    }

    @Override // y0.InterfaceC0533c
    public final void c(int i, long j3) {
        a();
        this.e.c(i, j3);
    }

    @Override // java.lang.AutoCloseable
    public final void close() throws IOException {
        this.e.close();
        this.f5529d = true;
    }

    @Override // y0.InterfaceC0533c
    public final boolean i(int i) {
        a();
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final String j(int i) {
        a();
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final void p(String str, int i) {
        i.e(str, "value");
        a();
        this.e.m(str, i);
    }

    @Override // y0.InterfaceC0533c
    public final String q(int i) {
        a();
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final int r() {
        a();
        return 0;
    }

    @Override // y0.InterfaceC0533c
    public final long s(int i) {
        a();
        AbstractC0239g.E("no row", 21);
        throw null;
    }

    @Override // y0.InterfaceC0533c
    public final boolean t() {
        a();
        this.e.f245c.execute();
        return false;
    }
}
