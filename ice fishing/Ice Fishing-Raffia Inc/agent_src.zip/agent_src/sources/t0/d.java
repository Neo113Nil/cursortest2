package t0;

import W1.l;
import W1.p;
import a.AbstractC0046a;
import q0.EnumC0402E;
import q0.InterfaceC0403F;
import s0.n;
import s0.u;
import y0.InterfaceC0531a;
import z0.InterfaceC0538a;

/* loaded from: classes.dex */
public final class d implements InterfaceC0403F, u {

    /* renamed from: a, reason: collision with root package name */
    public final a f5522a;

    public d(a aVar) {
        this.f5522a = aVar;
    }

    @Override // q0.v
    public final Object a(String str, l lVar, P1.c cVar) throws Exception {
        g gVarA = this.f5522a.A(str);
        try {
            Object objH = lVar.h(gVarA);
            L1.d.n(gVarA, null);
            return objH;
        } finally {
        }
    }

    @Override // s0.u
    public final InterfaceC0531a b() {
        return this.f5522a;
    }

    @Override // q0.InterfaceC0403F
    public final Object c(EnumC0402E enumC0402E, p pVar, P1.g gVar) {
        return e(enumC0402E, pVar, gVar);
    }

    @Override // q0.InterfaceC0403F
    public final Object d(P1.g gVar) {
        return Boolean.valueOf(this.f5522a.f5517b.z());
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0090  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object e(EnumC0402E enumC0402E, p pVar, P1.c cVar) throws Throwable {
        c cVar2;
        d dVar;
        Throwable th;
        InterfaceC0538a interfaceC0538a;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i = cVar2.i;
            if ((i & Integer.MIN_VALUE) != 0) {
                cVar2.i = i - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(this, cVar);
            }
        }
        Object obj = cVar2.f5520g;
        Object obj2 = O1.a.f839b;
        int i3 = cVar2.i;
        if (i3 == 0) {
            AbstractC0046a.N(obj);
            InterfaceC0538a interfaceC0538a2 = this.f5522a.f5517b;
            interfaceC0538a2.z();
            int iOrdinal = enumC0402E.ordinal();
            if (iOrdinal == 0) {
                interfaceC0538a2.u();
            } else if (iOrdinal == 1) {
                interfaceC0538a2.d();
            } else {
                if (iOrdinal != 2) {
                    throw new C0.c();
                }
                interfaceC0538a2.g();
            }
            try {
                Object nVar = new n(1, this);
                cVar2.e = this;
                cVar2.f5519f = interfaceC0538a2;
                cVar2.i = 1;
                Object objE = pVar.e(nVar, cVar2);
                if (objE == obj2) {
                    return obj2;
                }
                dVar = this;
                obj = objE;
                interfaceC0538a = interfaceC0538a2;
            } catch (Throwable th2) {
                dVar = this;
                th = th2;
                interfaceC0538a = interfaceC0538a2;
                interfaceC0538a.f();
                if (!interfaceC0538a.z()) {
                    dVar.getClass();
                }
                throw th;
            }
        } else {
            if (i3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            interfaceC0538a = cVar2.f5519f;
            dVar = cVar2.e;
            try {
                AbstractC0046a.N(obj);
            } catch (Throwable th3) {
                th = th3;
                interfaceC0538a.f();
                if (!interfaceC0538a.z()) {
                }
                throw th;
            }
        }
        interfaceC0538a.y();
        interfaceC0538a.f();
        if (!interfaceC0538a.z()) {
            dVar.getClass();
        }
        return obj;
    }
}
