package t0;

import X1.i;
import e2.h;
import java.io.IOException;
import java.util.Locale;
import y0.InterfaceC0531a;
import z0.InterfaceC0538a;

/* loaded from: classes.dex */
public final class a implements InterfaceC0531a {

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0538a f5517b;

    public a(InterfaceC0538a interfaceC0538a) {
        i.e(interfaceC0538a, "db");
        this.f5517b = interfaceC0538a;
    }

    @Override // y0.InterfaceC0531a
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final g A(String str) {
        i.e(str, "sql");
        InterfaceC0538a interfaceC0538a = this.f5517b;
        i.e(interfaceC0538a, "db");
        String string = h.E0(str).toString();
        if (string.length() >= 3) {
            String strSubstring = string.substring(0, 3);
            i.d(strSubstring, "substring(...)");
            String upperCase = strSubstring.toUpperCase(Locale.ROOT);
            i.d(upperCase, "toUpperCase(...)");
            int iHashCode = upperCase.hashCode();
            if (iHashCode == 79487 ? upperCase.equals("PRA") : !(iHashCode == 81978 ? !upperCase.equals("SEL") : !(iHashCode == 85954 && upperCase.equals("WIT")))) {
                e eVar = new e(interfaceC0538a, str);
                eVar.e = new int[0];
                eVar.f5523f = new long[0];
                eVar.f5524g = new double[0];
                eVar.f5525h = new String[0];
                eVar.i = new byte[0][];
                return eVar;
            }
        }
        return new f(interfaceC0538a, str);
    }

    @Override // java.lang.AutoCloseable
    public final void close() throws IOException {
        this.f5517b.close();
    }
}
