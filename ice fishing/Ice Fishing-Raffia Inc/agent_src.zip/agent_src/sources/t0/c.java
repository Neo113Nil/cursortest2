package t0;

import z0.InterfaceC0538a;

/* loaded from: classes.dex */
public final class c extends P1.c {
    public d e;

    /* renamed from: f, reason: collision with root package name */
    public InterfaceC0538a f5519f;

    /* renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f5520g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ d f5521h;
    public int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(d dVar, P1.c cVar) {
        super(cVar);
        this.f5521h = dVar;
    }

    @Override // P1.a
    public final Object o(Object obj) {
        this.f5520g = obj;
        this.i |= Integer.MIN_VALUE;
        return this.f5521h.e(null, null, this);
    }
}
