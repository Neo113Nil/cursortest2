package io.flutter.plugins;

import android.util.Log;
import d0.C0137c;
import r0.J;

/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(C0137c c0137c) {
        try {
            c0137c.f1762d.a(new J());
        } catch (Exception e2) {
            Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e2);
        }
    }
}
