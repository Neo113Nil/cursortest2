package com.glass.and.silicon;

import c0.AbstractActivityC0116f;

/* loaded from: classes.dex */
public final class MainActivity extends AbstractActivityC0116f {
}
