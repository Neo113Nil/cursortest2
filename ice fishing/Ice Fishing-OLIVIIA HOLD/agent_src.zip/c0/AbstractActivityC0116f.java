package c0;

import L.C0051b;
import L.Q;
import a.AbstractC0068a;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.Window;
import android.view.accessibility.AccessibilityManager;
import android.view.textservice.TextServicesManager;
import android.window.OnBackInvokedCallback;
import d0.C0137c;
import d0.C0139e;
import d0.C0141g;
import d0.C0142h;
import d0.C0143i;
import e0.C0149a;
import h0.C0204e;
import io.flutter.embedding.engine.FlutterJNI;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import l0.C0218a;
import l0.C0219b;
import l0.C0220c;
import l0.C0228k;
import l0.C0229l;
import q0.C0263a;

/* renamed from: c0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0116f extends Activity implements InterfaceC0119i, androidx.lifecycle.i {

    /* renamed from: i, reason: collision with root package name */
    public static final int f1665i = View.generateViewId();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1666e = false;

    /* renamed from: f, reason: collision with root package name */
    public C0120j f1667f;

    /* renamed from: g, reason: collision with root package name */
    public final androidx.lifecycle.j f1668g;

    /* renamed from: h, reason: collision with root package name */
    public final OnBackInvokedCallback f1669h;

    public AbstractActivityC0116f() {
        int i2 = Build.VERSION.SDK_INT;
        this.f1669h = i2 < 33 ? null : i2 >= 34 ? new C0115e(this) : new OnBackInvokedCallback() { // from class: c0.d
            public final void onBackInvoked() {
                this.f1663a.onBackPressed();
            }
        };
        this.f1668g = new androidx.lifecycle.j(this);
    }

    @Override // androidx.lifecycle.i
    public final androidx.lifecycle.j a() {
        return this.f1668g;
    }

    public final String b() {
        String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int c() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final String d() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final String e() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle bundleG = g();
            String string = bundleG != null ? bundleG.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final String f() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle bundleG = g();
            if (bundleG != null) {
                return bundleG.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final Bundle g() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void h(boolean z2) {
        if (z2 && !this.f1666e) {
            if (Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f1669h);
                this.f1666e = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1666e || Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1669h);
        this.f1666e = false;
    }

    public final boolean i() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (d() != null || this.f1667f.f1680g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean j() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : d() == null;
    }

    public final boolean k(String str) {
        C0120j c0120j = this.f1667f;
        if (c0120j == null) {
            Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0120j.f1683j) {
            return true;
        }
        Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        if (k("onActivityResult")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            if (c0120j.f1675b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Objects.toString(intent);
            C0139e c0139e = c0120j.f1675b.f1762d;
            if (!c0139e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            s0.a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                c0139e.f1793f.d(i2, i3, intent);
                Trace.endSection();
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (k("onBackPressed")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                c0137c.f1767i.f2654a.B("popRoute", null, null);
            } else {
                Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:188:0x0442  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x04e9  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x04f4  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x054a A[LOOP:0: B:202:0x0544->B:204:0x054a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0560  */
    /* JADX WARN: Removed duplicated region for block: B:215:0x057a  */
    /* JADX WARN: Removed duplicated region for block: B:249:0x062b  */
    /* JADX WARN: Type inference failed for: r10v1, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        byte[] byteArray;
        SparseArray sparseArray;
        SparseArray sparseArray2;
        SparseArray sparseArray3;
        int i2;
        int i3;
        int i4;
        try {
            Bundle bundleG = g();
            if (bundleG != null && (i4 = bundleG.getInt("io.flutter.embedding.android.NormalTheme", -1)) != -1) {
                setTheme(i4);
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.e("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
        super.onCreate(bundle);
        if (bundle != null) {
            h(bundle.getBoolean("enableOnBackInvokedCallbackState"));
        }
        C0120j c0120j = new C0120j(this);
        this.f1667f = c0120j;
        c0120j.c();
        if (c0120j.f1675b == null) {
            String strD = c0120j.f1674a.d();
            if (strD != null) {
                if (C0143i.f1805c == null) {
                    C0143i.f1805c = new C0143i(1);
                }
                C0137c c0137c = (C0137c) C0143i.f1805c.f1806a.get(strD);
                c0120j.f1675b = c0137c;
                c0120j.f1680g = true;
                if (c0137c == null) {
                    throw new IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + strD + "'");
                }
            } else {
                c0120j.f1674a.getClass();
                c0120j.f1675b = null;
                String stringExtra = c0120j.f1674a.getIntent().getStringExtra("cached_engine_group_id");
                if (stringExtra != null) {
                    if (C0143i.f1804b == null) {
                        synchronized (C0143i.class) {
                            try {
                                if (C0143i.f1804b == null) {
                                    C0143i.f1804b = new C0143i(0);
                                }
                            } finally {
                            }
                        }
                    }
                    C0142h c0142h = (C0142h) C0143i.f1804b.f1806a.get(stringExtra);
                    if (c0142h == null) {
                        throw new IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + stringExtra + "'");
                    }
                    AbstractActivityC0116f abstractActivityC0116f = c0120j.f1674a;
                    abstractActivityC0116f.getClass();
                    C0141g c0141g = new C0141g(abstractActivityC0116f);
                    c0120j.a(c0141g);
                    c0120j.f1675b = c0142h.a(c0141g);
                    c0120j.f1680g = false;
                } else {
                    AbstractActivityC0116f abstractActivityC0116f2 = c0120j.f1674a;
                    abstractActivityC0116f2.getClass();
                    Intent intent = c0120j.f1674a.getIntent();
                    ArrayList arrayList = new ArrayList();
                    if (intent.getBooleanExtra("trace-startup", false)) {
                        arrayList.add("--trace-startup");
                    }
                    if (intent.getBooleanExtra("start-paused", false)) {
                        arrayList.add("--start-paused");
                    }
                    int intExtra = intent.getIntExtra("vm-service-port", 0);
                    if (intExtra > 0) {
                        arrayList.add("--vm-service-port=" + Integer.toString(intExtra));
                    }
                    if (intent.getBooleanExtra("disable-service-auth-codes", false)) {
                        arrayList.add("--disable-service-auth-codes");
                    }
                    if (intent.getBooleanExtra("endless-trace-buffer", false)) {
                        arrayList.add("--endless-trace-buffer");
                    }
                    if (intent.getBooleanExtra("use-test-fonts", false)) {
                        arrayList.add("--use-test-fonts");
                    }
                    if (intent.getBooleanExtra("enable-dart-profiling", false)) {
                        arrayList.add("--enable-dart-profiling");
                    }
                    if (intent.getBooleanExtra("profile-startup", false)) {
                        arrayList.add("--profile-startup");
                    }
                    if (intent.getBooleanExtra("enable-software-rendering", false)) {
                        arrayList.add("--enable-software-rendering");
                    }
                    if (intent.getBooleanExtra("skia-deterministic-rendering", false)) {
                        arrayList.add("--skia-deterministic-rendering");
                    }
                    if (intent.getBooleanExtra("trace-skia", false)) {
                        arrayList.add("--trace-skia");
                    }
                    String stringExtra2 = intent.getStringExtra("trace-skia-allowlist");
                    if (stringExtra2 != null) {
                        arrayList.add("--trace-skia-allowlist=".concat(stringExtra2));
                    }
                    if (intent.getBooleanExtra("trace-systrace", false)) {
                        arrayList.add("--trace-systrace");
                    }
                    if (intent.hasExtra("trace-to-file")) {
                        arrayList.add("--trace-to-file=" + intent.getStringExtra("trace-to-file"));
                    }
                    if (intent.hasExtra("profile-microtasks")) {
                        arrayList.add("--profile-microtasks");
                    }
                    if (intent.hasExtra("enable-impeller")) {
                        if (intent.getBooleanExtra("enable-impeller", false)) {
                            arrayList.add("--enable-impeller=true");
                        } else {
                            arrayList.add("--enable-impeller=false");
                        }
                    }
                    if (intent.getBooleanExtra("enable-vulkan-validation", false)) {
                        arrayList.add("--enable-vulkan-validation");
                    }
                    if (intent.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
                        arrayList.add("--dump-skp-on-shader-compilation");
                    }
                    if (intent.getBooleanExtra("cache-sksl", false)) {
                        arrayList.add("--cache-sksl");
                    }
                    if (intent.getBooleanExtra("purge-persistent-cache", false)) {
                        arrayList.add("--purge-persistent-cache");
                    }
                    if (intent.getBooleanExtra("verbose-logging", false)) {
                        arrayList.add("--verbose-logging");
                    }
                    if (intent.hasExtra("dart-flags")) {
                        arrayList.add("--dart-flags=" + intent.getStringExtra("dart-flags"));
                    }
                    HashSet hashSet = new HashSet(arrayList);
                    C0142h c0142h2 = new C0142h(abstractActivityC0116f2, (String[]) hashSet.toArray(new String[hashSet.size()]));
                    AbstractActivityC0116f abstractActivityC0116f3 = c0120j.f1674a;
                    abstractActivityC0116f3.getClass();
                    C0141g c0141g2 = new C0141g(abstractActivityC0116f3);
                    c0141g2.f1801e = false;
                    c0141g2.f1802f = c0120j.f1674a.j();
                    c0120j.a(c0141g2);
                    c0120j.f1675b = c0142h2.a(c0141g2);
                    c0120j.f1680g = false;
                }
            }
        }
        c0120j.f1674a.getClass();
        C0139e c0139e = c0120j.f1675b.f1762d;
        androidx.lifecycle.j jVar = c0120j.f1674a.f1668g;
        c0139e.getClass();
        s0.a.b("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            C0120j c0120j2 = c0139e.f1792e;
            if (c0120j2 != null) {
                c0120j2.b();
            }
            c0139e.e();
            c0139e.f1792e = c0120j;
            AbstractActivityC0116f abstractActivityC0116f4 = c0120j.f1674a;
            abstractActivityC0116f4.getClass();
            c0139e.b(abstractActivityC0116f4, jVar);
            Trace.endSection();
            AbstractActivityC0116f abstractActivityC0116f5 = c0120j.f1674a;
            abstractActivityC0116f5.getClass();
            AbstractActivityC0116f abstractActivityC0116f6 = c0120j.f1674a;
            C0137c c0137c2 = c0120j.f1675b;
            abstractActivityC0116f6.getClass();
            c0120j.f1677d = new io.flutter.plugin.platform.e(abstractActivityC0116f6, c0137c2.f1770l, abstractActivityC0116f6);
            AbstractActivityC0116f abstractActivityC0116f7 = c0120j.f1674a;
            C0137c c0137c3 = c0120j.f1675b;
            abstractActivityC0116f7.getClass();
            int i5 = f1665i;
            c0120j.f1678e = new C0263a(i5, abstractActivityC0116f5, c0137c3.f1772n);
            AbstractActivityC0116f abstractActivityC0116f8 = c0120j.f1674a;
            C0137c c0137c4 = c0120j.f1675b;
            if (!abstractActivityC0116f8.f1667f.f1680g) {
                AbstractC0068a.D(c0137c4);
            }
            c0120j.f1683j = true;
            C0120j c0120j3 = this.f1667f;
            c0120j3.c();
            if (bundle != null) {
                bundle.getBundle("plugins");
                byteArray = bundle.getByteArray("framework");
            } else {
                byteArray = null;
            }
            if (c0120j3.f1674a.j()) {
                C0229l c0229l = c0120j3.f1675b.f1769k;
                c0229l.f2701e = true;
                C0228k c0228k = c0229l.f2700d;
                if (c0228k != null) {
                    c0228k.d(C0229l.a(byteArray));
                    c0229l.f2700d = null;
                    c0229l.f2698b = byteArray;
                } else if (c0229l.f2702f) {
                    c0229l.f2699c.B("push", C0229l.a(byteArray), new C0228k(0, c0229l, byteArray));
                } else {
                    c0229l.f2698b = byteArray;
                }
            }
            c0120j3.f1674a.getClass();
            C0139e c0139e2 = c0120j3.f1675b.f1762d;
            if (c0139e2.f()) {
                s0.a.b("FlutterEngineConnectionRegistry#onRestoreInstanceState");
                try {
                    Iterator it = ((HashSet) c0139e2.f1793f.f1787f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } finally {
                    try {
                        Trace.endSection();
                        throw th;
                    } catch (Throwable th) {
                        th.addSuppressed(th);
                    }
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
            }
            this.f1668g.a(androidx.lifecycle.d.ON_CREATE);
            if (c() == 2) {
                getWindow().setBackgroundDrawable(new ColorDrawable(0));
            }
            C0120j c0120j4 = this.f1667f;
            boolean z2 = (c() == 1 ? (char) 1 : (char) 2) == 1;
            c0120j4.c();
            if (c0120j4.f1674a.c() == 1) {
                AbstractActivityC0116f abstractActivityC0116f9 = c0120j4.f1674a;
                abstractActivityC0116f9.getClass();
                C0123m c0123m = new C0123m(abstractActivityC0116f9, c0120j4.f1674a.c() != 1);
                c0120j4.f1674a.getClass();
                AbstractActivityC0116f abstractActivityC0116f10 = c0120j4.f1674a;
                abstractActivityC0116f10.getClass();
                c0120j4.f1676c = new C0129s(abstractActivityC0116f10, c0123m);
            } else {
                AbstractActivityC0116f abstractActivityC0116f11 = c0120j4.f1674a;
                abstractActivityC0116f11.getClass();
                C0125o c0125o = new C0125o(abstractActivityC0116f11);
                c0125o.setOpaque(c0120j4.f1674a.c() == 1);
                c0120j4.f1674a.getClass();
                AbstractActivityC0116f abstractActivityC0116f12 = c0120j4.f1674a;
                abstractActivityC0116f12.getClass();
                c0120j4.f1676c = new C0129s(abstractActivityC0116f12, c0125o);
            }
            c0120j4.f1676c.f1723l.add(c0120j4.f1685l);
            c0120j4.f1674a.getClass();
            C0129s c0129s = c0120j4.f1676c;
            C0137c c0137c5 = c0120j4.f1675b;
            C0117g c0117g = c0129s.f1711C;
            Objects.toString(c0137c5);
            if (!c0129s.c()) {
                c0129s.f1725n = c0137c5;
                io.flutter.embedding.engine.renderer.h hVar = c0137c5.f1760b;
                c0129s.f1724m = hVar.f2347c;
                c0129s.f1721j.c(hVar);
                hVar.a(c0117g);
                if (c0129s.f1717f) {
                    hVar.f2345a.addResizingFlutterUiListener(c0129s.f1710B);
                }
                c0129s.f1727p = new Q(c0129s, c0129s.f1725n.f1766h);
                C0137c c0137c6 = c0129s.f1725n;
                c0129s.f1728q = new io.flutter.plugin.editing.l(c0129s, c0137c6.r, c0137c6.f1771m, c0137c6.f1776s, c0137c6.f1777t);
                try {
                    TextServicesManager textServicesManager = (TextServicesManager) c0129s.getContext().getSystemService("textservices");
                    c0129s.f1733w = textServicesManager;
                    c0129s.r = new io.flutter.plugin.editing.h(textServicesManager, c0129s.f1725n.f1774p);
                } catch (Exception unused2) {
                    Log.e("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
                }
                new Q(c0129s, c0129s.f1728q.f2397b, c0129s.f1725n.f1771m);
                c0129s.f1729s = c0129s.f1725n.f1763e;
                c0129s.f1730t = new C0051b(c0129s);
                c0129s.f1731u = new C0112b(c0129s.f1725n.f1760b, false);
                io.flutter.view.i iVar = new io.flutter.view.i(c0129s, c0137c5.f1764f, (AccessibilityManager) c0129s.getContext().getSystemService("accessibility"), c0129s.getContext().getContentResolver(), c0137c5.f1778u);
                c0129s.f1732v = iVar;
                iVar.r = c0129s.f1736z;
                boolean zIsEnabled = iVar.f2555c.isEnabled();
                boolean zIsTouchExplorationEnabled = c0129s.f1732v.f2555c.isTouchExplorationEnabled();
                if (c0129s.f1725n.f1760b.f2345a.getIsSoftwareRenderingEnabled()) {
                    c0129s.setWillNotDraw((zIsEnabled || zIsTouchExplorationEnabled) ? false : true);
                } else {
                    c0129s.setWillNotDraw(false);
                }
                C0137c c0137c7 = c0129s.f1725n;
                c0137c7.f1776s.f2443l.f2412a = c0129s.f1732v;
                new C0112b(c0137c7.f1760b, true);
                C0137c c0137c8 = c0129s.f1725n;
                c0137c8.f1777t.f2428j.f2412a = c0129s.f1732v;
                new C0112b(c0137c8.f1760b, true);
                c0129s.f1728q.f2397b.restartInput(c0129s);
                c0129s.d();
                c0129s.getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, c0129s.f1709A);
                c0129s.e();
                io.flutter.plugin.platform.k kVar = c0137c5.f1776s;
                sparseArray = kVar.f2446o;
                sparseArray2 = kVar.f2447p;
                sparseArray3 = kVar.r;
                kVar.f2438g = c0129s;
                for (i2 = 0; i2 < sparseArray3.size(); i2++) {
                    kVar.f2438g.addView((io.flutter.plugin.platform.g) sparseArray3.valueAt(i2));
                }
                for (i3 = 0; i3 < sparseArray2.size(); i3++) {
                    if (sparseArray2.valueAt(i3) != null) {
                        throw new ClassCastException();
                    }
                    kVar.f2438g.addView(null);
                }
                if (sparseArray.size() <= 0) {
                    sparseArray.valueAt(0).getClass();
                    throw new ClassCastException();
                }
                io.flutter.plugin.platform.j jVar2 = c0137c5.f1777t;
                SparseArray sparseArray4 = jVar2.f2429k;
                SparseArray sparseArray5 = jVar2.f2430l;
                jVar2.f2425g = c0129s;
                for (int i6 = 0; i6 < sparseArray5.size(); i6++) {
                    if (sparseArray5.valueAt(i6) != null) {
                        throw new ClassCastException();
                    }
                    jVar2.f2425g.addView(null);
                }
                if (sparseArray4.size() > 0) {
                    sparseArray4.valueAt(0).getClass();
                    throw new ClassCastException();
                }
                Iterator it2 = c0129s.f1726o.iterator();
                if (it2.hasNext()) {
                    it2.next().getClass();
                    throw new ClassCastException();
                }
                if (c0129s.f1724m) {
                    c0117g.b();
                }
            } else if (c0137c5 != c0129s.f1725n) {
                c0129s.a();
                c0129s.f1725n = c0137c5;
                io.flutter.embedding.engine.renderer.h hVar2 = c0137c5.f1760b;
                c0129s.f1724m = hVar2.f2347c;
                c0129s.f1721j.c(hVar2);
                hVar2.a(c0117g);
                if (c0129s.f1717f) {
                }
                c0129s.f1727p = new Q(c0129s, c0129s.f1725n.f1766h);
                C0137c c0137c62 = c0129s.f1725n;
                c0129s.f1728q = new io.flutter.plugin.editing.l(c0129s, c0137c62.r, c0137c62.f1771m, c0137c62.f1776s, c0137c62.f1777t);
                TextServicesManager textServicesManager2 = (TextServicesManager) c0129s.getContext().getSystemService("textservices");
                c0129s.f1733w = textServicesManager2;
                c0129s.r = new io.flutter.plugin.editing.h(textServicesManager2, c0129s.f1725n.f1774p);
                new Q(c0129s, c0129s.f1728q.f2397b, c0129s.f1725n.f1771m);
                c0129s.f1729s = c0129s.f1725n.f1763e;
                c0129s.f1730t = new C0051b(c0129s);
                c0129s.f1731u = new C0112b(c0129s.f1725n.f1760b, false);
                io.flutter.view.i iVar2 = new io.flutter.view.i(c0129s, c0137c5.f1764f, (AccessibilityManager) c0129s.getContext().getSystemService("accessibility"), c0129s.getContext().getContentResolver(), c0137c5.f1778u);
                c0129s.f1732v = iVar2;
                iVar2.r = c0129s.f1736z;
                boolean zIsEnabled2 = iVar2.f2555c.isEnabled();
                boolean zIsTouchExplorationEnabled2 = c0129s.f1732v.f2555c.isTouchExplorationEnabled();
                if (c0129s.f1725n.f1760b.f2345a.getIsSoftwareRenderingEnabled()) {
                }
                C0137c c0137c72 = c0129s.f1725n;
                c0137c72.f1776s.f2443l.f2412a = c0129s.f1732v;
                new C0112b(c0137c72.f1760b, true);
                C0137c c0137c82 = c0129s.f1725n;
                c0137c82.f1777t.f2428j.f2412a = c0129s.f1732v;
                new C0112b(c0137c82.f1760b, true);
                c0129s.f1728q.f2397b.restartInput(c0129s);
                c0129s.d();
                c0129s.getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, c0129s.f1709A);
                c0129s.e();
                io.flutter.plugin.platform.k kVar2 = c0137c5.f1776s;
                sparseArray = kVar2.f2446o;
                sparseArray2 = kVar2.f2447p;
                sparseArray3 = kVar2.r;
                kVar2.f2438g = c0129s;
                while (i2 < sparseArray3.size()) {
                }
                while (i3 < sparseArray2.size()) {
                }
                if (sparseArray.size() <= 0) {
                }
            }
            c0120j4.f1676c.setId(i5);
            if (z2) {
                C0129s c0129s2 = c0120j4.f1676c;
                if (c0120j4.f1674a.c() != 1) {
                    throw new IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
                }
                if (c0120j4.f1679f != null) {
                    c0129s2.getViewTreeObserver().removeOnPreDrawListener(c0120j4.f1679f);
                }
                c0120j4.f1679f = new ViewTreeObserverOnPreDrawListenerC0118h(c0120j4, c0129s2);
                c0129s2.getViewTreeObserver().addOnPreDrawListener(c0120j4.f1679f);
            }
            setContentView(c0120j4.f1676c);
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            if (Build.VERSION.SDK_INT < 35) {
                window.setStatusBarColor(1073741824);
            }
            window.getDecorView().setSystemUiVisibility(1280);
        } catch (Throwable th2) {
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (k("onDestroy")) {
            this.f1667f.e();
            this.f1667f.f();
        }
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1669h);
            this.f1666e = false;
        }
        C0120j c0120j = this.f1667f;
        if (c0120j != null) {
            c0120j.f1674a = null;
            c0120j.f1675b = null;
            c0120j.f1676c = null;
            c0120j.f1677d = null;
            c0120j.f1678e = null;
            this.f1667f = null;
        }
        this.f1668g.a(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (k("onNewIntent")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0139e c0139e = c0137c.f1762d;
            if (c0139e.f()) {
                s0.a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    Iterator it = ((HashSet) c0139e.f1793f.f1785d).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            String strD = c0120j.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            C0218a c0218a = c0120j.f1675b.f1767i;
            c0218a.getClass();
            HashMap map = new HashMap();
            map.put("location", strD);
            c0218a.f2654a.B("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (k("onPause")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            c0120j.f1674a.getClass();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                C0220c c0220c = c0137c.f1765g;
                c0220c.a(3, c0220c.f2658c);
            }
        }
        this.f1668g.a(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (k("onPostResume")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            if (c0120j.f1675b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0120j.f1677d;
            if (eVar != null) {
                eVar.b();
            }
            Iterator it = c0120j.f1675b.f1776s.f2444m.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (k("onRequestPermissionsResult")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            if (c0120j.f1675b == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            Arrays.toString(strArr);
            Arrays.toString(iArr);
            C0139e c0139e = c0120j.f1675b.f1762d;
            if (!c0139e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            s0.a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                Iterator it = ((HashSet) c0139e.f1793f.f1783b).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1668g.a(androidx.lifecycle.d.ON_RESUME);
        if (k("onResume")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            c0120j.f1675b.f1760b.d();
            c0120j.f1674a.getClass();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                C0220c c0220c = c0137c.f1765g;
                c0220c.a(2, c0220c.f2658c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (k("onSaveInstanceState")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            if (c0120j.f1674a.j()) {
                bundle.putByteArray("framework", c0120j.f1675b.f1769k.f2698b);
            }
            c0120j.f1674a.getClass();
            Bundle bundle2 = new Bundle();
            C0139e c0139e = c0120j.f1675b.f1762d;
            if (c0139e.f()) {
                s0.a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    Iterator it = ((HashSet) c0139e.f1793f.f1787f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new ClassCastException();
                        }
                        throw null;
                    }
                    Trace.endSection();
                } catch (Throwable th) {
                    try {
                        Trace.endSection();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0120j.f1674a.d() == null || c0120j.f1674a.i()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0120j.f1674a.f1666e);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        Bundle bundleG;
        super.onStart();
        this.f1668g.a(androidx.lifecycle.d.ON_START);
        if (k("onStart")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            if (c0120j.f1674a.d() == null && !c0120j.f1675b.f1761c.f1817j) {
                String strF = c0120j.f1674a.f();
                if (strF == null) {
                    AbstractActivityC0116f abstractActivityC0116f = c0120j.f1674a;
                    abstractActivityC0116f.getClass();
                    strF = c0120j.d(abstractActivityC0116f.getIntent());
                    if (strF == null) {
                        strF = "/";
                    }
                }
                AbstractActivityC0116f abstractActivityC0116f2 = c0120j.f1674a;
                abstractActivityC0116f2.getClass();
                try {
                    bundleG = abstractActivityC0116f2.g();
                } catch (PackageManager.NameNotFoundException unused) {
                }
                String string = bundleG != null ? bundleG.getString("io.flutter.EntrypointUri") : null;
                c0120j.f1674a.e();
                c0120j.f1675b.f1767i.f2654a.B("setInitialRoute", strF, null);
                String strB = c0120j.f1674a.b();
                if (strB == null || strB.isEmpty()) {
                    strB = ((C0204e) C0051b.A().f633g).f2304d.f2293b;
                }
                c0120j.f1675b.f1761c.a(string == null ? new C0149a(strB, c0120j.f1674a.e()) : new C0149a(strB, string, c0120j.f1674a.e()), (List) c0120j.f1674a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            Integer num = c0120j.f1684k;
            if (num != null) {
                c0120j.f1676c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (k("onStop")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            c0120j.f1674a.getClass();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                C0220c c0220c = c0137c.f1765g;
                c0220c.a(5, c0220c.f2658c);
            }
            c0120j.f1684k = Integer.valueOf(c0120j.f1676c.getVisibility());
            c0120j.f1676c.setVisibility(8);
            C0137c c0137c2 = c0120j.f1675b;
            if (c0137c2 != null) {
                c0137c2.f1760b.b(40);
            }
        }
        this.f1668g.a(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (k("onTrimMemory")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                if (c0120j.f1682i && i2 >= 10) {
                    FlutterJNI flutterJNI = c0137c.f1761c.f1812e;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    C0219b c0219b = c0120j.f1675b.f1775q;
                    c0219b.getClass();
                    HashMap map = new HashMap(1);
                    map.put("type", "memoryPressure");
                    c0219b.f2655a.i(map, null);
                }
                c0120j.f1675b.f1760b.b(i2);
                io.flutter.plugin.platform.k kVar = c0120j.f1675b.f1776s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                Iterator it = kVar.f2444m.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (k("onUserLeaveHint")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c == null) {
                Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            C0139e c0139e = c0137c.f1762d;
            if (!c0139e.f()) {
                Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            s0.a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                Iterator it = ((HashSet) c0139e.f1793f.f1786e).iterator();
                if (!it.hasNext()) {
                    Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                try {
                    Trace.endSection();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (k("onWindowFocusChanged")) {
            C0120j c0120j = this.f1667f;
            c0120j.c();
            c0120j.f1674a.getClass();
            C0137c c0137c = c0120j.f1675b;
            if (c0137c != null) {
                C0220c c0220c = c0137c.f1765g;
                if (z2) {
                    c0220c.a(c0220c.f2656a, true);
                } else {
                    c0220c.a(c0220c.f2656a, false);
                }
            }
        }
    }
}
