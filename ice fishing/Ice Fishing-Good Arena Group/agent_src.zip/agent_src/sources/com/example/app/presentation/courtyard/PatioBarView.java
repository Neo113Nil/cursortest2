package com.example.app.presentation.courtyard;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.cd0;
import defpackage.iu;
import defpackage.mk0;
import defpackage.w60;
import defpackage.y10;
import java.util.List;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class PatioBarView extends View {
    public static final /* synthetic */ int JtBRWN = 0;
    public ValueAnimator CWqrlS;
    public final RectF D6ihV3;
    public int FIzcol;
    public List IZp36m;
    public final Paint Jtmurk;
    public final TextPaint KfVgV3;
    public final Paint Nk77O2;
    public final Paint XPjQRF;
    public float[] XXBzWV;
    public final Paint Y4dfZK;
    public final Paint YQmmye;
    public final Paint YcbaGR;
    public final Paint Z7SPLw;
    public final Path f44QqK;
    public final Path fiyBpU;
    public cd0 flOPlW;
    public final Paint fmcqY6;
    public final TextPaint khf4Rv;
    public final Paint oIzScy;
    public int xzMlIC;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PatioBarView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        Paint paint = new Paint(1);
        paint.setColor(context.getColor(R.color.taro_green_deep));
        this.oIzScy = paint;
        Paint paint2 = new Paint(1);
        paint2.setColor(context.getColor(R.color.mango));
        this.XPjQRF = paint2;
        Paint paint3 = new Paint(1);
        paint3.setColor(context.getColor(R.color.taro_green));
        this.YQmmye = paint3;
        Paint paint4 = new Paint(1);
        paint4.setColor(context.getColor(R.color.poi_cream));
        this.Y4dfZK = paint4;
        Paint paint5 = new Paint(1);
        paint5.setColor(context.getColor(R.color.leaf_tint));
        this.fmcqY6 = paint5;
        Paint paint6 = new Paint(1);
        paint6.setColor(context.getColor(R.color.mango));
        Paint.Style style = Paint.Style.STROKE;
        paint6.setStyle(style);
        paint6.setStrokeWidth(wbQVfV(2.4f));
        this.YcbaGR = paint6;
        Paint paint7 = new Paint(1);
        paint7.setColor(context.getColor(R.color.white));
        paint7.setAlpha(70);
        this.Jtmurk = paint7;
        float applyDimension = TypedValue.applyDimension(2, 11.0f, getResources().getDisplayMetrics());
        TextPaint textPaint = new TextPaint(1);
        textPaint.setColor(context.getColor(R.color.poi_cream));
        Paint.Align align = Paint.Align.CENTER;
        textPaint.setTextAlign(align);
        textPaint.setTextSize(applyDimension);
        textPaint.setFakeBoldText(true);
        this.KfVgV3 = textPaint;
        TextPaint textPaint2 = new TextPaint(1);
        textPaint2.setColor(context.getColor(R.color.water_glimmer));
        textPaint2.setTextAlign(align);
        textPaint2.setTextSize(applyDimension);
        textPaint2.setFakeBoldText(true);
        this.khf4Rv = textPaint2;
        Paint paint8 = new Paint(1);
        paint8.setStyle(style);
        paint8.setStrokeCap(Paint.Cap.ROUND);
        paint8.setStrokeJoin(Paint.Join.ROUND);
        this.Nk77O2 = paint8;
        Paint paint9 = new Paint(1);
        paint9.setStyle(Paint.Style.FILL);
        this.Z7SPLw = paint9;
        this.fiyBpU = new Path();
        this.f44QqK = new Path();
        this.D6ihV3 = new RectF();
        this.IZp36m = w60.flOPlW;
        this.FIzcol = -1;
        this.XXBzWV = new float[0];
    }

    public final void XPjQRF(Canvas canvas) {
        float f = -wbQVfV(8.0f);
        float wbQVfV = wbQVfV(8.0f);
        Paint paint = this.Nk77O2;
        canvas.drawLine(RecyclerView.a, f, RecyclerView.a, wbQVfV, paint);
        canvas.drawLine(-wbQVfV(4.0f), -wbQVfV(8.0f), -wbQVfV(4.0f), -wbQVfV(2.0f), paint);
        canvas.drawLine(wbQVfV(4.0f), -wbQVfV(8.0f), wbQVfV(4.0f), -wbQVfV(2.0f), paint);
        canvas.drawLine(-wbQVfV(4.0f), -wbQVfV(2.0f), wbQVfV(4.0f), -wbQVfV(2.0f), paint);
    }

    public final void Y4dfZK(Canvas canvas) {
        Path path = this.f44QqK;
        path.reset();
        path.moveTo(-wbQVfV(2.0f), wbQVfV(8.0f));
        path.quadTo(RecyclerView.a, RecyclerView.a, wbQVfV(3.0f), -wbQVfV(8.0f));
        canvas.drawPath(path, this.Nk77O2);
        float f = -wbQVfV(8.0f);
        float f2 = -wbQVfV(3.0f);
        float f3 = -wbQVfV(1.0f);
        float wbQVfV = wbQVfV(3.0f);
        Paint paint = this.Z7SPLw;
        canvas.drawOval(f, f2, f3, wbQVfV, paint);
        canvas.drawOval(wbQVfV(1.0f), -wbQVfV(6.0f), wbQVfV(7.0f), RecyclerView.a, paint);
    }

    public final void YQmmye(Canvas canvas) {
        canvas.drawOval(-wbQVfV(8.0f), wbQVfV(1.0f), wbQVfV(8.0f), wbQVfV(8.0f), this.Z7SPLw);
        float f = -wbQVfV(7.0f);
        float f2 = -wbQVfV(4.0f);
        float wbQVfV = wbQVfV(7.0f);
        float wbQVfV2 = wbQVfV(3.0f);
        Paint paint = this.Nk77O2;
        canvas.drawOval(f, f2, wbQVfV, wbQVfV2, paint);
        canvas.drawOval(-wbQVfV(5.0f), -wbQVfV(8.0f), wbQVfV(5.0f), -wbQVfV(3.0f), paint);
    }

    public final void flOPlW(Canvas canvas) {
        Path path = this.f44QqK;
        path.reset();
        path.moveTo(-wbQVfV(8.0f), -wbQVfV(1.0f));
        path.quadTo(RecyclerView.a, wbQVfV(9.0f), wbQVfV(8.0f), -wbQVfV(1.0f));
        path.close();
        canvas.drawPath(path, this.Z7SPLw);
        float f = -wbQVfV(8.0f);
        float f2 = -wbQVfV(1.0f);
        float wbQVfV = wbQVfV(8.0f);
        float f3 = -wbQVfV(1.0f);
        Paint paint = this.Nk77O2;
        canvas.drawLine(f, f2, wbQVfV, f3, paint);
        canvas.drawLine(-wbQVfV(3.0f), -wbQVfV(7.0f), -wbQVfV(3.0f), -wbQVfV(2.0f), paint);
        canvas.drawLine(wbQVfV(2.0f), -wbQVfV(7.0f), wbQVfV(2.0f), -wbQVfV(2.0f), paint);
    }

    public final cd0 getOnLeafSelected() {
        return this.flOPlW;
    }

    public final void oIzScy(Canvas canvas) {
        canvas.drawRoundRect(-wbQVfV(6.0f), -wbQVfV(2.0f), wbQVfV(6.0f), wbQVfV(3.0f), wbQVfV(2.0f), wbQVfV(2.0f), this.Z7SPLw);
        float f = -wbQVfV(5.0f);
        float wbQVfV = wbQVfV(3.0f);
        float f2 = -wbQVfV(5.0f);
        float wbQVfV2 = wbQVfV(8.0f);
        Paint paint = this.Nk77O2;
        canvas.drawLine(f, wbQVfV, f2, wbQVfV2, paint);
        canvas.drawLine(wbQVfV(5.0f), wbQVfV(3.0f), wbQVfV(5.0f), wbQVfV(8.0f), paint);
        canvas.drawLine(-wbQVfV(5.0f), -wbQVfV(8.0f), -wbQVfV(5.0f), -wbQVfV(2.0f), paint);
        canvas.drawLine(-wbQVfV(5.0f), -wbQVfV(8.0f), wbQVfV(4.0f), -wbQVfV(8.0f), paint);
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.CWqrlS;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.CWqrlS = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        float f;
        canvas.getClass();
        super.onDraw(canvas);
        if (this.IZp36m.isEmpty() || getWidth() == 0) {
            return;
        }
        float wbQVfV = wbQVfV(18.0f);
        Path path = this.fiyBpU;
        path.reset();
        path.moveTo(RecyclerView.a, getHeight());
        path.lineTo(RecyclerView.a, wbQVfV(10.0f) + wbQVfV);
        float width = getWidth() / this.IZp36m.size();
        int size = this.IZp36m.size();
        float f2 = 0.0f;
        for (int i = 0; i < size; i++) {
            path.quadTo((0.18f * width) + f2, wbQVfV - wbQVfV(2.0f), (width / 2.0f) + f2, wbQVfV);
            f2 += width;
            path.quadTo((0.82f * width) + f2, wbQVfV - wbQVfV(2.0f), f2, wbQVfV(10.0f) + wbQVfV);
        }
        path.lineTo(getWidth(), getHeight());
        path.close();
        canvas.drawPath(path, this.oIzScy);
        Paint.Style style = Paint.Style.STROKE;
        Paint paint = this.XPjQRF;
        paint.setStyle(style);
        paint.setStrokeWidth(wbQVfV(5.0f));
        canvas.drawPath(path, paint);
        float f3 = 6.0f;
        canvas.drawRect(RecyclerView.a, getHeight() - wbQVfV(6.0f), getWidth(), getHeight(), this.YQmmye);
        float width2 = getWidth() / this.IZp36m.size();
        int size2 = this.IZp36m.size();
        int i2 = 0;
        while (i2 < size2) {
            float f4 = width2 / 2.0f;
            float f5 = (i2 * width2) + f4;
            float Y4dfZK = mk0.Y4dfZK(this.XXBzWV[i2], 1.12f);
            float wbQVfV2 = ((wbQVfV(f3) * Y4dfZK) + wbQVfV(16.0f)) * (i2 == this.FIzcol ? 0.94f : 1.0f);
            float wbQVfV3 = wbQVfV(30.0f) - (wbQVfV(7.0f) * Y4dfZK);
            RectF rectF = this.D6ihV3;
            rectF.set(f5 - wbQVfV2, wbQVfV3 - wbQVfV2, f5 + wbQVfV2, wbQVfV3 + wbQVfV2);
            canvas.drawOval(rectF, Y4dfZK > 0.5f ? this.Y4dfZK : this.fmcqY6);
            if (Y4dfZK > 0.45f) {
                canvas.drawOval(rectF, this.YcbaGR);
                f = wbQVfV3;
                canvas.drawOval(f5 - (0.42f * wbQVfV2), wbQVfV3 - (0.55f * wbQVfV2), f5 - (0.08f * wbQVfV2), wbQVfV3 - (0.22f * wbQVfV2), this.Jtmurk);
            } else {
                f = wbQVfV3;
            }
            boolean z = Y4dfZK > 0.5f;
            int color = getContext().getColor(R.color.taro_green);
            Paint paint2 = this.Nk77O2;
            paint2.setColor(color);
            paint2.setStrokeWidth(wbQVfV(1.8f));
            this.Z7SPLw.setColor(getContext().getColor(z ? R.color.mango : R.color.leaf_green));
            float wbQVfV4 = wbQVfV2 / wbQVfV(20.0f);
            int save = canvas.save();
            try {
                canvas.translate(f5, f);
                canvas.scale(wbQVfV4, wbQVfV4);
                if (i2 == 0) {
                    flOPlW(canvas);
                } else if (i2 == 1) {
                    XPjQRF(canvas);
                } else if (i2 == 2) {
                    YQmmye(canvas);
                } else if (i2 != 3) {
                    oIzScy(canvas);
                } else {
                    Y4dfZK(canvas);
                }
                canvas.restoreToCount(save);
                TextPaint textPaint = Y4dfZK > 0.5f ? this.KfVgV3 : this.khf4Rv;
                float height = (getHeight() - wbQVfV(14.0f)) - ((textPaint.ascent() + textPaint.descent()) / 2.0f);
                save = canvas.save();
                try {
                    canvas.clipRect((f5 - f4) + wbQVfV(4.0f), RecyclerView.a, (f4 + f5) - wbQVfV(4.0f), canvas.getHeight());
                    canvas.drawText((String) this.IZp36m.get(i2), f5, height, textPaint);
                    canvas.restoreToCount(save);
                    i2++;
                    f3 = 6.0f;
                } finally {
                    canvas.restoreToCount(save);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getClass();
        if (this.IZp36m.isEmpty() || getWidth() == 0) {
            return false;
        }
        int fmcqY6 = mk0.fmcqY6((int) (motionEvent.getX() / (getWidth() / this.IZp36m.size())), iu.lYknzc(this.IZp36m));
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.FIzcol = fmcqY6;
            invalidate();
            return true;
        }
        if (actionMasked == 1) {
            int i = this.FIzcol;
            this.FIzcol = -1;
            invalidate();
            if (i == fmcqY6 && i >= 0) {
                super.performClick();
                cd0 cd0Var = this.flOPlW;
                if (cd0Var != null) {
                    cd0Var.YcbaGR(Integer.valueOf(i));
                }
            }
        } else {
            if (actionMasked != 2) {
                if (actionMasked != 3) {
                    return super.onTouchEvent(motionEvent);
                }
                this.FIzcol = -1;
                invalidate();
                return true;
            }
            if (this.FIzcol != fmcqY6) {
                this.FIzcol = -1;
                invalidate();
                return true;
            }
        }
        return true;
    }

    @Override // android.view.View
    public final boolean performClick() {
        super.performClick();
        return true;
    }

    public final void setOnLeafSelected(cd0 cd0Var) {
        this.flOPlW = cd0Var;
    }

    public final float wbQVfV(float f) {
        return f * getResources().getDisplayMetrics().density;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public PatioBarView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    public /* synthetic */ PatioBarView(Context context, AttributeSet attributeSet, int i, int i2, y10 y10Var) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public PatioBarView(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }
}
