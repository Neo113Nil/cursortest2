package com.example.app.presentation.welcome;

import android.animation.ArgbEvaluator;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.example.app.presentation.welcome.WelcomeFragment;
import com.general.melcan.fizoryfork.R;
import defpackage.Nk77O2;
import defpackage.ak1;
import defpackage.as1;
import defpackage.b12;
import defpackage.be0;
import defpackage.bh1;
import defpackage.bj1;
import defpackage.c12;
import defpackage.c52;
import defpackage.ci0;
import defpackage.d40;
import defpackage.em1;
import defpackage.ex;
import defpackage.fc0;
import defpackage.g00;
import defpackage.g12;
import defpackage.gy1;
import defpackage.ht0;
import defpackage.iu;
import defpackage.j02;
import defpackage.km0;
import defpackage.mk0;
import defpackage.mt0;
import defpackage.n41;
import defpackage.o42;
import defpackage.oa0;
import defpackage.ph0;
import defpackage.pt0;
import defpackage.r2;
import defpackage.s;
import defpackage.si0;
import defpackage.t;
import defpackage.te0;
import defpackage.u;
import defpackage.ua0;
import defpackage.ui0;
import defpackage.v42;
import defpackage.w10;
import defpackage.wy;
import defpackage.x32;
import defpackage.xy;
import defpackage.yz;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class WelcomeFragment extends oa0 implements xy {
    public static final /* synthetic */ ci0[] BhT9nv;
    public final gy1 HouJZE;
    public final gy1 PmLeSG;
    public boolean S7AthI;
    public int mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(WelcomeFragment.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        BhT9nv = new ci0[]{bj1Var, new bj1(WelcomeFragment.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
    }

    public WelcomeFragment() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = BhT9nv;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        o42 o42Var = new o42(this, 0);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(12, new t(11, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(c52.class), new u(KLRxE3, 10), o42Var, new u(KLRxE3, 11));
        this.HouJZE = new gy1(new o42(this, 1));
        this.mkqF8w = -1;
    }

    public final ua0 Aqawi6() {
        return (ua0) this.HouJZE.getValue();
    }

    public final void MFKG20(v42 v42Var) {
        int i;
        TextView textView = Aqawi6().XPjQRF;
        int i2 = v42Var.oIzScy;
        te0 te0Var = v42Var.Y4dfZK;
        textView.setText(D6ihV3(R.string.landing_card_step, Integer.valueOf(i2 + 1), 3));
        int[] iArr = {R.string.landing_card_one_title, R.string.landing_card_two_title, R.string.landing_card_three_title};
        int[] iArr2 = {R.string.landing_card_one_text, R.string.landing_card_two_text, R.string.landing_card_three_text};
        TextView textView2 = Aqawi6().Y4dfZK;
        int i3 = v42Var.oIzScy;
        textView2.setText(iArr[mk0.fmcqY6(i3, 2)]);
        Aqawi6().YQmmye.setText(iArr2[mk0.fmcqY6(i3, 2)]);
        Aqawi6().D6ihV3.setVisibility(i3 == 1 ? 0 : 8);
        Aqawi6().KfVgV3.setText(i3 == 2 ? v42Var.XPjQRF ? R.string.landing_open_catalog : R.string.landing_finish : R.string.landing_next);
        Aqawi6().xzMlIC.setVisibility(i3 != 2 ? 0 : 8);
        Set set = v42Var.YQmmye;
        Iterator it = d40.YcbaGR.iterator();
        int i4 = 0;
        while (true) {
            Nk77O2 nk77O2 = (Nk77O2) it;
            if (nk77O2.hasNext()) {
                Object next = nk77O2.next();
                int i5 = i4 + 1;
                if (i4 < 0) {
                    iu.oMDQy3();
                    throw null;
                }
                d40 d40Var = (d40) next;
                View childAt = Aqawi6().fmcqY6.getChildAt(i4);
                if (childAt != null) {
                    childAt.setSelected(set.contains(d40Var));
                }
                i4 = i5;
            } else {
                Iterator it2 = te0.YQmmye.iterator();
                int i6 = 0;
                while (true) {
                    Nk77O2 nk77O22 = (Nk77O2) it2;
                    if (!nk77O22.hasNext()) {
                        TextView textView3 = Aqawi6().khf4Rv;
                        te0Var.getClass();
                        int ordinal = te0Var.ordinal();
                        if (ordinal == 0) {
                            i = R.string.pace_hint_unhurried;
                        } else if (ordinal == 1) {
                            i = R.string.pace_hint_steady;
                        } else {
                            if (ordinal != 2) {
                                j02.D6ihV3();
                                return;
                            }
                            i = R.string.pace_hint_brisk;
                        }
                        textView3.setText(i);
                        return;
                    }
                    Object next2 = nk77O22.next();
                    int i7 = i6 + 1;
                    if (i6 < 0) {
                        iu.oMDQy3();
                        throw null;
                    }
                    te0 te0Var2 = (te0) next2;
                    View childAt2 = Aqawi6().Nk77O2.getChildAt(i6);
                    if (childAt2 != null) {
                        childAt2.setSelected(te0Var2 == te0Var);
                    }
                    i6 = i7;
                }
            }
        }
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = Aqawi6().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    public final void TyvOFV() {
        mt0 D6ihV3 = as1.D6ihV3(this);
        ht0 Y4dfZK = D6ihV3.flOPlW.Y4dfZK();
        D6ihV3.wbQVfV(R.id.dest_lanai, null, new pt0(true, false, Y4dfZK != null ? Y4dfZK.oIzScy.wbQVfV : D6ihV3.flOPlW.fmcqY6().YcbaGR.wbQVfV, true, false, R.anim.leaf_unroll_enter, R.anim.leaf_roll_exit, -1, -1));
    }

    public final c52 cUjre7() {
        return (c52) this.w4eZP5.getValue();
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        view.getClass();
        ((TextView) Aqawi6().YcbaGR.YQmmye).setText(R.string.landing_title);
        ((TextView) Aqawi6().YcbaGR.XPjQRF).setText(R.string.landing_subtitle);
        ArgbEvaluator argbEvaluator = bh1.wbQVfV;
        bh1.wbQVfV(Aqawi6().flOPlW, 0.96f);
        bh1.wbQVfV(Aqawi6().KfVgV3, 0.96f);
        bh1.wbQVfV(Aqawi6().xzMlIC, 0.96f);
        final int i = 0;
        Aqawi6().flOPlW.setOnClickListener(new View.OnClickListener(this) { // from class: n42
            public final /* synthetic */ WelcomeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2 = i;
                WelcomeFragment welcomeFragment = this.oIzScy;
                switch (i2) {
                    case 0:
                        ci0[] ci0VarArr = WelcomeFragment.BhT9nv;
                        c52 cUjre7 = welcomeFragment.cUjre7();
                        int i3 = ((v42) cUjre7.oIzScy.YcbaGR()).oIzScy;
                        if (i3 > 0) {
                            cUjre7.Y4dfZK(i3 - 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre7), null, new x42(3, null, cUjre7), 3);
                            break;
                        }
                    case 1:
                        ci0[] ci0VarArr2 = WelcomeFragment.BhT9nv;
                        c52 cUjre72 = welcomeFragment.cUjre7();
                        int i4 = ((v42) cUjre72.oIzScy.YcbaGR()).oIzScy;
                        if (i4 < 2) {
                            cUjre72.Y4dfZK(i4 + 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre72), null, new x42(0, null, cUjre72), 3);
                            break;
                        }
                    default:
                        ci0[] ci0VarArr3 = WelcomeFragment.BhT9nv;
                        c52 cUjre73 = welcomeFragment.cUjre7();
                        mk0.O49KBk(km0.JtBRWN(cUjre73), null, new x42(2, null, cUjre73), 3);
                        break;
                }
            }
        });
        final int i2 = 1;
        Aqawi6().KfVgV3.setOnClickListener(new View.OnClickListener(this) { // from class: n42
            public final /* synthetic */ WelcomeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i2;
                WelcomeFragment welcomeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = WelcomeFragment.BhT9nv;
                        c52 cUjre7 = welcomeFragment.cUjre7();
                        int i3 = ((v42) cUjre7.oIzScy.YcbaGR()).oIzScy;
                        if (i3 > 0) {
                            cUjre7.Y4dfZK(i3 - 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre7), null, new x42(3, null, cUjre7), 3);
                            break;
                        }
                    case 1:
                        ci0[] ci0VarArr2 = WelcomeFragment.BhT9nv;
                        c52 cUjre72 = welcomeFragment.cUjre7();
                        int i4 = ((v42) cUjre72.oIzScy.YcbaGR()).oIzScy;
                        if (i4 < 2) {
                            cUjre72.Y4dfZK(i4 + 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre72), null, new x42(0, null, cUjre72), 3);
                            break;
                        }
                    default:
                        ci0[] ci0VarArr3 = WelcomeFragment.BhT9nv;
                        c52 cUjre73 = welcomeFragment.cUjre7();
                        mk0.O49KBk(km0.JtBRWN(cUjre73), null, new x42(2, null, cUjre73), 3);
                        break;
                }
            }
        });
        final int i3 = 2;
        Aqawi6().xzMlIC.setOnClickListener(new View.OnClickListener(this) { // from class: n42
            public final /* synthetic */ WelcomeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i3;
                WelcomeFragment welcomeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = WelcomeFragment.BhT9nv;
                        c52 cUjre7 = welcomeFragment.cUjre7();
                        int i32 = ((v42) cUjre7.oIzScy.YcbaGR()).oIzScy;
                        if (i32 > 0) {
                            cUjre7.Y4dfZK(i32 - 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre7), null, new x42(3, null, cUjre7), 3);
                            break;
                        }
                    case 1:
                        ci0[] ci0VarArr2 = WelcomeFragment.BhT9nv;
                        c52 cUjre72 = welcomeFragment.cUjre7();
                        int i4 = ((v42) cUjre72.oIzScy.YcbaGR()).oIzScy;
                        if (i4 < 2) {
                            cUjre72.Y4dfZK(i4 + 1);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(cUjre72), null, new x42(0, null, cUjre72), 3);
                            break;
                        }
                    default:
                        ci0[] ci0VarArr3 = WelcomeFragment.BhT9nv;
                        c52 cUjre73 = welcomeFragment.cUjre7();
                        mk0.O49KBk(km0.JtBRWN(cUjre73), null, new x42(2, null, cUjre73), 3);
                        break;
                }
            }
        });
        ak1 ak1Var = cUjre7().XPjQRF;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, WelcomeFragment.class, "render", "render(Lcom/example/app/presentation/welcome/WelcomeState;)V", 9)), mk0.f44QqK(IZp36m()));
        ak1 ak1Var2 = cUjre7().Y4dfZK;
        fc0 IZp36m2 = IZp36m();
        IZp36m2.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var2, IZp36m2.YQmmye), new s(this, WelcomeFragment.class, "react", "react(Lcom/example/app/presentation/welcome/WelcomeSignal;)V", 10)), mk0.f44QqK(IZp36m()));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
