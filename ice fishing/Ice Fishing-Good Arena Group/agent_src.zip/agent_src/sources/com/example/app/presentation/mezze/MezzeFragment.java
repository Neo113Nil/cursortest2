package com.example.app.presentation.mezze;

import android.content.res.Resources;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.ak1;
import defpackage.as1;
import defpackage.b12;
import defpackage.be0;
import defpackage.bh0;
import defpackage.bj1;
import defpackage.c12;
import defpackage.ch0;
import defpackage.ci0;
import defpackage.em1;
import defpackage.ex;
import defpackage.fc0;
import defpackage.g00;
import defpackage.g12;
import defpackage.gy1;
import defpackage.km0;
import defpackage.mk0;
import defpackage.n41;
import defpackage.oa0;
import defpackage.ph0;
import defpackage.r2;
import defpackage.s;
import defpackage.sa0;
import defpackage.si0;
import defpackage.t;
import defpackage.u;
import defpackage.ui0;
import defpackage.vo0;
import defpackage.w10;
import defpackage.wn0;
import defpackage.wy;
import defpackage.x32;
import defpackage.xn0;
import defpackage.xy;
import defpackage.yg0;
import defpackage.yz;
import defpackage.zg0;
import java.util.ArrayList;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class MezzeFragment extends oa0 implements xy {
    public static final /* synthetic */ ci0[] GdlsZt;
    public final gy1 BhT9nv;
    public final gy1 HouJZE;
    public final gy1 PmLeSG;
    public final gy1 S7AthI;
    public boolean mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(MezzeFragment.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        GdlsZt = new ci0[]{bj1Var, new bj1(MezzeFragment.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
    }

    public MezzeFragment() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = GdlsZt;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        xn0 xn0Var = new xn0(this, 0);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(8, new t(7, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(vo0.class), new u(KLRxE3, 6), xn0Var, new u(KLRxE3, 7));
        this.HouJZE = new gy1(new xn0(this, 1));
        this.S7AthI = new gy1(new xn0(this, 2));
        this.BhT9nv = new gy1(new xn0(this, 3));
    }

    public final wn0 Aqawi6() {
        return (wn0) this.S7AthI.getValue();
    }

    public final sa0 MFKG20() {
        return (sa0) this.HouJZE.getValue();
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = MFKG20().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    public final vo0 cUjre7() {
        return (vo0) this.w4eZP5.getValue();
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        view.getClass();
        if (MFKG20().flOPlW.getAdapter() == null) {
            RecyclerView recyclerView = MFKG20().flOPlW;
            ZkTDf6();
            recyclerView.setLayoutManager(new LinearLayoutManager());
            MFKG20().flOPlW.setAdapter(Aqawi6());
            MFKG20().flOPlW.setItemAnimator(null);
            ch0 ch0Var = (ch0) this.BhT9nv.getValue();
            RecyclerView recyclerView2 = MFKG20().flOPlW;
            yg0 yg0Var = ch0Var.Rq1tA3;
            RecyclerView recyclerView3 = ch0Var.xzMlIC;
            if (recyclerView3 != recyclerView2) {
                if (recyclerView3 != null) {
                    ArrayList arrayList = ch0Var.D6ihV3;
                    recyclerView3.pMXSGT(ch0Var);
                    RecyclerView recyclerView4 = ch0Var.xzMlIC;
                    recyclerView4.xzMlIC.remove(yg0Var);
                    if (recyclerView4.FIzcol == yg0Var) {
                        recyclerView4.FIzcol = null;
                    }
                    ArrayList arrayList2 = ch0Var.xzMlIC.MNdnlq;
                    if (arrayList2 != null) {
                        arrayList2.remove(ch0Var);
                    }
                    int size = arrayList.size();
                    while (true) {
                        size--;
                        if (size < 0) {
                            break;
                        }
                        zg0 zg0Var = (zg0) arrayList.get(0);
                        zg0Var.fmcqY6.cancel();
                        ch0Var.Z7SPLw.wbQVfV(ch0Var.xzMlIC, zg0Var.YQmmye);
                    }
                    arrayList.clear();
                    ch0Var.zkaTkY = null;
                    VelocityTracker velocityTracker = ch0Var.XXBzWV;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        ch0Var.XXBzWV = null;
                    }
                    bh0 bh0Var = ch0Var.O49KBk;
                    if (bh0Var != null) {
                        bh0Var.wbQVfV = false;
                        ch0Var.O49KBk = null;
                    }
                    if (ch0Var.hrFPdg != null) {
                        ch0Var.hrFPdg = null;
                    }
                }
                ch0Var.xzMlIC = recyclerView2;
                Resources resources = recyclerView2.getResources();
                ch0Var.Y4dfZK = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_velocity);
                ch0Var.fmcqY6 = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_max_velocity);
                ch0Var.IZp36m = ViewConfiguration.get(ch0Var.xzMlIC.getContext()).getScaledTouchSlop();
                ch0Var.xzMlIC.YcbaGR(ch0Var);
                ch0Var.xzMlIC.xzMlIC.add(yg0Var);
                RecyclerView recyclerView5 = ch0Var.xzMlIC;
                if (recyclerView5.MNdnlq == null) {
                    recyclerView5.MNdnlq = new ArrayList();
                }
                recyclerView5.MNdnlq.add(ch0Var);
                ch0Var.O49KBk = new bh0(ch0Var);
                ch0Var.hrFPdg = new GestureDetector(ch0Var.xzMlIC.getContext(), ch0Var.O49KBk);
            }
        }
        ak1 ak1Var = cUjre7().XPjQRF;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        int i = 22;
        as1.zkaTkY(new r2(i, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, MezzeFragment.class, "render", "render(Lcom/example/app/presentation/mezze/MezzeState;)V", 5)), mk0.f44QqK(IZp36m()));
        ak1 ak1Var2 = cUjre7().Y4dfZK;
        fc0 IZp36m2 = IZp36m();
        IZp36m2.oIzScy();
        as1.zkaTkY(new r2(i, km0.fiyBpU(ak1Var2, IZp36m2.YQmmye), new s(this, MezzeFragment.class, "react", "react(Lcom/example/app/presentation/mezze/MezzeSignal;)V", 6)), mk0.f44QqK(IZp36m()));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
