package com.example.app.presentation.grove;

import android.animation.ArgbEvaluator;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.general.melcan.fizoryfork.R;
import defpackage.a70;
import defpackage.ak1;
import defpackage.as1;
import defpackage.b12;
import defpackage.be0;
import defpackage.bh1;
import defpackage.bj1;
import defpackage.c12;
import defpackage.ci0;
import defpackage.ee0;
import defpackage.em1;
import defpackage.ex;
import defpackage.fc0;
import defpackage.fe0;
import defpackage.g00;
import defpackage.g12;
import defpackage.ge0;
import defpackage.gy1;
import defpackage.km0;
import defpackage.mk0;
import defpackage.n41;
import defpackage.oa0;
import defpackage.ph0;
import defpackage.q;
import defpackage.r2;
import defpackage.s;
import defpackage.se0;
import defpackage.si0;
import defpackage.t;
import defpackage.u;
import defpackage.ui0;
import defpackage.w10;
import defpackage.wb0;
import defpackage.wy;
import defpackage.x32;
import defpackage.xy;
import defpackage.yz;
import java.util.Set;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class GroveFragment extends oa0 implements xy {
    public static final /* synthetic */ ci0[] BhT9nv;
    public final gy1 HouJZE;
    public final gy1 PmLeSG;
    public Set S7AthI;
    public int mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(GroveFragment.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        BhT9nv = new ci0[]{bj1Var, new bj1(GroveFragment.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
    }

    public GroveFragment() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = BhT9nv;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        ee0 ee0Var = new ee0(this, 0);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(6, new t(5, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(se0.class), new u(KLRxE3, 4), ee0Var, new u(KLRxE3, 5));
        this.HouJZE = new gy1(new ee0(this, 1));
        this.mkqF8w = -1;
        this.S7AthI = a70.flOPlW;
    }

    public final se0 Aqawi6() {
        return (se0) this.w4eZP5.getValue();
    }

    public final wb0 MFKG20() {
        return (wb0) this.HouJZE.getValue();
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = MFKG20().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        view.getClass();
        ((TextView) MFKG20().Y4dfZK.oIzScy).setText(R.string.patch_title);
        ((TextView) MFKG20().Y4dfZK.flOPlW).setText(R.string.patch_subtitle);
        MFKG20().YQmmye.setOnPatchTapped(new q(1, Aqawi6(), se0.class, "turnPatch", "turnPatch(I)V", 0, 0, 5));
        MFKG20().YQmmye.setOnSpringTapped(new fe0(this, 0));
        ArgbEvaluator argbEvaluator = bh1.wbQVfV;
        bh1.wbQVfV(MFKG20().Nk77O2, 0.96f);
        bh1.wbQVfV(MFKG20().Jtmurk, 0.96f);
        MFKG20().Nk77O2.setOnClickListener(new ge0(0, this));
        MFKG20().Jtmurk.setOnClickListener(new ge0(1, this));
        ak1 ak1Var = Aqawi6().XPjQRF;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, GroveFragment.class, "render", "render(Lcom/example/app/presentation/grove/GroveState;)V", 3)), mk0.f44QqK(IZp36m()));
        ak1 ak1Var2 = Aqawi6().Y4dfZK;
        fc0 IZp36m2 = IZp36m();
        IZp36m2.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var2, IZp36m2.YQmmye), new s(this, GroveFragment.class, "react", "react(Lcom/example/app/presentation/grove/GroveSignal;)V", 4)), mk0.f44QqK(IZp36m()));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
