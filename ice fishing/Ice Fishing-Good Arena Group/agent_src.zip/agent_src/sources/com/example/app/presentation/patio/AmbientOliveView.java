package com.example.app.presentation.patio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.r0;
import defpackage.y10;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class AmbientOliveView extends View {
    public static final /* synthetic */ int Y4dfZK = 0;
    public float XPjQRF;
    public ValueAnimator YQmmye;
    public final Paint flOPlW;
    public final Path oIzScy;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AmbientOliveView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        Paint paint = new Paint(1);
        paint.setColor(context.getColor(R.color.sand_shadow));
        paint.setStyle(Paint.Style.FILL);
        this.flOPlW = paint;
        this.oIzScy = new Path();
        setClickable(false);
        setFocusable(false);
    }

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.a, 1.0f);
        ofFloat.setDuration(12000L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setRepeatMode(2);
        ofFloat.setInterpolator(new AccelerateDecelerateInterpolator());
        ofFloat.addUpdateListener(new r0(0, this));
        ofFloat.start();
        this.YQmmye = ofFloat;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.YQmmye;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.YQmmye = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        canvas.getClass();
        super.onDraw(canvas);
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        float width = getWidth() * 0.18f;
        wbQVfV(canvas, (this.XPjQRF * width) + ((-getWidth()) * 0.08f), getHeight() * 0.18f, 0.42f * getWidth(), -12.0f);
        wbQVfV(canvas, (getWidth() * 0.58f) - (this.XPjQRF * width), 0.66f * getHeight(), 0.38f * getWidth(), 18.0f);
    }

    public final void wbQVfV(Canvas canvas, float f, float f2, float f3, float f4) {
        Canvas canvas2;
        Path path = this.oIzScy;
        Paint paint = this.flOPlW;
        if (f3 < 1.0f) {
            f3 = 1.0f;
        }
        int save = canvas.save();
        canvas.rotate(f4, (0.5f * f3) + f, f2);
        try {
            paint.setStyle(Paint.Style.STROKE);
            float f5 = 0.025f * f3;
            if (f5 < 2.0f) {
                f5 = 2.0f;
            }
            paint.setStrokeWidth(f5);
            paint.setStrokeCap(Paint.Cap.ROUND);
            path.reset();
            path.moveTo(f, (0.28f * f3) + f2);
            path.quadTo((0.48f * f3) + f, f2 - (0.08f * f3), f + f3, f2);
            canvas.drawPath(path, paint);
            paint.setStyle(Paint.Style.FILL);
            int i = 0;
            while (i < 6) {
                int i2 = i + 1;
                float f6 = i2 / 7.0f;
                float f7 = (f3 * f6) + f;
                float f8 = ((0.22f - (f6 * 0.22f)) * f3) + f2;
                float f9 = 0.065f * f3;
                float f10 = f7 - (0.12f * f3);
                float f11 = (f8 - f9) - (i % 2 == 0 ? f9 : 0.0f);
                if (i % 2 == 0) {
                    f9 = 0.0f;
                }
                float f12 = f8 + f9;
                canvas2 = canvas;
                try {
                    canvas2.drawOval(f10, f11, f7, f12, paint);
                    i = i2;
                    canvas = canvas2;
                } catch (Throwable th) {
                    th = th;
                    Throwable th2 = th;
                    canvas2.restoreToCount(save);
                    throw th2;
                }
            }
            canvas.restoreToCount(save);
        } catch (Throwable th3) {
            th = th3;
            canvas2 = canvas;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AmbientOliveView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    public /* synthetic */ AmbientOliveView(Context context, AttributeSet attributeSet, int i, int i2, y10 y10Var) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AmbientOliveView(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }
}
