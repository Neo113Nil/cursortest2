package com.example.app.data.datasource.room;

import defpackage.ii0;
import defpackage.we0;
import defpackage.zr1;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public abstract class TerraceDatabase extends zr1 {
    public abstract ii0 Nk77O2();

    public abstract we0 khf4Rv();
}
