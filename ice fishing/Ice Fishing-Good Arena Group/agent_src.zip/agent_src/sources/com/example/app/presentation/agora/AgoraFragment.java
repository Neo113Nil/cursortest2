package com.example.app.presentation.agora;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.ak1;
import defpackage.as1;
import defpackage.b12;
import defpackage.be0;
import defpackage.bj1;
import defpackage.c12;
import defpackage.ci0;
import defpackage.em1;
import defpackage.ex;
import defpackage.fc0;
import defpackage.g00;
import defpackage.g12;
import defpackage.gh1;
import defpackage.gy1;
import defpackage.k0;
import defpackage.km0;
import defpackage.mk0;
import defpackage.n;
import defpackage.n41;
import defpackage.o;
import defpackage.oa0;
import defpackage.ph0;
import defpackage.q;
import defpackage.r2;
import defpackage.s;
import defpackage.si0;
import defpackage.t;
import defpackage.ta0;
import defpackage.u;
import defpackage.ui0;
import defpackage.w10;
import defpackage.w60;
import defpackage.wy;
import defpackage.x32;
import defpackage.xy;
import defpackage.yz;
import java.util.List;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class AgoraFragment extends oa0 implements xy {
    public static final /* synthetic */ ci0[] UfzG8s;
    public View BhT9nv;
    public gh1 GdlsZt;
    public final gy1 HouJZE;
    public final gy1 JAoXHU;
    public final gy1 PmLeSG;
    public ImageView S7AthI;
    public List mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(AgoraFragment.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        UfzG8s = new ci0[]{bj1Var, new bj1(AgoraFragment.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
    }

    public AgoraFragment() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = UfzG8s;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        o oVar = new o(this, 1);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(1, new t(0, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(k0.class), new u(KLRxE3, 0), oVar, new u(KLRxE3, 1));
        this.HouJZE = new gy1(new o(this, 2));
        this.mkqF8w = w60.flOPlW;
        this.JAoXHU = new gy1(new o(this, 3));
    }

    public final k0 Aqawi6() {
        return (k0) this.w4eZP5.getValue();
    }

    @Override // defpackage.oa0
    public final void IBj4av() {
        gh1 gh1Var = this.GdlsZt;
        if (gh1Var != null) {
            gh1Var.oIzScy = null;
            gh1Var.XPjQRF = null;
        }
        this.S7AthI = null;
        this.BhT9nv = null;
        this.i37xLF = true;
    }

    public final ta0 MFKG20() {
        return (ta0) this.HouJZE.getValue();
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = MFKG20().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        view.getClass();
        if (MFKG20().flOPlW.getAdapter() == null) {
            RecyclerView recyclerView = MFKG20().flOPlW;
            ZkTDf6();
            recyclerView.setLayoutManager(new LinearLayoutManager());
            MFKG20().flOPlW.setAdapter((n) this.JAoXHU.getValue());
            MFKG20().flOPlW.setItemAnimator(null);
            gh1 gh1Var = new gh1(new o(this, 0), new q(1, Aqawi6(), k0.class, "toggleGroup", "toggleGroup(Lcom/example/app/data/model/DishGroup;)V", 0, 0, 3));
            MFKG20().flOPlW.YcbaGR(gh1Var);
            MFKG20().flOPlW.xzMlIC.add(gh1Var);
            this.GdlsZt = gh1Var;
        }
        ak1 ak1Var = Aqawi6().Y4dfZK;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, AgoraFragment.class, "render", "render(Lcom/example/app/presentation/agora/AgoraState;)V", 0)), mk0.f44QqK(IZp36m()));
        ak1 ak1Var2 = Aqawi6().YcbaGR;
        fc0 IZp36m2 = IZp36m();
        IZp36m2.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var2, IZp36m2.YQmmye), new s(this, AgoraFragment.class, "react", "react(Lcom/example/app/presentation/agora/AgoraSignal;)V", 1)), mk0.f44QqK(IZp36m()));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
