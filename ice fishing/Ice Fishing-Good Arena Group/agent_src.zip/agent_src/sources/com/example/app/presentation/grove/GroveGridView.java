package com.example.app.presentation.grove;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.a70;
import defpackage.cd0;
import defpackage.gr;
import defpackage.he0;
import defpackage.j02;
import defpackage.jr;
import defpackage.ng1;
import defpackage.r0;
import defpackage.y10;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class GroveGridView extends View {
    public static final /* synthetic */ int X7zyyx = 0;
    public float[] CWqrlS;
    public float D6ihV3;
    public int[] FIzcol;
    public final float[] IBj4av;
    public gr IZp36m;
    public float[] JtBRWN;
    public final Paint Jtmurk;
    public final Paint KfVgV3;
    public final Path Nk77O2;
    public ValueAnimator O49KBk;
    public final int[] Rq1tA3;
    public final Paint XPjQRF;
    public Set XXBzWV;
    public final Paint Y4dfZK;
    public final Paint YQmmye;
    public final Paint YcbaGR;
    public final Matrix Z7SPLw;
    public float f44QqK;
    public LinearGradient fiyBpU;
    public cd0 flOPlW;
    public final Paint fmcqY6;
    public float hrFPdg;
    public final RectF khf4Rv;
    public cd0 oIzScy;
    public int[] xzMlIC;
    public final HashMap zkaTkY;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GroveGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        Paint paint = new Paint(1);
        Paint.Style style = Paint.Style.FILL;
        paint.setStyle(style);
        this.XPjQRF = paint;
        Paint paint2 = new Paint(1);
        Paint.Style style2 = Paint.Style.STROKE;
        paint2.setStyle(style2);
        Paint.Cap cap = Paint.Cap.ROUND;
        paint2.setStrokeCap(cap);
        paint2.setColor(context.getColor(R.color.taro_green));
        this.YQmmye = paint2;
        Paint paint3 = new Paint(1);
        paint3.setStyle(style2);
        paint3.setStrokeCap(cap);
        paint3.setColor(context.getColor(R.color.water_glimmer));
        this.Y4dfZK = paint3;
        Paint paint4 = new Paint(1);
        paint4.setStyle(style);
        this.fmcqY6 = paint4;
        Paint paint5 = new Paint(1);
        paint5.setStyle(style2);
        paint5.setStrokeWidth(flOPlW(2.0f));
        paint5.setColor(context.getColor(R.color.reed_hairline));
        this.YcbaGR = paint5;
        Paint paint6 = new Paint(1);
        paint6.setStyle(style2);
        paint6.setStrokeWidth(flOPlW(3.0f));
        paint6.setColor(context.getColor(R.color.mango));
        this.Jtmurk = paint6;
        Paint paint7 = new Paint(1);
        paint7.setStyle(style);
        paint7.setColor(context.getColor(R.color.taro_green));
        this.KfVgV3 = paint7;
        this.khf4Rv = new RectF();
        this.Nk77O2 = new Path();
        this.Z7SPLw = new Matrix();
        this.f44QqK = -1.0f;
        this.D6ihV3 = -1.0f;
        this.xzMlIC = new int[0];
        this.FIzcol = new int[0];
        this.XXBzWV = a70.flOPlW;
        this.CWqrlS = new float[0];
        this.JtBRWN = new float[0];
        this.zkaTkY = new HashMap();
        int color = context.getColor(R.color.water_glimmer);
        this.Rq1tA3 = new int[]{color, context.getColor(R.color.poi_cream), color};
        this.IBj4av = new float[]{RecyclerView.a, 0.5f, 1.0f};
    }

    public final float flOPlW(float f) {
        return f * getResources().getDisplayMetrics().density;
    }

    public final cd0 getOnPatchTapped() {
        return this.flOPlW;
    }

    public final cd0 getOnSpringTapped() {
        return this.oIzScy;
    }

    public final void oIzScy(Canvas canvas, float f, float f2, float f3, int i, boolean z) {
        float f4 = (f3 / 2.0f) + (i * f3) + f;
        float flOPlW = flOPlW(10.0f);
        Path path = this.Nk77O2;
        path.reset();
        if (z) {
            float f5 = flOPlW / 2.0f;
            float f6 = f - flOPlW;
            path.moveTo(f4 - f5, f6);
            path.lineTo(f5 + f4, f6);
            path.lineTo(f4, f - flOPlW(2.0f));
        } else {
            float f7 = flOPlW / 2.0f;
            float f8 = f + f2;
            float f9 = flOPlW + f8;
            path.moveTo(f4 - f7, f9);
            path.lineTo(f7 + f4, f9);
            path.lineTo(f4, flOPlW(2.0f) + f8);
        }
        path.close();
        canvas.drawPath(path, this.KfVgV3);
    }

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.a, 1.0f);
        ofFloat.setDuration(3400L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.addUpdateListener(new r0(1, this));
        ofFloat.start();
        this.O49KBk = ofFloat;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.O49KBk;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.O49KBk = null;
        wbQVfV();
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        float f;
        Paint paint;
        float f2;
        int i;
        Paint paint2;
        int save;
        char c;
        float f3;
        Paint paint3;
        float f4;
        float f5;
        canvas.getClass();
        super.onDraw(canvas);
        gr grVar = this.IZp36m;
        if (grVar == null) {
            return;
        }
        ArrayList arrayList = grVar.YQmmye;
        int i2 = grVar.XPjQRF;
        if (i2 <= 0 || getWidth() == 0) {
            return;
        }
        float flOPlW = flOPlW(14.0f);
        float min = Math.min(getWidth(), getHeight()) - (flOPlW * 2.0f);
        if (min < 1.0f) {
            min = 1.0f;
        }
        float f6 = min / i2;
        float flOPlW2 = flOPlW(3.0f);
        float flOPlW3 = flOPlW(10.0f);
        float f7 = 0.24f * f6;
        float flOPlW4 = flOPlW(4.0f);
        if (f7 < flOPlW4) {
            f7 = flOPlW4;
        }
        Paint paint4 = this.YQmmye;
        paint4.setStrokeWidth(f7);
        Paint paint5 = this.Y4dfZK;
        paint5.setStrokeWidth(f7);
        float f8 = min * 0.7f;
        float f9 = (((f8 * 2.0f) + min) * this.hrFPdg) + (-f8);
        LinearGradient linearGradient = this.fiyBpU;
        Paint paint6 = this.fmcqY6;
        if (linearGradient != null && this.f44QqK == f8 && this.D6ihV3 == min) {
            f2 = min;
            f = 2.0f;
            paint = paint6;
        } else {
            this.f44QqK = f8;
            this.D6ihV3 = min;
            f = 2.0f;
            paint = paint6;
            f2 = min;
            LinearGradient linearGradient2 = new LinearGradient(RecyclerView.a, RecyclerView.a, f8, f2, this.Rq1tA3, this.IBj4av, Shader.TileMode.CLAMP);
            paint.setShader(linearGradient2);
            this.fiyBpU = linearGradient2;
        }
        Matrix matrix = this.Z7SPLw;
        matrix.setTranslate(flOPlW + f9, flOPlW);
        LinearGradient linearGradient3 = this.fiyBpU;
        if (linearGradient3 != null) {
            linearGradient3.setLocalMatrix(matrix);
        }
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            ng1 ng1Var = (ng1) arrayList.get(i3);
            float f10 = flOPlW2 / f;
            float f11 = (ng1Var.flOPlW * f6) + flOPlW + f10;
            float[] fArr = this.JtBRWN;
            float f12 = RecyclerView.a;
            float f13 = f7;
            float f14 = f11 + ((i3 < 0 || i3 >= fArr.length) ? 0.0f : fArr[i3]);
            float f15 = (ng1Var.wbQVfV * f6) + flOPlW + f10;
            Paint paint7 = paint4;
            ArrayList arrayList2 = arrayList;
            RectF rectF = this.khf4Rv;
            rectF.set(f14, f15, (f14 + f6) - flOPlW2, (f15 + f6) - flOPlW2);
            Context context = getContext();
            List list = grVar.Y4dfZK;
            int ordinal = ((jr) list.get(ng1Var.Y4dfZK % list.size())).flOPlW.ordinal();
            if (ordinal == 0) {
                i = R.color.tag_aubergine_purple;
            } else if (ordinal == 1) {
                i = R.color.tag_clay_brown;
            } else if (ordinal == 2) {
                i = R.color.tag_tomato_red;
            } else if (ordinal == 3) {
                i = R.color.tag_olive_green;
            } else {
                if (ordinal != 4) {
                    j02.D6ihV3();
                    return;
                }
                i = R.color.tag_feta_white;
            }
            int color = context.getColor(i);
            Paint paint8 = this.XPjQRF;
            paint8.setColor(color);
            canvas.drawRoundRect(rectF, flOPlW3, flOPlW3, paint8);
            boolean contains = this.XXBzWV.contains(Integer.valueOf(i3));
            if (contains) {
                save = canvas.save();
                canvas.clipRect(rectF);
                try {
                    paint.setAlpha(110);
                    canvas.drawRoundRect(rectF, flOPlW3, flOPlW3, paint);
                } finally {
                    canvas.restoreToCount(save);
                }
            }
            canvas.drawRoundRect(rectF, flOPlW3, flOPlW3, this.YcbaGR);
            float f16 = flOPlW3;
            float centerX = rectF.centerX();
            float centerY = rectF.centerY();
            float width = rectF.width() / f;
            if (contains) {
                paint2 = paint5;
            } else {
                paint2 = paint5;
                paint5 = paint7;
            }
            float f17 = ((i3 < 0 || i3 >= this.xzMlIC.length) ? ng1Var.YQmmye : r14[i3]) * 90.0f;
            float[] fArr2 = this.CWqrlS;
            if (i3 >= 0 && i3 < fArr2.length) {
                f12 = fArr2[i3];
            }
            save = canvas.save();
            canvas.rotate(f17 + f12, centerX, centerY);
            try {
                Iterator it = ng1Var.oIzScy.flOPlW.iterator();
                while (it.hasNext()) {
                    int intValue = ((Number) it.next()).intValue();
                    RectF rectF2 = rectF;
                    float f18 = intValue != 1 ? intValue != 3 ? centerX : centerX - width : centerX + width;
                    if (intValue != 0) {
                        c = 2;
                        if (intValue != 2) {
                            f5 = f18;
                            paint3 = paint2;
                            f4 = centerY;
                            canvas.drawLine(centerX, centerY, f5, f4, paint5);
                            paint2 = paint3;
                            rectF = rectF2;
                        } else {
                            f3 = centerY + width;
                        }
                    } else {
                        c = 2;
                        f3 = centerY - width;
                    }
                    paint3 = paint2;
                    f4 = f3;
                    f5 = f18;
                    canvas.drawLine(centerX, centerY, f5, f4, paint5);
                    paint2 = paint3;
                    rectF = rectF2;
                }
                RectF rectF3 = rectF;
                Paint paint9 = paint2;
                canvas.drawCircle(centerX, centerY, 0.62f * f13, paint5);
                canvas.restoreToCount(save);
                if (ng1Var.fmcqY6) {
                    canvas.drawCircle(rectF3.centerX(), rectF3.centerY(), (f6 - flOPlW2) * 0.16f, this.Jtmurk);
                }
                i3++;
                paint5 = paint9;
                arrayList = arrayList2;
                f7 = f13;
                paint4 = paint7;
                flOPlW3 = f16;
            } catch (Throwable th) {
                throw th;
            }
        }
        float f19 = f2;
        oIzScy(canvas, flOPlW, f19, f6, grVar.YcbaGR, true);
        oIzScy(canvas, flOPlW, f19, f6, grVar.KfVgV3, false);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        int size = View.MeasureSpec.getSize(i);
        setMeasuredDimension(size, size);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        Object obj;
        motionEvent.getClass();
        gr grVar = this.IZp36m;
        if (grVar == null) {
            return false;
        }
        int i = grVar.XPjQRF;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                return super.onTouchEvent(motionEvent);
            }
            float flOPlW = flOPlW(14.0f);
            float min = Math.min(getWidth(), getHeight()) - (2.0f * flOPlW);
            if (min < 1.0f) {
                min = 1.0f;
            }
            float f = min / i;
            int x = (int) ((motionEvent.getX() - flOPlW) / f);
            int y = (int) ((motionEvent.getY() - flOPlW) / f);
            if (x >= 0 && x < i && y >= 0 && y < i) {
                int i2 = (i * y) + x;
                super.performClick();
                ArrayList arrayList = grVar.YQmmye;
                int size = arrayList.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        obj = null;
                        break;
                    }
                    obj = arrayList.get(i3);
                    i3++;
                    ng1 ng1Var = (ng1) obj;
                    if (ng1Var.wbQVfV == y && ng1Var.flOPlW == x) {
                        break;
                    }
                }
                ng1 ng1Var2 = (ng1) obj;
                if (ng1Var2 != null) {
                    if (ng1Var2.fmcqY6) {
                        if (i2 >= 0 && i2 < this.JtBRWN.length) {
                            int i4 = (-i2) - 1;
                            Integer valueOf = Integer.valueOf(i4);
                            HashMap hashMap = this.zkaTkY;
                            ValueAnimator valueAnimator = (ValueAnimator) hashMap.get(valueOf);
                            if (valueAnimator != null) {
                                valueAnimator.cancel();
                            }
                            ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.a, 1.0f);
                            ofFloat.setDuration(380L);
                            ofFloat.addUpdateListener(new he0(this, i2, 0));
                            ofFloat.start();
                            hashMap.put(Integer.valueOf(i4), ofFloat);
                        }
                        cd0 cd0Var = this.oIzScy;
                        if (cd0Var != null) {
                            cd0Var.YcbaGR(Integer.valueOf(i2));
                            return true;
                        }
                    } else {
                        cd0 cd0Var2 = this.flOPlW;
                        if (cd0Var2 != null) {
                            cd0Var2.YcbaGR(Integer.valueOf(i2));
                        }
                    }
                }
            }
        }
        return true;
    }

    @Override // android.view.View
    public final boolean performClick() {
        super.performClick();
        return true;
    }

    public final void setOnPatchTapped(cd0 cd0Var) {
        this.flOPlW = cd0Var;
    }

    public final void setOnSpringTapped(cd0 cd0Var) {
        this.oIzScy = cd0Var;
    }

    public final void wbQVfV() {
        HashMap hashMap = this.zkaTkY;
        Collection values = hashMap.values();
        values.getClass();
        Iterator it = values.iterator();
        while (it.hasNext()) {
            ((ValueAnimator) it.next()).cancel();
        }
        hashMap.clear();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public GroveGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    public /* synthetic */ GroveGridView(Context context, AttributeSet attributeSet, int i, int i2, y10 y10Var) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public GroveGridView(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }
}
