package com.example.app.common;

import android.app.Application;
import defpackage.bj1;
import defpackage.ci0;
import defpackage.em1;
import defpackage.ex;
import defpackage.f2;
import defpackage.fmcqY6;
import defpackage.h4;
import defpackage.n4;
import defpackage.ti0;
import defpackage.u1;
import defpackage.wy;
import defpackage.xy;
import defpackage.yz;
import defpackage.zt;
import java.lang.ref.WeakReference;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public class App extends Application implements xy {
    public static final /* synthetic */ ci0[] oIzScy;
    public final ti0 flOPlW = new ti0(new zt(2, new fmcqY6(1, this)));

    static {
        bj1 bj1Var = new bj1(App.class, "di", "getDi()Lorg/kodein/di/LazyDI;", 0);
        em1.wbQVfV.getClass();
        oIzScy = new ci0[]{bj1Var};
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        if (u1.oIzScy != 1) {
            u1.oIzScy = 1;
            synchronized (u1.Jtmurk) {
                try {
                    n4 n4Var = u1.YcbaGR;
                    n4Var.getClass();
                    h4 h4Var = new h4(n4Var);
                    while (h4Var.hasNext()) {
                        u1 u1Var = (u1) ((WeakReference) h4Var.next()).get();
                        if (u1Var != null) {
                            ((f2) u1Var).Z7SPLw(true, true);
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        ci0 ci0Var = oIzScy[0];
        ti0 ti0Var = this.flOPlW;
        ti0Var.getClass();
        ci0Var.getClass();
        return ti0Var;
    }
}
