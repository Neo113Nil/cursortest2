package com.example.app.presentation.recipe;

import android.animation.ArgbEvaluator;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.example.app.presentation.recipe.RecipeFragment;
import com.general.melcan.fizoryfork.R;
import defpackage.ak1;
import defpackage.as1;
import defpackage.b12;
import defpackage.b40;
import defpackage.be0;
import defpackage.bh1;
import defpackage.bj1;
import defpackage.bl0;
import defpackage.bt0;
import defpackage.c12;
import defpackage.ci0;
import defpackage.ck1;
import defpackage.e40;
import defpackage.ec0;
import defpackage.em1;
import defpackage.ex;
import defpackage.fc0;
import defpackage.g00;
import defpackage.g12;
import defpackage.gy1;
import defpackage.ht0;
import defpackage.hu;
import defpackage.j02;
import defpackage.km0;
import defpackage.mk0;
import defpackage.mt0;
import defpackage.n41;
import defpackage.oa0;
import defpackage.ph0;
import defpackage.pk1;
import defpackage.pt0;
import defpackage.r2;
import defpackage.rk1;
import defpackage.s;
import defpackage.si0;
import defpackage.t;
import defpackage.u;
import defpackage.ui0;
import defpackage.uk1;
import defpackage.w10;
import defpackage.wy;
import defpackage.x32;
import defpackage.xw1;
import defpackage.xy;
import defpackage.y3;
import defpackage.yz;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class RecipeFragment extends oa0 implements xy {
    public static final /* synthetic */ ci0[] GdlsZt;
    public int BhT9nv;
    public final gy1 HouJZE;
    public final gy1 PmLeSG;
    public int S7AthI;
    public int mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(RecipeFragment.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        GdlsZt = new ci0[]{bj1Var, new bj1(RecipeFragment.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
    }

    public RecipeFragment() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = GdlsZt;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        ck1 ck1Var = new ck1(this, 0);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(10, new t(9, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(uk1.class), new u(KLRxE3, 8), ck1Var, new u(KLRxE3, 9));
        this.HouJZE = new gy1(new ck1(this, 2));
        this.S7AthI = -1;
        this.BhT9nv = -1;
    }

    public final void Aqawi6(pk1 pk1Var) {
        e40 flOPlW = pk1Var.flOPlW();
        Set set = pk1Var.Y4dfZK;
        int i = pk1Var.YQmmye;
        boolean z = pk1Var.Jtmurk;
        bl0 bl0Var = flOPlW != null ? (bl0) hu.S7AthI(i, flOPlW.flOPlW) : null;
        LinearLayout linearLayout = cUjre7().XPjQRF;
        linearLayout.removeAllViews();
        if (bl0Var == null) {
            cUjre7().JtBRWN.setText(f44QqK(R.string.unwrap_no_step_index));
            cUjre7().CWqrlS.setText(R.string.unwrap_no_steps);
            cUjre7().hrFPdg.setText(R.string.unwrap_no_steps_hint);
            cUjre7().oIzScy.setVisibility(8);
            cUjre7().IBj4av.setVisibility(8);
            return;
        }
        List<String> list = bl0Var.oIzScy;
        int i2 = bl0Var.wbQVfV;
        cUjre7().oIzScy.setVisibility(0);
        cUjre7().IBj4av.setVisibility(0);
        int i3 = i2 + 1;
        cUjre7().JtBRWN.setText(D6ihV3(R.string.unwrap_step_number, Integer.valueOf(i3)));
        cUjre7().JtBRWN.setBackgroundResource(set.contains(Integer.valueOf(i)) ? R.drawable.bg_step_index_done : R.drawable.bg_step_index);
        cUjre7().zkaTkY.setVisibility(set.contains(Integer.valueOf(i)) ? 0 : 4);
        TextView textView = cUjre7().CWqrlS;
        Integer valueOf = Integer.valueOf(i3);
        e40 flOPlW2 = pk1Var.flOPlW();
        textView.setText(D6ihV3(R.string.unwrap_step_counter, valueOf, Integer.valueOf(flOPlW2 != null ? flOPlW2.flOPlW.size() : 0), Integer.valueOf(set.size())));
        cUjre7().hrFPdg.setText(bl0Var.flOPlW);
        cUjre7().IBj4av.setText(set.contains(Integer.valueOf(i)) ? R.string.unwrap_untick_step : R.string.unwrap_tick_step);
        cUjre7().oIzScy.setText(z ? R.string.unwrap_hide_callouts : R.string.unwrap_show_callouts);
        if (!z || list.isEmpty()) {
            linearLayout.setVisibility(8);
            return;
        }
        linearLayout.setVisibility(0);
        for (String str : list) {
            y3 FIzcol = y3.FIzcol(khf4Rv(), linearLayout);
            ((TextView) FIzcol.YQmmye).setText(str);
            View view = (View) FIzcol.XPjQRF;
            Drawable drawable = view.getContext().getDrawable(R.drawable.bg_key_dot);
            Drawable mutate = drawable != null ? drawable.mutate() : null;
            if (mutate instanceof GradientDrawable) {
                ((GradientDrawable) mutate).setColor(view.getContext().getColor(R.color.mango));
            }
            view.setBackground(mutate);
            linearLayout.addView((LinearLayout) FIzcol.oIzScy);
        }
    }

    public final void MFKG20(pk1 pk1Var) {
        b40 b40Var;
        int i;
        e40 flOPlW = pk1Var.flOPlW();
        if (flOPlW == null || (b40Var = pk1Var.oIzScy) == null) {
            return;
        }
        LinearLayout linearLayout = cUjre7().Y4dfZK;
        linearLayout.removeAllViews();
        int ordinal = b40Var.XPjQRF.ordinal();
        if (ordinal == 0) {
            i = R.color.tag_aubergine_purple;
        } else if (ordinal == 1) {
            i = R.color.tag_clay_brown;
        } else if (ordinal == 2) {
            i = R.color.tag_tomato_red;
        } else if (ordinal == 3) {
            i = R.color.tag_olive_green;
        } else {
            if (ordinal != 4) {
                j02.D6ihV3();
                return;
            }
            i = R.color.tag_feta_white;
        }
        for (String str : flOPlW.wbQVfV) {
            y3 FIzcol = y3.FIzcol(khf4Rv(), linearLayout);
            ((TextView) FIzcol.YQmmye).setText(str);
            View view = (View) FIzcol.XPjQRF;
            Drawable drawable = view.getContext().getDrawable(R.drawable.bg_key_dot);
            Drawable mutate = drawable != null ? drawable.mutate() : null;
            if (mutate instanceof GradientDrawable) {
                ((GradientDrawable) mutate).setColor(view.getContext().getColor(i));
            }
            view.setBackground(mutate);
            linearLayout.addView((LinearLayout) FIzcol.oIzScy);
        }
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = cUjre7().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    public final uk1 TyvOFV() {
        return (uk1) this.w4eZP5.getValue();
    }

    public final ec0 cUjre7() {
        return (ec0) this.HouJZE.getValue();
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        xw1 xw1Var;
        view.getClass();
        ArgbEvaluator argbEvaluator = bh1.wbQVfV;
        bh1.wbQVfV(cUjre7().flOPlW, 0.88f);
        bh1.wbQVfV(cUjre7().f44QqK, 0.88f);
        bh1.wbQVfV(cUjre7().Nk77O2, 0.88f);
        bh1.wbQVfV(cUjre7().D6ihV3, 0.88f);
        bh1.wbQVfV(cUjre7().IBj4av, 0.96f);
        bh1.wbQVfV(cUjre7().YcbaGR, 0.96f);
        bh1.wbQVfV(cUjre7().oIzScy, 0.94f);
        final int i = 0;
        cUjre7().flOPlW.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i2 = i;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i2) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i3 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i3));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i3);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i2 = 1;
        cUjre7().f44QqK.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i2;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i3 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i3));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i3);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i3 = 2;
        cUjre7().Nk77O2.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i3;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i32 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i32));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i32);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i4 = 3;
        cUjre7().D6ihV3.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i4;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i32 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i32));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i32);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i5 = 4;
        cUjre7().IBj4av.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i5;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i32 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i32));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i32);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i6 = 5;
        cUjre7().oIzScy.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i6;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i32 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i32));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i32);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        final int i7 = 6;
        cUjre7().YcbaGR.setOnClickListener(new View.OnClickListener(this) { // from class: fk1
            public final /* synthetic */ RecipeFragment oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                int i22 = i7;
                RecipeFragment recipeFragment = this.oIzScy;
                switch (i22) {
                    case 0:
                        ci0[] ci0VarArr = RecipeFragment.GdlsZt;
                        recipeFragment.lYknzc();
                        break;
                    case 1:
                        ci0[] ci0VarArr2 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV = recipeFragment.TyvOFV();
                        pk1 pk1Var = (pk1) TyvOFV.Y4dfZK.YcbaGR();
                        if (pk1Var.YQmmye > 0) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new tk1(TyvOFV, pk1Var, null, 0), 3);
                            break;
                        } else {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 1), 3);
                            break;
                        }
                    case li1.FLOAT_FIELD_NUMBER /* 2 */:
                        ci0[] ci0VarArr3 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV2 = recipeFragment.TyvOFV();
                        pk1 pk1Var2 = (pk1) TyvOFV2.Y4dfZK.YcbaGR();
                        e40 flOPlW = pk1Var2.flOPlW();
                        if (flOPlW != null) {
                            if (pk1Var2.YQmmye < flOPlW.flOPlW.size() - 1) {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new tk1(TyvOFV2, pk1Var2, null, 1), 3);
                                break;
                            } else {
                                mk0.O49KBk(km0.JtBRWN(TyvOFV2), null, new rk1(TyvOFV2, null, 2), 3);
                                break;
                            }
                        }
                        break;
                    case li1.INTEGER_FIELD_NUMBER /* 3 */:
                        ci0[] ci0VarArr4 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV3 = recipeFragment.TyvOFV();
                        e40 flOPlW2 = ((pk1) TyvOFV3.Y4dfZK.YcbaGR()).flOPlW();
                        if (flOPlW2 != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV3), null, new qk1(TyvOFV3, flOPlW2, null, 1), 3);
                            break;
                        }
                        break;
                    case li1.LONG_FIELD_NUMBER /* 4 */:
                        ci0[] ci0VarArr5 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV4 = recipeFragment.TyvOFV();
                        pk1 pk1Var3 = (pk1) TyvOFV4.Y4dfZK.YcbaGR();
                        e40 flOPlW3 = pk1Var3.flOPlW();
                        int i32 = pk1Var3.YQmmye;
                        if (flOPlW3 != null && !flOPlW3.flOPlW.isEmpty()) {
                            Set set = pk1Var3.Y4dfZK;
                            set.getClass();
                            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
                            boolean contains = linkedHashSet.contains(Integer.valueOf(i32));
                            boolean z = !contains;
                            Integer valueOf = Integer.valueOf(i32);
                            if (contains) {
                                linkedHashSet.remove(valueOf);
                            } else {
                                linkedHashSet.add(valueOf);
                            }
                            mk0.O49KBk(km0.JtBRWN(TyvOFV4), null, new to0(TyvOFV4, flOPlW3, pk1Var3, linkedHashSet, z, null), 3);
                            break;
                        }
                        break;
                    case li1.STRING_FIELD_NUMBER /* 5 */:
                        ci0[] ci0VarArr6 = RecipeFragment.GdlsZt;
                        cx1 cx1Var = recipeFragment.TyvOFV().KfVgV3;
                        Boolean valueOf2 = Boolean.valueOf(!((pk1) r10.Y4dfZK.YcbaGR()).Jtmurk);
                        cx1Var.getClass();
                        cx1Var.khf4Rv(null, valueOf2);
                        break;
                    default:
                        ci0[] ci0VarArr7 = RecipeFragment.GdlsZt;
                        uk1 TyvOFV5 = recipeFragment.TyvOFV();
                        b40 b40Var = TyvOFV5.khf4Rv;
                        if (b40Var != null) {
                            mk0.O49KBk(km0.JtBRWN(TyvOFV5), null, new g0(TyvOFV5, b40Var, null, 13), 3);
                            break;
                        }
                        break;
                }
            }
        });
        uk1 TyvOFV = TyvOFV();
        Bundle bundle = this.fmcqY6;
        int i8 = bundle != null ? bundle.getInt("dishId") : 0;
        if (TyvOFV.Z7SPLw != i8 || (xw1Var = TyvOFV.Nk77O2) == null || !xw1Var.wbQVfV()) {
            TyvOFV.Z7SPLw = i8;
            xw1 xw1Var2 = TyvOFV.Nk77O2;
            if (xw1Var2 != null) {
                xw1Var2.XPjQRF(null);
            }
            TyvOFV.Nk77O2 = mk0.O49KBk(km0.JtBRWN(TyvOFV), null, new rk1(TyvOFV, null, 0), 3);
        }
        ak1 ak1Var = TyvOFV().fmcqY6;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, RecipeFragment.class, "render", "render(Lcom/example/app/presentation/recipe/RecipeState;)V", 7)), mk0.f44QqK(IZp36m()));
        ak1 ak1Var2 = TyvOFV().Jtmurk;
        fc0 IZp36m2 = IZp36m();
        IZp36m2.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var2, IZp36m2.YQmmye), new s(this, RecipeFragment.class, "react", "react(Lcom/example/app/presentation/recipe/RecipeSignal;)V", 8)), mk0.f44QqK(IZp36m()));
    }

    public final void lYknzc() {
        mt0 D6ihV3 = as1.D6ihV3(this);
        bt0 bt0Var = D6ihV3.flOPlW;
        boolean z = false;
        if (!bt0Var.Y4dfZK.isEmpty()) {
            ht0 Y4dfZK = bt0Var.Y4dfZK();
            Y4dfZK.getClass();
            if (bt0Var.khf4Rv(Y4dfZK.oIzScy.wbQVfV, true, false) && bt0Var.flOPlW()) {
                z = true;
            }
        }
        bt0 bt0Var2 = D6ihV3.flOPlW;
        if (z) {
            return;
        }
        ht0 Y4dfZK2 = bt0Var2.Y4dfZK();
        D6ihV3.wbQVfV(R.id.dest_lanai, null, new pt0(true, false, Y4dfZK2 != null ? Y4dfZK2.oIzScy.wbQVfV : bt0Var2.fmcqY6().YcbaGR.wbQVfV, true, false, R.anim.leaf_unroll_enter, R.anim.leaf_roll_exit, -1, -1));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
