package com.example.app.presentation.grove;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.mk0;
import defpackage.vg0;
import defpackage.y10;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class IrrigationProgressView extends View {
    public static final /* synthetic */ int f44QqK = 0;
    public final int[] Jtmurk;
    public final float[] KfVgV3;
    public float Nk77O2;
    public final RectF XPjQRF;
    public LinearGradient Y4dfZK;
    public final Matrix YQmmye;
    public int YcbaGR;
    public ValueAnimator Z7SPLw;
    public ValueAnimator fiyBpU;
    public final Paint flOPlW;
    public float fmcqY6;
    public float khf4Rv;
    public final Paint oIzScy;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public IrrigationProgressView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        Paint paint = new Paint(1);
        Paint.Style style = Paint.Style.FILL;
        paint.setStyle(style);
        paint.setColor(context.getColor(R.color.leaf_tint));
        this.flOPlW = paint;
        Paint paint2 = new Paint(1);
        paint2.setStyle(style);
        this.oIzScy = paint2;
        this.XPjQRF = new RectF();
        this.YQmmye = new Matrix();
        this.fmcqY6 = -1.0f;
        this.YcbaGR = -1;
        int color = context.getColor(R.color.leaf_green);
        this.Jtmurk = new int[]{color, context.getColor(R.color.water_glimmer), color};
        this.KfVgV3 = new float[]{RecyclerView.a, 0.5f, 1.0f};
    }

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.a, 1.0f);
        ofFloat.setDuration(2600L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.addUpdateListener(new vg0(this, 0));
        ofFloat.start();
        this.fiyBpU = ofFloat;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.fiyBpU;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.fiyBpU = null;
        ValueAnimator valueAnimator2 = this.Z7SPLw;
        if (valueAnimator2 != null) {
            valueAnimator2.cancel();
        }
        this.Z7SPLw = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        Paint paint;
        canvas.getClass();
        super.onDraw(canvas);
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        float height = getHeight() / 2.0f;
        float width = getWidth();
        float height2 = getHeight();
        RectF rectF = this.XPjQRF;
        rectF.set(RecyclerView.a, RecyclerView.a, width, height2);
        int color = getContext().getColor(R.color.taro_green_deep);
        Paint paint2 = this.flOPlW;
        paint2.setColor(color);
        canvas.drawRoundRect(rectF, height, height, paint2);
        float height3 = getHeight() * 0.22f;
        rectF.set(height3, height3, getWidth() - height3, getHeight() - height3);
        paint2.setColor(getContext().getColor(R.color.sand_ground));
        canvas.drawRoundRect(rectF, height, height, paint2);
        float Y4dfZK = mk0.Y4dfZK(getWidth() * this.khf4Rv, getWidth());
        if (Y4dfZK <= height3) {
            return;
        }
        float width2 = getWidth() * 0.4f;
        float width3 = (((2.0f * width2) + getWidth()) * this.Nk77O2) + (-width2);
        float height4 = getHeight();
        int i = (int) height4;
        LinearGradient linearGradient = this.Y4dfZK;
        Paint paint3 = this.oIzScy;
        if (linearGradient != null && this.fmcqY6 == width2 && this.YcbaGR == i) {
            paint = paint3;
        } else {
            this.fmcqY6 = width2;
            this.YcbaGR = i;
            paint = paint3;
            LinearGradient linearGradient2 = new LinearGradient(RecyclerView.a, RecyclerView.a, width2, height4, this.Jtmurk, this.KfVgV3, Shader.TileMode.CLAMP);
            paint.setShader(linearGradient2);
            this.Y4dfZK = linearGradient2;
        }
        Matrix matrix = this.YQmmye;
        matrix.setTranslate(width3, RecyclerView.a);
        LinearGradient linearGradient3 = this.Y4dfZK;
        if (linearGradient3 != null) {
            linearGradient3.setLocalMatrix(matrix);
        }
        if (Y4dfZK < height3) {
            Y4dfZK = height3;
        }
        rectF.set(height3, height3, Y4dfZK, getHeight() - height3);
        canvas.drawRoundRect(rectF, height, height, paint);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public IrrigationProgressView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    public /* synthetic */ IrrigationProgressView(Context context, AttributeSet attributeSet, int i, int i2, y10 y10Var) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public IrrigationProgressView(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }
}
