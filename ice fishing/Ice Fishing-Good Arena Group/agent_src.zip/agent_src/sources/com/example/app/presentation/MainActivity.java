package com.example.app.presentation;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import defpackage.fj1;
import defpackage.g1;
import defpackage.g50;
import defpackage.h1;
import defpackage.h50;
import defpackage.i1;
import defpackage.i50;
import defpackage.j50;
import defpackage.jy1;
import defpackage.k50;
import defpackage.l50;
import defpackage.m50;
import defpackage.n50;
import defpackage.o50;
import defpackage.p50;
import defpackage.xt0;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class MainActivity extends i1 {
    public static final /* synthetic */ int IBj4av = 0;

    public MainActivity() {
        ((fj1) this.YQmmye.oIzScy).Z7SPLw("androidx:appcompat", new g1(this));
        YQmmye(new h1(this));
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x00a4, code lost:
    
        r0.run();
        r10 = getWindow();
        r10.getClass();
        r1.wbQVfV(r10);
        setRequestedOrientation(1);
        setContentView(com.general.melcan.fizoryfork.R.layout.activity_main);
        r10 = getWindow();
        getWindow().getDecorView();
        r0 = android.os.Build.VERSION.SDK_INT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00c7, code lost:
    
        if (r0 < 35) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00c9, code lost:
    
        r0 = new defpackage.p62(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00e4, code lost:
    
        r0.KUFTNX(true);
        r0.oVb4Ln(true);
        r10 = findViewById(com.general.melcan.fizoryfork.R.id.main);
        r0 = new defpackage.j02();
        r1 = defpackage.o32.wbQVfV;
        defpackage.g32.oIzScy(r10, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00fb, code lost:
    
        if (r11 != null) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00fd, code lost:
    
        r10 = new defpackage.gy();
        r11 = ((defpackage.qa0) r10.CWqrlS.oIzScy).Rq1tA3;
        r11.getClass();
        r0 = new defpackage.u4(r11);
        r0.fmcqY6(com.general.melcan.fizoryfork.R.id.fragment_container, r10, null, 2);
        r0.Jtmurk(r10);
        r0.YQmmye();
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0120, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00cf, code lost:
    
        if (r0 < 30) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00d1, code lost:
    
        r0 = new defpackage.o62(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00d7, code lost:
    
        if (r0 < 26) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00d9, code lost:
    
        r0 = new defpackage.m62(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00df, code lost:
    
        r0 = new defpackage.l62(r10);
     */
    @Override // defpackage.i1, defpackage.ov, defpackage.nv, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = 8;
        jy1 jy1Var = new jy1(new xt0(i));
        jy1 jy1Var2 = new jy1(new xt0(i));
        p50 p50Var = i50.wbQVfV;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        p50 p50Var2 = i50.wbQVfV;
        if (p50Var2 == null) {
            int i2 = Build.VERSION.SDK_INT;
            p50Var2 = i2 >= 35 ? new o50() : i2 >= 30 ? new n50() : i2 >= 29 ? new m50() : i2 >= 28 ? new l50() : i2 >= 26 ? new k50() : new j50();
            i50.wbQVfV = p50Var2;
        }
        p50 p50Var3 = p50Var2;
        g50 g50Var = new g50(p50Var3, jy1Var, jy1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i3 = 0;
        while (true) {
            if (i3 >= viewGroup.getChildCount()) {
                h50 h50Var = new h50(g50Var, viewGroup.getContext());
                h50Var.setTag(p50Var3);
                h50Var.setVisibility(8);
                h50Var.setWillNotDraw(true);
                viewGroup.addView(h50Var);
                break;
            }
            int i4 = i3 + 1;
            View childAt = viewGroup.getChildAt(i3);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof p50) {
                break;
            } else {
                i3 = i4;
            }
        }
    }
}
