package com.example.app.data.datasource.room;

import com.example.app.data.datasource.room.TerraceDatabase_Impl;
import defpackage.em1;
import defpackage.gy1;
import defpackage.ii0;
import defpackage.rc0;
import defpackage.rt;
import defpackage.sg0;
import defpackage.uy1;
import defpackage.v50;
import defpackage.w60;
import defpackage.we0;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class TerraceDatabase_Impl extends TerraceDatabase {
    public final gy1 Nk77O2;
    public final gy1 khf4Rv;

    public TerraceDatabase_Impl() {
        final int i = 0;
        this.khf4Rv = new gy1(new rc0(this) { // from class: ty1
            public final /* synthetic */ TerraceDatabase_Impl oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // defpackage.rc0
            public final Object wbQVfV() {
                int i2 = i;
                TerraceDatabase_Impl terraceDatabase_Impl = this.oIzScy;
                switch (i2) {
                    case 0:
                        return new ii0(terraceDatabase_Impl);
                    default:
                        return new we0(terraceDatabase_Impl);
                }
            }
        });
        final int i2 = 1;
        this.Nk77O2 = new gy1(new rc0(this) { // from class: ty1
            public final /* synthetic */ TerraceDatabase_Impl oIzScy;

            {
                this.oIzScy = this;
            }

            @Override // defpackage.rc0
            public final Object wbQVfV() {
                int i22 = i2;
                TerraceDatabase_Impl terraceDatabase_Impl = this.oIzScy;
                switch (i22) {
                    case 0:
                        return new ii0(terraceDatabase_Impl);
                    default:
                        return new we0(terraceDatabase_Impl);
                }
            }
        });
    }

    @Override // com.example.app.data.datasource.room.TerraceDatabase
    public final ii0 Nk77O2() {
        return (ii0) this.khf4Rv.getValue();
    }

    @Override // defpackage.zr1
    public final LinkedHashMap Y4dfZK() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        rt wbQVfV = em1.wbQVfV(ii0.class);
        w60 w60Var = w60.flOPlW;
        linkedHashMap.put(wbQVfV, w60Var);
        linkedHashMap.put(em1.wbQVfV(we0.class), w60Var);
        return linkedHashMap;
    }

    @Override // defpackage.zr1
    public final Set YQmmye() {
        return new LinkedHashSet();
    }

    @Override // defpackage.zr1
    public final sg0 flOPlW() {
        return new sg0(this, new LinkedHashMap(), new LinkedHashMap(), "keepsakes", "guide_progress");
    }

    @Override // com.example.app.data.datasource.room.TerraceDatabase
    public final we0 khf4Rv() {
        return (we0) this.Nk77O2.getValue();
    }

    @Override // defpackage.zr1
    public final v50 oIzScy() {
        return new uy1(this);
    }

    @Override // defpackage.zr1
    public final List wbQVfV(LinkedHashMap linkedHashMap) {
        return new ArrayList();
    }
}
