package com.example.app.presentation.patio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.general.melcan.fizoryfork.R;
import defpackage.r0;
import defpackage.y10;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class PatioShimmerFrame extends FrameLayout {
    public static final /* synthetic */ int Y4dfZK = 0;
    public ValueAnimator XPjQRF;
    public final int YQmmye;
    public final Paint flOPlW;
    public float oIzScy;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PatioShimmerFrame(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        context.getClass();
        this.flOPlW = new Paint(1);
        this.YQmmye = context.getColor(R.color.skeleton_sheen);
        setWillNotDraw(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        canvas.getClass();
        super.dispatchDraw(canvas);
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        float width = getWidth() * 0.45f;
        float width2 = (((2.0f * width) + getWidth()) * this.oIzScy) + (-width);
        LinearGradient linearGradient = new LinearGradient(width2, RecyclerView.a, width2 + width, getHeight(), new int[]{0, this.YQmmye, 0}, new float[]{RecyclerView.a, 0.5f, 1.0f}, Shader.TileMode.CLAMP);
        Paint paint = this.flOPlW;
        paint.setShader(linearGradient);
        canvas.drawRect(RecyclerView.a, RecyclerView.a, getWidth(), getHeight(), paint);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.a, 1.0f);
        ofFloat.setDuration(1500L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.addUpdateListener(new r0(3, this));
        ofFloat.start();
        this.XPjQRF = ofFloat;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        ValueAnimator valueAnimator = this.XPjQRF;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.XPjQRF = null;
        super.onDetachedFromWindow();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public PatioShimmerFrame(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        context.getClass();
    }

    public /* synthetic */ PatioShimmerFrame(Context context, AttributeSet attributeSet, int i, int i2, y10 y10Var) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public PatioShimmerFrame(Context context) {
        this(context, null, 0, 6, null);
        context.getClass();
    }
}
