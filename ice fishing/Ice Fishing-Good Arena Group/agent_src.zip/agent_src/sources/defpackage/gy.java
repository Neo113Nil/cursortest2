package defpackage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app.presentation.courtyard.PatioBarView;
import com.general.melcan.fizoryfork.R;
import java.util.List;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class gy extends oa0 implements xy {
    public static final /* synthetic */ ci0[] JAoXHU;
    public static final int[] UfzG8s;
    public boolean BhT9nv;
    public final fy GdlsZt;
    public final gy1 HouJZE;
    public final gy1 PmLeSG;
    public mt0 S7AthI;
    public y3 mkqF8w;
    public final gy1 pMXSGT;
    public final g00 w4eZP5;

    /* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
    public static final class wbQVfV extends c12<x32> {
    }

    static {
        bj1 bj1Var = new bj1(gy.class, "di", "getDi()Lorg/kodein/di/DI;", 0);
        em1.wbQVfV.getClass();
        JAoXHU = new ci0[]{bj1Var, new bj1(gy.class, "factory", "getFactory()Landroidx/lifecycle/ViewModelProvider$Factory;", 0)};
        UfzG8s = new int[]{R.id.dest_lanai, R.id.dest_unwrap, R.id.dest_calabash, R.id.dest_patch_flow, R.id.dest_landing};
    }

    public gy() {
        n41 Jtmurk = b12.Jtmurk(this);
        ci0[] ci0VarArr = JAoXHU;
        ci0 ci0Var = ci0VarArr[0];
        this.pMXSGT = Jtmurk.Rq1tA3(this);
        ph0 flOPlW = g12.flOPlW(new wbQVfV().wbQVfV);
        flOPlW.getClass();
        this.PmLeSG = as1.wbQVfV(this, new be0(flOPlW, x32.class)).CfnFHk(this, ci0VarArr[1]);
        ey eyVar = new ey(this, 0);
        si0 KLRxE3 = w10.KLRxE3(ui0.oIzScy, new t(3, new t(2, this)));
        this.w4eZP5 = new g00(em1.wbQVfV(jy.class), new u(KLRxE3, 2), eyVar, new u(KLRxE3, 3));
        this.HouJZE = new gy1(new ey(this, 1));
        this.GdlsZt = new fy(this);
    }

    public final void Aqawi6(String str) {
        y3 y3Var = this.mkqF8w;
        if (y3Var != null) {
            ((TextView) y3Var.XPjQRF).setText(str);
            View view = (View) y3Var.oIzScy;
            ch1 ch1Var = (ch1) y3Var.YQmmye;
            view.removeCallbacks(ch1Var);
            view.animate().cancel();
            if (view.getVisibility() != 0) {
                view.setAlpha(RecyclerView.a);
                float height = view.getHeight();
                if (height < 1.0f) {
                    height = 1.0f;
                }
                view.setTranslationY(height);
                view.setVisibility(0);
            }
            view.animate().alpha(1.0f).translationY(RecyclerView.a).setDuration(280L).setInterpolator(new OvershootInterpolator(1.1f)).start();
            view.postDelayed(ch1Var, 2200L);
        }
    }

    @Override // defpackage.oa0
    public final void IBj4av() {
        mt0 mt0Var = this.S7AthI;
        if (mt0Var != null) {
            fy fyVar = this.GdlsZt;
            fyVar.getClass();
            bt0 bt0Var = mt0Var.flOPlW;
            bt0Var.getClass();
            bt0Var.f44QqK.remove(fyVar);
        }
        this.S7AthI = null;
        this.BhT9nv = false;
        y3 y3Var = this.mkqF8w;
        if (y3Var != null) {
            View view = (View) y3Var.oIzScy;
            view.removeCallbacks((ch1) y3Var.YQmmye);
            view.animate().cancel();
        }
        this.mkqF8w = null;
        this.i37xLF = true;
    }

    public final yb0 MFKG20() {
        return (yb0) this.HouJZE.getValue();
    }

    @Override // defpackage.oa0
    public final View Rq1tA3(LayoutInflater layoutInflater) {
        layoutInflater.getClass();
        ConstraintLayout constraintLayout = MFKG20().wbQVfV;
        constraintLayout.getClass();
        return constraintLayout;
    }

    @Override // defpackage.oa0
    public final void ksweok(View view) {
        view.getClass();
        this.mkqF8w = new y3((LinearLayout) MFKG20().YQmmye.flOPlW, (TextView) MFKG20().YQmmye.oIzScy);
        PatioBarView patioBarView = MFKG20().oIzScy;
        List Ih6erT = iu.Ih6erT(f44QqK(R.string.section_lanai), f44QqK(R.string.section_unwrap), f44QqK(R.string.section_calabash), f44QqK(R.string.section_patch_flow), f44QqK(R.string.section_landing));
        patioBarView.IZp36m = Ih6erT;
        int size = Ih6erT.size() - 1;
        if (size < 0) {
            size = 0;
        }
        patioBarView.xzMlIC = mk0.fmcqY6(0, size);
        int size2 = Ih6erT.size();
        float[] fArr = new float[size2];
        int i = 0;
        while (i < size2) {
            fArr[i] = i == patioBarView.xzMlIC ? 1.0f : RecyclerView.a;
            i++;
        }
        patioBarView.XXBzWV = fArr;
        patioBarView.setContentDescription((CharSequence) hu.S7AthI(patioBarView.xzMlIC, Ih6erT));
        patioBarView.invalidate();
        MFKG20().oIzScy.setOnLeafSelected(new q(1, this, gy.class, "openSection", "openSection(I)V", 0, 0, 4));
        g00 g00Var = MFKG20().XPjQRF;
        String f44QqK = f44QqK(R.string.shell_error_hint);
        f44QqK.getClass();
        int i2 = 2;
        ey eyVar = new ey(this, i2);
        TextView textView = (TextView) g00Var.oIzScy;
        ((ImageView) g00Var.Y4dfZK).setImageResource(R.drawable.ic_alert_leaf);
        ((TextView) g00Var.XPjQRF).setText(R.string.shell_error_headline);
        ((TextView) g00Var.YQmmye).setText(f44QqK);
        textView.setVisibility(0);
        textView.setText(R.string.action_try_again);
        textView.setOnClickListener(new ge0(i2, eyVar));
        bh1.wbQVfV(textView, 0.96f);
        ak1 ak1Var = ((jy) this.w4eZP5.getValue()).XPjQRF;
        fc0 IZp36m = IZp36m();
        IZp36m.oIzScy();
        as1.zkaTkY(new r2(22, km0.fiyBpU(ak1Var, IZp36m.YQmmye), new s(this, gy.class, "render", "render(Lcom/example/app/presentation/courtyard/CourtyardState;)V", 2)), mk0.f44QqK(IZp36m()));
    }

    @Override // defpackage.xy
    public final yz oIzScy() {
        return ex.wbQVfV;
    }

    @Override // defpackage.xy
    public final wy wbQVfV() {
        return (wy) this.pMXSGT.getValue();
    }
}
