package defpackage;

import android.content.Context;
import java.util.List;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class yy1 {
    public final ti1 flOPlW;
    public final n41 wbQVfV;
    public static final ci1 oIzScy = new ci1("landing_card");
    public static final ci1 XPjQRF = new ci1("landing_finished");
    public static final ci1 YQmmye = new ci1("cook_groups");
    public static final ci1 Y4dfZK = new ci1("guide_pace");
    public static final ci1 fmcqY6 = new ci1("board_index");
    public static final ci1 YcbaGR = new ci1("best_turns");

    public yy1(Context context) {
        n41 n41Var;
        Context applicationContext = context.getApplicationContext();
        applicationContext.getClass();
        bi1 bi1Var = zy1.flOPlW;
        ci0 ci0Var = zy1.wbQVfV[0];
        bi1Var.getClass();
        ci0Var.getClass();
        n41 n41Var2 = bi1Var.XPjQRF;
        int i = 3;
        jx jxVar = null;
        if (n41Var2 == null) {
            synchronized (bi1Var.oIzScy) {
                try {
                    if (bi1Var.XPjQRF == null) {
                        Context applicationContext2 = applicationContext.getApplicationContext();
                        cd0 cd0Var = bi1Var.wbQVfV;
                        applicationContext2.getClass();
                        List list = (List) cd0Var.YcbaGR(applicationContext2);
                        xx xxVar = bi1Var.flOPlW;
                        p pVar = new p(i, applicationContext2, bi1Var);
                        list.getClass();
                        s10 s10Var = new s10(new i80(new zt(11, pVar)), a72.MNdnlq(new g0(list, jxVar, 7)), new yv1(15), xxVar);
                        int i2 = 29;
                        bi1Var.XPjQRF = new n41(i2, new n41(i2, s10Var));
                    }
                    n41Var = bi1Var.XPjQRF;
                    n41Var.getClass();
                } catch (Throwable th) {
                    throw th;
                }
            }
            n41Var2 = n41Var;
        }
        this.wbQVfV = n41Var2;
        this.flOPlW = new ti1(6, new r2(19, ((w00) n41Var2.oIzScy).FIzcol(), new vy1(3, null)));
    }
}
