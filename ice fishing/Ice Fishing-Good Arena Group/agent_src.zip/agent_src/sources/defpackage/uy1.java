package defpackage;

import com.example.app.data.datasource.room.TerraceDatabase_Impl;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.concurrent.locks.ReentrantLock;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final class uy1 extends v50 {
    public final /* synthetic */ TerraceDatabase_Impl XPjQRF;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public uy1(TerraceDatabase_Impl terraceDatabase_Impl) {
        super(1, "ec94151b209cd4dbbd41bf5a5b9dd28d", "e57d32ac7fe0aa26efbab87ea1d36ab6");
        this.XPjQRF = terraceDatabase_Impl;
    }

    @Override // defpackage.v50
    public final void CWqrlS(ks1 ks1Var) {
        ks1Var.getClass();
        wj0 IZp36m = a72.IZp36m();
        ms1 JtBRWN = ks1Var.JtBRWN("SELECT name FROM sqlite_master WHERE type = 'trigger'");
        while (JtBRWN.XXBzWV()) {
            try {
                IZp36m.add(JtBRWN.YQmmye(0));
            } finally {
            }
        }
        a72.f44QqK(JtBRWN, null);
        ListIterator listIterator = a72.Jtmurk(IZp36m).listIterator(0);
        while (true) {
            uj0 uj0Var = (uj0) listIterator;
            if (!uj0Var.hasNext()) {
                return;
            }
            String str = (String) uj0Var.next();
            if (mx1.TyvOFV(str, "room_fts_content_sync_")) {
                a72.zkaTkY(ks1Var, "DROP TRIGGER IF EXISTS ".concat(str));
            }
        }
    }

    @Override // defpackage.v50
    public final void FIzcol(ks1 ks1Var) {
        ks1Var.getClass();
        sg0 XPjQRF = this.XPjQRF.XPjQRF();
        u02 u02Var = XPjQRF.flOPlW;
        u02Var.getClass();
        ms1 JtBRWN = ks1Var.JtBRWN("PRAGMA query_only");
        try {
            JtBRWN.XXBzWV();
            boolean IZp36m = JtBRWN.IZp36m();
            a72.f44QqK(JtBRWN, null);
            if (!IZp36m) {
                a72.zkaTkY(ks1Var, "PRAGMA temp_store = MEMORY");
                a72.zkaTkY(ks1Var, "PRAGMA recursive_triggers = 1");
                a72.zkaTkY(ks1Var, "DROP TABLE IF EXISTS room_table_modification_log");
                if (u02Var.XPjQRF) {
                    a72.zkaTkY(ks1Var, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
                } else {
                    a72.zkaTkY(ks1Var, mx1.cUjre7("CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)", "TEMP", ""));
                }
                v41 v41Var = u02Var.YcbaGR;
                ReentrantLock reentrantLock = v41Var.wbQVfV;
                reentrantLock.lock();
                try {
                    v41Var.XPjQRF = true;
                } finally {
                    reentrantLock.unlock();
                }
            }
            synchronized (XPjQRF.fmcqY6) {
            }
        } finally {
        }
    }

    @Override // defpackage.v50
    public final cs1 JtBRWN(ks1 ks1Var) {
        ks1Var.getClass();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put("id", new ly1("id", "INTEGER", true, 1, null, 1));
        linkedHashMap.put("kind", new ly1("kind", "TEXT", true, 0, null, 1));
        linkedHashMap.put("dish_id", new ly1("dish_id", "INTEGER", true, 0, null, 1));
        linkedHashMap.put("title", new ly1("title", "TEXT", true, 0, null, 1));
        linkedHashMap.put("note", new ly1("note", "TEXT", true, 0, null, 1));
        linkedHashMap.put("position", new ly1("position", "INTEGER", true, 0, null, 1));
        linkedHashMap.put("archived", new ly1("archived", "INTEGER", true, 0, null, 1));
        linkedHashMap.put("saved_at", new ly1("saved_at", "INTEGER", true, 0, null, 1));
        linkedHashMap.put("grid_size", new ly1("grid_size", "INTEGER", true, 0, null, 1));
        linkedHashMap.put("turn_count", new ly1("turn_count", "INTEGER", true, 0, null, 1));
        oy1 oy1Var = new oy1("keepsakes", linkedHashMap, new LinkedHashSet(), new LinkedHashSet());
        oy1 ksweok = w10.ksweok(ks1Var, "keepsakes");
        if (!oy1Var.equals(ksweok)) {
            return new cs1("keepsakes(com.example.app.data.datasource.room.KeepsakeEntity).\n Expected:\n" + oy1Var + "\n Found:\n" + ksweok, false);
        }
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        linkedHashMap2.put("dish_id", new ly1("dish_id", "INTEGER", true, 1, null, 1));
        linkedHashMap2.put("variant_id", new ly1("variant_id", "TEXT", true, 0, null, 1));
        linkedHashMap2.put("current_step", new ly1("current_step", "INTEGER", true, 0, null, 1));
        linkedHashMap2.put("done_steps", new ly1("done_steps", "TEXT", true, 0, null, 1));
        oy1 oy1Var2 = new oy1("guide_progress", linkedHashMap2, new LinkedHashSet(), new LinkedHashSet());
        oy1 ksweok2 = w10.ksweok(ks1Var, "guide_progress");
        if (oy1Var2.equals(ksweok2)) {
            return new cs1(null, true);
        }
        return new cs1("guide_progress(com.example.app.data.datasource.room.GuideProgressEntity).\n Expected:\n" + oy1Var2 + "\n Found:\n" + ksweok2, false);
    }

    @Override // defpackage.v50
    public final void XXBzWV(ks1 ks1Var) {
        ks1Var.getClass();
    }

    @Override // defpackage.v50
    public final void oIzScy(ks1 ks1Var) {
        ks1Var.getClass();
        a72.zkaTkY(ks1Var, "DROP TABLE IF EXISTS `keepsakes`");
        a72.zkaTkY(ks1Var, "DROP TABLE IF EXISTS `guide_progress`");
    }

    @Override // defpackage.v50
    public final void wbQVfV(ks1 ks1Var) {
        ks1Var.getClass();
        a72.zkaTkY(ks1Var, "CREATE TABLE IF NOT EXISTS `keepsakes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `dish_id` INTEGER NOT NULL, `title` TEXT NOT NULL, `note` TEXT NOT NULL, `position` INTEGER NOT NULL, `archived` INTEGER NOT NULL, `saved_at` INTEGER NOT NULL, `grid_size` INTEGER NOT NULL, `turn_count` INTEGER NOT NULL)");
        a72.zkaTkY(ks1Var, "CREATE TABLE IF NOT EXISTS `guide_progress` (`dish_id` INTEGER NOT NULL, `variant_id` TEXT NOT NULL, `current_step` INTEGER NOT NULL, `done_steps` TEXT NOT NULL, PRIMARY KEY(`dish_id`))");
        a72.zkaTkY(ks1Var, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        a72.zkaTkY(ks1Var, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'ec94151b209cd4dbbd41bf5a5b9dd28d')");
    }

    @Override // defpackage.v50
    public final void xzMlIC(ks1 ks1Var) {
        ks1Var.getClass();
    }
}
