package defpackage;

import android.content.Context;
import android.content.ContextWrapper;
import com.example.app.presentation.agora.AgoraFragment;
import com.example.app.presentation.welcome.WelcomeFragment;
import java.io.File;
import java.util.ArrayList;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final /* synthetic */ class p implements rc0 {
    public final /* synthetic */ Object XPjQRF;
    public final /* synthetic */ int flOPlW;
    public final /* synthetic */ Object oIzScy;

    public /* synthetic */ p(ws0 ws0Var, ss0 ss0Var, boolean z) {
        this.flOPlW = 2;
        this.oIzScy = ws0Var;
        this.XPjQRF = ss0Var;
    }

    @Override // defpackage.rc0
    public final Object wbQVfV() {
        switch (this.flOPlW) {
            case 0:
                f0 f0Var = (f0) this.oIzScy;
                AgoraFragment agoraFragment = (AgoraFragment) this.XPjQRF;
                ci0[] ci0VarArr = AgoraFragment.UfzG8s;
                hh1 hh1Var = f0Var.XPjQRF;
                if (hh1Var != null) {
                    agoraFragment.Aqawi6().YQmmye(hh1Var);
                }
                return v12.wbQVfV;
            case 1:
                oa0 oa0Var = (oa0) this.oIzScy;
                i1 ErNdWP = ((oa0) ((zt) ((n41) this.XPjQRF).oIzScy).oIzScy).ErNdWP();
                Object obj = ErNdWP;
                while (obj != null) {
                    if (!obj.equals(oa0Var) && (obj instanceof xy)) {
                        return ((xy) obj).wbQVfV();
                    }
                    obj = obj instanceof ContextWrapper ? ((ContextWrapper) obj).getBaseContext() : null;
                }
                Object applicationContext = ErNdWP.getApplicationContext();
                xy xyVar = applicationContext instanceof xy ? (xy) applicationContext : null;
                if (xyVar != null) {
                    return xyVar.wbQVfV();
                }
                j02.YcbaGR("Trying to find closest DI, but no DI container was found at all. Your Application should be DIAware.");
                return null;
            case li1.FLOAT_FIELD_NUMBER /* 2 */:
                ws0 ws0Var = (ws0) this.oIzScy;
                ss0 ss0Var = (ss0) this.XPjQRF;
                synchronized (ws0Var.wbQVfV) {
                    try {
                        cx1 cx1Var = ws0Var.flOPlW;
                        Iterable iterable = (Iterable) cx1Var.YcbaGR();
                        ArrayList arrayList = new ArrayList();
                        for (Object obj2 : iterable) {
                            if (ng0.YQmmye((ss0) obj2, ss0Var)) {
                                cx1Var.khf4Rv(null, arrayList);
                            } else {
                                arrayList.add(obj2);
                            }
                        }
                        cx1Var.khf4Rv(null, arrayList);
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                return v12.wbQVfV;
            case li1.INTEGER_FIELD_NUMBER /* 3 */:
                Context context = (Context) this.oIzScy;
                ((bi1) this.XPjQRF).getClass();
                return new File(context.getApplicationContext().getFilesDir(), "datastore/".concat("terrace_table".concat(".preferences_pb")));
            default:
                WelcomeFragment welcomeFragment = (WelcomeFragment) this.oIzScy;
                v42 v42Var = (v42) this.XPjQRF;
                ci0[] ci0VarArr2 = WelcomeFragment.BhT9nv;
                welcomeFragment.MFKG20(v42Var);
                return v12.wbQVfV;
        }
    }

    public /* synthetic */ p(int i, Object obj, Object obj2) {
        this.flOPlW = i;
        this.oIzScy = obj;
        this.XPjQRF = obj2;
    }
}
