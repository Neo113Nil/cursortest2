package defpackage;

import android.app.ActivityManager;
import android.content.Context;
import com.example.app.data.datasource.room.TerraceDatabase;
import com.general.melcan.fizoryfork.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

/* compiled from: r8-map-id-1a31633f3bc287eb500cb8a8ba75ded61998e51973666030a06de21e62c8b0f9 */
/* loaded from: classes.dex */
public final /* synthetic */ class m00 implements cd0 {
    public final /* synthetic */ int flOPlW;
    public final /* synthetic */ Context oIzScy;

    public /* synthetic */ m00(Context context, int i) {
        this.flOPlW = i;
        this.oIzScy = context;
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:?, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x030c, code lost:
    
        defpackage.j02.FIzcol("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.");
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:120:0x037b A[LOOP:5: B:108:0x0351->B:120:0x037b, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:121:0x038b A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:151:0x0437  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0456  */
    /* JADX WARN: Type inference failed for: r11v8, types: [java.util.List] */
    @Override // defpackage.cd0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object YcbaGR(Object obj) {
        String str;
        v50 v50Var;
        int i;
        Object bwVar;
        f30 f30Var;
        int i2 = this.flOPlW;
        int i3 = 8;
        int i4 = 2;
        int i5 = 1;
        Context context = this.oIzScy;
        zx1 zx1Var = null;
        switch (i2) {
            case 0:
                cz czVar = (cz) obj;
                czVar.getClass();
                m00 m00Var = new m00(context, i5);
                n41 n41Var = new n41(0);
                mh0 mh0Var = czVar.Y4dfZK;
                ph0 flOPlW = g12.flOPlW(new n00().wbQVfV);
                flOPlW.getClass();
                czVar.wbQVfV(new xv1(n41Var, mh0Var, new be0(flOPlW, TerraceDatabase.class), m00Var), null);
                m00 m00Var2 = new m00(context, i4);
                n41 n41Var2 = new n41(0);
                ph0 flOPlW2 = g12.flOPlW(new o00().wbQVfV);
                flOPlW2.getClass();
                czVar.wbQVfV(new xv1(n41Var2, mh0Var, new be0(flOPlW2, yy1.class), m00Var2), null);
                uQUIhG uquihg = new uQUIhG(i3);
                n41 n41Var3 = new n41(0);
                ph0 flOPlW3 = g12.flOPlW(new p00().wbQVfV);
                flOPlW3.getClass();
                czVar.wbQVfV(new xv1(n41Var3, mh0Var, new be0(flOPlW3, ws.class), uquihg), null);
                uQUIhG uquihg2 = new uQUIhG(9);
                n41 n41Var4 = new n41(0);
                ph0 flOPlW4 = g12.flOPlW(new q00().wbQVfV);
                flOPlW4.getClass();
                czVar.wbQVfV(new xv1(n41Var4, mh0Var, new be0(flOPlW4, oi0.class), uquihg2), null);
                uQUIhG uquihg3 = new uQUIhG(10);
                n41 n41Var5 = new n41(0);
                ph0 flOPlW5 = g12.flOPlW(new r00().wbQVfV);
                flOPlW5.getClass();
                czVar.wbQVfV(new xv1(n41Var5, mh0Var, new be0(flOPlW5, af0.class), uquihg3), null);
                uQUIhG uquihg4 = new uQUIhG(11);
                n41 n41Var6 = new n41(0);
                ph0 flOPlW6 = g12.flOPlW(new s00().wbQVfV);
                flOPlW6.getClass();
                czVar.wbQVfV(new xv1(n41Var6, mh0Var, new be0(flOPlW6, az1.class), uquihg4), null);
                return v12.wbQVfV;
            case 1:
                ((l41) obj).getClass();
                Context applicationContext = context.getApplicationContext();
                applicationContext.getClass();
                if (mx1.jX7jAP("lanai_calabash.db")) {
                    j02.FIzcol("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
                    return null;
                }
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                ag0 ag0Var = new ag0(2);
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                LinkedHashSet linkedHashSet2 = new LinkedHashSet();
                ArrayList arrayList3 = new ArrayList();
                rt wbQVfV = em1.wbQVfV(TerraceDatabase.class);
                b4 b4Var = c4.xzMlIC;
                if (!linkedHashSet2.isEmpty()) {
                    Iterator it = linkedHashSet2.iterator();
                    while (it.hasNext()) {
                        int intValue = ((Number) it.next()).intValue();
                        if (linkedHashSet.contains(Integer.valueOf(intValue))) {
                            j02.oIzScy(dw1.oIzScy(intValue, "Inconsistency detected. A Migration was supplied to addMigration() that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(). Start version is: "));
                            return null;
                        }
                    }
                }
                yv1 yv1Var = new yv1(13);
                Object systemService = applicationContext.getSystemService("activity");
                ActivityManager activityManager = systemService instanceof ActivityManager ? (ActivityManager) systemService : null;
                xr1 xr1Var = xr1.oIzScy;
                u10 u10Var = new u10(applicationContext, "lanai_calabash.db", yv1Var, ag0Var, arrayList, false, (activityManager == null || activityManager.isLowRamDevice()) ? xr1.flOPlW : xr1Var, b4Var, b4Var, null, true, false, linkedHashSet, null, null, null, arrayList2, arrayList3, false, null, null);
                Class wbQVfV2 = wbQVfV.wbQVfV();
                wbQVfV2.getClass();
                Package r0 = wbQVfV2.getPackage();
                if (r0 == null || (str = r0.getName()) == null) {
                    str = "";
                }
                String canonicalName = wbQVfV2.getCanonicalName();
                canonicalName.getClass();
                if (str.length() != 0) {
                    canonicalName = canonicalName.substring(str.length() + 1);
                }
                String replace = canonicalName.replace('.', '_');
                replace.getClass();
                String concat = replace.concat("_Impl");
                try {
                    Class<?> cls = Class.forName(str.length() == 0 ? concat : str + '.' + concat, true, wbQVfV2.getClassLoader());
                    cls.getClass();
                    zr1 zr1Var = (zr1) cls.getDeclaredConstructor(null).newInstance(null);
                    zr1Var.getClass();
                    zr1Var.KfVgV3 = true;
                    try {
                        v50Var = zr1Var.oIzScy();
                        v50Var.getClass();
                    } catch (t41 unused) {
                        v50Var = null;
                    }
                    w60 w60Var = w60.flOPlW;
                    ?? r11 = u10Var.YQmmye;
                    if (v50Var == null) {
                        new xt0(zr1Var);
                        new yr1(2, zr1Var, as1.class, "compatTransactionCoroutineExecute", "compatTransactionCoroutineExecute(Landroidx/room/RoomDatabase;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 1, 0, 0);
                        f30 f30Var2 = new f30();
                        f30Var2.oIzScy = u10Var;
                        f30Var2.XPjQRF = new vr1(-1, "", "");
                        f30Var2.YQmmye = r11 == 0 ? w60Var : r11;
                        fmcqY6 fmcqy6 = new fmcqY6(i3, f30Var2);
                        if (r11 != 0) {
                            w60Var = r11;
                        }
                        hu.AeIGoK(w60Var, new wr1(fmcqy6));
                        u10Var.XPjQRF.getClass();
                        throw new t41();
                    }
                    yr1 yr1Var = new yr1(2, zr1Var, as1.class, "compatTransactionCoroutineExecute", "compatTransactionCoroutineExecute(Landroidx/room/RoomDatabase;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 1, 0, 1);
                    f30 f30Var3 = new f30();
                    f30Var3.oIzScy = u10Var;
                    f30Var3.XPjQRF = v50Var;
                    if (r11 != 0) {
                        w60Var = r11;
                    }
                    f30Var3.YQmmye = w60Var;
                    xr1 xr1Var2 = u10Var.Y4dfZK;
                    ls1 ls1Var = u10Var.f44QqK;
                    String str2 = u10Var.flOPlW;
                    if (ls1Var != null) {
                        f30Var3.fmcqY6 = null;
                        if (ls1Var.Y4dfZK()) {
                            bwVar = new mg1(new r2(f30Var3, ls1Var), str2 != null ? str2 : ":memory:", yr1Var);
                        } else if (str2 == null) {
                            bwVar = new bw(new r2(f30Var3, ls1Var));
                        } else {
                            r2 r2Var = new r2(f30Var3, ls1Var);
                            int ordinal = xr1Var2.ordinal();
                            if (ordinal == 1) {
                                i = 1;
                            } else {
                                if (ordinal != 2) {
                                    throw new IllegalStateException(("Can't get max number of reader for journal mode '" + xr1Var2 + '\'').toString());
                                }
                                i = 4;
                            }
                            int ordinal2 = xr1Var2.ordinal();
                            if (ordinal2 != 1 && ordinal2 != 2) {
                                throw new IllegalStateException(("Can't get max number of writers for journal mode '" + xr1Var2 + '\'').toString());
                            }
                            bwVar = new bw(r2Var, str2, i);
                        }
                        f30Var3.Y4dfZK = bwVar;
                    } else {
                        if (u10Var.oIzScy == null) {
                            j02.FIzcol("SQLiteManager was constructed with both null driver and open helper factory!");
                            throw null;
                        }
                        nc0 nc0Var = new nc0(u10Var.wbQVfV, str2, new ao0(f30Var3, v50Var.wbQVfV));
                        f30Var3.fmcqY6 = nc0Var;
                        f30Var3.Y4dfZK = new mg1(new ti1(nc0Var), str2 != null ? str2 : ":memory:", yr1Var);
                    }
                    boolean z = xr1Var2 == xr1Var;
                    zx1 zx1Var2 = (zx1) f30Var3.fmcqY6;
                    if (zx1Var2 != null) {
                        zx1Var2.setWriteAheadLoggingEnabled(z);
                    }
                    zr1Var.YQmmye = f30Var3;
                    zr1Var.Y4dfZK = zr1Var.flOPlW();
                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                    Set<rt> YQmmye = zr1Var.YQmmye();
                    List list = u10Var.Z7SPLw;
                    int size = list.size();
                    boolean[] zArr = new boolean[size];
                    for (rt rtVar : YQmmye) {
                        int size2 = list.size() - 1;
                        if (size2 >= 0) {
                            while (true) {
                                int i6 = size2 - 1;
                                if (rtVar.XPjQRF(list.get(size2))) {
                                    zArr[size2] = true;
                                } else if (i6 >= 0) {
                                    size2 = i6;
                                }
                            }
                        }
                        size2 = -1;
                        if (size2 < 0) {
                            j02.Y4dfZK(rtVar.flOPlW(), ") is missing in the database configuration.", "A required auto migration spec (");
                            return null;
                        }
                        linkedHashMap.put(rtVar, list.get(size2));
                    }
                    int size3 = list.size() - 1;
                    if (size3 >= 0) {
                        while (true) {
                            int i7 = size3 - 1;
                            if (size3 < size && zArr[size3]) {
                                if (i7 >= 0) {
                                    size3 = i7;
                                }
                            }
                        }
                    }
                    Iterator it2 = zr1Var.wbQVfV(linkedHashMap).iterator();
                    if (it2.hasNext()) {
                        it2.next().getClass();
                        j02.wbQVfV();
                        return null;
                    }
                    LinkedHashMap Y4dfZK = zr1Var.Y4dfZK();
                    List list2 = u10Var.Nk77O2;
                    boolean[] zArr2 = new boolean[list2.size()];
                    for (Map.Entry entry : Y4dfZK.entrySet()) {
                        rt rtVar2 = (rt) entry.getKey();
                        for (rt rtVar3 : (List) entry.getValue()) {
                            int size4 = list2.size() - 1;
                            if (size4 >= 0) {
                                while (true) {
                                    int i8 = size4 - 1;
                                    if (rtVar3.XPjQRF(list2.get(size4))) {
                                        zArr2[size4] = true;
                                    } else if (i8 >= 0) {
                                        size4 = i8;
                                    }
                                }
                                if (size4 >= 0) {
                                    j02.CWqrlS("A required type converter (", rtVar3.flOPlW(), ") for ", rtVar2.flOPlW(), " is missing in the database configuration.");
                                    return null;
                                }
                                Object obj2 = list2.get(size4);
                                rtVar3.getClass();
                                obj2.getClass();
                                zr1Var.Jtmurk.put(rtVar3, obj2);
                            }
                            size4 = -1;
                            if (size4 >= 0) {
                            }
                        }
                    }
                    int size5 = list2.size() - 1;
                    if (size5 >= 0) {
                        while (true) {
                            int i9 = size5 - 1;
                            if (!zArr2[size5]) {
                                throw new IllegalArgumentException("Unexpected type converter " + list2.get(size5) + ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                            }
                            if (i9 >= 0) {
                                size5 = i9;
                            }
                        }
                    }
                    zr1Var.oIzScy = u10Var.fmcqY6;
                    zr1Var.XPjQRF = new s1(u10Var.YcbaGR);
                    Executor executor = zr1Var.oIzScy;
                    if (executor == null) {
                        ng0.qjJ2uH("internalQueryExecutor");
                        throw null;
                    }
                    px i37xLF = a72.i37xLF(new s70(executor), b12.flOPlW());
                    if (i37xLF.f44QqK(yv1.YQmmye) == null) {
                        i37xLF = i37xLF.Nk77O2(new th0(null));
                    }
                    zr1Var.wbQVfV = new gx(i37xLF);
                    s1 s1Var = zr1Var.XPjQRF;
                    if (s1Var == null) {
                        ng0.qjJ2uH("internalTransactionExecutor");
                        throw null;
                    }
                    zr1Var.flOPlW = i37xLF.Nk77O2(new s70(s1Var));
                    f30 f30Var4 = zr1Var.YQmmye;
                    if (f30Var4 == null) {
                        ng0.qjJ2uH("connectionManager");
                        throw null;
                    }
                    zx1 zx1Var3 = (zx1) f30Var4.fmcqY6;
                    if (zx1Var3 != null) {
                        while (!(zx1Var3 instanceof xh1)) {
                            if (zx1Var3 instanceof b30) {
                                zx1Var3 = ((b30) zx1Var3).wbQVfV();
                            }
                        }
                        f30Var = zr1Var.YQmmye;
                        if (f30Var != null) {
                            ng0.qjJ2uH("connectionManager");
                            throw null;
                        }
                        zx1 zx1Var4 = (zx1) f30Var.fmcqY6;
                        if (zx1Var4 != null) {
                            while (true) {
                                if (zx1Var4 instanceof q4) {
                                    zx1Var = zx1Var4;
                                } else if (zx1Var4 instanceof b30) {
                                    zx1Var4 = ((b30) zx1Var4).wbQVfV();
                                }
                            }
                        }
                        return (TerraceDatabase) zr1Var;
                    }
                    zx1Var3 = null;
                    f30Var = zr1Var.YQmmye;
                    if (f30Var != null) {
                    }
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException("Cannot find implementation for " + wbQVfV2.getCanonicalName() + ". " + concat + " does not exist. Is Room annotation processor correctly configured?", e);
                } catch (IllegalAccessException e2) {
                    throw new RuntimeException("Cannot access the constructor " + wbQVfV2.getCanonicalName(), e2);
                } catch (InstantiationException e3) {
                    throw new RuntimeException("Failed to create an instance of " + wbQVfV2.getCanonicalName(), e3);
                }
                break;
            case li1.FLOAT_FIELD_NUMBER /* 2 */:
                ((l41) obj).getClass();
                return new yy1(context);
            case li1.INTEGER_FIELD_NUMBER /* 3 */:
                Integer num = (Integer) obj;
                String quantityString = context.getResources().getQuantityString(R.plurals.calabash_kept, num.intValue(), num);
                quantityString.getClass();
                return quantityString;
            case li1.LONG_FIELD_NUMBER /* 4 */:
                Integer num2 = (Integer) obj;
                String quantityString2 = context.getResources().getQuantityString(R.plurals.calabash_notes, num2.intValue(), num2);
                quantityString2.getClass();
                return quantityString2;
            case li1.STRING_FIELD_NUMBER /* 5 */:
                Integer num3 = (Integer) obj;
                String quantityString3 = context.getResources().getQuantityString(R.plurals.calabash_boards, num3.intValue(), num3);
                quantityString3.getClass();
                return quantityString3;
            default:
                Integer num4 = (Integer) obj;
                num4.intValue();
                String string = context.getString(R.string.calabash_lowest_turns, num4);
                string.getClass();
                return string;
        }
    }
}
