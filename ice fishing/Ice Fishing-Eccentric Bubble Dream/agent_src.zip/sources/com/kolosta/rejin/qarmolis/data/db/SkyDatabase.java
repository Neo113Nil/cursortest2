package com.kolosta.rejin.qarmolis.data.db;

/* loaded from: classes.dex */
public abstract class SkyDatabase extends defpackage.cj1 {
    public abstract defpackage.rr1 m();
}
