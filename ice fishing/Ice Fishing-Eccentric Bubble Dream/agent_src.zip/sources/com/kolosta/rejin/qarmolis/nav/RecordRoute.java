package com.kolosta.rejin.qarmolis.nav;

@defpackage.pp1
/* loaded from: classes.dex */
public final class RecordRoute {
    public static final defpackage.mg1 Companion = new defpackage.mg1();
    public final int a;

    public RecordRoute(int i, int i2) {
        java.lang.String str;
        if (1 == (i & 1)) {
            this.a = i2;
            return;
        }
        defpackage.lp1 lp1VarD = defpackage.lg1.a.d();
        lp1VarD.getClass();
        java.util.ArrayList arrayList = new java.util.ArrayList();
        int i3 = (~i) & 1;
        int i4 = 0;
        while (i4 < 32) {
            if ((i3 & 1) != 0) {
                arrayList.add(lp1VarD.d(i4));
            }
            i4++;
            i3 = 0;
        }
        java.lang.String strA = lp1VarD.a();
        strA.getClass();
        if (arrayList.size() == 1) {
            str = "Field '" + ((java.lang.String) arrayList.get(0)) + "' is required for type with serial name '" + strA + "', but it was missing";
        } else {
            str = "Fields " + arrayList + " are required for type with serial name '" + strA + "', but they were missing";
        }
        throw new defpackage.hw0(str, null);
    }

    public final boolean equals(java.lang.Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof com.kolosta.rejin.qarmolis.nav.RecordRoute) && this.a == ((com.kolosta.rejin.qarmolis.nav.RecordRoute) obj).a;
    }

    public final int hashCode() {
        return java.lang.Integer.hashCode(this.a);
    }

    public final java.lang.String toString() {
        return defpackage.k2.h(this.a, "RecordRoute(id=", ")");
    }

    public RecordRoute(int i) {
        this.a = i;
    }
}
