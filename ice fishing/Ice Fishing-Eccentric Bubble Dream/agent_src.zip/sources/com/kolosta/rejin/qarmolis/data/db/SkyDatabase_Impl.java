package com.kolosta.rejin.qarmolis.data.db;

/* loaded from: classes.dex */
public final class SkyDatabase_Impl extends com.kolosta.rejin.qarmolis.data.db.SkyDatabase {
    public final defpackage.wx1 l = new defpackage.wx1(new defpackage.k21(17, this));

    @Override // defpackage.cj1
    public final java.util.List b(java.util.LinkedHashMap linkedHashMap) {
        return new java.util.ArrayList();
    }

    @Override // defpackage.cj1
    public final defpackage.wj0 c() {
        return new defpackage.wj0(this, new java.util.LinkedHashMap(), new java.util.LinkedHashMap(), "observations", "progress");
    }

    @Override // defpackage.cj1
    public final defpackage.w30 d() {
        return new defpackage.sr1(this);
    }

    @Override // defpackage.cj1
    public final java.util.Set g() {
        return new java.util.LinkedHashSet();
    }

    @Override // defpackage.cj1
    public final java.util.LinkedHashMap h() {
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
        linkedHashMap.put(defpackage.bh1.a(defpackage.rr1.class), defpackage.q40.f);
        return linkedHashMap;
    }

    @Override // com.kolosta.rejin.qarmolis.data.db.SkyDatabase
    public final defpackage.rr1 m() {
        return (defpackage.rr1) this.l.getValue();
    }
}
