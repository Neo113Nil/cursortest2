package com.kolosta.rejin.qarmolis.nav;

@defpackage.pp1
/* loaded from: classes.dex */
public final class IndexRoute {
    public static final com.kolosta.rejin.qarmolis.nav.IndexRoute INSTANCE = new com.kolosta.rejin.qarmolis.nav.IndexRoute();
    public static final /* synthetic */ defpackage.gn0 a = defpackage.qr1.J(defpackage.rq0.f, new defpackage.tp(23));

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof com.kolosta.rejin.qarmolis.nav.IndexRoute);
    }

    public final int hashCode() {
        return -68420022;
    }

    public final defpackage.sk0 serializer() {
        return (defpackage.sk0) a.getValue();
    }

    public final java.lang.String toString() {
        return "IndexRoute";
    }
}
