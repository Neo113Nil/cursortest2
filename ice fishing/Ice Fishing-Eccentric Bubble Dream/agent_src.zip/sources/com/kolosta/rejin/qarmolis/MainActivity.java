package com.kolosta.rejin.qarmolis;

/* loaded from: classes.dex */
public final class MainActivity extends defpackage.ln {
    @Override // defpackage.ln, defpackage.kn, android.app.Activity
    public final void onCreate(android.os.Bundle bundle) throws java.lang.Exception {
        super.onCreate(bundle);
        defpackage.xx1 xx1Var = new defpackage.xx1(new defpackage.el1(23));
        defpackage.xx1 xx1Var2 = new defpackage.xx1(new defpackage.el1(23));
        defpackage.c30 c30Var = defpackage.b30.a;
        android.view.View decorView = getWindow().getDecorView();
        decorView.getClass();
        defpackage.c30 g30Var = defpackage.b30.a;
        if (g30Var == null) {
            int i = android.os.Build.VERSION.SDK_INT;
            g30Var = i >= 35 ? new defpackage.g30() : i >= 30 ? new defpackage.f30() : i >= 29 ? new defpackage.e30() : i >= 28 ? new defpackage.d30() : new defpackage.c30();
            defpackage.b30.a = g30Var;
        }
        defpackage.c30 c30Var2 = g30Var;
        defpackage.z20 z20Var = new defpackage.z20(c30Var2, xx1Var, xx1Var2, this, decorView);
        android.view.ViewGroup viewGroup = (android.view.ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 >= viewGroup.getChildCount()) {
                defpackage.a30 a30Var = new defpackage.a30(z20Var, viewGroup.getContext());
                a30Var.setTag(c30Var2);
                a30Var.setVisibility(8);
                a30Var.setWillNotDraw(true);
                viewGroup.addView(a30Var);
                break;
            }
            int i3 = i2 + 1;
            android.view.View childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new java.lang.IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof defpackage.c30) {
                break;
            } else {
                i2 = i3;
            }
        }
        z20Var.run();
        android.view.Window window = getWindow();
        window.getClass();
        c30Var2.a(window);
        defpackage.qn qnVar = defpackage.vv.i;
        android.view.ViewGroup.LayoutParams layoutParams = defpackage.mn.a;
        android.view.View childAt2 = ((android.view.ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        defpackage.ap apVar = childAt2 instanceof defpackage.ap ? (defpackage.ap) childAt2 : null;
        if (apVar != null) {
            apVar.setParentCompositionContext(null);
            apVar.setContent(qnVar);
            return;
        }
        defpackage.ap apVar2 = new defpackage.ap(this);
        apVar2.setParentCompositionContext(null);
        apVar2.setContent(qnVar);
        android.view.View decorView2 = getWindow().getDecorView();
        if (defpackage.l42.b(decorView2) == null) {
            decorView2.setTag(com.kolosta.rejin.qarmolis.R.id.view_tree_lifecycle_owner, this);
        }
        if (defpackage.n52.b(decorView2) == null) {
            decorView2.setTag(com.kolosta.rejin.qarmolis.R.id.view_tree_view_model_store_owner, this);
        }
        if (defpackage.e52.a(decorView2) == null) {
            decorView2.setTag(com.kolosta.rejin.qarmolis.R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(apVar2, defpackage.mn.a);
    }
}
