package com.kolosta.rejin.qarmolis.nav;

@defpackage.pp1
/* loaded from: classes.dex */
public final class DeskRoute {
    public static final com.kolosta.rejin.qarmolis.nav.DeskRoute INSTANCE = new com.kolosta.rejin.qarmolis.nav.DeskRoute();
    public static final /* synthetic */ defpackage.gn0 a = defpackage.qr1.J(defpackage.rq0.f, new defpackage.tp(17));

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof com.kolosta.rejin.qarmolis.nav.DeskRoute);
    }

    public final int hashCode() {
        return -2067151075;
    }

    public final defpackage.sk0 serializer() {
        return (defpackage.sk0) a.getValue();
    }

    public final java.lang.String toString() {
        return "DeskRoute";
    }
}
