package com.kolosta.rejin.qarmolis.nav;

@defpackage.pp1
/* loaded from: classes.dex */
public final class LedgerRoute {
    public static final com.kolosta.rejin.qarmolis.nav.LedgerRoute INSTANCE = new com.kolosta.rejin.qarmolis.nav.LedgerRoute();
    public static final /* synthetic */ defpackage.gn0 a = defpackage.qr1.J(defpackage.rq0.f, new defpackage.kl0(6));

    public final boolean equals(java.lang.Object obj) {
        return this == obj || (obj instanceof com.kolosta.rejin.qarmolis.nav.LedgerRoute);
    }

    public final int hashCode() {
        return -1051159795;
    }

    public final defpackage.sk0 serializer() {
        return (defpackage.sk0) a.getValue();
    }

    public final java.lang.String toString() {
        return "LedgerRoute";
    }
}
