package com.kolosta.rejin.qarmolis;

/* loaded from: classes.dex */
public final class AsterSpanApp extends android.app.Application {
    public static final /* synthetic */ int f = 0;

    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        defpackage.l lVar = new defpackage.l(10, this);
        synchronized (defpackage.s2.T) {
            defpackage.jl0 jl0Var = new defpackage.jl0();
            if (defpackage.s2.U != null) {
                throw new defpackage.xh0("A Koin Application has already been started");
            }
            defpackage.s2.U = jl0Var.a;
            lVar.h(jl0Var);
            jl0Var.a.f();
        }
    }
}
