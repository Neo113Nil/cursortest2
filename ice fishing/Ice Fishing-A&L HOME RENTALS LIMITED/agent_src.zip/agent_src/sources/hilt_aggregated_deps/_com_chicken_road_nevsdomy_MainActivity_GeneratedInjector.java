package hilt_aggregated_deps;

/* loaded from: classes2.dex */
public class _com_chicken_road_nevsdomy_MainActivity_GeneratedInjector {
}
