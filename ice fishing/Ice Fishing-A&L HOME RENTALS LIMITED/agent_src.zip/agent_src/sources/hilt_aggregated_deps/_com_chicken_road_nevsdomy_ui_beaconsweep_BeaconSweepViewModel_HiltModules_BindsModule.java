package hilt_aggregated_deps;

/* loaded from: classes2.dex */
public class _com_chicken_road_nevsdomy_ui_beaconsweep_BeaconSweepViewModel_HiltModules_BindsModule {
}
