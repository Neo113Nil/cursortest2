package hilt_aggregated_deps;

/* loaded from: classes2.dex */
public class _com_chicken_road_nevsdomy_StraitWatchApp_GeneratedInjector {
}
