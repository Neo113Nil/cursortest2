package hilt_aggregated_deps;

/* loaded from: classes2.dex */
public class _com_chicken_road_nevsdomy_ui_register_RegisterViewModel_HiltModules_KeyModule {
}
