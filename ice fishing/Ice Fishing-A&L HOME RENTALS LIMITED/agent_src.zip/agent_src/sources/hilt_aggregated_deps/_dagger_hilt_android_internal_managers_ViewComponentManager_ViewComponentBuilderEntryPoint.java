package hilt_aggregated_deps;

/* loaded from: classes2.dex */
public class _dagger_hilt_android_internal_managers_ViewComponentManager_ViewComponentBuilderEntryPoint {
}
