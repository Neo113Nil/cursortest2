package com.chicken.road.nevsdomy.data.db;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Entities.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0014\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0013\u001a\u00020\u0014HÖ\u0081\u0004J\n\u0010\u0015\u001a\u00020\u0003HÖ\u0081\u0004R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\n¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fÊ\u0001\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u0019Ê\u0001\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\u0003\u0010\u0002¨\u0006\u0016"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/CrossingEntity;", "", "straitId", "", "crossedOn", "", "<init>", "(Ljava/lang/String;J)V", "getStraitId", "()Ljava/lang/String;", "Landroidx/room/PrimaryKey;", "getCrossedOn", "()J", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "app", "Landroidx/room/Entity;", "tableName", "crossings", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class CrossingEntity {
    public static final int $stable = 0;
    private final long crossedOn;
    private final String straitId;

    public static /* synthetic */ CrossingEntity copy$default(CrossingEntity crossingEntity, String str, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            str = crossingEntity.straitId;
        }
        if ((i & 2) != 0) {
            j = crossingEntity.crossedOn;
        }
        return crossingEntity.copy(str, j);
    }

    /* renamed from: component1, reason: from getter */
    public final String getStraitId() {
        return this.straitId;
    }

    /* renamed from: component2, reason: from getter */
    public final long getCrossedOn() {
        return this.crossedOn;
    }

    public final CrossingEntity copy(String straitId, long crossedOn) {
        Intrinsics.checkNotNullParameter(straitId, "straitId");
        return new CrossingEntity(straitId, crossedOn);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CrossingEntity)) {
            return false;
        }
        CrossingEntity crossingEntity = (CrossingEntity) other;
        return Intrinsics.areEqual(this.straitId, crossingEntity.straitId) && this.crossedOn == crossingEntity.crossedOn;
    }

    public int hashCode() {
        return (this.straitId.hashCode() * 31) + Long.hashCode(this.crossedOn);
    }

    public String toString() {
        return "CrossingEntity(straitId=" + this.straitId + ", crossedOn=" + this.crossedOn + ")";
    }

    public CrossingEntity(String straitId, long j) {
        Intrinsics.checkNotNullParameter(straitId, "straitId");
        this.straitId = straitId;
        this.crossedOn = j;
    }

    public final String getStraitId() {
        return this.straitId;
    }

    public final long getCrossedOn() {
        return this.crossedOn;
    }
}
