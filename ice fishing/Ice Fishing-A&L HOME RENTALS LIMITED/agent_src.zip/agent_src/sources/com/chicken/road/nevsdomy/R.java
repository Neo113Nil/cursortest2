package com.chicken.road.nevsdomy;

/* loaded from: classes2.dex */
public final class R {

    /* JADX INFO: Added by JADX */
    public static final class anim {

        /* JADX INFO: Added by JADX */
        public static final int fragment_fast_out_extra_slow_in = 0x7f010000;
    }

    /* JADX INFO: Added by JADX */
    public static final class animator {

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_enter = 0x7f020000;

        /* JADX INFO: Added by JADX */
        public static final int fragment_close_exit = 0x7f020001;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_enter = 0x7f020002;

        /* JADX INFO: Added by JADX */
        public static final int fragment_fade_exit = 0x7f020003;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_enter = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int fragment_open_exit = 0x7f020005;
    }

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int action = 0x7f030000;

        /* JADX INFO: Added by JADX */
        public static final int activityAction = 0x7f030001;

        /* JADX INFO: Added by JADX */
        public static final int activityName = 0x7f030002;

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int alwaysExpand = 0x7f030004;

        /* JADX INFO: Added by JADX */
        public static final int animationBackgroundColor = 0x7f030005;

        /* JADX INFO: Added by JADX */
        public static final int argType = 0x7f030006;

        /* JADX INFO: Added by JADX */
        public static final int clearTop = 0x7f030007;

        /* JADX INFO: Added by JADX */
        public static final int data = 0x7f030008;

        /* JADX INFO: Added by JADX */
        public static final int dataPattern = 0x7f030009;

        /* JADX INFO: Added by JADX */
        public static final int destination = 0x7f03000a;

        /* JADX INFO: Added by JADX */
        public static final int dragRangeMaxRatio = 0x7f03000b;

        /* JADX INFO: Added by JADX */
        public static final int dragRangeMinRatio = 0x7f03000c;

        /* JADX INFO: Added by JADX */
        public static final int embeddingDividerColor = 0x7f03000d;

        /* JADX INFO: Added by JADX */
        public static final int embeddingDividerType = 0x7f03000e;

        /* JADX INFO: Added by JADX */
        public static final int embeddingDividerWidthDp = 0x7f03000f;

        /* JADX INFO: Added by JADX */
        public static final int enterAnim = 0x7f030010;

        /* JADX INFO: Added by JADX */
        public static final int exitAnim = 0x7f030011;

        /* JADX INFO: Added by JADX */
        public static final int finishPrimaryWithPlaceholder = 0x7f030012;

        /* JADX INFO: Added by JADX */
        public static final int finishPrimaryWithSecondary = 0x7f030013;

        /* JADX INFO: Added by JADX */
        public static final int finishSecondaryWithPrimary = 0x7f030014;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f030015;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f030016;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f030017;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFallbackQuery = 0x7f030018;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f030019;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f03001a;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f03001b;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f03001c;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f03001d;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f03001e;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f03001f;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f030020;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f030021;

        /* JADX INFO: Added by JADX */
        public static final int isDraggingToFullscreenAllowed = 0x7f030022;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f030023;

        /* JADX INFO: Added by JADX */
        public static final int launchSingleTop = 0x7f030024;

        /* JADX INFO: Added by JADX */
        public static final int mimeType = 0x7f030025;

        /* JADX INFO: Added by JADX */
        public static final int navGraph = 0x7f030026;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 0x7f030027;

        /* JADX INFO: Added by JADX */
        public static final int nullable = 0x7f030028;

        /* JADX INFO: Added by JADX */
        public static final int placeholderActivityName = 0x7f030029;

        /* JADX INFO: Added by JADX */
        public static final int popEnterAnim = 0x7f03002a;

        /* JADX INFO: Added by JADX */
        public static final int popExitAnim = 0x7f03002b;

        /* JADX INFO: Added by JADX */
        public static final int popUpTo = 0x7f03002c;

        /* JADX INFO: Added by JADX */
        public static final int popUpToInclusive = 0x7f03002d;

        /* JADX INFO: Added by JADX */
        public static final int popUpToSaveState = 0x7f03002e;

        /* JADX INFO: Added by JADX */
        public static final int primaryActivityName = 0x7f03002f;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 0x7f030030;

        /* JADX INFO: Added by JADX */
        public static final int restoreState = 0x7f030031;

        /* JADX INFO: Added by JADX */
        public static final int route = 0x7f030032;

        /* JADX INFO: Added by JADX */
        public static final int secondaryActivityAction = 0x7f030033;

        /* JADX INFO: Added by JADX */
        public static final int secondaryActivityName = 0x7f030034;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 0x7f030035;

        /* JADX INFO: Added by JADX */
        public static final int splitChangeAnimation = 0x7f030036;

        /* JADX INFO: Added by JADX */
        public static final int splitCloseAnimation = 0x7f030037;

        /* JADX INFO: Added by JADX */
        public static final int splitLayoutDirection = 0x7f030038;

        /* JADX INFO: Added by JADX */
        public static final int splitMaxAspectRatioInLandscape = 0x7f030039;

        /* JADX INFO: Added by JADX */
        public static final int splitMaxAspectRatioInPortrait = 0x7f03003a;

        /* JADX INFO: Added by JADX */
        public static final int splitMinHeightDp = 0x7f03003b;

        /* JADX INFO: Added by JADX */
        public static final int splitMinSmallestWidthDp = 0x7f03003c;

        /* JADX INFO: Added by JADX */
        public static final int splitMinWidthDp = 0x7f03003d;

        /* JADX INFO: Added by JADX */
        public static final int splitOpenAnimation = 0x7f03003e;

        /* JADX INFO: Added by JADX */
        public static final int splitRatio = 0x7f03003f;

        /* JADX INFO: Added by JADX */
        public static final int startDestination = 0x7f030040;

        /* JADX INFO: Added by JADX */
        public static final int stickyPlaceholder = 0x7f030041;

        /* JADX INFO: Added by JADX */
        public static final int tag = 0x7f030042;

        /* JADX INFO: Added by JADX */
        public static final int targetPackage = 0x7f030043;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f030044;

        /* JADX INFO: Added by JADX */
        public static final int uri = 0x7f030045;
    }

    public static final class color {
        public static int black = 0x7f040002;
        public static int purple_200 = 0x7f040007;
        public static int purple_500 = 0x7f040008;
        public static int purple_700 = 0x7f040009;
        public static int teal_200 = 0x7f04000a;
        public static int teal_700 = 0x7f04000b;
        public static int white = 0x7f04000e;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 0x7f040000;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 0x7f040001;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 0x7f040004;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 0x7f040005;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 0x7f040006;

        /* JADX INFO: Added by JADX */
        public static final int vector_tint_color = 0x7f04000c;

        /* JADX INFO: Added by JADX */
        public static final int vector_tint_theme_color = 0x7f04000d;

        private color() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 0x7f050002;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 0x7f050003;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 0x7f050007;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 0x7f050008;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 0x7f050009;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 0x7f05000a;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 0x7f05000b;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 0x7f05000c;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 0x7f05000d;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 0x7f05000e;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 0x7f05000f;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 0x7f050010;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 0x7f050011;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 0x7f050012;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 0x7f050013;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 0x7f050014;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 0x7f050015;
    }

    public static final class drawable {
        public static int ic_launcher_background = 0x7f060007;
        public static int ic_launcher_foreground = 0x7f060008;

        /* JADX INFO: Added by JADX */
        public static final int _ic_launcher_foreground__0_res_0x7f060000 = 0x7f060000;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer = 0x7f060001;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_low = 0x7f060002;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video = 0x7f060003;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video_low = 0x7f060004;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 0x7f060005;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline_low = 0x7f060006;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 0x7f060009;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 0x7f06000a;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 0x7f06000b;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 0x7f060010;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 0x7f060011;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 0x7f060012;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 0x7f060013;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 0x7f060014;

        private drawable() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class id {

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int adjacent = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int alwaysAllow = 0x7f070028;

        /* JADX INFO: Added by JADX */
        public static final int alwaysDisallow = 0x7f070029;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_compose_view_context = 0x7f07002a;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_view_composition_context = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int androidx_window_activity_scope = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f07002d;

        /* JADX INFO: Added by JADX */
        public static final int auto_clear_focus_behavior_tag = 0x7f07002e;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f07002f;

        /* JADX INFO: Added by JADX */
        public static final int bottomToTop = 0x7f070030;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int compose_prefetch_scheduler = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int compose_view_saveable_id_tag = 0x7f070033;

        /* JADX INFO: Added by JADX */
        public static final int consume_window_insets_tag = 0x7f070034;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f070035;

        /* JADX INFO: Added by JADX */
        public static final int draggable = 0x7f070036;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f070037;

        /* JADX INFO: Added by JADX */
        public static final int fixed = 0x7f070038;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f070039;

        /* JADX INFO: Added by JADX */
        public static final int fragment_container_view_tag = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int hide_graphics_layer_in_inspector_tag = 0x7f07003b;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int hide_in_inspector_tag = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f070040;

        /* JADX INFO: Added by JADX */
        public static final int inspection_slot_table_set = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f070042;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int jumpCut = 0x7f070044;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int locale = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int ltr = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int nav_controller_view_tag = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f07004d;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f07004e;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f07004f;

        /* JADX INFO: Added by JADX */
        public static final int report_drawn = 0x7f070050;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f070051;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f070052;

        /* JADX INFO: Added by JADX */
        public static final int rtl = 0x7f070053;

        /* JADX INFO: Added by JADX */
        public static final int special_effects_controller_view_tag = 0x7f070054;

        /* JADX INFO: Added by JADX */
        public static final int systemDefault = 0x7f070055;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f070056;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f070057;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f070058;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f070059;

        /* JADX INFO: Added by JADX */
        public static final int tag_compat_insets_dispatch = 0x7f07005a;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f07005b;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f07005d;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f07005e;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f07005f;

        /* JADX INFO: Added by JADX */
        public static final int tag_system_bar_state_monitor = 0x7f070060;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f070061;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f070062;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f070063;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f070065;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f070067;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int topToBottom = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_disjoint_parent = 0x7f07006a;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_navigation_event_dispatcher_owner = 0x7f07006c;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_saved_state_registry_owner = 0x7f07006e;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_view_model_store_owner = 0x7f07006f;

        /* JADX INFO: Added by JADX */
        public static final int visible_removing_fragment_view_tag = 0x7f070070;

        /* JADX INFO: Added by JADX */
        public static final int wrapped_composition_tag = 0x7f070071;
    }

    /* JADX INFO: Added by JADX */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int m3c_window_layout_in_display_cutout_mode = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 0x7f080001;
    }

    /* JADX INFO: Added by JADX */
    public static final class layout {

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 0x7f090001;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 0x7f090002;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 0x7f090003;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 0x7f090004;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 0x7f090005;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 0x7f090006;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 0x7f090007;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 0x7f090008;
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f0a0000;
        public static int ic_launcher_foreground = 0x7f0a0001;
        public static int ic_launcher_round = 0x7f0a0002;

        private mipmap() {
        }
    }

    public static final class plurals {
        public static int register_section_count = 0x7f0b0000;

        private plurals() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0c0003;
        public static int basin_atlantic_gates = 0x7f0c0004;
        public static int basin_eastern_seaways = 0x7f0c0005;
        public static int basin_monsoon_straits = 0x7f0c0006;
        public static int basin_pacific_rim = 0x7f0c0007;
        public static int cd_back = 0x7f0c000f;
        public static int cd_clear_search = 0x7f0c0010;
        public static int cd_open_drawer = 0x7f0c0011;
        public static int cd_search = 0x7f0c0012;
        public static int cd_tile_matched = 0x7f0c0013;
        public static int cd_tile_missed = 0x7f0c0014;
        public static int chart_hero_header = 0x7f0c0015;
        public static int chart_open_register = 0x7f0c0016;
        public static int chart_run_sweep = 0x7f0c0017;
        public static int chart_stat_best = 0x7f0c0018;
        public static int chart_stat_crossings = 0x7f0c0019;
        public static int chart_stat_passages = 0x7f0c001a;
        public static int chart_stat_runs = 0x7f0c001b;
        public static int chart_swing_the_glass = 0x7f0c001c;
        public static int chart_totals_header = 0x7f0c001d;
        public static int dialog_cancel = 0x7f0c0022;
        public static int dialog_confirm_date = 0x7f0c0023;
        public static int drawer_subtitle = 0x7f0c0024;
        public static int drawer_title = 0x7f0c0025;
        public static int neck_width = 0x7f0c006c;
        public static int passage_banks_header = 0x7f0c006e;
        public static int passage_clear_log = 0x7f0c006f;
        public static int passage_crossed_on = 0x7f0c0070;
        public static int passage_crossing_header = 0x7f0c0071;
        public static int passage_log_button = 0x7f0c0072;
        public static int passage_missing = 0x7f0c0073;
        public static int passage_no_crossing = 0x7f0c0074;
        public static int passage_soundings_header = 0x7f0c0075;
        public static int passage_story_header = 0x7f0c0076;
        public static int register_empty_glyph = 0x7f0c0079;
        public static int register_empty_hint = 0x7f0c007a;
        public static int register_empty_title = 0x7f0c007b;
        public static int register_search_hint = 0x7f0c007c;
        public static int register_sort_label = 0x7f0c007d;
        public static int screen_beacon_sweep = 0x7f0c007e;
        public static int screen_chart_room = 0x7f0c007f;
        public static int screen_register = 0x7f0c0080;
        public static int seas_joined = 0x7f0c0081;
        public static int sort_busiest = 0x7f0c0084;
        public static int sort_deepest = 0x7f0c0085;
        public static int sort_narrowest = 0x7f0c0086;
        public static int sort_register = 0x7f0c0087;
        public static int stat_deepest = 0x7f0c0088;
        public static int stat_length = 0x7f0c0089;
        public static int stat_narrowest = 0x7f0c008a;
        public static int stat_traffic = 0x7f0c008b;
        public static int sweep_again = 0x7f0c0090;
        public static int sweep_back = 0x7f0c0091;
        public static int sweep_best = 0x7f0c0092;
        public static int sweep_best_none = 0x7f0c0093;
        public static int sweep_boards = 0x7f0c0094;
        public static int sweep_call = 0x7f0c0095;
        public static int sweep_idle_glyph = 0x7f0c0096;
        public static int sweep_lamp = 0x7f0c0097;
        public static int sweep_new_best = 0x7f0c0098;
        public static int sweep_over_title = 0x7f0c0099;
        public static int sweep_rule_one = 0x7f0c009a;
        public static int sweep_rule_three = 0x7f0c009b;
        public static int sweep_rule_two = 0x7f0c009c;
        public static int sweep_rules_header = 0x7f0c009d;
        public static int sweep_start = 0x7f0c009e;
        public static int tag_bridged = 0x7f0c00a1;
        public static int tag_ice_season = 0x7f0c00a2;
        public static int tag_oil_artery = 0x7f0c00a3;
        public static int tag_shallow_bank = 0x7f0c00a4;
        public static int tag_tidal_race = 0x7f0c00a5;
        public static int value_km = 0x7f0c00a9;
        public static int value_length_km = 0x7f0c00aa;
        public static int value_metres = 0x7f0c00ab;
        public static int value_none = 0x7f0c00ac;
        public static int value_ships_day = 0x7f0c00ad;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_foundation_autofill = 0x7f0c0000;

        /* JADX INFO: Added by JADX */
        public static final int androidx_compose_ui_autofill = 0x7f0c0001;

        /* JADX INFO: Added by JADX */
        public static final int androidx_startup = 0x7f0c0002;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 0x7f0c0008;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 0x7f0c0009;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 0x7f0c000a;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 0x7f0c000b;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 0x7f0c000c;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 0x7f0c000d;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 0x7f0c000e;

        /* JADX INFO: Added by JADX */
        public static final int close_drawer = 0x7f0c001e;

        /* JADX INFO: Added by JADX */
        public static final int close_sheet = 0x7f0c001f;

        /* JADX INFO: Added by JADX */
        public static final int default_error_message = 0x7f0c0020;

        /* JADX INFO: Added by JADX */
        public static final int default_popup_window_title = 0x7f0c0021;

        /* JADX INFO: Added by JADX */
        public static final int dropdown_menu = 0x7f0c0026;

        /* JADX INFO: Added by JADX */
        public static final int in_progress = 0x7f0c0027;

        /* JADX INFO: Added by JADX */
        public static final int indeterminate = 0x7f0c0028;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_collapse_description = 0x7f0c0029;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_dismiss_description = 0x7f0c002a;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_drag_handle_description = 0x7f0c002b;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_expand_description = 0x7f0c002c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_bottom_sheet_pane_title = 0x7f0c002d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_headline = 0x7f0c002e;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_headline_description = 0x7f0c002f;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_invalid_for_pattern = 0x7f0c0030;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_invalid_not_allowed = 0x7f0c0031;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_invalid_year_range = 0x7f0c0032;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_label = 0x7f0c0033;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_no_input_description = 0x7f0c0034;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_input_title = 0x7f0c0035;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_headline = 0x7f0c0036;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_headline_description = 0x7f0c0037;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_navigate_to_year_description = 0x7f0c0038;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_no_selection_description = 0x7f0c0039;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_scroll_to_earlier_years = 0x7f0c003a;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_scroll_to_later_years = 0x7f0c003b;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_calendar_mode = 0x7f0c003c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_day_selection = 0x7f0c003d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_input_mode = 0x7f0c003e;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_next_month = 0x7f0c003f;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_previous_month = 0x7f0c0040;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_switch_to_year_selection = 0x7f0c0041;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_title = 0x7f0c0042;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_today_description = 0x7f0c0043;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_picker_year_picker_pane_title = 0x7f0c0044;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_input_invalid_range_input = 0x7f0c0045;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_input_title = 0x7f0c0046;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_day_in_range = 0x7f0c0047;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_end_headline = 0x7f0c0048;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_scroll_to_next_month = 0x7f0c0049;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_scroll_to_previous_month = 0x7f0c004a;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_start_headline = 0x7f0c004b;

        /* JADX INFO: Added by JADX */
        public static final int m3c_date_range_picker_title = 0x7f0c004c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dialog = 0x7f0c004d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_collapsed = 0x7f0c004e;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_expanded = 0x7f0c004f;

        /* JADX INFO: Added by JADX */
        public static final int m3c_dropdown_menu_toggle = 0x7f0c0050;

        /* JADX INFO: Added by JADX */
        public static final int m3c_floating_toolbar_collapse = 0x7f0c0051;

        /* JADX INFO: Added by JADX */
        public static final int m3c_floating_toolbar_expand = 0x7f0c0052;

        /* JADX INFO: Added by JADX */
        public static final int m3c_search_bar_search = 0x7f0c0053;

        /* JADX INFO: Added by JADX */
        public static final int m3c_snackbar_dismiss = 0x7f0c0054;

        /* JADX INFO: Added by JADX */
        public static final int m3c_snackbar_pane_title = 0x7f0c0055;

        /* JADX INFO: Added by JADX */
        public static final int m3c_suggestions_available = 0x7f0c0056;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_input_dialog_title = 0x7f0c0057;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_am = 0x7f0c0058;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_dialog_title = 0x7f0c0059;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_hour = 0x7f0c005a;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_hour_24h_suffix = 0x7f0c005b;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_hour_selection = 0x7f0c005c;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_hour_suffix = 0x7f0c005d;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_hour_text_field = 0x7f0c005e;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_minute = 0x7f0c005f;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_minute_selection = 0x7f0c0060;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_minute_suffix = 0x7f0c0061;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_minute_text_field = 0x7f0c0062;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_period_toggle_description = 0x7f0c0063;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_pm = 0x7f0c0064;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_toggle_keyboard = 0x7f0c0065;

        /* JADX INFO: Added by JADX */
        public static final int m3c_time_picker_toggle_touch = 0x7f0c0066;

        /* JADX INFO: Added by JADX */
        public static final int m3c_tooltip_long_press_label = 0x7f0c0067;

        /* JADX INFO: Added by JADX */
        public static final int m3c_tooltip_pane_description = 0x7f0c0068;

        /* JADX INFO: Added by JADX */
        public static final int m3c_wide_navigation_rail_close_rail = 0x7f0c0069;

        /* JADX INFO: Added by JADX */
        public static final int m3c_wide_navigation_rail_pane_title = 0x7f0c006a;

        /* JADX INFO: Added by JADX */
        public static final int navigation_menu = 0x7f0c006b;

        /* JADX INFO: Added by JADX */
        public static final int not_selected = 0x7f0c006d;

        /* JADX INFO: Added by JADX */
        public static final int range_end = 0x7f0c0077;

        /* JADX INFO: Added by JADX */
        public static final int range_start = 0x7f0c0078;

        /* JADX INFO: Added by JADX */
        public static final int selected = 0x7f0c0082;

        /* JADX INFO: Added by JADX */
        public static final int snackbar_pane_title = 0x7f0c0083;

        /* JADX INFO: Added by JADX */
        public static final int state_empty = 0x7f0c008c;

        /* JADX INFO: Added by JADX */
        public static final int state_off = 0x7f0c008d;

        /* JADX INFO: Added by JADX */
        public static final int state_on = 0x7f0c008e;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 0x7f0c008f;

        /* JADX INFO: Added by JADX */
        public static final int switch_role = 0x7f0c009f;

        /* JADX INFO: Added by JADX */
        public static final int tab = 0x7f0c00a0;

        /* JADX INFO: Added by JADX */
        public static final int template_percent = 0x7f0c00a6;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_description = 0x7f0c00a7;

        /* JADX INFO: Added by JADX */
        public static final int tooltip_label = 0x7f0c00a8;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_StraitWatch = 0x7f0d0009;

        /* JADX INFO: Added by JADX */
        public static final int DialogWindowTheme = 0x7f0d0000;

        /* JADX INFO: Added by JADX */
        public static final int EdgeToEdgeFloatingDialogTheme = 0x7f0d0001;

        /* JADX INFO: Added by JADX */
        public static final int EdgeToEdgeFloatingDialogWindowTheme = 0x7f0d0002;

        /* JADX INFO: Added by JADX */
        public static final int FloatingDialogWindowTheme = 0x7f0d0003;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 0x7f0d0004;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 0x7f0d0005;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f0d0006;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 0x7f0d0007;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 0x7f0d0008;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 0x7f0d000a;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 0x7f0d000b;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 0x7f0f0000;
        public static int data_extraction_rules = 0x7f0f0001;

        /* JADX INFO: Added by JADX */
        public static final int splits0 = 0x7f0f0002;

        private xml() {
        }
    }

    private R() {
    }
}
