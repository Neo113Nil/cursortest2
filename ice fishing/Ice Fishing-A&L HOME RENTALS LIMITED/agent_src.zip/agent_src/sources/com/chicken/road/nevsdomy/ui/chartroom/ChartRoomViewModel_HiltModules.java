package com.chicken.road.nevsdomy.ui.chartroom;

import androidx.lifecycle.ViewModel;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoMap;
import dagger.multibindings.LazyClassKey;

/* loaded from: classes2.dex */
public final class ChartRoomViewModel_HiltModules {
    private ChartRoomViewModel_HiltModules() {
    }

    @Module
    public static abstract class BindsModule {
        @LazyClassKey(ChartRoomViewModel.class)
        @Binds
        @IntoMap
        public abstract ViewModel binds(ChartRoomViewModel vm);

        private BindsModule() {
        }
    }

    @Module
    public static final class KeyModule {
        @Provides
        @LazyClassKey(ChartRoomViewModel.class)
        @IntoMap
        public static boolean provide() {
            return true;
        }

        private KeyModule() {
        }
    }
}
