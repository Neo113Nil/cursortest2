package com.chicken.road.nevsdomy;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import com.chicken.road.nevsdomy.nav.NavGraphKt;
import com.chicken.road.nevsdomy.ui.theme.ThemeKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* compiled from: MainActivity.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$MainActivityKt {
    public static final ComposableSingletons$MainActivityKt INSTANCE = new ComposableSingletons$MainActivityKt();

    /* renamed from: lambda$-1579192189, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f45lambda$1579192189 = ComposableLambdaKt.composableLambdaInstance(-1579192189, false, new Function2() { // from class: com.chicken.road.nevsdomy.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainActivityKt.lambda__1579192189$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1793856357 = ComposableLambdaKt.composableLambdaInstance(1793856357, false, new Function2() { // from class: com.chicken.road.nevsdomy.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainActivityKt.lambda_1793856357$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1579192189$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8887getLambda$1579192189$app() {
        return f45lambda$1579192189;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1793856357$app() {
        return lambda$1793856357;
    }

    static final Unit lambda_1793856357$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C16@573L70:MainActivity.kt#hsq1gt");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1793856357, i, -1, "com.chicken.road.nevsdomy.ComposableSingletons$MainActivityKt.lambda$1793856357.<anonymous> (MainActivity.kt:16)");
            }
            ThemeKt.StraitWatchTheme(f45lambda$1579192189, composer, 6);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1579192189$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C17@608L21:MainActivity.kt#hsq1gt");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1579192189, i, -1, "com.chicken.road.nevsdomy.ComposableSingletons$MainActivityKt.lambda$-1579192189.<anonymous> (MainActivity.kt:17)");
            }
            NavGraphKt.StraitWatchNavGraph(null, composer, 0, 1);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
