package com.chicken.road.nevsdomy.nav;

import androidx.compose.animation.AnimatedContentScope;
import androidx.compose.animation.AnimatedContentTransitionScope;
import androidx.compose.animation.EnterTransition;
import androidx.compose.animation.ExitTransition;
import androidx.compose.animation.SizeTransform;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.material3.DividerKt;
import androidx.compose.material3.DrawerState;
import androidx.compose.material3.DrawerValue;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.NavigationDrawerItemDefaults;
import androidx.compose.material3.NavigationDrawerKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambda;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.NavDeepLink;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraphBuilder;
import androidx.navigation.NavHostController;
import androidx.navigation.NavOptionsBuilder;
import androidx.navigation.NavType;
import androidx.navigation.Navigator;
import androidx.navigation.PopUpToBuilder;
import androidx.navigation.compose.NavGraphBuilderKt;
import androidx.navigation.compose.NavHostControllerKt;
import androidx.navigation.compose.NavHostKt;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt;
import com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt;
import com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt;
import com.chicken.road.nevsdomy.ui.register.RegisterScreenKt;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KType;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;

/* compiled from: NavGraph.kt */
@Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\u001a)\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007b\u0002\b\u0005b\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\b¢\u0006\u0002\u0010\u0004\u001a\u0014\u0010\t\u001a\u00020\u0001*\u00020\u00032\u0006\u0010\n\u001a\u00020\u000bH\u0002¨\u0006\f²\u0006\f\u0010\r\u001a\u0004\u0018\u00010\u000eX\u008a\u0084\u0002"}, d2 = {"StraitWatchNavGraph", "", "navController", "Landroidx/navigation/NavHostController;", "(Landroidx/navigation/NavHostController;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/Composable;", "Landroidx/compose/runtime/ComposableTarget;", "applier", "androidx.compose.ui.UiComposable", "navigateToPassage", "straitId", "", "app", "backStackEntry", "Landroidx/navigation/NavBackStackEntry;"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class NavGraphKt {

    /* compiled from: NavGraph.kt */
    @Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[DrawerEntry.values().length];
            try {
                iArr[DrawerEntry.CHART_ROOM.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[DrawerEntry.REGISTER.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[DrawerEntry.BEACON_SWEEP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    static final Unit StraitWatchNavGraph$lambda$6(NavHostController navHostController, int i, int i2, Composer composer, int i3) {
        StraitWatchNavGraph(navHostController, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x010d  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0154  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void StraitWatchNavGraph(NavHostController navHostController, Composer composer, final int i, final int i2) {
        NavHostController navHostControllerRememberNavController;
        int i3;
        final NavHostController navHostController2;
        final DrawerState drawerStateRememberDrawerState;
        Object objRememberedValue;
        final CoroutineScope coroutineScope;
        boolean zChangedInstance;
        Object objRememberedValue2;
        boolean zChangedInstance2;
        Object objRememberedValue3;
        int i4;
        Composer composerStartRestartGroup = composer.startRestartGroup(497820277);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(StraitWatchNavGraph)N(navController)47@2150L39,48@2206L24,49@2247L23,50@2311L30,53@2426L39,54@2500L40,79@3285L2339,128@5632L1189,77@3203L3618:NavGraph.kt#dpq88o");
        if ((i & 6) == 0) {
            if ((i2 & 1) == 0) {
                navHostControllerRememberNavController = navHostController;
                if (composerStartRestartGroup.changedInstance(navHostControllerRememberNavController)) {
                    i4 = 4;
                }
                i3 = i4 | i;
            } else {
                navHostControllerRememberNavController = navHostController;
            }
            i4 = 2;
            i3 = i4 | i;
        } else {
            navHostControllerRememberNavController = navHostController;
            i3 = i;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "46@2101L23");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 1) != 0) {
                    navHostControllerRememberNavController = NavHostControllerKt.rememberNavController(new Navigator[0], composerStartRestartGroup, 0);
                    i3 &= -15;
                }
                final NavHostController navHostController3 = navHostControllerRememberNavController;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(497820277, i3, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph (NavGraph.kt:46)");
                }
                drawerStateRememberDrawerState = NavigationDrawerKt.rememberDrawerState(DrawerValue.Closed, null, composerStartRestartGroup, 6, 2);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773894976, "CC(rememberCoroutineScope)N(getContext)763@35102L68:Effects.kt#9igjgp");
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 683736516, "CC(remember):Effects.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = EffectsKt.createCompositionCoroutineScope(EmptyCoroutineContext.INSTANCE, composerStartRestartGroup);
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                coroutineScope = (CoroutineScope) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final NavClickGuard navClickGuardRememberNavClickGuard = NavClickGuardKt.rememberNavClickGuard(composerStartRestartGroup, 0);
                NavBackStackEntry navBackStackEntryStraitWatchNavGraph$lambda$0 = StraitWatchNavGraph$lambda$0(NavHostControllerKt.currentBackStackEntryAsState(navHostController3, composerStartRestartGroup, i3 & 14));
                final NavDestination destination = navBackStackEntryStraitWatchNavGraph$lambda$0 != null ? navBackStackEntryStraitWatchNavGraph$lambda$0.getDestination() : null;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1663928668, "CC(remember):NavGraph.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(coroutineScope) | composerStartRestartGroup.changed(drawerStateRememberDrawerState);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NavGraphKt.StraitWatchNavGraph$lambda$1$0(coroutineScope, drawerStateRememberDrawerState);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                final Function0 function0 = (Function0) objRememberedValue2;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1663931037, "CC(remember):NavGraph.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(coroutineScope) | composerStartRestartGroup.changed(drawerStateRememberDrawerState);
                objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2 || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue3 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NavGraphKt.StraitWatchNavGraph$lambda$2$0(coroutineScope, drawerStateRememberDrawerState);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                }
                final Function0 function02 = (Function0) objRememberedValue3;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final Function3<Function0<Unit>, Composer, Integer, Unit> function3M8892getLambda$996978615$app = ComposableSingletons$NavGraphKt.INSTANCE.m8892getLambda$996978615$app();
                ComposableLambda composableLambdaRememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(-278344836, true, new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda15
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return NavGraphKt.StraitWatchNavGraph$lambda$4(destination, navClickGuardRememberNavClickGuard, function02, navHostController3, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54);
                Function2 function2 = new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda16
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return NavGraphKt.StraitWatchNavGraph$lambda$5(navHostController3, function0, navClickGuardRememberNavClickGuard, function02, function3M8892getLambda$996978615$app, (Composer) obj, ((Integer) obj2).intValue());
                    }
                };
                navHostController2 = navHostController3;
                NavigationDrawerKt.m2904ModalNavigationDrawerFHprtrg(composableLambdaRememberComposableLambda, null, drawerStateRememberDrawerState, false, 0L, ComposableLambdaKt.rememberComposableLambda(-1352490601, true, function2, composerStartRestartGroup, 54), composerStartRestartGroup, 196614, 26);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 1) != 0) {
                    i3 &= -15;
                }
                final NavHostController navHostController32 = navHostControllerRememberNavController;
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                }
                drawerStateRememberDrawerState = NavigationDrawerKt.rememberDrawerState(DrawerValue.Closed, null, composerStartRestartGroup, 6, 2);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773894976, "CC(rememberCoroutineScope)N(getContext)763@35102L68:Effects.kt#9igjgp");
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 683736516, "CC(remember):Effects.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                coroutineScope = (CoroutineScope) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final NavClickGuard navClickGuardRememberNavClickGuard2 = NavClickGuardKt.rememberNavClickGuard(composerStartRestartGroup, 0);
                NavBackStackEntry navBackStackEntryStraitWatchNavGraph$lambda$02 = StraitWatchNavGraph$lambda$0(NavHostControllerKt.currentBackStackEntryAsState(navHostController32, composerStartRestartGroup, i3 & 14));
                if (navBackStackEntryStraitWatchNavGraph$lambda$02 != null) {
                }
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1663928668, "CC(remember):NavGraph.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(coroutineScope) | composerStartRestartGroup.changed(drawerStateRememberDrawerState);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance) {
                    objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NavGraphKt.StraitWatchNavGraph$lambda$1$0(coroutineScope, drawerStateRememberDrawerState);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    final Function0 function03 = (Function0) objRememberedValue2;
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1663931037, "CC(remember):NavGraph.kt#9igjgp");
                    zChangedInstance2 = composerStartRestartGroup.changedInstance(coroutineScope) | composerStartRestartGroup.changed(drawerStateRememberDrawerState);
                    objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                    if (!zChangedInstance2) {
                        objRememberedValue3 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return NavGraphKt.StraitWatchNavGraph$lambda$2$0(coroutineScope, drawerStateRememberDrawerState);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                        final Function0 function022 = (Function0) objRememberedValue3;
                        ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        final Function3 function3M8892getLambda$996978615$app2 = ComposableSingletons$NavGraphKt.INSTANCE.m8892getLambda$996978615$app();
                        ComposableLambda composableLambdaRememberComposableLambda2 = ComposableLambdaKt.rememberComposableLambda(-278344836, true, new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return NavGraphKt.StraitWatchNavGraph$lambda$4(destination, navClickGuardRememberNavClickGuard2, function022, navHostController32, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, composerStartRestartGroup, 54);
                        Function2 function22 = new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return NavGraphKt.StraitWatchNavGraph$lambda$5(navHostController32, function03, navClickGuardRememberNavClickGuard2, function022, function3M8892getLambda$996978615$app2, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        };
                        navHostController2 = navHostController32;
                        NavigationDrawerKt.m2904ModalNavigationDrawerFHprtrg(composableLambdaRememberComposableLambda2, null, drawerStateRememberDrawerState, false, 0L, ComposableLambdaKt.rememberComposableLambda(-1352490601, true, function22, composerStartRestartGroup, 54), composerStartRestartGroup, 196614, 26);
                        if (ComposerKt.isTraceInProgress()) {
                        }
                    }
                }
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            navHostController2 = navHostControllerRememberNavController;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return NavGraphKt.StraitWatchNavGraph$lambda$6(navHostController2, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$1$0(CoroutineScope coroutineScope, DrawerState drawerState) {
        BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new NavGraphKt$StraitWatchNavGraph$openDrawer$1$1$1(drawerState, null), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$2$0(CoroutineScope coroutineScope, DrawerState drawerState) {
        BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new NavGraphKt$StraitWatchNavGraph$closeDrawer$1$1$1(drawerState, null), 3, null);
        return Unit.INSTANCE;
    }

    private static final void StraitWatchNavGraph$goTop(NavClickGuard navClickGuard, final Function0<Unit> function0, final NavHostController navHostController, final Object obj) {
        navClickGuard.run(new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda21
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return NavGraphKt.StraitWatchNavGraph$goTop$lambda$3(function0, navHostController, obj);
            }
        });
    }

    static final Unit StraitWatchNavGraph$goTop$lambda$3(Function0 function0, NavHostController navHostController, Object obj) {
        function0.invoke();
        navHostController.navigate((NavHostController) obj, new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj2) {
                return NavGraphKt.StraitWatchNavGraph$goTop$lambda$3$0((NavOptionsBuilder) obj2);
            }
        });
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$goTop$lambda$3$0(NavOptionsBuilder navigate) {
        Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo((NavOptionsBuilder) ChartRoomRoute.INSTANCE, new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return NavGraphKt.StraitWatchNavGraph$goTop$lambda$3$0$0((PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        navigate.setRestoreState(true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$goTop$lambda$3$0$0(PopUpToBuilder popUpTo) {
        Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setSaveState(true);
        return Unit.INSTANCE;
    }

    static final Unit StraitWatchNavGraph$lambda$4(final NavDestination navDestination, final NavClickGuard navClickGuard, final Function0 function0, final NavHostController navHostController, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C80@3316L2298,80@3299L2315:NavGraph.kt#dpq88o");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-278344836, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous> (NavGraph.kt:80)");
            }
            NavigationDrawerKt.m2903ModalDrawerSheetafqeVBk(null, null, 0L, 0L, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-302141608, true, new Function3() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return NavGraphKt.StraitWatchNavGraph$lambda$4$0(navDestination, navClickGuard, function0, navHostController, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer, 54), composer, 1572864, 63);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$4$0(NavDestination navDestination, final NavClickGuard navClickGuard, final Function0 function0, final NavHostController navHostController, ColumnScope ModalDrawerSheet, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(ModalDrawerSheet, "$this$ModalDrawerSheet");
        ComposerKt.sourceInformation(composer, "C81@3334L825,99@4176L19,*107@4691L351,116@5123L341,106@4637L945:NavGraph.kt#dpq88o");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-302141608, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous> (NavGraph.kt:81)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(Modifier.INSTANCE, Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8936getXsD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -470238254, "C86@3555L37,87@3640L10,85@3518L262,92@3838L40,93@3926L10,94@3994L11,91@3801L340:NavGraph.kt#dpq88o");
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.drawer_title, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.drawer_subtitle, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodySmall(), composer, 0, 24960, 110586);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            DividerKt.m2655HorizontalDivider9IZ8Weo(null, 0.0f, 0L, composer, 0, 7);
            Composer composer2 = composer;
            for (final DrawerEntry drawerEntry : DrawerEntry.getEntries()) {
                int i2 = WhenMappings.$EnumSwitchMapping$0[drawerEntry.ordinal()];
                Boolean boolValueOf = null;
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            throw new NoWhenBranchMatchedException();
                        }
                        if (navDestination != null) {
                            boolValueOf = Boolean.valueOf(NavDestination.INSTANCE.hasRoute(navDestination, Reflection.getOrCreateKotlinClass(BeaconSweepRoute.class)));
                        }
                    } else if (navDestination != null) {
                        boolValueOf = Boolean.valueOf(NavDestination.INSTANCE.hasRoute(navDestination, Reflection.getOrCreateKotlinClass(RegisterRoute.class)));
                    }
                } else if (navDestination != null) {
                    boolValueOf = Boolean.valueOf(NavDestination.INSTANCE.hasRoute(navDestination, Reflection.getOrCreateKotlinClass(ChartRoomRoute.class)));
                }
                boolean zAreEqual = Intrinsics.areEqual((Object) boolValueOf, (Object) true);
                ComposableLambda composableLambdaRememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(697366633, true, new Function2() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return NavGraphKt.StraitWatchNavGraph$lambda$4$0$1$0(drawerEntry, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer2, 54);
                ComposerKt.sourceInformationMarkerStart(composer2, -1223566301, "CC(remember):NavGraph.kt#9igjgp");
                boolean zChanged = composer2.changed(drawerEntry.ordinal()) | composer2.changedInstance(navClickGuard) | composer2.changed(function0) | composer2.changedInstance(navHostController);
                Object objRememberedValue = composer2.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return NavGraphKt.StraitWatchNavGraph$lambda$4$0$1$1$0(drawerEntry, navClickGuard, function0, navHostController);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                NavigationDrawerKt.NavigationDrawerItem(composableLambdaRememberComposableLambda, zAreEqual, (Function0) objRememberedValue, PaddingKt.padding(Modifier.INSTANCE, NavigationDrawerItemDefaults.INSTANCE.getItemPadding()), null, null, null, null, null, composer2, 6, 496);
                composer2 = composer;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$4$0$1$0(DrawerEntry drawerEntry, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C109@4766L30,110@4852L10,108@4721L295:NavGraph.kt#dpq88o");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(697366633, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous>.<anonymous>.<anonymous> (NavGraph.kt:108)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(drawerEntry.getLabelRes(), composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$4$0$1$1$0(DrawerEntry drawerEntry, NavClickGuard navClickGuard, Function0 function0, NavHostController navHostController) {
        int i = WhenMappings.$EnumSwitchMapping$0[drawerEntry.ordinal()];
        if (i == 1) {
            StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, ChartRoomRoute.INSTANCE);
        } else if (i == 2) {
            StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, RegisterRoute.INSTANCE);
        } else {
            if (i != 3) {
                throw new NoWhenBranchMatchedException();
            }
            StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, BeaconSweepRoute.INSTANCE);
        }
        return Unit.INSTANCE;
    }

    static final Unit StraitWatchNavGraph$lambda$5(final NavHostController navHostController, final Function0 function0, final NavClickGuard navClickGuard, final Function0 function02, final Function3 function3, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C129@5716L1099,129@5642L1173:NavGraph.kt#dpq88o");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1352490601, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous> (NavGraph.kt:129)");
            }
            ChartRoomRoute chartRoomRoute = ChartRoomRoute.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 1631626914, "CC(remember):NavGraph.kt#9igjgp");
            boolean zChanged = composer.changed(function0) | composer.changedInstance(navHostController) | composer.changedInstance(navClickGuard) | composer.changed(function02);
            Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                Function1 function1 = new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda22
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0(function0, navHostController, navClickGuard, function02, function3, (NavGraphBuilder) obj);
                    }
                };
                composer.updateRememberedValue(function1);
                objRememberedValue = function1;
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            NavHostKt.NavHost(navHostController, chartRoomRoute, (Modifier) null, (Alignment) null, (KClass<?>) null, (Map<KType, NavType<?>>) null, (Function1<AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<AnimatedContentTransitionScope<NavBackStackEntry>, SizeTransform>) null, (Function1<? super NavGraphBuilder, Unit>) objRememberedValue, composer, 48, 0, 2044);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0(final Function0 function0, final NavHostController navHostController, final NavClickGuard navClickGuard, final Function0 function02, final Function3 function3, NavGraphBuilder NavHost) {
        Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        ComposableLambda composableLambdaComposableLambdaInstance = ComposableLambdaKt.composableLambdaInstance(-161579914, true, new Function4() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$0(function0, navHostController, navClickGuard, function02, function3, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        });
        NavGraphBuilderKt.composable(NavHost, Reflection.getOrCreateKotlinClass(ChartRoomRoute.class), (Map<KType, NavType<?>>) MapsKt.emptyMap(), (List<NavDeepLink>) CollectionsKt.emptyList(), (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, SizeTransform>) null, composableLambdaComposableLambdaInstance);
        ComposableLambda composableLambdaComposableLambdaInstance2 = ComposableLambdaKt.composableLambdaInstance(1894401375, true, new Function4() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$1(function0, navHostController, function3, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        });
        NavGraphBuilderKt.composable(NavHost, Reflection.getOrCreateKotlinClass(RegisterRoute.class), (Map<KType, NavType<?>>) MapsKt.emptyMap(), (List<NavDeepLink>) CollectionsKt.emptyList(), (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, SizeTransform>) null, composableLambdaComposableLambdaInstance2);
        ComposableLambda composableLambdaComposableLambdaInstance3 = ComposableLambdaKt.composableLambdaInstance(1759818686, true, new Function4() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$2(function0, navClickGuard, function02, navHostController, function3, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        });
        NavGraphBuilderKt.composable(NavHost, Reflection.getOrCreateKotlinClass(BeaconSweepRoute.class), (Map<KType, NavType<?>>) MapsKt.emptyMap(), (List<NavDeepLink>) CollectionsKt.emptyList(), (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, SizeTransform>) null, composableLambdaComposableLambdaInstance3);
        ComposableLambda composableLambdaComposableLambdaInstance4 = ComposableLambdaKt.composableLambdaInstance(1625235997, true, new Function4() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function4
            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$3(navHostController, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
            }
        });
        NavGraphBuilderKt.composable(NavHost, Reflection.getOrCreateKotlinClass(PassageLogRoute.class), (Map<KType, NavType<?>>) MapsKt.emptyMap(), (List<NavDeepLink>) CollectionsKt.emptyList(), (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, EnterTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, ExitTransition>) null, (Function1<? super AnimatedContentTransitionScope<NavBackStackEntry>, SizeTransform>) null, composableLambdaComposableLambdaInstance4);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$0(Function0 function0, final NavHostController navHostController, final NavClickGuard navClickGuard, final Function0 function02, Function3 function3, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)133@5875L45,134@5959L24,135@6018L27,131@5775L336:NavGraph.kt#dpq88o");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-161579914, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous>.<anonymous>.<anonymous> (NavGraph.kt:131)");
        }
        ComposerKt.sourceInformationMarkerStart(composer, -659470877, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$0$0$0(navHostController, (String) obj);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        Function1 function1 = (Function1) objRememberedValue;
        ComposerKt.sourceInformationMarkerEnd(composer);
        ComposerKt.sourceInformationMarkerStart(composer, -659468210, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance2 = composer.changedInstance(navClickGuard) | composer.changed(function02) | composer.changedInstance(navHostController);
        Object objRememberedValue2 = composer.rememberedValue();
        if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
            objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$0$1$0(navClickGuard, function02, navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue2);
        }
        Function0 function03 = (Function0) objRememberedValue2;
        ComposerKt.sourceInformationMarkerEnd(composer);
        ComposerKt.sourceInformationMarkerStart(composer, -659466319, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance3 = composer.changedInstance(navClickGuard) | composer.changed(function02) | composer.changedInstance(navHostController);
        Object objRememberedValue3 = composer.rememberedValue();
        if (zChangedInstance3 || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
            objRememberedValue3 = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$0$2$0(navClickGuard, function02, navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue3);
        }
        ComposerKt.sourceInformationMarkerEnd(composer);
        ChartRoomScreenKt.ChartRoomScreen(function0, function1, function03, (Function0) objRememberedValue3, function3, null, composer, 24576, 32);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$0$0$0(NavHostController navHostController, String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        navigateToPassage(navHostController, id);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$0$1$0(NavClickGuard navClickGuard, Function0 function0, NavHostController navHostController) {
        StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, RegisterRoute.INSTANCE);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$0$2$0(NavClickGuard navClickGuard, Function0 function0, NavHostController navHostController) {
        StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, BeaconSweepRoute.INSTANCE);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$1(Function0 function0, final NavHostController navHostController, Function3 function3, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)142@6281L45,140@6182L210:NavGraph.kt#dpq88o");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(1894401375, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous>.<anonymous>.<anonymous> (NavGraph.kt:140)");
        }
        ComposerKt.sourceInformationMarkerStart(composer, -546408340, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$1$0$0(navHostController, (String) obj);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        ComposerKt.sourceInformationMarkerEnd(composer);
        RegisterScreenKt.RegisterScreen(function0, (Function1) objRememberedValue, function3, null, composer, 384, 8);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$1$0$0(NavHostController navHostController, String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        navigateToPassage(navHostController, id);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$2(Function0 function0, final NavClickGuard navClickGuard, final Function0 function02, final NavHostController navHostController, Function3 function3, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)149@6568L25,147@6466L193:NavGraph.kt#dpq88o");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(1759818686, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous>.<anonymous>.<anonymous> (NavGraph.kt:147)");
        }
        ComposerKt.sourceInformationMarkerStart(composer, -1031353513, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navClickGuard) | composer.changed(function02) | composer.changedInstance(navHostController);
        Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$2$0$0(navClickGuard, function02, navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        ComposerKt.sourceInformationMarkerEnd(composer);
        BeaconSweepScreenKt.BeaconSweepScreen(function0, (Function0) objRememberedValue, function3, null, composer, 384, 8);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$2$0$0(NavClickGuard navClickGuard, Function0 function0, NavHostController navHostController) {
        StraitWatchNavGraph$goTop(navClickGuard, function0, navHostController, ChartRoomRoute.INSTANCE);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$3(final NavHostController navHostController, AnimatedContentScope composable, NavBackStackEntry it, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(composable, "$this$composable");
        Intrinsics.checkNotNullParameter(it, "it");
        ComposerKt.sourceInformation(composer, "CN(it)154@6758L32,154@6732L59:NavGraph.kt#dpq88o");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(1625235997, i, -1, "com.chicken.road.nevsdomy.nav.StraitWatchNavGraph.<anonymous>.<anonymous>.<anonymous>.<anonymous> (NavGraph.kt:154)");
        }
        ComposerKt.sourceInformationMarkerStart(composer, -1516301187, "CC(remember):NavGraph.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return NavGraphKt.StraitWatchNavGraph$lambda$5$0$0$3$0$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        ComposerKt.sourceInformationMarkerEnd(composer);
        PassageLogScreenKt.PassageLogScreen((Function0) objRememberedValue, null, composer, 0, 2);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit StraitWatchNavGraph$lambda$5$0$0$3$0$0(NavHostController navHostController) {
        navHostController.popBackStack();
        return Unit.INSTANCE;
    }

    private static final void navigateToPassage(NavHostController navHostController, String str) {
        navHostController.navigate((NavHostController) new PassageLogRoute(str), new Function1() { // from class: com.chicken.road.nevsdomy.nav.NavGraphKt$$ExternalSyntheticLambda20
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return NavGraphKt.navigateToPassage$lambda$0((NavOptionsBuilder) obj);
            }
        });
    }

    static final Unit navigateToPassage$lambda$0(NavOptionsBuilder navigate) {
        Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.setLaunchSingleTop(true);
        return Unit.INSTANCE;
    }

    private static final NavBackStackEntry StraitWatchNavGraph$lambda$0(State<NavBackStackEntry> state) {
        return state.getValue();
    }
}
