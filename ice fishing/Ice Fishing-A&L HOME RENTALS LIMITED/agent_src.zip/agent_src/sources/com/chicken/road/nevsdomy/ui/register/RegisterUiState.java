package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.model.SortOrder;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterViewModel.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0019\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0007HÆ\u0003J\u000f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\n0\tHÆ\u0003J9\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tHÆ\u0001J\u0014\u0010\u001d\u001a\u00020\u00162\b\u0010\u001e\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u001f\u001a\u00020 HÖ\u0081\u0004J\n\u0010!\u001a\u00020\u0003HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u00168F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0017Ê\u0001\f\b#\u0012\b\b$\u0012\u0004\b\u0003\u0010\u0000¨\u0006\""}, d2 = {"Lcom/chicken/road/nevsdomy/ui/register/RegisterUiState;", "", "query", "", "activeTag", "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "sortOrder", "Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "sections", "", "Lcom/chicken/road/nevsdomy/ui/register/RegisterSection;", "<init>", "(Ljava/lang/String;Lcom/chicken/road/nevsdomy/data/model/StraitTag;Lcom/chicken/road/nevsdomy/data/model/SortOrder;Ljava/util/List;)V", "getQuery", "()Ljava/lang/String;", "getActiveTag", "()Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "getSortOrder", "()Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "getSections", "()Ljava/util/List;", "isEmpty", "", "()Z", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class RegisterUiState {
    public static final int $stable = 8;
    private final StraitTag activeTag;
    private final String query;
    private final List<RegisterSection> sections;
    private final SortOrder sortOrder;

    public RegisterUiState() {
        this(null, null, null, null, 15, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ RegisterUiState copy$default(RegisterUiState registerUiState, String str, StraitTag straitTag, SortOrder sortOrder, List list, int i, Object obj) {
        if ((i & 1) != 0) {
            str = registerUiState.query;
        }
        if ((i & 2) != 0) {
            straitTag = registerUiState.activeTag;
        }
        if ((i & 4) != 0) {
            sortOrder = registerUiState.sortOrder;
        }
        if ((i & 8) != 0) {
            list = registerUiState.sections;
        }
        return registerUiState.copy(str, straitTag, sortOrder, list);
    }

    /* renamed from: component1, reason: from getter */
    public final String getQuery() {
        return this.query;
    }

    /* renamed from: component2, reason: from getter */
    public final StraitTag getActiveTag() {
        return this.activeTag;
    }

    /* renamed from: component3, reason: from getter */
    public final SortOrder getSortOrder() {
        return this.sortOrder;
    }

    public final List<RegisterSection> component4() {
        return this.sections;
    }

    public final RegisterUiState copy(String query, StraitTag activeTag, SortOrder sortOrder, List<RegisterSection> sections) {
        Intrinsics.checkNotNullParameter(query, "query");
        Intrinsics.checkNotNullParameter(sortOrder, "sortOrder");
        Intrinsics.checkNotNullParameter(sections, "sections");
        return new RegisterUiState(query, activeTag, sortOrder, sections);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RegisterUiState)) {
            return false;
        }
        RegisterUiState registerUiState = (RegisterUiState) other;
        return Intrinsics.areEqual(this.query, registerUiState.query) && this.activeTag == registerUiState.activeTag && this.sortOrder == registerUiState.sortOrder && Intrinsics.areEqual(this.sections, registerUiState.sections);
    }

    public int hashCode() {
        int iHashCode = this.query.hashCode() * 31;
        StraitTag straitTag = this.activeTag;
        return ((((iHashCode + (straitTag == null ? 0 : straitTag.hashCode())) * 31) + this.sortOrder.hashCode()) * 31) + this.sections.hashCode();
    }

    public String toString() {
        return "RegisterUiState(query=" + this.query + ", activeTag=" + this.activeTag + ", sortOrder=" + this.sortOrder + ", sections=" + this.sections + ")";
    }

    public RegisterUiState(String query, StraitTag straitTag, SortOrder sortOrder, List<RegisterSection> sections) {
        Intrinsics.checkNotNullParameter(query, "query");
        Intrinsics.checkNotNullParameter(sortOrder, "sortOrder");
        Intrinsics.checkNotNullParameter(sections, "sections");
        this.query = query;
        this.activeTag = straitTag;
        this.sortOrder = sortOrder;
        this.sections = sections;
    }

    public /* synthetic */ RegisterUiState(String str, StraitTag straitTag, SortOrder sortOrder, List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "" : str, (i & 2) != 0 ? null : straitTag, (i & 4) != 0 ? SortOrder.REGISTER : sortOrder, (i & 8) != 0 ? CollectionsKt.emptyList() : list);
    }

    public final String getQuery() {
        return this.query;
    }

    public final StraitTag getActiveTag() {
        return this.activeTag;
    }

    public final SortOrder getSortOrder() {
        return this.sortOrder;
    }

    public final List<RegisterSection> getSections() {
        return this.sections;
    }

    public final boolean isEmpty() {
        return this.sections.isEmpty();
    }
}
