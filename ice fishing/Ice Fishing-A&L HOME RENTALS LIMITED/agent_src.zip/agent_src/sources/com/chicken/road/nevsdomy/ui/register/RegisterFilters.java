package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.model.SortOrder;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterViewModel.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B'\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J)\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0014\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0017\u001a\u00020\u0018HÖ\u0081\u0004J\n\u0010\u0019\u001a\u00020\u0003HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/register/RegisterFilters;", "", "query", "", "activeTag", "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "sortOrder", "Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "<init>", "(Ljava/lang/String;Lcom/chicken/road/nevsdomy/data/model/StraitTag;Lcom/chicken/road/nevsdomy/data/model/SortOrder;)V", "getQuery", "()Ljava/lang/String;", "getActiveTag", "()Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "getSortOrder", "()Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final /* data */ class RegisterFilters {
    private final StraitTag activeTag;
    private final String query;
    private final SortOrder sortOrder;

    public RegisterFilters() {
        this(null, null, null, 7, null);
    }

    public static /* synthetic */ RegisterFilters copy$default(RegisterFilters registerFilters, String str, StraitTag straitTag, SortOrder sortOrder, int i, Object obj) {
        if ((i & 1) != 0) {
            str = registerFilters.query;
        }
        if ((i & 2) != 0) {
            straitTag = registerFilters.activeTag;
        }
        if ((i & 4) != 0) {
            sortOrder = registerFilters.sortOrder;
        }
        return registerFilters.copy(str, straitTag, sortOrder);
    }

    /* renamed from: component1, reason: from getter */
    public final String getQuery() {
        return this.query;
    }

    /* renamed from: component2, reason: from getter */
    public final StraitTag getActiveTag() {
        return this.activeTag;
    }

    /* renamed from: component3, reason: from getter */
    public final SortOrder getSortOrder() {
        return this.sortOrder;
    }

    public final RegisterFilters copy(String query, StraitTag activeTag, SortOrder sortOrder) {
        Intrinsics.checkNotNullParameter(query, "query");
        Intrinsics.checkNotNullParameter(sortOrder, "sortOrder");
        return new RegisterFilters(query, activeTag, sortOrder);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RegisterFilters)) {
            return false;
        }
        RegisterFilters registerFilters = (RegisterFilters) other;
        return Intrinsics.areEqual(this.query, registerFilters.query) && this.activeTag == registerFilters.activeTag && this.sortOrder == registerFilters.sortOrder;
    }

    public int hashCode() {
        int iHashCode = this.query.hashCode() * 31;
        StraitTag straitTag = this.activeTag;
        return ((iHashCode + (straitTag == null ? 0 : straitTag.hashCode())) * 31) + this.sortOrder.hashCode();
    }

    public String toString() {
        return "RegisterFilters(query=" + this.query + ", activeTag=" + this.activeTag + ", sortOrder=" + this.sortOrder + ")";
    }

    public RegisterFilters(String query, StraitTag straitTag, SortOrder sortOrder) {
        Intrinsics.checkNotNullParameter(query, "query");
        Intrinsics.checkNotNullParameter(sortOrder, "sortOrder");
        this.query = query;
        this.activeTag = straitTag;
        this.sortOrder = sortOrder;
    }

    public /* synthetic */ RegisterFilters(String str, StraitTag straitTag, SortOrder sortOrder, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "" : str, (i & 2) != 0 ? null : straitTag, (i & 4) != 0 ? SortOrder.REGISTER : sortOrder);
    }

    public final String getQuery() {
        return this.query;
    }

    public final StraitTag getActiveTag() {
        return this.activeTag;
    }

    public final SortOrder getSortOrder() {
        return this.sortOrder;
    }
}
