package com.chicken.road.nevsdomy.ui.beaconsweep;

import androidx.core.app.NotificationCompat;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* compiled from: BeaconSweepViewModel.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0010\n\u0002\u0010\u0007\n\u0002\b\u000f\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B_\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n\u0012\b\b\u0002\u0010\f\u001a\u00020\n\u0012\b\b\u0002\u0010\r\u001a\u00020\n\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000f\u0010%\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\t\u0010&\u001a\u00020\nHÆ\u0003J\t\u0010'\u001a\u00020\nHÆ\u0003J\t\u0010(\u001a\u00020\nHÆ\u0003J\t\u0010)\u001a\u00020\nHÆ\u0003J\t\u0010*\u001a\u00020\u000fHÆ\u0003Ja\u0010+\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\r\u001a\u00020\n2\b\b\u0002\u0010\u000e\u001a\u00020\u000fHÆ\u0001J\u0014\u0010,\u001a\u00020\u000f2\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010.\u001a\u00020\nHÖ\u0081\u0004J\n\u0010/\u001a\u000200HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\f\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0011\u0010\r\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0011\u0010\u000e\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0011\u0010\u001f\u001a\u00020 8F¢\u0006\u0006\u001a\u0004\b!\u0010\"Ê\u0001\f\b2\u0012\b\b3\u0012\u0004\b\u0003\u0010\u0000¨\u00061"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;", "", "stage", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepStage;", NotificationCompat.CATEGORY_CALL, "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "tiles", "", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepTile;", "secondsLeft", "", "boardsCleared", "bestBoards", "runsPlayed", "beatTheRecord", "", "<init>", "(Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepStage;Lcom/chicken/road/nevsdomy/data/model/StraitTag;Ljava/util/List;IIIIZ)V", "getStage", "()Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepStage;", "getCall", "()Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "getTiles", "()Ljava/util/List;", "getSecondsLeft", "()I", "getBoardsCleared", "getBestBoards", "getRunsPlayed", "getBeatTheRecord", "()Z", "lampFraction", "", "getLampFraction", "()F", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class BeaconSweepUiState {
    public static final int $stable = 8;
    private final boolean beatTheRecord;
    private final int bestBoards;
    private final int boardsCleared;
    private final StraitTag call;
    private final int runsPlayed;
    private final int secondsLeft;
    private final SweepStage stage;
    private final List<SweepTile> tiles;

    public BeaconSweepUiState() {
        this(null, null, null, 0, 0, 0, 0, false, 255, null);
    }

    public static /* synthetic */ BeaconSweepUiState copy$default(BeaconSweepUiState beaconSweepUiState, SweepStage sweepStage, StraitTag straitTag, List list, int i, int i2, int i3, int i4, boolean z, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            sweepStage = beaconSweepUiState.stage;
        }
        if ((i5 & 2) != 0) {
            straitTag = beaconSweepUiState.call;
        }
        if ((i5 & 4) != 0) {
            list = beaconSweepUiState.tiles;
        }
        if ((i5 & 8) != 0) {
            i = beaconSweepUiState.secondsLeft;
        }
        if ((i5 & 16) != 0) {
            i2 = beaconSweepUiState.boardsCleared;
        }
        if ((i5 & 32) != 0) {
            i3 = beaconSweepUiState.bestBoards;
        }
        if ((i5 & 64) != 0) {
            i4 = beaconSweepUiState.runsPlayed;
        }
        if ((i5 & 128) != 0) {
            z = beaconSweepUiState.beatTheRecord;
        }
        int i6 = i4;
        boolean z2 = z;
        int i7 = i2;
        int i8 = i3;
        return beaconSweepUiState.copy(sweepStage, straitTag, list, i, i7, i8, i6, z2);
    }

    /* renamed from: component1, reason: from getter */
    public final SweepStage getStage() {
        return this.stage;
    }

    /* renamed from: component2, reason: from getter */
    public final StraitTag getCall() {
        return this.call;
    }

    public final List<SweepTile> component3() {
        return this.tiles;
    }

    /* renamed from: component4, reason: from getter */
    public final int getSecondsLeft() {
        return this.secondsLeft;
    }

    /* renamed from: component5, reason: from getter */
    public final int getBoardsCleared() {
        return this.boardsCleared;
    }

    /* renamed from: component6, reason: from getter */
    public final int getBestBoards() {
        return this.bestBoards;
    }

    /* renamed from: component7, reason: from getter */
    public final int getRunsPlayed() {
        return this.runsPlayed;
    }

    /* renamed from: component8, reason: from getter */
    public final boolean getBeatTheRecord() {
        return this.beatTheRecord;
    }

    public final BeaconSweepUiState copy(SweepStage stage, StraitTag call, List<SweepTile> tiles, int secondsLeft, int boardsCleared, int bestBoards, int runsPlayed, boolean beatTheRecord) {
        Intrinsics.checkNotNullParameter(stage, "stage");
        Intrinsics.checkNotNullParameter(tiles, "tiles");
        return new BeaconSweepUiState(stage, call, tiles, secondsLeft, boardsCleared, bestBoards, runsPlayed, beatTheRecord);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof BeaconSweepUiState)) {
            return false;
        }
        BeaconSweepUiState beaconSweepUiState = (BeaconSweepUiState) other;
        return this.stage == beaconSweepUiState.stage && this.call == beaconSweepUiState.call && Intrinsics.areEqual(this.tiles, beaconSweepUiState.tiles) && this.secondsLeft == beaconSweepUiState.secondsLeft && this.boardsCleared == beaconSweepUiState.boardsCleared && this.bestBoards == beaconSweepUiState.bestBoards && this.runsPlayed == beaconSweepUiState.runsPlayed && this.beatTheRecord == beaconSweepUiState.beatTheRecord;
    }

    public int hashCode() {
        int iHashCode = this.stage.hashCode() * 31;
        StraitTag straitTag = this.call;
        return ((((((((((((iHashCode + (straitTag == null ? 0 : straitTag.hashCode())) * 31) + this.tiles.hashCode()) * 31) + Integer.hashCode(this.secondsLeft)) * 31) + Integer.hashCode(this.boardsCleared)) * 31) + Integer.hashCode(this.bestBoards)) * 31) + Integer.hashCode(this.runsPlayed)) * 31) + Boolean.hashCode(this.beatTheRecord);
    }

    public String toString() {
        return "BeaconSweepUiState(stage=" + this.stage + ", call=" + this.call + ", tiles=" + this.tiles + ", secondsLeft=" + this.secondsLeft + ", boardsCleared=" + this.boardsCleared + ", bestBoards=" + this.bestBoards + ", runsPlayed=" + this.runsPlayed + ", beatTheRecord=" + this.beatTheRecord + ")";
    }

    public BeaconSweepUiState(SweepStage stage, StraitTag straitTag, List<SweepTile> tiles, int i, int i2, int i3, int i4, boolean z) {
        Intrinsics.checkNotNullParameter(stage, "stage");
        Intrinsics.checkNotNullParameter(tiles, "tiles");
        this.stage = stage;
        this.call = straitTag;
        this.tiles = tiles;
        this.secondsLeft = i;
        this.boardsCleared = i2;
        this.bestBoards = i3;
        this.runsPlayed = i4;
        this.beatTheRecord = z;
    }

    /*  JADX ERROR: NullPointerException in pass: InitCodeVariables
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.SSAVar.getPhiList()" because "resultVar" is null
        	at jadx.core.dex.visitors.InitCodeVariables.collectConnectedVars(InitCodeVariables.java:119)
        	at jadx.core.dex.visitors.InitCodeVariables.setCodeVar(InitCodeVariables.java:82)
        	at jadx.core.dex.visitors.InitCodeVariables.initCodeVar(InitCodeVariables.java:74)
        	at jadx.core.dex.visitors.InitCodeVariables.initCodeVars(InitCodeVariables.java:48)
        	at jadx.core.dex.visitors.InitCodeVariables.visit(InitCodeVariables.java:29)
        */
    public /* synthetic */ BeaconSweepUiState(com.chicken.road.nevsdomy.ui.beaconsweep.SweepStage r2, com.chicken.road.nevsdomy.data.model.StraitTag r3, java.util.List r4, int r5, int r6, int r7, int r8, boolean r9, int r10, kotlin.jvm.internal.DefaultConstructorMarker r11) {
        /*
            r1 = this;
            r11 = r10 & 1
            if (r11 == 0) goto L6
            com.chicken.road.nevsdomy.ui.beaconsweep.SweepStage r2 = com.chicken.road.nevsdomy.ui.beaconsweep.SweepStage.IDLE
        L6:
            r11 = r10 & 2
            if (r11 == 0) goto Lb
            r3 = 0
        Lb:
            r11 = r10 & 4
            if (r11 == 0) goto L13
            java.util.List r4 = kotlin.collections.CollectionsKt.emptyList()
        L13:
            r11 = r10 & 8
            if (r11 == 0) goto L19
            r5 = 40
        L19:
            r11 = r10 & 16
            r0 = 0
            if (r11 == 0) goto L1f
            r6 = r0
        L1f:
            r11 = r10 & 32
            if (r11 == 0) goto L24
            r7 = r0
        L24:
            r11 = r10 & 64
            if (r11 == 0) goto L29
            r8 = r0
        L29:
            r10 = r10 & 128(0x80, float:1.8E-43)
            if (r10 == 0) goto L37
            r11 = r0
            r9 = r7
            r10 = r8
            r7 = r5
            r8 = r6
            r5 = r3
            r6 = r4
            r3 = r1
            r4 = r2
            goto L40
        L37:
            r11 = r9
            r10 = r8
            r8 = r6
            r9 = r7
            r6 = r4
            r7 = r5
            r4 = r2
            r5 = r3
            r3 = r1
        L40:
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepUiState.<init>(com.chicken.road.nevsdomy.ui.beaconsweep.SweepStage, com.chicken.road.nevsdomy.data.model.StraitTag, java.util.List, int, int, int, int, boolean, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
    }

    public final SweepStage getStage() {
        return this.stage;
    }

    public final StraitTag getCall() {
        return this.call;
    }

    public final List<SweepTile> getTiles() {
        return this.tiles;
    }

    public final int getSecondsLeft() {
        return this.secondsLeft;
    }

    public final int getBoardsCleared() {
        return this.boardsCleared;
    }

    public final int getBestBoards() {
        return this.bestBoards;
    }

    public final int getRunsPlayed() {
        return this.runsPlayed;
    }

    public final boolean getBeatTheRecord() {
        return this.beatTheRecord;
    }

    public final float getLampFraction() {
        return RangesKt.coerceIn(this.secondsLeft / 40.0f, 0.0f, 1.0f);
    }
}
