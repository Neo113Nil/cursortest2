package com.chicken.road.nevsdomy.ui.passagelog;

/* loaded from: classes2.dex */
public final class PassageLogViewModel_HiltModules_BindsModule_Binds_LazyMapKey {
    static PassageLogViewModel keepFieldType = null;
    public static String lazyClassKeyName = "com.chicken.road.nevsdomy.ui.passagelog.PassageLogViewModel";
}
