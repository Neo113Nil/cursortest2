package com.chicken.road.nevsdomy.ui.chartroom;

import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import dagger.internal.Factory;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class ChartRoomViewModel_Factory implements Factory<ChartRoomViewModel> {
    private final Provider<StraitRepository> repositoryProvider;

    private ChartRoomViewModel_Factory(Provider<StraitRepository> repositoryProvider) {
        this.repositoryProvider = repositoryProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public ChartRoomViewModel get() {
        return newInstance(this.repositoryProvider.get());
    }

    public static ChartRoomViewModel_Factory create(Provider<StraitRepository> repositoryProvider) {
        return new ChartRoomViewModel_Factory(repositoryProvider);
    }

    public static ChartRoomViewModel newInstance(StraitRepository repository) {
        return new ChartRoomViewModel(repository);
    }
}
