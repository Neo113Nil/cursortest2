package com.chicken.road.nevsdomy;

/* loaded from: classes2.dex */
public interface StraitWatchApp_GeneratedInjector {
    void injectStraitWatchApp(StraitWatchApp straitWatchApp);
}
