package com.chicken.road.nevsdomy.ui.theme;

import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Theme.kt */
@Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a2\u0010\u0002\u001a\u00020\u00032\u0011\u0010\u0004\u001a\r\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\u0002\b\u0006H\u0007b\u0002\b\u0006b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u0007\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"StraitWatchColors", "Landroidx/compose/material3/ColorScheme;", "StraitWatchTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V", "Landroidx/compose/runtime/ComposableInferredTarget;", "scheme", "[0[0]]", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ThemeKt {
    private static final ColorScheme StraitWatchColors;

    static final Unit StraitWatchTheme$lambda$0(Function2 function2, int i, Composer composer, int i2) {
        StraitWatchTheme(function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static {
        long straitTeal = ColorKt.getStraitTeal();
        long onPrimaryWhite = ColorKt.getOnPrimaryWhite();
        long straitTealContainer = ColorKt.getStraitTealContainer();
        long straitTealOnContainer = ColorKt.getStraitTealOnContainer();
        long chartOchre = ColorKt.getChartOchre();
        long onPrimaryWhite2 = ColorKt.getOnPrimaryWhite();
        long chartOchreContainer = ColorKt.getChartOchreContainer();
        long chartOchreOnContainer = ColorKt.getChartOchreOnContainer();
        long straitTealDeep = ColorKt.getStraitTealDeep();
        long onPrimaryWhite3 = ColorKt.getOnPrimaryWhite();
        long parchmentBackground = ColorKt.getParchmentBackground();
        long onBackgroundInk = ColorKt.getOnBackgroundInk();
        long parchmentSurface = ColorKt.getParchmentSurface();
        long onBackgroundInk2 = ColorKt.getOnBackgroundInk();
        long parchmentVariant = ColorKt.getParchmentVariant();
        long onSurfaceMuted = ColorKt.getOnSurfaceMuted();
        long parchmentSurface2 = ColorKt.getParchmentSurface();
        long parchmentVariant2 = ColorKt.getParchmentVariant();
        long parchmentBackground2 = ColorKt.getParchmentBackground();
        StraitWatchColors = ColorSchemeKt.m2530lightColorScheme_VG5OTI$default(straitTeal, onPrimaryWhite, straitTealContainer, straitTealOnContainer, 0L, chartOchre, onPrimaryWhite2, chartOchreContainer, chartOchreOnContainer, straitTealDeep, onPrimaryWhite3, 0L, 0L, parchmentBackground, onBackgroundInk, parchmentSurface, onBackgroundInk2, parchmentVariant, onSurfaceMuted, 0L, 0L, 0L, ColorKt.getSweepMiss(), ColorKt.getOnPrimaryWhite(), ColorKt.getSweepMissContainer(), ColorKt.getSweepMissOnContainer(), ColorKt.getParchmentOutline(), ColorKt.getParchmentOutline(), 0L, 0L, parchmentSurface2, parchmentVariant2, 0L, parchmentBackground2, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 808982544, 65533, null);
    }

    public static final void StraitWatchTheme(Function2<? super Composer, ? super Integer, Unit> content, Composer composer, final int i) {
        int i2;
        final Function2<? super Composer, ? super Integer, Unit> function2;
        Intrinsics.checkNotNullParameter(content, "content");
        Composer composerStartRestartGroup = composer.startRestartGroup(-1144358461);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(StraitWatchTheme)N(content)38@1394L132:Theme.kt#lzqhre");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changedInstance(content) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            function2 = content;
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1144358461, i2, -1, "com.chicken.road.nevsdomy.ui.theme.StraitWatchTheme (Theme.kt:37)");
            }
            function2 = content;
            MaterialThemeKt.MaterialTheme(StraitWatchColors, null, TypeKt.getStraitWatchTypography(), function2, composerStartRestartGroup, ((i2 << 9) & 7168) | 6, 2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ThemeKt.StraitWatchTheme$lambda$0(function2, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }
}
