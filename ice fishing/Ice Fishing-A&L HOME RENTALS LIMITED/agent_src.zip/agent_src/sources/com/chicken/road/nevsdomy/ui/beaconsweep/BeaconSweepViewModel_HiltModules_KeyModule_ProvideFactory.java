package com.chicken.road.nevsdomy.ui.beaconsweep;

import com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel_HiltModules;
import dagger.internal.Factory;

/* loaded from: classes2.dex */
public final class BeaconSweepViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {
    @Override // javax.inject.Provider, jakarta.inject.Provider
    public Boolean get() {
        return Boolean.valueOf(provide());
    }

    public static BeaconSweepViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return InstanceHolder.INSTANCE;
    }

    public static boolean provide() {
        return BeaconSweepViewModel_HiltModules.KeyModule.provide();
    }

    private static final class InstanceHolder {
        static final BeaconSweepViewModel_HiltModules_KeyModule_ProvideFactory INSTANCE = new BeaconSweepViewModel_HiltModules_KeyModule_ProvideFactory();

        private InstanceHolder() {
        }
    }
}
