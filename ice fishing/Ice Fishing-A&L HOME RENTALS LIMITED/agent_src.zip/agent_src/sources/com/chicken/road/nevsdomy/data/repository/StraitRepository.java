package com.chicken.road.nevsdomy.data.repository;

import androidx.compose.foundation.style.StylePropertiesKt;
import androidx.core.view.MotionEventCompat;
import com.chicken.road.nevsdomy.data.db.CrossingDao;
import com.chicken.road.nevsdomy.data.db.CrossingEntity;
import com.chicken.road.nevsdomy.data.db.SweepStatsDao;
import com.chicken.road.nevsdomy.data.db.SweepStatsEntity;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.seed.StraitSeed;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.Flow;

/* compiled from: StraitRepository.kt */
@Singleton
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u001d\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u001a\u0002\b\b¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u000f\u001a\u00020\u0010J\u0018\u0010\u0011\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00140\u00130\u0012J\u0016\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00140\u00122\u0006\u0010\u0016\u001a\u00020\u0010J\u001e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0016\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u0014H\u0086@¢\u0006\u0002\u0010\u001aJ\u0016\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u0016\u001a\u00020\u0010H\u0086@¢\u0006\u0002\u0010\u001cJ\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001e0\u0012J\u0016\u0010\u001f\u001a\u00020\u00182\u0006\u0010 \u001a\u00020!H\u0086@¢\u0006\u0002\u0010\"R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rÊ\u0001\u0002\b$Ê\u0001\f\b%\u0012\b\b&\u0012\u0004\b\u0003\u0010\u0002¨\u0006#"}, d2 = {"Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;", "", "crossingDao", "Lcom/chicken/road/nevsdomy/data/db/CrossingDao;", "sweepStatsDao", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;", "<init>", "(Lcom/chicken/road/nevsdomy/data/db/CrossingDao;Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;)V", "Ljavax/inject/Inject;", "straits", "", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "getStraits", "()Ljava/util/List;", "straitById", "id", "", "observeCrossings", "Lkotlinx/coroutines/flow/Flow;", "", "", "observeCrossing", "straitId", "logCrossing", "", "epochMillis", "(Ljava/lang/String;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "clearCrossing", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "observeSweepStats", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;", "recordSweepRun", "boardsCleared", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app", "Ljavax/inject/Singleton;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class StraitRepository {
    public static final int $stable = 0;
    private final CrossingDao crossingDao;
    private final List<Strait> straits;
    private final SweepStatsDao sweepStatsDao;

    /* compiled from: StraitRepository.kt */
    @Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
    @DebugMetadata(c = "com.chicken.road.nevsdomy.data.repository.StraitRepository", f = "StraitRepository.kt", i = {0, 1, 1}, l = {MotionEventCompat.AXIS_GENERIC_15, MotionEventCompat.AXIS_GENERIC_16}, m = "recordSweepRun", n = {"boardsCleared", "current", "boardsCleared"}, nl = {MotionEventCompat.AXIS_GENERIC_16, StylePropertiesKt.ShapeId}, s = {"I$0", "L$0", "I$0"}, v = 2)
    /* renamed from: com.chicken.road.nevsdomy.data.repository.StraitRepository$recordSweepRun$1, reason: invalid class name */
    static final class AnonymousClass1 extends ContinuationImpl {
        int I$0;
        Object L$0;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return StraitRepository.this.recordSweepRun(0, this);
        }
    }

    @Inject
    public StraitRepository(CrossingDao crossingDao, SweepStatsDao sweepStatsDao) {
        Intrinsics.checkNotNullParameter(crossingDao, "crossingDao");
        Intrinsics.checkNotNullParameter(sweepStatsDao, "sweepStatsDao");
        this.crossingDao = crossingDao;
        this.sweepStatsDao = sweepStatsDao;
        this.straits = StraitSeed.INSTANCE.getStraits();
    }

    public final List<Strait> getStraits() {
        return this.straits;
    }

    public final Strait straitById(String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = this.straits.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((Strait) next).getId(), id)) {
                break;
            }
        }
        return (Strait) next;
    }

    public final Flow<Map<String, Long>> observeCrossings() {
        return new StraitRepository$observeCrossings$$inlined$map$1(this.crossingDao.observeAll());
    }

    public final Flow<Long> observeCrossing(String straitId) {
        Intrinsics.checkNotNullParameter(straitId, "straitId");
        return new StraitRepository$observeCrossing$$inlined$map$1(this.crossingDao.observeOne(straitId));
    }

    public final Object logCrossing(String str, long j, Continuation<? super Unit> continuation) {
        return this.crossingDao.upsert(new CrossingEntity(str, j), continuation);
    }

    public final Object clearCrossing(String str, Continuation<? super Unit> continuation) {
        return this.crossingDao.deleteById(str, continuation);
    }

    public final Flow<SweepStatsEntity> observeSweepStats() {
        return new StraitRepository$observeSweepStats$$inlined$map$1(this.sweepStatsDao.observe());
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object recordSweepRun(int i, Continuation<? super Unit> continuation) {
        AnonymousClass1 anonymousClass1;
        if (continuation instanceof AnonymousClass1) {
            anonymousClass1 = (AnonymousClass1) continuation;
            if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                anonymousClass1.label -= Integer.MIN_VALUE;
            } else {
                anonymousClass1 = new AnonymousClass1(continuation);
            }
        }
        Object objCurrent = anonymousClass1.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i2 = anonymousClass1.label;
        if (i2 == 0) {
            ResultKt.throwOnFailure(objCurrent);
            SweepStatsDao sweepStatsDao = this.sweepStatsDao;
            anonymousClass1.I$0 = i;
            anonymousClass1.label = 1;
            objCurrent = sweepStatsDao.current(anonymousClass1);
            if (objCurrent != coroutine_suspended) {
            }
        }
        if (i2 != 1) {
            if (i2 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            int i3 = anonymousClass1.I$0;
            ResultKt.throwOnFailure(objCurrent);
            return objCurrent;
        }
        i = anonymousClass1.I$0;
        ResultKt.throwOnFailure(objCurrent);
        SweepStatsEntity sweepStatsEntity = (SweepStatsEntity) objCurrent;
        SweepStatsEntity sweepStatsEntity2 = sweepStatsEntity == null ? new SweepStatsEntity(0, 0, 0, 7, null) : sweepStatsEntity;
        SweepStatsDao sweepStatsDao2 = this.sweepStatsDao;
        SweepStatsEntity sweepStatsEntityCopy$default = SweepStatsEntity.copy$default(sweepStatsEntity2, 0, Math.max(sweepStatsEntity2.getBestBoards(), i), sweepStatsEntity2.getRunsPlayed() + 1, 1, null);
        anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(sweepStatsEntity2);
        anonymousClass1.I$0 = i;
        anonymousClass1.label = 2;
        Object objUpsert = sweepStatsDao2.upsert(sweepStatsEntityCopy$default, anonymousClass1);
        return objUpsert == coroutine_suspended ? coroutine_suspended : objUpsert;
    }
}
