package com.chicken.road.nevsdomy.ui.register;

import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.style.StylePropertiesKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material3.AndroidMenu_androidKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.ChipKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambda;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.input.nestedscroll.NestedScrollModifierKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.compose.ui.unit.Dp;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.data.model.SortOrder;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.nav.NavClickGuard;
import com.chicken.road.nevsdomy.nav.NavClickGuardKt;
import com.chicken.road.nevsdomy.ui.common.ComponentsKt;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;

/* compiled from: RegisterScreen.kt */
@Metadata(d1 = {"\u0000f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\u001aj\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00050\t2\u001d\u0010\u000b\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0007\u0012\u0004\u0012\u00020\u00050\t¢\u0006\u0002\b\f2\b\b\u0002\u0010\r\u001a\u00020\u000eH\u0007b\u0002\b\fb\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0012¢\u0006\u0002\u0010\u000f\u001a=\u0010\u0013\u001a\u00020\u00052\b\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00050\tH\u0003b\u0002\b\fb\f\b\u0018\u0012\b\b\u0019\u0012\u0004\b\b(\u001a¢\u0006\u0002\u0010\u0017\u001a;\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u001d2\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u00050\tH\u0003b\u0002\b\fb\f\b\u0018\u0012\b\b\u0019\u0012\u0004\b\b(\u001a¢\u0006\u0002\u0010\u001f\u001a/\u0010 \u001a\u00020\u00052\u0006\u0010!\u001a\u00020\n2\u0006\u0010\"\u001a\u00020#H\u0003b\u0002\b\fb\f\b\u0018\u0012\b\b\u0019\u0012\u0004\b\b(\u001a¢\u0006\u0002\u0010$\u001a5\u0010%\u001a\u00020\u00052\u0006\u0010&\u001a\u00020'2\f\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007H\u0003b\u0002\b\fb\f\b\u0018\u0012\b\b\u0019\u0012\u0004\b\b(\u001a¢\u0006\u0002\u0010)\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006*²\u0006\n\u0010+\u001a\u00020,X\u008a\u0084\u0002²\u0006\n\u0010-\u001a\u00020.X\u008a\u008e\u0002"}, d2 = {"TileWidth", "Landroidx/compose/ui/unit/Dp;", "F", "TileEmoji", "RegisterScreen", "", "onOpenDrawer", "Lkotlin/Function0;", "onOpenPassage", "Lkotlin/Function1;", "", "navigationIcon", "Landroidx/compose/runtime/Composable;", "viewModel", "Lcom/chicken/road/nevsdomy/ui/register/RegisterViewModel;", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function3;Lcom/chicken/road/nevsdomy/ui/register/RegisterViewModel;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/ComposableInferredTarget;", "scheme", "[androidx.compose.ui.UiComposable[androidx.compose.ui.UiComposable]]", "TagRow", "activeTag", "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "onTagClick", "(Lcom/chicken/road/nevsdomy/data/model/StraitTag;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "Landroidx/compose/runtime/ComposableTarget;", "applier", "androidx.compose.ui.UiComposable", "SortControl", "current", "Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "onSelected", "(Lcom/chicken/road/nevsdomy/data/model/SortOrder;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "SectionHeader", "title", "count", "", "(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)V", "StraitTile", "strait", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "onClick", "(Lcom/chicken/road/nevsdomy/data/model/Strait;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app", "state", "Lcom/chicken/road/nevsdomy/ui/register/RegisterUiState;", "expanded", ""}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class RegisterScreenKt {
    private static final float TileWidth = Dp.m8373constructorimpl(168.0f);
    private static final float TileEmoji = Dp.m8373constructorimpl(64.0f);

    static final Unit RegisterScreen$lambda$3(Function0 function0, Function1 function1, Function3 function3, RegisterViewModel registerViewModel, int i, int i2, Composer composer, int i3) {
        RegisterScreen(function0, function1, function3, registerViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit SectionHeader$lambda$1(String str, int i, int i2, Composer composer, int i3) {
        SectionHeader(str, i, composer, RecomposeScopeImplKt.updateChangedFlags(i2 | 1));
        return Unit.INSTANCE;
    }

    static final Unit SortControl$lambda$4(SortOrder sortOrder, Function1 function1, int i, Composer composer, int i2) {
        SortControl(sortOrder, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit StraitTile$lambda$1(Strait strait, Function0 function0, int i, Composer composer, int i2) {
        StraitTile(strait, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit TagRow$lambda$1(StraitTag straitTag, Function1 function1, int i, Composer composer, int i2) {
        TagRow(straitTag, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x017f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void RegisterScreen(final Function0<Unit> onOpenDrawer, final Function1<? super String, Unit> onOpenPassage, final Function3<? super Function0<Unit>, ? super Composer, ? super Integer, Unit> navigationIcon, RegisterViewModel registerViewModel, Composer composer, final int i, final int i2) {
        int i3;
        boolean z;
        int i4;
        int i5;
        final RegisterViewModel registerViewModel2 = registerViewModel;
        Intrinsics.checkNotNullParameter(onOpenDrawer, "onOpenDrawer");
        Intrinsics.checkNotNullParameter(onOpenPassage, "onOpenPassage");
        Intrinsics.checkNotNullParameter(navigationIcon, "navigationIcon");
        Composer composerStartRestartGroup = composer.startRestartGroup(-942579818);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(RegisterScreen)N(onOpenDrawer,onOpenPassage,navigationIcon,viewModel)71@3202L29,72@3275L22,73@3314L23,77@3451L654,94@4113L3637,75@3343L4407:RegisterScreen.kt#zd2u8u");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(onOpenDrawer) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onOpenPassage) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navigationIcon) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            if ((i2 & 8) != 0) {
                i5 = 1024;
                i3 |= i5;
            } else {
                if ((i & 4096) == 0 ? composerStartRestartGroup.changed(registerViewModel2) : composerStartRestartGroup.changedInstance(registerViewModel2)) {
                    i5 = 2048;
                }
                i3 |= i5;
            }
        }
        int i6 = i3;
        if (composerStartRestartGroup.shouldExecute((i6 & 1171) != 1170, i6 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "69@3146L15");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 8) != 0) {
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1192010736, "CC(hiltViewModel)N(viewModelStoreOwner,key)40@1717L7,45@1869L81,46@1962L54:HiltViewModel.kt#gplxbw");
                    ViewModelStoreOwner current = LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    ViewModelProvider.Factory factoryRememberHiltViewModelFactory = HiltViewModelKt.rememberHiltViewModelFactory(ViewModelStoreOwnerDefaults.getViewModelProviderFactory(current), composerStartRestartGroup, 0, 0);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1729797275, "CC(viewModel)N(viewModelStoreOwner,key,factory,extras)58@2688L7,64@2951L63:ViewModel.kt#3tja67");
                    ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(RegisterViewModel.class), current, (String) null, factoryRememberHiltViewModelFactory, ViewModelStoreOwnerDefaults.getViewModelCreationExtras(current), composerStartRestartGroup, 0, 0);
                    composerStartRestartGroup = composerStartRestartGroup;
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    RegisterViewModel registerViewModel3 = (RegisterViewModel) viewModel;
                    i6 &= -7169;
                    z = true;
                    registerViewModel2 = registerViewModel3;
                    i4 = 0;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-942579818, i6, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen (RegisterScreen.kt:70)");
                }
                boolean z2 = z;
                Composer composer2 = composerStartRestartGroup;
                final State stateCollectAsStateWithLifecycle = FlowExtKt.collectAsStateWithLifecycle(registerViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer2, 0, 7);
                final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer2, 384, 3);
                final NavClickGuard navClickGuardRememberNavClickGuard = NavClickGuardKt.rememberNavClickGuard(composer2, i4);
                ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(533375826, z2, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda23
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return RegisterScreenKt.RegisterScreen$lambda$1(topAppBarScrollBehaviorPinnedScrollBehavior, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer2, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(-498738201, z2, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda24
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return RegisterScreenKt.RegisterScreen$lambda$2(stateCollectAsStateWithLifecycle, registerViewModel2, navClickGuardRememberNavClickGuard, onOpenPassage, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 508);
                composerStartRestartGroup = composer2;
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 8) != 0) {
                    i6 &= -7169;
                }
            }
            i4 = 0;
            z = true;
            composerStartRestartGroup.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
            }
            boolean z22 = z;
            Composer composer22 = composerStartRestartGroup;
            final State stateCollectAsStateWithLifecycle2 = FlowExtKt.collectAsStateWithLifecycle(registerViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer22, 0, 7);
            final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior2 = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer22, 384, 3);
            final NavClickGuard navClickGuardRememberNavClickGuard2 = NavClickGuardKt.rememberNavClickGuard(composer22, i4);
            ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior2.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(533375826, z22, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda23
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.RegisterScreen$lambda$1(topAppBarScrollBehaviorPinnedScrollBehavior2, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer22, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(-498738201, z22, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda24
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return RegisterScreenKt.RegisterScreen$lambda$2(stateCollectAsStateWithLifecycle2, registerViewModel2, navClickGuardRememberNavClickGuard2, onOpenPassage, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer22, 54), composer22, 805306416, 508);
            composerStartRestartGroup = composer22;
            if (ComposerKt.isTraceInProgress()) {
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        final RegisterViewModel registerViewModel4 = registerViewModel2;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda25
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.RegisterScreen$lambda$3(onOpenDrawer, onOpenPassage, navigationIcon, registerViewModel4, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$1$0(Function3 function3, Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C86@3773L28:RegisterScreen.kt#zd2u8u");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1201244696, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous> (RegisterScreen.kt:86)");
            }
            function3.invoke(function0, composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    static final Unit RegisterScreen$lambda$1(TopAppBarScrollBehavior topAppBarScrollBehavior, final Function3 function3, final Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C89@3965L11,90@4040L11,88@3897L183,86@3771L32,78@3465L630:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(533375826, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous> (RegisterScreen.kt:78)");
            }
            AppBarKt.m2345TopAppBarGHTll3U(ComposableSingletons$RegisterScreenKt.INSTANCE.m8921getLambda$1957778154$app(), null, ComposableLambdaKt.rememberComposableLambda(1201244696, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda20
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.RegisterScreen$lambda$1$0(function3, function0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), null, 0.0f, null, TopAppBarDefaults.INSTANCE.m3543topAppBarColors5tl4gsc(MaterialTheme.INSTANCE.getColorScheme(composer, 6).getSurface(), 0L, 0L, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurface(), 0L, 0L, composer, 1572864, 54), topAppBarScrollBehavior, composer, 390, 58);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit RegisterScreen$lambda$2(final State state, final RegisterViewModel registerViewModel, final NavClickGuard navClickGuard, final Function1 function1, PaddingValues innerPadding, Composer composer, int i) {
        int i2;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation(composer, "CN(innerPadding)101@4421L3323,95@4139L3605:RegisterScreen.kt#zd2u8u");
        if ((i & 6) == 0) {
            i2 = i | (composer.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if (!composer.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-498738201, i2, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous> (RegisterScreen.kt:95)");
            }
            Modifier modifierPadding = PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding);
            PaddingValues paddingValuesM1084PaddingValuesYgX7TsA = PaddingKt.m1084PaddingValuesYgX7TsA(Spacing.INSTANCE.m8932getLD9Ej5fM(), Spacing.INSTANCE.m8933getMD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1748939170, "CC(remember):RegisterScreen.kt#9igjgp");
            boolean zChanged = composer.changed(state) | composer.changedInstance(registerViewModel) | composer.changedInstance(navClickGuard) | composer.changed(function1);
            Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda18
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return RegisterScreenKt.RegisterScreen$lambda$2$0$0(registerViewModel, state, navClickGuard, function1, (LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            LazyDslKt.LazyColumn(modifierPadding, null, paddingValuesM1084PaddingValuesYgX7TsA, false, horizontalOrVerticalM782spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, composer, 0, 490);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0(final RegisterViewModel registerViewModel, final State state, final NavClickGuard navClickGuard, final Function1 function1, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(642991420, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return RegisterScreenKt.RegisterScreen$lambda$2$0$0$0(registerViewModel, state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-1118794509, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return RegisterScreenKt.RegisterScreen$lambda$2$0$0$1(registerViewModel, state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1944880244, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return RegisterScreenKt.RegisterScreen$lambda$2$0$0$2(registerViewModel, state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        if (RegisterScreen$lambda$0(state).isEmpty()) {
            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$RegisterScreenKt.INSTANCE.getLambda$2090042647$app(), 3, null);
        } else {
            for (final RegisterSection registerSection : RegisterScreen$lambda$0(state).getSections()) {
                LazyListScope.item$default(LazyColumn, registerSection.getBasin().name(), null, ComposableLambdaKt.composableLambdaInstance(2002729419, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return RegisterScreenKt.RegisterScreen$lambda$2$0$0$3$0(registerSection, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }), 2, null);
                LazyListScope.item$default(LazyColumn, registerSection.getBasin().name() + "-row", null, ComposableLambdaKt.composableLambdaInstance(1417890178, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return RegisterScreenKt.RegisterScreen$lambda$2$0$0$3$1(registerSection, navClickGuard, function1, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }), 2, null);
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$0(final RegisterViewModel registerViewModel, final State state, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C105@4554L24,123@5406L452,103@4458L1419:RegisterScreen.kt#zd2u8u");
        if (composer.shouldExecute((i & 17) != 16, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(642991420, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:103)");
            }
            String query = RegisterScreen$lambda$0(state).getQuery();
            ComposerKt.sourceInformationMarkerStart(composer, -560532332, "CC(remember):RegisterScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(registerViewModel);
            RegisterScreenKt$RegisterScreen$2$1$1$1$1$1 registerScreenKt$RegisterScreen$2$1$1$1$1$1RememberedValue = composer.rememberedValue();
            if (zChangedInstance || registerScreenKt$RegisterScreen$2$1$1$1$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                registerScreenKt$RegisterScreen$2$1$1$1$1$1RememberedValue = new RegisterScreenKt$RegisterScreen$2$1$1$1$1$1(registerViewModel);
                composer.updateRememberedValue(registerScreenKt$RegisterScreen$2$1$1$1$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            OutlinedTextFieldKt.OutlinedTextField(query, (Function1<? super String, Unit>) ((KFunction) registerScreenKt$RegisterScreen$2$1$1$1$1$1RememberedValue), SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$RegisterScreenKt.INSTANCE.m8920getLambda$1905890379$app(), (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$RegisterScreenKt.INSTANCE.getLambda$996143508$app(), (Function2<? super Composer, ? super Integer, Unit>) ComposableLambdaKt.rememberComposableLambda(-396789901, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.RegisterScreen$lambda$2$0$0$0$1(registerViewModel, state, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), (TextFieldColors) null, composer, 918552960, 12582912, 0, 6159480);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$0$1(RegisterViewModel registerViewModel, State state, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-396789901, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:124)");
            }
            if (RegisterScreen$lambda$0(state).getQuery().length() > 0) {
                composer.startReplaceGroup(-1017874951);
                ComposerKt.sourceInformation(composer, "125@5513L23,125@5492L318");
                ComposerKt.sourceInformationMarkerStart(composer, 936997930, "CC(remember):RegisterScreen.kt#9igjgp");
                boolean zChangedInstance = composer.changedInstance(registerViewModel);
                RegisterScreenKt$RegisterScreen$2$1$1$1$2$1$1 registerScreenKt$RegisterScreen$2$1$1$1$2$1$1RememberedValue = composer.rememberedValue();
                if (zChangedInstance || registerScreenKt$RegisterScreen$2$1$1$1$2$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                    registerScreenKt$RegisterScreen$2$1$1$1$2$1$1RememberedValue = new RegisterScreenKt$RegisterScreen$2$1$1$1$2$1$1(registerViewModel);
                    composer.updateRememberedValue(registerScreenKt$RegisterScreen$2$1$1$1$2$1$1RememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                IconButtonKt.IconButton((Function0) ((KFunction) registerScreenKt$RegisterScreen$2$1$1$1$2$1$1RememberedValue), null, false, null, null, null, ComposableSingletons$RegisterScreenKt.INSTANCE.m8922getLambda$517288166$app(), composer, 1572864, 62);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-1017515537);
                composer.endReplaceGroup();
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$1(RegisterViewModel registerViewModel, State state, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C138@6017L21,136@5927L130:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1118794509, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:136)");
            }
            StraitTag activeTag = RegisterScreen$lambda$0(state).getActiveTag();
            ComposerKt.sourceInformationMarkerStart(composer, -1419695672, "CC(remember):RegisterScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(registerViewModel);
            RegisterScreenKt$RegisterScreen$2$1$1$2$1$1 registerScreenKt$RegisterScreen$2$1$1$2$1$1RememberedValue = composer.rememberedValue();
            if (zChangedInstance || registerScreenKt$RegisterScreen$2$1$1$2$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                registerScreenKt$RegisterScreen$2$1$1$2$1$1RememberedValue = new RegisterScreenKt$RegisterScreen$2$1$1$2$1$1(registerViewModel);
                composer.updateRememberedValue(registerScreenKt$RegisterScreen$2$1$1$2$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            TagRow(activeTag, (Function1) ((KFunction) registerScreenKt$RegisterScreen$2$1$1$2$1$1RememberedValue), composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$2(RegisterViewModel registerViewModel, State state, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C144@6200L25,142@6107L137:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1944880244, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:142)");
            }
            SortOrder sortOrder = RegisterScreen$lambda$0(state).getSortOrder();
            ComposerKt.sourceInformationMarkerStart(composer, 719144301, "CC(remember):RegisterScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(registerViewModel);
            RegisterScreenKt$RegisterScreen$2$1$1$3$1$1 registerScreenKt$RegisterScreen$2$1$1$3$1$1RememberedValue = composer.rememberedValue();
            if (zChangedInstance || registerScreenKt$RegisterScreen$2$1$1$3$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                registerScreenKt$RegisterScreen$2$1$1$3$1$1RememberedValue = new RegisterScreenKt$RegisterScreen$2$1$1$3$1$1(registerViewModel);
                composer.updateRememberedValue(registerScreenKt$RegisterScreen$2$1$1$3$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            SortControl(sortOrder, (Function1) ((KFunction) registerScreenKt$RegisterScreen$2$1$1$3$1$1RememberedValue), composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$3$0(RegisterSection registerSection, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C159@6823L38,158@6772L174:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2002729419, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:158)");
            }
            SectionHeader(StringResources_androidKt.stringResource(registerSection.getBasin().getTitleRes(), composer, 0), registerSection.getStraits().size(), composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$3$1(final RegisterSection registerSection, final NavClickGuard navClickGuard, final Function1 function1, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C168@7322L358,164@7055L625:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1417890178, i, -1, "com.chicken.road.nevsdomy.ui.register.RegisterScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:164)");
            }
            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            PaddingValues paddingValuesM1085PaddingValuesYgX7TsA$default = PaddingKt.m1085PaddingValuesYgX7TsA$default(0.0f, Spacing.INSTANCE.m8936getXsD9Ej5fM(), 1, null);
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1087837960, "CC(remember):RegisterScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(registerSection) | composer.changedInstance(navClickGuard) | composer.changed(function1);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return RegisterScreenKt.RegisterScreen$lambda$2$0$0$3$1$0$0(registerSection, navClickGuard, function1, (LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            LazyDslKt.LazyRow(modifierFillMaxWidth$default, null, paddingValuesM1085PaddingValuesYgX7TsA$default, false, horizontalOrVerticalM782spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, composer, 6, 490);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit RegisterScreen$lambda$2$0$0$3$1$0$0(RegisterSection registerSection, final NavClickGuard navClickGuard, final Function1 function1, LazyListScope LazyRow) {
        Intrinsics.checkNotNullParameter(LazyRow, "$this$LazyRow");
        final List<Strait> straits = registerSection.getStraits();
        final Function1 function12 = new Function1() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda17
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return RegisterScreenKt.RegisterScreen$lambda$2$0$0$3$1$0$0$0((Strait) obj);
            }
        };
        final RegisterScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$1 registerScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$1 = new Function1() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(Strait strait) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                return invoke((Strait) obj);
            }
        };
        LazyRow.items(straits.size(), new Function1<Integer, Object>() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$2
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                return function12.invoke(straits.get(i));
            }
        }, new Function1<Integer, Object>() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                return registerScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$1.invoke(straits.get(i));
            }
        }, ComposableLambdaKt.composableLambdaInstance(802480018, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$lambda$2$0$0$3$1$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope lazyItemScope, int i, Composer composer, int i2) {
                int i3;
                ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final Strait strait = (Strait) straits.get(i);
                composer.startReplaceGroup(1886207413);
                ComposerKt.sourceInformation(composer, "CN(strait)*172@7547L42,170@7436L188:RegisterScreen.kt#zd2u8u");
                ComposerKt.sourceInformationMarkerStart(composer, 1861964124, "CC(remember):RegisterScreen.kt#9igjgp");
                boolean zChangedInstance = composer.changedInstance(navClickGuard) | composer.changed(function1) | composer.changedInstance(strait);
                Object objRememberedValue = composer.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    final NavClickGuard navClickGuard2 = navClickGuard;
                    final Function1 function13 = function1;
                    objRememberedValue = (Function0) new Function0<Unit>() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$2$1$1$4$2$1$1$2$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            NavClickGuard navClickGuard3 = navClickGuard2;
                            final Function1<String, Unit> function14 = function13;
                            final Strait strait2 = strait;
                            navClickGuard3.run(new Function0<Unit>() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$RegisterScreen$2$1$1$4$2$1$1$2$1$1.1
                                @Override // kotlin.jvm.functions.Function0
                                public /* bridge */ /* synthetic */ Unit invoke() {
                                    invoke2();
                                    return Unit.INSTANCE;
                                }

                                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                                public final void invoke2() {
                                    function14.invoke(strait2.getId());
                                }
                            });
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                RegisterScreenKt.StraitTile(strait, (Function0) objRememberedValue, composer, Strait.$stable);
                composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object RegisterScreen$lambda$2$0$0$3$1$0$0$0(Strait it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getId();
    }

    private static final void TagRow(final StraitTag straitTag, final Function1<? super StraitTag, Unit> function1, Composer composer, final int i) {
        int i2;
        Composer composer2;
        Composer composerStartRestartGroup = composer.startRestartGroup(-1715339015);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(TagRow)N(activeTag,onTagClick)186@7897L21,185@7847L1077:RegisterScreen.kt#zd2u8u");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(straitTag == null ? -1 : straitTag.ordinal()) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        int i3 = 32;
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function1) ? 32 : 16;
        }
        boolean z = true;
        boolean z2 = false;
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1715339015, i2, -1, "com.chicken.road.nevsdomy.ui.register.TagRow (RegisterScreen.kt:184)");
            }
            Modifier modifierHorizontalScroll$default = ScrollKt.horizontalScroll$default(Modifier.INSTANCE, ScrollKt.rememberScrollState(0, composerStartRestartGroup, 0, 1), false, null, false, 14, null);
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getTop(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierHorizontalScroll$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -2041491590, "C:RegisterScreen.kt#zd2u8u");
            composerStartRestartGroup.startReplaceGroup(488335319);
            ComposerKt.sourceInformation(composerStartRestartGroup, "*192@8132L19,193@8177L293,190@8049L859");
            Iterator<StraitTag> it = StraitTag.getEntries().iterator();
            while (it.hasNext()) {
                final StraitTag next = it.next();
                boolean z3 = straitTag == next ? z : z2;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 783709536, "CC(remember):RegisterScreen.kt#9igjgp");
                boolean zChanged = ((i2 & StylePropertiesKt.TextDirectionMask) == i3 ? z : z2) | composerStartRestartGroup.changed(next.ordinal());
                Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return RegisterScreenKt.TagRow$lambda$0$0$0$0(function1, next);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                Function0 function0 = (Function0) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Composer composer3 = composerStartRestartGroup;
                ChipKt.FilterChip(z3, function0, ComposableLambdaKt.rememberComposableLambda(-1131309318, z, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda15
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return RegisterScreenKt.TagRow$lambda$0$0$1(next, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54), null, false, straitTag == next ? ComposableSingletons$RegisterScreenKt.INSTANCE.m8919getLambda$1881468132$app() : null, null, null, null, null, null, null, composer3, 384, 0, 4056);
                composerStartRestartGroup = composer3;
                i3 = i3;
                z = z;
                z2 = z2;
                i2 = i2;
            }
            composer2 = composerStartRestartGroup;
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda16
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.TagRow$lambda$1(straitTag, function1, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit TagRow$lambda$0$0$0$0(Function1 function1, StraitTag straitTag) {
        function1.invoke(straitTag);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit TagRow$lambda$0$0$1(StraitTag straitTag, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C195@8236L28,196@8312L10,194@8199L253:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1131309318, i, -1, "com.chicken.road.nevsdomy.ui.register.TagRow.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:194)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(straitTag.getLabelRes(), composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final void SortControl(final SortOrder sortOrder, final Function1<? super SortOrder, Unit> function1, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(829654989);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(SortControl)N(current,onSelected)219@9039L34,220@9078L1052:RegisterScreen.kt#zd2u8u");
        if ((i & 6) == 0) {
            i2 = i | (composerStartRestartGroup.changed(sortOrder.ordinal()) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function1) ? 32 : 16;
        }
        if (composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(829654989, i2, -1, "com.chicken.road.nevsdomy.ui.register.SortControl (RegisterScreen.kt:218)");
            }
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1565469681, "CC(remember):RegisterScreen.kt#9igjgp");
            Object objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            final MutableState mutableState = (MutableState) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -2085776581, "C221@9116L19,221@9137L287,221@9095L329,229@9486L20,229@9508L616,229@9433L691:RegisterScreen.kt#zd2u8u");
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -482925450, "CC(remember):RegisterScreen.kt#9igjgp");
            Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return RegisterScreenKt.SortControl$lambda$3$0$0(mutableState);
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ButtonKt.TextButton((Function0) objRememberedValue2, null, false, null, null, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-515097216, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return RegisterScreenKt.SortControl$lambda$3$1(sortOrder, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, 805306374, 510);
            boolean zSortControl$lambda$1 = SortControl$lambda$1(mutableState);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -482913609, "CC(remember):RegisterScreen.kt#9igjgp");
            Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue3 = new Function0() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return RegisterScreenKt.SortControl$lambda$3$2$0(mutableState);
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
            }
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            AndroidMenu_androidKt.m2324DropdownMenuIlH_yew(zSortControl$lambda$1, (Function0) objRememberedValue3, null, 0L, null, null, null, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1037136360, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return RegisterScreenKt.SortControl$lambda$3$3(function1, mutableState, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, 48, 48, 2044);
            composerStartRestartGroup = composerStartRestartGroup;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.SortControl$lambda$4(sortOrder, function1, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final boolean SortControl$lambda$1(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void SortControl$lambda$2(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$0$0(MutableState mutableState) {
        SortControl$lambda$2(mutableState, true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$1(SortOrder sortOrder, RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C223@9225L32,223@9180L78,224@9298L10,222@9151L263:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-515097216, i, -1, "com.chicken.road.nevsdomy.ui.register.SortControl.<anonymous>.<anonymous> (RegisterScreen.kt:222)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.register_sort_label, new Object[]{StringResources_androidKt.stringResource(sortOrder.getLabelRes(), composer, 0)}, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$2$0(MutableState mutableState) {
        SortControl$lambda$2(mutableState, false);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$3(final Function1 function1, final MutableState mutableState, ColumnScope DropdownMenu, Composer composer, int i) {
        Composer composer2 = composer;
        Intrinsics.checkNotNullParameter(DropdownMenu, "$this$DropdownMenu");
        ComposerKt.sourceInformation(composer2, "C*232@9620L323,240@9975L106,231@9575L525:RegisterScreen.kt#zd2u8u");
        if (!composer2.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1037136360, i, -1, "com.chicken.road.nevsdomy.ui.register.SortControl.<anonymous>.<anonymous> (RegisterScreen.kt:230)");
            }
            for (final SortOrder sortOrder : SortOrder.getEntries()) {
                ComposableLambda composableLambdaRememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(-1376118913, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return RegisterScreenKt.SortControl$lambda$3$3$0$0(sortOrder, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer2, 54);
                ComposerKt.sourceInformationMarkerStart(composer2, 1310956377, "CC(remember):RegisterScreen.kt#9igjgp");
                boolean zChanged = composer2.changed(function1) | composer2.changed(sortOrder.ordinal());
                Object objRememberedValue = composer2.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return RegisterScreenKt.SortControl$lambda$3$3$0$1$0(function1, sortOrder, mutableState);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                AndroidMenu_androidKt.DropdownMenuItem(composableLambdaRememberComposableLambda, (Function0) objRememberedValue, null, null, null, false, null, null, null, composer2, 6, 508);
                composer2 = composer;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$3$0$0(SortOrder sortOrder, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C234@9687L30,235@9769L10,233@9646L275:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1376118913, i, -1, "com.chicken.road.nevsdomy.ui.register.SortControl.<anonymous>.<anonymous>.<anonymous>.<anonymous> (RegisterScreen.kt:233)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(sortOrder.getLabelRes(), composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit SortControl$lambda$3$3$0$1$0(Function1 function1, SortOrder sortOrder, MutableState mutableState) {
        SortControl$lambda$2(mutableState, false);
        function1.invoke(sortOrder);
        return Unit.INSTANCE;
    }

    private static final void SectionHeader(final String str, int i, Composer composer, final int i2) {
        int i3;
        Composer composer2;
        final int i4 = i;
        Composer composerStartRestartGroup = composer.startRestartGroup(272338015);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(SectionHeader)N(title,count)252@10205L554:RegisterScreen.kt#zd2u8u");
        if ((i2 & 6) == 0) {
            i3 = i2 | (composerStartRestartGroup.changed(str) ? 4 : 2);
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(i4) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(272338015, i3, -1, "com.chicken.road.nevsdomy.ui.register.SectionHeader (RegisterScreen.kt:251)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8936getXsD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1543605247, "C255@10344L10,253@10278L170,260@10482L68,261@10586L10,262@10642L11,259@10457L296:RegisterScreen.kt#zd2u8u");
            TextKt.m3328TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getTitleLarge(), composerStartRestartGroup, i3 & 14, 24960, 110590);
            i4 = i;
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.pluralStringResource(R.plurals.register_section_count, i, new Object[]{Integer.valueOf(i)}, composerStartRestartGroup, i3 & StylePropertiesKt.TextDirectionMask), null, MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getBodySmall(), composerStartRestartGroup, 0, 24960, 110586);
            composer2 = composerStartRestartGroup;
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda19
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.SectionHeader$lambda$1(str, i4, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void StraitTile(final Strait strait, final Function0<Unit> function0, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(906270783);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(StraitTile)N(strait,onClick)275@11008L56,276@11072L1115,271@10841L1346:RegisterScreen.kt#zd2u8u");
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? composerStartRestartGroup.changed(strait) : composerStartRestartGroup.changedInstance(strait) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(906270783, i2, -1, "com.chicken.road.nevsdomy.ui.register.StraitTile (RegisterScreen.kt:270)");
            }
            CardKt.ElevatedCard(function0, SizeKt.m1162width3ABfNKs(Modifier.INSTANCE, TileWidth), false, RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), null, CardDefaults.INSTANCE.m2402elevatedCardElevationaqJV_2Y(Dp.m8373constructorimpl(Spacing.INSTANCE.m8936getXsD9Ej5fM() / 2.0f), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, composerStartRestartGroup, 1572864, 62), null, ComposableLambdaKt.rememberComposableLambda(-348372739, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return RegisterScreenKt.StraitTile$lambda$0(strait, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i2 >> 3) & 14) | 12582960, 84);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterScreenKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return RegisterScreenKt.StraitTile$lambda$1(strait, function0, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    static final Unit StraitTile$lambda$0(Strait strait, ColumnScope ElevatedCard, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(ElevatedCard, "$this$ElevatedCard");
        ComposerKt.sourceInformation(composer, "C277@11082L1099:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-348372739, i, -1, "com.chicken.road.nevsdomy.ui.register.StraitTile.<anonymous> (RegisterScreen.kt:277)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 1508298519, "C283@11282L49,286@11424L10,284@11344L197,291@11583L65,292@11688L10,293@11748L11,290@11554L317,298@11913L44,299@11997L10,300@12057L11,297@11884L287:RegisterScreen.kt#zd2u8u");
            ComponentsKt.m8910EmojiTileicBs0wY(strait.getEmoji(), TileEmoji, null, 0.0f, composer, 48, 12);
            TextKt.m3328TextNvy7gAk(strait.getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleMedium(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.neck_width, new Object[]{ComponentsKt.formatKm(strait.getNarrowestKm())}, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodySmall(), composer, 0, 24960, 110586);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(((StraitTag) CollectionsKt.first((List) strait.getTags())).getLabelRes(), composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodySmall(), composer, 0, 24960, 110586);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final RegisterUiState RegisterScreen$lambda$0(State<RegisterUiState> state) {
        return state.getValue();
    }
}
