package com.chicken.road.nevsdomy.di;

import com.chicken.road.nevsdomy.data.db.StraitWatchDatabase;
import com.chicken.road.nevsdomy.data.db.SweepStatsDao;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class AppModule_ProvideSweepStatsDaoFactory implements Factory<SweepStatsDao> {
    private final Provider<StraitWatchDatabase> dbProvider;

    private AppModule_ProvideSweepStatsDaoFactory(Provider<StraitWatchDatabase> dbProvider) {
        this.dbProvider = dbProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public SweepStatsDao get() {
        return provideSweepStatsDao(this.dbProvider.get());
    }

    public static AppModule_ProvideSweepStatsDaoFactory create(Provider<StraitWatchDatabase> dbProvider) {
        return new AppModule_ProvideSweepStatsDaoFactory(dbProvider);
    }

    public static SweepStatsDao provideSweepStatsDao(StraitWatchDatabase db) {
        return (SweepStatsDao) Preconditions.checkNotNullFromProvides(AppModule.INSTANCE.provideSweepStatsDao(db));
    }
}
