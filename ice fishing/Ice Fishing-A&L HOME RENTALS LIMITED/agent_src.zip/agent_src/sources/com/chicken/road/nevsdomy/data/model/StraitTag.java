package com.chicken.road.nevsdomy.data.model;

import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: Strait.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0017\b\u0002\u0012\f\b\u0001\u0010\u0002\u001a\u00020\u0003:\u0002\b\u0004¢\u0006\u0004\b\u0005\u0010\u0006R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\r¨\u0006\u000e"}, d2 = {"Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "", "labelRes", "", "Landroidx/annotation/StringRes;", "<init>", "(Ljava/lang/String;II)V", "getLabelRes", "()I", "OIL_ARTERY", "ICE_SEASON", "BRIDGED", "TIDAL_RACE", "SHALLOW_BANK", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class StraitTag {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ StraitTag[] $VALUES;
    private final int labelRes;
    public static final StraitTag OIL_ARTERY = new StraitTag("OIL_ARTERY", 0, R.string.tag_oil_artery);
    public static final StraitTag ICE_SEASON = new StraitTag("ICE_SEASON", 1, R.string.tag_ice_season);
    public static final StraitTag BRIDGED = new StraitTag("BRIDGED", 2, R.string.tag_bridged);
    public static final StraitTag TIDAL_RACE = new StraitTag("TIDAL_RACE", 3, R.string.tag_tidal_race);
    public static final StraitTag SHALLOW_BANK = new StraitTag("SHALLOW_BANK", 4, R.string.tag_shallow_bank);

    private static final /* synthetic */ StraitTag[] $values() {
        return new StraitTag[]{OIL_ARTERY, ICE_SEASON, BRIDGED, TIDAL_RACE, SHALLOW_BANK};
    }

    public static EnumEntries<StraitTag> getEntries() {
        return $ENTRIES;
    }

    public static StraitTag valueOf(String str) {
        return (StraitTag) Enum.valueOf(StraitTag.class, str);
    }

    public static StraitTag[] values() {
        return (StraitTag[]) $VALUES.clone();
    }

    private StraitTag(String str, int i, int i2) {
        this.labelRes = i2;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    static {
        StraitTag[] straitTagArr$values = $values();
        $VALUES = straitTagArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(straitTagArr$values);
    }
}
