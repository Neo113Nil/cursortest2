package com.chicken.road.nevsdomy.ui.passagelog;

import androidx.lifecycle.SavedStateHandle;
import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import dagger.internal.Factory;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class PassageLogViewModel_Factory implements Factory<PassageLogViewModel> {
    private final Provider<StraitRepository> repositoryProvider;
    private final Provider<SavedStateHandle> savedStateHandleProvider;

    private PassageLogViewModel_Factory(Provider<StraitRepository> repositoryProvider, Provider<SavedStateHandle> savedStateHandleProvider) {
        this.repositoryProvider = repositoryProvider;
        this.savedStateHandleProvider = savedStateHandleProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public PassageLogViewModel get() {
        return newInstance(this.repositoryProvider.get(), this.savedStateHandleProvider.get());
    }

    public static PassageLogViewModel_Factory create(Provider<StraitRepository> repositoryProvider, Provider<SavedStateHandle> savedStateHandleProvider) {
        return new PassageLogViewModel_Factory(repositoryProvider, savedStateHandleProvider);
    }

    public static PassageLogViewModel newInstance(StraitRepository repository, SavedStateHandle savedStateHandle) {
        return new PassageLogViewModel(repository, savedStateHandle);
    }
}
