package com.chicken.road.nevsdomy.ui.passagelog;

import com.chicken.road.nevsdomy.ui.passagelog.PassageLogViewModel_HiltModules;
import dagger.internal.Factory;

/* loaded from: classes2.dex */
public final class PassageLogViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {
    @Override // javax.inject.Provider, jakarta.inject.Provider
    public Boolean get() {
        return Boolean.valueOf(provide());
    }

    public static PassageLogViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return InstanceHolder.INSTANCE;
    }

    public static boolean provide() {
        return PassageLogViewModel_HiltModules.KeyModule.provide();
    }

    private static final class InstanceHolder {
        static final PassageLogViewModel_HiltModules_KeyModule_ProvideFactory INSTANCE = new PassageLogViewModel_HiltModules_KeyModule_ProvideFactory();

        private InstanceHolder() {
        }
    }
}
