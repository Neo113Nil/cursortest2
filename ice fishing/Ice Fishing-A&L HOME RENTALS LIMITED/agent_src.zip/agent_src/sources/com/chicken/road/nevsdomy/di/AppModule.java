package com.chicken.road.nevsdomy.di;

import android.content.Context;
import androidx.room.Room;
import com.chicken.road.nevsdomy.data.db.CrossingDao;
import com.chicken.road.nevsdomy.data.db.StraitWatchDatabase;
import com.chicken.road.nevsdomy.data.db.SweepStatsDao;
import dagger.Module;
import dagger.Provides;
import dagger.hilt.android.qualifiers.ApplicationContext;
import javax.inject.Singleton;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: AppModule.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\f\b\u0001\u0010\u0006\u001a\u00020\u0007:\u0002\b\bH\u0007b\u0002\b\tb\u0002\b\nJ\u0014\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0005H\u0007b\u0002\b\tJ\u0014\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\u0005H\u0007b\u0002\b\tÊ\u0001\u0002\b\u0011Ê\u0001\u0010\b\u0012\u0012\f\b\u0013\u0012\b\b\fJ\u0004\b\t0\u0014Ê\u0001\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\u0003\u0010\u0002¨\u0006\u0010"}, d2 = {"Lcom/chicken/road/nevsdomy/di/AppModule;", "", "<init>", "()V", "provideDatabase", "Lcom/chicken/road/nevsdomy/data/db/StraitWatchDatabase;", "context", "Landroid/content/Context;", "Ldagger/hilt/android/qualifiers/ApplicationContext;", "Ldagger/Provides;", "Ljavax/inject/Singleton;", "provideCrossingDao", "Lcom/chicken/road/nevsdomy/data/db/CrossingDao;", "db", "provideSweepStatsDao", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;", "app", "Ldagger/Module;", "Ldagger/hilt/InstallIn;", "value", "Ldagger/hilt/components/SingletonComponent;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
@Module
/* loaded from: classes2.dex */
public final class AppModule {
    public static final int $stable = 0;
    public static final AppModule INSTANCE = new AppModule();

    private AppModule() {
    }

    @Provides
    @Singleton
    public final StraitWatchDatabase provideDatabase(@ApplicationContext Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return (StraitWatchDatabase) Room.databaseBuilder(context, StraitWatchDatabase.class, StraitWatchDatabase.NAME).fallbackToDestructiveMigration(true).build();
    }

    @Provides
    public final CrossingDao provideCrossingDao(StraitWatchDatabase db) {
        Intrinsics.checkNotNullParameter(db, "db");
        return db.crossingDao();
    }

    @Provides
    public final SweepStatsDao provideSweepStatsDao(StraitWatchDatabase db) {
        Intrinsics.checkNotNullParameter(db, "db");
        return db.sweepStatsDao();
    }
}
