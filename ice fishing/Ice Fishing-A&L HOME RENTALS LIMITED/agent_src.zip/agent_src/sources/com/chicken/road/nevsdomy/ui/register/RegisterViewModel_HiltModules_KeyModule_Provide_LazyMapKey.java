package com.chicken.road.nevsdomy.ui.register;

/* loaded from: classes2.dex */
public final class RegisterViewModel_HiltModules_KeyModule_Provide_LazyMapKey {
    static RegisterViewModel keepFieldType = null;
    public static String lazyClassKeyName = "com.chicken.road.nevsdomy.ui.register.RegisterViewModel";
}
