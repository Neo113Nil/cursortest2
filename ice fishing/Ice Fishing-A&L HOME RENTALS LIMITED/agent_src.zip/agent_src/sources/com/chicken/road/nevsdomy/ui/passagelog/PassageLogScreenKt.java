package com.chicken.road.nevsdomy.ui.passagelog;

import android.content.res.Resources;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.DatePickerDialog_androidKt;
import androidx.compose.material3.DatePickerKt;
import androidx.compose.material3.DatePickerState;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.input.nestedscroll.NestedScrollModifierKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.ui.common.ComponentsKt;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;

/* compiled from: PassageLogScreen.kt */
@Metadata(d1 = {"\u0000B\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\u001a7\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007b\u0002\b\u0007b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u0006\u001a'\u0010\u000b\u001a\u00020\u00012\u0006\u0010\f\u001a\u00020\rH\u0003b\u0002\b\u0007b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u000e\u001a'\u0010\u000f\u001a\u00020\u00012\u0006\u0010\f\u001a\u00020\rH\u0003b\u0002\b\u0007b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u000e\u001a/\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012H\u0003b\u0002\b\u0007b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u0014\u001aE\u0010\u0015\u001a\u00020\u00012\b\u0010\u0016\u001a\u0004\u0018\u00010\u00172\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003H\u0003b\u0002\b\u0007b\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¢\u0006\u0002\u0010\u001a\u001a\u0010\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u001c\u001a\u00020\u0017H\u0002¨\u0006\u001d²\u0006\n\u0010\u001e\u001a\u00020\u001fX\u008a\u0084\u0002²\u0006\n\u0010 \u001a\u00020!X\u008a\u008e\u0002"}, d2 = {"PassageLogScreen", "", "onBack", "Lkotlin/Function0;", "viewModel", "Lcom/chicken/road/nevsdomy/ui/passagelog/PassageLogViewModel;", "(Lkotlin/jvm/functions/Function0;Lcom/chicken/road/nevsdomy/ui/passagelog/PassageLogViewModel;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/Composable;", "Landroidx/compose/runtime/ComposableTarget;", "applier", "androidx.compose.ui.UiComposable", "SoundingsGrid", "strait", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "(Lcom/chicken/road/nevsdomy/data/model/Strait;Landroidx/compose/runtime/Composer;I)V", "TagStrip", "SectionText", "header", "", "body", "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V", "CrossingCard", "crossedOn", "", "onOpenPicker", "onClear", "(Ljava/lang/Long;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "formatDate", "epochMillis", "app", "state", "Lcom/chicken/road/nevsdomy/ui/passagelog/PassageLogUiState;", "pickerOpen", ""}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class PassageLogScreenKt {
    static final Unit CrossingCard$lambda$1(Long l, Function0 function0, Function0 function02, int i, Composer composer, int i2) {
        CrossingCard(l, function0, function02, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$10(Function0 function0, PassageLogViewModel passageLogViewModel, int i, int i2, Composer composer, int i3) {
        PassageLogScreen(function0, passageLogViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit SectionText$lambda$1(String str, String str2, int i, Composer composer, int i2) {
        SectionText(str, str2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit SoundingsGrid$lambda$1(Strait strait, int i, Composer composer, int i2) {
        SoundingsGrid(strait, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit TagStrip$lambda$1(Strait strait, int i, Composer composer, int i2) {
        TagStrip(strait, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0183  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0205  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0214  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void PassageLogScreen(final Function0<Unit> onBack, PassageLogViewModel passageLogViewModel, Composer composer, final int i, final int i2) {
        int i3;
        boolean z;
        Object objRememberedValue;
        final MutableState mutableState;
        final MutableState mutableState2;
        int i4;
        final PassageLogViewModel passageLogViewModel2 = passageLogViewModel;
        Intrinsics.checkNotNullParameter(onBack, "onBack");
        Composer composerStartRestartGroup = composer.startRestartGroup(-1216889757);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(PassageLogScreen)N(onBack,viewModel)58@2603L29,59@2676L22,60@2721L34,65@2899L948,89@3855L2908,63@2791L3972:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i3 = i | (composerStartRestartGroup.changedInstance(onBack) ? 4 : 2);
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) != 0) {
                i4 = 16;
                i3 |= i4;
            } else {
                if ((i & 64) == 0 ? composerStartRestartGroup.changed(passageLogViewModel2) : composerStartRestartGroup.changedInstance(passageLogViewModel2)) {
                    i4 = 32;
                }
                i3 |= i4;
            }
        }
        int i5 = i3;
        if (composerStartRestartGroup.shouldExecute((i5 & 19) != 18, i5 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "56@2547L15");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 2) != 0) {
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1192010736, "CC(hiltViewModel)N(viewModelStoreOwner,key)40@1717L7,45@1869L81,46@1962L54:HiltViewModel.kt#gplxbw");
                    ViewModelStoreOwner current = LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    ViewModelProvider.Factory factoryRememberHiltViewModelFactory = HiltViewModelKt.rememberHiltViewModelFactory(ViewModelStoreOwnerDefaults.getViewModelProviderFactory(current), composerStartRestartGroup, 0, 0);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1729797275, "CC(viewModel)N(viewModelStoreOwner,key,factory,extras)58@2688L7,64@2951L63:ViewModel.kt#3tja67");
                    ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(PassageLogViewModel.class), current, (String) null, factoryRememberHiltViewModelFactory, ViewModelStoreOwnerDefaults.getViewModelCreationExtras(current), composerStartRestartGroup, 0, 0);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    i5 &= -113;
                    z = true;
                    passageLogViewModel2 = (PassageLogViewModel) viewModel;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-1216889757, i5, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen (PassageLogScreen.kt:57)");
                }
                final State stateCollectAsStateWithLifecycle = FlowExtKt.collectAsStateWithLifecycle(passageLogViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composerStartRestartGroup, 0, 7);
                final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composerStartRestartGroup, 384, 3);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1199943707, "CC(remember):PassageLogScreen.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                mutableState = (MutableState) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final Strait strait = PassageLogScreen$lambda$0(stateCollectAsStateWithLifecycle).getStrait();
                boolean z2 = z;
                ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(-1122730721, z, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return PassageLogScreenKt.PassageLogScreen$lambda$4(topAppBarScrollBehaviorPinnedScrollBehavior, strait, onBack, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(243682164, z, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return PassageLogScreenKt.PassageLogScreen$lambda$5(strait, stateCollectAsStateWithLifecycle, passageLogViewModel2, mutableState, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, 805306416, 508);
                composerStartRestartGroup = composerStartRestartGroup;
                if (!PassageLogScreen$lambda$2(mutableState)) {
                    composerStartRestartGroup.startReplaceGroup(1460519716);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "168@6813L68,170@6939L22,171@6991L554,186@7575L380,196@7967L55,169@6890L1132");
                    final DatePickerState datePickerStateM2610rememberDatePickerStateEU0dCGE = DatePickerKt.m2610rememberDatePickerStateEU0dCGE(PassageLogScreen$lambda$0(stateCollectAsStateWithLifecycle).getCrossedOn(), null, null, 0, null, composerStartRestartGroup, 0, 30);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1199808743, "CC(remember):PassageLogScreen.kt#9igjgp");
                    Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        mutableState2 = mutableState;
                        objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return PassageLogScreenKt.PassageLogScreen$lambda$6$0(mutableState2);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    } else {
                        mutableState2 = mutableState;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    DatePickerDialog_androidKt.m2602DatePickerDialogGmEhDVc((Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(47923286, z2, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return PassageLogScreenKt.PassageLogScreen$lambda$7(datePickerStateM2610rememberDatePickerStateEU0dCGE, passageLogViewModel2, mutableState2, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composerStartRestartGroup, 54), null, ComposableLambdaKt.rememberComposableLambda(-2147305580, z2, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return PassageLogScreenKt.PassageLogScreen$lambda$8(mutableState2, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composerStartRestartGroup, 54), null, 0.0f, null, null, ComposableLambdaKt.rememberComposableLambda(-566563809, z2, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return PassageLogScreenKt.PassageLogScreen$lambda$9(datePickerStateM2610rememberDatePickerStateEU0dCGE, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, composerStartRestartGroup, 54), composerStartRestartGroup, 100666422, 244);
                    composerStartRestartGroup = composerStartRestartGroup;
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(1461714239);
                    composerStartRestartGroup.endReplaceGroup();
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i5 &= -113;
                }
            }
            z = true;
            composerStartRestartGroup.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
            }
            final State stateCollectAsStateWithLifecycle2 = FlowExtKt.collectAsStateWithLifecycle(passageLogViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composerStartRestartGroup, 0, 7);
            final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior2 = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composerStartRestartGroup, 384, 3);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1199943707, "CC(remember):PassageLogScreen.kt#9igjgp");
            objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
            }
            mutableState = (MutableState) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final Strait strait2 = PassageLogScreen$lambda$0(stateCollectAsStateWithLifecycle2).getStrait();
            boolean z22 = z;
            ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior2.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(-1122730721, z, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.PassageLogScreen$lambda$4(topAppBarScrollBehaviorPinnedScrollBehavior2, strait2, onBack, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(243682164, z, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return PassageLogScreenKt.PassageLogScreen$lambda$5(strait2, stateCollectAsStateWithLifecycle2, passageLogViewModel2, mutableState, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, 805306416, 508);
            composerStartRestartGroup = composerStartRestartGroup;
            if (!PassageLogScreen$lambda$2(mutableState)) {
            }
            if (ComposerKt.isTraceInProgress()) {
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.PassageLogScreen$lambda$10(onBack, passageLogViewModel2, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final boolean PassageLogScreen$lambda$2(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void PassageLogScreen$lambda$3(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$4$0(Strait strait, Composer composer, int i) throws Resources.NotFoundException {
        ComposerKt.sourceInformation(composer, "C68@2970L212:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(937961955, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous> (PassageLogScreen.kt:68)");
            }
            String name = strait != null ? strait.getName() : null;
            if (name == null) {
                composer.startReplaceGroup(-561690965);
                ComposerKt.sourceInformation(composer, "69@3023L40");
                name = StringResources_androidKt.stringResource(R.string.passage_missing, composer, 0);
            } else {
                composer.startReplaceGroup(-561691461);
            }
            composer.endReplaceGroup();
            TextKt.m3328TextNvy7gAk(name, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, null, composer, 0, 24960, 241662);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$4$1(Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C75@3257L270:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2095494245, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous> (PassageLogScreen.kt:75)");
            }
            IconButtonKt.IconButton(function0, null, false, null, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.m8913getLambda$567246205$app(), composer, 1572864, 62);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$4(TopAppBarScrollBehavior topAppBarScrollBehavior, final Strait strait, final Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C84@3707L11,85@3782L11,83@3639L183,67@2948L252,74@3235L310,66@2913L924:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1122730721, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous> (PassageLogScreen.kt:66)");
            }
            AppBarKt.m2345TopAppBarGHTll3U(ComposableLambdaKt.rememberComposableLambda(937961955, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.PassageLogScreen$lambda$4$0(strait, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), null, ComposableLambdaKt.rememberComposableLambda(2095494245, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda19
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.PassageLogScreen$lambda$4$1(function0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), null, 0.0f, null, TopAppBarDefaults.INSTANCE.m3543topAppBarColors5tl4gsc(MaterialTheme.INSTANCE.getColorScheme(composer, 6).getSurface(), 0L, 0L, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurface(), 0L, 0L, composer, 1572864, 54), topAppBarScrollBehavior, composer, 390, 58);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$5(final Strait strait, final State state, final PassageLogViewModel passageLogViewModel, final MutableState mutableState, PaddingValues innerPadding, Composer composer, int i) {
        int i2;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation(composer, "CN(innerPadding)108@4591L2166,102@4309L2448:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i2 = i | (composer.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if (composer.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(243682164, i2, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous> (PassageLogScreen.kt:90)");
            }
            if (strait == null) {
                composer.startReplaceGroup(1040675456);
                ComposerKt.sourceInformation(composer, "92@3951L45,93@4022L40,94@4087L44,91@3915L346");
                ComponentsKt.EmptyState(StringResources_androidKt.stringResource(R.string.register_empty_glyph, composer, 0), StringResources_androidKt.stringResource(R.string.passage_missing, composer, 0), StringResources_androidKt.stringResource(R.string.register_empty_hint, composer, 0), PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding), composer, 0, 0);
                composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                return Unit.INSTANCE;
            }
            composer.startReplaceGroup(1041057934);
            composer.endReplaceGroup();
            Modifier modifierPadding = PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding);
            PaddingValues paddingValuesM1084PaddingValuesYgX7TsA = PaddingKt.m1084PaddingValuesYgX7TsA(Spacing.INSTANCE.m8932getLD9Ej5fM(), Spacing.INSTANCE.m8933getMD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, -2044615958, "CC(remember):PassageLogScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(strait) | composer.changed(state) | composer.changedInstance(passageLogViewModel);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda22
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0(strait, passageLogViewModel, state, mutableState, (LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            LazyDslKt.LazyColumn(modifierPadding, null, paddingValuesM1084PaddingValuesYgX7TsA, false, horizontalOrVerticalM782spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, composer, 0, 490);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0(final Strait strait, final PassageLogViewModel passageLogViewModel, final State state, final MutableState mutableState, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-1963105655, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$0(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-37008000, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda10
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$1(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.getLambda$139320257$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(315648514, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$2(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(491976771, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$3(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(668305028, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$4(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(844633285, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$5(strait, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.getLambda$1020961542$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1197289799, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$6(passageLogViewModel, state, mutableState, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$0(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C109@4612L33:PassageLogScreen.kt#ae2drp");
        if (composer.shouldExecute((i & 17) != 16, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1963105655, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:109)");
            }
            ComponentsKt.EmojiBanner(strait.getEmoji(), null, composer, 0, 2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$1(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C111@4683L727:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-37008000, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:111)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8936getXsD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 1725856157, "C114@4864L10,112@4768L240,119@5066L62,120@5176L10,121@5245L11,118@5029L363:PassageLogScreen.kt#ae2drp");
            TextKt.m3328TextNvy7gAk(strait.getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getHeadlineMedium(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.seas_joined, new Object[]{strait.getSeaA(), strait.getSeaB()}, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110586);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$2(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C135@5748L21:PassageLogScreen.kt#ae2drp");
        if (composer.shouldExecute((i & 17) != 16, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(315648514, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:135)");
            }
            SoundingsGrid(strait, composer, Strait.$stable);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$3(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C136@5791L16:PassageLogScreen.kt#ae2drp");
        if (composer.shouldExecute((i & 17) != 16, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(491976771, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:136)");
            }
            TagStrip(strait, composer, Strait.$stable);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$4(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C139@5887L45,138@5845L147:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(668305028, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:138)");
            }
            SectionText(StringResources_androidKt.stringResource(R.string.passage_story_header, composer, 0), strait.getStory(), composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$5(Strait strait, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C145@6084L45,144@6042L147:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(844633285, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:144)");
            }
            SectionText(StringResources_androidKt.stringResource(R.string.passage_banks_header, composer, 0), strait.getBanks(), composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$6(PassageLogViewModel passageLogViewModel, State state, final MutableState mutableState, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C160@6640L21,161@6693L21,158@6542L191:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1197289799, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (PassageLogScreen.kt:158)");
            }
            Long crossedOn = PassageLogScreen$lambda$0(state).getCrossedOn();
            ComposerKt.sourceInformationMarkerStart(composer, -455734756, "CC(remember):PassageLogScreen.kt#9igjgp");
            Object objRememberedValue = composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return PassageLogScreenKt.PassageLogScreen$lambda$5$0$0$6$0$0(mutableState);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            Function0 function0 = (Function0) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerStart(composer, -455733060, "CC(remember):PassageLogScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(passageLogViewModel);
            PassageLogScreenKt$PassageLogScreen$2$1$1$7$2$1 passageLogScreenKt$PassageLogScreen$2$1$1$7$2$1RememberedValue = composer.rememberedValue();
            if (zChangedInstance || passageLogScreenKt$PassageLogScreen$2$1$1$7$2$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                passageLogScreenKt$PassageLogScreen$2$1$1$7$2$1RememberedValue = new PassageLogScreenKt$PassageLogScreen$2$1$1$7$2$1(passageLogViewModel);
                composer.updateRememberedValue(passageLogScreenKt$PassageLogScreen$2$1$1$7$2$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            CrossingCard(crossedOn, function0, (Function0) ((KFunction) passageLogScreenKt$PassageLogScreen$2$1$1$7$2$1RememberedValue), composer, 48);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$5$0$0$6$0$0(MutableState mutableState) {
        PassageLogScreen$lambda$3(mutableState, true);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$6$0(MutableState mutableState) {
        PassageLogScreen$lambda$3(mutableState, false);
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$7(final DatePickerState datePickerState, final PassageLogViewModel passageLogViewModel, final MutableState mutableState, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C173@7051L151,172@7009L522:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(47923286, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous> (PassageLogScreen.kt:172)");
            }
            ComposerKt.sourceInformationMarkerStart(composer, -1190360339, "CC(remember):PassageLogScreen.kt#9igjgp");
            boolean zChanged = composer.changed(datePickerState) | composer.changedInstance(passageLogViewModel);
            Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda20
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return PassageLogScreenKt.PassageLogScreen$lambda$7$0$0(datePickerState, passageLogViewModel, mutableState);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.getLambda$1947347449$app(), composer, 805306368, 510);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$7$0$0(DatePickerState datePickerState, PassageLogViewModel passageLogViewModel, MutableState mutableState) {
        Long selectedDateMillis = datePickerState.getSelectedDateMillis();
        if (selectedDateMillis != null) {
            passageLogViewModel.onDateChosen(selectedDateMillis.longValue());
        }
        PassageLogScreen$lambda$3(mutableState, false);
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$8(final MutableState mutableState, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C187@7614L22,187@7593L348:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2147305580, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous> (PassageLogScreen.kt:187)");
            }
            ComposerKt.sourceInformationMarkerStart(composer, -1976359030, "CC(remember):PassageLogScreen.kt#9igjgp");
            Object objRememberedValue = composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda17
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return PassageLogScreenKt.PassageLogScreen$lambda$8$0$0(mutableState);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.m8912getLambda$247881417$app(), composer, 805306374, 510);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PassageLogScreen$lambda$8$0$0(MutableState mutableState) {
        PassageLogScreen$lambda$3(mutableState, false);
        return Unit.INSTANCE;
    }

    static final Unit PassageLogScreen$lambda$9(DatePickerState datePickerState, ColumnScope DatePickerDialog, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(DatePickerDialog, "$this$DatePickerDialog");
        ComposerKt.sourceInformation(composer, "C197@7981L31:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-566563809, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreen.<anonymous> (PassageLogScreen.kt:197)");
            }
            DatePickerKt.DatePicker(datePickerState, null, null, null, null, null, false, null, composer, 0, 254);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final void SoundingsGrid(final Strait strait, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(-1310834452);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(SoundingsGrid)N(strait)204@8092L1166:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? composerStartRestartGroup.changed(strait) : composerStartRestartGroup.changedInstance(strait) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1310834452, i2, -1, "com.chicken.road.nevsdomy.ui.passagelog.SoundingsGrid (PassageLogScreen.kt:203)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 288537229, "C205@8164L541,217@8714L538:PassageLogScreen.kt#ae2drp");
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_42 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            Modifier.Companion companion2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_42, Alignment.INSTANCE.getTop(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion2);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor2);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl2 = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl2, Integer.valueOf(iHashCode2), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl2, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 454518249, "C207@8273L63,208@8364L39,206@8239L227,212@8513L54,213@8595L37,211@8479L216:PassageLogScreen.kt#ae2drp");
            ComponentsKt.StatTile(StringResources_androidKt.stringResource(R.string.value_km, new Object[]{ComponentsKt.formatKm(strait.getNarrowestKm())}, composerStartRestartGroup, 0), StringResources_androidKt.stringResource(R.string.stat_narrowest, composerStartRestartGroup, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composerStartRestartGroup, 0, 0);
            ComponentsKt.StatTile(StringResources_androidKt.stringResource(R.string.value_metres, new Object[]{Integer.valueOf(strait.getDeepestM())}, composerStartRestartGroup, 0), StringResources_androidKt.stringResource(R.string.stat_deepest, composerStartRestartGroup, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composerStartRestartGroup, 0, 0);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_43 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            Modifier.Companion companion3 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_43, Alignment.INSTANCE.getTop(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap3 = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion3);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor3);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl3 = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl3, Integer.valueOf(iHashCode3), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl3, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -2031995581, "C219@8823L57,220@8908L36,218@8789L218,224@9054L60,225@9142L37,223@9020L222:PassageLogScreen.kt#ae2drp");
            ComponentsKt.StatTile(StringResources_androidKt.stringResource(R.string.value_length_km, new Object[]{Integer.valueOf(strait.getLengthKm())}, composerStartRestartGroup, 0), StringResources_androidKt.stringResource(R.string.stat_length, composerStartRestartGroup, 0), RowScope.weight$default(rowScopeInstance2, Modifier.INSTANCE, 1.0f, false, 2, null), composerStartRestartGroup, 0, 0);
            ComponentsKt.StatTile(StringResources_androidKt.stringResource(R.string.value_ships_day, new Object[]{Integer.valueOf(strait.getShipsPerDay())}, composerStartRestartGroup, 0), StringResources_androidKt.stringResource(R.string.stat_traffic, composerStartRestartGroup, 0), RowScope.weight$default(rowScopeInstance2, Modifier.INSTANCE, 1.0f, false, 2, null), composerStartRestartGroup, 0, 0);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.SoundingsGrid$lambda$1(strait, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void TagStrip(final Strait strait, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(999062776);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(TagStrip)N(strait)235@9367L21,234@9317L257:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? composerStartRestartGroup.changed(strait) : composerStartRestartGroup.changedInstance(strait) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(999062776, i2, -1, "com.chicken.road.nevsdomy.ui.passagelog.TagStrip (PassageLogScreen.kt:233)");
            }
            Modifier modifierHorizontalScroll$default = ScrollKt.horizontalScroll$default(Modifier.INSTANCE, ScrollKt.rememberScrollState(0, composerStartRestartGroup, 0, 1), false, null, false, 14, null);
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getTop(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierHorizontalScroll$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -964333177, "C:PassageLogScreen.kt#ae2drp");
            composerStartRestartGroup.startReplaceGroup(2047102832);
            ComposerKt.sourceInformation(composerStartRestartGroup, "*239@9529L28,239@9513L45");
            Iterator<T> it = strait.getTags().iterator();
            while (it.hasNext()) {
                ComponentsKt.TagPill(StringResources_androidKt.stringResource(((StraitTag) it.next()).getLabelRes(), composerStartRestartGroup, 0), null, composerStartRestartGroup, 0, 2);
            }
            composerStartRestartGroup.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.TagStrip$lambda$1(strait, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void SectionText(final String str, String str2, Composer composer, final int i) {
        int i2;
        final String str3;
        Composer composer2;
        Composer composerStartRestartGroup = composer.startRestartGroup(-729529367);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(SectionText)N(header,body)246@9650L428:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i2 = i | (composerStartRestartGroup.changed(str) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changed(str2) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            str3 = str2;
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-729529367, i2, -1, "com.chicken.road.nevsdomy.ui.passagelog.SectionText (PassageLogScreen.kt:245)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1238297062, "C249@9789L10,247@9722L171,255@9967L10,253@9902L170:PassageLogScreen.kt#ae2drp");
            composer2 = composerStartRestartGroup;
            TextKt.m3328TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getTitleLarge(), composer2, i2 & 14, 24960, 110590);
            str3 = str2;
            TextKt.m3328TextNvy7gAk(str3, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 12, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, 6).getBodyMedium(), composer2, (i2 >> 3) & 14, 24960, 110590);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.SectionText$lambda$1(str, str3, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void CrossingCard(final Long l, final Function0<Unit> function0, final Function0<Unit> function02, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(1072282653);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(CrossingCard)N(crossedOn,onOpenPicker,onClear)271@10316L1694,268@10205L1805:PassageLogScreen.kt#ae2drp");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(l) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function02) ? 256 : 128;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 147) != 146, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1072282653, i2, -1, "com.chicken.road.nevsdomy.ui.passagelog.CrossingCard (PassageLogScreen.kt:267)");
            }
            CardKt.OutlinedCard(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), null, null, null, ComposableLambdaKt.rememberComposableLambda(460442257, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda23
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return PassageLogScreenKt.CrossingCard$lambda$0(l, function0, function02, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, 196614, 28);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.PassageLogScreenKt$$ExternalSyntheticLambda24
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return PassageLogScreenKt.CrossingCard$lambda$1(l, function0, function02, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    static final Unit CrossingCard$lambda$0(Long l, Function0 function0, Function0 function02, ColumnScope OutlinedCard, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(OutlinedCard, "$this$OutlinedCard");
        ComposerKt.sourceInformation(composer, "C272@10326L1678:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(460442257, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.CrossingCard.<anonymous> (PassageLogScreen.kt:272)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -89020000, "C:PassageLogScreen.kt#ae2drp");
            if (l == null) {
                composer.startReplaceGroup(-89019598);
                ComposerKt.sourceInformation(composer, "280@10600L44,281@10688L10,282@10753L11,279@10567L321,286@10905L375");
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_no_crossing, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110586);
                ButtonKt.Button(function0, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.getLambda$1967006930$app(), composer, 805306416, 508);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-88276187);
                ComposerKt.sourceInformation(composer, "296@11351L66,297@11461L10,295@11318L272,301@11607L373");
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_crossed_on, new Object[]{formatDate(l.longValue())}, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleMedium(), composer, 0, 24960, 110590);
                ButtonKt.TextButton(function02, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$PassageLogScreenKt.INSTANCE.m8911getLambda$1196967832$app(), composer, 805306416, 508);
                composer.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final String formatDate(long j) {
        String str = new SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(new Date(j));
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    private static final PassageLogUiState PassageLogScreen$lambda$0(State<PassageLogUiState> state) {
        return state.getValue();
    }
}
