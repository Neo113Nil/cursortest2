package com.chicken.road.nevsdomy.data.db;

import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.SQLiteStatementUtil;
import androidx.sqlite.SQLiteConnection;
import androidx.sqlite.SQLiteStatement;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KClass;
import kotlinx.coroutines.flow.Flow;

/* compiled from: SweepStatsDao_Impl.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\fJ\u0010\u0010\r\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u000eH\u0016J\u0010\u0010\u000f\u001a\u0004\u0018\u00010\bH\u0096@¢\u0006\u0002\u0010\u0010R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000Ê\u0001\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0012"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao_Impl;", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfSweepStatsEntity", "Landroidx/room/EntityInsertAdapter;", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;", "upsert", "", "entity", "(Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "observe", "Lkotlinx/coroutines/flow/Flow;", "current", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class SweepStatsDao_Impl implements SweepStatsDao {
    private final RoomDatabase __db;
    private final EntityInsertAdapter<SweepStatsEntity> __insertAdapterOfSweepStatsEntity;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;

    public SweepStatsDao_Impl(RoomDatabase __db) {
        Intrinsics.checkNotNullParameter(__db, "__db");
        this.__db = __db;
        this.__insertAdapterOfSweepStatsEntity = new EntityInsertAdapter<SweepStatsEntity>() { // from class: com.chicken.road.nevsdomy.data.db.SweepStatsDao_Impl.1
            @Override // androidx.room.EntityInsertAdapter
            protected String createQuery() {
                return "INSERT OR REPLACE INTO `sweep_stats` (`id`,`bestBoards`,`runsPlayed`) VALUES (?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(SQLiteStatement statement, SweepStatsEntity entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo8753bindLong(1, entity.getId());
                statement.mo8753bindLong(2, entity.getBestBoards());
                statement.mo8753bindLong(3, entity.getRunsPlayed());
            }
        };
    }

    @Override // com.chicken.road.nevsdomy.data.db.SweepStatsDao
    public Object upsert(final SweepStatsEntity sweepStatsEntity, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.chicken.road.nevsdomy.data.db.SweepStatsDao_Impl$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return SweepStatsDao_Impl.upsert$lambda$0(this.f$0, sweepStatsEntity, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit upsert$lambda$0(SweepStatsDao_Impl sweepStatsDao_Impl, SweepStatsEntity sweepStatsEntity, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        sweepStatsDao_Impl.__insertAdapterOfSweepStatsEntity.insert(_connection, (SQLiteConnection) sweepStatsEntity);
        return Unit.INSTANCE;
    }

    @Override // com.chicken.road.nevsdomy.data.db.SweepStatsDao
    public Flow<SweepStatsEntity> observe() {
        final String str = "SELECT * FROM sweep_stats WHERE id = 0 LIMIT 1";
        return FlowUtil.createFlow(this.__db, false, new String[]{"sweep_stats"}, new Function1() { // from class: com.chicken.road.nevsdomy.data.db.SweepStatsDao_Impl$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return SweepStatsDao_Impl.observe$lambda$0(str, (SQLiteConnection) obj);
            }
        });
    }

    static final SweepStatsEntity observe$lambda$0(String str, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            return sQLiteStatementPrepare.step() ? new SweepStatsEntity((int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "id")), (int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "bestBoards")), (int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "runsPlayed"))) : null;
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    @Override // com.chicken.road.nevsdomy.data.db.SweepStatsDao
    public Object current(Continuation<? super SweepStatsEntity> continuation) {
        final String str = "SELECT * FROM sweep_stats WHERE id = 0 LIMIT 1";
        return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.chicken.road.nevsdomy.data.db.SweepStatsDao_Impl$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return SweepStatsDao_Impl.current$lambda$0(str, (SQLiteConnection) obj);
            }
        }, continuation);
    }

    static final SweepStatsEntity current$lambda$0(String str, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            return sQLiteStatementPrepare.step() ? new SweepStatsEntity((int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "id")), (int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "bestBoards")), (int) sQLiteStatementPrepare.getLong(SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "runsPlayed"))) : null;
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    /* compiled from: SweepStatsDao_Impl.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final List<KClass<?>> getRequiredConverters() {
            return CollectionsKt.emptyList();
        }
    }
}
