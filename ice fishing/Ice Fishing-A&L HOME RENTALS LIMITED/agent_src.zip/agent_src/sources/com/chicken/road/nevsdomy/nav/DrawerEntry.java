package com.chicken.road.nevsdomy.nav;

import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: NavGraph.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\b\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0017\b\u0002\u0012\f\b\u0001\u0010\u0002\u001a\u00020\u0003:\u0002\b\u0004¢\u0006\u0004\b\u0005\u0010\u0006R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b¨\u0006\f"}, d2 = {"Lcom/chicken/road/nevsdomy/nav/DrawerEntry;", "", "labelRes", "", "Landroidx/annotation/StringRes;", "<init>", "(Ljava/lang/String;II)V", "getLabelRes", "()I", "CHART_ROOM", "REGISTER", "BEACON_SWEEP", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final class DrawerEntry {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ DrawerEntry[] $VALUES;
    private final int labelRes;
    public static final DrawerEntry CHART_ROOM = new DrawerEntry("CHART_ROOM", 0, R.string.screen_chart_room);
    public static final DrawerEntry REGISTER = new DrawerEntry("REGISTER", 1, R.string.screen_register);
    public static final DrawerEntry BEACON_SWEEP = new DrawerEntry("BEACON_SWEEP", 2, R.string.screen_beacon_sweep);

    private static final /* synthetic */ DrawerEntry[] $values() {
        return new DrawerEntry[]{CHART_ROOM, REGISTER, BEACON_SWEEP};
    }

    public static EnumEntries<DrawerEntry> getEntries() {
        return $ENTRIES;
    }

    public static DrawerEntry valueOf(String str) {
        return (DrawerEntry) Enum.valueOf(DrawerEntry.class, str);
    }

    public static DrawerEntry[] values() {
        return (DrawerEntry[]) $VALUES.clone();
    }

    private DrawerEntry(String str, int i, int i2) {
        this.labelRes = i2;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    static {
        DrawerEntry[] drawerEntryArr$values = $values();
        $VALUES = drawerEntryArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(drawerEntryArr$values);
    }
}
