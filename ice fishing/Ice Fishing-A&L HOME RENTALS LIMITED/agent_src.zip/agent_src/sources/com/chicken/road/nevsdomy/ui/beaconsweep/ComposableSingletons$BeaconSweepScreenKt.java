package com.chicken.road.nevsdomy.ui.beaconsweep;

import android.content.res.Resources;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextOverflow;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: BeaconSweepScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$BeaconSweepScreenKt {
    public static final ComposableSingletons$BeaconSweepScreenKt INSTANCE = new ComposableSingletons$BeaconSweepScreenKt();

    /* renamed from: lambda$-480780521, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f51lambda$480780521 = ComposableLambdaKt.composableLambdaInstance(-480780521, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__480780521$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$2041094266 = ComposableLambdaKt.composableLambdaInstance(2041094266, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda_2041094266$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1505440477, reason: not valid java name */
    private static Function3<LazyItemScope, Composer, Integer, Unit> f48lambda$1505440477 = ComposableLambdaKt.composableLambdaInstance(-1505440477, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__1505440477$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1696469682, reason: not valid java name */
    private static Function3<ColumnScope, Composer, Integer, Unit> f49lambda$1696469682 = ComposableLambdaKt.composableLambdaInstance(-1696469682, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__1696469682$lambda$0((ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$518059074 = ComposableLambdaKt.composableLambdaInstance(518059074, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda_518059074$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-903540592, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f52lambda$903540592 = ComposableLambdaKt.composableLambdaInstance(-903540592, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__903540592$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-367342354, reason: not valid java name */
    private static Function3<LazyItemScope, Composer, Integer, Unit> f50lambda$367342354 = ComposableLambdaKt.composableLambdaInstance(-367342354, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__367342354$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$543195334 = ComposableLambdaKt.composableLambdaInstance(543195334, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda_543195334$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-911528605, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f53lambda$911528605 = ComposableLambdaKt.composableLambdaInstance(-911528605, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$BeaconSweepScreenKt.lambda__911528605$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1505440477$app, reason: not valid java name */
    public final Function3<LazyItemScope, Composer, Integer, Unit> m8900getLambda$1505440477$app() {
        return f48lambda$1505440477;
    }

    /* renamed from: getLambda$-1696469682$app, reason: not valid java name */
    public final Function3<ColumnScope, Composer, Integer, Unit> m8901getLambda$1696469682$app() {
        return f49lambda$1696469682;
    }

    /* renamed from: getLambda$-367342354$app, reason: not valid java name */
    public final Function3<LazyItemScope, Composer, Integer, Unit> m8902getLambda$367342354$app() {
        return f50lambda$367342354;
    }

    /* renamed from: getLambda$-480780521$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8903getLambda$480780521$app() {
        return f51lambda$480780521;
    }

    /* renamed from: getLambda$-903540592$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8904getLambda$903540592$app() {
        return f52lambda$903540592;
    }

    /* renamed from: getLambda$-911528605$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8905getLambda$911528605$app() {
        return f53lambda$911528605;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$2041094266$app() {
        return lambda$2041094266;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$518059074$app() {
        return lambda$518059074;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$543195334$app() {
        return lambda$543195334;
    }

    static final Unit lambda__480780521$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C67@2864L44,66@2827L200:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-480780521, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-480780521.<anonymous> (BeaconSweepScreen.kt:66)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.screen_beacon_sweep, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, null, composer, 0, 24960, 241662);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_2041094266$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C122@4612L41,123@4693L10,121@4583L225:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2041094266, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$2041094266.<anonymous> (BeaconSweepScreen.kt:121)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_idle_glyph, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8308getClipgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getDisplayMedium(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1505440477$lambda$0(LazyItemScope item, Composer composer, int i) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C130@4875L44,131@4959L10,129@4846L279:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1505440477, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-1505440477.<anonymous> (BeaconSweepScreen.kt:129)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.screen_beacon_sweep, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, TextAlign.m8244boximpl(TextAlign.INSTANCE.m8251getCentere0LSkKk()), 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getHeadlineMedium(), composer, 0, 24960, 109566);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_518059074$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C138@5163L1310:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(518059074, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$518059074.<anonymous> (BeaconSweepScreen.kt:138)");
            }
            CardKt.OutlinedCard(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), null, null, null, f49lambda$1696469682, composer, 196614, 28);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1696469682$lambda$0(ColumnScope OutlinedCard, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(OutlinedCard, "$this$OutlinedCard");
        ComposerKt.sourceInformation(composer, "C142@5316L1143:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1696469682, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-1696469682.<anonymous> (BeaconSweepScreen.kt:142)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 1773498206, "C149@5601L43,150@5692L10,148@5564L268:BeaconSweepScreen.kt#gn9yix");
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_rules_header, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110590);
            Composer composer2 = composer;
            composer2.startReplaceGroup(1719792113);
            ComposerKt.sourceInformation(composer2, "*160@6115L20,161@6187L10,162@6260L11,159@6074L345");
            int i2 = 0;
            Iterator it = CollectionsKt.listOf((Object[]) new Integer[]{Integer.valueOf(R.string.sweep_rule_one), Integer.valueOf(R.string.sweep_rule_two), Integer.valueOf(R.string.sweep_rule_three)}).iterator();
            while (it.hasNext()) {
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(((Number) it.next()).intValue(), composer2, i2), null, MaterialTheme.INSTANCE.getColorScheme(composer2, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 3, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, 6).getBodyMedium(), composer, 0, 24960, 110586);
                composer2 = composer;
                i2 = i2;
            }
            composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__903540592$lambda$0(RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C185@7054L36,186@7134L10,184@7021L241:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-903540592, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-903540592.<anonymous> (BeaconSweepScreen.kt:184)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_start, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__367342354$lambda$0(LazyItemScope item, Composer composer, int i) throws Resources.NotFoundException {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C330@12169L41,331@12250L10,329@12140L276:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-367342354, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-367342354.<anonymous> (BeaconSweepScreen.kt:329)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_over_title, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, TextAlign.m8244boximpl(TextAlign.INSTANCE.m8251getCentere0LSkKk()), 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getHeadlineMedium(), composer, 0, 24960, 109566);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_543195334$lambda$0(RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C377@14220L36,378@14300L10,376@14187L241:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(543195334, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$543195334.<anonymous> (BeaconSweepScreen.kt:376)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_again, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__911528605$lambda$0(RowScope OutlinedButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
        ComposerKt.sourceInformation(composer, "C387@14607L35,388@14686L10,386@14574L240:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-911528605, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.ComposableSingletons$BeaconSweepScreenKt.lambda$-911528605.<anonymous> (BeaconSweepScreen.kt:386)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_back, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
