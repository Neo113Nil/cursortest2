package com.chicken.road.nevsdomy.data.db;

import androidx.room.RoomDatabase;
import kotlin.Metadata;

/* compiled from: StraitWatchDatabase.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0007H&Ê\u0001*\b\n\u0012\u0012\b\u000b\u0012\u000e\b\fJ\u0004\b\t0\fJ\u0004\b\t0\r\u0012\b\b\u000e\u0012\u0004\b\u0003\u0010\u0002\u0012\b\b\u000f\u0012\u0004\b\u0007\u0010\u0002Ê\u0001\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\u0003\u0010\u0000¨\u0006\t"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/StraitWatchDatabase;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "crossingDao", "Lcom/chicken/road/nevsdomy/data/db/CrossingDao;", "sweepStatsDao", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;", "Companion", "app", "Landroidx/room/Database;", "entities", "Lcom/chicken/road/nevsdomy/data/db/CrossingEntity;", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;", "version", "exportSchema", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class StraitWatchDatabase extends RoomDatabase {
    public static final String NAME = "strait_watch.db";
    public static final int $stable = 8;

    public abstract CrossingDao crossingDao();

    public abstract SweepStatsDao sweepStatsDao();
}
