package com.chicken.road.nevsdomy;

import dagger.hilt.android.HiltAndroidApp;
import kotlin.Metadata;

/* compiled from: StraitWatchApp.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003Ê\u0001\u0002\b\u0005Ê\u0001\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0004"}, d2 = {"Lcom/chicken/road/nevsdomy/StraitWatchApp;", "Landroid/app/Application;", "<init>", "()V", "app", "Ldagger/hilt/android/HiltAndroidApp;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
@HiltAndroidApp
/* loaded from: classes2.dex */
public class StraitWatchApp extends Hilt_StraitWatchApp {
    public static final int $stable = 8;
}
