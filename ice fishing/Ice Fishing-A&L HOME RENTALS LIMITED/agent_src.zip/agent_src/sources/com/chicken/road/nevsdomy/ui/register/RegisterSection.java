package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.model.Basin;
import com.chicken.road.nevsdomy.data.model.Strait;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterViewModel.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0003J#\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0001J\u0014\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0013\u001a\u00020\u0014HÖ\u0081\u0004J\n\u0010\u0015\u001a\u00020\u0016HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fÊ\u0001\f\b\u0018\u0012\b\b\u0019\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0017"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/register/RegisterSection;", "", "basin", "Lcom/chicken/road/nevsdomy/data/model/Basin;", "straits", "", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "<init>", "(Lcom/chicken/road/nevsdomy/data/model/Basin;Ljava/util/List;)V", "getBasin", "()Lcom/chicken/road/nevsdomy/data/model/Basin;", "getStraits", "()Ljava/util/List;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class RegisterSection {
    public static final int $stable = 8;
    private final Basin basin;
    private final List<Strait> straits;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ RegisterSection copy$default(RegisterSection registerSection, Basin basin, List list, int i, Object obj) {
        if ((i & 1) != 0) {
            basin = registerSection.basin;
        }
        if ((i & 2) != 0) {
            list = registerSection.straits;
        }
        return registerSection.copy(basin, list);
    }

    /* renamed from: component1, reason: from getter */
    public final Basin getBasin() {
        return this.basin;
    }

    public final List<Strait> component2() {
        return this.straits;
    }

    public final RegisterSection copy(Basin basin, List<Strait> straits) {
        Intrinsics.checkNotNullParameter(basin, "basin");
        Intrinsics.checkNotNullParameter(straits, "straits");
        return new RegisterSection(basin, straits);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RegisterSection)) {
            return false;
        }
        RegisterSection registerSection = (RegisterSection) other;
        return this.basin == registerSection.basin && Intrinsics.areEqual(this.straits, registerSection.straits);
    }

    public int hashCode() {
        return (this.basin.hashCode() * 31) + this.straits.hashCode();
    }

    public String toString() {
        return "RegisterSection(basin=" + this.basin + ", straits=" + this.straits + ")";
    }

    public RegisterSection(Basin basin, List<Strait> straits) {
        Intrinsics.checkNotNullParameter(basin, "basin");
        Intrinsics.checkNotNullParameter(straits, "straits");
        this.basin = basin;
        this.straits = straits;
    }

    public final Basin getBasin() {
        return this.basin;
    }

    public final List<Strait> getStraits() {
        return this.straits;
    }
}
