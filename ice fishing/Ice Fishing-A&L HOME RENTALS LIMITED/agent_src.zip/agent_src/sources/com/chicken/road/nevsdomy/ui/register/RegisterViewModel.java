package com.chicken.road.nevsdomy.ui.register;

import androidx.lifecycle.CoroutineLiveDataKt;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.chicken.road.nevsdomy.data.model.Basin;
import com.chicken.road.nevsdomy.data.model.SortOrder;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.enums.EnumEntries;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: RegisterViewModel.kt */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0015\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u001a\u0002\b\u0006¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0010J\u000e\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019J\f\u0010\u001a\u001a\u00020\f*\u00020\tH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eÊ\u0001\u0002\b\u001cÊ\u0001\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u001b"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/register/RegisterViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;", "<init>", "(Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;)V", "Ljavax/inject/Inject;", "filters", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/chicken/road/nevsdomy/ui/register/RegisterFilters;", "uiState", "Lkotlinx/coroutines/flow/StateFlow;", "Lcom/chicken/road/nevsdomy/ui/register/RegisterUiState;", "getUiState", "()Lkotlinx/coroutines/flow/StateFlow;", "onQueryChange", "", "value", "", "onClearQuery", "onTagClick", "tag", "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "onSortSelected", "order", "Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "toUiState", "app", "Ldagger/hilt/android/lifecycle/HiltViewModel;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class RegisterViewModel extends ViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<RegisterFilters> filters;
    private final StraitRepository repository;
    private final StateFlow<RegisterUiState> uiState;

    /* compiled from: RegisterViewModel.kt */
    @Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[SortOrder.values().length];
            try {
                iArr[SortOrder.REGISTER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[SortOrder.NARROWEST.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[SortOrder.DEEPEST.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[SortOrder.BUSIEST.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    @Inject
    public RegisterViewModel(StraitRepository repository) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        MutableStateFlow<RegisterFilters> MutableStateFlow = StateFlowKt.MutableStateFlow(new RegisterFilters(null, null, null, 7, null));
        this.filters = MutableStateFlow;
        String str = null;
        StraitTag straitTag = null;
        SortOrder sortOrder = null;
        this.uiState = FlowKt.stateIn(new RegisterViewModel$special$$inlined$map$1(MutableStateFlow, this), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null), toUiState(new RegisterFilters(str, straitTag, sortOrder, 7, null)));
    }

    public final StateFlow<RegisterUiState> getUiState() {
        return this.uiState;
    }

    public final void onQueryChange(String value) {
        Intrinsics.checkNotNullParameter(value, "value");
        MutableStateFlow<RegisterFilters> mutableStateFlow = this.filters;
        mutableStateFlow.setValue(RegisterFilters.copy$default(mutableStateFlow.getValue(), value, null, null, 6, null));
    }

    public final void onClearQuery() {
        MutableStateFlow<RegisterFilters> mutableStateFlow = this.filters;
        mutableStateFlow.setValue(RegisterFilters.copy$default(mutableStateFlow.getValue(), "", null, null, 6, null));
    }

    public final void onTagClick(StraitTag tag) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        RegisterFilters value = this.filters.getValue();
        MutableStateFlow<RegisterFilters> mutableStateFlow = this.filters;
        if (value.getActiveTag() == tag) {
            tag = null;
        }
        mutableStateFlow.setValue(RegisterFilters.copy$default(value, null, tag, null, 5, null));
    }

    public final void onSortSelected(SortOrder order) {
        Intrinsics.checkNotNullParameter(order, "order");
        MutableStateFlow<RegisterFilters> mutableStateFlow = this.filters;
        mutableStateFlow.setValue(RegisterFilters.copy$default(mutableStateFlow.getValue(), null, null, order, 3, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0089  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final RegisterUiState toUiState(RegisterFilters registerFilters) {
        boolean z;
        String lowerCase = StringsKt.trim((CharSequence) registerFilters.getQuery()).toString().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        List<Strait> straits = this.repository.getStraits();
        ArrayList arrayList = new ArrayList();
        Iterator<T> it = straits.iterator();
        while (true) {
            boolean z2 = true;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            Strait strait = (Strait) next;
            String str = lowerCase;
            if (str.length() == 0) {
                z = true;
            } else {
                String lowerCase2 = strait.getName().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (!StringsKt.contains$default((CharSequence) lowerCase2, (CharSequence) str, false, 2, (Object) null)) {
                    String lowerCase3 = strait.getSeaA().toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                    if (!StringsKt.contains$default((CharSequence) lowerCase3, (CharSequence) str, false, 2, (Object) null)) {
                        String lowerCase4 = strait.getSeaB().toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
                        if (!StringsKt.contains$default((CharSequence) lowerCase4, (CharSequence) str, false, 2, (Object) null)) {
                            z = false;
                        }
                    }
                }
            }
            if (registerFilters.getActiveTag() != null && !strait.getTags().contains(registerFilters.getActiveTag())) {
                z2 = false;
            }
            if (z && z2) {
                arrayList.add(next);
            }
        }
        ArrayList arrayListSortedWith = arrayList;
        int i = WhenMappings.$EnumSwitchMapping$0[registerFilters.getSortOrder().ordinal()];
        if (i != 1) {
            if (i == 2) {
                arrayListSortedWith = CollectionsKt.sortedWith(arrayListSortedWith, new Comparator() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterViewModel$toUiState$$inlined$sortedBy$1
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t, T t2) {
                        return ComparisonsKt.compareValues(Double.valueOf(((Strait) t).getNarrowestKm()), Double.valueOf(((Strait) t2).getNarrowestKm()));
                    }
                });
            } else if (i == 3) {
                arrayListSortedWith = CollectionsKt.sortedWith(arrayListSortedWith, new Comparator() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterViewModel$toUiState$$inlined$sortedByDescending$1
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t, T t2) {
                        return ComparisonsKt.compareValues(Integer.valueOf(((Strait) t2).getDeepestM()), Integer.valueOf(((Strait) t).getDeepestM()));
                    }
                });
            } else {
                if (i != 4) {
                    throw new NoWhenBranchMatchedException();
                }
                arrayListSortedWith = CollectionsKt.sortedWith(arrayListSortedWith, new Comparator() { // from class: com.chicken.road.nevsdomy.ui.register.RegisterViewModel$toUiState$$inlined$sortedByDescending$2
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t, T t2) {
                        return ComparisonsKt.compareValues(Integer.valueOf(((Strait) t2).getShipsPerDay()), Integer.valueOf(((Strait) t).getShipsPerDay()));
                    }
                });
            }
        }
        EnumEntries<Basin> entries = Basin.getEntries();
        ArrayList arrayList2 = new ArrayList();
        for (Basin basin : entries) {
            ArrayList arrayList3 = new ArrayList();
            for (Object obj : arrayListSortedWith) {
                if (((Strait) obj).getBasin() == basin) {
                    arrayList3.add(obj);
                }
            }
            ArrayList arrayList4 = arrayList3;
            RegisterSection registerSection = arrayList4.isEmpty() ? null : new RegisterSection(basin, arrayList4);
            if (registerSection != null) {
                arrayList2.add(registerSection);
            }
        }
        return new RegisterUiState(registerFilters.getQuery(), registerFilters.getActiveTag(), registerFilters.getSortOrder(), arrayList2);
    }
}
