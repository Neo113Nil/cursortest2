package com.chicken.road.nevsdomy.ui.beaconsweep;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: BeaconSweepViewModel.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepStage;", "", "<init>", "(Ljava/lang/String;I)V", "IDLE", "PLAYING", "OVER", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class SweepStage {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ SweepStage[] $VALUES;
    public static final SweepStage IDLE = new SweepStage("IDLE", 0);
    public static final SweepStage PLAYING = new SweepStage("PLAYING", 1);
    public static final SweepStage OVER = new SweepStage("OVER", 2);

    private static final /* synthetic */ SweepStage[] $values() {
        return new SweepStage[]{IDLE, PLAYING, OVER};
    }

    public static EnumEntries<SweepStage> getEntries() {
        return $ENTRIES;
    }

    public static SweepStage valueOf(String str) {
        return (SweepStage) Enum.valueOf(SweepStage.class, str);
    }

    public static SweepStage[] values() {
        return (SweepStage[]) $VALUES.clone();
    }

    static {
        SweepStage[] sweepStageArr$values = $values();
        $VALUES = sweepStageArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(sweepStageArr$values);
    }

    private SweepStage(String str, int i) {
    }
}
