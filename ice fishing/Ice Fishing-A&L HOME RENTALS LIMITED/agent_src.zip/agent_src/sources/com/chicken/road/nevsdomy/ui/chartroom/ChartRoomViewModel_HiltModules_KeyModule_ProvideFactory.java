package com.chicken.road.nevsdomy.ui.chartroom;

import com.chicken.road.nevsdomy.ui.chartroom.ChartRoomViewModel_HiltModules;
import dagger.internal.Factory;

/* loaded from: classes2.dex */
public final class ChartRoomViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {
    @Override // javax.inject.Provider, jakarta.inject.Provider
    public Boolean get() {
        return Boolean.valueOf(provide());
    }

    public static ChartRoomViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return InstanceHolder.INSTANCE;
    }

    public static boolean provide() {
        return ChartRoomViewModel_HiltModules.KeyModule.provide();
    }

    private static final class InstanceHolder {
        static final ChartRoomViewModel_HiltModules_KeyModule_ProvideFactory INSTANCE = new ChartRoomViewModel_HiltModules_KeyModule_ProvideFactory();

        private InstanceHolder() {
        }
    }
}
