package com.chicken.road.nevsdomy.ui.chartroom;

import com.chicken.road.nevsdomy.data.db.SweepStatsEntity;
import com.chicken.road.nevsdomy.data.model.Strait;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function4;

/* compiled from: ChartRoomViewModel.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\bH\n"}, d2 = {"<anonymous>", "Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomUiState;", "id", "", "crossings", "", "", "stats", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;"}, k = 3, mv = {2, 4, 0}, xi = 48)
@DebugMetadata(c = "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomViewModel$uiState$1", f = "ChartRoomViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
/* loaded from: classes2.dex */
final class ChartRoomViewModel$uiState$1 extends SuspendLambda implements Function4<String, Map<String, ? extends Long>, SweepStatsEntity, Continuation<? super ChartRoomUiState>, Object> {
    /* synthetic */ Object L$0;
    /* synthetic */ Object L$1;
    /* synthetic */ Object L$2;
    int label;
    final /* synthetic */ ChartRoomViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ChartRoomViewModel$uiState$1(ChartRoomViewModel chartRoomViewModel, Continuation<? super ChartRoomViewModel$uiState$1> continuation) {
        super(4, continuation);
        this.this$0 = chartRoomViewModel;
    }

    @Override // kotlin.jvm.functions.Function4
    public /* bridge */ /* synthetic */ Object invoke(String str, Map<String, ? extends Long> map, SweepStatsEntity sweepStatsEntity, Continuation<? super ChartRoomUiState> continuation) {
        return invoke2(str, (Map<String, Long>) map, sweepStatsEntity, continuation);
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final Object invoke2(String str, Map<String, Long> map, SweepStatsEntity sweepStatsEntity, Continuation<? super ChartRoomUiState> continuation) {
        ChartRoomViewModel$uiState$1 chartRoomViewModel$uiState$1 = new ChartRoomViewModel$uiState$1(this.this$0, continuation);
        chartRoomViewModel$uiState$1.L$0 = str;
        chartRoomViewModel$uiState$1.L$1 = map;
        chartRoomViewModel$uiState$1.L$2 = sweepStatsEntity;
        return chartRoomViewModel$uiState$1.invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        String str = (String) this.L$0;
        Map map = (Map) this.L$1;
        SweepStatsEntity sweepStatsEntity = (SweepStatsEntity) this.L$2;
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            ResultKt.throwOnFailure(obj);
            Strait straitStraitById = this.this$0.repository.straitById(str);
            if (straitStraitById == null) {
                straitStraitById = (Strait) CollectionsKt.first((List) this.this$0.repository.getStraits());
            }
            return new ChartRoomUiState(straitStraitById, this.this$0.repository.getStraits().size(), map.size(), sweepStatsEntity.getBestBoards(), sweepStatsEntity.getRunsPlayed());
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
