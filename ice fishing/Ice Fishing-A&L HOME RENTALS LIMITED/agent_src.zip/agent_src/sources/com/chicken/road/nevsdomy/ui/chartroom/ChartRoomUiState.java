package com.chicken.road.nevsdomy.ui.chartroom;

import com.chicken.road.nevsdomy.data.model.Strait;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ChartRoomViewModel.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J;\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u0005HÆ\u0001J\u0014\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u001b\u001a\u00020\u0005HÖ\u0081\u0004J\n\u0010\u001c\u001a\u00020\u001dHÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eÊ\u0001\f\b\u001f\u0012\b\b \u0012\u0004\b\u0003\u0010\u0000¨\u0006\u001e"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomUiState;", "", "featured", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "passagesOnFile", "", "crossingsLogged", "bestBoards", "sweepsRun", "<init>", "(Lcom/chicken/road/nevsdomy/data/model/Strait;IIII)V", "getFeatured", "()Lcom/chicken/road/nevsdomy/data/model/Strait;", "getPassagesOnFile", "()I", "getCrossingsLogged", "getBestBoards", "getSweepsRun", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class ChartRoomUiState {
    public static final int $stable = Strait.$stable;
    private final int bestBoards;
    private final int crossingsLogged;
    private final Strait featured;
    private final int passagesOnFile;
    private final int sweepsRun;

    public static /* synthetic */ ChartRoomUiState copy$default(ChartRoomUiState chartRoomUiState, Strait strait, int i, int i2, int i3, int i4, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            strait = chartRoomUiState.featured;
        }
        if ((i5 & 2) != 0) {
            i = chartRoomUiState.passagesOnFile;
        }
        if ((i5 & 4) != 0) {
            i2 = chartRoomUiState.crossingsLogged;
        }
        if ((i5 & 8) != 0) {
            i3 = chartRoomUiState.bestBoards;
        }
        if ((i5 & 16) != 0) {
            i4 = chartRoomUiState.sweepsRun;
        }
        int i6 = i4;
        int i7 = i2;
        return chartRoomUiState.copy(strait, i, i7, i3, i6);
    }

    /* renamed from: component1, reason: from getter */
    public final Strait getFeatured() {
        return this.featured;
    }

    /* renamed from: component2, reason: from getter */
    public final int getPassagesOnFile() {
        return this.passagesOnFile;
    }

    /* renamed from: component3, reason: from getter */
    public final int getCrossingsLogged() {
        return this.crossingsLogged;
    }

    /* renamed from: component4, reason: from getter */
    public final int getBestBoards() {
        return this.bestBoards;
    }

    /* renamed from: component5, reason: from getter */
    public final int getSweepsRun() {
        return this.sweepsRun;
    }

    public final ChartRoomUiState copy(Strait featured, int passagesOnFile, int crossingsLogged, int bestBoards, int sweepsRun) {
        Intrinsics.checkNotNullParameter(featured, "featured");
        return new ChartRoomUiState(featured, passagesOnFile, crossingsLogged, bestBoards, sweepsRun);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ChartRoomUiState)) {
            return false;
        }
        ChartRoomUiState chartRoomUiState = (ChartRoomUiState) other;
        return Intrinsics.areEqual(this.featured, chartRoomUiState.featured) && this.passagesOnFile == chartRoomUiState.passagesOnFile && this.crossingsLogged == chartRoomUiState.crossingsLogged && this.bestBoards == chartRoomUiState.bestBoards && this.sweepsRun == chartRoomUiState.sweepsRun;
    }

    public int hashCode() {
        return (((((((this.featured.hashCode() * 31) + Integer.hashCode(this.passagesOnFile)) * 31) + Integer.hashCode(this.crossingsLogged)) * 31) + Integer.hashCode(this.bestBoards)) * 31) + Integer.hashCode(this.sweepsRun);
    }

    public String toString() {
        return "ChartRoomUiState(featured=" + this.featured + ", passagesOnFile=" + this.passagesOnFile + ", crossingsLogged=" + this.crossingsLogged + ", bestBoards=" + this.bestBoards + ", sweepsRun=" + this.sweepsRun + ")";
    }

    public ChartRoomUiState(Strait featured, int i, int i2, int i3, int i4) {
        Intrinsics.checkNotNullParameter(featured, "featured");
        this.featured = featured;
        this.passagesOnFile = i;
        this.crossingsLogged = i2;
        this.bestBoards = i3;
        this.sweepsRun = i4;
    }

    public final Strait getFeatured() {
        return this.featured;
    }

    public final int getPassagesOnFile() {
        return this.passagesOnFile;
    }

    public final int getCrossingsLogged() {
        return this.crossingsLogged;
    }

    public final int getBestBoards() {
        return this.bestBoards;
    }

    public final int getSweepsRun() {
        return this.sweepsRun;
    }
}
