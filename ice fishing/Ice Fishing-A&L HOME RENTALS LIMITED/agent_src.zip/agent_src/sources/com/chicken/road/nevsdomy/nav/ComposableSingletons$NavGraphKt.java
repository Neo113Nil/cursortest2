package com.chicken.road.nevsdomy.nav;

import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.MenuKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.StringResources_androidKt;
import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: NavGraph.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$NavGraphKt {
    public static final ComposableSingletons$NavGraphKt INSTANCE = new ComposableSingletons$NavGraphKt();

    /* renamed from: lambda$-1883452057, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f46lambda$1883452057 = ComposableLambdaKt.composableLambdaInstance(-1883452057, false, new Function2() { // from class: com.chicken.road.nevsdomy.nav.ComposableSingletons$NavGraphKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$NavGraphKt.lambda__1883452057$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-996978615, reason: not valid java name */
    private static Function3<Function0<Unit>, Composer, Integer, Unit> f47lambda$996978615 = ComposableLambdaKt.composableLambdaInstance(-996978615, false, new Function3() { // from class: com.chicken.road.nevsdomy.nav.ComposableSingletons$NavGraphKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$NavGraphKt.lambda__996978615$lambda$0((Function0) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1883452057$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8891getLambda$1883452057$app() {
        return f46lambda$1883452057;
    }

    /* renamed from: getLambda$-996978615$app, reason: not valid java name */
    public final Function3<Function0<Unit>, Composer, Integer, Unit> m8892getLambda$996978615$app() {
        return f47lambda$996978615;
    }

    static final Unit lambda__996978615$lambda$0(Function0 open, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(open, "open");
        ComposerKt.sourceInformation(composer, "CN(open)69@2994L197:NavGraph.kt#dpq88o");
        if ((i & 6) == 0) {
            i |= composer.changedInstance(open) ? 4 : 2;
        }
        if (!composer.shouldExecute((i & 19) != 18, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-996978615, i, -1, "com.chicken.road.nevsdomy.nav.ComposableSingletons$NavGraphKt.lambda$-996978615.<anonymous> (NavGraph.kt:69)");
            }
            IconButtonKt.IconButton(open, null, false, null, null, null, f46lambda$1883452057, composer, (i & 14) | 1572864, 62);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1883452057$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C72@3127L39,70@3035L146:NavGraph.kt#dpq88o");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1883452057, i, -1, "com.chicken.road.nevsdomy.nav.ComposableSingletons$NavGraphKt.lambda$-1883452057.<anonymous> (NavGraph.kt:70)");
            }
            IconKt.m2776Iconww6aTOc(MenuKt.getMenu(Icons.Filled.INSTANCE), StringResources_androidKt.stringResource(R.string.cd_open_drawer, composer, 0), (Modifier) null, 0L, composer, 0, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
