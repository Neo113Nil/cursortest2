package com.chicken.road.nevsdomy.ui.beaconsweep;

import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import dagger.internal.Factory;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class BeaconSweepViewModel_Factory implements Factory<BeaconSweepViewModel> {
    private final Provider<StraitRepository> repositoryProvider;

    private BeaconSweepViewModel_Factory(Provider<StraitRepository> repositoryProvider) {
        this.repositoryProvider = repositoryProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public BeaconSweepViewModel get() {
        return newInstance(this.repositoryProvider.get());
    }

    public static BeaconSweepViewModel_Factory create(Provider<StraitRepository> repositoryProvider) {
        return new BeaconSweepViewModel_Factory(repositoryProvider);
    }

    public static BeaconSweepViewModel newInstance(StraitRepository repository) {
        return new BeaconSweepViewModel(repository);
    }
}
