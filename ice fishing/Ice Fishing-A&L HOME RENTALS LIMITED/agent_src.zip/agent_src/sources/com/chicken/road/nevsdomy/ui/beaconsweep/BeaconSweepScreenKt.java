package com.chicken.road.nevsdomy.ui.beaconsweep;

import android.content.res.Resources;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.AspectRatioKt;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.lazy.grid.GridCells;
import androidx.compose.foundation.lazy.grid.LazyGridDslKt;
import androidx.compose.foundation.lazy.grid.LazyGridItemScope;
import androidx.compose.foundation.lazy.grid.LazyGridScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.style.StylePropertiesKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CheckKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.input.nestedscroll.NestedScrollModifierKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.compose.ui.unit.Dp;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.compose.LifecycleEffectKt;
import androidx.lifecycle.compose.LifecyclePauseOrDisposeEffectResult;
import androidx.lifecycle.compose.LifecycleResumePauseEffectScope;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import androidx.profileinstaller.ProfileVerifier;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;

/* compiled from: BeaconSweepScreen.kt */
@Metadata(d1 = {"\u0000N\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u001ad\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\u001d\u0010\u0005\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0003\u0012\u0004\u0012\u00020\u00010\u0006¢\u0006\u0002\b\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0007b\u0002\b\u0007b\f\b\u000b\u0012\b\b\f\u0012\u0004\b\b(\r¢\u0006\u0002\u0010\n\u001a?\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0003b\u0002\b\u0007b\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0017¢\u0006\u0002\u0010\u0014\u001aE\u0010\u0018\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u00102\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u00010\u00062\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0003b\u0002\b\u0007b\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0017¢\u0006\u0002\u0010\u001b\u001a5\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u001e2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003H\u0003b\u0002\b\u0007b\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0017¢\u0006\u0002\u0010 \u001aM\u0010!\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u00102\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0003b\u0002\b\u0007b\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0017¢\u0006\u0002\u0010#¨\u0006$²\u0006\n\u0010\u000f\u001a\u00020\u0010X\u008a\u0084\u0002"}, d2 = {"BeaconSweepScreen", "", "onOpenDrawer", "Lkotlin/Function0;", "onBackToChart", "navigationIcon", "Lkotlin/Function1;", "Landroidx/compose/runtime/Composable;", "viewModel", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepViewModel;", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function3;Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepViewModel;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/ComposableInferredTarget;", "scheme", "[androidx.compose.ui.UiComposable[androidx.compose.ui.UiComposable]]", "IdleBody", "state", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;", "onStart", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/ComposableTarget;", "applier", "androidx.compose.ui.UiComposable", "PlayBody", "onTileTap", "", "(Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "BoardTile", "tile", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepTile;", "onClick", "(Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepTile;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "OverBody", "onAgain", "(Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class BeaconSweepScreenKt {

    /* compiled from: BeaconSweepScreen.kt */
    @Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[SweepStage.values().length];
            try {
                iArr[SweepStage.IDLE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[SweepStage.PLAYING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[SweepStage.OVER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    static final Unit BeaconSweepScreen$lambda$4(Function0 function0, Function0 function02, Function3 function3, BeaconSweepViewModel beaconSweepViewModel, int i, int i2, Composer composer, int i3) {
        BeaconSweepScreen(function0, function02, function3, beaconSweepViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit BoardTile$lambda$1(SweepTile sweepTile, Function0 function0, int i, Composer composer, int i2) {
        BoardTile(sweepTile, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit IdleBody$lambda$1(BeaconSweepUiState beaconSweepUiState, Function0 function0, Modifier modifier, int i, int i2, Composer composer, int i3) {
        IdleBody(beaconSweepUiState, function0, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit OverBody$lambda$1(BeaconSweepUiState beaconSweepUiState, Function0 function0, Function0 function02, Modifier modifier, int i, int i2, Composer composer, int i3) {
        OverBody(beaconSweepUiState, function0, function02, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit PlayBody$lambda$1(BeaconSweepUiState beaconSweepUiState, Function1 function1, Modifier modifier, int i, int i2, Composer composer, int i3) throws Resources.NotFoundException {
        PlayBody(beaconSweepUiState, function1, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0150  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0158  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x01b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void BeaconSweepScreen(final Function0<Unit> onOpenDrawer, final Function0<Unit> onBackToChart, final Function3<? super Function0<Unit>, ? super Composer, ? super Integer, Unit> navigationIcon, BeaconSweepViewModel beaconSweepViewModel, Composer composer, final int i, final int i2) {
        int i3;
        boolean z;
        int i4;
        Composer composer2;
        boolean z2;
        Object objRememberedValue;
        int i5;
        final BeaconSweepViewModel beaconSweepViewModel2 = beaconSweepViewModel;
        Intrinsics.checkNotNullParameter(onOpenDrawer, "onOpenDrawer");
        Intrinsics.checkNotNullParameter(onBackToChart, "onBackToChart");
        Intrinsics.checkNotNullParameter(navigationIcon, "navigationIcon");
        Composer composerStartRestartGroup = composer.startRestartGroup(-924659305);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(BeaconSweepScreen)N(onOpenDrawer,onBackToChart,navigationIcon,viewModel)53@2414L29,54@2487L22,56@2543L99,56@2515L127,63@2756L658,80@3422L738,61@2648L1512:BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(onOpenDrawer) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onBackToChart) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navigationIcon) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            if ((i2 & 8) != 0) {
                i5 = 1024;
                i3 |= i5;
            } else {
                if ((i & 4096) == 0 ? composerStartRestartGroup.changed(beaconSweepViewModel2) : composerStartRestartGroup.changedInstance(beaconSweepViewModel2)) {
                    i5 = 2048;
                }
                i3 |= i5;
            }
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "51@2358L15");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 8) != 0) {
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1192010736, "CC(hiltViewModel)N(viewModelStoreOwner,key)40@1717L7,45@1869L81,46@1962L54:HiltViewModel.kt#gplxbw");
                    ViewModelStoreOwner current = LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    ViewModelProvider.Factory factoryRememberHiltViewModelFactory = HiltViewModelKt.rememberHiltViewModelFactory(ViewModelStoreOwnerDefaults.getViewModelProviderFactory(current), composerStartRestartGroup, 0, 0);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1729797275, "CC(viewModel)N(viewModelStoreOwner,key,factory,extras)58@2688L7,64@2951L63:ViewModel.kt#3tja67");
                    int i6 = i3;
                    z = false;
                    ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(BeaconSweepViewModel.class), current, (String) null, factoryRememberHiltViewModelFactory, ViewModelStoreOwnerDefaults.getViewModelCreationExtras(current), composerStartRestartGroup, 0, 0);
                    composerStartRestartGroup = composerStartRestartGroup;
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    i4 = i6 & (-7169);
                    beaconSweepViewModel2 = (BeaconSweepViewModel) viewModel;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-924659305, i4, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreen (BeaconSweepScreen.kt:52)");
                }
                composer2 = composerStartRestartGroup;
                final State stateCollectAsStateWithLifecycle = FlowExtKt.collectAsStateWithLifecycle(beaconSweepViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer2, 0, 7);
                final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer2, 384, 3);
                Unit unit = Unit.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 460649818, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                z2 = ((((i4 & 7168) ^ 3072) > 2048 || !composer2.changedInstance(beaconSweepViewModel2)) && (i4 & 3072) != 2048) ? z : true;
                objRememberedValue = composer2.rememberedValue();
                if (z2 || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BeaconSweepScreenKt.BeaconSweepScreen$lambda$1$0(beaconSweepViewModel2, (LifecycleResumePauseEffectScope) obj);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                LifecycleEffectKt.LifecycleResumeEffect(unit, (LifecycleOwner) null, (Function1<? super LifecycleResumePauseEffectScope, ? extends LifecyclePauseOrDisposeEffectResult>) objRememberedValue, composer2, 6, 2);
                ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(2122081107, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return BeaconSweepScreenKt.BeaconSweepScreen$lambda$2(topAppBarScrollBehaviorPinnedScrollBehavior, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer2, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(-1007526808, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return BeaconSweepScreenKt.BeaconSweepScreen$lambda$3(beaconSweepViewModel2, onBackToChart, stateCollectAsStateWithLifecycle, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 508);
                composerStartRestartGroup = composer2;
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 8) != 0) {
                    i3 &= -7169;
                }
            }
            i4 = i3;
            z = false;
            composerStartRestartGroup.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
            }
            composer2 = composerStartRestartGroup;
            final State stateCollectAsStateWithLifecycle2 = FlowExtKt.collectAsStateWithLifecycle(beaconSweepViewModel2.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer2, 0, 7);
            final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior2 = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer2, 384, 3);
            Unit unit2 = Unit.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, 460649818, "CC(remember):BeaconSweepScreen.kt#9igjgp");
            if (((i4 & 7168) ^ 3072) > 2048) {
                objRememberedValue = composer2.rememberedValue();
                if (z2) {
                    objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BeaconSweepScreenKt.BeaconSweepScreen$lambda$1$0(beaconSweepViewModel2, (LifecycleResumePauseEffectScope) obj);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    LifecycleEffectKt.LifecycleResumeEffect(unit2, (LifecycleOwner) null, (Function1<? super LifecycleResumePauseEffectScope, ? extends LifecyclePauseOrDisposeEffectResult>) objRememberedValue, composer2, 6, 2);
                    ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior2.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(2122081107, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return BeaconSweepScreenKt.BeaconSweepScreen$lambda$2(topAppBarScrollBehaviorPinnedScrollBehavior2, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composer2, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(-1007526808, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return BeaconSweepScreenKt.BeaconSweepScreen$lambda$3(beaconSweepViewModel2, onBackToChart, stateCollectAsStateWithLifecycle2, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, composer2, 54), composer2, 805306416, 508);
                    composerStartRestartGroup = composer2;
                    if (ComposerKt.isTraceInProgress()) {
                    }
                }
            } else {
                objRememberedValue = composer2.rememberedValue();
                if (z2) {
                }
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        final BeaconSweepViewModel beaconSweepViewModel3 = beaconSweepViewModel2;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return BeaconSweepScreenKt.BeaconSweepScreen$lambda$4(onOpenDrawer, onBackToChart, navigationIcon, beaconSweepViewModel3, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final LifecyclePauseOrDisposeEffectResult BeaconSweepScreen$lambda$1$0(final BeaconSweepViewModel beaconSweepViewModel, final LifecycleResumePauseEffectScope LifecycleResumeEffect) {
        Intrinsics.checkNotNullParameter(LifecycleResumeEffect, "$this$LifecycleResumeEffect");
        beaconSweepViewModel.onScreenResumed();
        return new LifecyclePauseOrDisposeEffectResult() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$BeaconSweepScreen$lambda$1$0$$inlined$onPauseOrDispose$1
            @Override // androidx.lifecycle.compose.LifecyclePauseOrDisposeEffectResult
            public void runPauseOrOnDisposeEffect() {
                LifecycleResumePauseEffectScope lifecycleResumePauseEffectScope = LifecycleResumeEffect;
                beaconSweepViewModel.onScreenPaused();
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit BeaconSweepScreen$lambda$2$0(Function3 function3, Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C72@3082L28:BeaconSweepScreen.kt#gn9yix");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2051361049, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreen.<anonymous>.<anonymous> (BeaconSweepScreen.kt:72)");
            }
            function3.invoke(function0, composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    static final Unit BeaconSweepScreen$lambda$2(TopAppBarScrollBehavior topAppBarScrollBehavior, final Function3 function3, final Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C75@3274L11,76@3349L11,74@3206L183,72@3080L32,64@2770L634:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2122081107, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreen.<anonymous> (BeaconSweepScreen.kt:64)");
            }
            AppBarKt.m2345TopAppBarGHTll3U(ComposableSingletons$BeaconSweepScreenKt.INSTANCE.m8903getLambda$480780521$app(), null, ComposableLambdaKt.rememberComposableLambda(2051361049, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return BeaconSweepScreenKt.BeaconSweepScreen$lambda$2$0(function3, function0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), null, 0.0f, null, TopAppBarDefaults.INSTANCE.m3543topAppBarColors5tl4gsc(MaterialTheme.INSTANCE.getColorScheme(composer, 6).getSurface(), 0L, 0L, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurface(), 0L, 0L, composer, 1572864, 54), topAppBarScrollBehavior, composer, 390, 58);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit BeaconSweepScreen$lambda$3(BeaconSweepViewModel beaconSweepViewModel, Function0 function0, State state, PaddingValues innerPadding, Composer composer, int i) throws Resources.NotFoundException {
        int i2;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation(composer, "CN(innerPadding):BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i2 = (composer.changed(innerPadding) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (composer.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1007526808, i2, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreen.<anonymous> (BeaconSweepScreen.kt:81)");
            }
            Modifier modifierPadding = PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding);
            int i3 = WhenMappings.$EnumSwitchMapping$0[BeaconSweepScreen$lambda$0(state).getStage().ordinal()];
            if (i3 == 1) {
                composer.startReplaceGroup(-1865615082);
                ComposerKt.sourceInformation(composer, "88@3666L19,86@3599L142");
                BeaconSweepUiState beaconSweepUiStateBeaconSweepScreen$lambda$0 = BeaconSweepScreen$lambda$0(state);
                ComposerKt.sourceInformationMarkerStart(composer, -1865613061, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean zChangedInstance = composer.changedInstance(beaconSweepViewModel);
                BeaconSweepScreenKt$BeaconSweepScreen$3$1$1 beaconSweepScreenKt$BeaconSweepScreen$3$1$1RememberedValue = composer.rememberedValue();
                if (zChangedInstance || beaconSweepScreenKt$BeaconSweepScreen$3$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                    beaconSweepScreenKt$BeaconSweepScreen$3$1$1RememberedValue = new BeaconSweepScreenKt$BeaconSweepScreen$3$1$1(beaconSweepViewModel);
                    composer.updateRememberedValue(beaconSweepScreenKt$BeaconSweepScreen$3$1$1RememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                IdleBody(beaconSweepUiStateBeaconSweepScreen$lambda$0, (Function0) ((KFunction) beaconSweepScreenKt$BeaconSweepScreen$3$1$1RememberedValue), modifierPadding, composer, BeaconSweepUiState.$stable, 0);
                composer.endReplaceGroup();
            } else if (i3 == 2) {
                composer.startReplaceGroup(-1865609383);
                ComposerKt.sourceInformation(composer, "94@3846L20,92@3777L145");
                BeaconSweepUiState beaconSweepUiStateBeaconSweepScreen$lambda$02 = BeaconSweepScreen$lambda$0(state);
                ComposerKt.sourceInformationMarkerStart(composer, -1865607300, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean zChangedInstance2 = composer.changedInstance(beaconSweepViewModel);
                BeaconSweepScreenKt$BeaconSweepScreen$3$2$1 beaconSweepScreenKt$BeaconSweepScreen$3$2$1RememberedValue = composer.rememberedValue();
                if (zChangedInstance2 || beaconSweepScreenKt$BeaconSweepScreen$3$2$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                    beaconSweepScreenKt$BeaconSweepScreen$3$2$1RememberedValue = new BeaconSweepScreenKt$BeaconSweepScreen$3$2$1(beaconSweepViewModel);
                    composer.updateRememberedValue(beaconSweepScreenKt$BeaconSweepScreen$3$2$1RememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                PlayBody(beaconSweepUiStateBeaconSweepScreen$lambda$02, (Function1) ((KFunction) beaconSweepScreenKt$BeaconSweepScreen$3$2$1RememberedValue), modifierPadding, composer, BeaconSweepUiState.$stable, 0);
                composer.endReplaceGroup();
            } else {
                if (i3 != 3) {
                    composer.startReplaceGroup(-1865616281);
                    composer.endReplaceGroup();
                    throw new NoWhenBranchMatchedException();
                }
                composer.startReplaceGroup(-1865603643);
                ComposerKt.sourceInformation(composer, "100@4022L19,98@3955L189");
                BeaconSweepUiState beaconSweepUiStateBeaconSweepScreen$lambda$03 = BeaconSweepScreen$lambda$0(state);
                ComposerKt.sourceInformationMarkerStart(composer, -1865601669, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean zChangedInstance3 = composer.changedInstance(beaconSweepViewModel);
                BeaconSweepScreenKt$BeaconSweepScreen$3$3$1 beaconSweepScreenKt$BeaconSweepScreen$3$3$1RememberedValue = composer.rememberedValue();
                if (zChangedInstance3 || beaconSweepScreenKt$BeaconSweepScreen$3$3$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                    beaconSweepScreenKt$BeaconSweepScreen$3$3$1RememberedValue = new BeaconSweepScreenKt$BeaconSweepScreen$3$3$1(beaconSweepViewModel);
                    composer.updateRememberedValue(beaconSweepScreenKt$BeaconSweepScreen$3$3$1RememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                OverBody(beaconSweepUiStateBeaconSweepScreen$lambda$03, (Function0) ((KFunction) beaconSweepScreenKt$BeaconSweepScreen$3$3$1RememberedValue), function0, modifierPadding, composer, BeaconSweepUiState.$stable, 0);
                composer.endReplaceGroup();
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0102  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:69:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void IdleBody(final BeaconSweepUiState beaconSweepUiState, final Function0<Unit> function0, Modifier modifier, Composer composer, final int i, final int i2) {
        int i3;
        Modifier modifier2;
        final Modifier modifier3;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        Composer composerStartRestartGroup = composer.startRestartGroup(-1780633937);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(IdleBody)N(state,onStart,modifier)119@4554L2738,114@4297L2995:BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i3 = ((i & 8) == 0 ? composerStartRestartGroup.changed(beaconSweepUiState) : composerStartRestartGroup.changedInstance(beaconSweepUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        int i4 = i2 & 4;
        if (i4 == 0) {
            if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                Modifier.Companion companion = i4 != 0 ? Modifier.INSTANCE : modifier2;
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-1780633937, i3, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.IdleBody (BeaconSweepScreen.kt:113)");
                }
                PaddingValues paddingValuesM1084PaddingValuesYgX7TsA = PaddingKt.m1084PaddingValuesYgX7TsA(Spacing.INSTANCE.m8932getLD9Ej5fM(), Spacing.INSTANCE.m8935getXlD9Ej5fM());
                Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8932getLD9Ej5fM());
                Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1792215071, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean z = ((i3 & 14) == 4 || ((i3 & 8) != 0 && composerStartRestartGroup.changedInstance(beaconSweepUiState))) | ((i3 & StylePropertiesKt.TextDirectionMask) == 32);
                Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda19
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BeaconSweepScreenKt.IdleBody$lambda$0$0(beaconSweepUiState, function0, (LazyListScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                Modifier modifier4 = companion;
                LazyDslKt.LazyColumn(modifier4, null, paddingValuesM1084PaddingValuesYgX7TsA, false, horizontalOrVerticalM782spacedBy0680j_4, centerHorizontally, null, false, null, (Function1) objRememberedValue, composerStartRestartGroup, ((i3 >> 6) & 14) | ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 458);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda20
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return BeaconSweepScreenKt.IdleBody$lambda$1(beaconSweepUiState, function0, modifier3, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 384;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit IdleBody$lambda$0$0(final BeaconSweepUiState beaconSweepUiState, final Function0 function0, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.getLambda$2041094266$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.m8900getLambda$1505440477$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.getLambda$518059074$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-1753408671, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return BeaconSweepScreenKt.IdleBody$lambda$0$0$0(beaconSweepUiState, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(270090880, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return BeaconSweepScreenKt.IdleBody$lambda$0$0$1(function0, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit IdleBody$lambda$0$0$0(BeaconSweepUiState beaconSweepUiState, LazyItemScope item, Composer composer, int i) throws Resources.NotFoundException {
        String strStringResource;
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C177@6786L10,171@6511L392:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1753408671, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.IdleBody.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:171)");
            }
            if (beaconSweepUiState.getRunsPlayed() == 0) {
                composer.startReplaceGroup(-405391887);
                ComposerKt.sourceInformation(composer, "173@6589L40");
                strStringResource = StringResources_androidKt.stringResource(R.string.sweep_best_none, composer, 0);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-405306172);
                ComposerKt.sourceInformation(composer, "175@6675L53");
                strStringResource = StringResources_androidKt.stringResource(R.string.sweep_best, new Object[]{Integer.valueOf(beaconSweepUiState.getBestBoards())}, composer, 0);
                composer.endReplaceGroup();
            }
            TextKt.m3328TextNvy7gAk(strStringResource, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleMedium(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit IdleBody$lambda$0$0$1(Function0 function0, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C183@6941L335:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(270090880, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.IdleBody.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:183)");
            }
            ButtonKt.Button(function0, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.m8904getLambda$903540592$app(), composer, 805306416, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x044c  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x045a  */
    /* JADX WARN: Removed duplicated region for block: B:106:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x03f5  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x03fe  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x040a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0446  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void PlayBody(final BeaconSweepUiState beaconSweepUiState, Function1<? super Integer, Unit> function1, Modifier modifier, Composer composer, final int i, final int i2) throws Resources.NotFoundException {
        int i3;
        Modifier modifier2;
        final Function1<? super Integer, Unit> function12;
        Composer composer2;
        final Modifier modifier3;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        String strStringResource;
        final BeaconSweepUiState beaconSweepUiState2;
        boolean z;
        boolean z2;
        Object objRememberedValue;
        Composer composerStartRestartGroup = composer.startRestartGroup(235992238);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(PlayBody)N(state,onTileTap,modifier)201@7434L2002:BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i3 = ((i & 8) == 0 ? composerStartRestartGroup.changed(beaconSweepUiState) : composerStartRestartGroup.changedInstance(beaconSweepUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function1) ? 32 : 16;
        }
        int i4 = i2 & 4;
        if (i4 == 0) {
            if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                function12 = function1;
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                Modifier.Companion companion = i4 != 0 ? Modifier.INSTANCE : modifier2;
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(235992238, i3, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.PlayBody (BeaconSweepScreen.kt:200)");
                }
                Modifier modifierM1092paddingVpY3zN4$default = PaddingKt.m1092paddingVpY3zN4$default(companion, Spacing.INSTANCE.m8932getLD9Ej5fM(), 0.0f, 2, null);
                Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1092paddingVpY3zN4$default);
                Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                Modifier modifier4 = companion;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composerStartRestartGroup);
                Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -2047932781, "C207@7637L139,211@7812L10,206@7612L362,217@8031L22,216@7983L129,220@8121L780,245@9230L200,239@8910L520:BeaconSweepScreen.kt#gn9yix");
                StraitTag call = beaconSweepUiState.getCall();
                int i5 = R.string.sweep_call;
                if (call == null) {
                    composerStartRestartGroup.startReplaceGroup(-2047849146);
                    composerStartRestartGroup.endReplaceGroup();
                    strStringResource = "";
                } else {
                    composerStartRestartGroup.startReplaceGroup(-204606699);
                    ComposerKt.sourceInformation(composerStartRestartGroup, "209@7732L29");
                    strStringResource = StringResources_androidKt.stringResource(call.getLabelRes(), composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                }
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(i5, new Object[]{strStringResource}, composerStartRestartGroup, 0), PaddingKt.m1094paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, Spacing.INSTANCE.m8933getMD9Ej5fM(), 0.0f, 0.0f, 13, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getTitleLarge(), composerStartRestartGroup, 0, 24960, 110588);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -204597138, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                int i6 = i3 & 14;
                boolean z3 = i6 == 4 || ((i3 & 8) != 0 && composerStartRestartGroup.changedInstance(beaconSweepUiState));
                Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (z3 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return Float.valueOf(beaconSweepUiState.getLampFraction());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                int i7 = i3;
                ProgressIndicatorKt.m2991LinearProgressIndicatorGJbTh5U((Function0) objRememberedValue2, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 0L, 0L, 0, 0.0f, null, composerStartRestartGroup, 48, 124);
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.HorizontalOrVertical spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, Alignment.INSTANCE.getTop(), composerStartRestartGroup, 6);
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxWidth$default);
                Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor2);
                } else {
                    composerStartRestartGroup.useNode();
                }
                Composer composerM4604constructorimpl2 = Updater.m4604constructorimpl(composerStartRestartGroup);
                Updater.m4612setimpl(composerM4604constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m4612setimpl(composerM4604constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Updater.m4612setimpl(composerM4604constructorimpl2, Integer.valueOf(iHashCode2), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                Updater.m4610reconcileimpl(composerM4604constructorimpl2, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                Updater.m4612setimpl(composerM4604constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 471641368, "C225@8289L54,226@8383L10,227@8444L11,224@8260L307,232@8609L58,233@8707L10,234@8768L11,231@8580L311:BeaconSweepScreen.kt#gn9yix");
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_lamp, new Object[]{Integer.valueOf(beaconSweepUiState.getSecondsLeft())}, composerStartRestartGroup, 0), null, MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getBodyMedium(), composerStartRestartGroup, 0, 24960, 110586);
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_boards, new Object[]{Integer.valueOf(beaconSweepUiState.getBoardsCleared())}, composerStartRestartGroup, 0), null, MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, 6).getBodyMedium(), composerStartRestartGroup, 0, 24960, 110586);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                GridCells.Fixed fixed = new GridCells.Fixed(3);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                PaddingValues paddingValuesM1085PaddingValuesYgX7TsA$default = PaddingKt.m1085PaddingValuesYgX7TsA$default(0.0f, Spacing.INSTANCE.m8934getSD9Ej5fM(), 1, null);
                Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_42 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
                GridCells.Fixed fixed2 = fixed;
                Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_43 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
                Arrangement.HorizontalOrVertical horizontalOrVertical = horizontalOrVerticalM782spacedBy0680j_42;
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -204558592, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                if (i6 != 4) {
                    if ((i7 & 8) != 0) {
                        beaconSweepUiState2 = beaconSweepUiState;
                        if (composerStartRestartGroup.changedInstance(beaconSweepUiState2)) {
                        }
                        z2 = z | ((i7 & StylePropertiesKt.TextDirectionMask) == 32);
                        objRememberedValue = composerStartRestartGroup.rememberedValue();
                        if (z2 || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            function12 = function1;
                            objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda11
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return BeaconSweepScreenKt.PlayBody$lambda$0$2$0(beaconSweepUiState2, function12, (LazyGridScope) obj);
                                }
                            };
                            composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                        } else {
                            function12 = function1;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        composer2 = composerStartRestartGroup;
                        LazyGridDslKt.LazyVerticalGrid(fixed2, modifierFillMaxWidth$default2, null, paddingValuesM1085PaddingValuesYgX7TsA$default, false, horizontalOrVerticalM782spacedBy0680j_43, horizontalOrVertical, null, false, null, (Function1) objRememberedValue, composer2, 48, 0, 916);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                        modifier3 = modifier4;
                    } else {
                        beaconSweepUiState2 = beaconSweepUiState;
                    }
                    z = false;
                    z2 = z | ((i7 & StylePropertiesKt.TextDirectionMask) == 32);
                    objRememberedValue = composerStartRestartGroup.rememberedValue();
                    if (z2) {
                        function12 = function1;
                        objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return BeaconSweepScreenKt.PlayBody$lambda$0$2$0(beaconSweepUiState2, function12, (LazyGridScope) obj);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                        ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        composer2 = composerStartRestartGroup;
                        LazyGridDslKt.LazyVerticalGrid(fixed2, modifierFillMaxWidth$default2, null, paddingValuesM1085PaddingValuesYgX7TsA$default, false, horizontalOrVerticalM782spacedBy0680j_43, horizontalOrVertical, null, false, null, (Function1) objRememberedValue, composer2, 48, 0, 916);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (ComposerKt.isTraceInProgress()) {
                        }
                        modifier3 = modifier4;
                    }
                } else {
                    beaconSweepUiState2 = beaconSweepUiState;
                }
                z = true;
                z2 = z | ((i7 & StylePropertiesKt.TextDirectionMask) == 32);
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (z2) {
                }
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                final Function1<? super Integer, Unit> function13 = function12;
                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return BeaconSweepScreenKt.PlayBody$lambda$1(beaconSweepUiState, function13, modifier3, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 384;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit PlayBody$lambda$0$2$0(BeaconSweepUiState beaconSweepUiState, final Function1 function1, LazyGridScope LazyVerticalGrid) {
        Intrinsics.checkNotNullParameter(LazyVerticalGrid, "$this$LazyVerticalGrid");
        final List<SweepTile> tiles = beaconSweepUiState.getTiles();
        final Function2 function2 = new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return BeaconSweepScreenKt.PlayBody$lambda$0$2$0$0(((Integer) obj).intValue(), (SweepTile) obj2);
            }
        };
        LazyVerticalGrid.items(tiles.size(), new Function1<Integer, Object>() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$PlayBody$lambda$0$2$0$$inlined$itemsIndexed$default$1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                return function2.invoke(Integer.valueOf(i), tiles.get(i));
            }
        }, null, new Function1<Integer, Object>() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$PlayBody$lambda$0$2$0$$inlined$itemsIndexed$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int i) {
                tiles.get(i);
                return null;
            }
        }, ComposableLambdaKt.composableLambdaInstance(-1942245546, true, new Function4<LazyGridItemScope, Integer, Composer, Integer, Unit>() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$PlayBody$lambda$0$2$0$$inlined$itemsIndexed$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyGridItemScope lazyGridItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyGridItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyGridItemScope lazyGridItemScope, final int i, Composer composer, int i2) {
                int i3;
                ComposerKt.sourceInformation(composer, "CN(it)576@25926L26:LazyGridDsl.kt#7791vq");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyGridItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-1942245546, i3, -1, "androidx.compose.foundation.lazy.grid.itemsIndexed.<anonymous> (LazyGridDsl.kt:576)");
                }
                SweepTile sweepTile = (SweepTile) tiles.get(i);
                composer.startReplaceGroup(-1056503461);
                ComposerKt.sourceInformation(composer, "CN(index,tile)*247@9385L20,247@9352L54:BeaconSweepScreen.kt#gn9yix");
                ComposerKt.sourceInformationMarkerStart(composer, 935751590, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean zChanged = composer.changed(function1) | ((((i3 & StylePropertiesKt.TextDirectionMask) ^ 48) > 32 && composer.changed(i)) || (i3 & 48) == 32);
                Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    final Function1 function12 = function1;
                    objRememberedValue = (Function0) new Function0<Unit>() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$PlayBody$1$3$1$2$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function12.invoke(Integer.valueOf(i));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                BeaconSweepScreenKt.BoardTile(sweepTile, (Function0) objRememberedValue, composer, SweepTile.$stable);
                composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object PlayBody$lambda$0$2$0$0(int i, SweepTile tile) {
        Intrinsics.checkNotNullParameter(tile, "tile");
        return tile.getStrait().getId() + i;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void BoardTile(final SweepTile sweepTile, final Function0<Unit> function0, Composer composer, final int i) {
        int i2;
        long surface;
        long onSurface;
        Composer composerStartRestartGroup = composer.startRestartGroup(-22706891);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(BoardTile)N(tile,onClick)272@10171L189,278@10395L48,279@10451L1235,265@9928L1758:BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? composerStartRestartGroup.changed(sweepTile) : composerStartRestartGroup.changedInstance(sweepTile) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-22706891, i2, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BoardTile (BeaconSweepScreen.kt:254)");
            }
            if (sweepTile.getLocked()) {
                composerStartRestartGroup.startReplaceGroup(-346481604);
                ComposerKt.sourceInformation(composerStartRestartGroup, "256@9578L11");
                surface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getPrimary();
                composerStartRestartGroup.endReplaceGroup();
            } else if (sweepTile.getWrong()) {
                composerStartRestartGroup.startReplaceGroup(-346479805);
                ComposerKt.sourceInformation(composerStartRestartGroup, "257@9634L11");
                surface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getErrorContainer();
                composerStartRestartGroup.endReplaceGroup();
            } else {
                composerStartRestartGroup.startReplaceGroup(-346477988);
                ComposerKt.sourceInformation(composerStartRestartGroup, "258@9691L11");
                surface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getSurface();
                composerStartRestartGroup.endReplaceGroup();
            }
            long j = surface;
            if (sweepTile.getLocked()) {
                composerStartRestartGroup.startReplaceGroup(-346475170);
                ComposerKt.sourceInformation(composerStartRestartGroup, "261@9779L11");
                onSurface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnPrimary();
                composerStartRestartGroup.endReplaceGroup();
            } else if (sweepTile.getWrong()) {
                composerStartRestartGroup.startReplaceGroup(-346473307);
                ComposerKt.sourceInformation(composerStartRestartGroup, "262@9837L11");
                onSurface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnErrorContainer();
                composerStartRestartGroup.endReplaceGroup();
            } else {
                composerStartRestartGroup.startReplaceGroup(-346471426);
                ComposerKt.sourceInformation(composerStartRestartGroup, "263@9896L11");
                onSurface = MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, 6).getOnSurface();
                composerStartRestartGroup.endReplaceGroup();
            }
            long j2 = onSurface;
            int i3 = ((i2 >> 3) & 14) | 100663344;
            CardKt.Card(function0, AspectRatioKt.aspectRatio$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 1.0f, false, 2, null), (sweepTile.getLocked() || sweepTile.getWrong()) ? false : true, RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), CardDefaults.INSTANCE.m2399cardColorsro_MJ88(j, j2, j, j2, composerStartRestartGroup, 24576, 0), CardDefaults.INSTANCE.m2400cardElevationaqJV_2Y(Dp.m8373constructorimpl(Spacing.INSTANCE.m8936getXsD9Ej5fM() / 2.0f), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, composerStartRestartGroup, 1572864, 62), null, null, ComposableLambdaKt.rememberComposableLambda(1223831210, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return BeaconSweepScreenKt.BoardTile$lambda$0(sweepTile, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, i3, 192);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return BeaconSweepScreenKt.BoardTile$lambda$1(sweepTile, function0, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    static final Unit BoardTile$lambda$0(SweepTile sweepTile, ColumnScope Card, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation(composer, "C280@10461L1219:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1223831210, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.BoardTile.<anonymous> (BeaconSweepScreen.kt:280)");
            }
            Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composer, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierFillMaxSize$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 2125534479, "C281@10514L800:BeaconSweepScreen.kt#gn9yix");
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8934getSD9Ej5fM());
            Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
            Arrangement.HorizontalOrVertical center = Arrangement.INSTANCE.getCenter();
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(center, centerHorizontally, composer, 54);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl2 = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl2, Integer.valueOf(iHashCode2), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl2, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -220983327, "C290@10886L10,288@10792L221,296@11123L10,294@11030L270:BeaconSweepScreen.kt#gn9yix");
            TextKt.m3328TextNvy7gAk(sweepTile.getStrait().getEmoji(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8308getClipgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getHeadlineSmall(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(sweepTile.getStrait().getName(), null, 0L, null, 0L, null, null, null, 0L, null, TextAlign.m8244boximpl(TextAlign.INSTANCE.m8251getCentere0LSkKk()), 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodySmall(), composer, 0, 24960, 109566);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (sweepTile.getLocked()) {
                composer.startReplaceGroup(2126332108);
                ComposerKt.sourceInformation(composer, "305@11463L40,303@11362L294");
                IconKt.m2776Iconww6aTOc(CheckKt.getCheck(Icons.Filled.INSTANCE), StringResources_androidKt.stringResource(R.string.cd_tile_matched, composer, 0), PaddingKt.m1090padding3ABfNKs(boxScopeInstance.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopEnd()), Spacing.INSTANCE.m8934getSD9Ej5fM()), 0L, composer, 0, 8);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(2126645394);
                composer.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:80:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void OverBody(final BeaconSweepUiState beaconSweepUiState, final Function0<Unit> function0, final Function0<Unit> function02, Modifier modifier, Composer composer, final int i, final int i2) {
        int i3;
        Modifier modifier2;
        Composer composer2;
        final Modifier modifier3;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        Composer composerStartRestartGroup = composer.startRestartGroup(1563385059);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(OverBody)N(state,onAgain,onBackToChart,modifier)327@12111L2733,322@11854L2990:BeaconSweepScreen.kt#gn9yix");
        if ((i & 6) == 0) {
            i3 = ((i & 8) == 0 ? composerStartRestartGroup.changed(beaconSweepUiState) : composerStartRestartGroup.changedInstance(beaconSweepUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function02) ? 256 : 128;
        }
        int i4 = i2 & 8;
        if (i4 == 0) {
            if ((i & 3072) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 2048 : 1024;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                if (i4 != 0) {
                    modifier2 = Modifier.INSTANCE;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(1563385059, i3, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.OverBody (BeaconSweepScreen.kt:321)");
                }
                PaddingValues paddingValuesM1084PaddingValuesYgX7TsA = PaddingKt.m1084PaddingValuesYgX7TsA(Spacing.INSTANCE.m8932getLD9Ej5fM(), Spacing.INSTANCE.m8935getXlD9Ej5fM());
                Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8932getLD9Ej5fM());
                Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
                ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -825496336, "CC(remember):BeaconSweepScreen.kt#9igjgp");
                boolean z = ((i3 & 14) == 4 || ((i3 & 8) != 0 && composerStartRestartGroup.changedInstance(beaconSweepUiState))) | ((i3 & StylePropertiesKt.TextDirectionMask) == 32) | ((i3 & 896) == 256);
                Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function1() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BeaconSweepScreenKt.OverBody$lambda$0$0(beaconSweepUiState, function0, function02, (LazyListScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                int i5 = ((i3 >> 9) & 14) | ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE;
                Modifier modifier4 = modifier2;
                composer2 = composerStartRestartGroup;
                LazyDslKt.LazyColumn(modifier4, null, paddingValuesM1084PaddingValuesYgX7TsA, false, horizontalOrVerticalM782spacedBy0680j_4, centerHorizontally, null, false, null, (Function1) objRememberedValue, composer2, i5, 458);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda17
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return BeaconSweepScreenKt.OverBody$lambda$1(beaconSweepUiState, function0, function02, modifier3, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 3072;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit OverBody$lambda$0$0(final BeaconSweepUiState beaconSweepUiState, final Function0 function0, final Function0 function02, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.m8902getLambda$367342354$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-1653999017, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return BeaconSweepScreenKt.OverBody$lambda$0$0$0(beaconSweepUiState, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-504166730, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return BeaconSweepScreenKt.OverBody$lambda$0$0$1(function0, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(645665557, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return BeaconSweepScreenKt.OverBody$lambda$0$0$2(function02, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit OverBody$lambda$0$0$0(final BeaconSweepUiState beaconSweepUiState, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C341@12589L1480,338@12454L1615:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1653999017, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.OverBody.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:338)");
            }
            CardKt.OutlinedCard(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), null, null, null, ComposableLambdaKt.rememberComposableLambda(-2046815133, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return BeaconSweepScreenKt.OverBody$lambda$0$0$0$0(beaconSweepUiState, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer, 54), composer, 196614, 28);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit OverBody$lambda$0$0$0$0(BeaconSweepUiState beaconSweepUiState, ColumnScope OutlinedCard, Composer composer, int i) {
        Composer composer2 = composer;
        Intrinsics.checkNotNullParameter(OutlinedCard, "$this$OutlinedCard");
        ComposerKt.sourceInformation(composer2, "C342@12607L1448:BeaconSweepScreen.kt#gn9yix");
        if (!composer2.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2046815133, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.OverBody.<anonymous>.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:342)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
            ComposerKt.sourceInformationMarkerStart(composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, centerHorizontally, composer2, 48);
            ComposerKt.sourceInformationMarkerStart(composer2, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer2, 0));
            CompositionLocalMap currentCompositionLocalMap = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                composer2.createNode(constructor);
            } else {
                composer2.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer2);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -512584480, "C359@13413L58,360@13519L10,358@13376L286,365@13720L53,366@13821L10,367@13890L11,364@13683L354:BeaconSweepScreen.kt#gn9yix");
            if (beaconSweepUiState.getBeatTheRecord()) {
                composer2.startReplaceGroup(-512557294);
                ComposerKt.sourceInformation(composer2, "351@13019L39,352@13110L10,353@13183L11,350@12978L355");
                TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_new_best, composer2, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer2, 6).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, 6).getTitleLarge(), composer, 0, 24960, 110586);
                composer2 = composer;
                composer2.endReplaceGroup();
            } else {
                composer2.startReplaceGroup(-512194315);
                composer2.endReplaceGroup();
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_boards, new Object[]{Integer.valueOf(beaconSweepUiState.getBoardsCleared())}, composer2, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, 6).getHeadlineSmall(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.sweep_best, new Object[]{Integer.valueOf(beaconSweepUiState.getBestBoards())}, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110586);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit OverBody$lambda$0$0$1(Function0 function0, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C375@14107L335:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-504166730, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.OverBody.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:375)");
            }
            ButtonKt.Button(function0, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.getLambda$543195334$app(), composer, 805306416, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit OverBody$lambda$0$0$2(Function0 function0, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C385@14480L348:BeaconSweepScreen.kt#gn9yix");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(645665557, i, -1, "com.chicken.road.nevsdomy.ui.beaconsweep.OverBody.<anonymous>.<anonymous>.<anonymous> (BeaconSweepScreen.kt:385)");
            }
            ButtonKt.OutlinedButton(function0, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$BeaconSweepScreenKt.INSTANCE.m8905getLambda$911528605$app(), composer, 805306416, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final BeaconSweepUiState BeaconSweepScreen$lambda$0(State<BeaconSweepUiState> state) {
        return state.getValue();
    }
}
