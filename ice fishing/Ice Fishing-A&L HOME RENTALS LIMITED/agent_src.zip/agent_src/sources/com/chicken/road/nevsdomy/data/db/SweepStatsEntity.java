package com.chicken.road.nevsdomy.data.db;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: Entities.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u0000 \u00172\u00020\u0001:\u0001\u0017B%\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J'\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0014\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0014\u001a\u00020\u0003HÖ\u0081\u0004J\n\u0010\u0015\u001a\u00020\u0016HÖ\u0081\u0004R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\n¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\tÊ\u0001\f\b\u0019\u0012\b\b\u001a\u0012\u0004\b\b(\u001bÊ\u0001\f\b\u001c\u0012\b\b\u001d\u0012\u0004\b\u0003\u0010\u0002¨\u0006\u0018"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;", "", "id", "", "bestBoards", "runsPlayed", "<init>", "(III)V", "getId", "()I", "Landroidx/room/PrimaryKey;", "getBestBoards", "getRunsPlayed", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "Companion", "app", "Landroidx/room/Entity;", "tableName", "sweep_stats", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class SweepStatsEntity {
    public static final int $stable = 0;
    public static final int SINGLETON_ID = 0;
    private final int bestBoards;
    private final int id;
    private final int runsPlayed;

    public SweepStatsEntity() {
        this(0, 0, 0, 7, null);
    }

    public static /* synthetic */ SweepStatsEntity copy$default(SweepStatsEntity sweepStatsEntity, int i, int i2, int i3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = sweepStatsEntity.id;
        }
        if ((i4 & 2) != 0) {
            i2 = sweepStatsEntity.bestBoards;
        }
        if ((i4 & 4) != 0) {
            i3 = sweepStatsEntity.runsPlayed;
        }
        return sweepStatsEntity.copy(i, i2, i3);
    }

    /* renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* renamed from: component2, reason: from getter */
    public final int getBestBoards() {
        return this.bestBoards;
    }

    /* renamed from: component3, reason: from getter */
    public final int getRunsPlayed() {
        return this.runsPlayed;
    }

    public final SweepStatsEntity copy(int id, int bestBoards, int runsPlayed) {
        return new SweepStatsEntity(id, bestBoards, runsPlayed);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SweepStatsEntity)) {
            return false;
        }
        SweepStatsEntity sweepStatsEntity = (SweepStatsEntity) other;
        return this.id == sweepStatsEntity.id && this.bestBoards == sweepStatsEntity.bestBoards && this.runsPlayed == sweepStatsEntity.runsPlayed;
    }

    public int hashCode() {
        return (((Integer.hashCode(this.id) * 31) + Integer.hashCode(this.bestBoards)) * 31) + Integer.hashCode(this.runsPlayed);
    }

    public String toString() {
        return "SweepStatsEntity(id=" + this.id + ", bestBoards=" + this.bestBoards + ", runsPlayed=" + this.runsPlayed + ")";
    }

    public SweepStatsEntity(int i, int i2, int i3) {
        this.id = i;
        this.bestBoards = i2;
        this.runsPlayed = i3;
    }

    public /* synthetic */ SweepStatsEntity(int i, int i2, int i3, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        this((i4 & 1) != 0 ? 0 : i, (i4 & 2) != 0 ? 0 : i2, (i4 & 4) != 0 ? 0 : i3);
    }

    public final int getId() {
        return this.id;
    }

    public final int getBestBoards() {
        return this.bestBoards;
    }

    public final int getRunsPlayed() {
        return this.runsPlayed;
    }
}
