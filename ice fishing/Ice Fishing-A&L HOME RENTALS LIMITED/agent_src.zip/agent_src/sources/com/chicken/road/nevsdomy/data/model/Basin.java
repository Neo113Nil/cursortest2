package com.chicken.road.nevsdomy.data.model;

import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: Strait.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0017\b\u0002\u0012\f\b\u0001\u0010\u0002\u001a\u00020\u0003:\u0002\b\u0004¢\u0006\u0004\b\u0005\u0010\u0006R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f¨\u0006\r"}, d2 = {"Lcom/chicken/road/nevsdomy/data/model/Basin;", "", "titleRes", "", "Landroidx/annotation/StringRes;", "<init>", "(Ljava/lang/String;II)V", "getTitleRes", "()I", "ATLANTIC_GATES", "EASTERN_SEAWAYS", "MONSOON_STRAITS", "PACIFIC_RIM", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class Basin {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ Basin[] $VALUES;
    public static final Basin ATLANTIC_GATES = new Basin("ATLANTIC_GATES", 0, R.string.basin_atlantic_gates);
    public static final Basin EASTERN_SEAWAYS = new Basin("EASTERN_SEAWAYS", 1, R.string.basin_eastern_seaways);
    public static final Basin MONSOON_STRAITS = new Basin("MONSOON_STRAITS", 2, R.string.basin_monsoon_straits);
    public static final Basin PACIFIC_RIM = new Basin("PACIFIC_RIM", 3, R.string.basin_pacific_rim);
    private final int titleRes;

    private static final /* synthetic */ Basin[] $values() {
        return new Basin[]{ATLANTIC_GATES, EASTERN_SEAWAYS, MONSOON_STRAITS, PACIFIC_RIM};
    }

    public static EnumEntries<Basin> getEntries() {
        return $ENTRIES;
    }

    public static Basin valueOf(String str) {
        return (Basin) Enum.valueOf(Basin.class, str);
    }

    public static Basin[] values() {
        return (Basin[]) $VALUES.clone();
    }

    private Basin(String str, int i, int i2) {
        this.titleRes = i2;
    }

    public final int getTitleRes() {
        return this.titleRes;
    }

    static {
        Basin[] basinArr$values = $values();
        $VALUES = basinArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(basinArr$values);
    }
}
