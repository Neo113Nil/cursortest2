package com.chicken.road.nevsdomy.ui.theme;

import androidx.compose.material3.Typography;
import androidx.compose.ui.graphics.Shadow;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.text.PlatformTextStyle;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontSynthesis;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.GenericFontFamily;
import androidx.compose.ui.text.font.SystemFontFamily;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.style.BaselineShift;
import androidx.compose.ui.text.style.LineHeightStyle;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.style.TextGeometricTransform;
import androidx.compose.ui.text.style.TextIndent;
import androidx.compose.ui.text.style.TextMotion;
import androidx.compose.ui.unit.TextUnitKt;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: Type.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000\"\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"ChartHead", "Landroidx/compose/ui/text/font/GenericFontFamily;", "ChartBody", "Landroidx/compose/ui/text/font/SystemFontFamily;", "StraitWatchTypography", "Landroidx/compose/material3/Typography;", "getStraitWatchTypography", "()Landroidx/compose/material3/Typography;", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class TypeKt {
    private static final SystemFontFamily ChartBody;
    private static final GenericFontFamily ChartHead;
    private static final Typography StraitWatchTypography;

    static {
        GenericFontFamily serif = FontFamily.INSTANCE.getSerif();
        ChartHead = serif;
        SystemFontFamily systemFontFamily = FontFamily.INSTANCE.getDefault();
        ChartBody = systemFontFamily;
        FontWeight semiBold = FontWeight.INSTANCE.getSemiBold();
        GenericFontFamily genericFontFamily = serif;
        TextStyle textStyle = new TextStyle(0L, TextUnitKt.getSp(28), semiBold, (FontStyle) null, (FontSynthesis) null, genericFontFamily, (String) null, TextUnitKt.getSp(0), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(34), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight semiBold2 = FontWeight.INSTANCE.getSemiBold();
        GenericFontFamily genericFontFamily2 = serif;
        TextStyle textStyle2 = new TextStyle(0L, TextUnitKt.getSp(24), semiBold2, (FontStyle) null, (FontSynthesis) null, genericFontFamily2, (String) null, TextUnitKt.getSp(0), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(30), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight semiBold3 = FontWeight.INSTANCE.getSemiBold();
        GenericFontFamily genericFontFamily3 = serif;
        TextStyle textStyle3 = new TextStyle(0L, TextUnitKt.getSp(21), semiBold3, (FontStyle) null, (FontSynthesis) null, genericFontFamily3, (String) null, TextUnitKt.getSp(0), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(27), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight semiBold4 = FontWeight.INSTANCE.getSemiBold();
        SystemFontFamily systemFontFamily2 = systemFontFamily;
        TextStyle textStyle4 = new TextStyle(0L, TextUnitKt.getSp(16), semiBold4, (FontStyle) null, (FontSynthesis) null, systemFontFamily2, (String) null, TextUnitKt.getSp(0.1d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(22), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight medium = FontWeight.INSTANCE.getMedium();
        SystemFontFamily systemFontFamily3 = systemFontFamily;
        TextStyle textStyle5 = new TextStyle(0L, TextUnitKt.getSp(14), medium, (FontStyle) null, (FontSynthesis) null, systemFontFamily3, (String) null, TextUnitKt.getSp(0.1d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(20), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight normal = FontWeight.INSTANCE.getNormal();
        SystemFontFamily systemFontFamily4 = systemFontFamily;
        TextStyle textStyle6 = new TextStyle(0L, TextUnitKt.getSp(16), normal, (FontStyle) null, (FontSynthesis) null, systemFontFamily4, (String) null, TextUnitKt.getSp(0.5d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(24), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight normal2 = FontWeight.INSTANCE.getNormal();
        SystemFontFamily systemFontFamily5 = systemFontFamily;
        TextStyle textStyle7 = new TextStyle(0L, TextUnitKt.getSp(14), normal2, (FontStyle) null, (FontSynthesis) null, systemFontFamily5, (String) null, TextUnitKt.getSp(0.25d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(21), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight normal3 = FontWeight.INSTANCE.getNormal();
        SystemFontFamily systemFontFamily6 = systemFontFamily;
        TextStyle textStyle8 = new TextStyle(0L, TextUnitKt.getSp(12), normal3, (FontStyle) null, (FontSynthesis) null, systemFontFamily6, (String) null, TextUnitKt.getSp(0.4d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(17), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight medium2 = FontWeight.INSTANCE.getMedium();
        SystemFontFamily systemFontFamily7 = systemFontFamily;
        TextStyle textStyle9 = new TextStyle(0L, TextUnitKt.getSp(14), medium2, (FontStyle) null, (FontSynthesis) null, systemFontFamily7, (String) null, TextUnitKt.getSp(0.1d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(20), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight medium3 = FontWeight.INSTANCE.getMedium();
        SystemFontFamily systemFontFamily8 = systemFontFamily;
        TextStyle textStyle10 = new TextStyle(0L, TextUnitKt.getSp(12), medium3, (FontStyle) null, (FontSynthesis) null, systemFontFamily8, (String) null, TextUnitKt.getSp(0.5d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(16), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null);
        FontWeight medium4 = FontWeight.INSTANCE.getMedium();
        SystemFontFamily systemFontFamily9 = systemFontFamily;
        StraitWatchTypography = new Typography(null, null, null, null, textStyle, textStyle2, textStyle3, textStyle4, textStyle5, textStyle6, textStyle7, textStyle8, textStyle9, textStyle10, new TextStyle(0L, TextUnitKt.getSp(11), medium4, (FontStyle) null, (FontSynthesis) null, systemFontFamily9, (String) null, TextUnitKt.getSp(0.5d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(16), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null), 15, null);
    }

    public static final Typography getStraitWatchTypography() {
        return StraitWatchTypography;
    }
}
