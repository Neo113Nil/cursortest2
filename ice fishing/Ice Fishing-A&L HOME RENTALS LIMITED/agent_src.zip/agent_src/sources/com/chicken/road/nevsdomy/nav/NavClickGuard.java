package com.chicken.road.nevsdomy.nav;

import android.os.SystemClock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: NavClickGuard.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0014\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000Ê\u0001\f\b\f\u0012\b\b\r\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u000b"}, d2 = {"Lcom/chicken/road/nevsdomy/nav/NavClickGuard;", "", "windowMillis", "", "<init>", "(J)V", "lastAccepted", "run", "", "action", "Lkotlin/Function0;", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class NavClickGuard {
    public static final int $stable = 8;
    private long lastAccepted;
    private final long windowMillis;

    public NavClickGuard() {
        this(0L, 1, null);
    }

    public NavClickGuard(long j) {
        this.windowMillis = j;
    }

    public /* synthetic */ NavClickGuard(long j, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 600L : j);
    }

    public final void run(Function0<Unit> action) {
        Intrinsics.checkNotNullParameter(action, "action");
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (jElapsedRealtime - this.lastAccepted < this.windowMillis) {
            return;
        }
        this.lastAccepted = jElapsedRealtime;
        action.invoke();
    }
}
