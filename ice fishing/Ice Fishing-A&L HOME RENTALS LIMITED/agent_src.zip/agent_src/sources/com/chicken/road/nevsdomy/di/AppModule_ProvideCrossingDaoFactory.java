package com.chicken.road.nevsdomy.di;

import com.chicken.road.nevsdomy.data.db.CrossingDao;
import com.chicken.road.nevsdomy.data.db.StraitWatchDatabase;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class AppModule_ProvideCrossingDaoFactory implements Factory<CrossingDao> {
    private final Provider<StraitWatchDatabase> dbProvider;

    private AppModule_ProvideCrossingDaoFactory(Provider<StraitWatchDatabase> dbProvider) {
        this.dbProvider = dbProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public CrossingDao get() {
        return provideCrossingDao(this.dbProvider.get());
    }

    public static AppModule_ProvideCrossingDaoFactory create(Provider<StraitWatchDatabase> dbProvider) {
        return new AppModule_ProvideCrossingDaoFactory(dbProvider);
    }

    public static CrossingDao provideCrossingDao(StraitWatchDatabase db) {
        return (CrossingDao) Preconditions.checkNotNullFromProvides(AppModule.INSTANCE.provideCrossingDao(db));
    }
}
