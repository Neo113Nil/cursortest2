package com.chicken.road.nevsdomy.ui.beaconsweep;

import kotlin.Metadata;

/* compiled from: BeaconSweepViewModel.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"RUN_SECONDS", "", "BOARD_SIZE", "MIN_MATCHES", "WRONG_TAP_PENALTY", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class BeaconSweepViewModelKt {
    private static final int BOARD_SIZE = 9;
    private static final int MIN_MATCHES = 2;
    public static final int RUN_SECONDS = 40;
    private static final int WRONG_TAP_PENALTY = 3;
}
