package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.model.SortOrder;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final /* synthetic */ class RegisterScreenKt$RegisterScreen$2$1$1$3$1$1 extends FunctionReferenceImpl implements Function1<SortOrder, Unit> {
    RegisterScreenKt$RegisterScreen$2$1$1$3$1$1(Object obj) {
        super(1, obj, RegisterViewModel.class, "onSortSelected", "onSortSelected(Lcom/chicken/road/nevsdomy/data/model/SortOrder;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(SortOrder sortOrder) {
        invoke2(sortOrder);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(SortOrder p0) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        ((RegisterViewModel) this.receiver).onSortSelected(p0);
    }
}
