package com.chicken.road.nevsdomy.ui.chartroom;

import androidx.lifecycle.CoroutineLiveDataKt;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: ChartRoomViewModel.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0015\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u001a\u0002\b\u0006¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u000f\u001a\u00020\u0010R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eÊ\u0001\u0002\b\u0012Ê\u0001\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0011"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;", "<init>", "(Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;)V", "Ljavax/inject/Inject;", "featuredId", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "uiState", "Lkotlinx/coroutines/flow/StateFlow;", "Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomUiState;", "getUiState", "()Lkotlinx/coroutines/flow/StateFlow;", "swingTheGlass", "", "app", "Ldagger/hilt/android/lifecycle/HiltViewModel;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ChartRoomViewModel extends ViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<String> featuredId;
    private final StraitRepository repository;
    private final StateFlow<ChartRoomUiState> uiState;

    @Inject
    public ChartRoomViewModel(StraitRepository repository) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        MutableStateFlow<String> MutableStateFlow = StateFlowKt.MutableStateFlow(((Strait) CollectionsKt.random(repository.getStraits(), Random.INSTANCE)).getId());
        this.featuredId = MutableStateFlow;
        Flow flowCombine = FlowKt.combine(MutableStateFlow, repository.observeCrossings(), repository.observeSweepStats(), new ChartRoomViewModel$uiState$1(this, null));
        CoroutineScope viewModelScope = ViewModelKt.getViewModelScope(this);
        SharingStarted sharingStartedWhileSubscribed$default = SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, CoroutineLiveDataKt.DEFAULT_TIMEOUT, 0L, 2, null);
        Strait straitStraitById = repository.straitById(MutableStateFlow.getValue());
        this.uiState = FlowKt.stateIn(flowCombine, viewModelScope, sharingStartedWhileSubscribed$default, new ChartRoomUiState(straitStraitById == null ? (Strait) CollectionsKt.first((List) repository.getStraits()) : straitStraitById, repository.getStraits().size(), 0, 0, 0));
    }

    public final StateFlow<ChartRoomUiState> getUiState() {
        return this.uiState;
    }

    public final void swingTheGlass() {
        List<Strait> straits = this.repository.getStraits();
        ArrayList arrayList = new ArrayList();
        for (Object obj : straits) {
            if (!Intrinsics.areEqual(((Strait) obj).getId(), this.featuredId.getValue())) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = arrayList;
        if (arrayList2.isEmpty()) {
            return;
        }
        this.featuredId.setValue(((Strait) CollectionsKt.random(arrayList2, Random.INSTANCE)).getId());
    }
}
