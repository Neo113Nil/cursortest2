package com.chicken.road.nevsdomy.data.repository;

import com.chicken.road.nevsdomy.data.db.CrossingDao;
import com.chicken.road.nevsdomy.data.db.SweepStatsDao;
import dagger.internal.Factory;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class StraitRepository_Factory implements Factory<StraitRepository> {
    private final Provider<CrossingDao> crossingDaoProvider;
    private final Provider<SweepStatsDao> sweepStatsDaoProvider;

    private StraitRepository_Factory(Provider<CrossingDao> crossingDaoProvider, Provider<SweepStatsDao> sweepStatsDaoProvider) {
        this.crossingDaoProvider = crossingDaoProvider;
        this.sweepStatsDaoProvider = sweepStatsDaoProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public StraitRepository get() {
        return newInstance(this.crossingDaoProvider.get(), this.sweepStatsDaoProvider.get());
    }

    public static StraitRepository_Factory create(Provider<CrossingDao> crossingDaoProvider, Provider<SweepStatsDao> sweepStatsDaoProvider) {
        return new StraitRepository_Factory(crossingDaoProvider, sweepStatsDaoProvider);
    }

    public static StraitRepository newInstance(CrossingDao crossingDao, SweepStatsDao sweepStatsDao) {
        return new StraitRepository(crossingDao, sweepStatsDao);
    }
}
