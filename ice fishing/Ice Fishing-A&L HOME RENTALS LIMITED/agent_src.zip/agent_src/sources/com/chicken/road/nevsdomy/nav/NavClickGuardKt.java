package com.chicken.road.nevsdomy.nav;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import kotlin.Metadata;

/* compiled from: NavClickGuard.kt */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0011\u0010\u0000\u001a\u00020\u0001H\u0007b\u0002\b\u0003¢\u0006\u0002\u0010\u0002¨\u0006\u0004"}, d2 = {"rememberNavClickGuard", "Lcom/chicken/road/nevsdomy/nav/NavClickGuard;", "(Landroidx/compose/runtime/Composer;I)Lcom/chicken/road/nevsdomy/nav/NavClickGuard;", "Landroidx/compose/runtime/Composable;", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class NavClickGuardKt {
    public static final NavClickGuard rememberNavClickGuard(Composer composer, int i) {
        ComposerKt.sourceInformationMarkerStart(composer, 646310795, "C(rememberNavClickGuard)22@678L28:NavClickGuard.kt#dpq88o");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(646310795, i, -1, "com.chicken.road.nevsdomy.nav.rememberNavClickGuard (NavClickGuard.kt:22)");
        }
        ComposerKt.sourceInformationMarkerStart(composer, -1665582457, "CC(remember):NavClickGuard.kt#9igjgp");
        Object objRememberedValue = composer.rememberedValue();
        if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new NavClickGuard(0L, 1, null);
            composer.updateRememberedValue(objRememberedValue);
        }
        NavClickGuard navClickGuard = (NavClickGuard) objRememberedValue;
        ComposerKt.sourceInformationMarkerEnd(composer);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        ComposerKt.sourceInformationMarkerEnd(composer);
        return navClickGuard;
    }
}
