package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import dagger.internal.Factory;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class RegisterViewModel_Factory implements Factory<RegisterViewModel> {
    private final Provider<StraitRepository> repositoryProvider;

    private RegisterViewModel_Factory(Provider<StraitRepository> repositoryProvider) {
        this.repositoryProvider = repositoryProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public RegisterViewModel get() {
        return newInstance(this.repositoryProvider.get());
    }

    public static RegisterViewModel_Factory create(Provider<StraitRepository> repositoryProvider) {
        return new RegisterViewModel_Factory(repositoryProvider);
    }

    public static RegisterViewModel newInstance(StraitRepository repository) {
        return new RegisterViewModel(repository);
    }
}
