package com.chicken.road.nevsdomy.ui.beaconsweep;

import androidx.core.location.LocationRequestCompat;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.chicken.road.nevsdomy.data.db.SweepStatsEntity;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.data.repository.StraitRepository;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.CancellationException;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* compiled from: BeaconSweepViewModel.kt */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0015\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u001a\u0002\b\u0006¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u0014J\u0006\u0010\u0015\u001a\u00020\u0011J\u0006\u0010\u0016\u001a\u00020\u0011J\b\u0010\u0017\u001a\u00020\u0011H\u0002J\b\u0010\u0018\u001a\u00020\u0011H\u0002J\b\u0010\u0019\u001a\u00020\u0011H\u0002J\b\u0010\u001a\u001a\u00020\u0011H\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000Ê\u0001\u0002\b\u001cÊ\u0001\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u001b"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;", "<init>", "(Lcom/chicken/road/nevsdomy/data/repository/StraitRepository;)V", "Ljavax/inject/Inject;", "_uiState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/chicken/road/nevsdomy/ui/beaconsweep/BeaconSweepUiState;", "uiState", "Lkotlinx/coroutines/flow/StateFlow;", "getUiState", "()Lkotlinx/coroutines/flow/StateFlow;", "lampJob", "Lkotlinx/coroutines/Job;", "startRun", "", "onTileTap", "index", "", "onScreenResumed", "onScreenPaused", "dealBoard", "startLamp", "endRun", "onCleared", "app", "Ldagger/hilt/android/lifecycle/HiltViewModel;", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class BeaconSweepViewModel extends ViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<BeaconSweepUiState> _uiState;
    private Job lampJob;
    private final StraitRepository repository;
    private final StateFlow<BeaconSweepUiState> uiState;

    @Inject
    public BeaconSweepViewModel(StraitRepository repository) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        this.repository = repository;
        MutableStateFlow<BeaconSweepUiState> MutableStateFlow = StateFlowKt.MutableStateFlow(new BeaconSweepUiState(null, null, null, 0, 0, 0, 0, false, 255, null));
        this._uiState = MutableStateFlow;
        this.uiState = FlowKt.asStateFlow(MutableStateFlow);
        FlowKt.launchIn(FlowKt.onEach(repository.observeSweepStats(), new AnonymousClass1(null)), ViewModelKt.getViewModelScope(this));
    }

    public final StateFlow<BeaconSweepUiState> getUiState() {
        return this.uiState;
    }

    /* compiled from: BeaconSweepViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "stats", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;"}, k = 3, mv = {2, 4, 0}, xi = 48)
    @DebugMetadata(c = "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$1", f = "BeaconSweepViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
    /* renamed from: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<SweepStatsEntity, Continuation<? super Unit>, Object> {
        /* synthetic */ Object L$0;
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            AnonymousClass1 anonymousClass1 = BeaconSweepViewModel.this.new AnonymousClass1(continuation);
            anonymousClass1.L$0 = obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(SweepStatsEntity sweepStatsEntity, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(sweepStatsEntity, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            SweepStatsEntity sweepStatsEntity = (SweepStatsEntity) this.L$0;
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            BeaconSweepViewModel.this._uiState.setValue(BeaconSweepUiState.copy$default((BeaconSweepUiState) BeaconSweepViewModel.this._uiState.getValue(), null, null, null, 0, 0, sweepStatsEntity.getBestBoards(), sweepStatsEntity.getRunsPlayed(), false, 159, null));
            return Unit.INSTANCE;
        }
    }

    public final void startRun() {
        if (this._uiState.getValue().getStage() == SweepStage.PLAYING) {
            return;
        }
        MutableStateFlow<BeaconSweepUiState> mutableStateFlow = this._uiState;
        mutableStateFlow.setValue(BeaconSweepUiState.copy$default(mutableStateFlow.getValue(), SweepStage.PLAYING, null, null, 40, 0, 0, 0, false, LocationRequestCompat.QUALITY_BALANCED_POWER_ACCURACY, null));
        dealBoard();
        startLamp();
    }

    public final void onTileTap(int index) {
        SweepTile sweepTile;
        BeaconSweepUiState value = this._uiState.getValue();
        if (value.getStage() != SweepStage.PLAYING || (sweepTile = (SweepTile) CollectionsKt.getOrNull(value.getTiles(), index)) == null || sweepTile.getLocked() || sweepTile.getWrong()) {
            return;
        }
        List mutableList = CollectionsKt.toMutableList((Collection) value.getTiles());
        if (sweepTile.getMatches()) {
            mutableList.set(index, SweepTile.copy$default(sweepTile, null, false, true, false, 11, null));
            List<SweepTile> list = mutableList;
            if (!(list instanceof Collection) || !list.isEmpty()) {
                for (SweepTile sweepTile2 : list) {
                    if (sweepTile2.getMatches() && !sweepTile2.getLocked()) {
                        this._uiState.setValue(BeaconSweepUiState.copy$default(value, null, null, mutableList, 0, 0, 0, 0, false, 251, null));
                        return;
                    }
                    mutableList = mutableList;
                }
            }
            this._uiState.setValue(BeaconSweepUiState.copy$default(value, null, null, mutableList, 0, value.getBoardsCleared() + 1, 0, 0, false, 235, null));
            dealBoard();
            return;
        }
        mutableList.set(index, SweepTile.copy$default(sweepTile, null, false, false, true, 7, null));
        int secondsLeft = value.getSecondsLeft() - 3;
        MutableStateFlow<BeaconSweepUiState> mutableStateFlow = this._uiState;
        if (secondsLeft <= 0) {
            mutableStateFlow.setValue(BeaconSweepUiState.copy$default(value, null, null, mutableList, 0, 0, 0, 0, false, 243, null));
            endRun();
        } else {
            mutableStateFlow.setValue(BeaconSweepUiState.copy$default(value, null, null, mutableList, secondsLeft, 0, 0, 0, false, 243, null));
        }
    }

    public final void onScreenResumed() {
        if (this._uiState.getValue().getStage() == SweepStage.PLAYING) {
            startLamp();
        }
    }

    public final void onScreenPaused() {
        Job job = this.lampJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.lampJob = null;
    }

    private final void dealBoard() {
        int i;
        int i2;
        List<Strait> straits = this.repository.getStraits();
        Object objRandom = CollectionsKt.random(StraitTag.getEntries(), Random.INSTANCE);
        List<Strait> list = straits;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (((Strait) obj).getTags().contains(objRandom)) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = arrayList;
        for (int i3 = 0; arrayList2.size() < 2 && i3 < StraitTag.getEntries().size(); i3++) {
            objRandom = CollectionsKt.random(StraitTag.getEntries(), Random.INSTANCE);
            ArrayList arrayList3 = new ArrayList();
            for (Object obj2 : list) {
                if (((Strait) obj2).getTags().contains(objRandom)) {
                    arrayList3.add(obj2);
                }
            }
            arrayList2 = arrayList3;
        }
        if (arrayList2.size() < 2) {
            Iterator<StraitTag> it = StraitTag.getEntries().iterator();
            if (!it.hasNext()) {
                throw new NoSuchElementException();
            }
            StraitTag next = it.next();
            if (it.hasNext()) {
                StraitTag straitTag = next;
                boolean z = list instanceof Collection;
                if (z && list.isEmpty()) {
                    i = 0;
                } else {
                    Iterator<T> it2 = list.iterator();
                    i = 0;
                    while (it2.hasNext()) {
                        if (((Strait) it2.next()).getTags().contains(straitTag) && (i = i + 1) < 0) {
                            CollectionsKt.throwCountOverflow();
                        }
                    }
                }
                do {
                    StraitTag next2 = it.next();
                    StraitTag straitTag2 = next2;
                    if (z && list.isEmpty()) {
                        i2 = 0;
                    } else {
                        Iterator<T> it3 = list.iterator();
                        i2 = 0;
                        while (it3.hasNext()) {
                            if (((Strait) it3.next()).getTags().contains(straitTag2) && (i2 = i2 + 1) < 0) {
                                CollectionsKt.throwCountOverflow();
                            }
                        }
                    }
                    if (i < i2) {
                        next = next2;
                        i = i2;
                    }
                } while (it.hasNext());
            }
            objRandom = next;
            ArrayList arrayList4 = new ArrayList();
            for (Object obj3 : list) {
                if (((Strait) obj3).getTags().contains(objRandom)) {
                    arrayList4.add(obj3);
                }
            }
            arrayList2 = arrayList4;
        }
        StraitTag straitTag3 = (StraitTag) objRandom;
        ArrayList arrayList5 = new ArrayList();
        for (Object obj4 : list) {
            if (!((Strait) obj4).getTags().contains(straitTag3)) {
                arrayList5.add(obj4);
            }
        }
        List listShuffled = CollectionsKt.shuffled(arrayList5);
        List listTake = CollectionsKt.take(CollectionsKt.shuffled(arrayList2), RangesKt.coerceAtLeast(RangesKt.coerceAtMost(arrayList2.size(), 8), 2));
        List listShuffled2 = CollectionsKt.shuffled(CollectionsKt.plus((Collection) listTake, (Iterable) CollectionsKt.take(listShuffled, 9 - listTake.size())));
        MutableStateFlow<BeaconSweepUiState> mutableStateFlow = this._uiState;
        BeaconSweepUiState value = mutableStateFlow.getValue();
        List<Strait> list2 = listShuffled2;
        ArrayList arrayList6 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
        for (Strait strait : list2) {
            arrayList6.add(new SweepTile(strait, strait.getTags().contains(straitTag3), false, false, 12, null));
        }
        mutableStateFlow.setValue(BeaconSweepUiState.copy$default(value, null, straitTag3, arrayList6, 0, 0, 0, 0, false, 249, null));
    }

    /* compiled from: BeaconSweepViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 4, 0}, xi = 48)
    @DebugMetadata(c = "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$startLamp$1", f = "BeaconSweepViewModel.kt", i = {0}, l = {167}, m = "invokeSuspend", n = {"$this$launch"}, nl = {168}, s = {"L$0"}, v = 2)
    /* renamed from: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$startLamp$1, reason: invalid class name and case insensitive filesystem */
    static final class C03381 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        int label;

        C03381(Continuation<? super C03381> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            C03381 c03381 = BeaconSweepViewModel.this.new C03381(continuation);
            c03381.L$0 = obj;
            return c03381;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03381) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:20:0x0071  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x0074  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0059 -> B:18:0x005c). Please report as a decompilation issue!!! */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            CoroutineScope coroutineScope = (CoroutineScope) this.L$0;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            int i2 = 1;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                if (!CoroutineScopeKt.isActive(coroutineScope)) {
                }
                return Unit.INSTANCE;
            }
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            BeaconSweepUiState beaconSweepUiState = (BeaconSweepUiState) BeaconSweepViewModel.this._uiState.getValue();
            if (beaconSweepUiState.getStage() == SweepStage.PLAYING) {
                return Unit.INSTANCE;
            }
            int secondsLeft = beaconSweepUiState.getSecondsLeft() - i2;
            BeaconSweepViewModel.this._uiState.setValue(BeaconSweepUiState.copy$default(beaconSweepUiState, null, null, null, RangesKt.coerceAtLeast(secondsLeft, 0), 0, 0, 0, false, 247, null));
            if (secondsLeft <= 0) {
                BeaconSweepViewModel.this.endRun();
                return Unit.INSTANCE;
            }
            i2 = 1;
            if (!CoroutineScopeKt.isActive(coroutineScope) && ((BeaconSweepUiState) BeaconSweepViewModel.this._uiState.getValue()).getSecondsLeft() > 0 && ((BeaconSweepUiState) BeaconSweepViewModel.this._uiState.getValue()).getStage() == SweepStage.PLAYING) {
                this.L$0 = coroutineScope;
                this.label = i2;
                if (DelayKt.delay(1000L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                BeaconSweepUiState beaconSweepUiState2 = (BeaconSweepUiState) BeaconSweepViewModel.this._uiState.getValue();
                if (beaconSweepUiState2.getStage() == SweepStage.PLAYING) {
                }
            } else {
                return Unit.INSTANCE;
            }
        }
    }

    private final void startLamp() {
        Job job = this.lampJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.lampJob = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03381(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void endRun() {
        Job job = this.lampJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.lampJob = null;
        BeaconSweepUiState value = this._uiState.getValue();
        if (value.getStage() != SweepStage.PLAYING) {
            return;
        }
        this._uiState.setValue(BeaconSweepUiState.copy$default(value, SweepStage.OVER, null, null, 0, 0, 0, 0, value.getBoardsCleared() > value.getBestBoards(), 118, null));
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C03371(value, null), 3, null);
    }

    /* compiled from: BeaconSweepViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 4, 0}, xi = 48)
    @DebugMetadata(c = "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$endRun$1", f = "BeaconSweepViewModel.kt", i = {}, l = {191}, m = "invokeSuspend", n = {}, nl = {-1}, s = {}, v = 2)
    /* renamed from: com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel$endRun$1, reason: invalid class name and case insensitive filesystem */
    static final class C03371 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ BeaconSweepUiState $state;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C03371(BeaconSweepUiState beaconSweepUiState, Continuation<? super C03371> continuation) {
            super(2, continuation);
            this.$state = beaconSweepUiState;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return BeaconSweepViewModel.this.new C03371(this.$state, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C03371) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (BeaconSweepViewModel.this.repository.recordSweepRun(this.$state.getBoardsCleared(), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }
    }

    @Override // androidx.lifecycle.ViewModel
    protected void onCleared() {
        super.onCleared();
        Job job = this.lampJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
    }
}
