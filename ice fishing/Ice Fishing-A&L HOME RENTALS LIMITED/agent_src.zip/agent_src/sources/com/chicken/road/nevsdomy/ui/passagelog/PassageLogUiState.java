package com.chicken.road.nevsdomy.ui.passagelog;

import com.chicken.road.nevsdomy.data.model.Strait;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PassageLogViewModel.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u001b\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000b\u0010\r\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\u000bJ&\u0010\u000f\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u0010J\u0014\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0014\u001a\u00020\u0015HÖ\u0081\u0004J\n\u0010\u0016\u001a\u00020\u0017HÖ\u0081\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0015\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bÊ\u0001\f\b\u0019\u0012\b\b\u001a\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0018"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/passagelog/PassageLogUiState;", "", "strait", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "crossedOn", "", "<init>", "(Lcom/chicken/road/nevsdomy/data/model/Strait;Ljava/lang/Long;)V", "getStrait", "()Lcom/chicken/road/nevsdomy/data/model/Strait;", "getCrossedOn", "()Ljava/lang/Long;", "Ljava/lang/Long;", "component1", "component2", "copy", "(Lcom/chicken/road/nevsdomy/data/model/Strait;Ljava/lang/Long;)Lcom/chicken/road/nevsdomy/ui/passagelog/PassageLogUiState;", "equals", "", "other", "hashCode", "", "toString", "", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class PassageLogUiState {
    public static final int $stable = Strait.$stable;
    private final Long crossedOn;
    private final Strait strait;

    public static /* synthetic */ PassageLogUiState copy$default(PassageLogUiState passageLogUiState, Strait strait, Long l, int i, Object obj) {
        if ((i & 1) != 0) {
            strait = passageLogUiState.strait;
        }
        if ((i & 2) != 0) {
            l = passageLogUiState.crossedOn;
        }
        return passageLogUiState.copy(strait, l);
    }

    /* renamed from: component1, reason: from getter */
    public final Strait getStrait() {
        return this.strait;
    }

    /* renamed from: component2, reason: from getter */
    public final Long getCrossedOn() {
        return this.crossedOn;
    }

    public final PassageLogUiState copy(Strait strait, Long crossedOn) {
        return new PassageLogUiState(strait, crossedOn);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PassageLogUiState)) {
            return false;
        }
        PassageLogUiState passageLogUiState = (PassageLogUiState) other;
        return Intrinsics.areEqual(this.strait, passageLogUiState.strait) && Intrinsics.areEqual(this.crossedOn, passageLogUiState.crossedOn);
    }

    public int hashCode() {
        Strait strait = this.strait;
        int iHashCode = (strait == null ? 0 : strait.hashCode()) * 31;
        Long l = this.crossedOn;
        return iHashCode + (l != null ? l.hashCode() : 0);
    }

    public String toString() {
        return "PassageLogUiState(strait=" + this.strait + ", crossedOn=" + this.crossedOn + ")";
    }

    public PassageLogUiState(Strait strait, Long l) {
        this.strait = strait;
        this.crossedOn = l;
    }

    public final Strait getStrait() {
        return this.strait;
    }

    public final Long getCrossedOn() {
        return this.crossedOn;
    }
}
