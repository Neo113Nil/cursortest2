package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.data.model.StraitTag;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final /* synthetic */ class RegisterScreenKt$RegisterScreen$2$1$1$2$1$1 extends FunctionReferenceImpl implements Function1<StraitTag, Unit> {
    RegisterScreenKt$RegisterScreen$2$1$1$2$1$1(Object obj) {
        super(1, obj, RegisterViewModel.class, "onTagClick", "onTagClick(Lcom/chicken/road/nevsdomy/data/model/StraitTag;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(StraitTag straitTag) {
        invoke2(straitTag);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(StraitTag p0) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        ((RegisterViewModel) this.receiver).onTagClick(p0);
    }
}
