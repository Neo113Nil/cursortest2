package com.chicken.road.nevsdomy.ui.chartroom;

import android.content.res.Resources;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.input.nestedscroll.NestedScrollModifierKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.compose.ui.unit.Dp;
import androidx.hilt.lifecycle.viewmodel.compose.HiltViewModelKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewModelStoreOwnerDefaults;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
import androidx.lifecycle.viewmodel.compose.ViewModelKt;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.data.model.Strait;
import com.chicken.road.nevsdomy.data.model.StraitTag;
import com.chicken.road.nevsdomy.nav.NavClickGuard;
import com.chicken.road.nevsdomy.nav.NavClickGuardKt;
import com.chicken.road.nevsdomy.ui.common.ComponentsKt;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;

/* compiled from: ChartRoomScreen.kt */
@Metadata(d1 = {"\u0000B\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\u001a\u0086\u0001\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u00052\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\u00032\u001d\u0010\t\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0003\u0012\u0004\u0012\u00020\u00010\u0005¢\u0006\u0002\b\n2\b\b\u0002\u0010\u000b\u001a\u00020\fH\u0007b\u0002\b\nb\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010¢\u0006\u0002\u0010\r\u001a5\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0012\u001a\u00020\u00132\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003H\u0003b\u0002\b\nb\f\b\u0016\u0012\b\b\u0017\u0012\u0004\b\b(\u0018¢\u0006\u0002\u0010\u0015¨\u0006\u0019²\u0006\n\u0010\u001a\u001a\u00020\u001bX\u008a\u0084\u0002"}, d2 = {"ChartRoomScreen", "", "onOpenDrawer", "Lkotlin/Function0;", "onOpenPassage", "Lkotlin/Function1;", "", "onOpenRegister", "onRunSweep", "navigationIcon", "Landroidx/compose/runtime/Composable;", "viewModel", "Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomViewModel;", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function3;Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomViewModel;Landroidx/compose/runtime/Composer;II)V", "Landroidx/compose/runtime/ComposableInferredTarget;", "scheme", "[androidx.compose.ui.UiComposable[androidx.compose.ui.UiComposable]]", "HeroCard", "strait", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "onClick", "(Lcom/chicken/road/nevsdomy/data/model/Strait;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "Landroidx/compose/runtime/ComposableTarget;", "applier", "androidx.compose.ui.UiComposable", "app", "state", "Lcom/chicken/road/nevsdomy/ui/chartroom/ChartRoomUiState;"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ChartRoomScreenKt {
    static final Unit ChartRoomScreen$lambda$3(Function0 function0, Function1 function1, Function0 function02, Function0 function03, Function3 function3, ChartRoomViewModel chartRoomViewModel, int i, int i2, Composer composer, int i3) {
        ChartRoomScreen(function0, function1, function02, function03, function3, chartRoomViewModel, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit HeroCard$lambda$1(Strait strait, Function0 function0, int i, Composer composer, int i2) {
        HeroCard(strait, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01c5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ChartRoomScreen(final Function0<Unit> onOpenDrawer, final Function1<? super String, Unit> onOpenPassage, final Function0<Unit> onOpenRegister, final Function0<Unit> onRunSweep, final Function3<? super Function0<Unit>, ? super Composer, ? super Integer, Unit> navigationIcon, ChartRoomViewModel chartRoomViewModel, Composer composer, final int i, final int i2) {
        int i3;
        final ChartRoomViewModel chartRoomViewModel2;
        int i4;
        boolean z;
        int i5;
        ChartRoomViewModel chartRoomViewModel3 = chartRoomViewModel;
        Intrinsics.checkNotNullParameter(onOpenDrawer, "onOpenDrawer");
        Intrinsics.checkNotNullParameter(onOpenPassage, "onOpenPassage");
        Intrinsics.checkNotNullParameter(onOpenRegister, "onOpenRegister");
        Intrinsics.checkNotNullParameter(onRunSweep, "onRunSweep");
        Intrinsics.checkNotNullParameter(navigationIcon, "navigationIcon");
        Composer composerStartRestartGroup = composer.startRestartGroup(465203036);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(ChartRoomScreen)N(onOpenDrawer,onOpenPassage,onOpenRegister,onRunSweep,navigationIcon,viewModel)48@2141L29,49@2214L22,50@2253L23,54@2390L656,71@3054L4205,52@2282L4977:ChartRoomScreen.kt#5xc6jq");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(onOpenDrawer) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onOpenPassage) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onOpenRegister) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onRunSweep) ? 2048 : 1024;
        }
        if ((i & 24576) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navigationIcon) ? 16384 : 8192;
        }
        if ((196608 & i) == 0) {
            if ((i2 & 32) != 0) {
                i5 = 65536;
                i3 |= i5;
            } else {
                if ((262144 & i) == 0 ? composerStartRestartGroup.changed(chartRoomViewModel3) : composerStartRestartGroup.changedInstance(chartRoomViewModel3)) {
                    i5 = 131072;
                }
                i3 |= i5;
            }
        }
        if (composerStartRestartGroup.shouldExecute((74899 & i3) != 74898, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            ComposerKt.sourceInformation(composerStartRestartGroup, "46@2085L15");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 32) != 0) {
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1192010736, "CC(hiltViewModel)N(viewModelStoreOwner,key)40@1717L7,45@1869L81,46@1962L54:HiltViewModel.kt#gplxbw");
                    ViewModelStoreOwner current = LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    ViewModelProvider.Factory factoryRememberHiltViewModelFactory = HiltViewModelKt.rememberHiltViewModelFactory(ViewModelStoreOwnerDefaults.getViewModelProviderFactory(current), composerStartRestartGroup, 0, 0);
                    ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1729797275, "CC(viewModel)N(viewModelStoreOwner,key,factory,extras)58@2688L7,64@2951L63:ViewModel.kt#3tja67");
                    i4 = 0;
                    ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(ChartRoomViewModel.class), current, (String) null, factoryRememberHiltViewModelFactory, ViewModelStoreOwnerDefaults.getViewModelCreationExtras(current), composerStartRestartGroup, 0, 0);
                    composerStartRestartGroup = composerStartRestartGroup;
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    ChartRoomViewModel chartRoomViewModel4 = (ChartRoomViewModel) viewModel;
                    i3 &= -458753;
                    z = true;
                    chartRoomViewModel3 = chartRoomViewModel4;
                }
                composerStartRestartGroup.endDefaults();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(465203036, i3, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen (ChartRoomScreen.kt:47)");
                }
                boolean z2 = z;
                Composer composer2 = composerStartRestartGroup;
                final State stateCollectAsStateWithLifecycle = FlowExtKt.collectAsStateWithLifecycle(chartRoomViewModel3.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer2, 0, 7);
                final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer2, 384, 3);
                final NavClickGuard navClickGuardRememberNavClickGuard = NavClickGuardKt.rememberNavClickGuard(composer2, i4);
                chartRoomViewModel2 = chartRoomViewModel3;
                ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(-1833220328, z2, new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$1(topAppBarScrollBehaviorPinnedScrollBehavior, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer2, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(1388529837, z2, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$2(stateCollectAsStateWithLifecycle, navClickGuardRememberNavClickGuard, onOpenPassage, chartRoomViewModel2, onOpenRegister, onRunSweep, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 508);
                composerStartRestartGroup = composer2;
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 32) != 0) {
                    i3 &= -458753;
                }
            }
            i4 = 0;
            z = true;
            composerStartRestartGroup.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
            }
            boolean z22 = z;
            Composer composer22 = composerStartRestartGroup;
            final State stateCollectAsStateWithLifecycle2 = FlowExtKt.collectAsStateWithLifecycle(chartRoomViewModel3.getUiState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, composer22, 0, 7);
            final TopAppBarScrollBehavior topAppBarScrollBehaviorPinnedScrollBehavior2 = TopAppBarDefaults.INSTANCE.pinnedScrollBehavior(null, null, composer22, 384, 3);
            final NavClickGuard navClickGuardRememberNavClickGuard2 = NavClickGuardKt.rememberNavClickGuard(composer22, i4);
            chartRoomViewModel2 = chartRoomViewModel3;
            ScaffoldKt.m3021ScaffoldTvnljyQ(NestedScrollModifierKt.nestedScroll$default(Modifier.INSTANCE, topAppBarScrollBehaviorPinnedScrollBehavior2.getNestedScrollConnection(), null, 2, null), ComposableLambdaKt.rememberComposableLambda(-1833220328, z22, new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ChartRoomScreenKt.ChartRoomScreen$lambda$1(topAppBarScrollBehaviorPinnedScrollBehavior2, navigationIcon, onOpenDrawer, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer22, 54), null, null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(1388529837, z22, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return ChartRoomScreenKt.ChartRoomScreen$lambda$2(stateCollectAsStateWithLifecycle2, navClickGuardRememberNavClickGuard2, onOpenPassage, chartRoomViewModel2, onOpenRegister, onRunSweep, (PaddingValues) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer22, 54), composer22, 805306416, 508);
            composerStartRestartGroup = composer22;
            if (ComposerKt.isTraceInProgress()) {
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            chartRoomViewModel2 = chartRoomViewModel3;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ChartRoomScreenKt.ChartRoomScreen$lambda$3(onOpenDrawer, onOpenPassage, onOpenRegister, onRunSweep, navigationIcon, chartRoomViewModel2, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$1$0(Function3 function3, Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C63@2714L28:ChartRoomScreen.kt#5xc6jq");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-794053666, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous> (ChartRoomScreen.kt:63)");
            }
            function3.invoke(function0, composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return Unit.INSTANCE;
    }

    static final Unit ChartRoomScreen$lambda$1(TopAppBarScrollBehavior topAppBarScrollBehavior, final Function3 function3, final Function0 function0, Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C66@2906L11,67@2981L11,65@2838L183,63@2712L32,55@2404L632:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1833220328, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous> (ChartRoomScreen.kt:55)");
            }
            AppBarKt.m2345TopAppBarGHTll3U(ComposableSingletons$ChartRoomScreenKt.INSTANCE.getLambda$394738908$app(), null, ComposableLambdaKt.rememberComposableLambda(-794053666, true, new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ChartRoomScreenKt.ChartRoomScreen$lambda$1$0(function3, function0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), null, 0.0f, null, TopAppBarDefaults.INSTANCE.m3543topAppBarColors5tl4gsc(MaterialTheme.INSTANCE.getColorScheme(composer, 6).getSurface(), 0L, 0L, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurface(), 0L, 0L, composer, 1572864, 54), topAppBarScrollBehavior, composer, 390, 58);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit ChartRoomScreen$lambda$2(final State state, final NavClickGuard navClickGuard, final Function1 function1, final ChartRoomViewModel chartRoomViewModel, final Function0 function0, final Function0 function02, PaddingValues innerPadding, Composer composer, int i) {
        int i2;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation(composer, "CN(innerPadding)78@3362L3891,72@3080L4173:ChartRoomScreen.kt#5xc6jq");
        if ((i & 6) == 0) {
            i2 = i | (composer.changed(innerPadding) ? 4 : 2);
        } else {
            i2 = i;
        }
        if (!composer.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1388529837, i2, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous> (ChartRoomScreen.kt:72)");
            }
            Modifier modifierPadding = PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding);
            PaddingValues paddingValuesM1084PaddingValuesYgX7TsA = PaddingKt.m1084PaddingValuesYgX7TsA(Spacing.INSTANCE.m8932getLD9Ej5fM(), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, -1357641952, "CC(remember):ChartRoomScreen.kt#9igjgp");
            boolean zChanged = composer.changed(state) | composer.changedInstance(navClickGuard) | composer.changed(function1) | composer.changedInstance(chartRoomViewModel) | composer.changed(function0) | composer.changed(function02);
            Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                Function1 function12 = new Function1() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0(navClickGuard, function1, state, chartRoomViewModel, function0, function02, (LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(function12);
                objRememberedValue = function12;
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            LazyDslKt.LazyColumn(modifierPadding, null, paddingValuesM1084PaddingValuesYgX7TsA, false, horizontalOrVerticalM782spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, composer, 0, 490);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0(final NavClickGuard navClickGuard, final Function1 function1, final State state, final ChartRoomViewModel chartRoomViewModel, final Function0 function0, final Function0 function02, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$ChartRoomScreenKt.INSTANCE.getLambda$862929666$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-951151175, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$0(navClickGuard, function1, state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1401707066, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$1(chartRoomViewModel, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$ChartRoomScreenKt.INSTANCE.m8909getLambda$540401989$app(), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1812456252, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$2(state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-129652803, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$3(state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-2071761858, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$4(navClickGuard, function0, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(281096383, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$5(navClickGuard, function02, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
            }
        }), 3, null);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$0(final NavClickGuard navClickGuard, final Function1 function1, final State state, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C90@3781L50,88@3696L154:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-951151175, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:88)");
            }
            Strait featured = ChartRoomScreen$lambda$0(state).getFeatured();
            ComposerKt.sourceInformationMarkerStart(composer, 771758219, "CC(remember):ChartRoomScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(navClickGuard) | composer.changed(function1) | composer.changed(state);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda11
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$0$0$0(navClickGuard, function1, state);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            HeroCard(featured, (Function0) objRememberedValue, composer, Strait.$stable);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$0$0$0(NavClickGuard navClickGuard, final Function1 function1, final State state) {
        navClickGuard.run(new Function0() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$0$0$0$0(function1, state);
            }
        });
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$0$0$0$0(Function1 function1, State state) {
        function1.invoke(ChartRoomScreen$lambda$0(state).getFeatured().getId());
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$1(ChartRoomViewModel chartRoomViewModel, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C95@3942L24,94@3900L453:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1401707066, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:94)");
            }
            ComposerKt.sourceInformationMarkerStart(composer, -1579238574, "CC(remember):ChartRoomScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(chartRoomViewModel);
            ChartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1 chartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1RememberedValue = composer.rememberedValue();
            if (zChangedInstance || chartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                chartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1RememberedValue = new ChartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1(chartRoomViewModel);
                composer.updateRememberedValue(chartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ButtonKt.TextButton((Function0) ((KFunction) chartRoomScreenKt$ChartRoomScreen$2$1$1$2$1$1RememberedValue), SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$ChartRoomScreenKt.INSTANCE.m8907getLambda$1276858889$app(), composer, 805306416, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$2(State state, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C116@4768L588:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1812456252, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:116)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -1298342756, "C119@4960L44,117@4851L232,124@5214L45,122@5104L234:ChartRoomScreen.kt#5xc6jq");
            ComponentsKt.StatTile(String.valueOf(ChartRoomScreen$lambda$0(state).getPassagesOnFile()), StringResources_androidKt.stringResource(R.string.chart_stat_passages, composer, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composer, 0, 0);
            ComponentsKt.StatTile(String.valueOf(ChartRoomScreen$lambda$0(state).getCrossingsLogged()), StringResources_androidKt.stringResource(R.string.chart_stat_crossings, composer, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composer, 0, 0);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$3(State state, LazyItemScope item, Composer composer, int i) throws Resources.NotFoundException {
        String strValueOf;
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C130@5406L748:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-129652803, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:130)");
            }
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, companion);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -1164750885, "C137@5773L40,131@5489L403,142@6017L40,140@5913L223:ChartRoomScreen.kt#5xc6jq");
            if (ChartRoomScreen$lambda$0(state).getSweepsRun() == 0) {
                composer.startReplaceGroup(-1164700666);
                ComposerKt.sourceInformation(composer, "133@5587L35");
                strValueOf = StringResources_androidKt.stringResource(R.string.value_none, composer, 0);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-1164604690);
                composer.endReplaceGroup();
                strValueOf = String.valueOf(ChartRoomScreen$lambda$0(state).getBestBoards());
            }
            ComponentsKt.StatTile(strValueOf, StringResources_androidKt.stringResource(R.string.chart_stat_best, composer, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composer, 0, 0);
            ComponentsKt.StatTile(String.valueOf(ChartRoomScreen$lambda$0(state).getSweepsRun()), StringResources_androidKt.stringResource(R.string.chart_stat_runs, composer, 0), RowScope.weight$default(rowScopeInstance, Modifier.INSTANCE, 1.0f, false, 2, null), composer, 0, 0);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$4(final NavClickGuard navClickGuard, final Function0 function0, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C149@6242L29,148@6204L527:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2071761858, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:148)");
            }
            ComposerKt.sourceInformationMarkerStart(composer, 1901681627, "CC(remember):ChartRoomScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(navClickGuard) | composer.changed(function0);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$4$0$0(navClickGuard, function0);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ButtonKt.Button((Function0) objRememberedValue, PaddingKt.m1094paddingqDBjuR0$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 0.0f, Spacing.INSTANCE.m8934getSD9Ej5fM(), 0.0f, 0.0f, 13, null), false, null, null, null, null, null, null, ComposableSingletons$ChartRoomScreenKt.INSTANCE.m8908getLambda$1708071890$app(), composer, 805306368, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$4$0$0(NavClickGuard navClickGuard, Function0 function0) {
        navClickGuard.run(function0);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$5(final NavClickGuard navClickGuard, final Function0 function0, LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C164@6823L25,163@6781L448:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(281096383, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ChartRoomScreen.kt:163)");
            }
            ComposerKt.sourceInformationMarkerStart(composer, -449313640, "CC(remember):ChartRoomScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(navClickGuard) | composer.changed(function0);
            Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ChartRoomScreenKt.ChartRoomScreen$lambda$2$0$0$5$0$0(navClickGuard, function0);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ButtonKt.TextButton((Function0) objRememberedValue, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, null, null, null, ComposableSingletons$ChartRoomScreenKt.INSTANCE.getLambda$1897497724$app(), composer, 805306416, 508);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit ChartRoomScreen$lambda$2$0$0$5$0$0(NavClickGuard navClickGuard, Function0 function0) {
        navClickGuard.run(function0);
        return Unit.INSTANCE;
    }

    private static final void HeroCard(final Strait strait, final Function0<Unit> function0, Composer composer, final int i) {
        int i2;
        Composer composerStartRestartGroup = composer.startRestartGroup(1687791112);
        ComposerKt.sourceInformation(composerStartRestartGroup, "C(HeroCard)N(strait,onClick)185@7504L56,186@7568L1347,181@7339L1576:ChartRoomScreen.kt#5xc6jq");
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? composerStartRestartGroup.changed(strait) : composerStartRestartGroup.changedInstance(strait) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 19) != 18, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1687791112, i2, -1, "com.chicken.road.nevsdomy.ui.chartroom.HeroCard (ChartRoomScreen.kt:180)");
            }
            CardKt.ElevatedCard(function0, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, RoundedCornerShapeKt.m1423RoundedCornerShape0680j_4(Spacing.INSTANCE.m8933getMD9Ej5fM()), null, CardDefaults.INSTANCE.m2402elevatedCardElevationaqJV_2Y(Dp.m8373constructorimpl(Spacing.INSTANCE.m8936getXsD9Ej5fM() / 2.0f), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, composerStartRestartGroup, 1572864, 62), null, ComposableLambdaKt.rememberComposableLambda(433147590, true, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return ChartRoomScreenKt.HeroCard$lambda$0(strait, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, ((i2 >> 3) & 14) | 12582960, 84);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ChartRoomScreenKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ChartRoomScreenKt.HeroCard$lambda$1(strait, function0, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    static final Unit HeroCard$lambda$0(Strait strait, ColumnScope ElevatedCard, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(ElevatedCard, "$this$ElevatedCard");
        ComposerKt.sourceInformation(composer, "C187@7578L1331:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(433147590, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.HeroCard.<anonymous> (ChartRoomScreen.kt:187)");
            }
            Modifier modifierM1090padding3ABfNKs = PaddingKt.m1090padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Spacing.INSTANCE.m8932getLD9Ej5fM());
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_4 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer, modifierM1090padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl, Integer.valueOf(iHashCode), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, 762715334, "C193@7778L33,196@7904L10,194@7824L199,201@8065L62,202@8167L10,203@8228L11,200@8036L315,208@8393L65,209@8498L10,210@8558L11,207@8364L317,214@8694L205:ChartRoomScreen.kt#5xc6jq");
            ComponentsKt.EmojiBanner(strait.getEmoji(), null, composer, 0, 2);
            TextKt.m3328TextNvy7gAk(strait.getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getHeadlineSmall(), composer, 0, 24960, 110590);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.seas_joined, new Object[]{strait.getSeaA(), strait.getSeaB()}, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110586);
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.neck_width, new Object[]{ComponentsKt.formatKm(strait.getNarrowestKm())}, composer, 0), null, MaterialTheme.INSTANCE.getColorScheme(composer, 6).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodySmall(), composer, 0, 24960, 110586);
            Arrangement.HorizontalOrVertical horizontalOrVerticalM782spacedBy0680j_42 = Arrangement.INSTANCE.m782spacedBy0680j_4(Spacing.INSTANCE.m8934getSD9Ej5fM());
            ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            Modifier.Companion companion = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalOrVerticalM782spacedBy0680j_42, Alignment.INSTANCE.getTop(), composer, 0);
            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer, companion);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16216L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            } else {
                composer.useNode();
            }
            Composer composerM4604constructorimpl2 = Updater.m4604constructorimpl(composer);
            Updater.m4612setimpl(composerM4604constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m4612setimpl(composerM4604constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Updater.m4612setimpl(composerM4604constructorimpl2, Integer.valueOf(iHashCode2), ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            Updater.m4610reconcileimpl(composerM4604constructorimpl2, ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            Updater.m4612setimpl(composerM4604constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer, -1415748557, "C:ChartRoomScreen.kt#5xc6jq");
            composer.startReplaceGroup(369973060);
            ComposerKt.sourceInformation(composer, "*216@8838L28,216@8822L45");
            Iterator<T> it = strait.getTags().iterator();
            while (it.hasNext()) {
                ComponentsKt.TagPill(StringResources_androidKt.stringResource(((StraitTag) it.next()).getLabelRes(), composer, 0), null, composer, 0, 2);
            }
            composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final ChartRoomUiState ChartRoomScreen$lambda$0(State<ChartRoomUiState> state) {
        return state.getValue();
    }
}
