package com.chicken.road.nevsdomy.di;

import android.content.Context;
import com.chicken.road.nevsdomy.data.db.StraitWatchDatabase;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;

/* loaded from: classes2.dex */
public final class AppModule_ProvideDatabaseFactory implements Factory<StraitWatchDatabase> {
    private final Provider<Context> contextProvider;

    private AppModule_ProvideDatabaseFactory(Provider<Context> contextProvider) {
        this.contextProvider = contextProvider;
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public StraitWatchDatabase get() {
        return provideDatabase(this.contextProvider.get());
    }

    public static AppModule_ProvideDatabaseFactory create(Provider<Context> contextProvider) {
        return new AppModule_ProvideDatabaseFactory(contextProvider);
    }

    public static StraitWatchDatabase provideDatabase(Context context) {
        return (StraitWatchDatabase) Preconditions.checkNotNullFromProvides(AppModule.INSTANCE.provideDatabase(context));
    }
}
