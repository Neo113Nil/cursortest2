package com.chicken.road.nevsdomy.data.model;

import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: Strait.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0017\b\u0002\u0012\f\b\u0001\u0010\u0002\u001a\u00020\u0003:\u0002\b\u0004¢\u0006\u0004\b\u0005\u0010\u0006R\u001b\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u0092\u0002\u0002\b\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f¨\u0006\r"}, d2 = {"Lcom/chicken/road/nevsdomy/data/model/SortOrder;", "", "labelRes", "", "Landroidx/annotation/StringRes;", "<init>", "(Ljava/lang/String;II)V", "getLabelRes", "()I", "REGISTER", "NARROWEST", "DEEPEST", "BUSIEST", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class SortOrder {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ SortOrder[] $VALUES;
    private final int labelRes;
    public static final SortOrder REGISTER = new SortOrder("REGISTER", 0, R.string.sort_register);
    public static final SortOrder NARROWEST = new SortOrder("NARROWEST", 1, R.string.sort_narrowest);
    public static final SortOrder DEEPEST = new SortOrder("DEEPEST", 2, R.string.sort_deepest);
    public static final SortOrder BUSIEST = new SortOrder("BUSIEST", 3, R.string.sort_busiest);

    private static final /* synthetic */ SortOrder[] $values() {
        return new SortOrder[]{REGISTER, NARROWEST, DEEPEST, BUSIEST};
    }

    public static EnumEntries<SortOrder> getEntries() {
        return $ENTRIES;
    }

    public static SortOrder valueOf(String str) {
        return (SortOrder) Enum.valueOf(SortOrder.class, str);
    }

    public static SortOrder[] values() {
        return (SortOrder[]) $VALUES.clone();
    }

    private SortOrder(String str, int i, int i2) {
        this.labelRes = i2;
    }

    public final int getLabelRes() {
        return this.labelRes;
    }

    static {
        SortOrder[] sortOrderArr$values = $values();
        $VALUES = sortOrderArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(sortOrderArr$values);
    }
}
