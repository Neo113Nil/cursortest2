package com.chicken.road.nevsdomy.ui.chartroom;

/* loaded from: classes2.dex */
public final class ChartRoomViewModel_HiltModules_BindsModule_Binds_LazyMapKey {
    static ChartRoomViewModel keepFieldType = null;
    public static String lazyClassKeyName = "com.chicken.road.nevsdomy.ui.chartroom.ChartRoomViewModel";
}
