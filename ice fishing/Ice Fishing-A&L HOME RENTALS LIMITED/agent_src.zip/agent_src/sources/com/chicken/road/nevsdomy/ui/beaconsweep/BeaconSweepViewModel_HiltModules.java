package com.chicken.road.nevsdomy.ui.beaconsweep;

import androidx.lifecycle.ViewModel;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoMap;
import dagger.multibindings.LazyClassKey;

/* loaded from: classes2.dex */
public final class BeaconSweepViewModel_HiltModules {
    private BeaconSweepViewModel_HiltModules() {
    }

    @Module
    public static abstract class BindsModule {
        @LazyClassKey(BeaconSweepViewModel.class)
        @Binds
        @IntoMap
        public abstract ViewModel binds(BeaconSweepViewModel vm);

        private BindsModule() {
        }
    }

    @Module
    public static final class KeyModule {
        @Provides
        @LazyClassKey(BeaconSweepViewModel.class)
        @IntoMap
        public static boolean provide() {
            return true;
        }

        private KeyModule() {
        }
    }
}
