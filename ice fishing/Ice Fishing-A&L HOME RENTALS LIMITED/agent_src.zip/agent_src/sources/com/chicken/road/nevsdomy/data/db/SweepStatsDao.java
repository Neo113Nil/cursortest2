package com.chicken.road.nevsdomy.data.db;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* compiled from: Daos.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\bg\u0018\u00002\u00020\u0001J\u001e\u0010\u0002\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003H'b\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007J\u001e\u0010\b\u001a\u0004\u0018\u00010\u0004H§@b\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007¢\u0006\u0002\u0010\tJ$\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u0004H§@b\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\u0003\u0010\u0002¢\u0006\u0002\u0010\rÊ\u0001\u0002\b\u0011¨\u0006\u0010À\u0006\u0003"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/SweepStatsDao;", "", "observe", "Lkotlinx/coroutines/flow/Flow;", "Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;", "Landroidx/room/Query;", "value", "SELECT * FROM sweep_stats WHERE id = 0 LIMIT 1", "current", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "upsert", "", "entity", "(Lcom/chicken/road/nevsdomy/data/db/SweepStatsEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Landroidx/room/Insert;", "onConflict", "app", "Landroidx/room/Dao;"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public interface SweepStatsDao {
    Object current(Continuation<? super SweepStatsEntity> continuation);

    Flow<SweepStatsEntity> observe();

    Object upsert(SweepStatsEntity sweepStatsEntity, Continuation<? super Unit> continuation);
}
