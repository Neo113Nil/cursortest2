package com.chicken.road.nevsdomy.ui.beaconsweep;

/* loaded from: classes2.dex */
public final class BeaconSweepViewModel_HiltModules_BindsModule_Binds_LazyMapKey {
    static BeaconSweepViewModel keepFieldType = null;
    public static String lazyClassKeyName = "com.chicken.road.nevsdomy.ui.beaconsweep.BeaconSweepViewModel";
}
