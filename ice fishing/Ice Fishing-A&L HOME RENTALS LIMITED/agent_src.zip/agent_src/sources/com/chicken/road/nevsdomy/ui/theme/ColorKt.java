package com.chicken.road.nevsdomy.ui.theme;

import kotlin.Metadata;

/* compiled from: Color.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b$\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0013\u0010\u001d\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003\"\u0013\u0010\u001f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b \u0010\u0003\"\u0013\u0010!\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\"\u0010\u0003\"\u0013\u0010#\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b$\u0010\u0003¨\u0006%"}, d2 = {"StraitTeal", "Landroidx/compose/ui/graphics/Color;", "getStraitTeal", "()J", "J", "StraitTealDeep", "getStraitTealDeep", "StraitTealContainer", "getStraitTealContainer", "StraitTealOnContainer", "getStraitTealOnContainer", "ChartOchre", "getChartOchre", "ChartOchreContainer", "getChartOchreContainer", "ChartOchreOnContainer", "getChartOchreOnContainer", "ParchmentBackground", "getParchmentBackground", "ParchmentSurface", "getParchmentSurface", "ParchmentVariant", "getParchmentVariant", "ParchmentOutline", "getParchmentOutline", "OnPrimaryWhite", "getOnPrimaryWhite", "OnBackgroundInk", "getOnBackgroundInk", "OnSurfaceMuted", "getOnSurfaceMuted", "SweepMiss", "getSweepMiss", "SweepMissContainer", "getSweepMissContainer", "SweepMissOnContainer", "getSweepMissOnContainer", "app"}, k = 2, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ColorKt {
    private static final long StraitTeal = androidx.compose.ui.graphics.ColorKt.Color(4279138944L);
    private static final long StraitTealDeep = androidx.compose.ui.graphics.ColorKt.Color(4278869860L);
    private static final long StraitTealContainer = androidx.compose.ui.graphics.ColorKt.Color(4291618535L);
    private static final long StraitTealOnContainer = androidx.compose.ui.graphics.ColorKt.Color(4278464559L);
    private static final long ChartOchre = androidx.compose.ui.graphics.ColorKt.Color(4290808382L);
    private static final long ChartOchreContainer = androidx.compose.ui.graphics.ColorKt.Color(4294304968L);
    private static final long ChartOchreOnContainer = androidx.compose.ui.graphics.ColorKt.Color(4282198539L);
    private static final long ParchmentBackground = androidx.compose.ui.graphics.ColorKt.Color(4294835190L);
    private static final long ParchmentSurface = androidx.compose.ui.graphics.ColorKt.Color(4294374122L);
    private static final long ParchmentVariant = androidx.compose.ui.graphics.ColorKt.Color(4293386451L);
    private static final long ParchmentOutline = androidx.compose.ui.graphics.ColorKt.Color(4291806900L);
    private static final long OnPrimaryWhite = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long OnBackgroundInk = androidx.compose.ui.graphics.ColorKt.Color(4279900698L);
    private static final long OnSurfaceMuted = androidx.compose.ui.graphics.ColorKt.Color(4283846986L);
    private static final long SweepMiss = androidx.compose.ui.graphics.ColorKt.Color(4289930782L);
    private static final long SweepMissContainer = androidx.compose.ui.graphics.ColorKt.Color(4294565596L);
    private static final long SweepMissOnContainer = androidx.compose.ui.graphics.ColorKt.Color(4282453515L);

    public static final long getStraitTeal() {
        return StraitTeal;
    }

    public static final long getStraitTealDeep() {
        return StraitTealDeep;
    }

    public static final long getStraitTealContainer() {
        return StraitTealContainer;
    }

    public static final long getStraitTealOnContainer() {
        return StraitTealOnContainer;
    }

    public static final long getChartOchre() {
        return ChartOchre;
    }

    public static final long getChartOchreContainer() {
        return ChartOchreContainer;
    }

    public static final long getChartOchreOnContainer() {
        return ChartOchreOnContainer;
    }

    public static final long getParchmentBackground() {
        return ParchmentBackground;
    }

    public static final long getParchmentSurface() {
        return ParchmentSurface;
    }

    public static final long getParchmentVariant() {
        return ParchmentVariant;
    }

    public static final long getParchmentOutline() {
        return ParchmentOutline;
    }

    public static final long getOnPrimaryWhite() {
        return OnPrimaryWhite;
    }

    public static final long getOnBackgroundInk() {
        return OnBackgroundInk;
    }

    public static final long getOnSurfaceMuted() {
        return OnSurfaceMuted;
    }

    public static final long getSweepMiss() {
        return SweepMiss;
    }

    public static final long getSweepMissContainer() {
        return SweepMissContainer;
    }

    public static final long getSweepMissOnContainer() {
        return SweepMissOnContainer;
    }
}
