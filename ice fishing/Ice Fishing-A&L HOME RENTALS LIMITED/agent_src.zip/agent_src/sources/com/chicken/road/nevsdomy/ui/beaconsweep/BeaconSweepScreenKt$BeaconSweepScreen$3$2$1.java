package com.chicken.road.nevsdomy.ui.beaconsweep;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* compiled from: BeaconSweepScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final /* synthetic */ class BeaconSweepScreenKt$BeaconSweepScreen$3$2$1 extends FunctionReferenceImpl implements Function1<Integer, Unit> {
    BeaconSweepScreenKt$BeaconSweepScreen$3$2$1(Object obj) {
        super(1, obj, BeaconSweepViewModel.class, "onTileTap", "onTileTap(I)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
        invoke(num.intValue());
        return Unit.INSTANCE;
    }

    public final void invoke(int i) {
        ((BeaconSweepViewModel) this.receiver).onTileTap(i);
    }
}
