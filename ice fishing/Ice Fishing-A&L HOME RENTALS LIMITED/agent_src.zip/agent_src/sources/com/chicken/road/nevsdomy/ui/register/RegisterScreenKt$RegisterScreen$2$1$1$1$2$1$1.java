package com.chicken.road.nevsdomy.ui.register;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* compiled from: RegisterScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
final /* synthetic */ class RegisterScreenKt$RegisterScreen$2$1$1$1$2$1$1 extends FunctionReferenceImpl implements Function0<Unit> {
    RegisterScreenKt$RegisterScreen$2$1$1$1$2$1$1(Object obj) {
        super(0, obj, RegisterViewModel.class, "onClearQuery", "onClearQuery()V", 0);
    }

    @Override // kotlin.jvm.functions.Function0
    public /* bridge */ /* synthetic */ Unit invoke() {
        invoke2();
        return Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2() {
        ((RegisterViewModel) this.receiver).onClearQuery();
    }
}
