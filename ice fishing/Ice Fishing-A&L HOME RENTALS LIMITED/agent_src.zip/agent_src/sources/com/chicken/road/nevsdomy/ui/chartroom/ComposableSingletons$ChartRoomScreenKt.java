package com.chicken.road.nevsdomy.ui.chartroom;

import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.ui.theme.Spacing;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: ChartRoomScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$ChartRoomScreenKt {
    public static final ComposableSingletons$ChartRoomScreenKt INSTANCE = new ComposableSingletons$ChartRoomScreenKt();
    private static Function2<Composer, Integer, Unit> lambda$394738908 = ComposableLambdaKt.composableLambdaInstance(394738908, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$ChartRoomScreenKt.lambda_394738908$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$862929666 = ComposableLambdaKt.composableLambdaInstance(862929666, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ChartRoomScreenKt.lambda_862929666$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1276858889, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f54lambda$1276858889 = ComposableLambdaKt.composableLambdaInstance(-1276858889, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ChartRoomScreenKt.lambda__1276858889$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-540401989, reason: not valid java name */
    private static Function3<LazyItemScope, Composer, Integer, Unit> f56lambda$540401989 = ComposableLambdaKt.composableLambdaInstance(-540401989, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ChartRoomScreenKt.lambda__540401989$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1708071890, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f55lambda$1708071890 = ComposableLambdaKt.composableLambdaInstance(-1708071890, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ChartRoomScreenKt.lambda__1708071890$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1897497724 = ComposableLambdaKt.composableLambdaInstance(1897497724, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$ChartRoomScreenKt.lambda_1897497724$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1276858889$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8907getLambda$1276858889$app() {
        return f54lambda$1276858889;
    }

    /* renamed from: getLambda$-1708071890$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8908getLambda$1708071890$app() {
        return f55lambda$1708071890;
    }

    /* renamed from: getLambda$-540401989$app, reason: not valid java name */
    public final Function3<LazyItemScope, Composer, Integer, Unit> m8909getLambda$540401989$app() {
        return f56lambda$540401989;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1897497724$app() {
        return lambda$1897497724;
    }

    public final Function2<Composer, Integer, Unit> getLambda$394738908$app() {
        return lambda$394738908;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$862929666$app() {
        return lambda$862929666;
    }

    static final Unit lambda_394738908$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C58@2498L42,57@2461L198:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(394738908, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$394738908.<anonymous> (ChartRoomScreen.kt:57)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.screen_chart_room, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, null, composer, 0, 24960, 241662);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_862929666$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C81@3432L42,82@3518L10,80@3399L247:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(862929666, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$862929666.<anonymous> (ChartRoomScreen.kt:80)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.chart_hero_header, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1276858889$lambda$0(RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C99@4101L46,100@4195L10,98@4064L271:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1276858889, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$-1276858889.<anonymous> (ChartRoomScreen.kt:98)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.chart_swing_the_glass, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__540401989$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C108@4436L44,109@4524L10,107@4403L315:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-540401989, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$-540401989.<anonymous> (ChartRoomScreen.kt:107)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.chart_totals_header, composer, 0), PaddingKt.m1094paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, Spacing.INSTANCE.m8934getSD9Ej5fM(), 0.0f, 0.0f, 13, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110588);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1708071890$lambda$0(RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C155@6481L44,156@6573L10,154@6444L269:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1708071890, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$-1708071890.<anonymous> (ChartRoomScreen.kt:154)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.chart_open_register, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1897497724$lambda$0(RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C168@6983L40,169@7071L10,167@6946L265:ChartRoomScreen.kt#5xc6jq");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1897497724, i, -1, "com.chicken.road.nevsdomy.ui.chartroom.ComposableSingletons$ChartRoomScreenKt.lambda$1897497724.<anonymous> (ChartRoomScreen.kt:167)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.chart_run_sweep, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
