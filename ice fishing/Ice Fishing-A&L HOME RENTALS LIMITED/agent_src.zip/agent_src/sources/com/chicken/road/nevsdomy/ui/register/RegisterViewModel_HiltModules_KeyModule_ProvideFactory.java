package com.chicken.road.nevsdomy.ui.register;

import com.chicken.road.nevsdomy.ui.register.RegisterViewModel_HiltModules;
import dagger.internal.Factory;

/* loaded from: classes2.dex */
public final class RegisterViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {
    @Override // javax.inject.Provider, jakarta.inject.Provider
    public Boolean get() {
        return Boolean.valueOf(provide());
    }

    public static RegisterViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return InstanceHolder.INSTANCE;
    }

    public static boolean provide() {
        return RegisterViewModel_HiltModules.KeyModule.provide();
    }

    private static final class InstanceHolder {
        static final RegisterViewModel_HiltModules_KeyModule_ProvideFactory INSTANCE = new RegisterViewModel_HiltModules_KeyModule_ProvideFactory();

        private InstanceHolder() {
        }
    }
}
