package com.chicken.road.nevsdomy.data.db;

import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* compiled from: Daos.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\bg\u0018\u00002\u00020\u0001J\"\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'b\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\bJ&\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00032\u0006\u0010\n\u001a\u00020\u000bH'b\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\fJ$\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0005H§@b\f\b\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\u0002¢\u0006\u0002\u0010\u0010J$\u0010\u0013\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u000bH§@b\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\u0015¢\u0006\u0002\u0010\u0014Ê\u0001\u0002\b\u0017¨\u0006\u0016À\u0006\u0003"}, d2 = {"Lcom/chicken/road/nevsdomy/data/db/CrossingDao;", "", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/chicken/road/nevsdomy/data/db/CrossingEntity;", "Landroidx/room/Query;", "value", "SELECT * FROM crossings", "observeOne", "straitId", "", "SELECT * FROM crossings WHERE straitId = :straitId LIMIT 1", "upsert", "", "entity", "(Lcom/chicken/road/nevsdomy/data/db/CrossingEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Landroidx/room/Insert;", "onConflict", "deleteById", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "DELETE FROM crossings WHERE straitId = :straitId", "app", "Landroidx/room/Dao;"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public interface CrossingDao {
    Object deleteById(String str, Continuation<? super Unit> continuation);

    Flow<List<CrossingEntity>> observeAll();

    Flow<CrossingEntity> observeOne(String straitId);

    Object upsert(CrossingEntity crossingEntity, Continuation<? super Unit> continuation);
}
