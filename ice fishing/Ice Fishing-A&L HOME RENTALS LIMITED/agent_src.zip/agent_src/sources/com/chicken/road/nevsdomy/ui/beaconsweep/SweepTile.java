package com.chicken.road.nevsdomy.ui.beaconsweep;

import com.chicken.road.nevsdomy.data.model.Strait;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: BeaconSweepViewModel.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0012\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0014\u0010\u0015\u001a\u00020\u00052\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0017\u001a\u00020\u0018HÖ\u0081\u0004J\n\u0010\u0019\u001a\u00020\u001aHÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rÊ\u0001\f\b\u001c\u0012\b\b\u001d\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u001b"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/beaconsweep/SweepTile;", "", "strait", "Lcom/chicken/road/nevsdomy/data/model/Strait;", "matches", "", "locked", "wrong", "<init>", "(Lcom/chicken/road/nevsdomy/data/model/Strait;ZZZ)V", "getStrait", "()Lcom/chicken/road/nevsdomy/data/model/Strait;", "getMatches", "()Z", "getLocked", "getWrong", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class SweepTile {
    public static final int $stable = Strait.$stable;
    private final boolean locked;
    private final boolean matches;
    private final Strait strait;
    private final boolean wrong;

    public static /* synthetic */ SweepTile copy$default(SweepTile sweepTile, Strait strait, boolean z, boolean z2, boolean z3, int i, Object obj) {
        if ((i & 1) != 0) {
            strait = sweepTile.strait;
        }
        if ((i & 2) != 0) {
            z = sweepTile.matches;
        }
        if ((i & 4) != 0) {
            z2 = sweepTile.locked;
        }
        if ((i & 8) != 0) {
            z3 = sweepTile.wrong;
        }
        return sweepTile.copy(strait, z, z2, z3);
    }

    /* renamed from: component1, reason: from getter */
    public final Strait getStrait() {
        return this.strait;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getMatches() {
        return this.matches;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getLocked() {
        return this.locked;
    }

    /* renamed from: component4, reason: from getter */
    public final boolean getWrong() {
        return this.wrong;
    }

    public final SweepTile copy(Strait strait, boolean matches, boolean locked, boolean wrong) {
        Intrinsics.checkNotNullParameter(strait, "strait");
        return new SweepTile(strait, matches, locked, wrong);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SweepTile)) {
            return false;
        }
        SweepTile sweepTile = (SweepTile) other;
        return Intrinsics.areEqual(this.strait, sweepTile.strait) && this.matches == sweepTile.matches && this.locked == sweepTile.locked && this.wrong == sweepTile.wrong;
    }

    public int hashCode() {
        return (((((this.strait.hashCode() * 31) + Boolean.hashCode(this.matches)) * 31) + Boolean.hashCode(this.locked)) * 31) + Boolean.hashCode(this.wrong);
    }

    public String toString() {
        return "SweepTile(strait=" + this.strait + ", matches=" + this.matches + ", locked=" + this.locked + ", wrong=" + this.wrong + ")";
    }

    public SweepTile(Strait strait, boolean z, boolean z2, boolean z3) {
        Intrinsics.checkNotNullParameter(strait, "strait");
        this.strait = strait;
        this.matches = z;
        this.locked = z2;
        this.wrong = z3;
    }

    public /* synthetic */ SweepTile(Strait strait, boolean z, boolean z2, boolean z3, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(strait, z, (i & 4) != 0 ? false : z2, (i & 8) != 0 ? false : z3);
    }

    public final Strait getStrait() {
        return this.strait;
    }

    public final boolean getMatches() {
        return this.matches;
    }

    public final boolean getLocked() {
        return this.locked;
    }

    public final boolean getWrong() {
        return this.wrong;
    }
}
