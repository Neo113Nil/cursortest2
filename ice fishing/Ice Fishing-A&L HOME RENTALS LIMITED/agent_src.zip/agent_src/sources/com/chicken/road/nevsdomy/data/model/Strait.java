package com.chicken.road.nevsdomy.data.model;

import androidx.autofill.HintConstants;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Strait.kt */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b#\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001Bu\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\r\u0012\u0006\u0010\u000f\u001a\u00020\r\u0012\u0006\u0010\u0010\u001a\u00020\u0003\u0012\u0006\u0010\u0011\u001a\u00020\u0003\u0012\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\t\u0010)\u001a\u00020\u0003HÆ\u0003J\t\u0010*\u001a\u00020\u0003HÆ\u0003J\t\u0010+\u001a\u00020\u0003HÆ\u0003J\t\u0010,\u001a\u00020\u0007HÆ\u0003J\t\u0010-\u001a\u00020\u0003HÆ\u0003J\t\u0010.\u001a\u00020\u0003HÆ\u0003J\t\u0010/\u001a\u00020\u000bHÆ\u0003J\t\u00100\u001a\u00020\rHÆ\u0003J\t\u00101\u001a\u00020\rHÆ\u0003J\t\u00102\u001a\u00020\rHÆ\u0003J\t\u00103\u001a\u00020\u0003HÆ\u0003J\t\u00104\u001a\u00020\u0003HÆ\u0003J\u000f\u00105\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013HÆ\u0003J\u0091\u0001\u00106\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u000b2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\r2\b\b\u0002\u0010\u0010\u001a\u00020\u00032\b\b\u0002\u0010\u0011\u001a\u00020\u00032\u000e\b\u0002\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013HÆ\u0001J\u0014\u00107\u001a\u0002082\b\u00109\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010:\u001a\u00020\rHÖ\u0081\u0004J\n\u0010;\u001a\u00020\u0003HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0018R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0018R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0018R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0018R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0011\u0010\u000e\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\"R\u0011\u0010\u000f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\"R\u0011\u0010\u0010\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u0018R\u0011\u0010\u0011\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0018R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013¢\u0006\b\n\u0000\u001a\u0004\b'\u0010(Ê\u0001\f\b=\u0012\b\b>\u0012\u0004\b\u0003\u0010\u0000¨\u0006<"}, d2 = {"Lcom/chicken/road/nevsdomy/data/model/Strait;", "", "id", "", HintConstants.AUTOFILL_HINT_NAME, "emoji", "basin", "Lcom/chicken/road/nevsdomy/data/model/Basin;", "seaA", "seaB", "narrowestKm", "", "deepestM", "", "lengthKm", "shipsPerDay", "banks", "story", "tags", "", "Lcom/chicken/road/nevsdomy/data/model/StraitTag;", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/chicken/road/nevsdomy/data/model/Basin;Ljava/lang/String;Ljava/lang/String;DIIILjava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getId", "()Ljava/lang/String;", "getName", "getEmoji", "getBasin", "()Lcom/chicken/road/nevsdomy/data/model/Basin;", "getSeaA", "getSeaB", "getNarrowestKm", "()D", "getDeepestM", "()I", "getLengthKm", "getShipsPerDay", "getBanks", "getStory", "getTags", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "copy", "equals", "", "other", "hashCode", "toString", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class Strait {
    public static final int $stable = 8;
    private final String banks;
    private final Basin basin;
    private final int deepestM;
    private final String emoji;
    private final String id;
    private final int lengthKm;
    private final String name;
    private final double narrowestKm;
    private final String seaA;
    private final String seaB;
    private final int shipsPerDay;
    private final String story;
    private final List<StraitTag> tags;

    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* renamed from: component10, reason: from getter */
    public final int getShipsPerDay() {
        return this.shipsPerDay;
    }

    /* renamed from: component11, reason: from getter */
    public final String getBanks() {
        return this.banks;
    }

    /* renamed from: component12, reason: from getter */
    public final String getStory() {
        return this.story;
    }

    public final List<StraitTag> component13() {
        return this.tags;
    }

    /* renamed from: component2, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* renamed from: component3, reason: from getter */
    public final String getEmoji() {
        return this.emoji;
    }

    /* renamed from: component4, reason: from getter */
    public final Basin getBasin() {
        return this.basin;
    }

    /* renamed from: component5, reason: from getter */
    public final String getSeaA() {
        return this.seaA;
    }

    /* renamed from: component6, reason: from getter */
    public final String getSeaB() {
        return this.seaB;
    }

    /* renamed from: component7, reason: from getter */
    public final double getNarrowestKm() {
        return this.narrowestKm;
    }

    /* renamed from: component8, reason: from getter */
    public final int getDeepestM() {
        return this.deepestM;
    }

    /* renamed from: component9, reason: from getter */
    public final int getLengthKm() {
        return this.lengthKm;
    }

    public final Strait copy(String id, String name, String emoji, Basin basin, String seaA, String seaB, double narrowestKm, int deepestM, int lengthKm, int shipsPerDay, String banks, String story, List<? extends StraitTag> tags) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(emoji, "emoji");
        Intrinsics.checkNotNullParameter(basin, "basin");
        Intrinsics.checkNotNullParameter(seaA, "seaA");
        Intrinsics.checkNotNullParameter(seaB, "seaB");
        Intrinsics.checkNotNullParameter(banks, "banks");
        Intrinsics.checkNotNullParameter(story, "story");
        Intrinsics.checkNotNullParameter(tags, "tags");
        return new Strait(id, name, emoji, basin, seaA, seaB, narrowestKm, deepestM, lengthKm, shipsPerDay, banks, story, tags);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Strait)) {
            return false;
        }
        Strait strait = (Strait) other;
        return Intrinsics.areEqual(this.id, strait.id) && Intrinsics.areEqual(this.name, strait.name) && Intrinsics.areEqual(this.emoji, strait.emoji) && this.basin == strait.basin && Intrinsics.areEqual(this.seaA, strait.seaA) && Intrinsics.areEqual(this.seaB, strait.seaB) && Double.compare(this.narrowestKm, strait.narrowestKm) == 0 && this.deepestM == strait.deepestM && this.lengthKm == strait.lengthKm && this.shipsPerDay == strait.shipsPerDay && Intrinsics.areEqual(this.banks, strait.banks) && Intrinsics.areEqual(this.story, strait.story) && Intrinsics.areEqual(this.tags, strait.tags);
    }

    public int hashCode() {
        return (((((((((((((((((((((((this.id.hashCode() * 31) + this.name.hashCode()) * 31) + this.emoji.hashCode()) * 31) + this.basin.hashCode()) * 31) + this.seaA.hashCode()) * 31) + this.seaB.hashCode()) * 31) + Double.hashCode(this.narrowestKm)) * 31) + Integer.hashCode(this.deepestM)) * 31) + Integer.hashCode(this.lengthKm)) * 31) + Integer.hashCode(this.shipsPerDay)) * 31) + this.banks.hashCode()) * 31) + this.story.hashCode()) * 31) + this.tags.hashCode();
    }

    public String toString() {
        return "Strait(id=" + this.id + ", name=" + this.name + ", emoji=" + this.emoji + ", basin=" + this.basin + ", seaA=" + this.seaA + ", seaB=" + this.seaB + ", narrowestKm=" + this.narrowestKm + ", deepestM=" + this.deepestM + ", lengthKm=" + this.lengthKm + ", shipsPerDay=" + this.shipsPerDay + ", banks=" + this.banks + ", story=" + this.story + ", tags=" + this.tags + ")";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Strait(String id, String name, String emoji, Basin basin, String seaA, String seaB, double d, int i, int i2, int i3, String banks, String story, List<? extends StraitTag> tags) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(emoji, "emoji");
        Intrinsics.checkNotNullParameter(basin, "basin");
        Intrinsics.checkNotNullParameter(seaA, "seaA");
        Intrinsics.checkNotNullParameter(seaB, "seaB");
        Intrinsics.checkNotNullParameter(banks, "banks");
        Intrinsics.checkNotNullParameter(story, "story");
        Intrinsics.checkNotNullParameter(tags, "tags");
        this.id = id;
        this.name = name;
        this.emoji = emoji;
        this.basin = basin;
        this.seaA = seaA;
        this.seaB = seaB;
        this.narrowestKm = d;
        this.deepestM = i;
        this.lengthKm = i2;
        this.shipsPerDay = i3;
        this.banks = banks;
        this.story = story;
        this.tags = tags;
    }

    public final String getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getEmoji() {
        return this.emoji;
    }

    public final Basin getBasin() {
        return this.basin;
    }

    public final String getSeaA() {
        return this.seaA;
    }

    public final String getSeaB() {
        return this.seaB;
    }

    public final double getNarrowestKm() {
        return this.narrowestKm;
    }

    public final int getDeepestM() {
        return this.deepestM;
    }

    public final int getLengthKm() {
        return this.lengthKm;
    }

    public final int getShipsPerDay() {
        return this.shipsPerDay;
    }

    public final String getBanks() {
        return this.banks;
    }

    public final String getStory() {
        return this.story;
    }

    public final List<StraitTag> getTags() {
        return this.tags;
    }
}
