package com.chicken.road.nevsdomy.ui.passagelog;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.automirrored.filled.ArrowBackKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import com.chicken.road.nevsdomy.R;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PassageLogScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$PassageLogScreenKt {
    public static final ComposableSingletons$PassageLogScreenKt INSTANCE = new ComposableSingletons$PassageLogScreenKt();

    /* renamed from: lambda$-567246205, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f59lambda$567246205 = ComposableLambdaKt.composableLambdaInstance(-567246205, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$PassageLogScreenKt.lambda__567246205$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$139320257 = ComposableLambdaKt.composableLambdaInstance(139320257, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda_139320257$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$1020961542 = ComposableLambdaKt.composableLambdaInstance(1020961542, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda_1020961542$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1947347449 = ComposableLambdaKt.composableLambdaInstance(1947347449, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda_1947347449$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-247881417, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f58lambda$247881417 = ComposableLambdaKt.composableLambdaInstance(-247881417, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda__247881417$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1967006930 = ComposableLambdaKt.composableLambdaInstance(1967006930, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda_1967006930$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1196967832, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f57lambda$1196967832 = ComposableLambdaKt.composableLambdaInstance(-1196967832, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$PassageLogScreenKt.lambda__1196967832$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1196967832$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8911getLambda$1196967832$app() {
        return f57lambda$1196967832;
    }

    /* renamed from: getLambda$-247881417$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m8912getLambda$247881417$app() {
        return f58lambda$247881417;
    }

    /* renamed from: getLambda$-567246205$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8913getLambda$567246205$app() {
        return f59lambda$567246205;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$1020961542$app() {
        return lambda$1020961542;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$139320257$app() {
        return lambda$139320257;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1947347449$app() {
        return lambda$1947347449;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1967006930$app() {
        return lambda$1967006930;
    }

    static final Unit lambda__567246205$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C78@3446L32,76@3312L193:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-567246205, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$-567246205.<anonymous> (PassageLogScreen.kt:76)");
            }
            IconKt.m2776Iconww6aTOc(ArrowBackKt.getArrowBack(Icons.AutoMirrored.Filled.INSTANCE), StringResources_androidKt.stringResource(R.string.cd_back, composer, 0), (Modifier) null, 0L, composer, 0, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_139320257$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C129@5493L49,130@5586L10,128@5460L254:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(139320257, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$139320257.<anonymous> (PassageLogScreen.kt:128)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_soundings_header, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1020961542$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C151@6272L48,152@6364L10,150@6239L253:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1020961542, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$1020961542.<anonymous> (PassageLogScreen.kt:150)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_crossing_header, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getTitleLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1947347449$lambda$0(RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C179@7281L44,180@7373L10,178@7244L269:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1947347449, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$1947347449.<anonymous> (PassageLogScreen.kt:178)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.dialog_confirm_date, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__247881417$lambda$0(RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C189@7697L38,190@7783L10,188@7660L263:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-247881417, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$-247881417.<anonymous> (PassageLogScreen.kt:188)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.dialog_cancel, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1967006930$lambda$0(RowScope Button, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C288@11031L43,289@11122L10,287@10994L268:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1967006930, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$1967006930.<anonymous> (PassageLogScreen.kt:287)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_log_button, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1196967832$lambda$0(RowScope TextButton, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation(composer, "C303@11732L42,304@11822L10,302@11695L267:PassageLogScreen.kt#ae2drp");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1196967832, i, -1, "com.chicken.road.nevsdomy.ui.passagelog.ComposableSingletons$PassageLogScreenKt.lambda$-1196967832.<anonymous> (PassageLogScreen.kt:302)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.passage_clear_log, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getLabelLarge(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
