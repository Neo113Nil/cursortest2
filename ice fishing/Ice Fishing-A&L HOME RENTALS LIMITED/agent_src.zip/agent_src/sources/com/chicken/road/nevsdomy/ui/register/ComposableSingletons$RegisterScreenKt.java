package com.chicken.road.nevsdomy.ui.register;

import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CheckKt;
import androidx.compose.material.icons.filled.ClearKt;
import androidx.compose.material.icons.filled.SearchKt;
import androidx.compose.material3.FilterChipDefaults;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextOverflow;
import com.chicken.road.nevsdomy.R;
import com.chicken.road.nevsdomy.ui.common.ComponentsKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: RegisterScreen.kt */
@Metadata(k = 3, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class ComposableSingletons$RegisterScreenKt {
    public static final ComposableSingletons$RegisterScreenKt INSTANCE = new ComposableSingletons$RegisterScreenKt();

    /* renamed from: lambda$-1957778154, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f62lambda$1957778154 = ComposableLambdaKt.composableLambdaInstance(-1957778154, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$RegisterScreenKt.lambda__1957778154$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-1905890379, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f61lambda$1905890379 = ComposableLambdaKt.composableLambdaInstance(-1905890379, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$RegisterScreenKt.lambda__1905890379$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$996143508 = ComposableLambdaKt.composableLambdaInstance(996143508, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$RegisterScreenKt.lambda_996143508$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-517288166, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f63lambda$517288166 = ComposableLambdaKt.composableLambdaInstance(-517288166, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$RegisterScreenKt.lambda__517288166$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$2090042647 = ComposableLambdaKt.composableLambdaInstance(2090042647, false, new Function3() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$RegisterScreenKt.lambda_2090042647$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-1881468132, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f60lambda$1881468132 = ComposableLambdaKt.composableLambdaInstance(-1881468132, false, new Function2() { // from class: com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$RegisterScreenKt.lambda__1881468132$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1881468132$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8919getLambda$1881468132$app() {
        return f60lambda$1881468132;
    }

    /* renamed from: getLambda$-1905890379$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8920getLambda$1905890379$app() {
        return f61lambda$1905890379;
    }

    /* renamed from: getLambda$-1957778154$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8921getLambda$1957778154$app() {
        return f62lambda$1957778154;
    }

    /* renamed from: getLambda$-517288166$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m8922getLambda$517288166$app() {
        return f63lambda$517288166;
    }

    public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$2090042647$app() {
        return lambda$2090042647;
    }

    public final Function2<Composer, Integer, Unit> getLambda$996143508$app() {
        return lambda$996143508;
    }

    static final Unit lambda__1957778154$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C81@3559L40,80@3522L196:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1957778154, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$-1957778154.<anonymous> (RegisterScreen.kt:80)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.screen_register, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, null, composer, 0, 24960, 241662);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1905890379$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C111@4835L45,112@4932L10,110@4794L290:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1905890379, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$-1905890379.<anonymous> (RegisterScreen.kt:110)");
            }
            TextKt.m3328TextNvy7gAk(StringResources_androidKt.stringResource(R.string.register_search_hint, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.INSTANCE.m8309getEllipsisgIe3tQ8(), false, 1, 0, null, MaterialTheme.INSTANCE.getTypography(composer, 6).getBodyMedium(), composer, 0, 24960, 110590);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_996143508$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C120@5286L34,118@5168L179:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(996143508, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$996143508.<anonymous> (RegisterScreen.kt:118)");
            }
            IconKt.m2776Iconww6aTOc(SearchKt.getSearch(Icons.Filled.INSTANCE), StringResources_androidKt.stringResource(R.string.cd_search, composer, 0), (Modifier) null, 0L, composer, 0, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__517288166$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C128@5705L40,126@5572L208:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-517288166, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$-517288166.<anonymous> (RegisterScreen.kt:126)");
            }
            IconKt.m2776Iconww6aTOc(ClearKt.getClear(Icons.Filled.INSTANCE), StringResources_androidKt.stringResource(R.string.cd_clear_search, composer, 0), (Modifier) null, 0L, composer, 0, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_2090042647$lambda$0(LazyItemScope item, Composer composer, int i) {
        Intrinsics.checkNotNullParameter(item, "$this$item");
        ComposerKt.sourceInformation(composer, "C150@6379L45,151@6458L45,152@6536L44,149@6335L268:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2090042647, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$2090042647.<anonymous> (RegisterScreen.kt:149)");
            }
            ComponentsKt.EmptyState(StringResources_androidKt.stringResource(R.string.register_empty_glyph, composer, 0), StringResources_androidKt.stringResource(R.string.register_empty_title, composer, 0), StringResources_androidKt.stringResource(R.string.register_empty_hint, composer, 0), null, composer, 0, 8);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1881468132$lambda$0(Composer composer, int i) {
        ComposerKt.sourceInformation(composer, "C203@8572L231:RegisterScreen.kt#zd2u8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1881468132, i, -1, "com.chicken.road.nevsdomy.ui.register.ComposableSingletons$RegisterScreenKt.lambda$-1881468132.<anonymous> (RegisterScreen.kt:203)");
            }
            IconKt.m2776Iconww6aTOc(CheckKt.getCheck(Icons.Filled.INSTANCE), (String) null, SizeKt.m1157size3ABfNKs(Modifier.INSTANCE, FilterChipDefaults.INSTANCE.m2718getIconSizeD9Ej5fM()), 0L, composer, 48, 8);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
