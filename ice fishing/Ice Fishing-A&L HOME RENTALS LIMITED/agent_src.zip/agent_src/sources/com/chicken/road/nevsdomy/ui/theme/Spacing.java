package com.chicken.road.nevsdomy.ui.theme;

import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* compiled from: Spacing.kt */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0013\u0010\u0004\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0006\u0010\u0007R\u0013\u0010\t\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\n\u0010\u0007R\u0013\u0010\u000b\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\f\u0010\u0007R\u0013\u0010\r\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u000e\u0010\u0007R\u0013\u0010\u000f\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0010\u0010\u0007R\u0013\u0010\u0011\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0012\u0010\u0007Ê\u0001\f\b\u0014\u0012\b\b\u0015\u0012\u0004\b\u0003\u0010\u0002¨\u0006\u0013"}, d2 = {"Lcom/chicken/road/nevsdomy/ui/theme/Spacing;", "", "<init>", "()V", "xs", "Landroidx/compose/ui/unit/Dp;", "getXs-D9Ej5fM", "()F", "F", "s", "getS-D9Ej5fM", "m", "getM-D9Ej5fM", "l", "getL-D9Ej5fM", "xl", "getXl-D9Ej5fM", "xxl", "getXxl-D9Ej5fM", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class Spacing {
    public static final int $stable = 0;
    public static final Spacing INSTANCE = new Spacing();
    private static final float xs = Dp.m8373constructorimpl(4.0f);
    private static final float s = Dp.m8373constructorimpl(8.0f);
    private static final float m = Dp.m8373constructorimpl(12.0f);
    private static final float l = Dp.m8373constructorimpl(16.0f);
    private static final float xl = Dp.m8373constructorimpl(24.0f);
    private static final float xxl = Dp.m8373constructorimpl(32.0f);

    private Spacing() {
    }

    /* renamed from: getXs-D9Ej5fM, reason: not valid java name */
    public final float m8936getXsD9Ej5fM() {
        return xs;
    }

    /* renamed from: getS-D9Ej5fM, reason: not valid java name */
    public final float m8934getSD9Ej5fM() {
        return s;
    }

    /* renamed from: getM-D9Ej5fM, reason: not valid java name */
    public final float m8933getMD9Ej5fM() {
        return m;
    }

    /* renamed from: getL-D9Ej5fM, reason: not valid java name */
    public final float m8932getLD9Ej5fM() {
        return l;
    }

    /* renamed from: getXl-D9Ej5fM, reason: not valid java name */
    public final float m8935getXlD9Ej5fM() {
        return xl;
    }

    /* renamed from: getXxl-D9Ej5fM, reason: not valid java name */
    public final float m8937getXxlD9Ej5fM() {
        return xxl;
    }
}
