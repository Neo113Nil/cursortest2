package com.chicken.road.nevsdomy;

/* loaded from: classes2.dex */
public interface MainActivity_GeneratedInjector {
    void injectMainActivity(MainActivity mainActivity);
}
