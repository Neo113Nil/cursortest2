package com.chicken.road.nevsdomy;

/* loaded from: classes2.dex */
public final class StraitWatchApp_ComponentTreeDeps {
}
