package uhggroup.iceskating.app.data.datastore;

/* compiled from: OnboardingDataStoreManager.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\bH\u0086@¢\u0006\u0002\u0010\u000eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0010"}, d2 = {"Luhggroup/iceskating/app/data/datastore/OnboardingDataStoreManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "onboardedStateFlow", "Lkotlinx/coroutines/flow/Flow;", "", "getOnboardedStateFlow", "()Lkotlinx/coroutines/flow/Flow;", "setOnboardedState", "", "state", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OnboardingDataStoreManager {
    private final android.content.Context context;
    private final kotlinx.coroutines.flow.Flow<java.lang.Boolean> onboardedStateFlow;
    public static final int $stable = 8;
    private static final androidx.datastore.preferences.core.Preferences.Key<java.lang.Boolean> ONBOARDED_STATE_KEY = androidx.datastore.preferences.core.PreferencesKeys.booleanKey("onboardedState");

    public OnboardingDataStoreManager(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        final kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> data = uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManagerKt.getOnboardingDataStore(context).getData();
        this.onboardedStateFlow = new kotlinx.coroutines.flow.Flow<java.lang.Boolean>() { // from class: uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
            /* renamed from: uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1$2", f = "OnboardingDataStoreManager.kt", i = {0, 0, 0, 0, 0}, l = {50}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1"}, nl = {49}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 2)
                /* renamed from: uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    int I$0;
                    java.lang.Object L$0;
                    java.lang.Object L$1;
                    java.lang.Object L$2;
                    java.lang.Object L$3;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    if (continuation instanceof uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                        }
                    }
                    java.lang.Object obj2 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = anonymousClass1.label;
                    if (i == 0) {
                        kotlin.ResultKt.throwOnFailure(obj2);
                        kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                        java.lang.Object obj3 = ((androidx.datastore.preferences.core.Preferences) obj).get(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.ONBOARDED_STATE_KEY);
                        anonymousClass1.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(obj);
                        anonymousClass1.L$1 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(anonymousClass1);
                        anonymousClass1.L$2 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(obj);
                        anonymousClass1.L$3 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(flowCollector);
                        anonymousClass1.I$0 = 0;
                        anonymousClass1.label = 1;
                        if (flowCollector.emit(obj3, anonymousClass1) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else {
                        if (i != 1) {
                            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        int i2 = anonymousClass1.I$0;
                        java.lang.Object obj4 = anonymousClass1.L$2;
                        java.lang.Object obj5 = anonymousClass1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj2);
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.lang.Boolean> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object objCollect = data.collect(new uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$special$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return objCollect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : kotlin.Unit.INSTANCE;
            }
        };
    }

    public final kotlinx.coroutines.flow.Flow<java.lang.Boolean> getOnboardedStateFlow() {
        return this.onboardedStateFlow;
    }

    /* compiled from: OnboardingDataStoreManager.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "prefs", "Landroidx/datastore/preferences/core/MutablePreferences;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$setOnboardedState$2", f = "OnboardingDataStoreManager.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager$setOnboardedState$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.datastore.preferences.core.MutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ boolean $state;
        /* synthetic */ java.lang.Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(boolean z, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.AnonymousClass2> continuation) {
            super(2, continuation);
            this.$state = z;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.AnonymousClass2 anonymousClass2 = new uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.AnonymousClass2(this.$state, continuation);
            anonymousClass2.L$0 = obj;
            return anonymousClass2;
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(androidx.datastore.preferences.core.MutablePreferences mutablePreferences, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.AnonymousClass2) create(mutablePreferences, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            androidx.datastore.preferences.core.MutablePreferences mutablePreferences = (androidx.datastore.preferences.core.MutablePreferences) this.L$0;
            kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                mutablePreferences.set(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.ONBOARDED_STATE_KEY, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(this.$state));
                return kotlin.Unit.INSTANCE;
            }
            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    public final java.lang.Object setOnboardedState(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objEdit = androidx.datastore.preferences.core.PreferencesKt.edit(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManagerKt.getOnboardingDataStore(this.context), new uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.AnonymousClass2(z, null), continuation);
        return objEdit == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objEdit : kotlin.Unit.INSTANCE;
    }
}
