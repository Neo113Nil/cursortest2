package uhggroup.iceskating.app.data.datastore;

/* compiled from: OnboardingDataStoreManager.kt */
@kotlin.Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"%\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003*\u00020\u00058FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007¨\u0006\n"}, d2 = {"ONBOARDING_PREFS_NAME", "", "onboardingDataStore", "Landroidx/datastore/core/DataStore;", "Landroidx/datastore/preferences/core/Preferences;", "Landroid/content/Context;", "getOnboardingDataStore", "(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", "onboardingDataStore$delegate", "Lkotlin/properties/ReadOnlyProperty;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OnboardingDataStoreManagerKt {
    static final /* synthetic */ kotlin.reflect.KProperty<java.lang.Object>[] $$delegatedProperties = {new kotlin.jvm.internal.PropertyReference1Impl(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManagerKt.class, "onboardingDataStore", "getOnboardingDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", 1)};
    private static final java.lang.String ONBOARDING_PREFS_NAME = "onboarding_prefs";
    private static final kotlin.properties.ReadOnlyProperty onboardingDataStore$delegate = androidx.datastore.preferences.PreferenceDataStoreDelegateKt.preferencesDataStore$default(ONBOARDING_PREFS_NAME, null, null, null, 14, null);

    public static final androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> getOnboardingDataStore(android.content.Context context) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(context, "<this>");
        return (androidx.datastore.core.DataStore) onboardingDataStore$delegate.getValue(context, $$delegatedProperties[0]);
    }
}
