package uhggroup.iceskating.app.data.entity;

/* compiled from: OrderEntity.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\tHÆ\u0003J\t\u0010\u001e\u001a\u00020\u000bHÆ\u0003JO\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000bHÆ\u0001J\u0014\u0010 \u001a\u00020!2\b\u0010\"\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010#\u001a\u00020$HÖ\u0081\u0004J\n\u0010%\u001a\u00020\u0003HÖ\u0081\u0004R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0016\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000fR\u0016\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u0016\u0010\u0007\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000fR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017¨\u0006&"}, d2 = {"Luhggroup/iceskating/app/data/entity/OrderEntity;", "", "orderNumber", "", "description", "customerFirstName", "customerLastName", "customerEmail", "price", "", "timestamp", "Ljava/time/LocalDateTime;", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DLjava/time/LocalDateTime;)V", "getOrderNumber", "()Ljava/lang/String;", "getDescription", "getCustomerFirstName", "getCustomerLastName", "getCustomerEmail", "getPrice", "()D", "getTimestamp", "()Ljava/time/LocalDateTime;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "", "toString", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class OrderEntity {
    public static final int $stable = 8;
    private final java.lang.String customerEmail;
    private final java.lang.String customerFirstName;
    private final java.lang.String customerLastName;
    private final java.lang.String description;
    private final java.lang.String orderNumber;
    private final double price;
    private final java.time.LocalDateTime timestamp;

    public static /* synthetic */ uhggroup.iceskating.app.data.entity.OrderEntity copy$default(uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, java.lang.String str, java.lang.String str2, java.lang.String str3, java.lang.String str4, java.lang.String str5, double d, java.time.LocalDateTime localDateTime, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            str = orderEntity.orderNumber;
        }
        if ((i & 2) != 0) {
            str2 = orderEntity.description;
        }
        if ((i & 4) != 0) {
            str3 = orderEntity.customerFirstName;
        }
        if ((i & 8) != 0) {
            str4 = orderEntity.customerLastName;
        }
        if ((i & 16) != 0) {
            str5 = orderEntity.customerEmail;
        }
        if ((i & 32) != 0) {
            d = orderEntity.price;
        }
        if ((i & 64) != 0) {
            localDateTime = orderEntity.timestamp;
        }
        java.time.LocalDateTime localDateTime2 = localDateTime;
        double d2 = d;
        java.lang.String str6 = str5;
        java.lang.String str7 = str3;
        return orderEntity.copy(str, str2, str7, str4, str6, d2, localDateTime2);
    }

    /* renamed from: component1, reason: from getter */
    public final java.lang.String getOrderNumber() {
        return this.orderNumber;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getDescription() {
        return this.description;
    }

    /* renamed from: component3, reason: from getter */
    public final java.lang.String getCustomerFirstName() {
        return this.customerFirstName;
    }

    /* renamed from: component4, reason: from getter */
    public final java.lang.String getCustomerLastName() {
        return this.customerLastName;
    }

    /* renamed from: component5, reason: from getter */
    public final java.lang.String getCustomerEmail() {
        return this.customerEmail;
    }

    /* renamed from: component6, reason: from getter */
    public final double getPrice() {
        return this.price;
    }

    /* renamed from: component7, reason: from getter */
    public final java.time.LocalDateTime getTimestamp() {
        return this.timestamp;
    }

    public final uhggroup.iceskating.app.data.entity.OrderEntity copy(java.lang.String orderNumber, java.lang.String description, java.lang.String customerFirstName, java.lang.String customerLastName, java.lang.String customerEmail, double price, java.time.LocalDateTime timestamp) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(orderNumber, "orderNumber");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerFirstName, "customerFirstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerLastName, "customerLastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerEmail, "customerEmail");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(timestamp, "timestamp");
        return new uhggroup.iceskating.app.data.entity.OrderEntity(orderNumber, description, customerFirstName, customerLastName, customerEmail, price, timestamp);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.data.entity.OrderEntity)) {
            return false;
        }
        uhggroup.iceskating.app.data.entity.OrderEntity orderEntity = (uhggroup.iceskating.app.data.entity.OrderEntity) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.orderNumber, orderEntity.orderNumber) && kotlin.jvm.internal.Intrinsics.areEqual(this.description, orderEntity.description) && kotlin.jvm.internal.Intrinsics.areEqual(this.customerFirstName, orderEntity.customerFirstName) && kotlin.jvm.internal.Intrinsics.areEqual(this.customerLastName, orderEntity.customerLastName) && kotlin.jvm.internal.Intrinsics.areEqual(this.customerEmail, orderEntity.customerEmail) && java.lang.Double.compare(this.price, orderEntity.price) == 0 && kotlin.jvm.internal.Intrinsics.areEqual(this.timestamp, orderEntity.timestamp);
    }

    public int hashCode() {
        return (((((((((((this.orderNumber.hashCode() * 31) + this.description.hashCode()) * 31) + this.customerFirstName.hashCode()) * 31) + this.customerLastName.hashCode()) * 31) + this.customerEmail.hashCode()) * 31) + java.lang.Double.hashCode(this.price)) * 31) + this.timestamp.hashCode();
    }

    public java.lang.String toString() {
        return "OrderEntity(orderNumber=" + this.orderNumber + ", description=" + this.description + ", customerFirstName=" + this.customerFirstName + ", customerLastName=" + this.customerLastName + ", customerEmail=" + this.customerEmail + ", price=" + this.price + ", timestamp=" + this.timestamp + ")";
    }

    public OrderEntity(java.lang.String orderNumber, java.lang.String description, java.lang.String customerFirstName, java.lang.String customerLastName, java.lang.String customerEmail, double d, java.time.LocalDateTime timestamp) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(orderNumber, "orderNumber");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(description, "description");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerFirstName, "customerFirstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerLastName, "customerLastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerEmail, "customerEmail");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(timestamp, "timestamp");
        this.orderNumber = orderNumber;
        this.description = description;
        this.customerFirstName = customerFirstName;
        this.customerLastName = customerLastName;
        this.customerEmail = customerEmail;
        this.price = d;
        this.timestamp = timestamp;
    }

    public final java.lang.String getOrderNumber() {
        return this.orderNumber;
    }

    public final java.lang.String getDescription() {
        return this.description;
    }

    public final java.lang.String getCustomerFirstName() {
        return this.customerFirstName;
    }

    public final java.lang.String getCustomerLastName() {
        return this.customerLastName;
    }

    public final java.lang.String getCustomerEmail() {
        return this.customerEmail;
    }

    public final double getPrice() {
        return this.price;
    }

    public final java.time.LocalDateTime getTimestamp() {
        return this.timestamp;
    }
}
