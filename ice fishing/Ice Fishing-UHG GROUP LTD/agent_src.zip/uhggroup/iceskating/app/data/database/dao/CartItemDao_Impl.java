package uhggroup.iceskating.app.data.database.dao;

/* compiled from: CartItemDao_Impl.kt */
@kotlin.Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\b\b\u0007\u0018\u0000  2\u00020\u0001:\u0001 B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\fJ\u0016\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fH\u0096@¢\u0006\u0002\u0010\u0010J\u0016\u0010\u0011\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fH\u0096@¢\u0006\u0002\u0010\u0010J\u0014\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00140\u0013H\u0016J\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\b0\u0014H\u0096@¢\u0006\u0002\u0010\u0016J\u0016\u0010\u0017\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010\u001aJ\u000e\u0010\u001b\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u0016J\u0016\u0010\u001c\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010\u001aJ\u0016\u0010\u001e\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010\u001aJ\u0016\u0010\u001f\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010\u001aR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/CartItemDao_Impl;", "Luhggroup/iceskating/app/data/database/dao/CartItemDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfCartItemEntity", "Landroidx/room/EntityInsertAdapter;", "Luhggroup/iceskating/app/data/entity/CartItemEntity;", "save", "", "cartItemEntity", "(Luhggroup/iceskating/app/data/entity/CartItemEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "incrementProductQuantityOrAdd", "product", "Luhggroup/iceskating/app/data/model/Product;", "(Luhggroup/iceskating/app/data/model/Product;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "decrementProductQuantityOrRemove", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "getAll", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteById", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteAll", "incrementQuantity", "productId", "decrementQuantity", "deleteIfQuantityOne", "Companion", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CartItemDao_Impl implements uhggroup.iceskating.app.data.database.dao.CartItemDao {
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertAdapter<uhggroup.iceskating.app.data.entity.CartItemEntity> __insertAdapterOfCartItemEntity;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.Companion INSTANCE = new uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.Companion(null);
    public static final int $stable = 8;

    public CartItemDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(__db, "__db");
        this.__db = __db;
        this.__insertAdapterOfCartItemEntity = new androidx.room.EntityInsertAdapter<uhggroup.iceskating.app.data.entity.CartItemEntity>() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.1
            @Override // androidx.room.EntityInsertAdapter
            protected java.lang.String createQuery() {
                return "INSERT OR IGNORE INTO `cart_items` (`id`,`quantity`) VALUES (?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(androidx.sqlite.SQLiteStatement statement, uhggroup.iceskating.app.data.entity.CartItemEntity entity) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(statement, "statement");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo9245bindLong(1, entity.getId());
                statement.mo9245bindLong(2, entity.getQuantity());
            }
        };
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object save(final uhggroup.iceskating.app.data.entity.CartItemEntity cartItemEntity, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objPerformSuspending = androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.save$lambda$0(this.f$0, cartItemEntity, (androidx.sqlite.SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit save$lambda$0(uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl cartItemDao_Impl, uhggroup.iceskating.app.data.entity.CartItemEntity cartItemEntity, androidx.sqlite.SQLiteConnection _connection) throws java.lang.Exception {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        cartItemDao_Impl.__insertAdapterOfCartItemEntity.insert(_connection, (androidx.sqlite.SQLiteConnection) cartItemEntity);
        return kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartItemDao_Impl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$incrementProductQuantityOrAdd$2", f = "CartItemDao_Impl.kt", i = {}, l = {49}, m = "invokeSuspend", n = {}, nl = {50}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$incrementProductQuantityOrAdd$2, reason: invalid class name and case insensitive filesystem */
    static final class C05322 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function1<kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ uhggroup.iceskating.app.data.model.Product $product;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05322(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.C05322> continuation) {
            super(1, continuation);
            this.$product = product;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.this.new C05322(this.$product, continuation);
        }

        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.C05322) create(continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.super.incrementProductQuantityOrAdd(this.$product, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object incrementProductQuantityOrAdd(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objPerformInTransactionSuspending = androidx.room.util.DBUtil.performInTransactionSuspending(this.__db, new uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.C05322(product, null), continuation);
        return objPerformInTransactionSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformInTransactionSuspending : kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartItemDao_Impl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$decrementProductQuantityOrRemove$2", f = "CartItemDao_Impl.kt", i = {}, l = {53}, m = "invokeSuspend", n = {}, nl = {54}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$decrementProductQuantityOrRemove$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function1<kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ uhggroup.iceskating.app.data.model.Product $product;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.AnonymousClass2> continuation) {
            super(1, continuation);
            this.$product = product;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.this.new AnonymousClass2(this.$product, continuation);
        }

        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.AnonymousClass2) create(continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.super.decrementProductQuantityOrRemove(this.$product, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object decrementProductQuantityOrRemove(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objPerformInTransactionSuspending = androidx.room.util.DBUtil.performInTransactionSuspending(this.__db, new uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.AnonymousClass2(product, null), continuation);
        return objPerformInTransactionSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformInTransactionSuspending : kotlin.Unit.INSTANCE;
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> observeAll() {
        final java.lang.String str = "SELECT * FROM cart_items";
        return androidx.room.coroutines.FlowUtil.createFlow(this.__db, false, new java.lang.String[]{"cart_items"}, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.observeAll$lambda$0(str, (androidx.sqlite.SQLiteConnection) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.util.List observeAll$lambda$0(java.lang.String str, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            int columnIndexOrThrow = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "id");
            int columnIndexOrThrow2 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "quantity");
            java.util.ArrayList arrayList = new java.util.ArrayList();
            while (sQLiteStatementPrepare.step()) {
                arrayList.add(new uhggroup.iceskating.app.data.entity.CartItemEntity((int) sQLiteStatementPrepare.getLong(columnIndexOrThrow), (int) sQLiteStatementPrepare.getLong(columnIndexOrThrow2)));
            }
            return arrayList;
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object getAll(kotlin.coroutines.Continuation<? super java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> continuation) {
        final java.lang.String str = "SELECT * FROM cart_items";
        return androidx.room.util.DBUtil.performSuspending(this.__db, true, false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.getAll$lambda$0(str, (androidx.sqlite.SQLiteConnection) obj);
            }
        }, continuation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.util.List getAll$lambda$0(java.lang.String str, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            int columnIndexOrThrow = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "id");
            int columnIndexOrThrow2 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "quantity");
            java.util.ArrayList arrayList = new java.util.ArrayList();
            while (sQLiteStatementPrepare.step()) {
                arrayList.add(new uhggroup.iceskating.app.data.entity.CartItemEntity((int) sQLiteStatementPrepare.getLong(columnIndexOrThrow), (int) sQLiteStatementPrepare.getLong(columnIndexOrThrow2)));
            }
            return arrayList;
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object deleteById(final int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        final java.lang.String str = "DELETE FROM cart_items WHERE id = ?";
        java.lang.Object objPerformSuspending = androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.deleteById$lambda$0(str, i, (androidx.sqlite.SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit deleteById$lambda$0(java.lang.String str, int i, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            sQLiteStatementPrepare.mo9245bindLong(1, i);
            sQLiteStatementPrepare.step();
            sQLiteStatementPrepare.close();
            return kotlin.Unit.INSTANCE;
        } catch (java.lang.Throwable th) {
            sQLiteStatementPrepare.close();
            throw th;
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object deleteAll(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        final java.lang.String str = "DELETE FROM cart_items";
        java.lang.Object objPerformSuspending = androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.deleteAll$lambda$0(str, (androidx.sqlite.SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit deleteAll$lambda$0(java.lang.String str, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            sQLiteStatementPrepare.step();
            sQLiteStatementPrepare.close();
            return kotlin.Unit.INSTANCE;
        } catch (java.lang.Throwable th) {
            sQLiteStatementPrepare.close();
            throw th;
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object incrementQuantity(final int i, kotlin.coroutines.Continuation<? super java.lang.Integer> continuation) {
        final java.lang.String str = "UPDATE cart_items SET quantity = quantity + 1 WHERE id = ?";
        return androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.incrementQuantity$lambda$0(str, i, (androidx.sqlite.SQLiteConnection) obj));
            }
        }, continuation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int incrementQuantity$lambda$0(java.lang.String str, int i, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            sQLiteStatementPrepare.mo9245bindLong(1, i);
            sQLiteStatementPrepare.step();
            return androidx.room.util.SQLiteConnectionUtil.getTotalChangedRows(_connection);
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object decrementQuantity(final int i, kotlin.coroutines.Continuation<? super java.lang.Integer> continuation) {
        final java.lang.String str = "UPDATE cart_items SET quantity = quantity - 1 WHERE id = ? AND quantity > 1";
        return androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.decrementQuantity$lambda$0(str, i, (androidx.sqlite.SQLiteConnection) obj));
            }
        }, continuation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int decrementQuantity$lambda$0(java.lang.String str, int i, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            sQLiteStatementPrepare.mo9245bindLong(1, i);
            sQLiteStatementPrepare.step();
            return androidx.room.util.SQLiteConnectionUtil.getTotalChangedRows(_connection);
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    @Override // uhggroup.iceskating.app.data.database.dao.CartItemDao
    public java.lang.Object deleteIfQuantityOne(final int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        final java.lang.String str = "DELETE FROM cart_items WHERE id = ? AND quantity = 1";
        java.lang.Object objPerformSuspending = androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.deleteIfQuantityOne$lambda$0(str, i, (androidx.sqlite.SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit deleteIfQuantityOne$lambda$0(java.lang.String str, int i, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            sQLiteStatementPrepare.mo9245bindLong(1, i);
            sQLiteStatementPrepare.step();
            sQLiteStatementPrepare.close();
            return kotlin.Unit.INSTANCE;
        } catch (java.lang.Throwable th) {
            sQLiteStatementPrepare.close();
            throw th;
        }
    }

    /* compiled from: CartItemDao_Impl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/CartItemDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    public static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final java.util.List<kotlin.reflect.KClass<?>> getRequiredConverters() {
            return kotlin.collections.CollectionsKt.emptyList();
        }
    }
}
