package uhggroup.iceskating.app.data.database;

/* compiled from: ICSAppDatabase.kt */
@kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0007H&¨\u0006\b"}, d2 = {"Luhggroup/iceskating/app/data/database/ICSAppDatabase;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "cartItemDao", "Luhggroup/iceskating/app/data/database/dao/CartItemDao;", "orderDao", "Luhggroup/iceskating/app/data/database/dao/OrderDao;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public abstract class ICSAppDatabase extends androidx.room.RoomDatabase {
    public static final int $stable = 8;

    public abstract uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao();

    public abstract uhggroup.iceskating.app.data.database.dao.OrderDao orderDao();
}
