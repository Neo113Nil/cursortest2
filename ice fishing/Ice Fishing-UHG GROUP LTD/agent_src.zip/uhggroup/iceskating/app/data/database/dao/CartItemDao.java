package uhggroup.iceskating.app.data.database.dao;

/* compiled from: CartItemDao.kt */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H§@¢\u0006\u0002\u0010\u0007J\u0016\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u000bJ\u0016\u0010\f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u000eH§@¢\u0006\u0002\u0010\u000fJ\u000e\u0010\u0010\u001a\u00020\tH§@¢\u0006\u0002\u0010\u0007J\u0016\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u000eH§@¢\u0006\u0002\u0010\u000fJ\u0016\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\u0015H\u0097@¢\u0006\u0002\u0010\u0016J\u0016\u0010\u0017\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u000eH§@¢\u0006\u0002\u0010\u000fJ\u0016\u0010\u0018\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u000eH§@¢\u0006\u0002\u0010\u000fJ\u0016\u0010\u0019\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\u0015H\u0097@¢\u0006\u0002\u0010\u0016¨\u0006\u001aÀ\u0006\u0003"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/CartItemDao;", "", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "Luhggroup/iceskating/app/data/entity/CartItemEntity;", "getAll", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "save", "", "cartItemEntity", "(Luhggroup/iceskating/app/data/entity/CartItemEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteById", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteAll", "incrementQuantity", "productId", "incrementProductQuantityOrAdd", "product", "Luhggroup/iceskating/app/data/model/Product;", "(Luhggroup/iceskating/app/data/model/Product;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "decrementQuantity", "deleteIfQuantityOne", "decrementProductQuantityOrRemove", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public interface CartItemDao {

    /* compiled from: CartItemDao.kt */
    @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.database.dao.CartItemDao", f = "CartItemDao.kt", i = {0, 0, 1, 1, 1}, l = {55, 57}, m = "decrementProductQuantityOrRemove$suspendImpl", n = {"$this", "product", "$this", "product", "updated"}, nl = {56, 59}, s = {"L$0", "L$1", "L$0", "L$1", "I$0"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.database.dao.CartItemDao$decrementProductQuantityOrRemove$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        int I$0;
        java.lang.Object L$0;
        java.lang.Object L$1;
        int label;
        /* synthetic */ java.lang.Object result;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.database.dao.CartItemDao.AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return uhggroup.iceskating.app.data.database.dao.CartItemDao.decrementProductQuantityOrRemove$suspendImpl(uhggroup.iceskating.app.data.database.dao.CartItemDao.this, null, this);
        }
    }

    /* compiled from: CartItemDao.kt */
    @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.database.dao.CartItemDao", f = "CartItemDao.kt", i = {0, 0, 1, 1, 1}, l = {35, androidx.core.view.MotionEventCompat.AXIS_GENERIC_7}, m = "incrementProductQuantityOrAdd$suspendImpl", n = {"$this", "product", "$this", "product", "updated"}, nl = {37, 45}, s = {"L$0", "L$1", "L$0", "L$1", "I$0"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.database.dao.CartItemDao$incrementProductQuantityOrAdd$1, reason: invalid class name and case insensitive filesystem */
    static final class C05311 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        int I$0;
        java.lang.Object L$0;
        java.lang.Object L$1;
        int label;
        /* synthetic */ java.lang.Object result;

        C05311(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.database.dao.CartItemDao.C05311> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return uhggroup.iceskating.app.data.database.dao.CartItemDao.incrementProductQuantityOrAdd$suspendImpl(uhggroup.iceskating.app.data.database.dao.CartItemDao.this, null, this);
        }
    }

    default java.lang.Object decrementProductQuantityOrRemove(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return decrementProductQuantityOrRemove$suspendImpl(this, product, continuation);
    }

    java.lang.Object decrementQuantity(int i, kotlin.coroutines.Continuation<? super java.lang.Integer> continuation);

    java.lang.Object deleteAll(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object deleteById(int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object deleteIfQuantityOne(int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    java.lang.Object getAll(kotlin.coroutines.Continuation<? super java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> continuation);

    default java.lang.Object incrementProductQuantityOrAdd(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return incrementProductQuantityOrAdd$suspendImpl(this, product, continuation);
    }

    java.lang.Object incrementQuantity(int i, kotlin.coroutines.Continuation<? super java.lang.Integer> continuation);

    kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> observeAll();

    java.lang.Object save(uhggroup.iceskating.app.data.entity.CartItemEntity cartItemEntity, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation);

    /* compiled from: CartItemDao.kt */
    @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    public static final class DefaultImpls {
        @java.lang.Deprecated
        public static java.lang.Object incrementProductQuantityOrAdd(uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao, uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return uhggroup.iceskating.app.data.database.dao.CartItemDao.super.incrementProductQuantityOrAdd(product, continuation);
        }

        @java.lang.Deprecated
        public static java.lang.Object decrementProductQuantityOrRemove(uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao, uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return uhggroup.iceskating.app.data.database.dao.CartItemDao.super.decrementProductQuantityOrRemove(product, continuation);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0085, code lost:
    
        if (r6.save(r2, r0) == r1) goto L23;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static /* synthetic */ java.lang.Object incrementProductQuantityOrAdd$suspendImpl(uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao, uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        uhggroup.iceskating.app.data.database.dao.CartItemDao.C05311 c05311;
        if (continuation instanceof uhggroup.iceskating.app.data.database.dao.CartItemDao.C05311) {
            c05311 = (uhggroup.iceskating.app.data.database.dao.CartItemDao.C05311) continuation;
            if ((c05311.label & Integer.MIN_VALUE) != 0) {
                c05311.label -= Integer.MIN_VALUE;
            } else {
                c05311 = cartItemDao.new C05311(continuation);
            }
        }
        java.lang.Object objIncrementQuantity = c05311.result;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = c05311.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(objIncrementQuantity);
            int id = product.getId();
            c05311.L$0 = cartItemDao;
            c05311.L$1 = product;
            c05311.label = 1;
            objIncrementQuantity = cartItemDao.incrementQuantity(id, c05311);
            if (objIncrementQuantity != coroutine_suspended) {
            }
            return coroutine_suspended;
        }
        if (i != 1) {
            if (i != 2) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            int i2 = c05311.I$0;
            kotlin.ResultKt.throwOnFailure(objIncrementQuantity);
            return kotlin.Unit.INSTANCE;
        }
        product = (uhggroup.iceskating.app.data.model.Product) c05311.L$1;
        cartItemDao = (uhggroup.iceskating.app.data.database.dao.CartItemDao) c05311.L$0;
        kotlin.ResultKt.throwOnFailure(objIncrementQuantity);
        int iIntValue = ((java.lang.Number) objIncrementQuantity).intValue();
        if (iIntValue != 0) {
            return kotlin.Unit.INSTANCE;
        }
        uhggroup.iceskating.app.data.entity.CartItemEntity cartItemEntity = new uhggroup.iceskating.app.data.entity.CartItemEntity(product.getId(), 1);
        c05311.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(cartItemDao);
        c05311.L$1 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(product);
        c05311.I$0 = iIntValue;
        c05311.label = 2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0080, code lost:
    
        if (r5.deleteIfQuantityOne(r2, r0) == r1) goto L23;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static /* synthetic */ java.lang.Object decrementProductQuantityOrRemove$suspendImpl(uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao, uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        uhggroup.iceskating.app.data.database.dao.CartItemDao.AnonymousClass1 anonymousClass1;
        if (continuation instanceof uhggroup.iceskating.app.data.database.dao.CartItemDao.AnonymousClass1) {
            anonymousClass1 = (uhggroup.iceskating.app.data.database.dao.CartItemDao.AnonymousClass1) continuation;
            if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                anonymousClass1.label -= Integer.MIN_VALUE;
            } else {
                anonymousClass1 = cartItemDao.new AnonymousClass1(continuation);
            }
        }
        java.lang.Object objDecrementQuantity = anonymousClass1.result;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = anonymousClass1.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(objDecrementQuantity);
            int id = product.getId();
            anonymousClass1.L$0 = cartItemDao;
            anonymousClass1.L$1 = product;
            anonymousClass1.label = 1;
            objDecrementQuantity = cartItemDao.decrementQuantity(id, anonymousClass1);
            if (objDecrementQuantity != coroutine_suspended) {
            }
            return coroutine_suspended;
        }
        if (i != 1) {
            if (i != 2) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            int i2 = anonymousClass1.I$0;
            kotlin.ResultKt.throwOnFailure(objDecrementQuantity);
            return kotlin.Unit.INSTANCE;
        }
        product = (uhggroup.iceskating.app.data.model.Product) anonymousClass1.L$1;
        cartItemDao = (uhggroup.iceskating.app.data.database.dao.CartItemDao) anonymousClass1.L$0;
        kotlin.ResultKt.throwOnFailure(objDecrementQuantity);
        int iIntValue = ((java.lang.Number) objDecrementQuantity).intValue();
        if (iIntValue != 0) {
            return kotlin.Unit.INSTANCE;
        }
        int id2 = product.getId();
        anonymousClass1.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(cartItemDao);
        anonymousClass1.L$1 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(product);
        anonymousClass1.I$0 = iIntValue;
        anonymousClass1.label = 2;
    }
}
