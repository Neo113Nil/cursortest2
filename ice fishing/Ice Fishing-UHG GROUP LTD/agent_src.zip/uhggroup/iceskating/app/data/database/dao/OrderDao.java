package uhggroup.iceskating.app.data.database.dao;

/* compiled from: OrderDao.kt */
@kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0016\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\t¨\u0006\nÀ\u0006\u0003"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/OrderDao;", "", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "save", "", "orderEntity", "(Luhggroup/iceskating/app/data/entity/OrderEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public interface OrderDao {
    kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> observeAll();

    java.lang.Object save(uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, kotlin.coroutines.Continuation<? super java.lang.Long> continuation);
}
