package uhggroup.iceskating.app.data.database;

/* compiled from: ICSAppDatabase_Impl.kt */
@kotlin.Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\t\u001a\u00020\nH\u0014J\b\u0010\u000b\u001a\u00020\fH\u0014J\b\u0010\r\u001a\u00020\u000eH\u0016J\"\u0010\u000f\u001a\u001c\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0011\u0012\u000e\u0012\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00110\u00120\u0010H\u0014J\u0016\u0010\u0013\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u00110\u0014H\u0016J*\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u00122\u001a\u0010\u0018\u001a\u0016\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0011\u0012\u0004\u0012\u00020\u00150\u0010H\u0016J\b\u0010\u0019\u001a\u00020\u0006H\u0016J\b\u0010\u001a\u001a\u00020\bH\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Luhggroup/iceskating/app/data/database/ICSAppDatabase_Impl;", "Luhggroup/iceskating/app/data/database/ICSAppDatabase;", "<init>", "()V", "_cartItemDao", "Lkotlin/Lazy;", "Luhggroup/iceskating/app/data/database/dao/CartItemDao;", "_orderDao", "Luhggroup/iceskating/app/data/database/dao/OrderDao;", "createOpenDelegate", "Landroidx/room/RoomOpenDelegate;", "createInvalidationTracker", "Landroidx/room/InvalidationTracker;", "clearAllTables", "", "getRequiredTypeConverterClasses", "", "Lkotlin/reflect/KClass;", "", "getRequiredAutoMigrationSpecClasses", "", "Landroidx/room/migration/AutoMigrationSpec;", "createAutoMigrations", "Landroidx/room/migration/Migration;", "autoMigrationSpecs", "cartItemDao", "orderDao", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSAppDatabase_Impl extends uhggroup.iceskating.app.data.database.ICSAppDatabase {
    public static final int $stable = 8;
    private final kotlin.Lazy<uhggroup.iceskating.app.data.database.dao.CartItemDao> _cartItemDao = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function0
        public final java.lang.Object invoke() {
            return uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl._cartItemDao$lambda$0(this.f$0);
        }
    });
    private final kotlin.Lazy<uhggroup.iceskating.app.data.database.dao.OrderDao> _orderDao = kotlin.LazyKt.lazy(new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function0
        public final java.lang.Object invoke() {
            return uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl._orderDao$lambda$0(this.f$0);
        }
    });

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl _cartItemDao$lambda$0(uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl iCSAppDatabase_Impl) {
        return new uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl(iCSAppDatabase_Impl);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.database.dao.OrderDao_Impl _orderDao$lambda$0(uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl iCSAppDatabase_Impl) {
        return new uhggroup.iceskating.app.data.database.dao.OrderDao_Impl(iCSAppDatabase_Impl);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.room.RoomDatabase
    public androidx.room.RoomOpenDelegate createOpenDelegate() {
        return new androidx.room.RoomOpenDelegate() { // from class: uhggroup.iceskating.app.data.database.ICSAppDatabase_Impl$createOpenDelegate$_openDelegate$1
            @Override // androidx.room.RoomOpenDelegate
            public void onCreate(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
            }

            @Override // androidx.room.RoomOpenDelegate
            public void onPostMigrate(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
            }

            {
                super(1, "e4d8b9c40a3023ed3f1f354d4f3fbfbf", "66b335e5f04ae5091aac85d1c0ed154c");
            }

            @Override // androidx.room.RoomOpenDelegate
            public void createAllTables(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
                androidx.sqlite.SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `cart_items` (`id` INTEGER NOT NULL, `quantity` INTEGER NOT NULL, PRIMARY KEY(`id`))");
                androidx.sqlite.SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `orders` (`order_number` TEXT NOT NULL, `description` TEXT NOT NULL, `customer_first_name` TEXT NOT NULL, `customer_last_name` TEXT NOT NULL, `customer_email` TEXT NOT NULL, `price` REAL NOT NULL, `timestamp` TEXT NOT NULL, PRIMARY KEY(`order_number`))");
                androidx.sqlite.SQLite.execSQL(connection, androidx.room.RoomMasterTable.CREATE_QUERY);
                androidx.sqlite.SQLite.execSQL(connection, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'e4d8b9c40a3023ed3f1f354d4f3fbfbf')");
            }

            @Override // androidx.room.RoomOpenDelegate
            public void dropAllTables(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
                androidx.sqlite.SQLite.execSQL(connection, "DROP TABLE IF EXISTS `cart_items`");
                androidx.sqlite.SQLite.execSQL(connection, "DROP TABLE IF EXISTS `orders`");
            }

            @Override // androidx.room.RoomOpenDelegate
            public void onOpen(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
                this.this$0.internalInitInvalidationTracker(connection);
            }

            @Override // androidx.room.RoomOpenDelegate
            public void onPreMigrate(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
                androidx.room.util.DBUtil.dropFtsSyncTriggers(connection);
            }

            @Override // androidx.room.RoomOpenDelegate
            public androidx.room.RoomOpenDelegate.ValidationResult onValidateSchema(androidx.sqlite.SQLiteConnection connection) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(connection, "connection");
                java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
                linkedHashMap.put("id", new androidx.room.util.TableInfo.Column("id", "INTEGER", true, 1, null, 1));
                linkedHashMap.put("quantity", new androidx.room.util.TableInfo.Column("quantity", "INTEGER", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo = new androidx.room.util.TableInfo("cart_items", linkedHashMap, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfo2 = androidx.room.util.TableInfo.INSTANCE.read(connection, "cart_items");
                if (!tableInfo.equals(tableInfo2)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult(false, "cart_items(uhggroup.iceskating.app.data.entity.CartItemEntity).\n Expected:\n" + tableInfo + "\n Found:\n" + tableInfo2);
                }
                java.util.LinkedHashMap linkedHashMap2 = new java.util.LinkedHashMap();
                linkedHashMap2.put("order_number", new androidx.room.util.TableInfo.Column("order_number", "TEXT", true, 1, null, 1));
                linkedHashMap2.put("description", new androidx.room.util.TableInfo.Column("description", "TEXT", true, 0, null, 1));
                linkedHashMap2.put("customer_first_name", new androidx.room.util.TableInfo.Column("customer_first_name", "TEXT", true, 0, null, 1));
                linkedHashMap2.put("customer_last_name", new androidx.room.util.TableInfo.Column("customer_last_name", "TEXT", true, 0, null, 1));
                linkedHashMap2.put("customer_email", new androidx.room.util.TableInfo.Column("customer_email", "TEXT", true, 0, null, 1));
                linkedHashMap2.put("price", new androidx.room.util.TableInfo.Column("price", "REAL", true, 0, null, 1));
                linkedHashMap2.put("timestamp", new androidx.room.util.TableInfo.Column("timestamp", "TEXT", true, 0, null, 1));
                androidx.room.util.TableInfo tableInfo3 = new androidx.room.util.TableInfo("orders", linkedHashMap2, new java.util.LinkedHashSet(), new java.util.LinkedHashSet());
                androidx.room.util.TableInfo tableInfo4 = androidx.room.util.TableInfo.INSTANCE.read(connection, "orders");
                if (!tableInfo3.equals(tableInfo4)) {
                    return new androidx.room.RoomOpenDelegate.ValidationResult(false, "orders(uhggroup.iceskating.app.data.entity.OrderEntity).\n Expected:\n" + tableInfo3 + "\n Found:\n" + tableInfo4);
                }
                return new androidx.room.RoomOpenDelegate.ValidationResult(true, null);
            }
        };
    }

    @Override // androidx.room.RoomDatabase
    protected androidx.room.InvalidationTracker createInvalidationTracker() {
        return new androidx.room.InvalidationTracker(this, new java.util.LinkedHashMap(), new java.util.LinkedHashMap(), "cart_items", "orders");
    }

    @Override // androidx.room.RoomDatabase
    public void clearAllTables() {
        super.performClear(false, "cart_items", "orders");
    }

    @Override // androidx.room.RoomDatabase
    protected java.util.Map<kotlin.reflect.KClass<?>, java.util.List<kotlin.reflect.KClass<?>>> getRequiredTypeConverterClasses() {
        java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap();
        linkedHashMap.put(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.CartItemDao.class), uhggroup.iceskating.app.data.database.dao.CartItemDao_Impl.INSTANCE.getRequiredConverters());
        linkedHashMap.put(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.OrderDao.class), uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.INSTANCE.getRequiredConverters());
        return linkedHashMap;
    }

    @Override // androidx.room.RoomDatabase
    public java.util.Set<kotlin.reflect.KClass<? extends androidx.room.migration.AutoMigrationSpec>> getRequiredAutoMigrationSpecClasses() {
        return new java.util.LinkedHashSet();
    }

    @Override // androidx.room.RoomDatabase
    public java.util.List<androidx.room.migration.Migration> createAutoMigrations(java.util.Map<kotlin.reflect.KClass<? extends androidx.room.migration.AutoMigrationSpec>, ? extends androidx.room.migration.AutoMigrationSpec> autoMigrationSpecs) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(autoMigrationSpecs, "autoMigrationSpecs");
        return new java.util.ArrayList();
    }

    @Override // uhggroup.iceskating.app.data.database.ICSAppDatabase
    public uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao() {
        return this._cartItemDao.getValue();
    }

    @Override // uhggroup.iceskating.app.data.database.ICSAppDatabase
    public uhggroup.iceskating.app.data.database.dao.OrderDao orderDao() {
        return this._orderDao.getValue();
    }
}
