package uhggroup.iceskating.app.data.database.dao;

/* compiled from: OrderDao_Impl.kt */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\b\u0007\u0018\u0000 \u00122\u00020\u0001:\u0001\u0012B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000eJ\u0014\u0010\u000f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00110\u0010H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/OrderDao_Impl;", "Luhggroup/iceskating/app/data/database/dao/OrderDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfOrderEntity", "Landroidx/room/EntityInsertAdapter;", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "__converters", "Luhggroup/iceskating/app/data/database/converter/Converters;", "save", "", "orderEntity", "(Luhggroup/iceskating/app/data/entity/OrderEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "Companion", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OrderDao_Impl implements uhggroup.iceskating.app.data.database.dao.OrderDao {
    private final uhggroup.iceskating.app.data.database.converter.Converters __converters;
    private final androidx.room.RoomDatabase __db;
    private final androidx.room.EntityInsertAdapter<uhggroup.iceskating.app.data.entity.OrderEntity> __insertAdapterOfOrderEntity;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.Companion INSTANCE = new uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.Companion(null);
    public static final int $stable = 8;

    public OrderDao_Impl(androidx.room.RoomDatabase __db) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(__db, "__db");
        this.__converters = new uhggroup.iceskating.app.data.database.converter.Converters();
        this.__db = __db;
        this.__insertAdapterOfOrderEntity = new androidx.room.EntityInsertAdapter<uhggroup.iceskating.app.data.entity.OrderEntity>() { // from class: uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.1
            @Override // androidx.room.EntityInsertAdapter
            protected java.lang.String createQuery() {
                return "INSERT OR ABORT INTO `orders` (`order_number`,`description`,`customer_first_name`,`customer_last_name`,`customer_email`,`price`,`timestamp`) VALUES (?,?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(androidx.sqlite.SQLiteStatement statement, uhggroup.iceskating.app.data.entity.OrderEntity entity) {
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(statement, "statement");
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo9247bindText(1, entity.getOrderNumber());
                statement.mo9247bindText(2, entity.getDescription());
                statement.mo9247bindText(3, entity.getCustomerFirstName());
                statement.mo9247bindText(4, entity.getCustomerLastName());
                statement.mo9247bindText(5, entity.getCustomerEmail());
                statement.mo9244bindDouble(6, entity.getPrice());
                java.lang.String strLocalDateTimeToString = uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.this.__converters.localDateTimeToString(entity.getTimestamp());
                if (strLocalDateTimeToString == null) {
                    statement.mo9246bindNull(7);
                } else {
                    statement.mo9247bindText(7, strLocalDateTimeToString);
                }
            }
        };
    }

    @Override // uhggroup.iceskating.app.data.database.dao.OrderDao
    public java.lang.Object save(final uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, kotlin.coroutines.Continuation<? super java.lang.Long> continuation) {
        return androidx.room.util.DBUtil.performSuspending(this.__db, false, true, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.OrderDao_Impl$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return java.lang.Long.valueOf(uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.save$lambda$0(this.f$0, orderEntity, (androidx.sqlite.SQLiteConnection) obj));
            }
        }, continuation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long save$lambda$0(uhggroup.iceskating.app.data.database.dao.OrderDao_Impl orderDao_Impl, uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        return orderDao_Impl.__insertAdapterOfOrderEntity.insertAndReturnId(_connection, orderEntity);
    }

    @Override // uhggroup.iceskating.app.data.database.dao.OrderDao
    public kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> observeAll() {
        final java.lang.String str = "SELECT * FROM orders";
        return androidx.room.coroutines.FlowUtil.createFlow(this.__db, false, new java.lang.String[]{"orders"}, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.data.database.dao.OrderDao_Impl$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.data.database.dao.OrderDao_Impl.observeAll$lambda$0(str, this, (androidx.sqlite.SQLiteConnection) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.util.List observeAll$lambda$0(java.lang.String str, uhggroup.iceskating.app.data.database.dao.OrderDao_Impl orderDao_Impl, androidx.sqlite.SQLiteConnection _connection) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(_connection, "_connection");
        androidx.sqlite.SQLiteStatement sQLiteStatementPrepare = _connection.prepare(str);
        try {
            int columnIndexOrThrow = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "order_number");
            int columnIndexOrThrow2 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "description");
            int columnIndexOrThrow3 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "customer_first_name");
            int columnIndexOrThrow4 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "customer_last_name");
            int columnIndexOrThrow5 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "customer_email");
            int columnIndexOrThrow6 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "price");
            int columnIndexOrThrow7 = androidx.room.util.SQLiteStatementUtil.getColumnIndexOrThrow(sQLiteStatementPrepare, "timestamp");
            java.util.ArrayList arrayList = new java.util.ArrayList();
            while (sQLiteStatementPrepare.step()) {
                java.lang.String text = sQLiteStatementPrepare.getText(columnIndexOrThrow);
                java.lang.String text2 = sQLiteStatementPrepare.getText(columnIndexOrThrow2);
                java.lang.String text3 = sQLiteStatementPrepare.getText(columnIndexOrThrow3);
                java.lang.String text4 = sQLiteStatementPrepare.getText(columnIndexOrThrow4);
                java.lang.String text5 = sQLiteStatementPrepare.getText(columnIndexOrThrow5);
                double d = sQLiteStatementPrepare.getDouble(columnIndexOrThrow6);
                int i = columnIndexOrThrow;
                java.time.LocalDateTime localDateTimeStringToLocalDateTime = orderDao_Impl.__converters.stringToLocalDateTime(sQLiteStatementPrepare.isNull(columnIndexOrThrow7) ? null : sQLiteStatementPrepare.getText(columnIndexOrThrow7));
                if (localDateTimeStringToLocalDateTime == null) {
                    throw new java.lang.IllegalStateException("Expected NON-NULL 'java.time.LocalDateTime', but it was NULL.".toString());
                }
                arrayList.add(new uhggroup.iceskating.app.data.entity.OrderEntity(text, text2, text3, text4, text5, d, localDateTimeStringToLocalDateTime));
                columnIndexOrThrow = i;
            }
            return arrayList;
        } finally {
            sQLiteStatementPrepare.close();
        }
    }

    /* compiled from: OrderDao_Impl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Luhggroup/iceskating/app/data/database/dao/OrderDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    public static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final java.util.List<kotlin.reflect.KClass<?>> getRequiredConverters() {
            return kotlin.collections.CollectionsKt.emptyList();
        }
    }
}
