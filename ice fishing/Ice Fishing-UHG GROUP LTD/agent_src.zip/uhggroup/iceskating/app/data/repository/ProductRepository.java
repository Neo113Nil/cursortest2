package uhggroup.iceskating.app.data.repository;

/* compiled from: ProductRepository.kt */
@kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\b2\u0006\u0010\t\u001a\u00020\nJ\u0010\u0010\u000b\u001a\u0004\u0018\u00010\u00062\u0006\u0010\t\u001a\u00020\nJ\u0012\u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00050\bR\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Luhggroup/iceskating/app/data/repository/ProductRepository;", "", "<init>", "()V", "products", "", "Luhggroup/iceskating/app/data/model/Product;", "observeById", "Lkotlinx/coroutines/flow/Flow;", "id", "", "getById", "observeAll", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductRepository {
    public static final int $stable = 8;
    private final java.util.List<uhggroup.iceskating.app.data.model.Product> products = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new uhggroup.iceskating.app.data.model.Product[]{new uhggroup.iceskating.app.data.model.Product(1, "Hardside spinner suitcase", "A durable polycarbonate suitcase with four smooth-rolling spinner wheels for easy maneuverability. Features a TSA-approved combination lock and expandable design for extra packing space. The interior includes compression straps and zippered dividers to keep belongings organized. Lightweight yet sturdy construction protects your items during travel.", uhggroup.iceskating.app.data.model.ProductCategory.SUITCASES, 89.99d, "https://m.media-amazon.com/images/I/7154wB9xPuL.jpg"), new uhggroup.iceskating.app.data.model.Product(2, "Carry-on suitcase", "A compact cabin-sized suitcase that fits most airline overhead compartments. Built with scratch-resistant hardshell material and reinforced corners for long-lasting durability. The telescopic handle adjusts to multiple heights for comfortable handling. Interior mesh pockets and elastic straps secure your essentials during transit.", uhggroup.iceskating.app.data.model.ProductCategory.SUITCASES, 64.99d, "https://media.wired.com/photos/5a5f8e04578ad833ef6878da/master/w_2560%2Cc_limit/Away_Carry-On_TopArt.jpg"), new uhggroup.iceskating.app.data.model.Product(3, "Duffel bag", "A spacious canvas duffel with reinforced stitching and heavy-duty metal zippers. The wide opening allows for easy packing and unpacking of clothing and gear. Padded shoulder strap and dual carry handles provide multiple carrying options. Water-resistant coating protects contents from light rain and spills.", uhggroup.iceskating.app.data.model.ProductCategory.TRAVEL_BAGS, 45.0d, "https://manofmany.com/wp-content/uploads/2015/09/Herschel-Supply-Co-e1443398719681.jpg"), new uhggroup.iceskating.app.data.model.Product(4, "Weekender bag", "An elegant overnight bag perfect for short trips and weekend getaways. Made from premium vegan leather with soft fabric lining to protect delicate items. Features an exterior shoe compartment to keep footwear separate from clothing. Includes a detachable shoulder strap for hands-free carrying.", uhggroup.iceskating.app.data.model.ProductCategory.TRAVEL_BAGS, 55.0d, "https://cdn.shopify.com/s/files/1/0419/1525/files/1024x1024-WeekenderBag-OldEnglish-100923-3.4.jpg?v=1699398826"), new uhggroup.iceskating.app.data.model.Product(5, "Travel backpack", "A versatile backpack designed specifically for air travel and extended trips. Multiple compartments organize electronics, documents, and personal items efficiently. Padded laptop sleeve fits devices up to 17 inches and includes a tablet pocket. Breathable back panel and adjustable straps ensure comfort during long periods of wear.", uhggroup.iceskating.app.data.model.ProductCategory.BACKPACKS, 72.0d, "https://cdn.shopify.com/s/files/1/0714/2398/3772/files/classic-back-door-bag-black.jpg?v=1777586211"), new uhggroup.iceskating.app.data.model.Product(6, "Laptop backpack", "A professional backpack with dedicated padded compartment for laptops and tablets. Features USB charging port for convenient device charging on the go. Water-repellent fabric keeps electronics safe from unexpected weather. Anti-theft pocket on the back panel secures valuables against pickpockets.", uhggroup.iceskating.app.data.model.ProductCategory.BACKPACKS, 49.99d, "https://i0.wp.com/nusrah.co/wp-content/uploads/2024/06/7-2-jpg.webp?resize=1000%2C1000&ssl=1"), new uhggroup.iceskating.app.data.model.Product(7, "Packing cubes", "A set of lightweight mesh packing cubes in various sizes for efficient luggage organization. See-through panels allow you to quickly identify contents without opening each cube. Double zippers ensure smooth operation and long-lasting durability. Helps compress clothing to maximize suitcase space and keep items wrinkle-free.", uhggroup.iceskating.app.data.model.ProductCategory.ORGANIZERS, 24.99d, "https://www.rockluggage.com/cdn/shop/files/4piecepackingcubesetfrontangleGrey_1080x.jpg?v=1756988111"), new uhggroup.iceskating.app.data.model.Product(8, "Toiletry bag", "A hanging toiletry organizer with multiple compartments for all your bathroom essentials. Features a sturdy hook for convenient hanging in bathrooms or on closet rods. Waterproof lining protects against leaks and spills from bottles and containers. Clear zippered pockets make it easy to find items quickly during your trip.", uhggroup.iceskating.app.data.model.ProductCategory.ORGANIZERS, 19.99d, "https://www.travelandleisure.com/thmb/gpBOcQmj27w6oxEPl3QbIP4PeTg=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/nishel-travel-toiletry-bag-c0433ba4b23a4914ad56bce7ffa82cc8.jpg"), new uhggroup.iceskating.app.data.model.Product(9, "Suitcase cover", "A stretchy protective cover that shields your luggage from scratches, dirt, and damage. Made from elastic polyester fabric that fits snugly over most standard suitcase sizes. Easy to install and remove with convenient opening for the handle. Machine washable for simple cleaning after each trip.", uhggroup.iceskating.app.data.model.ProductCategory.LUGGAGE_COVERS, 15.99d, "https://onyxjourney.com/cdn/shop/files/9Luggage_cover_Onyx_carry-on.png?v=1776076161&width=1500"), new uhggroup.iceskating.app.data.model.Product(10, "Waterproof luggage cover", "A heavy-duty rain cover designed to keep your suitcase completely dry in wet conditions. Made from thick PVC material with sealed seams to prevent water penetration. Elastic edges and drawstring closure ensure a secure fit during transport. Folds into a compact pouch for easy storage when not in use.", uhggroup.iceskating.app.data.model.ProductCategory.LUGGAGE_COVERS, 22.0d, "https://tm-prd-cdn.themarket.co.nz/resizer/view?key=21a43db40068b001a21855e4e1157331&b=productimages&w=1080&h=1080")});

    public final kotlinx.coroutines.flow.Flow<uhggroup.iceskating.app.data.model.Product> observeById(int id) {
        java.lang.Object next;
        java.util.Iterator<T> it = this.products.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((uhggroup.iceskating.app.data.model.Product) next).getId() == id) {
                break;
            }
        }
        return kotlinx.coroutines.flow.FlowKt.flowOf((uhggroup.iceskating.app.data.model.Product) next);
    }

    public final uhggroup.iceskating.app.data.model.Product getById(int id) {
        java.lang.Object next;
        java.util.Iterator<T> it = this.products.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((uhggroup.iceskating.app.data.model.Product) next).getId() == id) {
                break;
            }
        }
        return (uhggroup.iceskating.app.data.model.Product) next;
    }

    public final kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.model.Product>> observeAll() {
        return kotlinx.coroutines.flow.FlowKt.flowOf(this.products);
    }
}
