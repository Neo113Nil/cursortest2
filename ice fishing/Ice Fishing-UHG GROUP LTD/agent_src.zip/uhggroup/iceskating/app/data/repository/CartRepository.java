package uhggroup.iceskating.app.data.repository;

/* compiled from: CartRepository.kt */
@kotlin.Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\tJ\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0086@¢\u0006\u0002\u0010\rJ\u0016\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0086@¢\u0006\u0002\u0010\u0012J\u000e\u0010\u0013\u001a\u00020\u000fH\u0086@¢\u0006\u0002\u0010\rJ\u0016\u0010\u0014\u001a\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\u0011H\u0086@¢\u0006\u0002\u0010\u0012J\u0016\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0017\u001a\u00020\u0018H\u0086@¢\u0006\u0002\u0010\u0019J\u0016\u0010\u001a\u001a\u00020\u000f2\u0006\u0010\u0017\u001a\u00020\u0018H\u0086@¢\u0006\u0002\u0010\u0019R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Luhggroup/iceskating/app/data/repository/CartRepository;", "", "cartItemDao", "Luhggroup/iceskating/app/data/database/dao/CartItemDao;", "coroutineDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "<init>", "(Luhggroup/iceskating/app/data/database/dao/CartItemDao;Lkotlinx/coroutines/CoroutineDispatcher;)V", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "Luhggroup/iceskating/app/data/entity/CartItemEntity;", "getAll", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteById", "", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteAll", "incrementQuantity", "productId", "incrementProductQuantityOrAdd", "product", "Luhggroup/iceskating/app/data/model/Product;", "(Luhggroup/iceskating/app/data/model/Product;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "decrementProductQuantityOrRemove", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CartRepository {
    public static final int $stable = 8;
    private final uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao;
    private final kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher;

    public CartRepository(uhggroup.iceskating.app.data.database.dao.CartItemDao cartItemDao, kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartItemDao, "cartItemDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(coroutineDispatcher, "coroutineDispatcher");
        this.cartItemDao = cartItemDao;
        this.coroutineDispatcher = coroutineDispatcher;
    }

    public final kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> observeAll() {
        return this.cartItemDao.observeAll();
    }

    public final java.lang.Object getAll(kotlin.coroutines.Continuation<? super java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> continuation) {
        return this.cartItemDao.getAll(continuation);
    }

    /* compiled from: CartRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.CartRepository$deleteById$2", f = "CartRepository.kt", i = {}, l = {25}, m = "invokeSuspend", n = {}, nl = {26}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.CartRepository$deleteById$2, reason: invalid class name and case insensitive filesystem */
    static final class C05342 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $id;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05342(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.CartRepository.C05342> continuation) {
            super(2, continuation);
            this.$id = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.CartRepository.this.new C05342(this.$id, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.repository.CartRepository.C05342) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.repository.CartRepository.this.cartItemDao.deleteById(this.$id, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final java.lang.Object deleteById(int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.CartRepository.C05342(i, null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.CartRepository$deleteAll$2", f = "CartRepository.kt", i = {}, l = {31}, m = "invokeSuspend", n = {}, nl = {32}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.CartRepository$deleteAll$2, reason: invalid class name and case insensitive filesystem */
    static final class C05332 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C05332(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.CartRepository.C05332> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.CartRepository.this.new C05332(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.repository.CartRepository.C05332) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.repository.CartRepository.this.cartItemDao.deleteAll(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final java.lang.Object deleteAll(kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.CartRepository.C05332(null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.CartRepository$incrementQuantity$2", f = "CartRepository.kt", i = {}, l = {37}, m = "invokeSuspend", n = {}, nl = {-1}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.CartRepository$incrementQuantity$2, reason: invalid class name and case insensitive filesystem */
    static final class C05362 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.Integer>, java.lang.Object> {
        final /* synthetic */ int $productId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05362(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.CartRepository.C05362> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.CartRepository.this.new C05362(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super java.lang.Integer> continuation) {
            return ((uhggroup.iceskating.app.data.repository.CartRepository.C05362) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i != 0) {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
                return obj;
            }
            kotlin.ResultKt.throwOnFailure(obj);
            this.label = 1;
            java.lang.Object objIncrementQuantity = uhggroup.iceskating.app.data.repository.CartRepository.this.cartItemDao.incrementQuantity(this.$productId, this);
            return objIncrementQuantity == coroutine_suspended ? coroutine_suspended : objIncrementQuantity;
        }
    }

    public final java.lang.Object incrementQuantity(int i, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.CartRepository.C05362(i, null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.CartRepository$incrementProductQuantityOrAdd$2", f = "CartRepository.kt", i = {}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_12}, m = "invokeSuspend", n = {}, nl = {44}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.CartRepository$incrementProductQuantityOrAdd$2, reason: invalid class name and case insensitive filesystem */
    static final class C05352 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ uhggroup.iceskating.app.data.model.Product $product;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05352(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.CartRepository.C05352> continuation) {
            super(2, continuation);
            this.$product = product;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.CartRepository.this.new C05352(this.$product, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.repository.CartRepository.C05352) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.repository.CartRepository.this.cartItemDao.incrementProductQuantityOrAdd(this.$product, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final java.lang.Object incrementProductQuantityOrAdd(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.CartRepository.C05352(product, null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }

    /* compiled from: CartRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.CartRepository$decrementProductQuantityOrRemove$2", f = "CartRepository.kt", i = {}, l = {49}, m = "invokeSuspend", n = {}, nl = {50}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.CartRepository$decrementProductQuantityOrRemove$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ uhggroup.iceskating.app.data.model.Product $product;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.CartRepository.AnonymousClass2> continuation) {
            super(2, continuation);
            this.$product = product;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.CartRepository.this.new AnonymousClass2(this.$product, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.repository.CartRepository.AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.repository.CartRepository.this.cartItemDao.decrementProductQuantityOrRemove(this.$product, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final java.lang.Object decrementProductQuantityOrRemove(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.CartRepository.AnonymousClass2(product, null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }
}
