package uhggroup.iceskating.app.data.repository;

/* compiled from: OrderRepository.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0016\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\fJ\u0012\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\u000f0\u000eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Luhggroup/iceskating/app/data/repository/OrderRepository;", "", "orderDao", "Luhggroup/iceskating/app/data/database/dao/OrderDao;", "coroutineDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "<init>", "(Luhggroup/iceskating/app/data/database/dao/OrderDao;Lkotlinx/coroutines/CoroutineDispatcher;)V", "save", "", "orderEntity", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "(Luhggroup/iceskating/app/data/entity/OrderEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "observeAll", "Lkotlinx/coroutines/flow/Flow;", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OrderRepository {
    public static final int $stable = 8;
    private final kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher;
    private final uhggroup.iceskating.app.data.database.dao.OrderDao orderDao;

    public OrderRepository(uhggroup.iceskating.app.data.database.dao.OrderDao orderDao, kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(orderDao, "orderDao");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(coroutineDispatcher, "coroutineDispatcher");
        this.orderDao = orderDao;
        this.coroutineDispatcher = coroutineDispatcher;
    }

    /* compiled from: OrderRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\t\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.OrderRepository$save$2", f = "OrderRepository.kt", i = {}, l = {15}, m = "invokeSuspend", n = {}, nl = {-1}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.OrderRepository$save$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super java.lang.Long>, java.lang.Object> {
        final /* synthetic */ uhggroup.iceskating.app.data.entity.OrderEntity $orderEntity;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.OrderRepository.AnonymousClass2> continuation) {
            super(2, continuation);
            this.$orderEntity = orderEntity;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.OrderRepository.this.new AnonymousClass2(this.$orderEntity, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super java.lang.Long> continuation) {
            return ((uhggroup.iceskating.app.data.repository.OrderRepository.AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i != 0) {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
                return obj;
            }
            kotlin.ResultKt.throwOnFailure(obj);
            this.label = 1;
            java.lang.Object objSave = uhggroup.iceskating.app.data.repository.OrderRepository.this.orderDao.save(this.$orderEntity, this);
            return objSave == coroutine_suspended ? coroutine_suspended : objSave;
        }
    }

    public final java.lang.Object save(uhggroup.iceskating.app.data.entity.OrderEntity orderEntity, kotlin.coroutines.Continuation<? super java.lang.Long> continuation) {
        return kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.OrderRepository.AnonymousClass2(orderEntity, null), continuation);
    }

    public final kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> observeAll() {
        return this.orderDao.observeAll();
    }
}
