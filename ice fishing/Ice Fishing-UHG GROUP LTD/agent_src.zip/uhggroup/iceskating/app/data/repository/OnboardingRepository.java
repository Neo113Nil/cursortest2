package uhggroup.iceskating.app.data.repository;

/* compiled from: OnboardingRepository.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\tJ\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\nH\u0086@¢\u0006\u0002\u0010\u000eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Luhggroup/iceskating/app/data/repository/OnboardingRepository;", "", "onboardingDataStoreManager", "Luhggroup/iceskating/app/data/datastore/OnboardingDataStoreManager;", "coroutineDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "<init>", "(Luhggroup/iceskating/app/data/datastore/OnboardingDataStoreManager;Lkotlinx/coroutines/CoroutineDispatcher;)V", "observeOnboardingState", "Lkotlinx/coroutines/flow/Flow;", "", "setOnboardingState", "", "state", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OnboardingRepository {
    public static final int $stable = 8;
    private final kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher;
    private final uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager onboardingDataStoreManager;

    public OnboardingRepository(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager onboardingDataStoreManager, kotlinx.coroutines.CoroutineDispatcher coroutineDispatcher) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onboardingDataStoreManager, "onboardingDataStoreManager");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(coroutineDispatcher, "coroutineDispatcher");
        this.onboardingDataStoreManager = onboardingDataStoreManager;
        this.coroutineDispatcher = coroutineDispatcher;
    }

    public final kotlinx.coroutines.flow.Flow<java.lang.Boolean> observeOnboardingState() {
        return this.onboardingDataStoreManager.getOnboardedStateFlow();
    }

    /* compiled from: OnboardingRepository.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.data.repository.OnboardingRepository$setOnboardingState$2", f = "OnboardingRepository.kt", i = {}, l = {19}, m = "invokeSuspend", n = {}, nl = {20}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.data.repository.OnboardingRepository$setOnboardingState$2, reason: invalid class name */
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ boolean $state;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(boolean z, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.data.repository.OnboardingRepository.AnonymousClass2> continuation) {
            super(2, continuation);
            this.$state = z;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.data.repository.OnboardingRepository.this.new AnonymousClass2(this.$state, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.data.repository.OnboardingRepository.AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.data.repository.OnboardingRepository.this.onboardingDataStoreManager.setOnboardedState(this.$state, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final java.lang.Object setOnboardingState(boolean z, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        java.lang.Object objWithContext = kotlinx.coroutines.BuildersKt.withContext(this.coroutineDispatcher, new uhggroup.iceskating.app.data.repository.OnboardingRepository.AnonymousClass2(z, null), continuation);
        return objWithContext == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : kotlin.Unit.INSTANCE;
    }
}
