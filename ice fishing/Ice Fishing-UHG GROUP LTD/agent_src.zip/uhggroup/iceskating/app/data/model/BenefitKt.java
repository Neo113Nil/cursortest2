package uhggroup.iceskating.app.data.model;

/* compiled from: Benefit.kt */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"productBenefits", "", "Luhggroup/iceskating/app/data/model/Benefit;", "getProductBenefits", "()Ljava/util/List;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class BenefitKt {
    private static final java.util.List<uhggroup.iceskating.app.data.model.Benefit> productBenefits = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new uhggroup.iceskating.app.data.model.Benefit[]{new uhggroup.iceskating.app.data.model.Benefit(androidx.compose.material.icons.filled.WorkspacePremiumKt.getWorkspacePremium(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Premium quality materials"), new uhggroup.iceskating.app.data.model.Benefit(androidx.compose.material.icons.filled.VerifiedKt.getVerified(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Two-year warranty"), new uhggroup.iceskating.app.data.model.Benefit(androidx.compose.material.icons.filled.LocalShippingKt.getLocalShipping(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), "Free shipping on orders over £50")});

    public static final java.util.List<uhggroup.iceskating.app.data.model.Benefit> getProductBenefits() {
        return productBenefits;
    }
}
