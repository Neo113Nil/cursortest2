package uhggroup.iceskating.app.data.model;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: ProductCategory.kt */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f¨\u0006\r"}, d2 = {"Luhggroup/iceskating/app/data/model/ProductCategory;", "", "titleRes", "", "<init>", "(Ljava/lang/String;II)V", "getTitleRes", "()I", "SUITCASES", "TRAVEL_BAGS", "BACKPACKS", "ORGANIZERS", "LUGGAGE_COVERS", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductCategory {
    private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES;
    private static final /* synthetic */ uhggroup.iceskating.app.data.model.ProductCategory[] $VALUES;
    private final int titleRes;
    public static final uhggroup.iceskating.app.data.model.ProductCategory SUITCASES = new uhggroup.iceskating.app.data.model.ProductCategory("SUITCASES", 0, uhggroup.iceskating.app.R.string.product_category_suitcases_title);
    public static final uhggroup.iceskating.app.data.model.ProductCategory TRAVEL_BAGS = new uhggroup.iceskating.app.data.model.ProductCategory("TRAVEL_BAGS", 1, uhggroup.iceskating.app.R.string.product_category_travel_bags_title);
    public static final uhggroup.iceskating.app.data.model.ProductCategory BACKPACKS = new uhggroup.iceskating.app.data.model.ProductCategory("BACKPACKS", 2, uhggroup.iceskating.app.R.string.product_category_backpacks_title);
    public static final uhggroup.iceskating.app.data.model.ProductCategory ORGANIZERS = new uhggroup.iceskating.app.data.model.ProductCategory("ORGANIZERS", 3, uhggroup.iceskating.app.R.string.product_category_organizers_title);
    public static final uhggroup.iceskating.app.data.model.ProductCategory LUGGAGE_COVERS = new uhggroup.iceskating.app.data.model.ProductCategory("LUGGAGE_COVERS", 4, uhggroup.iceskating.app.R.string.product_category_luggage_covers_title);

    private static final /* synthetic */ uhggroup.iceskating.app.data.model.ProductCategory[] $values() {
        return new uhggroup.iceskating.app.data.model.ProductCategory[]{SUITCASES, TRAVEL_BAGS, BACKPACKS, ORGANIZERS, LUGGAGE_COVERS};
    }

    public static kotlin.enums.EnumEntries<uhggroup.iceskating.app.data.model.ProductCategory> getEntries() {
        return $ENTRIES;
    }

    public static uhggroup.iceskating.app.data.model.ProductCategory valueOf(java.lang.String str) {
        return (uhggroup.iceskating.app.data.model.ProductCategory) java.lang.Enum.valueOf(uhggroup.iceskating.app.data.model.ProductCategory.class, str);
    }

    public static uhggroup.iceskating.app.data.model.ProductCategory[] values() {
        return (uhggroup.iceskating.app.data.model.ProductCategory[]) $VALUES.clone();
    }

    private ProductCategory(java.lang.String str, int i, int i2) {
        this.titleRes = i2;
    }

    public final int getTitleRes() {
        return this.titleRes;
    }

    static {
        uhggroup.iceskating.app.data.model.ProductCategory[] productCategoryArr$values = $values();
        $VALUES = productCategoryArr$values;
        $ENTRIES = kotlin.enums.EnumEntriesKt.enumEntries(productCategoryArr$values);
    }
}
