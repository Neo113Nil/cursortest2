package uhggroup.iceskating.app.data.model;

/* compiled from: Benefit.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0014\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0012\u001a\u00020\u0013HÖ\u0081\u0004J\n\u0010\u0014\u001a\u00020\u0005HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"Luhggroup/iceskating/app/data/model/Benefit;", "", "icon", "Landroidx/compose/ui/graphics/vector/ImageVector;", "text", "", "<init>", "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;)V", "getIcon", "()Landroidx/compose/ui/graphics/vector/ImageVector;", "getText", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class Benefit {
    public static final int $stable = 0;
    private final androidx.compose.ui.graphics.vector.ImageVector icon;
    private final java.lang.String text;

    public static /* synthetic */ uhggroup.iceskating.app.data.model.Benefit copy$default(uhggroup.iceskating.app.data.model.Benefit benefit, androidx.compose.ui.graphics.vector.ImageVector imageVector, java.lang.String str, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            imageVector = benefit.icon;
        }
        if ((i & 2) != 0) {
            str = benefit.text;
        }
        return benefit.copy(imageVector, str);
    }

    /* renamed from: component1, reason: from getter */
    public final androidx.compose.ui.graphics.vector.ImageVector getIcon() {
        return this.icon;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getText() {
        return this.text;
    }

    public final uhggroup.iceskating.app.data.model.Benefit copy(androidx.compose.ui.graphics.vector.ImageVector icon, java.lang.String text) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icon, "icon");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(text, "text");
        return new uhggroup.iceskating.app.data.model.Benefit(icon, text);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.data.model.Benefit)) {
            return false;
        }
        uhggroup.iceskating.app.data.model.Benefit benefit = (uhggroup.iceskating.app.data.model.Benefit) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.icon, benefit.icon) && kotlin.jvm.internal.Intrinsics.areEqual(this.text, benefit.text);
    }

    public int hashCode() {
        return (this.icon.hashCode() * 31) + this.text.hashCode();
    }

    public java.lang.String toString() {
        return "Benefit(icon=" + this.icon + ", text=" + this.text + ")";
    }

    public Benefit(androidx.compose.ui.graphics.vector.ImageVector icon, java.lang.String text) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icon, "icon");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(text, "text");
        this.icon = icon;
        this.text = text;
    }

    public final androidx.compose.ui.graphics.vector.ImageVector getIcon() {
        return this.icon;
    }

    public final java.lang.String getText() {
        return this.text;
    }
}
