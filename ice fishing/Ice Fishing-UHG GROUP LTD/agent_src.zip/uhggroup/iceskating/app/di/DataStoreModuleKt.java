package uhggroup.iceskating.app.di;

/* compiled from: DataStoreModule.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"dataStoreModule", "Lorg/koin/core/module/Module;", "getDataStoreModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DataStoreModuleKt {
    private static final org.koin.core.module.Module dataStoreModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.di.DataStoreModuleKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            return uhggroup.iceskating.app.di.DataStoreModuleKt.dataStoreModule$lambda$0((org.koin.core.module.Module) obj);
        }
    }, 1, null);

    public static final org.koin.core.module.Module getDataStoreModule() {
        return dataStoreModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit dataStoreModule$lambda$0(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        kotlin.jvm.functions.Function2 function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DataStoreModuleKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DataStoreModuleKt.dataStoreModule$lambda$0$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.class), null, function2, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory2 = singleInstanceFactory;
        module.indexPrimaryType(singleInstanceFactory2);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager dataStoreModule$lambda$0$0(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager(org.koin.android.ext.koin.ModuleExtKt.androidContext(single));
    }
}
