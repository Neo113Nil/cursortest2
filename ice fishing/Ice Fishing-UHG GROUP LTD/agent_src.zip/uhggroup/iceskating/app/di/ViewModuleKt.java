package uhggroup.iceskating.app.di;

/* compiled from: ViewModule.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"viewModule", "Lorg/koin/core/module/Module;", "getViewModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ViewModuleKt {
    private static final org.koin.core.module.Module viewModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0((org.koin.core.module.Module) obj);
        }
    }, 1, null);

    public static final org.koin.core.module.Module getViewModule() {
        return viewModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit viewModule$lambda$0(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        kotlin.jvm.functions.Function2 function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.AppViewModel.class), null, function2, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory);
        kotlin.jvm.functions.Function2 function22 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$1((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory2 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.SplashViewModel.class), null, function22, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory2);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory2);
        kotlin.jvm.functions.Function2 function23 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$2((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory3 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.class), null, function23, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory3);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory3);
        kotlin.jvm.functions.Function2 function24 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$3((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory4 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.class), null, function24, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory4);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory4);
        kotlin.jvm.functions.Function2 function25 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$4((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory5 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.class), null, function25, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory5);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory5);
        kotlin.jvm.functions.Function2 function26 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$5((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory6 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.class), null, function26, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory6);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory6);
        kotlin.jvm.functions.Function2 function27 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$6((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory7 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.CartViewModel.class), null, function27, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory7);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory7);
        kotlin.jvm.functions.Function2 function28 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.ViewModuleKt$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.ViewModuleKt.viewModule$lambda$0$7((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.FactoryInstanceFactory factoryInstanceFactory8 = new org.koin.core.instance.FactoryInstanceFactory(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.class), null, function28, org.koin.core.definition.Kind.Factory, kotlin.collections.CollectionsKt.emptyList()));
        module.indexPrimaryType(factoryInstanceFactory8);
        new org.koin.core.definition.KoinDefinition(module, factoryInstanceFactory8);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.AppViewModel viewModule$lambda$0$0(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.AppViewModel((uhggroup.iceskating.app.data.repository.CartRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.SplashViewModel viewModule$lambda$0$1(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.SplashViewModel((uhggroup.iceskating.app.data.repository.OnboardingRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OnboardingRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel viewModule$lambda$0$2(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel((uhggroup.iceskating.app.data.repository.OnboardingRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OnboardingRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.ProductViewModel viewModule$lambda$0$3(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.ProductViewModel((uhggroup.iceskating.app.data.repository.ProductRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.ProductRepository.class), null, null), (uhggroup.iceskating.app.data.repository.CartRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel viewModule$lambda$0$4(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel((uhggroup.iceskating.app.data.repository.ProductRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.ProductRepository.class), null, null), (uhggroup.iceskating.app.data.repository.CartRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel viewModule$lambda$0$5(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel((uhggroup.iceskating.app.data.repository.CartRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, null), (uhggroup.iceskating.app.data.repository.ProductRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.ProductRepository.class), null, null), (uhggroup.iceskating.app.data.repository.OrderRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OrderRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.CartViewModel viewModule$lambda$0$6(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.CartViewModel((uhggroup.iceskating.app.data.repository.CartRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, null), (uhggroup.iceskating.app.data.repository.ProductRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.ProductRepository.class), null, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.ui.viewmodel.OrderViewModel viewModule$lambda$0$7(org.koin.core.scope.Scope viewModel, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(viewModel, "$this$viewModel");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.ui.viewmodel.OrderViewModel((uhggroup.iceskating.app.data.repository.OrderRepository) viewModel.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OrderRepository.class), null, null));
    }
}
