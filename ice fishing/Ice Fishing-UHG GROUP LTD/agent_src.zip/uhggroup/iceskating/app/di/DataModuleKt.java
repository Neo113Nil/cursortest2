package uhggroup.iceskating.app.di;

/* compiled from: DataModule.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"dataModule", "Lorg/koin/core/module/Module;", "getDataModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DataModuleKt {
    private static final org.koin.core.module.Module dataModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.di.DataModuleKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            return uhggroup.iceskating.app.di.DataModuleKt.dataModule$lambda$0((org.koin.core.module.Module) obj);
        }
    }, 1, null);

    public static final org.koin.core.module.Module getDataModule() {
        return dataModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit dataModule$lambda$0(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        module.includes(uhggroup.iceskating.app.di.DatabaseModuleKt.getDatabaseModule(), uhggroup.iceskating.app.di.DataStoreModuleKt.getDataStoreModule());
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OnboardingRepository.class), null, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DataModuleKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DataModuleKt.dataModule$lambda$0$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        }, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory2 = singleInstanceFactory;
        module.indexPrimaryType(singleInstanceFactory2);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory2);
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory3 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.ProductRepository.class), null, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DataModuleKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DataModuleKt.dataModule$lambda$0$1((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        }, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory4 = singleInstanceFactory3;
        module.indexPrimaryType(singleInstanceFactory4);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory3);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory4);
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory5 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.CartRepository.class), null, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DataModuleKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DataModuleKt.dataModule$lambda$0$2((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        }, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory6 = singleInstanceFactory5;
        module.indexPrimaryType(singleInstanceFactory6);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory5);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory6);
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory7 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.repository.OrderRepository.class), null, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DataModuleKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DataModuleKt.dataModule$lambda$0$3((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        }, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory8 = singleInstanceFactory7;
        module.indexPrimaryType(singleInstanceFactory8);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory7);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory8);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.repository.OnboardingRepository dataModule$lambda$0$0(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.data.repository.OnboardingRepository((uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.datastore.OnboardingDataStoreManager.class), null, null), (kotlinx.coroutines.CoroutineDispatcher) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), org.koin.core.qualifier.QualifierKt.named("IO"), null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.repository.ProductRepository dataModule$lambda$0$1(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.data.repository.ProductRepository();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.repository.CartRepository dataModule$lambda$0$2(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.data.repository.CartRepository((uhggroup.iceskating.app.data.database.dao.CartItemDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.CartItemDao.class), null, null), (kotlinx.coroutines.CoroutineDispatcher) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), org.koin.core.qualifier.QualifierKt.named("IO"), null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.repository.OrderRepository dataModule$lambda$0$3(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return new uhggroup.iceskating.app.data.repository.OrderRepository((uhggroup.iceskating.app.data.database.dao.OrderDao) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.OrderDao.class), null, null), (kotlinx.coroutines.CoroutineDispatcher) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), org.koin.core.qualifier.QualifierKt.named("IO"), null));
    }
}
