package uhggroup.iceskating.app.di;

/* compiled from: DispatcherModule.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"dispatcherModule", "Lorg/koin/core/module/Module;", "getDispatcherModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DispatcherModuleKt {
    private static final org.koin.core.module.Module dispatcherModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.di.DispatcherModuleKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            return uhggroup.iceskating.app.di.DispatcherModuleKt.dispatcherModule$lambda$0((org.koin.core.module.Module) obj);
        }
    }, 1, null);

    public static final org.koin.core.module.Module getDispatcherModule() {
        return dispatcherModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit dispatcherModule$lambda$0(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        org.koin.core.qualifier.StringQualifier io = uhggroup.iceskating.app.di.DispatchersQualifiers.INSTANCE.getIO();
        kotlin.jvm.functions.Function2 function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DispatcherModuleKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DispatcherModuleKt.dispatcherModule$lambda$0$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), io, function2, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory2 = singleInstanceFactory;
        module.indexPrimaryType(singleInstanceFactory2);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory2);
        org.koin.core.qualifier.StringQualifier stringQualifier = uhggroup.iceskating.app.di.DispatchersQualifiers.INSTANCE.getDefault();
        kotlin.jvm.functions.Function2 function22 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DispatcherModuleKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DispatcherModuleKt.dispatcherModule$lambda$0$1((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory3 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), stringQualifier, function22, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory4 = singleInstanceFactory3;
        module.indexPrimaryType(singleInstanceFactory4);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory3);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory4);
        org.koin.core.qualifier.StringQualifier main = uhggroup.iceskating.app.di.DispatchersQualifiers.INSTANCE.getMain();
        kotlin.jvm.functions.Function2 function23 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DispatcherModuleKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DispatcherModuleKt.dispatcherModule$lambda$0$2((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory5 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(kotlinx.coroutines.CoroutineDispatcher.class), main, function23, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory6 = singleInstanceFactory5;
        module.indexPrimaryType(singleInstanceFactory6);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory5);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory6);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlinx.coroutines.CoroutineDispatcher dispatcherModule$lambda$0$0(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return kotlinx.coroutines.Dispatchers.getIO();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlinx.coroutines.CoroutineDispatcher dispatcherModule$lambda$0$1(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return kotlinx.coroutines.Dispatchers.getDefault();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlinx.coroutines.CoroutineDispatcher dispatcherModule$lambda$0$2(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return kotlinx.coroutines.Dispatchers.getMain();
    }
}
