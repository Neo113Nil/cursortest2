package uhggroup.iceskating.app.di;

/* compiled from: DatabaseModule.kt */
@kotlin.Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"DB_NAME", "", "databaseModule", "Lorg/koin/core/module/Module;", "getDatabaseModule", "()Lorg/koin/core/module/Module;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DatabaseModuleKt {
    private static final java.lang.String DB_NAME = "ics_db";
    private static final org.koin.core.module.Module databaseModule = org.koin.dsl.ModuleDSLKt.module$default(false, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.di.DatabaseModuleKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function1
        public final java.lang.Object invoke(java.lang.Object obj) {
            return uhggroup.iceskating.app.di.DatabaseModuleKt.databaseModule$lambda$0((org.koin.core.module.Module) obj);
        }
    }, 1, null);

    public static final org.koin.core.module.Module getDatabaseModule() {
        return databaseModule;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit databaseModule$lambda$0(org.koin.core.module.Module module) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(module, "$this$module");
        kotlin.jvm.functions.Function2 function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DatabaseModuleKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DatabaseModuleKt.databaseModule$lambda$0$0((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.ICSAppDatabase.class), null, function2, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory2 = singleInstanceFactory;
        module.indexPrimaryType(singleInstanceFactory2);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory2);
        kotlin.jvm.functions.Function2 function22 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DatabaseModuleKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DatabaseModuleKt.databaseModule$lambda$0$1((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory3 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.CartItemDao.class), null, function22, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory4 = singleInstanceFactory3;
        module.indexPrimaryType(singleInstanceFactory4);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory3);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory4);
        kotlin.jvm.functions.Function2 function23 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.di.DatabaseModuleKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function2
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                return uhggroup.iceskating.app.di.DatabaseModuleKt.databaseModule$lambda$0$2((org.koin.core.scope.Scope) obj, (org.koin.core.parameter.ParametersHolder) obj2);
            }
        };
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory5 = new org.koin.core.instance.SingleInstanceFactory<>(new org.koin.core.definition.BeanDefinition(org.koin.core.registry.ScopeRegistry.INSTANCE.getRootScopeQualifier(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.dao.OrderDao.class), null, function23, org.koin.core.definition.Kind.Singleton, kotlin.collections.CollectionsKt.emptyList()));
        org.koin.core.instance.SingleInstanceFactory<?> singleInstanceFactory6 = singleInstanceFactory5;
        module.indexPrimaryType(singleInstanceFactory6);
        if (module.get_createdAtStart()) {
            module.prepareForCreationAtStart(singleInstanceFactory5);
        }
        new org.koin.core.definition.KoinDefinition(module, singleInstanceFactory6);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.database.ICSAppDatabase databaseModule$lambda$0$0(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return (uhggroup.iceskating.app.data.database.ICSAppDatabase) androidx.room.Room.databaseBuilder((android.content.Context) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(android.content.Context.class), null, null), uhggroup.iceskating.app.data.database.ICSAppDatabase.class, DB_NAME).build();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.database.dao.CartItemDao databaseModule$lambda$0$1(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((uhggroup.iceskating.app.data.database.ICSAppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.ICSAppDatabase.class), null, null)).cartItemDao();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final uhggroup.iceskating.app.data.database.dao.OrderDao databaseModule$lambda$0$2(org.koin.core.scope.Scope single, org.koin.core.parameter.ParametersHolder it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(single, "$this$single");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        return ((uhggroup.iceskating.app.data.database.ICSAppDatabase) single.get(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.data.database.ICSAppDatabase.class), null, null)).orderDao();
    }
}
