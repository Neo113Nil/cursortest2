package uhggroup.iceskating.app.di;

/* compiled from: DispatcherModule.kt */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007¨\u0006\f"}, d2 = {"Luhggroup/iceskating/app/di/DispatchersQualifiers;", "", "<init>", "()V", "IO", "Lorg/koin/core/qualifier/StringQualifier;", "getIO", "()Lorg/koin/core/qualifier/StringQualifier;", "Default", "getDefault", "Main", "getMain", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DispatchersQualifiers {
    public static final uhggroup.iceskating.app.di.DispatchersQualifiers INSTANCE = new uhggroup.iceskating.app.di.DispatchersQualifiers();
    private static final org.koin.core.qualifier.StringQualifier IO = org.koin.core.qualifier.QualifierKt.named("IO");
    private static final org.koin.core.qualifier.StringQualifier Default = org.koin.core.qualifier.QualifierKt.named("Default");
    private static final org.koin.core.qualifier.StringQualifier Main = org.koin.core.qualifier.QualifierKt.named("Main");
    public static final int $stable = 8;

    private DispatchersQualifiers() {
    }

    public final org.koin.core.qualifier.StringQualifier getIO() {
        return IO;
    }

    public final org.koin.core.qualifier.StringQualifier getDefault() {
        return Default;
    }

    public final org.koin.core.qualifier.StringQualifier getMain() {
        return Main;
    }
}
