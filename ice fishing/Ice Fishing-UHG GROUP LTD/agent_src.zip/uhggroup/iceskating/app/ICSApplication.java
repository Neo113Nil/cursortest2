package uhggroup.iceskating.app;

/* compiled from: ICSApplication.kt */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ICSApplication;", "Landroid/app/Application;", "<init>", "()V", "onCreate", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public class ICSApplication extends android.app.Application {
    public static final int $stable = 8;

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        final java.util.List listPlus = kotlin.collections.CollectionsKt.plus((java.util.Collection<? extends org.koin.core.module.Module>) uhggroup.iceskating.app.di.DataModuleKt.getDataModule().plus(uhggroup.iceskating.app.di.ViewModuleKt.getViewModule()), uhggroup.iceskating.app.di.DispatcherModuleKt.getDispatcherModule());
        org.koin.core.context.GlobalContext.INSTANCE.startKoin(new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ICSApplication$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ICSApplication.onCreate$lambda$0(this.f$0, listPlus, (org.koin.core.KoinApplication) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit onCreate$lambda$0(uhggroup.iceskating.app.ICSApplication iCSApplication, java.util.List list, org.koin.core.KoinApplication startKoin) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(startKoin, "$this$startKoin");
        org.koin.android.ext.koin.KoinExtKt.androidLogger$default(startKoin, null, 1, null);
        org.koin.android.ext.koin.KoinExtKt.androidContext(startKoin, iCSApplication);
        startKoin.modules((java.util.List<org.koin.core.module.Module>) list);
        return kotlin.Unit.INSTANCE;
    }
}
