package uhggroup.iceskating.app.ui.theme.typography;

/* compiled from: Fonts.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0014\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0010\u001a\u00020\u0011HÖ\u0081\u0004J\n\u0010\u0012\u001a\u00020\u0013HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0014"}, d2 = {"Luhggroup/iceskating/app/ui/theme/typography/Fonts;", "", "body", "Landroidx/compose/ui/text/font/FontFamily;", "display", "<init>", "(Landroidx/compose/ui/text/font/FontFamily;Landroidx/compose/ui/text/font/FontFamily;)V", "getBody", "()Landroidx/compose/ui/text/font/FontFamily;", "getDisplay", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class Fonts {
    public static final int $stable = 0;
    private final androidx.compose.ui.text.font.FontFamily body;
    private final androidx.compose.ui.text.font.FontFamily display;

    public static /* synthetic */ uhggroup.iceskating.app.ui.theme.typography.Fonts copy$default(uhggroup.iceskating.app.ui.theme.typography.Fonts fonts, androidx.compose.ui.text.font.FontFamily fontFamily, androidx.compose.ui.text.font.FontFamily fontFamily2, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            fontFamily = fonts.body;
        }
        if ((i & 2) != 0) {
            fontFamily2 = fonts.display;
        }
        return fonts.copy(fontFamily, fontFamily2);
    }

    /* renamed from: component1, reason: from getter */
    public final androidx.compose.ui.text.font.FontFamily getBody() {
        return this.body;
    }

    /* renamed from: component2, reason: from getter */
    public final androidx.compose.ui.text.font.FontFamily getDisplay() {
        return this.display;
    }

    public final uhggroup.iceskating.app.ui.theme.typography.Fonts copy(androidx.compose.ui.text.font.FontFamily body, androidx.compose.ui.text.font.FontFamily display) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(body, "body");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(display, "display");
        return new uhggroup.iceskating.app.ui.theme.typography.Fonts(body, display);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.ui.theme.typography.Fonts)) {
            return false;
        }
        uhggroup.iceskating.app.ui.theme.typography.Fonts fonts = (uhggroup.iceskating.app.ui.theme.typography.Fonts) other;
        return kotlin.jvm.internal.Intrinsics.areEqual(this.body, fonts.body) && kotlin.jvm.internal.Intrinsics.areEqual(this.display, fonts.display);
    }

    public int hashCode() {
        return (this.body.hashCode() * 31) + this.display.hashCode();
    }

    public java.lang.String toString() {
        return "Fonts(body=" + this.body + ", display=" + this.display + ")";
    }

    public Fonts(androidx.compose.ui.text.font.FontFamily body, androidx.compose.ui.text.font.FontFamily display) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(body, "body");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(display, "display");
        this.body = body;
        this.display = display;
    }

    public final androidx.compose.ui.text.font.FontFamily getBody() {
        return this.body;
    }

    public final androidx.compose.ui.text.font.FontFamily getDisplay() {
        return this.display;
    }
}
