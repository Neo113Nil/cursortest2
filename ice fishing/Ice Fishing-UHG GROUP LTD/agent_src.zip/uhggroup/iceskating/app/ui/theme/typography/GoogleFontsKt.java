package uhggroup.iceskating.app.ui.theme.typography;

/* compiled from: GoogleFonts.kt */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u001a\u000e\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"GoogleFontsProvider", "Landroidx/compose/ui/text/googlefonts/GoogleFont$Provider;", "googleFontFamily", "Landroidx/compose/ui/text/font/FontFamily;", androidx.autofill.HintConstants.AUTOFILL_HINT_NAME, "", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class GoogleFontsKt {
    private static final androidx.compose.ui.text.googlefonts.GoogleFont.Provider GoogleFontsProvider = new androidx.compose.ui.text.googlefonts.GoogleFont.Provider("com.google.android.gms.fonts", "com.google.android.gms", uhggroup.iceskating.app.R.array.com_google_android_gms_fonts_certs);

    public static final androidx.compose.ui.text.font.FontFamily googleFontFamily(java.lang.String name) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(name, "name");
        androidx.compose.ui.text.googlefonts.GoogleFont googleFont = new androidx.compose.ui.text.googlefonts.GoogleFont(name, false, 2, null);
        androidx.compose.ui.text.googlefonts.GoogleFont.Provider provider = GoogleFontsProvider;
        return androidx.compose.ui.text.font.FontFamilyKt.FontFamily(androidx.compose.ui.text.googlefonts.GoogleFontKt.m8457FontwCLgNak$default(googleFont, provider, androidx.compose.ui.text.font.FontWeight.INSTANCE.getNormal(), 0, 8, null), androidx.compose.ui.text.googlefonts.GoogleFontKt.m8457FontwCLgNak$default(googleFont, provider, androidx.compose.ui.text.font.FontWeight.INSTANCE.getMedium(), 0, 8, null), androidx.compose.ui.text.googlefonts.GoogleFontKt.m8457FontwCLgNak$default(googleFont, provider, androidx.compose.ui.text.font.FontWeight.INSTANCE.getSemiBold(), 0, 8, null), androidx.compose.ui.text.googlefonts.GoogleFontKt.m8457FontwCLgNak$default(googleFont, provider, androidx.compose.ui.text.font.FontWeight.INSTANCE.getBold(), 0, 8, null));
    }
}
