package uhggroup.iceskating.app.ui.theme;

/* compiled from: Palette.kt */
@kotlin.Metadata(d1 = {"\u0000'\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0003\b\u0097\u0001\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B§\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0003\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\u0006\u0010\f\u001a\u00020\u0003\u0012\u0006\u0010\r\u001a\u00020\u0003\u0012\u0006\u0010\u000e\u001a\u00020\u0003\u0012\u0006\u0010\u000f\u001a\u00020\u0003\u0012\u0006\u0010\u0010\u001a\u00020\u0003\u0012\u0006\u0010\u0011\u001a\u00020\u0003\u0012\u0006\u0010\u0012\u001a\u00020\u0003\u0012\u0006\u0010\u0013\u001a\u00020\u0003\u0012\u0006\u0010\u0014\u001a\u00020\u0003\u0012\u0006\u0010\u0015\u001a\u00020\u0003\u0012\u0006\u0010\u0016\u001a\u00020\u0003\u0012\u0006\u0010\u0017\u001a\u00020\u0003\u0012\u0006\u0010\u0018\u001a\u00020\u0003\u0012\u0006\u0010\u0019\u001a\u00020\u0003\u0012\u0006\u0010\u001a\u001a\u00020\u0003\u0012\u0006\u0010\u001b\u001a\u00020\u0003\u0012\u0006\u0010\u001c\u001a\u00020\u0003\u0012\u0006\u0010\u001d\u001a\u00020\u0003\u0012\u0006\u0010\u001e\u001a\u00020\u0003\u0012\u0006\u0010\u001f\u001a\u00020\u0003\u0012\u0006\u0010 \u001a\u00020\u0003\u0012\u0006\u0010!\u001a\u00020\u0003\u0012\u0006\u0010\"\u001a\u00020\u0003\u0012\u0006\u0010#\u001a\u00020\u0003\u0012\u0006\u0010$\u001a\u00020\u0003\u0012\u0006\u0010%\u001a\u00020\u0003\u0012\u0006\u0010&\u001a\u00020\u0003¢\u0006\u0004\b'\u0010(J\u0010\u0010O\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bP\u0010*J\u0010\u0010Q\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bR\u0010*J\u0010\u0010S\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bT\u0010*J\u0010\u0010U\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bV\u0010*J\u0010\u0010W\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bX\u0010*J\u0010\u0010Y\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bZ\u0010*J\u0010\u0010[\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b\\\u0010*J\u0010\u0010]\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b^\u0010*J\u0010\u0010_\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b`\u0010*J\u0010\u0010a\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bb\u0010*J\u0010\u0010c\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bd\u0010*J\u0010\u0010e\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bf\u0010*J\u0010\u0010g\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bh\u0010*J\u0010\u0010i\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bj\u0010*J\u0010\u0010k\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bl\u0010*J\u0010\u0010m\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bn\u0010*J\u0010\u0010o\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bp\u0010*J\u0010\u0010q\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\br\u0010*J\u0010\u0010s\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bt\u0010*J\u0010\u0010u\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bv\u0010*J\u0010\u0010w\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bx\u0010*J\u0010\u0010y\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\bz\u0010*J\u0010\u0010{\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b|\u0010*J\u0010\u0010}\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b~\u0010*J\u0011\u0010\u007f\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0080\u0001\u0010*J\u0012\u0010\u0081\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0082\u0001\u0010*J\u0012\u0010\u0083\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0084\u0001\u0010*J\u0012\u0010\u0085\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0086\u0001\u0010*J\u0012\u0010\u0087\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0088\u0001\u0010*J\u0012\u0010\u0089\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u008a\u0001\u0010*J\u0012\u0010\u008b\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u008c\u0001\u0010*J\u0012\u0010\u008d\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u008e\u0001\u0010*J\u0012\u0010\u008f\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0090\u0001\u0010*J\u0012\u0010\u0091\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0092\u0001\u0010*J\u0012\u0010\u0093\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0094\u0001\u0010*J\u0012\u0010\u0095\u0001\u001a\u00020\u0003HÆ\u0003¢\u0006\u0005\b\u0096\u0001\u0010*Jû\u0002\u0010\u0097\u0001\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u00032\b\b\u0002\u0010\u0010\u001a\u00020\u00032\b\b\u0002\u0010\u0011\u001a\u00020\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u00032\b\b\u0002\u0010\u0013\u001a\u00020\u00032\b\b\u0002\u0010\u0014\u001a\u00020\u00032\b\b\u0002\u0010\u0015\u001a\u00020\u00032\b\b\u0002\u0010\u0016\u001a\u00020\u00032\b\b\u0002\u0010\u0017\u001a\u00020\u00032\b\b\u0002\u0010\u0018\u001a\u00020\u00032\b\b\u0002\u0010\u0019\u001a\u00020\u00032\b\b\u0002\u0010\u001a\u001a\u00020\u00032\b\b\u0002\u0010\u001b\u001a\u00020\u00032\b\b\u0002\u0010\u001c\u001a\u00020\u00032\b\b\u0002\u0010\u001d\u001a\u00020\u00032\b\b\u0002\u0010\u001e\u001a\u00020\u00032\b\b\u0002\u0010\u001f\u001a\u00020\u00032\b\b\u0002\u0010 \u001a\u00020\u00032\b\b\u0002\u0010!\u001a\u00020\u00032\b\b\u0002\u0010\"\u001a\u00020\u00032\b\b\u0002\u0010#\u001a\u00020\u00032\b\b\u0002\u0010$\u001a\u00020\u00032\b\b\u0002\u0010%\u001a\u00020\u00032\b\b\u0002\u0010&\u001a\u00020\u0003HÆ\u0001¢\u0006\u0006\b\u0098\u0001\u0010\u0099\u0001J\u0017\u0010\u009a\u0001\u001a\u00030\u009b\u00012\t\u0010\u009c\u0001\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\f\u0010\u009d\u0001\u001a\u00030\u009e\u0001HÖ\u0081\u0004J\f\u0010\u009f\u0001\u001a\u00030 \u0001HÖ\u0081\u0004R\u0013\u0010\u0002\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b)\u0010*R\u0013\u0010\u0004\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b,\u0010*R\u0013\u0010\u0005\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b-\u0010*R\u0013\u0010\u0006\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b.\u0010*R\u0013\u0010\u0007\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b/\u0010*R\u0013\u0010\b\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b0\u0010*R\u0013\u0010\t\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b1\u0010*R\u0013\u0010\n\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b2\u0010*R\u0013\u0010\u000b\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b3\u0010*R\u0013\u0010\f\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b4\u0010*R\u0013\u0010\r\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b5\u0010*R\u0013\u0010\u000e\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b6\u0010*R\u0013\u0010\u000f\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b7\u0010*R\u0013\u0010\u0010\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b8\u0010*R\u0013\u0010\u0011\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b9\u0010*R\u0013\u0010\u0012\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b:\u0010*R\u0013\u0010\u0013\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b;\u0010*R\u0013\u0010\u0014\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b<\u0010*R\u0013\u0010\u0015\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b=\u0010*R\u0013\u0010\u0016\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b>\u0010*R\u0013\u0010\u0017\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b?\u0010*R\u0013\u0010\u0018\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\b@\u0010*R\u0013\u0010\u0019\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bA\u0010*R\u0013\u0010\u001a\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bB\u0010*R\u0013\u0010\u001b\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bC\u0010*R\u0013\u0010\u001c\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bD\u0010*R\u0013\u0010\u001d\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bE\u0010*R\u0013\u0010\u001e\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bF\u0010*R\u0013\u0010\u001f\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bG\u0010*R\u0013\u0010 \u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bH\u0010*R\u0013\u0010!\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bI\u0010*R\u0013\u0010\"\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bJ\u0010*R\u0013\u0010#\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bK\u0010*R\u0013\u0010$\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bL\u0010*R\u0013\u0010%\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bM\u0010*R\u0013\u0010&\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010+\u001a\u0004\bN\u0010*¨\u0006¡\u0001"}, d2 = {"Luhggroup/iceskating/app/ui/theme/Palette;", "", "primary", "Landroidx/compose/ui/graphics/Color;", "onPrimary", "primaryContainer", "onPrimaryContainer", "secondary", "onSecondary", "secondaryContainer", "onSecondaryContainer", "tertiary", "onTertiary", "tertiaryContainer", "onTertiaryContainer", "error", "onError", "errorContainer", "onErrorContainer", "background", "onBackground", "surface", "onSurface", "surfaceVariant", "onSurfaceVariant", "surfaceTint", "surfaceDim", "surfaceBright", "surfaceContainerLowest", "surfaceContainerLow", "surfaceContainer", "surfaceContainerHigh", "surfaceContainerHighest", "outline", "outlineVariant", "inverseSurface", "inverseOnSurface", "inversePrimary", "scrim", "<init>", "(JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getPrimary-0d7_KjU", "()J", "J", "getOnPrimary-0d7_KjU", "getPrimaryContainer-0d7_KjU", "getOnPrimaryContainer-0d7_KjU", "getSecondary-0d7_KjU", "getOnSecondary-0d7_KjU", "getSecondaryContainer-0d7_KjU", "getOnSecondaryContainer-0d7_KjU", "getTertiary-0d7_KjU", "getOnTertiary-0d7_KjU", "getTertiaryContainer-0d7_KjU", "getOnTertiaryContainer-0d7_KjU", "getError-0d7_KjU", "getOnError-0d7_KjU", "getErrorContainer-0d7_KjU", "getOnErrorContainer-0d7_KjU", "getBackground-0d7_KjU", "getOnBackground-0d7_KjU", "getSurface-0d7_KjU", "getOnSurface-0d7_KjU", "getSurfaceVariant-0d7_KjU", "getOnSurfaceVariant-0d7_KjU", "getSurfaceTint-0d7_KjU", "getSurfaceDim-0d7_KjU", "getSurfaceBright-0d7_KjU", "getSurfaceContainerLowest-0d7_KjU", "getSurfaceContainerLow-0d7_KjU", "getSurfaceContainer-0d7_KjU", "getSurfaceContainerHigh-0d7_KjU", "getSurfaceContainerHighest-0d7_KjU", "getOutline-0d7_KjU", "getOutlineVariant-0d7_KjU", "getInverseSurface-0d7_KjU", "getInverseOnSurface-0d7_KjU", "getInversePrimary-0d7_KjU", "getScrim-0d7_KjU", "component1", "component1-0d7_KjU", "component2", "component2-0d7_KjU", "component3", "component3-0d7_KjU", "component4", "component4-0d7_KjU", "component5", "component5-0d7_KjU", "component6", "component6-0d7_KjU", "component7", "component7-0d7_KjU", "component8", "component8-0d7_KjU", "component9", "component9-0d7_KjU", "component10", "component10-0d7_KjU", "component11", "component11-0d7_KjU", "component12", "component12-0d7_KjU", "component13", "component13-0d7_KjU", "component14", "component14-0d7_KjU", "component15", "component15-0d7_KjU", "component16", "component16-0d7_KjU", "component17", "component17-0d7_KjU", "component18", "component18-0d7_KjU", "component19", "component19-0d7_KjU", "component20", "component20-0d7_KjU", "component21", "component21-0d7_KjU", "component22", "component22-0d7_KjU", "component23", "component23-0d7_KjU", "component24", "component24-0d7_KjU", "component25", "component25-0d7_KjU", "component26", "component26-0d7_KjU", "component27", "component27-0d7_KjU", "component28", "component28-0d7_KjU", "component29", "component29-0d7_KjU", "component30", "component30-0d7_KjU", "component31", "component31-0d7_KjU", "component32", "component32-0d7_KjU", "component33", "component33-0d7_KjU", "component34", "component34-0d7_KjU", "component35", "component35-0d7_KjU", "component36", "component36-0d7_KjU", "copy", "copy-C-Xl9yA", "(JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ)Luhggroup/iceskating/app/ui/theme/Palette;", "equals", "", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class Palette {
    public static final int $stable = 0;
    private final long background;
    private final long error;
    private final long errorContainer;
    private final long inverseOnSurface;
    private final long inversePrimary;
    private final long inverseSurface;
    private final long onBackground;
    private final long onError;
    private final long onErrorContainer;
    private final long onPrimary;
    private final long onPrimaryContainer;
    private final long onSecondary;
    private final long onSecondaryContainer;
    private final long onSurface;
    private final long onSurfaceVariant;
    private final long onTertiary;
    private final long onTertiaryContainer;
    private final long outline;
    private final long outlineVariant;
    private final long primary;
    private final long primaryContainer;
    private final long scrim;
    private final long secondary;
    private final long secondaryContainer;
    private final long surface;
    private final long surfaceBright;
    private final long surfaceContainer;
    private final long surfaceContainerHigh;
    private final long surfaceContainerHighest;
    private final long surfaceContainerLow;
    private final long surfaceContainerLowest;
    private final long surfaceDim;
    private final long surfaceTint;
    private final long surfaceVariant;
    private final long tertiary;
    private final long tertiaryContainer;

    public /* synthetic */ Palette(long j, long j2, long j3, long j4, long j5, long j6, long j7, long j8, long j9, long j10, long j11, long j12, long j13, long j14, long j15, long j16, long j17, long j18, long j19, long j20, long j21, long j22, long j23, long j24, long j25, long j26, long j27, long j28, long j29, long j30, long j31, long j32, long j33, long j34, long j35, long j36, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this(j, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12, j13, j14, j15, j16, j17, j18, j19, j20, j21, j22, j23, j24, j25, j26, j27, j28, j29, j30, j31, j32, j33, j34, j35, j36);
    }

    /* renamed from: copy-C-Xl9yA$default, reason: not valid java name */
    public static /* synthetic */ uhggroup.iceskating.app.ui.theme.Palette m11518copyCXl9yA$default(uhggroup.iceskating.app.ui.theme.Palette palette, long j, long j2, long j3, long j4, long j5, long j6, long j7, long j8, long j9, long j10, long j11, long j12, long j13, long j14, long j15, long j16, long j17, long j18, long j19, long j20, long j21, long j22, long j23, long j24, long j25, long j26, long j27, long j28, long j29, long j30, long j31, long j32, long j33, long j34, long j35, long j36, int i, int i2, java.lang.Object obj) {
        long j37;
        long j38;
        long j39;
        long j40;
        long j41;
        long j42;
        long j43;
        long j44;
        long j45;
        long j46;
        long j47;
        long j48;
        long j49;
        long j50;
        long j51;
        long j52;
        long j53;
        long j54;
        long j55;
        long j56;
        long j57;
        long j58;
        long j59;
        long j60;
        long j61;
        long j62;
        long j63;
        long j64;
        long j65;
        long j66;
        uhggroup.iceskating.app.ui.theme.Palette palette2;
        long j67;
        long j68;
        long j69;
        long j70;
        long j71;
        long j72 = (i & 1) != 0 ? palette.primary : j;
        long j73 = (i & 2) != 0 ? palette.onPrimary : j2;
        long j74 = (i & 4) != 0 ? palette.primaryContainer : j3;
        long j75 = (i & 8) != 0 ? palette.onPrimaryContainer : j4;
        long j76 = (i & 16) != 0 ? palette.secondary : j5;
        long j77 = (i & 32) != 0 ? palette.onSecondary : j6;
        long j78 = (i & 64) != 0 ? palette.secondaryContainer : j7;
        long j79 = j72;
        long j80 = (i & 128) != 0 ? palette.onSecondaryContainer : j8;
        long j81 = (i & 256) != 0 ? palette.tertiary : j9;
        long j82 = (i & 512) != 0 ? palette.onTertiary : j10;
        long j83 = (i & 1024) != 0 ? palette.tertiaryContainer : j11;
        long j84 = (i & 2048) != 0 ? palette.onTertiaryContainer : j12;
        long j85 = (i & 4096) != 0 ? palette.error : j13;
        long j86 = (i & 8192) != 0 ? palette.onError : j14;
        long j87 = (i & 16384) != 0 ? palette.errorContainer : j15;
        long j88 = (i & 32768) != 0 ? palette.onErrorContainer : j16;
        long j89 = (i & 65536) != 0 ? palette.background : j17;
        long j90 = (i & 131072) != 0 ? palette.onBackground : j18;
        long j91 = (i & 262144) != 0 ? palette.surface : j19;
        long j92 = (i & 524288) != 0 ? palette.onSurface : j20;
        long j93 = (i & 1048576) != 0 ? palette.surfaceVariant : j21;
        long j94 = (i & 2097152) != 0 ? palette.onSurfaceVariant : j22;
        long j95 = (i & 4194304) != 0 ? palette.surfaceTint : j23;
        long j96 = (i & 8388608) != 0 ? palette.surfaceDim : j24;
        long j97 = (i & 16777216) != 0 ? palette.surfaceBright : j25;
        long j98 = (i & androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasAuxSlotFlag) != 0 ? palette.surfaceContainerLowest : j26;
        long j99 = (i & 67108864) != 0 ? palette.surfaceContainerLow : j27;
        long j100 = (i & androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasRecompositionRequiredFlag) != 0 ? palette.surfaceContainer : j28;
        long j101 = (i & androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.IsMovableContentFlag) != 0 ? palette.surfaceContainerHigh : j29;
        long j102 = (i & androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasMovableContentFlag) != 0 ? palette.surfaceContainerHighest : j30;
        long j103 = (i & androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.IsSubcompositionContextFlag) != 0 ? palette.outline : j31;
        long j104 = (i & Integer.MIN_VALUE) != 0 ? palette.outlineVariant : j32;
        long j105 = (i2 & 1) != 0 ? palette.inverseSurface : j33;
        long j106 = (i2 & 2) != 0 ? palette.inverseOnSurface : j34;
        long j107 = (i2 & 4) != 0 ? palette.inversePrimary : j35;
        if ((i2 & 8) != 0) {
            j38 = j107;
            j37 = palette.scrim;
            j40 = j101;
            j41 = j102;
            j42 = j103;
            j43 = j104;
            j44 = j105;
            j45 = j106;
            j47 = j94;
            j48 = j95;
            j49 = j96;
            j50 = j97;
            j51 = j98;
            j52 = j99;
            j39 = j100;
            j54 = j87;
            j55 = j88;
            j56 = j89;
            j57 = j90;
            j58 = j91;
            j59 = j92;
            j46 = j93;
            j61 = j80;
            j62 = j81;
            j63 = j82;
            j64 = j83;
            j65 = j84;
            j66 = j85;
            j53 = j86;
            palette2 = palette;
            j67 = j73;
            j68 = j74;
            j69 = j75;
            j70 = j76;
            j71 = j77;
            j60 = j78;
        } else {
            j37 = j36;
            j38 = j107;
            j39 = j100;
            j40 = j101;
            j41 = j102;
            j42 = j103;
            j43 = j104;
            j44 = j105;
            j45 = j106;
            j46 = j93;
            j47 = j94;
            j48 = j95;
            j49 = j96;
            j50 = j97;
            j51 = j98;
            j52 = j99;
            j53 = j86;
            j54 = j87;
            j55 = j88;
            j56 = j89;
            j57 = j90;
            j58 = j91;
            j59 = j92;
            j60 = j78;
            j61 = j80;
            j62 = j81;
            j63 = j82;
            j64 = j83;
            j65 = j84;
            j66 = j85;
            palette2 = palette;
            j67 = j73;
            j68 = j74;
            j69 = j75;
            j70 = j76;
            j71 = j77;
        }
        return palette2.m11555copyCXl9yA(j79, j67, j68, j69, j70, j71, j60, j61, j62, j63, j64, j65, j66, j53, j54, j55, j56, j57, j58, j59, j46, j47, j48, j49, j50, j51, j52, j39, j40, j41, j42, j43, j44, j45, j38, j37);
    }

    /* renamed from: component1-0d7_KjU, reason: not valid java name and from getter */
    public final long getPrimary() {
        return this.primary;
    }

    /* renamed from: component10-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnTertiary() {
        return this.onTertiary;
    }

    /* renamed from: component11-0d7_KjU, reason: not valid java name and from getter */
    public final long getTertiaryContainer() {
        return this.tertiaryContainer;
    }

    /* renamed from: component12-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnTertiaryContainer() {
        return this.onTertiaryContainer;
    }

    /* renamed from: component13-0d7_KjU, reason: not valid java name and from getter */
    public final long getError() {
        return this.error;
    }

    /* renamed from: component14-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnError() {
        return this.onError;
    }

    /* renamed from: component15-0d7_KjU, reason: not valid java name and from getter */
    public final long getErrorContainer() {
        return this.errorContainer;
    }

    /* renamed from: component16-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnErrorContainer() {
        return this.onErrorContainer;
    }

    /* renamed from: component17-0d7_KjU, reason: not valid java name and from getter */
    public final long getBackground() {
        return this.background;
    }

    /* renamed from: component18-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnBackground() {
        return this.onBackground;
    }

    /* renamed from: component19-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurface() {
        return this.surface;
    }

    /* renamed from: component2-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnPrimary() {
        return this.onPrimary;
    }

    /* renamed from: component20-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnSurface() {
        return this.onSurface;
    }

    /* renamed from: component21-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceVariant() {
        return this.surfaceVariant;
    }

    /* renamed from: component22-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnSurfaceVariant() {
        return this.onSurfaceVariant;
    }

    /* renamed from: component23-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceTint() {
        return this.surfaceTint;
    }

    /* renamed from: component24-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceDim() {
        return this.surfaceDim;
    }

    /* renamed from: component25-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceBright() {
        return this.surfaceBright;
    }

    /* renamed from: component26-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceContainerLowest() {
        return this.surfaceContainerLowest;
    }

    /* renamed from: component27-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceContainerLow() {
        return this.surfaceContainerLow;
    }

    /* renamed from: component28-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceContainer() {
        return this.surfaceContainer;
    }

    /* renamed from: component29-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceContainerHigh() {
        return this.surfaceContainerHigh;
    }

    /* renamed from: component3-0d7_KjU, reason: not valid java name and from getter */
    public final long getPrimaryContainer() {
        return this.primaryContainer;
    }

    /* renamed from: component30-0d7_KjU, reason: not valid java name and from getter */
    public final long getSurfaceContainerHighest() {
        return this.surfaceContainerHighest;
    }

    /* renamed from: component31-0d7_KjU, reason: not valid java name and from getter */
    public final long getOutline() {
        return this.outline;
    }

    /* renamed from: component32-0d7_KjU, reason: not valid java name and from getter */
    public final long getOutlineVariant() {
        return this.outlineVariant;
    }

    /* renamed from: component33-0d7_KjU, reason: not valid java name and from getter */
    public final long getInverseSurface() {
        return this.inverseSurface;
    }

    /* renamed from: component34-0d7_KjU, reason: not valid java name and from getter */
    public final long getInverseOnSurface() {
        return this.inverseOnSurface;
    }

    /* renamed from: component35-0d7_KjU, reason: not valid java name and from getter */
    public final long getInversePrimary() {
        return this.inversePrimary;
    }

    /* renamed from: component36-0d7_KjU, reason: not valid java name and from getter */
    public final long getScrim() {
        return this.scrim;
    }

    /* renamed from: component4-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnPrimaryContainer() {
        return this.onPrimaryContainer;
    }

    /* renamed from: component5-0d7_KjU, reason: not valid java name and from getter */
    public final long getSecondary() {
        return this.secondary;
    }

    /* renamed from: component6-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnSecondary() {
        return this.onSecondary;
    }

    /* renamed from: component7-0d7_KjU, reason: not valid java name and from getter */
    public final long getSecondaryContainer() {
        return this.secondaryContainer;
    }

    /* renamed from: component8-0d7_KjU, reason: not valid java name and from getter */
    public final long getOnSecondaryContainer() {
        return this.onSecondaryContainer;
    }

    /* renamed from: component9-0d7_KjU, reason: not valid java name and from getter */
    public final long getTertiary() {
        return this.tertiary;
    }

    /* renamed from: copy-C-Xl9yA, reason: not valid java name */
    public final uhggroup.iceskating.app.ui.theme.Palette m11555copyCXl9yA(long primary, long onPrimary, long primaryContainer, long onPrimaryContainer, long secondary, long onSecondary, long secondaryContainer, long onSecondaryContainer, long tertiary, long onTertiary, long tertiaryContainer, long onTertiaryContainer, long error, long onError, long errorContainer, long onErrorContainer, long background, long onBackground, long surface, long onSurface, long surfaceVariant, long onSurfaceVariant, long surfaceTint, long surfaceDim, long surfaceBright, long surfaceContainerLowest, long surfaceContainerLow, long surfaceContainer, long surfaceContainerHigh, long surfaceContainerHighest, long outline, long outlineVariant, long inverseSurface, long inverseOnSurface, long inversePrimary, long scrim) {
        return new uhggroup.iceskating.app.ui.theme.Palette(primary, onPrimary, primaryContainer, onPrimaryContainer, secondary, onSecondary, secondaryContainer, onSecondaryContainer, tertiary, onTertiary, tertiaryContainer, onTertiaryContainer, error, onError, errorContainer, onErrorContainer, background, onBackground, surface, onSurface, surfaceVariant, onSurfaceVariant, surfaceTint, surfaceDim, surfaceBright, surfaceContainerLowest, surfaceContainerLow, surfaceContainer, surfaceContainerHigh, surfaceContainerHighest, outline, outlineVariant, inverseSurface, inverseOnSurface, inversePrimary, scrim, null);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.ui.theme.Palette)) {
            return false;
        }
        uhggroup.iceskating.app.ui.theme.Palette palette = (uhggroup.iceskating.app.ui.theme.Palette) other;
        return androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.primary, palette.primary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onPrimary, palette.onPrimary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.primaryContainer, palette.primaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onPrimaryContainer, palette.onPrimaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.secondary, palette.secondary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onSecondary, palette.onSecondary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.secondaryContainer, palette.secondaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onSecondaryContainer, palette.onSecondaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.tertiary, palette.tertiary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onTertiary, palette.onTertiary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.tertiaryContainer, palette.tertiaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onTertiaryContainer, palette.onTertiaryContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.error, palette.error) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onError, palette.onError) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.errorContainer, palette.errorContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onErrorContainer, palette.onErrorContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.background, palette.background) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onBackground, palette.onBackground) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surface, palette.surface) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onSurface, palette.onSurface) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceVariant, palette.surfaceVariant) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.onSurfaceVariant, palette.onSurfaceVariant) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceTint, palette.surfaceTint) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceDim, palette.surfaceDim) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceBright, palette.surfaceBright) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceContainerLowest, palette.surfaceContainerLowest) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceContainerLow, palette.surfaceContainerLow) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceContainer, palette.surfaceContainer) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceContainerHigh, palette.surfaceContainerHigh) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.surfaceContainerHighest, palette.surfaceContainerHighest) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.outline, palette.outline) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.outlineVariant, palette.outlineVariant) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.inverseSurface, palette.inverseSurface) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.inverseOnSurface, palette.inverseOnSurface) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.inversePrimary, palette.inversePrimary) && androidx.compose.ui.graphics.Color.m5983equalsimpl0(this.scrim, palette.scrim);
    }

    public int hashCode() {
        return (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.primary) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onPrimary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.primaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onPrimaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.secondary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onSecondary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.secondaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onSecondaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.tertiary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onTertiary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.tertiaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onTertiaryContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.error)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onError)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.errorContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onErrorContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.background)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onBackground)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surface)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onSurface)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceVariant)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.onSurfaceVariant)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceTint)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceDim)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceBright)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceContainerLowest)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceContainerLow)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceContainer)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceContainerHigh)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.surfaceContainerHighest)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.outline)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.outlineVariant)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.inverseSurface)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.inverseOnSurface)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.inversePrimary)) * 31) + androidx.compose.ui.graphics.Color.m5989hashCodeimpl(this.scrim);
    }

    public java.lang.String toString() {
        return "Palette(primary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.primary) + ", onPrimary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onPrimary) + ", primaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.primaryContainer) + ", onPrimaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onPrimaryContainer) + ", secondary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.secondary) + ", onSecondary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onSecondary) + ", secondaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.secondaryContainer) + ", onSecondaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onSecondaryContainer) + ", tertiary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.tertiary) + ", onTertiary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onTertiary) + ", tertiaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.tertiaryContainer) + ", onTertiaryContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onTertiaryContainer) + ", error=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.error) + ", onError=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onError) + ", errorContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.errorContainer) + ", onErrorContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onErrorContainer) + ", background=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.background) + ", onBackground=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onBackground) + ", surface=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surface) + ", onSurface=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onSurface) + ", surfaceVariant=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceVariant) + ", onSurfaceVariant=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.onSurfaceVariant) + ", surfaceTint=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceTint) + ", surfaceDim=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceDim) + ", surfaceBright=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceBright) + ", surfaceContainerLowest=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceContainerLowest) + ", surfaceContainerLow=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceContainerLow) + ", surfaceContainer=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceContainer) + ", surfaceContainerHigh=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceContainerHigh) + ", surfaceContainerHighest=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.surfaceContainerHighest) + ", outline=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.outline) + ", outlineVariant=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.outlineVariant) + ", inverseSurface=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.inverseSurface) + ", inverseOnSurface=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.inverseOnSurface) + ", inversePrimary=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.inversePrimary) + ", scrim=" + androidx.compose.ui.graphics.Color.m5990toStringimpl(this.scrim) + ")";
    }

    private Palette(long j, long j2, long j3, long j4, long j5, long j6, long j7, long j8, long j9, long j10, long j11, long j12, long j13, long j14, long j15, long j16, long j17, long j18, long j19, long j20, long j21, long j22, long j23, long j24, long j25, long j26, long j27, long j28, long j29, long j30, long j31, long j32, long j33, long j34, long j35, long j36) {
        this.primary = j;
        this.onPrimary = j2;
        this.primaryContainer = j3;
        this.onPrimaryContainer = j4;
        this.secondary = j5;
        this.onSecondary = j6;
        this.secondaryContainer = j7;
        this.onSecondaryContainer = j8;
        this.tertiary = j9;
        this.onTertiary = j10;
        this.tertiaryContainer = j11;
        this.onTertiaryContainer = j12;
        this.error = j13;
        this.onError = j14;
        this.errorContainer = j15;
        this.onErrorContainer = j16;
        this.background = j17;
        this.onBackground = j18;
        this.surface = j19;
        this.onSurface = j20;
        this.surfaceVariant = j21;
        this.onSurfaceVariant = j22;
        this.surfaceTint = j23;
        this.surfaceDim = j24;
        this.surfaceBright = j25;
        this.surfaceContainerLowest = j26;
        this.surfaceContainerLow = j27;
        this.surfaceContainer = j28;
        this.surfaceContainerHigh = j29;
        this.surfaceContainerHighest = j30;
        this.outline = j31;
        this.outlineVariant = j32;
        this.inverseSurface = j33;
        this.inverseOnSurface = j34;
        this.inversePrimary = j35;
        this.scrim = j36;
    }

    /* renamed from: getPrimary-0d7_KjU, reason: not valid java name */
    public final long m11575getPrimary0d7_KjU() {
        return this.primary;
    }

    /* renamed from: getOnPrimary-0d7_KjU, reason: not valid java name */
    public final long m11565getOnPrimary0d7_KjU() {
        return this.onPrimary;
    }

    /* renamed from: getPrimaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11576getPrimaryContainer0d7_KjU() {
        return this.primaryContainer;
    }

    /* renamed from: getOnPrimaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11566getOnPrimaryContainer0d7_KjU() {
        return this.onPrimaryContainer;
    }

    /* renamed from: getSecondary-0d7_KjU, reason: not valid java name */
    public final long m11578getSecondary0d7_KjU() {
        return this.secondary;
    }

    /* renamed from: getOnSecondary-0d7_KjU, reason: not valid java name */
    public final long m11567getOnSecondary0d7_KjU() {
        return this.onSecondary;
    }

    /* renamed from: getSecondaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11579getSecondaryContainer0d7_KjU() {
        return this.secondaryContainer;
    }

    /* renamed from: getOnSecondaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11568getOnSecondaryContainer0d7_KjU() {
        return this.onSecondaryContainer;
    }

    /* renamed from: getTertiary-0d7_KjU, reason: not valid java name */
    public final long m11590getTertiary0d7_KjU() {
        return this.tertiary;
    }

    /* renamed from: getOnTertiary-0d7_KjU, reason: not valid java name */
    public final long m11571getOnTertiary0d7_KjU() {
        return this.onTertiary;
    }

    /* renamed from: getTertiaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11591getTertiaryContainer0d7_KjU() {
        return this.tertiaryContainer;
    }

    /* renamed from: getOnTertiaryContainer-0d7_KjU, reason: not valid java name */
    public final long m11572getOnTertiaryContainer0d7_KjU() {
        return this.onTertiaryContainer;
    }

    /* renamed from: getError-0d7_KjU, reason: not valid java name */
    public final long m11557getError0d7_KjU() {
        return this.error;
    }

    /* renamed from: getOnError-0d7_KjU, reason: not valid java name */
    public final long m11563getOnError0d7_KjU() {
        return this.onError;
    }

    /* renamed from: getErrorContainer-0d7_KjU, reason: not valid java name */
    public final long m11558getErrorContainer0d7_KjU() {
        return this.errorContainer;
    }

    /* renamed from: getOnErrorContainer-0d7_KjU, reason: not valid java name */
    public final long m11564getOnErrorContainer0d7_KjU() {
        return this.onErrorContainer;
    }

    /* renamed from: getBackground-0d7_KjU, reason: not valid java name */
    public final long m11556getBackground0d7_KjU() {
        return this.background;
    }

    /* renamed from: getOnBackground-0d7_KjU, reason: not valid java name */
    public final long m11562getOnBackground0d7_KjU() {
        return this.onBackground;
    }

    /* renamed from: getSurface-0d7_KjU, reason: not valid java name */
    public final long m11580getSurface0d7_KjU() {
        return this.surface;
    }

    /* renamed from: getOnSurface-0d7_KjU, reason: not valid java name */
    public final long m11569getOnSurface0d7_KjU() {
        return this.onSurface;
    }

    /* renamed from: getSurfaceVariant-0d7_KjU, reason: not valid java name */
    public final long m11589getSurfaceVariant0d7_KjU() {
        return this.surfaceVariant;
    }

    /* renamed from: getOnSurfaceVariant-0d7_KjU, reason: not valid java name */
    public final long m11570getOnSurfaceVariant0d7_KjU() {
        return this.onSurfaceVariant;
    }

    /* renamed from: getSurfaceTint-0d7_KjU, reason: not valid java name */
    public final long m11588getSurfaceTint0d7_KjU() {
        return this.surfaceTint;
    }

    /* renamed from: getSurfaceDim-0d7_KjU, reason: not valid java name */
    public final long m11587getSurfaceDim0d7_KjU() {
        return this.surfaceDim;
    }

    /* renamed from: getSurfaceBright-0d7_KjU, reason: not valid java name */
    public final long m11581getSurfaceBright0d7_KjU() {
        return this.surfaceBright;
    }

    /* renamed from: getSurfaceContainerLowest-0d7_KjU, reason: not valid java name */
    public final long m11586getSurfaceContainerLowest0d7_KjU() {
        return this.surfaceContainerLowest;
    }

    /* renamed from: getSurfaceContainerLow-0d7_KjU, reason: not valid java name */
    public final long m11585getSurfaceContainerLow0d7_KjU() {
        return this.surfaceContainerLow;
    }

    /* renamed from: getSurfaceContainer-0d7_KjU, reason: not valid java name */
    public final long m11582getSurfaceContainer0d7_KjU() {
        return this.surfaceContainer;
    }

    /* renamed from: getSurfaceContainerHigh-0d7_KjU, reason: not valid java name */
    public final long m11583getSurfaceContainerHigh0d7_KjU() {
        return this.surfaceContainerHigh;
    }

    /* renamed from: getSurfaceContainerHighest-0d7_KjU, reason: not valid java name */
    public final long m11584getSurfaceContainerHighest0d7_KjU() {
        return this.surfaceContainerHighest;
    }

    /* renamed from: getOutline-0d7_KjU, reason: not valid java name */
    public final long m11573getOutline0d7_KjU() {
        return this.outline;
    }

    /* renamed from: getOutlineVariant-0d7_KjU, reason: not valid java name */
    public final long m11574getOutlineVariant0d7_KjU() {
        return this.outlineVariant;
    }

    /* renamed from: getInverseSurface-0d7_KjU, reason: not valid java name */
    public final long m11561getInverseSurface0d7_KjU() {
        return this.inverseSurface;
    }

    /* renamed from: getInverseOnSurface-0d7_KjU, reason: not valid java name */
    public final long m11559getInverseOnSurface0d7_KjU() {
        return this.inverseOnSurface;
    }

    /* renamed from: getInversePrimary-0d7_KjU, reason: not valid java name */
    public final long m11560getInversePrimary0d7_KjU() {
        return this.inversePrimary;
    }

    /* renamed from: getScrim-0d7_KjU, reason: not valid java name */
    public final long m11577getScrim0d7_KjU() {
        return this.scrim;
    }
}
