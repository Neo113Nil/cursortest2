package uhggroup.iceskating.app.ui.theme.typography;

/* compiled from: AppFonts.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"AppFonts", "Luhggroup/iceskating/app/ui/theme/typography/Fonts;", "getAppFonts", "()Luhggroup/iceskating/app/ui/theme/typography/Fonts;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppFontsKt {
    private static final uhggroup.iceskating.app.ui.theme.typography.Fonts AppFonts = new uhggroup.iceskating.app.ui.theme.typography.Fonts(uhggroup.iceskating.app.ui.theme.typography.GoogleFontsKt.googleFontFamily("Nunito Sans"), uhggroup.iceskating.app.ui.theme.typography.GoogleFontsKt.googleFontFamily("Rubik"));

    public static final uhggroup.iceskating.app.ui.theme.typography.Fonts getAppFonts() {
        return AppFonts;
    }
}
