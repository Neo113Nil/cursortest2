package uhggroup.iceskating.app.ui.theme;

/* compiled from: Theme.kt */
@kotlin.Metadata(d1 = {"\u0000,\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a \u0010\t\u001a\u00020\n2\u0011\u0010\u000b\u001a\r\u0012\u0004\u0012\u00020\n0\f¢\u0006\u0002\b\rH\u0007¢\u0006\u0002\u0010\u000e\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"LightColorScheme", "Landroidx/compose/material3/ColorScheme;", "LocalDimens", "Landroidx/compose/runtime/ProvidableCompositionLocal;", "Luhggroup/iceskating/app/ui/theme/dimens/Dimens;", "getLocalDimens", "()Landroidx/compose/runtime/ProvidableCompositionLocal;", "AppTypography", "Landroidx/compose/material3/Typography;", "ICSAppTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ThemeKt {
    private static final androidx.compose.material3.Typography AppTypography;
    private static final androidx.compose.material3.ColorScheme LightColorScheme;
    private static final androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> LocalDimens;

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSAppTheme$lambda$1(kotlin.jvm.functions.Function2 function2, int i, androidx.compose.runtime.Composer composer, int i2) {
        ICSAppTheme(function2, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    static {
        long jM11575getPrimary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11575getPrimary0d7_KjU();
        long jM11565getOnPrimary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11565getOnPrimary0d7_KjU();
        long jM11576getPrimaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11576getPrimaryContainer0d7_KjU();
        long jM11566getOnPrimaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11566getOnPrimaryContainer0d7_KjU();
        long jM11578getSecondary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11578getSecondary0d7_KjU();
        long jM11567getOnSecondary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11567getOnSecondary0d7_KjU();
        long jM11579getSecondaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11579getSecondaryContainer0d7_KjU();
        long jM11568getOnSecondaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11568getOnSecondaryContainer0d7_KjU();
        long jM11590getTertiary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11590getTertiary0d7_KjU();
        long jM11571getOnTertiary0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11571getOnTertiary0d7_KjU();
        long jM11591getTertiaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11591getTertiaryContainer0d7_KjU();
        long jM11572getOnTertiaryContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11572getOnTertiaryContainer0d7_KjU();
        long jM11557getError0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11557getError0d7_KjU();
        long jM11563getOnError0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11563getOnError0d7_KjU();
        long jM11558getErrorContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11558getErrorContainer0d7_KjU();
        long jM11564getOnErrorContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11564getOnErrorContainer0d7_KjU();
        long jM11556getBackground0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11556getBackground0d7_KjU();
        long jM11562getOnBackground0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11562getOnBackground0d7_KjU();
        long jM11580getSurface0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11580getSurface0d7_KjU();
        long jM11569getOnSurface0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11569getOnSurface0d7_KjU();
        long jM11589getSurfaceVariant0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11589getSurfaceVariant0d7_KjU();
        long jM11570getOnSurfaceVariant0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11570getOnSurfaceVariant0d7_KjU();
        long jM11588getSurfaceTint0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11588getSurfaceTint0d7_KjU();
        long jM11587getSurfaceDim0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11587getSurfaceDim0d7_KjU();
        long jM11581getSurfaceBright0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11581getSurfaceBright0d7_KjU();
        long jM11586getSurfaceContainerLowest0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11586getSurfaceContainerLowest0d7_KjU();
        long jM11585getSurfaceContainerLow0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11585getSurfaceContainerLow0d7_KjU();
        long jM11582getSurfaceContainer0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11582getSurfaceContainer0d7_KjU();
        long jM11583getSurfaceContainerHigh0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11583getSurfaceContainerHigh0d7_KjU();
        long jM11584getSurfaceContainerHighest0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11584getSurfaceContainerHighest0d7_KjU();
        long jM11573getOutline0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11573getOutline0d7_KjU();
        long jM11574getOutlineVariant0d7_KjU = uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11574getOutlineVariant0d7_KjU();
        LightColorScheme = androidx.compose.material3.ColorSchemeKt.m2690lightColorScheme_VG5OTI$default(jM11575getPrimary0d7_KjU, jM11565getOnPrimary0d7_KjU, jM11576getPrimaryContainer0d7_KjU, jM11566getOnPrimaryContainer0d7_KjU, uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11560getInversePrimary0d7_KjU(), jM11578getSecondary0d7_KjU, jM11567getOnSecondary0d7_KjU, jM11579getSecondaryContainer0d7_KjU, jM11568getOnSecondaryContainer0d7_KjU, jM11590getTertiary0d7_KjU, jM11571getOnTertiary0d7_KjU, jM11591getTertiaryContainer0d7_KjU, jM11572getOnTertiaryContainer0d7_KjU, jM11556getBackground0d7_KjU, jM11562getOnBackground0d7_KjU, jM11580getSurface0d7_KjU, jM11569getOnSurface0d7_KjU, jM11589getSurfaceVariant0d7_KjU, jM11570getOnSurfaceVariant0d7_KjU, jM11588getSurfaceTint0d7_KjU, uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11561getInverseSurface0d7_KjU(), uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11559getInverseOnSurface0d7_KjU(), jM11557getError0d7_KjU, jM11563getOnError0d7_KjU, jM11558getErrorContainer0d7_KjU, jM11564getOnErrorContainer0d7_KjU, jM11573getOutline0d7_KjU, jM11574getOutlineVariant0d7_KjU, uhggroup.iceskating.app.ui.theme.AppPaletteKt.getAppPalette().m11577getScrim0d7_KjU(), jM11581getSurfaceBright0d7_KjU, jM11582getSurfaceContainer0d7_KjU, jM11583getSurfaceContainerHigh0d7_KjU, jM11584getSurfaceContainerHighest0d7_KjU, jM11585getSurfaceContainerLow0d7_KjU, jM11586getSurfaceContainerLowest0d7_KjU, jM11587getSurfaceDim0d7_KjU, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0, 65520, null);
        LocalDimens = androidx.compose.runtime.CompositionLocalKt.staticCompositionLocalOf(new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.theme.ThemeKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.theme.dimens.AppDimensKt.getAppDimens();
            }
        });
        AppTypography = uhggroup.iceskating.app.ui.theme.typography.AppTypographyKt.appTypography(uhggroup.iceskating.app.ui.theme.typography.AppFontsKt.getAppFonts());
    }

    public static final androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> getLocalDimens() {
        return LocalDimens;
    }

    public static final void ICSAppTheme(final kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> content, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(content, "content");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(305655204);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSAppTheme)N(content)73@2510L154,73@2453L211:Theme.kt#6merkr");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changedInstance(content) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(305655204, i2, -1, "uhggroup.iceskating.app.ui.theme.ICSAppTheme (Theme.kt:72)");
            }
            androidx.compose.runtime.CompositionLocalKt.CompositionLocalProvider(LocalDimens.provides(uhggroup.iceskating.app.ui.theme.dimens.AppDimensKt.getAppDimens()), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(2101457508, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.theme.ThemeKt.ICSAppTheme$lambda$0(content, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, androidx.compose.runtime.ProvidedValue.$stable | 48);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.ThemeKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.theme.ThemeKt.ICSAppTheme$lambda$1(content, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSAppTheme$lambda$0(kotlin.jvm.functions.Function2 function2, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C74@2520L138:Theme.kt#6merkr");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(2101457508, i, -1, "uhggroup.iceskating.app.ui.theme.ICSAppTheme.<anonymous> (Theme.kt:74)");
            }
            androidx.compose.material3.MaterialThemeKt.MaterialTheme(LightColorScheme, null, AppTypography, function2, composer, 390, 2);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
