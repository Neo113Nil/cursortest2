package uhggroup.iceskating.app.ui.theme.dimens;

/* compiled from: Dimens.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b7\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001Bg\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0003\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\u0006\u0010\f\u001a\u00020\u0003\u0012\u0006\u0010\r\u001a\u00020\u0003\u0012\u0006\u0010\u000e\u001a\u00020\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\u0010\u0010\u001f\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b \u0010\u0012J\u0010\u0010!\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b\"\u0010\u0012J\u0010\u0010#\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b$\u0010\u0012J\u0010\u0010%\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b&\u0010\u0012J\u0010\u0010'\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b(\u0010\u0012J\u0010\u0010)\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b*\u0010\u0012J\u0010\u0010+\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b,\u0010\u0012J\u0010\u0010-\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b.\u0010\u0012J\u0010\u0010/\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b0\u0010\u0012J\u0010\u00101\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b2\u0010\u0012J\u0010\u00103\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b4\u0010\u0012J\u0010\u00105\u001a\u00020\u0003HÆ\u0003¢\u0006\u0004\b6\u0010\u0012J\u0088\u0001\u00107\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u0003HÆ\u0001¢\u0006\u0004\b8\u00109J\u0014\u0010:\u001a\u00020;2\b\u0010<\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010=\u001a\u00020>HÖ\u0081\u0004J\n\u0010?\u001a\u00020@HÖ\u0081\u0004R\u0013\u0010\u0002\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0011\u0010\u0012R\u0013\u0010\u0004\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0014\u0010\u0012R\u0013\u0010\u0005\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0015\u0010\u0012R\u0013\u0010\u0006\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0016\u0010\u0012R\u0013\u0010\u0007\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0017\u0010\u0012R\u0013\u0010\b\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0018\u0010\u0012R\u0013\u0010\t\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0019\u0010\u0012R\u0013\u0010\n\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u001a\u0010\u0012R\u0013\u0010\u000b\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u001b\u0010\u0012R\u0013\u0010\f\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u001c\u0010\u0012R\u0013\u0010\r\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u001d\u0010\u0012R\u0013\u0010\u000e\u001a\u00020\u0003¢\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u001e\u0010\u0012¨\u0006A"}, d2 = {"Luhggroup/iceskating/app/ui/theme/dimens/Dimens;", "", "screenPadding", "Landroidx/compose/ui/unit/Dp;", "sectionGap", "contentSpacing", "cardPadding", "itemSpacing", "tightSpacing", "cardCornerRadius", "cornerRadius", "controlCornerRadius", "cardBorderWidth", "imageBorderWidth", "controlBorderWidth", "<init>", "(FFFFFFFFFFFFLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getScreenPadding-D9Ej5fM", "()F", "F", "getSectionGap-D9Ej5fM", "getContentSpacing-D9Ej5fM", "getCardPadding-D9Ej5fM", "getItemSpacing-D9Ej5fM", "getTightSpacing-D9Ej5fM", "getCardCornerRadius-D9Ej5fM", "getCornerRadius-D9Ej5fM", "getControlCornerRadius-D9Ej5fM", "getCardBorderWidth-D9Ej5fM", "getImageBorderWidth-D9Ej5fM", "getControlBorderWidth-D9Ej5fM", "component1", "component1-D9Ej5fM", "component2", "component2-D9Ej5fM", "component3", "component3-D9Ej5fM", "component4", "component4-D9Ej5fM", "component5", "component5-D9Ej5fM", "component6", "component6-D9Ej5fM", "component7", "component7-D9Ej5fM", "component8", "component8-D9Ej5fM", "component9", "component9-D9Ej5fM", "component10", "component10-D9Ej5fM", "component11", "component11-D9Ej5fM", "component12", "component12-D9Ej5fM", "copy", "copy-CaHt2TY", "(FFFFFFFFFFFF)Luhggroup/iceskating/app/ui/theme/dimens/Dimens;", "equals", "", "other", "hashCode", "", "toString", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class Dimens {
    public static final int $stable = 0;
    private final float cardBorderWidth;
    private final float cardCornerRadius;
    private final float cardPadding;
    private final float contentSpacing;
    private final float controlBorderWidth;
    private final float controlCornerRadius;
    private final float cornerRadius;
    private final float imageBorderWidth;
    private final float itemSpacing;
    private final float screenPadding;
    private final float sectionGap;
    private final float tightSpacing;

    public /* synthetic */ Dimens(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this(f, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12);
    }

    /* renamed from: copy-CaHt2TY$default, reason: not valid java name */
    public static /* synthetic */ uhggroup.iceskating.app.ui.theme.dimens.Dimens m11597copyCaHt2TY$default(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, int i, java.lang.Object obj) {
        if ((i & 1) != 0) {
            f = dimens.screenPadding;
        }
        if ((i & 2) != 0) {
            f2 = dimens.sectionGap;
        }
        if ((i & 4) != 0) {
            f3 = dimens.contentSpacing;
        }
        if ((i & 8) != 0) {
            f4 = dimens.cardPadding;
        }
        if ((i & 16) != 0) {
            f5 = dimens.itemSpacing;
        }
        if ((i & 32) != 0) {
            f6 = dimens.tightSpacing;
        }
        if ((i & 64) != 0) {
            f7 = dimens.cardCornerRadius;
        }
        if ((i & 128) != 0) {
            f8 = dimens.cornerRadius;
        }
        if ((i & 256) != 0) {
            f9 = dimens.controlCornerRadius;
        }
        if ((i & 512) != 0) {
            f10 = dimens.cardBorderWidth;
        }
        if ((i & 1024) != 0) {
            f11 = dimens.imageBorderWidth;
        }
        if ((i & 2048) != 0) {
            f12 = dimens.controlBorderWidth;
        }
        float f13 = f11;
        float f14 = f12;
        float f15 = f9;
        float f16 = f10;
        float f17 = f7;
        float f18 = f8;
        float f19 = f5;
        float f20 = f6;
        return dimens.m11610copyCaHt2TY(f, f2, f3, f4, f19, f20, f17, f18, f15, f16, f13, f14);
    }

    /* renamed from: component1-D9Ej5fM, reason: not valid java name and from getter */
    public final float getScreenPadding() {
        return this.screenPadding;
    }

    /* renamed from: component10-D9Ej5fM, reason: not valid java name and from getter */
    public final float getCardBorderWidth() {
        return this.cardBorderWidth;
    }

    /* renamed from: component11-D9Ej5fM, reason: not valid java name and from getter */
    public final float getImageBorderWidth() {
        return this.imageBorderWidth;
    }

    /* renamed from: component12-D9Ej5fM, reason: not valid java name and from getter */
    public final float getControlBorderWidth() {
        return this.controlBorderWidth;
    }

    /* renamed from: component2-D9Ej5fM, reason: not valid java name and from getter */
    public final float getSectionGap() {
        return this.sectionGap;
    }

    /* renamed from: component3-D9Ej5fM, reason: not valid java name and from getter */
    public final float getContentSpacing() {
        return this.contentSpacing;
    }

    /* renamed from: component4-D9Ej5fM, reason: not valid java name and from getter */
    public final float getCardPadding() {
        return this.cardPadding;
    }

    /* renamed from: component5-D9Ej5fM, reason: not valid java name and from getter */
    public final float getItemSpacing() {
        return this.itemSpacing;
    }

    /* renamed from: component6-D9Ej5fM, reason: not valid java name and from getter */
    public final float getTightSpacing() {
        return this.tightSpacing;
    }

    /* renamed from: component7-D9Ej5fM, reason: not valid java name and from getter */
    public final float getCardCornerRadius() {
        return this.cardCornerRadius;
    }

    /* renamed from: component8-D9Ej5fM, reason: not valid java name and from getter */
    public final float getCornerRadius() {
        return this.cornerRadius;
    }

    /* renamed from: component9-D9Ej5fM, reason: not valid java name and from getter */
    public final float getControlCornerRadius() {
        return this.controlCornerRadius;
    }

    /* renamed from: copy-CaHt2TY, reason: not valid java name */
    public final uhggroup.iceskating.app.ui.theme.dimens.Dimens m11610copyCaHt2TY(float screenPadding, float sectionGap, float contentSpacing, float cardPadding, float itemSpacing, float tightSpacing, float cardCornerRadius, float cornerRadius, float controlCornerRadius, float cardBorderWidth, float imageBorderWidth, float controlBorderWidth) {
        return new uhggroup.iceskating.app.ui.theme.dimens.Dimens(screenPadding, sectionGap, contentSpacing, cardPadding, itemSpacing, tightSpacing, cardCornerRadius, cornerRadius, controlCornerRadius, cardBorderWidth, imageBorderWidth, controlBorderWidth, null);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.ui.theme.dimens.Dimens)) {
            return false;
        }
        uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) other;
        return androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.screenPadding, dimens.screenPadding) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.sectionGap, dimens.sectionGap) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.contentSpacing, dimens.contentSpacing) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.cardPadding, dimens.cardPadding) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.itemSpacing, dimens.itemSpacing) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.tightSpacing, dimens.tightSpacing) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.cardCornerRadius, dimens.cardCornerRadius) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.cornerRadius, dimens.cornerRadius) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.controlCornerRadius, dimens.controlCornerRadius) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.cardBorderWidth, dimens.cardBorderWidth) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.imageBorderWidth, dimens.imageBorderWidth) && androidx.compose.ui.unit.Dp.m8856equalsimpl0(this.controlBorderWidth, dimens.controlBorderWidth);
    }

    public int hashCode() {
        return (((((((((((((((((((((androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.screenPadding) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.sectionGap)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.contentSpacing)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.cardPadding)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.itemSpacing)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.tightSpacing)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.cardCornerRadius)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.cornerRadius)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.controlCornerRadius)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.cardBorderWidth)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.imageBorderWidth)) * 31) + androidx.compose.ui.unit.Dp.m8857hashCodeimpl(this.controlBorderWidth);
    }

    public java.lang.String toString() {
        return "Dimens(screenPadding=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.screenPadding) + ", sectionGap=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.sectionGap) + ", contentSpacing=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.contentSpacing) + ", cardPadding=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.cardPadding) + ", itemSpacing=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.itemSpacing) + ", tightSpacing=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.tightSpacing) + ", cardCornerRadius=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.cardCornerRadius) + ", cornerRadius=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.cornerRadius) + ", controlCornerRadius=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.controlCornerRadius) + ", cardBorderWidth=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.cardBorderWidth) + ", imageBorderWidth=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.imageBorderWidth) + ", controlBorderWidth=" + androidx.compose.ui.unit.Dp.m8862toStringimpl(this.controlBorderWidth) + ")";
    }

    private Dimens(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12) {
        this.screenPadding = f;
        this.sectionGap = f2;
        this.contentSpacing = f3;
        this.cardPadding = f4;
        this.itemSpacing = f5;
        this.tightSpacing = f6;
        this.cardCornerRadius = f7;
        this.cornerRadius = f8;
        this.controlCornerRadius = f9;
        this.cardBorderWidth = f10;
        this.imageBorderWidth = f11;
        this.controlBorderWidth = f12;
    }

    /* renamed from: getScreenPadding-D9Ej5fM, reason: not valid java name */
    public final float m11620getScreenPaddingD9Ej5fM() {
        return this.screenPadding;
    }

    /* renamed from: getSectionGap-D9Ej5fM, reason: not valid java name */
    public final float m11621getSectionGapD9Ej5fM() {
        return this.sectionGap;
    }

    /* renamed from: getContentSpacing-D9Ej5fM, reason: not valid java name */
    public final float m11614getContentSpacingD9Ej5fM() {
        return this.contentSpacing;
    }

    /* renamed from: getCardPadding-D9Ej5fM, reason: not valid java name */
    public final float m11613getCardPaddingD9Ej5fM() {
        return this.cardPadding;
    }

    /* renamed from: getItemSpacing-D9Ej5fM, reason: not valid java name */
    public final float m11619getItemSpacingD9Ej5fM() {
        return this.itemSpacing;
    }

    /* renamed from: getTightSpacing-D9Ej5fM, reason: not valid java name */
    public final float m11622getTightSpacingD9Ej5fM() {
        return this.tightSpacing;
    }

    /* renamed from: getCardCornerRadius-D9Ej5fM, reason: not valid java name */
    public final float m11612getCardCornerRadiusD9Ej5fM() {
        return this.cardCornerRadius;
    }

    /* renamed from: getCornerRadius-D9Ej5fM, reason: not valid java name */
    public final float m11617getCornerRadiusD9Ej5fM() {
        return this.cornerRadius;
    }

    /* renamed from: getControlCornerRadius-D9Ej5fM, reason: not valid java name */
    public final float m11616getControlCornerRadiusD9Ej5fM() {
        return this.controlCornerRadius;
    }

    /* renamed from: getCardBorderWidth-D9Ej5fM, reason: not valid java name */
    public final float m11611getCardBorderWidthD9Ej5fM() {
        return this.cardBorderWidth;
    }

    /* renamed from: getImageBorderWidth-D9Ej5fM, reason: not valid java name */
    public final float m11618getImageBorderWidthD9Ej5fM() {
        return this.imageBorderWidth;
    }

    /* renamed from: getControlBorderWidth-D9Ej5fM, reason: not valid java name */
    public final float m11615getControlBorderWidthD9Ej5fM() {
        return this.controlBorderWidth;
    }
}
