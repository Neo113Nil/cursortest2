package uhggroup.iceskating.app.ui.theme;

/* compiled from: SystemBars.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\u0011\u0010\u0002\u001a\u00020\u0003*\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006\u001a\u0017\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\n\u0010\u000b\u001a\u000e\u0010\f\u001a\u0004\u0018\u00010\r*\u00020\u000eH\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"LightBackgroundLuminance", "", "isLight", "", "Landroidx/compose/ui/graphics/Color;", "isLight-8_81llA", "(J)Z", "StatusBarIconsFor", "", "backgroundColor", "StatusBarIconsFor-ek8zF_U", "(JLandroidx/compose/runtime/Composer;I)V", "findActivity", "Landroid/app/Activity;", "Landroid/content/Context;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class SystemBarsKt {
    private static final float LightBackgroundLuminance = 0.5f;

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit StatusBarIconsFor_ek8zF_U$lambda$0(long j, int i, androidx.compose.runtime.Composer composer, int i2) {
        m11593StatusBarIconsForek8zF_U(j, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit StatusBarIconsFor_ek8zF_U$lambda$1(long j, int i, androidx.compose.runtime.Composer composer, int i2) {
        m11593StatusBarIconsForek8zF_U(j, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit StatusBarIconsFor_ek8zF_U$lambda$3(long j, int i, androidx.compose.runtime.Composer composer, int i2) {
        m11593StatusBarIconsForek8zF_U(j, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    /* renamed from: isLight-8_81llA, reason: not valid java name */
    public static final boolean m11594isLight8_81llA(long j) {
        return androidx.compose.ui.graphics.ColorKt.m6034luminance8_81llA(j) > 0.5f;
    }

    /* renamed from: StatusBarIconsFor-ek8zF_U, reason: not valid java name */
    public static final void m11593StatusBarIconsForek8zF_U(final long j, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> function2;
        final android.view.Window window;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(973636331);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(StatusBarIconsFor)N(backgroundColor:c#ui.graphics.Color)18@606L7,24@777L105,24@766L116:SystemBars.kt#6merkr");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changed(j) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(973636331, i2, -1, "uhggroup.iceskating.app.ui.theme.StatusBarIconsFor (SystemBars.kt:17)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<android.view.View> localView = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalView();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localView);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final android.view.View view = (android.view.View) objConsume;
            if (!view.isInEditMode()) {
                android.content.Context context = view.getContext();
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
                android.app.Activity activityFindActivity = findActivity(context);
                if (activityFindActivity == null || (window = activityFindActivity.getWindow()) == null) {
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup == null) {
                        return;
                    } else {
                        function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.SystemBarsKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function2
                            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                                return uhggroup.iceskating.app.ui.theme.SystemBarsKt.StatusBarIconsFor_ek8zF_U$lambda$1(j, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                            }
                        };
                    }
                } else {
                    final boolean zM11594isLight8_81llA = m11594isLight8_81llA(j);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -638348524, "CC(remember):SystemBars.kt#9igjgp");
                    boolean zChangedInstance = composerStartRestartGroup.changedInstance(window) | composerStartRestartGroup.changedInstance(view) | composerStartRestartGroup.changed(zM11594isLight8_81llA);
                    java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.theme.SystemBarsKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                return uhggroup.iceskating.app.ui.theme.SystemBarsKt.StatusBarIconsFor_ek8zF_U$lambda$2$0(window, view, zM11594isLight8_81llA);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.EffectsKt.SideEffect((kotlin.jvm.functions.Function0) objRememberedValue, composerStartRestartGroup, 0);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                }
            } else {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
                if (scopeUpdateScopeEndRestartGroup == null) {
                    return;
                } else {
                    function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.SystemBarsKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                            return uhggroup.iceskating.app.ui.theme.SystemBarsKt.StatusBarIconsFor_ek8zF_U$lambda$0(j, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                        }
                    };
                }
            }
            scopeUpdateScopeEndRestartGroup.updateScope(function2);
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            function2 = new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.SystemBarsKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.theme.SystemBarsKt.StatusBarIconsFor_ek8zF_U$lambda$3(j, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            };
            scopeUpdateScopeEndRestartGroup.updateScope(function2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit StatusBarIconsFor_ek8zF_U$lambda$2$0(android.view.Window window, android.view.View view, boolean z) {
        androidx.core.view.WindowCompat.getInsetsController(window, view).setAppearanceLightStatusBars(z);
        return kotlin.Unit.INSTANCE;
    }

    private static final android.app.Activity findActivity(android.content.Context context) {
        while (context instanceof android.content.ContextWrapper) {
            if (context instanceof android.app.Activity) {
                return (android.app.Activity) context;
            }
            context = ((android.content.ContextWrapper) context).getBaseContext();
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(context, "getBaseContext(...)");
        }
        return null;
    }
}
