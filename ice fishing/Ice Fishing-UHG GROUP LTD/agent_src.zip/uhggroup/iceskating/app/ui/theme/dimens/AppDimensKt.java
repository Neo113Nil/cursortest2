package uhggroup.iceskating.app.ui.theme.dimens;

/* compiled from: AppDimens.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"AppDimens", "Luhggroup/iceskating/app/ui/theme/dimens/Dimens;", "getAppDimens", "()Luhggroup/iceskating/app/ui/theme/dimens/Dimens;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppDimensKt {
    private static final uhggroup.iceskating.app.ui.theme.dimens.Dimens AppDimens;

    static {
        float f = 16;
        float f2 = 12;
        float f3 = 1;
        AppDimens = new uhggroup.iceskating.app.ui.theme.dimens.Dimens(androidx.compose.ui.unit.Dp.m8851constructorimpl(24), androidx.compose.ui.unit.Dp.m8851constructorimpl(40), androidx.compose.ui.unit.Dp.m8851constructorimpl(f), androidx.compose.ui.unit.Dp.m8851constructorimpl(20), androidx.compose.ui.unit.Dp.m8851constructorimpl(f2), androidx.compose.ui.unit.Dp.m8851constructorimpl(6), androidx.compose.ui.unit.Dp.m8851constructorimpl(f), androidx.compose.ui.unit.Dp.m8851constructorimpl(f2), androidx.compose.ui.unit.Dp.m8851constructorimpl(f2), androidx.compose.ui.unit.Dp.m8851constructorimpl(f3), androidx.compose.ui.unit.Dp.m8851constructorimpl(0), androidx.compose.ui.unit.Dp.m8851constructorimpl(f3), null);
    }

    public static final uhggroup.iceskating.app.ui.theme.dimens.Dimens getAppDimens() {
        return AppDimens;
    }
}
