package uhggroup.iceskating.app.ui.theme;

/* compiled from: Borders.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\u001a\u001b\u0010\u0000\u001a\u0004\u0018\u00010\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0004\b\u0004\u0010\u0005\u001a\u001b\u0010\u0006\u001a\u0004\u0018\u00010\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0004\b\u0007\u0010\u0005\u001a\u0019\u0010\b\u001a\u00020\t*\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007¢\u0006\u0002\u0010\f\u001a#\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\t2\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"cardBorderStroke", "Landroidx/compose/foundation/BorderStroke;", "color", "Landroidx/compose/ui/graphics/Color;", "cardBorderStroke-Iv8Zu3U", "(JLandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/BorderStroke;", "controlBorderStroke", "controlBorderStroke-Iv8Zu3U", "imageBorder", "Landroidx/compose/ui/Modifier;", "shape", "Landroidx/compose/ui/graphics/Shape;", "(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/Modifier;", "ControlDivider", "", "modifier", "ControlDivider-iJQMabo", "(Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class BordersKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ControlDivider_iJQMabo$lambda$0(androidx.compose.ui.Modifier modifier, long j, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        m11515ControlDivideriJQMabo(modifier, j, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* renamed from: cardBorderStroke-Iv8Zu3U, reason: not valid java name */
    public static final androidx.compose.foundation.BorderStroke m11516cardBorderStrokeIv8Zu3U(long j, androidx.compose.runtime.Composer composer, int i, int i2) {
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1778091021, "C(cardBorderStroke)N(color:c#ui.graphics.Color)14@498L11,16@573L7:Borders.kt#6merkr");
        if ((i2 & 1) != 0) {
            j = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOutlineVariant();
        }
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(1778091021, i, -1, "uhggroup.iceskating.app.ui.theme.cardBorderStroke (Borders.kt:15)");
        }
        androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
        java.lang.Object objConsume = composer.consume(localDimens);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        float fM11611getCardBorderWidthD9Ej5fM = ((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11611getCardBorderWidthD9Ej5fM();
        androidx.compose.foundation.BorderStroke borderStrokeM359BorderStrokecXLIe8U = androidx.compose.ui.unit.Dp.m8850compareTo0680j_4(fM11611getCardBorderWidthD9Ej5fM, androidx.compose.ui.unit.Dp.m8851constructorimpl((float) 0)) > 0 ? androidx.compose.foundation.BorderStrokeKt.m359BorderStrokecXLIe8U(fM11611getCardBorderWidthD9Ej5fM, j) : null;
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        return borderStrokeM359BorderStrokecXLIe8U;
    }

    /* renamed from: controlBorderStroke-Iv8Zu3U, reason: not valid java name */
    public static final androidx.compose.foundation.BorderStroke m11517controlBorderStrokeIv8Zu3U(long j, androidx.compose.runtime.Composer composer, int i, int i2) {
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1974658562, "C(controlBorderStroke)N(color:c#ui.graphics.Color)26@768L11,28@843L7:Borders.kt#6merkr");
        if ((i2 & 1) != 0) {
            j = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOutlineVariant();
        }
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-1974658562, i, -1, "uhggroup.iceskating.app.ui.theme.controlBorderStroke (Borders.kt:27)");
        }
        androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
        java.lang.Object objConsume = composer.consume(localDimens);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        float fM11615getControlBorderWidthD9Ej5fM = ((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11615getControlBorderWidthD9Ej5fM();
        androidx.compose.foundation.BorderStroke borderStrokeM359BorderStrokecXLIe8U = androidx.compose.ui.unit.Dp.m8850compareTo0680j_4(fM11615getControlBorderWidthD9Ej5fM, androidx.compose.ui.unit.Dp.m8851constructorimpl((float) 0)) > 0 ? androidx.compose.foundation.BorderStrokeKt.m359BorderStrokecXLIe8U(fM11615getControlBorderWidthD9Ej5fM, j) : null;
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        return borderStrokeM359BorderStrokecXLIe8U;
    }

    public static final androidx.compose.ui.Modifier imageBorder(androidx.compose.ui.Modifier modifier, androidx.compose.ui.graphics.Shape shape, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(modifier, "<this>");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(shape, "shape");
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 346808724, "C(imageBorder)N(shape)34@1030L7:Borders.kt#6merkr");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(346808724, i, -1, "uhggroup.iceskating.app.ui.theme.imageBorder (Borders.kt:33)");
        }
        androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
        java.lang.Object objConsume = composer.consume(localDimens);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        float fM11618getImageBorderWidthD9Ej5fM = ((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11618getImageBorderWidthD9Ej5fM();
        if (androidx.compose.ui.unit.Dp.m8850compareTo0680j_4(fM11618getImageBorderWidthD9Ej5fM, androidx.compose.ui.unit.Dp.m8851constructorimpl(0)) > 0) {
            composer.startReplaceGroup(-1912483136);
            androidx.compose.runtime.ComposerKt.sourceInformation(composer, "36@1122L11");
            modifier = androidx.compose.foundation.BorderKt.m341borderxT4_qwU(modifier, fM11618getImageBorderWidthD9Ej5fM, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOutlineVariant(), shape);
            composer.endReplaceGroup();
        } else {
            composer.startReplaceGroup(-1912401606);
            composer.endReplaceGroup();
        }
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        return modifier;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00e8  */
    /* renamed from: ControlDivider-iJQMabo, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void m11515ControlDivideriJQMabo(androidx.compose.ui.Modifier modifier, long j, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        final androidx.compose.ui.Modifier modifier2;
        final long j2;
        androidx.compose.ui.Modifier.Companion companion;
        int i4;
        long outlineVariant;
        float fM11615getControlBorderWidthD9Ej5fM;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1349383548);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ControlDivider)N(modifier,color:c#ui.graphics.Color)47@1352L7:Borders.kt#6merkr");
        int i5 = i2 & 1;
        if (i5 != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = i | (composerStartRestartGroup.changed(modifier) ? 4 : 2);
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= ((i2 & 2) == 0 && composerStartRestartGroup.changed(j)) ? 32 : 16;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "45@1292L11");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier;
            } else {
                companion = i5 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier;
                if ((i2 & 2) != 0) {
                    i4 = i3 & (-113);
                    outlineVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOutlineVariant();
                }
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1349383548, i4, -1, "uhggroup.iceskating.app.ui.theme.ControlDivider (Borders.kt:46)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                fM11615getControlBorderWidthD9Ej5fM = ((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11615getControlBorderWidthD9Ej5fM();
                if (androidx.compose.ui.unit.Dp.m8850compareTo0680j_4(fM11615getControlBorderWidthD9Ej5fM, androidx.compose.ui.unit.Dp.m8851constructorimpl(0)) <= 0) {
                    composerStartRestartGroup.startReplaceGroup(-1408412481);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "49@1411L119");
                    androidx.compose.material3.DividerKt.m2864HorizontalDivider9IZ8Weo(companion, fM11615getControlBorderWidthD9Ej5fM, outlineVariant, composerStartRestartGroup, (i4 & 14) | ((i4 << 3) & 896), 0);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-1408282746);
                    composerStartRestartGroup.endReplaceGroup();
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier2 = companion;
                j2 = outlineVariant;
            }
            i4 = i3;
            outlineVariant = j;
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens2 = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume2 = composerStartRestartGroup.consume(localDimens2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            fM11615getControlBorderWidthD9Ej5fM = ((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume2).m11615getControlBorderWidthD9Ej5fM();
            if (androidx.compose.ui.unit.Dp.m8850compareTo0680j_4(fM11615getControlBorderWidthD9Ej5fM, androidx.compose.ui.unit.Dp.m8851constructorimpl(0)) <= 0) {
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            modifier2 = companion;
            j2 = outlineVariant;
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            modifier2 = modifier;
            j2 = j;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.theme.BordersKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.theme.BordersKt.ControlDivider_iJQMabo$lambda$0(modifier2, j2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }
}
