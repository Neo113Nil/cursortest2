package uhggroup.iceskating.app.ui.state;

/* compiled from: CartItemUiState.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J;\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u0005HÆ\u0001J\u0014\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u001d\u001a\u00020\u0003HÖ\u0081\u0004J\n\u0010\u001e\u001a\u00020\u0005HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000f¨\u0006\u001f"}, d2 = {"Luhggroup/iceskating/app/ui/state/CartItemUiState;", "", "productId", "", "productTitle", "", "productPrice", "", "quantity", "productImageUrl", "<init>", "(ILjava/lang/String;DILjava/lang/String;)V", "getProductId", "()I", "getProductTitle", "()Ljava/lang/String;", "getProductPrice", "()D", "getQuantity", "getProductImageUrl", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class CartItemUiState {
    public static final int $stable = 0;
    private final int productId;
    private final java.lang.String productImageUrl;
    private final double productPrice;
    private final java.lang.String productTitle;
    private final int quantity;

    public static /* synthetic */ uhggroup.iceskating.app.ui.state.CartItemUiState copy$default(uhggroup.iceskating.app.ui.state.CartItemUiState cartItemUiState, int i, java.lang.String str, double d, int i2, java.lang.String str2, int i3, java.lang.Object obj) {
        if ((i3 & 1) != 0) {
            i = cartItemUiState.productId;
        }
        if ((i3 & 2) != 0) {
            str = cartItemUiState.productTitle;
        }
        if ((i3 & 4) != 0) {
            d = cartItemUiState.productPrice;
        }
        if ((i3 & 8) != 0) {
            i2 = cartItemUiState.quantity;
        }
        if ((i3 & 16) != 0) {
            str2 = cartItemUiState.productImageUrl;
        }
        double d2 = d;
        return cartItemUiState.copy(i, str, d2, i2, str2);
    }

    /* renamed from: component1, reason: from getter */
    public final int getProductId() {
        return this.productId;
    }

    /* renamed from: component2, reason: from getter */
    public final java.lang.String getProductTitle() {
        return this.productTitle;
    }

    /* renamed from: component3, reason: from getter */
    public final double getProductPrice() {
        return this.productPrice;
    }

    /* renamed from: component4, reason: from getter */
    public final int getQuantity() {
        return this.quantity;
    }

    /* renamed from: component5, reason: from getter */
    public final java.lang.String getProductImageUrl() {
        return this.productImageUrl;
    }

    public final uhggroup.iceskating.app.ui.state.CartItemUiState copy(int productId, java.lang.String productTitle, double productPrice, int quantity, java.lang.String productImageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productTitle, "productTitle");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productImageUrl, "productImageUrl");
        return new uhggroup.iceskating.app.ui.state.CartItemUiState(productId, productTitle, productPrice, quantity, productImageUrl);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.ui.state.CartItemUiState)) {
            return false;
        }
        uhggroup.iceskating.app.ui.state.CartItemUiState cartItemUiState = (uhggroup.iceskating.app.ui.state.CartItemUiState) other;
        return this.productId == cartItemUiState.productId && kotlin.jvm.internal.Intrinsics.areEqual(this.productTitle, cartItemUiState.productTitle) && java.lang.Double.compare(this.productPrice, cartItemUiState.productPrice) == 0 && this.quantity == cartItemUiState.quantity && kotlin.jvm.internal.Intrinsics.areEqual(this.productImageUrl, cartItemUiState.productImageUrl);
    }

    public int hashCode() {
        return (((((((java.lang.Integer.hashCode(this.productId) * 31) + this.productTitle.hashCode()) * 31) + java.lang.Double.hashCode(this.productPrice)) * 31) + java.lang.Integer.hashCode(this.quantity)) * 31) + this.productImageUrl.hashCode();
    }

    public java.lang.String toString() {
        return "CartItemUiState(productId=" + this.productId + ", productTitle=" + this.productTitle + ", productPrice=" + this.productPrice + ", quantity=" + this.quantity + ", productImageUrl=" + this.productImageUrl + ")";
    }

    public CartItemUiState(int i, java.lang.String productTitle, double d, int i2, java.lang.String productImageUrl) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productTitle, "productTitle");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productImageUrl, "productImageUrl");
        this.productId = i;
        this.productTitle = productTitle;
        this.productPrice = d;
        this.quantity = i2;
        this.productImageUrl = productImageUrl;
    }

    public final int getProductId() {
        return this.productId;
    }

    public final java.lang.String getProductTitle() {
        return this.productTitle;
    }

    public final double getProductPrice() {
        return this.productPrice;
    }

    public final int getQuantity() {
        return this.quantity;
    }

    public final java.lang.String getProductImageUrl() {
        return this.productImageUrl;
    }
}
