package uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar;

/* compiled from: AddToCartSnackbarState.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0010\u001a\u00020\u0011R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R+\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00078F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\f\u0010\r\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Luhggroup/iceskating/app/ui/composable/screen/productdetails/snackbar/AddToCartSnackbarState;", "", "scope", "Lkotlinx/coroutines/CoroutineScope;", "<init>", "(Lkotlinx/coroutines/CoroutineScope;)V", "<set-?>", "", "isVisible", "()Z", "setVisible", "(Z)V", "isVisible$delegate", "Landroidx/compose/runtime/MutableState;", "hideJob", "Lkotlinx/coroutines/Job;", "show", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AddToCartSnackbarState {
    public static final int $stable = 0;
    private kotlinx.coroutines.Job hideJob;

    /* renamed from: isVisible$delegate, reason: from kotlin metadata */
    private final androidx.compose.runtime.MutableState isVisible;
    private final kotlinx.coroutines.CoroutineScope scope;

    public AddToCartSnackbarState(kotlinx.coroutines.CoroutineScope scope) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(scope, "scope");
        this.scope = scope;
        this.isVisible = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setVisible(boolean z) {
        this.isVisible.setValue(java.lang.Boolean.valueOf(z));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean isVisible() {
        return ((java.lang.Boolean) this.isVisible.getValue()).booleanValue();
    }

    /* compiled from: AddToCartSnackbarState.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState$show$1", f = "AddToCartSnackbarState.kt", i = {}, l = {29}, m = "invokeSuspend", n = {}, nl = {30}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState$show$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.this.setVisible(true);
                this.label = 1;
                if (kotlinx.coroutines.DelayKt.delay(2500L, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.this.setVisible(false);
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void show() {
        kotlinx.coroutines.Job job = this.hideJob;
        if (job != null) {
            kotlinx.coroutines.Job.DefaultImpls.cancel$default(job, (java.util.concurrent.CancellationException) null, 1, (java.lang.Object) null);
        }
        this.hideJob = kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(this.scope, null, null, new uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState.AnonymousClass1(null), 3, null);
    }
}
