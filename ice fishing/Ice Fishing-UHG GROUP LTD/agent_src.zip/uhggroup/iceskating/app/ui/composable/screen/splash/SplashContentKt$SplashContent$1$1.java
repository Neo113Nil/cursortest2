package uhggroup.iceskating.app.ui.composable.screen.splash;

/* compiled from: SplashContent.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1", f = "SplashContent.kt", i = {0, 1}, l = {51, 52}, m = "invokeSuspend", n = {"$this$LaunchedEffect", "$this$LaunchedEffect"}, nl = {52, 53}, s = {"L$0", "L$0"}, v = 2)
/* loaded from: classes3.dex */
final class SplashContentKt$SplashContent$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoAlpha;
    final /* synthetic */ kotlin.jvm.functions.Function0<kotlin.Unit> $onAnimationFinished;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $scale;
    final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $titleAlpha;
    private /* synthetic */ java.lang.Object L$0;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    SplashContentKt$SplashContent$1$1(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable2, kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable3, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1> continuation) {
        super(2, continuation);
        this.$scale = animatable;
        this.$titleAlpha = animatable2;
        this.$onAnimationFinished = function0;
        this.$logoAlpha = animatable3;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1 splashContentKt$SplashContent$1$1 = new uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1(this.$scale, this.$titleAlpha, this.$onAnimationFinished, this.$logoAlpha, continuation);
        splashContentKt$SplashContent$1$1.L$0 = obj;
        return splashContentKt$SplashContent$1$1;
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    /* compiled from: SplashContent.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1$1", f = "SplashContent.kt", i = {}, l = {49}, m = "invokeSuspend", n = {}, nl = {50}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> $logoAlpha;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(androidx.compose.animation.core.Animatable<java.lang.Float, androidx.compose.animation.core.AnimationVector1D> animatable, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1.AnonymousClass1> continuation) {
            super(2, continuation);
            this.$logoAlpha = animatable;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return new uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1.AnonymousClass1(this.$logoAlpha, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (androidx.compose.animation.core.Animatable.animateTo$default(this.$logoAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(androidx.window.core.layout.WindowSizeClass.WIDTH_DP_EXTRA_LARGE_LOWER_BOUND, 0, null, 6, null), null, null, this, 12, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0091, code lost:
    
        if (androidx.compose.animation.core.Animatable.animateTo$default(r22.$titleAlpha, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(900, 0, null, 6, null), null, null, r22, 12, null) == r1) goto L15;
     */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) this.L$0;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt$SplashContent$1$1.AnonymousClass1(this.$logoAlpha, null), 3, null);
            this.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(coroutineScope);
            this.label = 1;
            if (androidx.compose.animation.core.Animatable.animateTo$default(this.$scale, kotlin.coroutines.jvm.internal.Boxing.boxFloat(1.0f), androidx.compose.animation.core.AnimationSpecKt.tween$default(androidx.window.core.layout.WindowSizeClass.WIDTH_DP_EXTRA_LARGE_LOWER_BOUND, 0, null, 6, null), null, null, this, 12, null) != coroutine_suspended) {
            }
            return coroutine_suspended;
        }
        if (i != 1) {
            if (i != 2) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(obj);
            this.$onAnimationFinished.invoke();
            return kotlin.Unit.INSTANCE;
        }
        kotlin.ResultKt.throwOnFailure(obj);
        this.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(coroutineScope);
        this.label = 2;
    }
}
