package uhggroup.iceskating.app.ui.composable.screen.order;

/* compiled from: ICSOrderScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ICSOrderScreenKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$515512510 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(515512510, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt.lambda_515512510$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$515512510$app_release() {
        return lambda$515512510;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_515512510$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C71@2700L56,70@2648L182:ICSOrderScreen.kt#gr4iox");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(515512510, i, -1, "uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt.lambda$515512510.<anonymous> (ICSOrderScreen.kt:70)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt.DataEmptyContent(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.orders_state_empty_primary_text, composer, 0), null, null, null, composer, 6, 28);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
