package uhggroup.iceskating.app.ui.composable.approot;

/* compiled from: ClearCartDialog.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ClearCartDialogKt {
    public static final uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt INSTANCE = new uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt();

    /* renamed from: lambda$-28583769, reason: not valid java name */
    private static kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f53lambda$28583769 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-28583769, false, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
            return uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda__28583769$lambda$0((androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
        }
    });

    /* renamed from: lambda$-2068034150, reason: not valid java name */
    private static kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f52lambda$2068034150 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-2068034150, false, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
            return uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda__2068034150$lambda$0((androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
        }
    });
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1773677493 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1773677493, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda_1773677493$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1112088020 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1112088020, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda_1112088020$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-2068034150$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11450getLambda$2068034150$app_release() {
        return f52lambda$2068034150;
    }

    /* renamed from: getLambda$-28583769$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11451getLambda$28583769$app_release() {
        return f53lambda$28583769;
    }

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1112088020$app_release() {
        return lambda$1112088020;
    }

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1773677493$app_release() {
        return lambda$1773677493;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1773677493$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C28@967L48,29@1055L10,30@1116L11,27@938L214:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1773677493, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda$1773677493.<anonymous> (ClearCartDialog.kt:27)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.clear_cart_dialog_title, composer, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getTitleLarge(), composer, 0, 0, 131066);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1112088020$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C35@1222L47,36@1309L10,37@1370L11,34@1193L220:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1112088020, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda$1112088020.<anonymous> (ClearCartDialog.kt:34)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.clear_card_dialog_text, composer, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getBodyMedium(), composer, 0, 0, 131066);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__28583769$lambda$0(androidx.compose.foundation.layout.RowScope FilledTonalButton, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(FilledTonalButton, "$this$FilledTonalButton");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C50@1860L50,51@1954L10,49@1827L167:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-28583769, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda$-28583769.<anonymous> (ClearCartDialog.kt:49)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.button_confirm_clear_cart, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelLarge(), composer, 0, 0, 131070);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__2068034150$lambda$0(androidx.compose.foundation.layout.RowScope TextButton, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C58@2141L49,59@2234L10,60@2299L11,57@2108L238:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-2068034150, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.lambda$-2068034150.<anonymous> (ClearCartDialog.kt:57)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.button_cancel_clear_cart, composer, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelLarge(), composer, 0, 0, 131066);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
