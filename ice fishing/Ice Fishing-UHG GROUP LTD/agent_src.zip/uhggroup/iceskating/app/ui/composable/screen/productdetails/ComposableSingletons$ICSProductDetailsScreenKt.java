package uhggroup.iceskating.app.ui.composable.screen.productdetails;

/* compiled from: ICSProductDetailsScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ICSProductDetailsScreenKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt();

    /* renamed from: lambda$-1787610298, reason: not valid java name */
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f60lambda$1787610298 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1787610298, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt.lambda__1787610298$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1787610298$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11497getLambda$1787610298$app_release() {
        return f60lambda$1787610298;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__1787610298$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C63@2258L65,62@2206L191:ICSProductDetailsScreen.kt#eadzsu");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1787610298, i, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt.lambda$-1787610298.<anonymous> (ICSProductDetailsScreen.kt:62)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt.DataEmptyContent(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.product_details_state_empty_primary_text, composer, 0), null, null, null, composer, 6, 28);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
