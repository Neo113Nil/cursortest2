package uhggroup.iceskating.app.ui.composable.screen.onboarding.controls;

/* compiled from: OnboardingControls.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$OnboardingControlsKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.ComposableSingletons$OnboardingControlsKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.ComposableSingletons$OnboardingControlsKt();
    private static kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$2040510541 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(2040510541, false, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.ComposableSingletons$OnboardingControlsKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
            return uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.ComposableSingletons$OnboardingControlsKt.lambda_2040510541$lambda$0((androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
        }
    });

    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$2040510541$app_release() {
        return lambda$2040510541;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_2040510541$lambda$0(androidx.compose.foundation.layout.RowScope TextButton, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C43@1564L42,43@1552L55:OnboardingControls.kt#7ougze");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(2040510541, i, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.ComposableSingletons$OnboardingControlsKt.lambda$2040510541.<anonymous> (OnboardingControls.kt:43)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.skip_button_title, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer, 0, 0, 262142);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
