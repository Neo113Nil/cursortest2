package uhggroup.iceskating.app.ui.composable.screen.onboarding;

/* compiled from: ICSOnboardingScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ICSOnboardingScreenKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt();

    /* renamed from: lambda$-169637370, reason: not valid java name */
    private static kotlin.jvm.functions.Function4<androidx.compose.foundation.pager.PagerScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f59lambda$169637370 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-169637370, false, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function4
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
            return uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt.lambda__169637370$lambda$0((androidx.compose.foundation.pager.PagerScope) obj, ((java.lang.Integer) obj2).intValue(), (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
        }
    });

    /* renamed from: getLambda$-169637370$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function4<androidx.compose.foundation.pager.PagerScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11488getLambda$169637370$app_release() {
        return f59lambda$169637370;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__169637370$lambda$0(androidx.compose.foundation.pager.PagerScope HorizontalPager, int i, androidx.compose.runtime.Composer composer, int i2) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(HorizontalPager, "$this$HorizontalPager");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(page)77@2929L54:ICSOnboardingScreen.kt#760l7a");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-169637370, i2, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt.lambda$-169637370.<anonymous> (ICSOnboardingScreen.kt:77)");
        }
        uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.OnboardingPage(uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContentKt.getOnboardingPagesContent().get(i), null, composer, 0, 2);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }
}
