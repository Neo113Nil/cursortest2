package uhggroup.iceskating.app.ui.composable.approot.bottombar;

/* compiled from: AppBottomBar.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001aA\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\n2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00060\u000fH\u0007¢\u0006\u0002\u0010\u0010\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0004\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\u0011"}, d2 = {"BarHeight", "Landroidx/compose/ui/unit/Dp;", "F", "IconSize", "BarElevation", "AppBottomBar", "", "itemsInCart", "", "currentDestination", "Landroidx/navigation/NavDestination;", "navigationItems", "", "Luhggroup/iceskating/app/ui/composable/approot/bottombar/BottomNavItem;", "onNavigateToRoute", "Lkotlin/Function1;", "(ILandroidx/navigation/NavDestination;Ljava/util/List;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppBottomBarKt {
    private static final float BarHeight = androidx.compose.ui.unit.Dp.m8851constructorimpl(64);
    private static final float IconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(20);
    private static final float BarElevation = androidx.compose.ui.unit.Dp.m8851constructorimpl(2);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$1(int i, androidx.navigation.NavDestination navDestination, java.util.List list, kotlin.jvm.functions.Function1 function1, int i2, androidx.compose.runtime.Composer composer, int i3) {
        AppBottomBar(i, navDestination, list, function1, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1));
        return kotlin.Unit.INSTANCE;
    }

    public static final void AppBottomBar(final int i, final androidx.navigation.NavDestination navDestination, final java.util.List<uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem> navigationItems, final kotlin.jvm.functions.Function1<? super uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem, kotlin.Unit> onNavigateToRoute, androidx.compose.runtime.Composer composer, final int i2) {
        int i3;
        androidx.compose.ui.Modifier.Companion companionBorder;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigationItems, "navigationItems");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToRoute, "onNavigateToRoute");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1983570851);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AppBottomBar)N(itemsInCart,currentDestination,navigationItems,onNavigateToRoute)44@1844L7,47@1972L11,47@1930L74,49@2010L3203:AppBottomBar.kt#2951w6");
        if ((i2 & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(i) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navDestination) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navigationItems) ? 256 : 128;
        }
        if ((i2 & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToRoute) ? 2048 : 1024;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1983570851, i3, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar (AppBottomBar.kt:43)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
            androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeM1543RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11612getCardCornerRadiusD9Ej5fM());
            androidx.compose.foundation.BorderStroke borderStrokeM11517controlBorderStrokeIv8Zu3U = uhggroup.iceskating.app.ui.theme.BordersKt.m11517controlBorderStrokeIv8Zu3U(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnTertiaryContainer(), composerStartRestartGroup, 0, 0);
            androidx.compose.ui.Modifier modifierM1166paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(androidx.compose.foundation.layout.WindowInsetsPadding_androidKt.navigationBarsPadding(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null)), dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, dimens.m11620getScreenPaddingD9Ej5fM(), dimens.m11614getContentSpacingD9Ej5fM(), 2, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1166paddingqDBjuR0$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1353305097, "C64@2580L11,65@2652L11,67@2748L2459,59@2298L2909:AppBottomBar.kt#2951w6");
            androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShape = roundedCornerShapeM1543RoundedCornerShape0680j_4;
            androidx.compose.ui.Modifier modifierM5580shadows4CzXII$default = androidx.compose.ui.draw.ShadowKt.m5580shadows4CzXII$default(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, BarHeight), BarElevation, roundedCornerShape, true, 0L, 0L, 24, null);
            if (borderStrokeM11517controlBorderStrokeIv8Zu3U == null || (companionBorder = androidx.compose.foundation.BorderKt.border(androidx.compose.ui.Modifier.INSTANCE, borderStrokeM11517controlBorderStrokeIv8Zu3U, roundedCornerShape)) == null) {
                companionBorder = androidx.compose.ui.Modifier.INSTANCE;
            }
            androidx.compose.material3.NavigationBarKt.m3153NavigationBarHsRjFd4(modifierM5580shadows4CzXII$default.then(companionBorder), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getTertiaryContainer(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnTertiaryContainer(), 0.0f, androidx.compose.foundation.layout.WindowInsetsKt.WindowInsets(0, 0, 0, 0), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(341009302, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function3
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                    return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1(navigationItems, navDestination, onNavigateToRoute, i, (androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composerStartRestartGroup, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$1(i, navDestination, navigationItems, onNavigateToRoute, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1(java.util.List list, androidx.navigation.NavDestination navDestination, final kotlin.jvm.functions.Function1 function1, final int i, androidx.compose.foundation.layout.RowScope rowScope, androidx.compose.runtime.Composer composer, int i2) {
        int i3;
        androidx.compose.foundation.layout.RowScope NavigationBar = rowScope;
        androidx.compose.runtime.Composer composer2 = composer;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavigationBar, "$this$NavigationBar");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer2, "C*71@2947L27,72@3003L1142,97@4175L322,106@4617L11,107@4697L11,108@4779L11,109@4872L11,112@5038L11,105@4554L611,69@2812L2371:AppBottomBar.kt#2951w6");
        if ((i2 & 6) == 0) {
            i3 = i2 | (composer2.changed(NavigationBar) ? 4 : 2);
        } else {
            i3 = i2;
        }
        boolean z = true;
        if (!composer2.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(341009302, i3, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous> (AppBottomBar.kt:68)");
            }
            java.util.Iterator it = list.iterator();
            while (it.hasNext()) {
                final uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem = (uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem) it.next();
                boolean zIsSelectedDestination = uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItemKt.isSelectedDestination(navDestination, bottomNavItem.getRoute());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer2, 261267389, "CC(remember):AppBottomBar.kt#9igjgp");
                boolean zChanged = composer2.changed(function1) | composer2.changed(bottomNavItem);
                java.lang.Object objRememberedValue = composer2.rememberedValue();
                if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$0$0(function1, bottomNavItem);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.internal.ComposableLambda composableLambdaRememberComposableLambda = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1782165629, z, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$1(bottomNavItem, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                }, composer2, 54);
                androidx.compose.runtime.internal.ComposableLambda composableLambdaRememberComposableLambda2 = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(870593024, z, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$2(bottomNavItem, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                }, composer2, 54);
                int i4 = i3;
                androidx.compose.material3.NavigationBarItemDefaults navigationBarItemDefaults = androidx.compose.material3.NavigationBarItemDefaults.INSTANCE;
                long tertiary = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getTertiary();
                composer2 = composer;
                androidx.compose.material3.NavigationBarKt.NavigationBarItem(NavigationBar, zIsSelectedDestination, (kotlin.jvm.functions.Function0) objRememberedValue, composableLambdaRememberComposableLambda, null, false, composableLambdaRememberComposableLambda2, false, navigationBarItemDefaults.m3148colors69fazGs(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getOnTertiary(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getOnTertiaryContainer(), tertiary, androidx.compose.ui.graphics.Color.m5981copywmQWz5c$default(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getOnTertiaryContainer(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null), androidx.compose.ui.graphics.Color.m5981copywmQWz5c$default(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getOnTertiaryContainer(), 0.6f, 0.0f, 0.0f, 0.0f, 14, null), 0L, 0L, composer, androidx.compose.material3.NavigationBarItemDefaults.$stable << 21, 96), null, composer2, (i4 & 14) | 1575936, 344);
                NavigationBar = rowScope;
                i3 = i4;
                z = z;
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$0$0(kotlin.jvm.functions.Function1 function1, uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem) {
        function1.invoke(bottomNavItem);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$1(final uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem, final int i, androidx.compose.runtime.Composer composer, int i2) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppBottomBar.kt#2951w6");
        if (!composer.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1782165629, i2, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AppBottomBar.kt:73)");
            }
            if (kotlin.jvm.internal.Intrinsics.areEqual(bottomNavItem.getRoute(), uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart.INSTANCE)) {
                composer.startReplaceGroup(-1889377647);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "75@3143L295,82@3469L323,74@3092L700");
                androidx.compose.material3.BadgeKt.BadgedBox(androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1095020192, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function3
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                        return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$1$0(i, (androidx.compose.foundation.layout.BoxScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                    }
                }, composer, 54), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(59984606, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function3
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                        return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$1$1(bottomNavItem, (androidx.compose.foundation.layout.BoxScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                    }
                }, composer, 54), composer, 390, 2);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-1888635910);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "92@3970L29,90@3854L243");
                androidx.compose.material3.IconKt.m3011Iconww6aTOc(bottomNavItem.getIcon(), androidx.compose.ui.res.StringResources_androidKt.stringResource(bottomNavItem.getTitleRes(), composer, 0), androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), 0L, composer, 384, 8);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$1$0(final int i, androidx.compose.foundation.layout.BoxScope BadgedBox, androidx.compose.runtime.Composer composer, int i2) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(BadgedBox, "$this$BadgedBox");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppBottomBar.kt#2951w6");
        if (composer.shouldExecute((i2 & 17) != 16, i2 & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1095020192, i2, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AppBottomBar.kt:76)");
            }
            if (i > 0) {
                composer.startReplaceGroup(1469991544);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "77@3250L116,77@3244L122");
                androidx.compose.material3.BadgeKt.m2496BadgeeopBjH0(null, 0L, 0L, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-985523224, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                        return uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar$lambda$0$1$0$1$0$0(i, (androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                    }
                }, composer, 54), composer, 3072, 7);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(1470185666);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$1$0$0(int i, androidx.compose.foundation.layout.RowScope Badge, androidx.compose.runtime.Composer composer, int i2) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Badge, "$this$Badge");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C78@3296L28:AppBottomBar.kt#2951w6");
        if (!composer.shouldExecute((i2 & 17) != 16, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-985523224, i2, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AppBottomBar.kt:78)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(java.lang.String.valueOf(i), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer, 0, 0, 262142);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$1$1(uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem, androidx.compose.foundation.layout.BoxScope BadgedBox, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(BadgedBox, "$this$BadgedBox");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C85@3627L29,83@3503L259:AppBottomBar.kt#2951w6");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(59984606, i, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AppBottomBar.kt:83)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(bottomNavItem.getIcon(), androidx.compose.ui.res.StringResources_androidKt.stringResource(bottomNavItem.getTitleRes(), composer, 0), androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), 0L, composer, 384, 8);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppBottomBar$lambda$0$1$0$2(uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C99@4242L29,100@4323L10,98@4201L274:AppBottomBar.kt#2951w6");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(870593024, i, -1, "uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBar.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AppBottomBar.kt:98)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(bottomNavItem.getTitleRes(), composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, androidx.compose.ui.text.style.TextOverflow.INSTANCE.m8787getEllipsisgIe3tQ8(), false, 1, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelSmall(), composer, 0, 24960, 110590);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
