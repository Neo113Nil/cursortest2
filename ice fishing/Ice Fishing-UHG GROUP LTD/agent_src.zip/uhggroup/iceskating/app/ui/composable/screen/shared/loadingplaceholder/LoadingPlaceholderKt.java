package uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder;

/* compiled from: LoadingPlaceholder.kt */
@kotlin.Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\u001a\u0017\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0007²\u0006\n\u0010\b\u001a\u00020\tX\u008a\u008e\u0002²\u0006\n\u0010\n\u001a\u00020\u000bX\u008a\u0084\u0002"}, d2 = {"ShimmerDurationMillis", "", "LoadingPlaceholder", "", "modifier", "Landroidx/compose/ui/Modifier;", "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release", "size", "Landroidx/compose/ui/unit/IntSize;", "sweep", ""}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class LoadingPlaceholderKt {
    private static final int ShimmerDurationMillis = 2000;

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit LoadingPlaceholder$lambda$5(androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        LoadingPlaceholder(modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final void LoadingPlaceholder(androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-2144988528);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(LoadingPlaceholder)N(modifier)26@1089L41,28@1153L68,29@1250L277,38@1563L11,39@1654L11,46@1846L13,44@1786L584:LoadingPlaceholder.kt#y35zf3");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
            modifier3 = modifier2;
        } else {
            modifier3 = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-2144988528, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholder (LoadingPlaceholder.kt:25)");
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 250329017, "CC(remember):LoadingPlaceholder.kt#9igjgp");
            java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(androidx.compose.ui.unit.IntSize.m9014boximpl(androidx.compose.ui.unit.IntSize.INSTANCE.m9027getZeroYbymL2g()), null, 2, null);
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            final androidx.compose.runtime.MutableState mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.State<java.lang.Float> stateAnimateFloat = androidx.compose.animation.core.InfiniteTransitionKt.animateFloat(androidx.compose.animation.core.InfiniteTransitionKt.rememberInfiniteTransition("product_image_shimmer_vertical", composerStartRestartGroup, 6, 0), 0.0f, 1.0f, androidx.compose.animation.core.AnimationSpecKt.m211infiniteRepeatable9IiC70o$default(androidx.compose.animation.core.AnimationSpecKt.tween$default(ShimmerDurationMillis, 0, androidx.compose.animation.core.EasingKt.getLinearEasing(), 2, null), null, 0L, 6, null), "product_image_shimmer_vertical_sweep", composerStartRestartGroup, androidx.compose.animation.core.InfiniteTransition.$stable | 25008 | (androidx.compose.animation.core.InfiniteRepeatableSpec.$stable << 9), 0);
            long surfaceContainerHighest = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHighest();
            long jM6033lerpjxsXWHM = androidx.compose.ui.graphics.ColorKt.m6033lerpjxsXWHM(surfaceContainerHighest, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerLowest(), 0.5f);
            float fLoadingPlaceholder$lambda$3 = ((LoadingPlaceholder$lambda$3(stateAnimateFloat) * 2.0f) - 1.0f) * ((int) (LoadingPlaceholder$lambda$1(mutableState) & 4294967295L));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 250353213, "CC(remember):LoadingPlaceholder.kt#9igjgp");
            java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholderKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        return uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholderKt.LoadingPlaceholder$lambda$4$0(mutableState, (androidx.compose.ui.unit.IntSize) obj);
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.background$default(androidx.compose.ui.layout.OnRemeasuredModifierKt.onSizeChanged(modifier3, (kotlin.jvm.functions.Function1) objRememberedValue2), androidx.compose.ui.graphics.Brush.Companion.m5932linearGradientmHitzGk$default(androidx.compose.ui.graphics.Brush.INSTANCE, new kotlin.Pair[]{kotlin.TuplesKt.to(java.lang.Float.valueOf(0.0f), androidx.compose.ui.graphics.Color.m5972boximpl(surfaceContainerHighest)), kotlin.TuplesKt.to(java.lang.Float.valueOf(0.35f), androidx.compose.ui.graphics.Color.m5972boximpl(surfaceContainerHighest)), kotlin.TuplesKt.to(java.lang.Float.valueOf(0.5f), androidx.compose.ui.graphics.Color.m5972boximpl(jM6033lerpjxsXWHM)), kotlin.TuplesKt.to(java.lang.Float.valueOf(0.65f), androidx.compose.ui.graphics.Color.m5972boximpl(surfaceContainerHighest)), kotlin.TuplesKt.to(java.lang.Float.valueOf(1.0f), androidx.compose.ui.graphics.Color.m5972boximpl(surfaceContainerHighest))}, androidx.compose.ui.geometry.Offset.m5729constructorimpl((java.lang.Float.floatToRawIntBits(0.0f) << 32) | (java.lang.Float.floatToRawIntBits(fLoadingPlaceholder$lambda$3) & 4294967295L)), androidx.compose.ui.geometry.Offset.m5729constructorimpl((java.lang.Float.floatToRawIntBits(0.0f) << 32) | (java.lang.Float.floatToRawIntBits(fLoadingPlaceholder$lambda$3 + r9) & 4294967295L)), 0, 8, (java.lang.Object) null), null, 0.0f, 6, null), composerStartRestartGroup, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholderKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholderKt.LoadingPlaceholder$lambda$5(modifier3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    private static final long LoadingPlaceholder$lambda$1(androidx.compose.runtime.MutableState<androidx.compose.ui.unit.IntSize> mutableState) {
        return mutableState.getValue().m9026unboximpl();
    }

    private static final void LoadingPlaceholder$lambda$2(androidx.compose.runtime.MutableState<androidx.compose.ui.unit.IntSize> mutableState, long j) {
        mutableState.setValue(androidx.compose.ui.unit.IntSize.m9014boximpl(j));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit LoadingPlaceholder$lambda$4$0(androidx.compose.runtime.MutableState mutableState, androidx.compose.ui.unit.IntSize intSize) {
        LoadingPlaceholder$lambda$2(mutableState, intSize.m9026unboximpl());
        return kotlin.Unit.INSTANCE;
    }

    private static final float LoadingPlaceholder$lambda$3(androidx.compose.runtime.State<java.lang.Float> state) {
        return state.getValue().floatValue();
    }
}
