package uhggroup.iceskating.app.ui.composable.screen.checkout;

/* compiled from: ICSCheckoutScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
final /* synthetic */ class ICSCheckoutScreenKt$ICSCheckoutScreen$3$1 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> {
    ICSCheckoutScreenKt$ICSCheckoutScreen$3$1(java.lang.Object obj) {
        super(1, obj, uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.class, "updateCustomerEmail", "updateCustomerEmail(Ljava/lang/String;)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(java.lang.String str) {
        invoke2(str);
        return kotlin.Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(java.lang.String p0) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(p0, "p0");
        ((uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel) this.receiver).updateCustomerEmail(p0);
    }
}
