package uhggroup.iceskating.app.ui.composable.approot.topbar;

/* compiled from: AppTopBar.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$AppTopBarKt {
    public static final uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt INSTANCE = new uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1862759896 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1862759896, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.lambda_1862759896$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-1290821457, reason: not valid java name */
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f54lambda$1290821457 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1290821457, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.lambda__1290821457$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1290821457$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11457getLambda$1290821457$app_release() {
        return f54lambda$1290821457;
    }

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1862759896$app_release() {
        return lambda$1862759896;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__1290821457$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C93@3995L52,91@3876L259:AppTopBar.kt#cp3yd8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1290821457, i, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.lambda$-1290821457.<anonymous> (AppTopBar.kt:91)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.DeleteKt.getDelete(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.clear_cart_icon_description, composer, 0), androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(22)), 0L, composer, 384, 8);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1862759896$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C105@4479L46,106@4576L11,103@4345L286:AppTopBar.kt#cp3yd8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1862759896, i, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.lambda$1862759896.<anonymous> (AppTopBar.kt:103)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.automirrored.filled.ArrowBackKt.getArrowBack(androidx.compose.material.icons.Icons.AutoMirrored.Filled.INSTANCE), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.back_icon_description, composer, 0), (androidx.compose.ui.Modifier) null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), composer, 0, 4);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
