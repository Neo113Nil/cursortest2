package uhggroup.iceskating.app.ui.composable.screen.onboarding;

/* compiled from: ICSOnboardingScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$OnboardingPager$1$1$1$1", f = "ICSOnboardingScreen.kt", i = {}, l = {91}, m = "invokeSuspend", n = {}, nl = {92}, s = {}, v = 2)
/* loaded from: classes3.dex */
final class ICSOnboardingScreenKt$OnboardingPager$1$1$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.compose.foundation.pager.PagerState $pagerState;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ICSOnboardingScreenKt$OnboardingPager$1$1$1$1(androidx.compose.foundation.pager.PagerState pagerState, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$OnboardingPager$1$1$1$1> continuation) {
        super(2, continuation);
        this.$pagerState = pagerState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$OnboardingPager$1$1$1$1(this.$pagerState, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$OnboardingPager$1$1$1$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            androidx.compose.foundation.pager.PagerState pagerState = this.$pagerState;
            this.label = 1;
            if (androidx.compose.foundation.pager.PagerState.animateScrollToPage$default(pagerState, pagerState.getCurrentPage() + 1, 0.0f, null, this, 6, null) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(obj);
        }
        return kotlin.Unit.INSTANCE;
    }
}
