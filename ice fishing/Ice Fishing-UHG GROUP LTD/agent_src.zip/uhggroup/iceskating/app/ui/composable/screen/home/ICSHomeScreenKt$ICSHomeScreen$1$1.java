package uhggroup.iceskating.app.ui.composable.screen.home;

/* compiled from: ICSHomeScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
final /* synthetic */ class ICSHomeScreenKt$ICSHomeScreen$1$1 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> {
    ICSHomeScreenKt$ICSHomeScreen$1$1(java.lang.Object obj) {
        super(1, obj, uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.class, "addToCart", "addToCart(I)V", 0);
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ kotlin.Unit invoke(java.lang.Integer num) {
        invoke(num.intValue());
        return kotlin.Unit.INSTANCE;
    }

    public final void invoke(int i) {
        ((uhggroup.iceskating.app.ui.viewmodel.ProductViewModel) this.receiver).addToCart(i);
    }
}
