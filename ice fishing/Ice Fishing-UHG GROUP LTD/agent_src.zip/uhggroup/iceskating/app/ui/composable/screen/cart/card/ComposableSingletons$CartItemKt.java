package uhggroup.iceskating.app.ui.composable.screen.cart.card;

/* compiled from: CartItem.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$CartItemKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt();

    /* renamed from: lambda$-1680076134, reason: not valid java name */
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f56lambda$1680076134 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1680076134, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda__1680076134$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$457404035 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(457404035, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda_457404035$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: lambda$-899838796, reason: not valid java name */
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f57lambda$899838796 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-899838796, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda__899838796$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-1680076134$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11469getLambda$1680076134$app_release() {
        return f56lambda$1680076134;
    }

    /* renamed from: getLambda$-899838796$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11470getLambda$899838796$app_release() {
        return f57lambda$899838796;
    }

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$457404035$app_release() {
        return lambda$457404035;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__1680076134$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C90@3630L121,88@3511L267:CartItem.kt#moic0h");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1680076134, i, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda$-1680076134.<anonymous> (CartItem.kt:88)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.RemoveKt.getRemove(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.decrease_quantity_icon_description, composer, 0), (androidx.compose.ui.Modifier) null, 0L, composer, 0, 12);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_457404035$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C110@4473L121,108@4357L264:CartItem.kt#moic0h");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(457404035, i, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda$457404035.<anonymous> (CartItem.kt:108)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.AddKt.getAdd(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.increase_quantity_icon_description, composer, 0), (androidx.compose.ui.Modifier) null, 0L, composer, 0, 12);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__899838796$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C126@5026L53,124@4923L175:CartItem.kt#moic0h");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-899838796, i, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.card.ComposableSingletons$CartItemKt.lambda$-899838796.<anonymous> (CartItem.kt:124)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.DeleteKt.getDelete(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.delete_item_icon_description, composer, 0), (androidx.compose.ui.Modifier) null, 0L, composer, 0, 12);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
