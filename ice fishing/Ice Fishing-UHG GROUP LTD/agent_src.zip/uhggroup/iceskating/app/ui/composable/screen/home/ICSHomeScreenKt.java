package uhggroup.iceskating.app.ui.composable.screen.home;

/* compiled from: ICSHomeScreen.kt */
@kotlin.Metadata(d1 = {"\u0000:\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\u001aD\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072!\u0010\b\u001a\u001d\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00030\tH\u0007¢\u0006\u0002\u0010\r\u001aq\u0010\u000e\u001a\u00020\u00032\u0012\u0010\u000f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\u00102\b\b\u0002\u0010\u0004\u001a\u00020\u00052!\u0010\b\u001a\u001d\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00030\t2!\u0010\u0013\u001a\u001d\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00030\tH\u0003¢\u0006\u0002\u0010\u0014\u001ak\u0010\u0015\u001a\u00020\u00032\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00120\u00112\b\b\u0002\u0010\u0004\u001a\u00020\u00052!\u0010\u0017\u001a\u001d\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00030\t2!\u0010\u0018\u001a\u001d\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00030\tH\u0003¢\u0006\u0002\u0010\u0019\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001a²\u0006\u0016\u0010\u000f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u00110\u0010X\u008a\u0084\u0002²\u0006\f\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u008a\u008e\u0002"}, d2 = {"FEATURED_PRODUCTS_COUNT", "", "ICSHomeScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/ProductViewModel;", "onNavigateToProductDetails", "Lkotlin/Function1;", "Lkotlin/ParameterName;", androidx.autofill.HintConstants.AUTOFILL_HINT_NAME, "productId", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/ProductViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "HomeContent", "productsState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/data/model/Product;", "onAddProductToCart", "(Luhggroup/iceskating/app/ui/state/DataUiState;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "ProductsList", "products", "onProductClick", "onAddToCartClick", "(Ljava/util/List;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "app_release", "selectedCategory", "Luhggroup/iceskating/app/data/model/ProductCategory;"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSHomeScreenKt {
    private static final int FEATURED_PRODUCTS_COUNT = 3;

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit HomeContent$lambda$1(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        HomeContent(dataUiState, modifier, function1, function12, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSHomeScreen$lambda$2(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel, kotlin.jvm.functions.Function1 function1, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ICSHomeScreen(modifier, productViewModel, function1, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$5(java.util.List list, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ProductsList(list, modifier, function1, function12, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0138  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ICSHomeScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onNavigateToProductDetails, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel2;
        final androidx.compose.ui.Modifier.Companion companion;
        final uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel3;
        uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel4;
        boolean zChangedInstance;
        uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ICSHomeScreen$1$1 iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToProductDetails, "onNavigateToProductDetails");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-212133285);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSHomeScreen)N(modifier,viewModel,onNavigateToProductDetails)45@2205L16,51@2402L20,47@2227L202:ICSHomeScreen.kt#8md9ri");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                productViewModel2 = productViewModel;
                int i5 = composerStartRestartGroup.changedInstance(productViewModel2) ? 32 : 16;
                i3 |= i5;
            } else {
                productViewModel2 = productViewModel;
            }
            i3 |= i5;
        } else {
            productViewModel2 = productViewModel;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToProductDetails) ? 256 : 128;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) != 146, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "42@2077L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    i3 &= -113;
                    productViewModel4 = (uhggroup.iceskating.app.ui.viewmodel.ProductViewModel) viewModelResolveViewModel;
                }
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-212133285, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreen (ICSHomeScreen.kt:44)");
                }
                uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.model.Product>> dataUiStateICSHomeScreen$lambda$0 = ICSHomeScreen$lambda$0(androidx.compose.runtime.SnapshotStateKt.collectAsState(productViewModel4.getProductsState(), null, composerStartRestartGroup, 0, 1));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1996610737, "CC(remember):ICSHomeScreen.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(productViewModel4);
                iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance || iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ICSHomeScreen$1$1(productViewModel4);
                    composerStartRestartGroup.updateRememberedValue(iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                HomeContent(dataUiStateICSHomeScreen$lambda$0, companion, onNavigateToProductDetails, (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue), composerStartRestartGroup, (i3 & 896) | ((i3 << 3) & 112), 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                productViewModel3 = productViewModel4;
            }
            productViewModel4 = productViewModel2;
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.model.Product>> dataUiStateICSHomeScreen$lambda$02 = ICSHomeScreen$lambda$0(androidx.compose.runtime.SnapshotStateKt.collectAsState(productViewModel4.getProductsState(), null, composerStartRestartGroup, 0, 1));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1996610737, "CC(remember):ICSHomeScreen.kt#9igjgp");
            zChangedInstance = composerStartRestartGroup.changedInstance(productViewModel4);
            iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (!zChangedInstance) {
                iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ICSHomeScreen$1$1(productViewModel4);
                composerStartRestartGroup.updateRememberedValue(iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                HomeContent(dataUiStateICSHomeScreen$lambda$02, companion, onNavigateToProductDetails, (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSHomeScreenKt$ICSHomeScreen$1$1RememberedValue), composerStartRestartGroup, (i3 & 896) | ((i3 << 3) & 112), 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                }
                productViewModel3 = productViewModel4;
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier2;
            productViewModel3 = productViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ICSHomeScreen$lambda$2(companion, productViewModel3, onNavigateToProductDetails, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void HomeContent(final uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.data.model.Product>> dataUiState, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function12, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        final androidx.compose.ui.Modifier.Companion companion;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1108000506);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(HomeContent)N(productsState,modifier,onNavigateToProductDetails,onAddProductToCart)62@2668L747:ICSHomeScreen.kt#8md9ri");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(dataUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(modifier) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function1) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function12) ? 2048 : 1024;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier;
        } else {
            companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1108000506, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.HomeContent (ICSHomeScreen.kt:61)");
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1357751605, "C68@2842L313,64@2707L702:ICSHomeScreen.kt#8md9ri");
            uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt.DataBasedContainer(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), dataUiState, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1662585111, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.HomeContent$lambda$0$0(dataUiState, function1, function12, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt.INSTANCE.m11478getLambda$485815720$app_release(), null, composerStartRestartGroup, ((i3 << 3) & 112) | 3462, 16);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.HomeContent$lambda$1(dataUiState, companion, function1, function12, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit HomeContent$lambda$0$0(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C71@2949L192:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1662585111, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.HomeContent.<anonymous>.<anonymous> (ICSHomeScreen.kt:69)");
            }
            kotlin.jvm.internal.Intrinsics.checkNotNull(dataUiState, "null cannot be cast to non-null type uhggroup.iceskating.app.ui.state.DataUiState.Populated<kotlin.collections.List<uhggroup.iceskating.app.data.model.Product>>");
            ProductsList((java.util.List) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData(), null, function1, function12, composer, 0, 2);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x007b  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01ed  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x01f9  */
    /* JADX WARN: Removed duplicated region for block: B:97:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void ProductsList(final java.util.List<uhggroup.iceskating.app.data.model.Product> list, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function12, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function13;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(552678041);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ProductsList)N(products,modifier,onProductClick,onAddToCartClick)95@3664L42,95@3647L59,97@3734L172,102@3937L7,108@4155L7,111@4256L1901,104@3950L2207:ICSHomeScreen.kt#8md9ri");
        int i3 = (i & 6) == 0 ? (composerStartRestartGroup.changedInstance(list) ? 4 : 2) | i : i;
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(function1) ? 256 : 128;
            }
            if ((i & 3072) != 0) {
                function13 = function12;
                i3 |= composerStartRestartGroup.changedInstance(function13) ? 2048 : 1024;
            } else {
                function13 = function12;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier modifier4 = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(552678041, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList (ICSHomeScreen.kt:94)");
                }
                java.lang.Object[] objArr = new java.lang.Object[0];
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1452340061, "CC(remember):ICSHomeScreen.kt#9igjgp");
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$0$0();
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final androidx.compose.runtime.MutableState mutableState = (androidx.compose.runtime.MutableState) androidx.compose.runtime.saveable.RememberSaveableKt.rememberSaveable(objArr, (kotlin.jvm.functions.Function0) objRememberedValue, composerStartRestartGroup, 48);
                uhggroup.iceskating.app.data.model.ProductCategory productCategoryProductsList$lambda$1 = ProductsList$lambda$1(mutableState);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1452337691, "CC(remember):ICSHomeScreen.kt#9igjgp");
                boolean zChanged = composerStartRestartGroup.changed(productCategoryProductsList$lambda$1 != null ? productCategoryProductsList$lambda$1.ordinal() : -1) | composerStartRestartGroup.changed(list);
                java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (zChanged || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    uhggroup.iceskating.app.data.model.ProductCategory productCategoryProductsList$lambda$12 = ProductsList$lambda$1(mutableState);
                    if (productCategoryProductsList$lambda$12 == null) {
                        objRememberedValue2 = list;
                    } else {
                        java.util.ArrayList arrayList = new java.util.ArrayList();
                        for (java.lang.Object obj : list) {
                            if (((uhggroup.iceskating.app.data.model.Product) obj).getCategory() == productCategoryProductsList$lambda$12) {
                                arrayList.add(obj);
                            }
                        }
                        objRememberedValue2 = arrayList;
                    }
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                final java.util.List list2 = (java.util.List) objRememberedValue2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(modifier4, 0.0f, 1, null);
                float fM11620getScreenPaddingD9Ej5fM = dimens.m11620getScreenPaddingD9Ej5fM();
                float fM11620getScreenPaddingD9Ej5fM2 = dimens.m11620getScreenPaddingD9Ej5fM();
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume2 = composerStartRestartGroup.consume(localContentBottomPadding);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.foundation.layout.PaddingValues paddingValuesM1159PaddingValuesa9UjIt4$default = androidx.compose.foundation.layout.PaddingKt.m1159PaddingValuesa9UjIt4$default(0.0f, fM11620getScreenPaddingD9Ej5fM, 0.0f, androidx.compose.ui.unit.Dp.m8851constructorimpl(fM11620getScreenPaddingD9Ej5fM2 + ((androidx.compose.ui.unit.Dp) objConsume2).m8865unboximpl()), 5, null);
                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical horizontalOrVerticalM836spacedBy0680j_4 = androidx.compose.foundation.layout.Arrangement.INSTANCE.m836spacedBy0680j_4(dimens.m11614getContentSpacingD9Ej5fM());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1452319258, "CC(remember):ICSHomeScreen.kt#9igjgp");
                boolean zChanged2 = composerStartRestartGroup.changed(dimens) | composerStartRestartGroup.changedInstance(list) | ((i3 & 896) == 256) | composerStartRestartGroup.changed(mutableState) | composerStartRestartGroup.changedInstance(list2) | ((i3 & 7168) == 2048);
                java.lang.Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (zChanged2 || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function14 = function13;
                    kotlin.jvm.functions.Function1 function15 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj2) {
                            return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0(list2, dimens, list, function1, mutableState, function14, (androidx.compose.foundation.lazy.LazyListScope) obj2);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(function15);
                    objRememberedValue3 = function15;
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.Modifier modifier5 = modifier4;
                composer2 = composerStartRestartGroup;
                androidx.compose.foundation.lazy.LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM1159PaddingValuesa9UjIt4$default, false, horizontalOrVerticalM836spacedBy0680j_4, null, null, false, null, (kotlin.jvm.functions.Function1) objRememberedValue3, composer2, 0, 490);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier5;
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj2, java.lang.Object obj3) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$5(list, modifier3, function1, function12, i, i2, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if ((i & 384) == 0) {
        }
        if ((i & 3072) != 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.runtime.MutableState ProductsList$lambda$0$0() {
        return androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
    }

    private static final uhggroup.iceskating.app.data.model.ProductCategory ProductsList$lambda$1(androidx.compose.runtime.MutableState<uhggroup.iceskating.app.data.model.ProductCategory> mutableState) {
        return mutableState.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0(final java.util.List list, final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, final java.util.List list2, final kotlin.jvm.functions.Function1 function1, final androidx.compose.runtime.MutableState mutableState, final kotlin.jvm.functions.Function1 function12, androidx.compose.foundation.lazy.LazyListScope LazyColumn) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyColumn, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1514362962, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$0(dimens, (androidx.compose.foundation.lazy.LazyItemScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }), 3, null);
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyColumn, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(809434277, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$1(list2, function1, (androidx.compose.foundation.lazy.LazyItemScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }), 3, null);
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyColumn, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(2064216294, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$2(dimens, (androidx.compose.foundation.lazy.LazyItemScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }), 3, null);
        androidx.compose.foundation.lazy.LazyListScope.stickyHeader$default(LazyColumn, (java.lang.Object) null, (java.lang.Object) null, (kotlin.jvm.functions.Function4) androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1341237574, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$3(dimens, mutableState, (androidx.compose.foundation.lazy.LazyItemScope) obj, ((java.lang.Integer) obj2).intValue(), (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        }), 3, (java.lang.Object) null);
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyColumn, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-975968985, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$4(dimens, list, (androidx.compose.foundation.lazy.LazyItemScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }), 3, null);
        final kotlin.jvm.functions.Function1 function13 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$5((uhggroup.iceskating.app.data.model.Product) obj);
            }
        };
        final uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$1 iCSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$1 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Void invoke(uhggroup.iceskating.app.data.model.Product product) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object obj) {
                return invoke((uhggroup.iceskating.app.data.model.Product) obj);
            }
        };
        LazyColumn.items(list.size(), new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$2
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return function13.invoke(list.get(i));
            }
        }, new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return iCSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$1.invoke(list.get(i));
            }
        }, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(802480018, true, new kotlin.jvm.functions.Function4<androidx.compose.foundation.lazy.LazyItemScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$lambda$4$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, java.lang.Integer num, androidx.compose.runtime.Composer composer, java.lang.Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, int i, androidx.compose.runtime.Composer composer, int i2) {
                int i3;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final uhggroup.iceskating.app.data.model.Product product = (uhggroup.iceskating.app.data.model.Product) list.get(i);
                composer.startReplaceGroup(784571584);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(product)*164@6027L30,165@6094L32,161@5873L268:ICSHomeScreen.kt#8md9ri");
                androidx.compose.ui.Modifier modifierM1164paddingVpY3zN4$default = androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1775801867, "CC(remember):ICSHomeScreen.kt#9igjgp");
                boolean zChanged = composer.changed(function1) | composer.changed(product);
                java.lang.Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function14 = function1;
                    objRememberedValue = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$1$1$7$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function14.invoke(java.lang.Integer.valueOf(product.getId()));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                kotlin.jvm.functions.Function0 function0 = (kotlin.jvm.functions.Function0) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1775799721, "CC(remember):ICSHomeScreen.kt#9igjgp");
                boolean zChanged2 = composer.changed(function12) | composer.changed(product);
                java.lang.Object objRememberedValue2 = composer.rememberedValue();
                if (zChanged2 || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function15 = function12;
                    objRememberedValue2 = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$ProductsList$1$1$7$2$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function15.invoke(java.lang.Integer.valueOf(product.getId()));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue2);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                uhggroup.iceskating.app.ui.composable.screen.home.card.ProductItemKt.ProductItem(product, modifierM1164paddingVpY3zN4$default, function0, (kotlin.jvm.functions.Function0) objRememberedValue2, composer, 0, 0);
                composer.endReplaceGroup();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$0(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C114@4322L44,113@4285L176:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1514362962, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList.<anonymous>.<anonymous>.<anonymous> (ICSHomeScreen.kt:113)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.sectiontitle.SectionTitleKt.SectionTitle(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.home_featured_title, composer, 0), androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null), null, composer, 0, 4);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$1(java.util.List list, kotlin.jvm.functions.Function1 function1, androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C120@4500L145:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(809434277, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList.<anonymous>.<anonymous>.<anonymous> (ICSHomeScreen.kt:120)");
            }
            uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider(kotlin.collections.CollectionsKt.take(list, 3), null, function1, composer, 0, 2);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$2(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C128@4721L46,127@4684L178:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(2064216294, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList.<anonymous>.<anonymous>.<anonymous> (ICSHomeScreen.kt:127)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.sectiontitle.SectionTitleKt.SectionTitle(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.home_categories_title, composer, 0), androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null), null, composer, 0, 4);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$3(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, final androidx.compose.runtime.MutableState mutableState, androidx.compose.foundation.lazy.LazyItemScope stickyHeader, int i, androidx.compose.runtime.Composer composer, int i2) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(stickyHeader, "$this$stickyHeader");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)137@5035L11,134@4909L594:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i2 & 129) != 128, i2 & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1341237574, i2, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList.<anonymous>.<anonymous>.<anonymous> (ICSHomeScreen.kt:134)");
            }
            androidx.compose.ui.Modifier modifierM324backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainer(), null, 2, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierM324backgroundbw27NRU$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1173730024, "C145@5393L43,139@5098L357,148@5473L16:ICSHomeScreen.kt#8md9ri");
            androidx.compose.ui.Modifier modifierM1166paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, dimens.m11614getContentSpacingD9Ej5fM(), 0.0f, dimens.m11614getContentSpacingD9Ej5fM(), 5, null);
            uhggroup.iceskating.app.data.model.ProductCategory productCategoryProductsList$lambda$1 = ProductsList$lambda$1(mutableState);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2040356815, "CC(remember):ICSHomeScreen.kt#9igjgp");
            boolean zChanged = composer.changed(mutableState);
            java.lang.Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ProductsList$lambda$4$0$3$0$0$0(mutableState, (uhggroup.iceskating.app.data.model.ProductCategory) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryFilterRow(productCategoryProductsList$lambda$1, modifierM1166paddingqDBjuR0$default, (kotlin.jvm.functions.Function1) objRememberedValue, composer, 0, 0);
            uhggroup.iceskating.app.ui.theme.BordersKt.m11515ControlDivideriJQMabo(null, 0L, composer, 0, 3);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$3$0$0$0(androidx.compose.runtime.MutableState mutableState, uhggroup.iceskating.app.data.model.ProductCategory productCategory) {
        mutableState.setValue(productCategory);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductsList$lambda$4$0$4(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, java.util.List list, androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C154@5579L44,153@5542L222:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-975968985, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ProductsList.<anonymous>.<anonymous>.<anonymous> (ICSHomeScreen.kt:153)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.sectiontitle.SectionTitleKt.SectionTitle(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.home_products_title, composer, 0), androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null), java.lang.Integer.valueOf(list.size()), composer, 0, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.Object ProductsList$lambda$4$0$5(uhggroup.iceskating.app.data.model.Product product) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(product, "product");
        return java.lang.Integer.valueOf(product.getId());
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.model.Product>> ICSHomeScreen$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.data.model.Product>>> state) {
        return (uhggroup.iceskating.app.ui.state.DataUiState) state.getValue();
    }
}
