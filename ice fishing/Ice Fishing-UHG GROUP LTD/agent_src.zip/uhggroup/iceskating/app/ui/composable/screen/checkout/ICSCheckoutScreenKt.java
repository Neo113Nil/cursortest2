package uhggroup.iceskating.app.ui.composable.screen.checkout;

/* compiled from: ICSCheckoutScreen.kt */
@kotlin.Metadata(d1 = {"\u0000D\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a/\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\b\u001a\u0091\u0001\u0010\t\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u000f2\u0012\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00010\u00142\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00010\u00142\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00010\u00142\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0003¢\u0006\u0002\u0010\u0018¨\u0006\u0019²\u0006\u0010\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001bX\u008a\u0084\u0002²\u0006\n\u0010\u001d\u001a\u00020\u000fX\u008a\u0084\u0002²\u0006\n\u0010\u0012\u001a\u00020\u000fX\u008a\u0084\u0002"}, d2 = {"ICSCheckoutScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/CheckoutViewModel;", "onNavigateToOrdersScreen", "Lkotlin/Function0;", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/CheckoutViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "CheckoutContent", "customerFirstName", "", "customerLastName", "customerEmail", "isEmailInvalid", "", "focusManager", "Landroidx/compose/ui/focus/FocusManager;", "isButtonEnabled", "onFirstNameChanged", "Lkotlin/Function1;", "onLastNameChanged", "onEmailChanged", "onPlaceOrderButtonClick", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/ui/Modifier;Landroidx/compose/ui/focus/FocusManager;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;III)V", "app_release", "orderState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "emailInvalidState"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSCheckoutScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutContent$lambda$1(java.lang.String str, java.lang.String str2, java.lang.String str3, boolean z, androidx.compose.ui.Modifier modifier, androidx.compose.ui.focus.FocusManager focusManager, boolean z2, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, kotlin.jvm.functions.Function1 function13, kotlin.jvm.functions.Function0 function0, int i, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) throws android.content.res.Resources.NotFoundException {
        CheckoutContent(str, str2, str3, z, modifier, focusManager, z2, function1, function12, function13, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSCheckoutScreen$lambda$8(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        ICSCheckoutScreen(modifier, checkoutViewModel, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0145  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x015b  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0192  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x01bc  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x0212  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0243  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ICSCheckoutScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToOrdersScreen, androidx.compose.runtime.Composer composer, final int i, final int i2) throws android.content.res.Resources.NotFoundException {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel2;
        final androidx.compose.ui.Modifier.Companion companion;
        final uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel3;
        int i4;
        androidx.compose.runtime.State stateCollectAsStateWithLifecycle;
        java.lang.Object objRememberedValue;
        boolean zChangedInstance;
        uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$1$1 iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue;
        boolean zChangedInstance2;
        uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$2$1 iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue;
        boolean zChangedInstance3;
        uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$3$1 iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue;
        boolean zChangedInstance4;
        uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$4$1 iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToOrdersScreen, "onNavigateToOrdersScreen");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1576643200);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSCheckoutScreen)N(modifier,viewModel,onNavigateToOrdersScreen)31@1443L7,32@1494L29,33@1581L29,35@1639L227,57@2369L34,58@2433L33,59@2493L30,60@2559L21,49@2009L577:ICSCheckoutScreen.kt#yz6ycr");
        int i5 = i2 & 1;
        if (i5 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                checkoutViewModel2 = checkoutViewModel;
                int i6 = composerStartRestartGroup.changedInstance(checkoutViewModel2) ? 32 : 16;
                i3 |= i6;
            } else {
                checkoutViewModel2 = checkoutViewModel;
            }
            i3 |= i6;
        } else {
            checkoutViewModel2 = checkoutViewModel;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToOrdersScreen) ? 256 : 128;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) != 146, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "28@1339L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i5 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    checkoutViewModel3 = (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel) viewModelResolveViewModel;
                    i4 = i3 & (-113);
                }
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1576643200, i4, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreen (ICSCheckoutScreen.kt:30)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.focus.FocusManager> localFocusManager = androidx.compose.ui.platform.CompositionLocalsKt.getLocalFocusManager();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localFocusManager);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.focus.FocusManager focusManager = (androidx.compose.ui.focus.FocusManager) objConsume;
                stateCollectAsStateWithLifecycle = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(checkoutViewModel3.getOrderState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
                androidx.compose.runtime.State stateCollectAsStateWithLifecycle2 = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(checkoutViewModel3.getEmailInvalidState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969327485, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = androidx.compose.runtime.SnapshotStateKt.derivedStateOf(new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return java.lang.Boolean.valueOf(uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt.ICSCheckoutScreen$lambda$2$0(checkoutViewModel3));
                        }
                    });
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.State state = (androidx.compose.runtime.State) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (!(ICSCheckoutScreen$lambda$0(stateCollectAsStateWithLifecycle) instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated)) {
                    composerStartRestartGroup.startReplaceGroup(15886600);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "44@1923L74");
                    uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialogKt.CheckoutDialog(onNavigateToOrdersScreen, composerStartRestartGroup, (i4 >> 6) & 14);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(15973090);
                    composerStartRestartGroup.endReplaceGroup();
                }
                java.lang.String customerFirstName = checkoutViewModel3.getCustomerFirstName();
                java.lang.String customerLastName = checkoutViewModel3.getCustomerLastName();
                java.lang.String customerEmail = checkoutViewModel3.getCustomerEmail();
                boolean zICSCheckoutScreen$lambda$1 = ICSCheckoutScreen$lambda$1(stateCollectAsStateWithLifecycle2);
                boolean zICSCheckoutScreen$lambda$3 = ICSCheckoutScreen$lambda$3(state);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969304318, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance || iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$1$1(checkoutViewModel3);
                    composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969302271, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2 || iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$2$1(checkoutViewModel3);
                    composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969300354, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                zChangedInstance3 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance3 || iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$3$1(checkoutViewModel3);
                    composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                kotlin.jvm.functions.Function1 function13 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969298251, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                zChangedInstance4 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance4 || iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$4$1(checkoutViewModel3);
                    composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                CheckoutContent(customerFirstName, customerLastName, customerEmail, zICSCheckoutScreen$lambda$1, companion, focusManager, zICSCheckoutScreen$lambda$3, function1, function12, function13, (kotlin.jvm.functions.Function0) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue), composerStartRestartGroup, (i4 << 12) & 57344, 0, 0);
                composerStartRestartGroup = composerStartRestartGroup;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
            i4 = i3;
            checkoutViewModel3 = checkoutViewModel2;
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.focus.FocusManager> localFocusManager2 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalFocusManager();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume2 = composerStartRestartGroup.consume(localFocusManager2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.ui.focus.FocusManager focusManager2 = (androidx.compose.ui.focus.FocusManager) objConsume2;
            stateCollectAsStateWithLifecycle = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(checkoutViewModel3.getOrderState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
            androidx.compose.runtime.State stateCollectAsStateWithLifecycle22 = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(checkoutViewModel3.getEmailInvalidState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969327485, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
            objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            }
            androidx.compose.runtime.State state2 = (androidx.compose.runtime.State) objRememberedValue;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (!(ICSCheckoutScreen$lambda$0(stateCollectAsStateWithLifecycle) instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated)) {
            }
            java.lang.String customerFirstName2 = checkoutViewModel3.getCustomerFirstName();
            java.lang.String customerLastName2 = checkoutViewModel3.getCustomerLastName();
            java.lang.String customerEmail2 = checkoutViewModel3.getCustomerEmail();
            boolean zICSCheckoutScreen$lambda$12 = ICSCheckoutScreen$lambda$1(stateCollectAsStateWithLifecycle22);
            boolean zICSCheckoutScreen$lambda$32 = ICSCheckoutScreen$lambda$3(state2);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969304318, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
            zChangedInstance = composerStartRestartGroup.changedInstance(checkoutViewModel3);
            iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (!zChangedInstance) {
                iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$1$1(checkoutViewModel3);
                composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                kotlin.jvm.functions.Function1 function14 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$1$1RememberedValue);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969302271, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2) {
                    iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$2$1(checkoutViewModel3);
                    composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    kotlin.jvm.functions.Function1 function122 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$2$1RememberedValue);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969300354, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                    zChangedInstance3 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                    iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue = composerStartRestartGroup.rememberedValue();
                    if (!zChangedInstance3) {
                        iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$3$1(checkoutViewModel3);
                        composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        kotlin.jvm.functions.Function1 function132 = (kotlin.jvm.functions.Function1) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$3$1RememberedValue);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -969298251, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                        zChangedInstance4 = composerStartRestartGroup.changedInstance(checkoutViewModel3);
                        iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue = composerStartRestartGroup.rememberedValue();
                        if (!zChangedInstance4) {
                            iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$ICSCheckoutScreen$4$1(checkoutViewModel3);
                            composerStartRestartGroup.updateRememberedValue(iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                            CheckoutContent(customerFirstName2, customerLastName2, customerEmail2, zICSCheckoutScreen$lambda$12, companion, focusManager2, zICSCheckoutScreen$lambda$32, function14, function122, function132, (kotlin.jvm.functions.Function0) ((kotlin.reflect.KFunction) iCSCheckoutScreenKt$ICSCheckoutScreen$4$1RememberedValue), composerStartRestartGroup, (i4 << 12) & 57344, 0, 0);
                            composerStartRestartGroup = composerStartRestartGroup;
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            }
                        }
                    }
                }
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier2;
            checkoutViewModel3 = checkoutViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt.ICSCheckoutScreen$lambda$8(companion, checkoutViewModel3, onNavigateToOrdersScreen, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean ICSCheckoutScreen$lambda$2$0(uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel) {
        return checkoutViewModel.getCustomerFirstName().length() > 0 && checkoutViewModel.getCustomerLastName().length() > 0 && checkoutViewModel.getCustomerEmail().length() > 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:124:0x02d2  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x02de  */
    /* JADX WARN: Removed duplicated region for block: B:129:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x00ee  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0112  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x011b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void CheckoutContent(final java.lang.String str, final java.lang.String str2, final java.lang.String str3, final boolean z, androidx.compose.ui.Modifier modifier, final androidx.compose.ui.focus.FocusManager focusManager, final boolean z2, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> function1, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> function12, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> function13, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.runtime.Composer composer, final int i, final int i2, final int i3) throws android.content.res.Resources.NotFoundException {
        int i4;
        java.lang.String str4;
        java.lang.String str5;
        boolean z3;
        boolean z4;
        int i5;
        final androidx.compose.ui.Modifier modifier2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(848613443);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CheckoutContent)N(customerFirstName,customerLastName,customerEmail,isEmailInvalid,modifier,focusManager,isButtonEnabled,onFirstNameChanged,onLastNameChanged,onEmailChanged,onPlaceOrderButtonClick)86@3433L7,82@3286L951:ICSCheckoutScreen.kt#yz6ycr");
        if ((i & 6) == 0) {
            i4 = (composerStartRestartGroup.changed(str) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            str4 = str2;
            i4 |= composerStartRestartGroup.changed(str4) ? 32 : 16;
        } else {
            str4 = str2;
        }
        if ((i & 384) == 0) {
            str5 = str3;
            i4 |= composerStartRestartGroup.changed(str5) ? 256 : 128;
        } else {
            str5 = str3;
        }
        if ((i & 3072) == 0) {
            z3 = z;
            i4 |= composerStartRestartGroup.changed(z3) ? 2048 : 1024;
        } else {
            z3 = z;
        }
        int i6 = i3 & 16;
        if (i6 == 0) {
            if ((i & 24576) == 0) {
                i4 |= composerStartRestartGroup.changed(modifier) ? 16384 : 8192;
            }
            if ((196608 & i) == 0) {
                i4 |= composerStartRestartGroup.changedInstance(focusManager) ? 131072 : 65536;
            }
            if ((1572864 & i) != 0) {
                z4 = z2;
                i4 |= composerStartRestartGroup.changed(z4) ? 1048576 : 524288;
            } else {
                z4 = z2;
            }
            if ((i & 12582912) == 0) {
                i4 |= composerStartRestartGroup.changedInstance(function1) ? 8388608 : 4194304;
            }
            if ((i & 100663296) == 0) {
                i4 |= composerStartRestartGroup.changedInstance(function12) ? 67108864 : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasAuxSlotFlag;
            }
            if ((i & 805306368) == 0) {
                i4 |= composerStartRestartGroup.changedInstance(function13) ? androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasMovableContentFlag : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.IsMovableContentFlag;
            }
            if ((i2 & 6) != 0) {
                i5 = i2 | (composerStartRestartGroup.changedInstance(function0) ? 4 : 2);
            } else {
                i5 = i2;
            }
            if (composerStartRestartGroup.shouldExecute((i4 & 306783379) == 306783378 || (i5 & 3) != 2, i4 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier2 = modifier;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i6 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(848613443, i4, i5, "uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutContent (ICSCheckoutScreen.kt:77)");
                }
                float f = 16;
                androidx.compose.ui.Modifier modifierM1162padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m1162padding3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(companion, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m8851constructorimpl(f));
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
                androidx.compose.ui.Modifier modifier3 = companion;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localContentBottomPadding);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.Modifier modifierM1166paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(modifierM1162padding3ABfNKs, 0.0f, 0.0f, 0.0f, ((androidx.compose.ui.unit.Dp) objConsume).m8865unboximpl(), 7, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                int i7 = i4;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1166paddingqDBjuR0$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 735320166, "C95@3753L21,88@3459L517,102@3986L41,106@4121L99,104@4037L194:ICSCheckoutScreen.kt#yz6ycr");
                int i8 = i7 >> 3;
                uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt.CheckoutForm(str, str4, str5, z3, androidx.compose.foundation.ScrollKt.verticalScroll$default(androidx.compose.foundation.layout.ColumnScope.weight$default(columnScopeInstance, androidx.compose.ui.Modifier.INSTANCE, 1.0f, false, 2, null), androidx.compose.foundation.ScrollKt.rememberScrollState(0, composerStartRestartGroup, 0, 1), false, null, false, 14, null), focusManager, function1, function12, function13, composerStartRestartGroup, (i7 & 466942) | (3670016 & i8) | (29360128 & i8) | (i8 & 234881024), 0);
                composerStartRestartGroup = composerStartRestartGroup;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f)), composerStartRestartGroup, 6);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -253354148, "CC(remember):ICSCheckoutScreen.kt#9igjgp");
                boolean zChangedInstance = composerStartRestartGroup.changedInstance(focusManager) | ((i5 & 14) == 4);
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt.CheckoutContent$lambda$0$0$0(focusManager, function0);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButtonKt.CheckoutConfirmButton(z4, (kotlin.jvm.functions.Function0) objRememberedValue, null, composerStartRestartGroup, (i7 >> 18) & 14, 4);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier2 = modifier3;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt.CheckoutContent$lambda$1(str, str2, str3, z, modifier2, focusManager, z2, function1, function12, function13, function0, i, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i4 |= 24576;
        if ((196608 & i) == 0) {
        }
        if ((1572864 & i) != 0) {
        }
        if ((i & 12582912) == 0) {
        }
        if ((i & 100663296) == 0) {
        }
        if ((i & 805306368) == 0) {
        }
        if ((i2 & 6) != 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i4 & 306783379) == 306783378 || (i5 & 3) != 2, i4 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutContent$lambda$0$0$0(androidx.compose.ui.focus.FocusManager focusManager, kotlin.jvm.functions.Function0 function0) {
        androidx.compose.ui.focus.FocusManager.clearFocus$default(focusManager, false, 1, null);
        function0.invoke();
        return kotlin.Unit.INSTANCE;
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.entity.OrderEntity> ICSCheckoutScreen$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.entity.OrderEntity>> state) {
        return state.getValue();
    }

    private static final boolean ICSCheckoutScreen$lambda$1(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue().booleanValue();
    }

    private static final boolean ICSCheckoutScreen$lambda$3(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue().booleanValue();
    }
}
