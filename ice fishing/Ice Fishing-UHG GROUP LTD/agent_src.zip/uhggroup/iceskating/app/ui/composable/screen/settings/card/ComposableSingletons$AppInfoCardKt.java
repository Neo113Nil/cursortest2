package uhggroup.iceskating.app.ui.composable.screen.settings.card;

/* compiled from: AppInfoCard.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$AppInfoCardKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.settings.card.ComposableSingletons$AppInfoCardKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.settings.card.ComposableSingletons$AppInfoCardKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1294994634 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1294994634, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.settings.card.ComposableSingletons$AppInfoCardKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.settings.card.ComposableSingletons$AppInfoCardKt.lambda_1294994634$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1294994634$app_release() {
        return lambda$1294994634;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1294994634$lambda$0(androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C102@3864L54,103@3944L40,105@4098L10,101@3836L294:AppInfoCard.kt#u5v2fg");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1294994634, i, -1, "uhggroup.iceskating.app.ui.composable.screen.settings.card.ComposableSingletons$AppInfoCardKt.lambda$1294994634.<anonymous> (AppInfoCard.kt:101)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.settings_screen_version_label, composer, 0) + " " + androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.ics_app_version, composer, 0), androidx.compose.foundation.layout.PaddingKt.m1163paddingVpY3zN4(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(10), androidx.compose.ui.unit.Dp.m8851constructorimpl(4)), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelSmall(), composer, 48, 0, 131068);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
