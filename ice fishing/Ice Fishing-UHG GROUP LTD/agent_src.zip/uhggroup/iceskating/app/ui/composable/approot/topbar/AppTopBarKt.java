package uhggroup.iceskating.app.ui.composable.approot.topbar;

/* compiled from: AppTopBar.kt */
@kotlin.Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a;\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00040\n2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\nH\u0007¢\u0006\u0002\u0010\f\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\r"}, d2 = {"IconSize", "Landroidx/compose/ui/unit/Dp;", "F", "AppTopBar", "", "currentDestination", "Landroidx/navigation/NavDestination;", "isCartNotEmpty", "", "onClearCartIconClick", "Lkotlin/Function0;", "onNavigateBack", "(Landroidx/navigation/NavDestination;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppTopBarKt {
    private static final float IconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(32);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppTopBar$lambda$1(androidx.navigation.NavDestination navDestination, boolean z, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, int i, androidx.compose.runtime.Composer composer, int i2) {
        AppTopBar(navDestination, z, function0, function02, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    public static final void AppTopBar(final androidx.navigation.NavDestination navDestination, boolean z, final kotlin.jvm.functions.Function0<kotlin.Unit> onClearCartIconClick, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateBack, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        final boolean z2 = z;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onClearCartIconClick, "onClearCartIconClick");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateBack, "onNavigateBack");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1224281713);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AppTopBar)N(currentDestination,isCartNotEmpty,onClearCartIconClick,onNavigateBack)50@2190L7,53@2411L11,55@2445L33,57@2484L2612:AppTopBar.kt#cp3yd8");
        if ((i & 6) == 0) {
            i2 = (composerStartRestartGroup.changedInstance(navDestination) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerStartRestartGroup.changed(z2) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(onClearCartIconClick) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= composerStartRestartGroup.changedInstance(onNavigateBack) ? 2048 : 1024;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 1171) != 1170, i2 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1224281713, i2, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBar (AppTopBar.kt:49)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
            boolean z3 = navDestination != null && androidx.navigation.NavDestination.INSTANCE.hasRoute(navDestination, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart.class));
            final boolean zMatchesAnyRoute = uhggroup.iceskating.app.ui.composable.approot.AppRootKt.matchesAnyRoute(navDestination, uhggroup.iceskating.app.ui.composable.approot.topbar.TopBarTitlesKt.getCanNavigateBackRoutes());
            long surfaceContainer = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainer();
            uhggroup.iceskating.app.ui.theme.SystemBarsKt.m11593StatusBarIconsForek8zF_U(surfaceContainer, composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            final boolean z4 = z3;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -138227635, "C114@4843L11,115@4925L11,116@5010L11,112@4727L326,59@2532L916,100@4221L464,82@3473L716,58@2501L2563,120@5074L16:AppTopBar.kt#cp3yd8");
            androidx.compose.material3.TopAppBarColors topAppBarColorsM3957topAppBarColors5tl4gsc = androidx.compose.material3.TopAppBarDefaults.INSTANCE.m3957topAppBarColors5tl4gsc(surfaceContainer, 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), 0L, composerStartRestartGroup, androidx.compose.material3.TopAppBarDefaults.$stable << 18, 34);
            composerStartRestartGroup = composerStartRestartGroup;
            z2 = z;
            androidx.compose.material3.AppBarKt.m2479TopAppBarGHTll3U(androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(201647901, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar$lambda$0$0(dimens, navDestination, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-934296545, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar$lambda$0$1(zMatchesAnyRoute, onNavigateBack, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1805480520, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function3
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                    return uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar$lambda$0$2(z4, onClearCartIconClick, z2, (androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), 0.0f, null, topAppBarColorsM3957topAppBarColors5tl4gsc, null, composerStartRestartGroup, 3462, 178);
            uhggroup.iceskating.app.ui.theme.BordersKt.m11515ControlDivideriJQMabo(null, 0L, composerStartRestartGroup, 0, 3);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar$lambda$1(navDestination, z2, onClearCartIconClick, onNavigateBack, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppTopBar$lambda$0$0(uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.navigation.NavDestination navDestination, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        java.lang.String strStringResource;
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C60@2550L884:AppTopBar.kt#cp3yd8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(201647901, i, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBar.<anonymous>.<anonymous> (AppTopBar.kt:60)");
            }
            androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
            androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composer, 48);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, companion);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1319184650, "C62@2665L32,61@2624L369,70@3015L53,75@3276L10,72@3090L326:AppTopBar.kt#cp3yd8");
            androidx.compose.foundation.ImageKt.Image(androidx.compose.ui.res.PainterResources_androidKt.painterResource(uhggroup.iceskating.app.R.drawable.icon, composer, 0), (java.lang.String) null, androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11617getCornerRadiusD9Ej5fM())), (androidx.compose.ui.Alignment) null, androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop(), 0.0f, (androidx.compose.ui.graphics.ColorFilter) null, composer, androidx.compose.ui.graphics.painter.Painter.$stable | 24624, androidx.core.location.LocationRequestCompat.QUALITY_LOW_POWER);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11619getItemSpacingD9Ej5fM()), composer, 0);
            java.lang.Integer num = uhggroup.iceskating.app.ui.composable.approot.topbar.TopBarTitlesKt.topBarTitleRes(navDestination);
            if (num == null) {
                composer.startReplaceGroup(1319695590);
                composer.endReplaceGroup();
                strStringResource = null;
            } else {
                composer.startReplaceGroup(1319695591);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "*73@3169L18");
                strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(num.intValue(), composer, 0);
                composer.endReplaceGroup();
            }
            if (strStringResource == null) {
                strStringResource = "";
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(strStringResource, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, androidx.compose.ui.text.style.TextOverflow.INSTANCE.m8787getEllipsisgIe3tQ8(), false, 1, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getTitleLarge(), composer, 0, 24960, 110590);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppTopBar$lambda$0$2(boolean z, final kotlin.jvm.functions.Function0 function0, boolean z2, androidx.compose.foundation.layout.RowScope TopAppBar, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(TopAppBar, "$this$TopAppBar");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppTopBar.kt#cp3yd8");
        if (composer.shouldExecute((i & 17) != 16, i & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1805480520, i, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBar.<anonymous>.<anonymous> (AppTopBar.kt:83)");
            }
            if (z) {
                composer.startReplaceGroup(1194779872);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "85@3577L26,88@3782L11,87@3707L119,84@3531L626");
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -100004510, "CC(remember):AppTopBar.kt#9igjgp");
                boolean zChanged = composer.changed(function0);
                java.lang.Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar$lambda$0$2$0$0(function0);
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.material3.IconButtonKt.IconButton((kotlin.jvm.functions.Function0) objRememberedValue, null, z2, androidx.compose.material3.IconButtonDefaults.INSTANCE.m2983iconButtonColorsro_MJ88(0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getError(), 0L, 0L, composer, androidx.compose.material3.IconButtonDefaults.$stable << 12, 13), null, null, uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.INSTANCE.m11457getLambda$1290821457$app_release(), composer, 1572864, 50);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(1195419898);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppTopBar$lambda$0$2$0$0(kotlin.jvm.functions.Function0 function0) {
        function0.invoke();
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppTopBar$lambda$0$1(boolean z, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppTopBar.kt#cp3yd8");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-934296545, i, -1, "uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBar.<anonymous>.<anonymous> (AppTopBar.kt:101)");
            }
            if (z) {
                composer.startReplaceGroup(2054724712);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "102@4282L371");
                androidx.compose.material3.IconButtonKt.IconButton(function0, null, false, null, null, null, uhggroup.iceskating.app.ui.composable.approot.topbar.ComposableSingletons$AppTopBarKt.INSTANCE.getLambda$1862759896$app_release(), composer, 1572864, 62);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(2055119683);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }
}
