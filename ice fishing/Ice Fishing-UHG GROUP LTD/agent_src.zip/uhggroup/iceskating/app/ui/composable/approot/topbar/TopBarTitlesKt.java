package uhggroup.iceskating.app.ui.composable.approot.topbar;

/* compiled from: TopBarTitles.kt */
@kotlin.Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0019\u0010\u0006\u001a\u0004\u0018\u00010\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0000¢\u0006\u0002\u0010\n\"\"\u0010\u0000\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00030\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005¨\u0006\u000b"}, d2 = {"canNavigateBackRoutes", "", "Lkotlin/reflect/KClass;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "getCanNavigateBackRoutes", "()Ljava/util/List;", "topBarTitleRes", "", "currentDestination", "Landroidx/navigation/NavDestination;", "(Landroidx/navigation/NavDestination;)Ljava/lang/Integer;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class TopBarTitlesKt {
    private static final java.util.List<kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> canNavigateBackRoutes = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new kotlin.reflect.KClass[]{kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.class), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout.class)});

    public static final java.util.List<kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> getCanNavigateBackRoutes() {
        return canNavigateBackRoutes;
    }

    public static final java.lang.Integer topBarTitleRes(androidx.navigation.NavDestination navDestination) {
        if (navDestination == null) {
            return null;
        }
        java.util.Iterator<androidx.navigation.NavDestination> it = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_home_title);
            }
        }
        java.util.Iterator<androidx.navigation.NavDestination> it2 = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it2.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it2.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_product_details_title);
            }
        }
        java.util.Iterator<androidx.navigation.NavDestination> it3 = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it3.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it3.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_cart_title);
            }
        }
        java.util.Iterator<androidx.navigation.NavDestination> it4 = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it4.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it4.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_checkout_title);
            }
        }
        java.util.Iterator<androidx.navigation.NavDestination> it5 = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it5.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it5.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_orders_title);
            }
        }
        java.util.Iterator<androidx.navigation.NavDestination> it6 = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination).iterator();
        while (it6.hasNext()) {
            if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it6.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings.class))) {
                return java.lang.Integer.valueOf(uhggroup.iceskating.app.R.string.ics_top_bar_settings_title);
            }
        }
        return null;
    }
}
