package uhggroup.iceskating.app.ui.composable.screen.shared;

/* compiled from: DataEmptyContent.kt */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aC\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0005H\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"DataEmptyContent", "", "modifier", "Landroidx/compose/ui/Modifier;", "primaryText", "", "secondaryText", "icon", "Landroidx/compose/ui/graphics/painter/Painter;", "iconContentDescription", "(Landroidx/compose/ui/Modifier;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/graphics/painter/Painter;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DataEmptyContentKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit DataEmptyContent$lambda$1(androidx.compose.ui.Modifier modifier, java.lang.String str, java.lang.String str2, androidx.compose.ui.graphics.painter.Painter painter, java.lang.String str3, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        DataEmptyContent(modifier, str, str2, painter, str3, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0089  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x02f5  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0302  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void DataEmptyContent(androidx.compose.ui.Modifier modifier, final java.lang.String primaryText, java.lang.String str, androidx.compose.ui.graphics.painter.Painter painter, java.lang.String str2, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        java.lang.String str3;
        int i4;
        int i5;
        java.lang.String str4;
        int i6;
        final androidx.compose.ui.graphics.painter.Painter painter2;
        final androidx.compose.ui.Modifier modifier3;
        final java.lang.String str5;
        final java.lang.String str6;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.ui.Modifier modifier4;
        java.lang.Object obj;
        androidx.compose.ui.graphics.painter.Painter painter3;
        java.lang.String str7;
        java.lang.String str8;
        androidx.compose.ui.graphics.painter.Painter painter4 = painter;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(primaryText, "primaryText");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-508845423);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(DataEmptyContent)N(modifier,primaryText,secondaryText,icon,iconContentDescription)26@935L1095:DataEmptyContent.kt#kegtjg");
        int i7 = i2 & 1;
        if (i7 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(primaryText) ? 32 : 16;
        }
        int i8 = i2 & 4;
        if (i8 != 0) {
            i3 |= 384;
        } else {
            if ((i & 384) == 0) {
                str3 = str;
                i3 |= composerStartRestartGroup.changed(str3) ? 256 : 128;
            }
            i4 = i2 & 8;
            if (i4 == 0) {
                i3 |= 3072;
            } else if ((i & 3072) == 0) {
                i3 |= (i & 4096) == 0 ? composerStartRestartGroup.changed(painter4) : composerStartRestartGroup.changedInstance(painter4) ? 2048 : 1024;
            }
            i5 = i2 & 16;
            if (i5 != 0) {
                if ((i & 24576) == 0) {
                    str4 = str2;
                    i3 |= composerStartRestartGroup.changed(str4) ? 16384 : 8192;
                }
                i6 = i3;
                if (composerStartRestartGroup.shouldExecute((i6 & 9363) != 9362, i6 & 1)) {
                    androidx.compose.ui.Modifier.Companion companion = i7 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                    java.lang.String str9 = i8 != 0 ? null : str3;
                    if (i4 != 0) {
                        painter4 = null;
                    }
                    java.lang.String str10 = i5 == 0 ? str4 : null;
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventStart(-508845423, i6, -1, "uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContent (DataEmptyContent.kt:25)");
                    }
                    androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical center = androidx.compose.foundation.layout.Arrangement.INSTANCE.getCenter();
                    androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(center, centerHorizontally, composerStartRestartGroup, 54);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                    int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                    if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composerStartRestartGroup.startReusableNode();
                    if (composerStartRestartGroup.getInserting()) {
                        composerStartRestartGroup.createNode(constructor);
                    } else {
                        composerStartRestartGroup.useNode();
                    }
                    androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                    androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                    androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -681031510, "C38@1253L40,43@1435L11,46@1564L10,40@1303L293:DataEmptyContent.kt#kegtjg");
                    if (painter4 == null) {
                        composerStartRestartGroup.startReplaceGroup(-681049957);
                        composerStartRestartGroup.endReplaceGroup();
                        painter3 = painter4;
                        modifier4 = companion;
                        str7 = str10;
                        obj = null;
                    } else {
                        composerStartRestartGroup.startReplaceGroup(-681049956);
                        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "*32@1122L111");
                        modifier4 = companion;
                        androidx.compose.ui.graphics.painter.Painter painter5 = painter4;
                        obj = null;
                        androidx.compose.foundation.ImageKt.Image(painter5, str10, (androidx.compose.ui.Modifier) null, (androidx.compose.ui.Alignment) null, (androidx.compose.ui.layout.ContentScale) null, 0.0f, (androidx.compose.ui.graphics.ColorFilter) null, composerStartRestartGroup, androidx.compose.ui.graphics.painter.Painter.$stable | ((i6 >> 9) & 112), 124);
                        painter3 = painter5;
                        str7 = str10;
                        composerStartRestartGroup.endReplaceGroup();
                    }
                    float f = 6;
                    androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f)), composerStartRestartGroup, 6);
                    androidx.compose.material3.TextKt.m3717TextNvy7gAk(primaryText, androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f), 0.0f, 2, obj), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), null, androidx.compose.ui.unit.TextUnitKt.getSp(18), null, null, null, 0L, null, androidx.compose.ui.text.style.TextAlign.m8722boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m8729getCentere0LSkKk()), 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getTitleLarge(), composerStartRestartGroup, ((i6 >> 3) & 14) | 24624, 0, 130024);
                    composerStartRestartGroup = composerStartRestartGroup;
                    if (str9 == null) {
                        composerStartRestartGroup.startReplaceGroup(-680528909);
                        composerStartRestartGroup.endReplaceGroup();
                        str8 = str9;
                    } else {
                        composerStartRestartGroup.startReplaceGroup(-680528908);
                        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "*50@1639L41,55@1830L11,58@1978L10,52@1694L320");
                        float f2 = 12;
                        androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f2)), composerStartRestartGroup, 6);
                        str8 = str9;
                        androidx.compose.material3.TextKt.m3717TextNvy7gAk(str8, androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f2), 0.0f, 2, null), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), null, androidx.compose.ui.unit.TextUnitKt.getSp(16), null, null, null, 0L, null, androidx.compose.ui.text.style.TextAlign.m8722boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m8729getCentere0LSkKk()), 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getBodyMedium(), composerStartRestartGroup, 24624, 0, 130024);
                        composerStartRestartGroup = composerStartRestartGroup;
                        composerStartRestartGroup.endReplaceGroup();
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    composerStartRestartGroup.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    str5 = str8;
                    modifier3 = modifier4;
                    painter2 = painter3;
                    str6 = str7;
                } else {
                    composerStartRestartGroup.skipToGroupEnd();
                    painter2 = painter4;
                    modifier3 = modifier2;
                    str5 = str3;
                    str6 = str4;
                }
                scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
                if (scopeUpdateScopeEndRestartGroup != null) {
                    scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object invoke(java.lang.Object obj2, java.lang.Object obj3) {
                            return uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt.DataEmptyContent$lambda$1(modifier3, primaryText, str5, painter2, str6, i, i2, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                        }
                    });
                    return;
                }
                return;
            }
            i3 |= 24576;
            str4 = str2;
            i6 = i3;
            if (composerStartRestartGroup.shouldExecute((i6 & 9363) != 9362, i6 & 1)) {
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup != null) {
            }
        }
        str3 = str;
        i4 = i2 & 8;
        if (i4 == 0) {
        }
        i5 = i2 & 16;
        if (i5 != 0) {
        }
        str4 = str2;
        i6 = i3;
        if (composerStartRestartGroup.shouldExecute((i6 & 9363) != 9362, i6 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
        }
    }
}
