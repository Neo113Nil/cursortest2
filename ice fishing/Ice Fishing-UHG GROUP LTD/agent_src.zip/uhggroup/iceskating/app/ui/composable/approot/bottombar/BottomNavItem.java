package uhggroup.iceskating.app.ui.composable.approot.bottombar;

/* compiled from: BottomNavItem.kt */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0014\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0017\u001a\u00020\u0003HÖ\u0081\u0004J\n\u0010\u0018\u001a\u00020\u0019HÖ\u0081\u0004R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Luhggroup/iceskating/app/ui/composable/approot/bottombar/BottomNavItem;", "", "titleRes", "", "icon", "Landroidx/compose/ui/graphics/vector/ImageVector;", "route", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "(ILandroidx/compose/ui/graphics/vector/ImageVector;Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;)V", "getTitleRes", "()I", "getIcon", "()Landroidx/compose/ui/graphics/vector/ImageVector;", "getRoute", "()Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final /* data */ class BottomNavItem {
    public static final int $stable = 0;
    private final androidx.compose.ui.graphics.vector.ImageVector icon;
    private final uhggroup.iceskating.app.ui.composable.navigation.NavRoute route;
    private final int titleRes;

    public static /* synthetic */ uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem copy$default(uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem, int i, androidx.compose.ui.graphics.vector.ImageVector imageVector, uhggroup.iceskating.app.ui.composable.navigation.NavRoute navRoute, int i2, java.lang.Object obj) {
        if ((i2 & 1) != 0) {
            i = bottomNavItem.titleRes;
        }
        if ((i2 & 2) != 0) {
            imageVector = bottomNavItem.icon;
        }
        if ((i2 & 4) != 0) {
            navRoute = bottomNavItem.route;
        }
        return bottomNavItem.copy(i, imageVector, navRoute);
    }

    /* renamed from: component1, reason: from getter */
    public final int getTitleRes() {
        return this.titleRes;
    }

    /* renamed from: component2, reason: from getter */
    public final androidx.compose.ui.graphics.vector.ImageVector getIcon() {
        return this.icon;
    }

    /* renamed from: component3, reason: from getter */
    public final uhggroup.iceskating.app.ui.composable.navigation.NavRoute getRoute() {
        return this.route;
    }

    public final uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem copy(int titleRes, androidx.compose.ui.graphics.vector.ImageVector icon, uhggroup.iceskating.app.ui.composable.navigation.NavRoute route) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icon, "icon");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(route, "route");
        return new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem(titleRes, icon, route);
    }

    public boolean equals(java.lang.Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem)) {
            return false;
        }
        uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem bottomNavItem = (uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem) other;
        return this.titleRes == bottomNavItem.titleRes && kotlin.jvm.internal.Intrinsics.areEqual(this.icon, bottomNavItem.icon) && kotlin.jvm.internal.Intrinsics.areEqual(this.route, bottomNavItem.route);
    }

    public int hashCode() {
        return (((java.lang.Integer.hashCode(this.titleRes) * 31) + this.icon.hashCode()) * 31) + this.route.hashCode();
    }

    public java.lang.String toString() {
        return "BottomNavItem(titleRes=" + this.titleRes + ", icon=" + this.icon + ", route=" + this.route + ")";
    }

    public BottomNavItem(int i, androidx.compose.ui.graphics.vector.ImageVector icon, uhggroup.iceskating.app.ui.composable.navigation.NavRoute route) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icon, "icon");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(route, "route");
        this.titleRes = i;
        this.icon = icon;
        this.route = route;
    }

    public final int getTitleRes() {
        return this.titleRes;
    }

    public final androidx.compose.ui.graphics.vector.ImageVector getIcon() {
        return this.icon;
    }

    public final uhggroup.iceskating.app.ui.composable.navigation.NavRoute getRoute() {
        return this.route;
    }
}
