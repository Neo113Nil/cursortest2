package uhggroup.iceskating.app.ui.composable.screen.cart;

/* compiled from: ICSCartScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ICSCartScreenKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1546875243 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1546875243, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt.lambda_1546875243$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1546875243$app_release() {
        return lambda$1546875243;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1546875243$lambda$0(androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C108@4265L54,111@4468L7,107@4213L282:ICSCartScreen.kt#8m9skv");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1546875243, i, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt.lambda$1546875243.<anonymous> (ICSCartScreen.kt:107)");
            }
            java.lang.String strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.cart_state_empty_primary_text, composer, 0);
            androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
            androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composer.consume(localContentBottomPadding);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt.DataEmptyContent(androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(modifierFillMaxSize$default, 0.0f, 0.0f, 0.0f, ((androidx.compose.ui.unit.Dp) objConsume).m8865unboximpl(), 7, null), strStringResource, null, null, null, composer, 0, 28);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
