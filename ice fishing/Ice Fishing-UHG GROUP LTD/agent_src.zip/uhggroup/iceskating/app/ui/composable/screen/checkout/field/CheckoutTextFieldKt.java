package uhggroup.iceskating.app.ui.composable.screen.checkout.field;

/* compiled from: CheckoutTextField.kt */
@kotlin.Metadata(d1 = {"\u0000H\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0085\u0001\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00050\t2\u0006\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u000e2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u00112\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u00072\b\b\u0002\u0010\u0013\u001a\u00020\u00142\b\b\u0002\u0010\u0015\u001a\u00020\u00162\b\b\u0002\u0010\u0017\u001a\u00020\u0018H\u0007¢\u0006\u0002\u0010\u0019\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\u001a"}, d2 = {"IconSize", "Landroidx/compose/ui/unit/Dp;", "F", "LabelSpacing", "CheckoutTextField", "", "input", "", "onInputChange", "Lkotlin/Function1;", "labelText", "modifier", "Landroidx/compose/ui/Modifier;", "enabled", "", "isError", "leadingIcon", "Landroidx/compose/ui/graphics/vector/ImageVector;", "supportingText", "labelStyle", "Landroidx/compose/ui/text/TextStyle;", "keyboardOptions", "Landroidx/compose/foundation/text/KeyboardOptions;", "keyboardActions", "Landroidx/compose/foundation/text/KeyboardActions;", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;Landroidx/compose/runtime/Composer;III)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CheckoutTextFieldKt {
    private static final float IconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(18);
    private static final float LabelSpacing = androidx.compose.ui.unit.Dp.m8851constructorimpl(6);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutTextField$lambda$1(java.lang.String str, kotlin.jvm.functions.Function1 function1, java.lang.String str2, androidx.compose.ui.Modifier modifier, boolean z, boolean z2, androidx.compose.ui.graphics.vector.ImageVector imageVector, java.lang.String str3, androidx.compose.ui.text.TextStyle textStyle, androidx.compose.foundation.text.KeyboardOptions keyboardOptions, androidx.compose.foundation.text.KeyboardActions keyboardActions, int i, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) {
        CheckoutTextField(str, function1, str2, modifier, z, z2, imageVector, str3, textStyle, keyboardOptions, keyboardActions, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x016d  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x0630  */
    /* JADX WARN: Removed duplicated region for block: B:187:0x0646  */
    /* JADX WARN: Removed duplicated region for block: B:189:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00b2  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x00ee  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x010f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void CheckoutTextField(final java.lang.String input, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onInputChange, final java.lang.String labelText, androidx.compose.ui.Modifier modifier, boolean z, boolean z2, androidx.compose.ui.graphics.vector.ImageVector imageVector, java.lang.String str, androidx.compose.ui.text.TextStyle textStyle, androidx.compose.foundation.text.KeyboardOptions keyboardOptions, androidx.compose.foundation.text.KeyboardActions keyboardActions, androidx.compose.runtime.Composer composer, final int i, final int i2, final int i3) {
        int i4;
        androidx.compose.ui.Modifier modifier2;
        int i5;
        boolean z3;
        int i6;
        boolean z4;
        int i7;
        int i8;
        java.lang.String str2;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.graphics.vector.ImageVector imageVector2;
        final androidx.compose.foundation.text.KeyboardOptions keyboardOptions2;
        final java.lang.String str3;
        final androidx.compose.ui.Modifier modifier3;
        final boolean z5;
        final boolean z6;
        final androidx.compose.ui.text.TextStyle textStyle2;
        final androidx.compose.foundation.text.KeyboardActions keyboardActions2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.ui.text.TextStyle labelLarge;
        int i15;
        androidx.compose.foundation.text.KeyboardActions keyboardActions3;
        androidx.compose.ui.text.TextStyle textStyle3;
        androidx.compose.foundation.text.KeyboardOptions keyboardOptions3;
        boolean z7;
        boolean z8;
        androidx.compose.ui.graphics.vector.ImageVector imageVector3;
        androidx.compose.ui.Modifier modifier4;
        long onSurfaceVariant;
        androidx.compose.ui.graphics.vector.ImageVector imageVector4;
        androidx.compose.runtime.Composer composer3;
        long j;
        androidx.compose.runtime.internal.ComposableLambda composableLambdaRememberComposableLambda;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(input, "input");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onInputChange, "onInputChange");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(labelText, "labelText");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1760410557);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CheckoutTextField)N(input,onInputChange,labelText,modifier,enabled,isError,leadingIcon,supportingText,labelStyle,keyboardOptions,keyboardActions)42@1693L7,50@1853L2439:CheckoutTextField.kt#8is3vj");
        if ((i & 6) == 0) {
            i4 = (composerStartRestartGroup.changed(input) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            i4 |= composerStartRestartGroup.changedInstance(onInputChange) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i4 |= composerStartRestartGroup.changed(labelText) ? 256 : 128;
        }
        int i16 = i3 & 8;
        if (i16 != 0) {
            i4 |= 3072;
        } else {
            if ((i & 3072) == 0) {
                modifier2 = modifier;
                i4 |= composerStartRestartGroup.changed(modifier2) ? 2048 : 1024;
            }
            i5 = i3 & 16;
            if (i5 == 0) {
                i4 |= 24576;
            } else {
                if ((i & 24576) == 0) {
                    z3 = z;
                    i4 |= composerStartRestartGroup.changed(z3) ? 16384 : 8192;
                }
                i6 = i3 & 32;
                if (i6 != 0) {
                    i4 |= androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE;
                } else {
                    if ((196608 & i) == 0) {
                        z4 = z2;
                        i4 |= composerStartRestartGroup.changed(z4) ? 131072 : 65536;
                    }
                    i7 = i3 & 64;
                    if (i7 == 0) {
                        i4 |= 1572864;
                    } else if ((i & 1572864) == 0) {
                        i4 |= composerStartRestartGroup.changed(imageVector) ? 1048576 : 524288;
                    }
                    i8 = i3 & 128;
                    if (i8 == 0) {
                        i4 |= 12582912;
                        str2 = str;
                    } else {
                        str2 = str;
                        if ((i & 12582912) == 0) {
                            i4 |= composerStartRestartGroup.changed(str2) ? 8388608 : 4194304;
                        }
                    }
                    if ((i & 100663296) == 0) {
                        i4 |= ((i3 & 256) == 0 && composerStartRestartGroup.changed(textStyle)) ? 67108864 : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasAuxSlotFlag;
                    }
                    i9 = i3 & 512;
                    if (i9 != 0) {
                        if ((i & 805306368) == 0) {
                            i10 = i9;
                            i4 |= composerStartRestartGroup.changed(keyboardOptions) ? androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasMovableContentFlag : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.IsMovableContentFlag;
                        }
                        i11 = i3 & 1024;
                        if (i11 != 0) {
                            i13 = i4;
                            i14 = i2 | 6;
                            i12 = i11;
                        } else if ((i2 & 6) == 0) {
                            i12 = i11;
                            i13 = i4;
                            i14 = i2 | (composerStartRestartGroup.changed(keyboardActions) ? 4 : 2);
                        } else {
                            i12 = i11;
                            i13 = i4;
                            i14 = i2;
                        }
                        if (composerStartRestartGroup.shouldExecute(((i13 & 306783379) == 306783378 && (i14 & 3) == 2) ? false : true, i13 & 1)) {
                            composerStartRestartGroup.startDefaults();
                            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "38@1509L10");
                            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                                composerStartRestartGroup.skipToGroupEnd();
                                if ((i3 & 256) != 0) {
                                    imageVector3 = imageVector;
                                    textStyle3 = textStyle;
                                    keyboardOptions3 = keyboardOptions;
                                    keyboardActions3 = keyboardActions;
                                    i15 = i13 & (-234881025);
                                } else {
                                    imageVector3 = imageVector;
                                    textStyle3 = textStyle;
                                    keyboardOptions3 = keyboardOptions;
                                    keyboardActions3 = keyboardActions;
                                    i15 = i13;
                                }
                                modifier4 = modifier2;
                                z7 = z3;
                                z8 = z4;
                            } else {
                                if (i16 != 0) {
                                    modifier2 = androidx.compose.ui.Modifier.INSTANCE;
                                }
                                if (i5 != 0) {
                                    z3 = true;
                                }
                                if (i6 != 0) {
                                    z4 = false;
                                }
                                androidx.compose.ui.graphics.vector.ImageVector imageVector5 = i7 != 0 ? null : imageVector;
                                if (i8 != 0) {
                                    str2 = null;
                                }
                                if ((i3 & 256) != 0) {
                                    labelLarge = androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getLabelLarge();
                                    i15 = i13 & (-234881025);
                                } else {
                                    labelLarge = textStyle;
                                    i15 = i13;
                                }
                                androidx.compose.foundation.text.KeyboardOptions keyboardOptions4 = i10 != 0 ? androidx.compose.foundation.text.KeyboardOptions.INSTANCE.getDefault() : keyboardOptions;
                                if (i12 != 0) {
                                    textStyle3 = labelLarge;
                                    keyboardOptions3 = keyboardOptions4;
                                    z7 = z3;
                                    keyboardActions3 = androidx.compose.foundation.text.KeyboardActions.INSTANCE.getDefault();
                                } else {
                                    keyboardActions3 = keyboardActions;
                                    textStyle3 = labelLarge;
                                    keyboardOptions3 = keyboardOptions4;
                                    z7 = z3;
                                }
                                z8 = z4;
                                imageVector3 = imageVector5;
                                modifier4 = modifier2;
                            }
                            composerStartRestartGroup.endDefaults();
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventStart(-1760410557, i15, i14, "uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextField (CheckoutTextField.kt:41)");
                            }
                            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                            uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                            if (z8) {
                                composerStartRestartGroup.startReplaceGroup(1455284016);
                                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "45@1760L11");
                                onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getError();
                                composerStartRestartGroup.endReplaceGroup();
                            } else {
                                composerStartRestartGroup.startReplaceGroup(1455336933);
                                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "47@1813L11");
                                onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant();
                                composerStartRestartGroup.endReplaceGroup();
                            }
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifier4);
                            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                            androidx.compose.ui.Modifier modifier5 = modifier4;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                androidx.compose.runtime.ComposablesKt.invalidApplier();
                            }
                            composerStartRestartGroup.startReusableNode();
                            if (composerStartRestartGroup.getInserting()) {
                                composerStartRestartGroup.createNode(constructor);
                            } else {
                                composerStartRestartGroup.useNode();
                            }
                            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -762928613, "C51@1891L556,70@2457L48,91@3272L11,92@3349L11,93@3422L11,94@3492L11,95@3566L11,96@3636L11,97@3710L11,98@3784L11,99@3854L11,100@3932L11,101@4023L11,102@4110L11,103@4173L11,104@4243L11,90@3210L1065,72@2515L1771:CheckoutTextField.kt#8is3vj");
                            androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
                            androidx.compose.ui.Modifier.Companion companion = androidx.compose.ui.Modifier.INSTANCE;
                            androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composerStartRestartGroup, 48);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                            int iHashCode2 = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                            androidx.compose.ui.Modifier modifierMaterializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                                androidx.compose.runtime.ComposablesKt.invalidApplier();
                            }
                            composerStartRestartGroup.startReusableNode();
                            if (composerStartRestartGroup.getInserting()) {
                                composerStartRestartGroup.createNode(constructor2);
                            } else {
                                composerStartRestartGroup.useNode();
                            }
                            androidx.compose.runtime.Composer composerM5083constructorimpl2 = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, java.lang.Integer.valueOf(iHashCode2), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, modifierMaterializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1669303782, "C63@2312L125:CheckoutTextField.kt#8is3vj");
                            if (imageVector3 != null) {
                                composerStartRestartGroup.startReplaceGroup(-1669284067);
                                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "53@2000L212,60@2230L54");
                                androidx.compose.ui.graphics.vector.ImageVector imageVector6 = imageVector3;
                                long j2 = onSurfaceVariant;
                                androidx.compose.material3.IconKt.m3011Iconww6aTOc(imageVector6, (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), j2, composerStartRestartGroup, ((i15 >> 18) & 14) | 432, 0);
                                imageVector4 = imageVector6;
                                j = j2;
                                composer3 = composerStartRestartGroup;
                                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11622getTightSpacingD9Ej5fM()), composer3, 0);
                                composer3.endReplaceGroup();
                            } else {
                                imageVector4 = imageVector3;
                                composer3 = composerStartRestartGroup;
                                j = onSurfaceVariant;
                                composer3.startReplaceGroup(-1668980391);
                                composer3.endReplaceGroup();
                            }
                            int i17 = i15 >> 6;
                            int i18 = i15 >> 3;
                            int i19 = i14;
                            final java.lang.String str4 = str2;
                            int i20 = i15;
                            androidx.compose.runtime.Composer composer4 = composer3;
                            androidx.compose.material3.TextKt.m3717TextNvy7gAk(labelText, null, j, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, textStyle3, composer4, i17 & 14, i18 & 29360128, 131066);
                            androidx.compose.ui.text.TextStyle textStyle4 = textStyle3;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                            composer4.endNode();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer4);
                            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, LabelSpacing), composer4, 6);
                            androidx.compose.ui.Modifier modifierFillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                            if (str4 == null) {
                                composer4.startReplaceGroup(-762165860);
                                composer4.endReplaceGroup();
                                composableLambdaRememberComposableLambda = null;
                            } else {
                                composer4.startReplaceGroup(-762165859);
                                androidx.compose.runtime.ComposerKt.sourceInformation(composer4, "*78@2758L172");
                                composableLambdaRememberComposableLambda = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(60278129, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function2
                                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                                        return uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt.CheckoutTextField$lambda$0$1$0(str4, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                                    }
                                }, composer4, 54);
                                composer4.endReplaceGroup();
                            }
                            boolean z9 = z7;
                            boolean z10 = z8;
                            androidx.compose.foundation.text.KeyboardOptions keyboardOptions5 = keyboardOptions3;
                            androidx.compose.foundation.text.KeyboardActions keyboardActions4 = keyboardActions3;
                            androidx.compose.material3.OutlinedTextFieldKt.OutlinedTextField(input, onInputChange, modifierFillMaxWidth$default, z9, false, (androidx.compose.ui.text.TextStyle) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) null, (kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit>) composableLambdaRememberComposableLambda, z10, (androidx.compose.ui.text.input.VisualTransformation) null, keyboardOptions5, keyboardActions4, true, 0, 0, (androidx.compose.foundation.interaction.MutableInteractionSource) null, (androidx.compose.ui.graphics.Shape) androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11617getCornerRadiusD9Ej5fM()), androidx.compose.material3.OutlinedTextFieldDefaults.INSTANCE.m3256colors0hiis_0(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getSurface(), 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getError(), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOutline(), 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getError(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer4, androidx.compose.material3.MaterialTheme.$stable).getError(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer4, 0, 0, 0, 0, 3072, 2147460164, 4084), composer4, (i20 & 14) | 384 | (i20 & 112) | (i18 & 7168), (i17 & 7168) | 12582912 | ((i20 >> 12) & 458752) | ((i19 << 18) & 3670016), 0, 1855472);
                            composer2 = composer4;
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                            composer2.endNode();
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                                androidx.compose.runtime.ComposerKt.traceEventEnd();
                            }
                            z5 = z9;
                            z6 = z10;
                            keyboardOptions2 = keyboardOptions5;
                            keyboardActions2 = keyboardActions4;
                            str3 = str4;
                            modifier3 = modifier5;
                            imageVector2 = imageVector4;
                            textStyle2 = textStyle4;
                        } else {
                            composer2 = composerStartRestartGroup;
                            composer2.skipToGroupEnd();
                            imageVector2 = imageVector;
                            keyboardOptions2 = keyboardOptions;
                            str3 = str2;
                            modifier3 = modifier2;
                            z5 = z3;
                            z6 = z4;
                            textStyle2 = textStyle;
                            keyboardActions2 = keyboardActions;
                        }
                        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
                        if (scopeUpdateScopeEndRestartGroup != null) {
                            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt$$ExternalSyntheticLambda1
                                @Override // kotlin.jvm.functions.Function2
                                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                                    return uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt.CheckoutTextField$lambda$1(input, onInputChange, labelText, modifier3, z5, z6, imageVector2, str3, textStyle2, keyboardOptions2, keyboardActions2, i, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                                }
                            });
                            return;
                        }
                        return;
                    }
                    i4 |= 805306368;
                    i10 = i9;
                    i11 = i3 & 1024;
                    if (i11 != 0) {
                    }
                    if (composerStartRestartGroup.shouldExecute(((i13 & 306783379) == 306783378 && (i14 & 3) == 2) ? false : true, i13 & 1)) {
                    }
                    scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                    }
                }
                z4 = z2;
                i7 = i3 & 64;
                if (i7 == 0) {
                }
                i8 = i3 & 128;
                if (i8 == 0) {
                }
                if ((i & 100663296) == 0) {
                }
                i9 = i3 & 512;
                if (i9 != 0) {
                }
                i10 = i9;
                i11 = i3 & 1024;
                if (i11 != 0) {
                }
                if (composerStartRestartGroup.shouldExecute(((i13 & 306783379) == 306783378 && (i14 & 3) == 2) ? false : true, i13 & 1)) {
                }
                scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
                if (scopeUpdateScopeEndRestartGroup != null) {
                }
            }
            z3 = z;
            i6 = i3 & 32;
            if (i6 != 0) {
            }
            z4 = z2;
            i7 = i3 & 64;
            if (i7 == 0) {
            }
            i8 = i3 & 128;
            if (i8 == 0) {
            }
            if ((i & 100663296) == 0) {
            }
            i9 = i3 & 512;
            if (i9 != 0) {
            }
            i10 = i9;
            i11 = i3 & 1024;
            if (i11 != 0) {
            }
            if (composerStartRestartGroup.shouldExecute(((i13 & 306783379) == 306783378 && (i14 & 3) == 2) ? false : true, i13 & 1)) {
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup != null) {
            }
        }
        modifier2 = modifier;
        i5 = i3 & 16;
        if (i5 == 0) {
        }
        z3 = z;
        i6 = i3 & 32;
        if (i6 != 0) {
        }
        z4 = z2;
        i7 = i3 & 64;
        if (i7 == 0) {
        }
        i8 = i3 & 128;
        if (i8 == 0) {
        }
        if ((i & 100663296) == 0) {
        }
        i9 = i3 & 512;
        if (i9 != 0) {
        }
        i10 = i9;
        i11 = i3 & 1024;
        if (i11 != 0) {
        }
        if (composerStartRestartGroup.shouldExecute(((i13 & 306783379) == 306783378 && (i14 & 3) == 2) ? false : true, i13 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutTextField$lambda$0$1$0(java.lang.String str, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C81@2869L10,79@2780L132:CheckoutTextField.kt#8is3vj");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(60278129, i, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextField.<anonymous>.<anonymous>.<anonymous> (CheckoutTextField.kt:79)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getBodySmall(), composer, 0, 0, 131070);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
