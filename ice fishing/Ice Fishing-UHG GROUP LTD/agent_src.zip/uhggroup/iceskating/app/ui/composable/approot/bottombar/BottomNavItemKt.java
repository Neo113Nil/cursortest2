package uhggroup.iceskating.app.ui.composable.approot.bottombar;

/* compiled from: BottomNavItem.kt */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u001a\u0010\u0000\u001a\u00020\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0000¨\u0006\u0006"}, d2 = {"isSelectedDestination", "", "destination", "Landroidx/navigation/NavDestination;", "route", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class BottomNavItemKt {
    public static final boolean isSelectedDestination(androidx.navigation.NavDestination navDestination, uhggroup.iceskating.app.ui.composable.navigation.NavRoute route) {
        kotlin.sequences.Sequence<androidx.navigation.NavDestination> hierarchy;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(route, "route");
        if (navDestination != null && (hierarchy = androidx.navigation.NavDestination.INSTANCE.getHierarchy(navDestination)) != null) {
            java.util.Iterator<androidx.navigation.NavDestination> it = hierarchy.iterator();
            while (it.hasNext()) {
                if (androidx.navigation.NavDestination.INSTANCE.hasRoute(it.next(), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(route.getClass()))) {
                    return true;
                }
            }
        }
        return false;
    }
}
