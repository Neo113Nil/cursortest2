package uhggroup.iceskating.app.ui.composable.screen.checkout.button;

/* compiled from: CheckoutConfirmButton.kt */
@kotlin.Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a-\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00060\n2\b\b\u0002\u0010\u000b\u001a\u00020\fH\u0007¢\u0006\u0002\u0010\r\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0004\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\u000e²\u0006\n\u0010\u000f\u001a\u00020\bX\u008a\u0084\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0001X\u008a\u0084\u0002"}, d2 = {"ButtonHeight", "Landroidx/compose/ui/unit/Dp;", "F", "BevelHeight", "IconSize", "CheckoutConfirmButton", "", "enabled", "", "onClick", "Lkotlin/Function0;", "modifier", "Landroidx/compose/ui/Modifier;", "(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release", "isPressed", "faceOffset"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CheckoutConfirmButtonKt {
    private static final float ButtonHeight = androidx.compose.ui.unit.Dp.m8851constructorimpl(52);
    private static final float BevelHeight = androidx.compose.ui.unit.Dp.m8851constructorimpl(6);
    private static final float IconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(20);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutConfirmButton$lambda$4(boolean z, kotlin.jvm.functions.Function0 function0, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        CheckoutConfirmButton(z, function0, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x04d0  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x04da  */
    /* JADX WARN: Removed duplicated region for block: B:97:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void CheckoutConfirmButton(final boolean z, final kotlin.jvm.functions.Function0<kotlin.Unit> onClick, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        float fM8851constructorimpl;
        long surfaceContainerHighest;
        long surfaceContainerHighest2;
        long onSurfaceVariant;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onClick, "onClick");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(111902004);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CheckoutConfirmButton)N(enabled,onClick,modifier)44@1766L7,46@1865L39,47@1944L25,49@1993L142,70@2613L1596:CheckoutConfirmButton.kt#i8xodn");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(z) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onClick) ? 32 : 16;
        }
        int i4 = i2 & 4;
        if (i4 == 0) {
            if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(111902004, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButton (CheckoutConfirmButton.kt:43)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeM1543RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11616getControlCornerRadiusD9Ej5fM());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 163651195, "CC(remember):CheckoutConfirmButton.kt#9igjgp");
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = androidx.compose.foundation.interaction.InteractionSourceKt.MutableInteractionSource();
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.foundation.interaction.MutableInteractionSource mutableInteractionSource = (androidx.compose.foundation.interaction.MutableInteractionSource) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.State<java.lang.Boolean> stateCollectIsPressedAsState = androidx.compose.foundation.interaction.PressInteractionKt.collectIsPressedAsState(mutableInteractionSource, composerStartRestartGroup, 6);
                if (!z || CheckoutConfirmButton$lambda$1(stateCollectIsPressedAsState)) {
                    fM8851constructorimpl = BevelHeight;
                } else {
                    fM8851constructorimpl = androidx.compose.ui.unit.Dp.m8851constructorimpl(0);
                }
                final androidx.compose.runtime.State<androidx.compose.ui.unit.Dp> stateM200animateDpAsStateAjpBEmI = androidx.compose.animation.core.AnimateAsStateKt.m200animateDpAsStateAjpBEmI(fM8851constructorimpl, null, "checkout_button_face_offset", null, composerStartRestartGroup, 384, 10);
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(778522621);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "55@2194L11");
                    surfaceContainerHighest = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getPrimary();
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(778577677);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "57@2249L11");
                    surfaceContainerHighest = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHighest();
                    composerStartRestartGroup.endReplaceGroup();
                }
                long j = surfaceContainerHighest;
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(778675730);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "60@2348L11");
                    surfaceContainerHighest2 = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnPrimaryContainer();
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(778741357);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "62@2414L11");
                    surfaceContainerHighest2 = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHighest();
                    composerStartRestartGroup.endReplaceGroup();
                }
                long j2 = surfaceContainerHighest2;
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(778842107);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "65@2516L11");
                    onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnPrimary();
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(778898868);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "67@2573L11");
                    onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant();
                    composerStartRestartGroup.endReplaceGroup();
                }
                long j3 = onSurfaceVariant;
                androidx.compose.ui.Modifier modifierFillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null);
                float f = ButtonHeight;
                androidx.compose.ui.Modifier modifierM1218height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(modifierFillMaxWidth$default, androidx.compose.ui.unit.Dp.m8851constructorimpl(f + BevelHeight));
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                androidx.compose.ui.Modifier modifier4 = companion;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1218height3ABfNKs);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1858862627, "C75@2739L232,89@3156L40,84@2981L1222:CheckoutConfirmButton.kt#i8xodn");
                androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShape = roundedCornerShapeM1543RoundedCornerShape0680j_4;
                androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(boxScopeInstance.align(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), f), androidx.compose.ui.Alignment.INSTANCE.getBottomCenter()), roundedCornerShape), j2, null, 2, null), composerStartRestartGroup, 0);
                androidx.compose.ui.Modifier modifierAlign = boxScopeInstance.align(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), f), androidx.compose.ui.Alignment.INSTANCE.getTopCenter());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 632785270, "CC(remember):CheckoutConfirmButton.kt#9igjgp");
                boolean zChanged = composerStartRestartGroup.changed(stateM200animateDpAsStateAjpBEmI);
                java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (zChanged || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButtonKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButtonKt.CheckoutConfirmButton$lambda$3$0$0(stateM200animateDpAsStateAjpBEmI, (androidx.compose.ui.unit.Density) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.Modifier modifierM366clickableO2vRcR0$default = androidx.compose.foundation.ClickableKt.m366clickableO2vRcR0$default(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.OffsetKt.offset(modifierAlign, (kotlin.jvm.functions.Function1) objRememberedValue2), roundedCornerShape), j, null, 2, null), mutableInteractionSource, null, z, null, androidx.compose.ui.semantics.Role.m8020boximpl(androidx.compose.ui.semantics.Role.INSTANCE.m8027getButtono7Vup1c()), onClick, 8, null);
                androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode2 = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM366clickableO2vRcR0$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor2);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl2 = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, measurePolicyMaybeCachedBoxMeasurePolicy2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, java.lang.Integer.valueOf(iHashCode2), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, modifierMaterializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance2 = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -439560702, "C101@3601L592:CheckoutConfirmButton.kt#i8xodn");
                androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
                androidx.compose.ui.Modifier.Companion companion2 = androidx.compose.ui.Modifier.INSTANCE;
                androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composerStartRestartGroup, 48);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode3 = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap3 = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier3 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion2);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor3 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor3);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl3 = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl3, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl3, currentCompositionLocalMap3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl3, java.lang.Integer.valueOf(iHashCode3), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl3, modifierMaterializeModifier3, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -362671174, "C102@3671L222,109@3911L39,112@4001L51,114@4138L10,111@3968L211:CheckoutConfirmButton.kt#i8xodn");
                androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.CheckKt.getCheck(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), j3, composerStartRestartGroup, 432, 0);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(8)), composerStartRestartGroup, 6);
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.button_confirm_order_label, composerStartRestartGroup, 0), null, j3, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getTitleMedium(), composerStartRestartGroup, 0, 0, 131066);
                composerStartRestartGroup = composerStartRestartGroup;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButtonKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.checkout.button.CheckoutConfirmButtonKt.CheckoutConfirmButton$lambda$4(z, onClick, modifier3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 384;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.ui.unit.IntOffset CheckoutConfirmButton$lambda$3$0$0(androidx.compose.runtime.State state, androidx.compose.ui.unit.Density offset) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(offset, "$this$offset");
        return androidx.compose.ui.unit.IntOffset.m8970boximpl(androidx.compose.ui.unit.IntOffset.m8973constructorimpl((offset.mo493roundToPx0680j_4(CheckoutConfirmButton$lambda$2(state)) & 4294967295L) | (0 << 32)));
    }

    private static final boolean CheckoutConfirmButton$lambda$1(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue().booleanValue();
    }

    private static final float CheckoutConfirmButton$lambda$2(androidx.compose.runtime.State<androidx.compose.ui.unit.Dp> state) {
        return state.getValue().m8865unboximpl();
    }
}
