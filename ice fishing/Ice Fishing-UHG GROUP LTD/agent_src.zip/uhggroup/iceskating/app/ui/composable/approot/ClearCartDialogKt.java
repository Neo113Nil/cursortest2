package uhggroup.iceskating.app.ui.composable.approot;

/* compiled from: ClearCartDialog.kt */
@kotlin.Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a3\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0005H\u0007¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"ClearCartDialog", "", "modifier", "Landroidx/compose/ui/Modifier;", "onConfirm", "Lkotlin/Function0;", "onDismiss", "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ClearCartDialogKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ClearCartDialog$lambda$2(androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ClearCartDialog(modifier, function0, function02, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final void ClearCartDialog(androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function0<kotlin.Unit> onConfirm, final kotlin.jvm.functions.Function0<kotlin.Unit> onDismiss, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.Modifier modifier3;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onConfirm, "onConfirm");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onDismiss, "onDismiss");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(295417985);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ClearCartDialog)N(modifier,onConfirm,onDismiss)25@880L11,40@1449L569,55@2044L326,21@718L1659:ClearCartDialog.kt#udo5m8");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onConfirm) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onDismiss) ? 256 : 128;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 147) != 146, i3 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
            modifier3 = modifier2;
        } else {
            androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(295417985, i3, -1, "uhggroup.iceskating.app.ui.composable.approot.ClearCartDialog (ClearCartDialog.kt:20)");
            }
            composer2 = composerStartRestartGroup;
            androidx.compose.material3.AndroidAlertDialog_androidKt.m2434AlertDialogOix01E0(onDismiss, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(125068089, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt.ClearCartDialog$lambda$0(onConfirm, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), companion, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1198110857, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt.ClearCartDialog$lambda$1(onDismiss, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.INSTANCE.getLambda$1773677493$app_release(), uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.INSTANCE.getLambda$1112088020$app_release(), androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(androidx.compose.ui.unit.Dp.m8851constructorimpl(24)), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceVariant(), 0L, 0L, 0L, 0.0f, null, composer2, ((i3 >> 6) & 14) | 1772592 | ((i3 << 6) & 896), 0, 15888);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
            modifier3 = companion;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt.ClearCartDialog$lambda$2(modifier3, onConfirm, onDismiss, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ClearCartDialog$lambda$0(kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C44@1635L11,45@1705L11,43@1559L186,41@1463L545:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(125068089, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ClearCartDialog.<anonymous> (ClearCartDialog.kt:41)");
            }
            androidx.compose.material3.ButtonKt.FilledTonalButton(function0, null, false, androidx.compose.foundation.shape.RoundedCornerShapeKt.RoundedCornerShape(50), androidx.compose.material3.ButtonDefaults.INSTANCE.m2526filledTonalButtonColorsro_MJ88(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnPrimary(), 0L, 0L, composer, androidx.compose.material3.ButtonDefaults.$stable << 12, 12), null, null, null, null, uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.INSTANCE.m11451getLambda$28583769$app_release(), composer, 805306368, 486);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ClearCartDialog$lambda$1(kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C56@2058L302:ClearCartDialog.kt#udo5m8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1198110857, i, -1, "uhggroup.iceskating.app.ui.composable.approot.ClearCartDialog.<anonymous> (ClearCartDialog.kt:56)");
            }
            androidx.compose.material3.ButtonKt.TextButton(function0, null, false, null, null, null, null, null, null, uhggroup.iceskating.app.ui.composable.approot.ComposableSingletons$ClearCartDialogKt.INSTANCE.m11450getLambda$2068034150$app_release(), composer, 805306368, 510);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
