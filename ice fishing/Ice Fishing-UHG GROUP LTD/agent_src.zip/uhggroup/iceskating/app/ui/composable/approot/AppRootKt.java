package uhggroup.iceskating.app.ui.composable.approot;

/* compiled from: AppRoot.kt */
@kotlin.Metadata(d1 = {"\u0000\\\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a\u0017\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\nH\u0007¢\u0006\u0002\u0010\u000b\u001ao\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00142\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\b0\u00182\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\b0\u001a2\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\b0\u0018H\u0003¢\u0006\u0002\u0010\u001c\u001a\"\u0010\u001d\u001a\u00020\u0014*\u0004\u0018\u00010\u00102\u0014\u0010\u001e\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u00040\u0001\"\u0014\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001c\u0010\u0003\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u00040\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001c\u0010\u0006\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u00040\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001f²\u0006\u0010\u0010 \u001a\b\u0012\u0004\u0012\u00020\b0!X\u008a\u0084\u0002²\u0006\n\u0010\"\u001a\u00020\u0012X\u008a\u0084\u0002²\u0006\f\u0010#\u001a\u0004\u0018\u00010$X\u008a\u0084\u0002²\u0006\n\u0010%\u001a\u00020\u0014X\u008a\u008e\u0002"}, d2 = {"navigationItems", "", "Luhggroup/iceskating/app/ui/composable/approot/bottombar/BottomNavItem;", "topBarHiddenScreens", "Lkotlin/reflect/KClass;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "bottomBarHiddenScreens", "AppRoot", "", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/AppViewModel;", "(Luhggroup/iceskating/app/ui/viewmodel/AppViewModel;Landroidx/compose/runtime/Composer;II)V", "AppRootContent", "navController", "Landroidx/navigation/NavHostController;", "currentDestination", "Landroidx/navigation/NavDestination;", "itemsInCart", "", "isCartNotEmpty", "", "shouldShowTopBar", "shouldShowBottomBar", "onClearCartIconClick", "Lkotlin/Function0;", "onNavigateToRoute", "Lkotlin/Function1;", "onNavigateBack", "(Landroidx/navigation/NavHostController;Landroidx/navigation/NavDestination;IZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "matchesAnyRoute", "routes", "app_release", "cartPopulatedState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "itemsInCartState", "backStackEntry", "Landroidx/navigation/NavBackStackEntry;", "shouldShowClearCartDialog"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppRootKt {
    private static final java.util.List<uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem> navigationItems = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem[]{new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem(uhggroup.iceskating.app.R.string.ics_bottom_bar_nav_item_home_title, androidx.compose.material.icons.filled.HomeKt.getHome(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.INSTANCE), new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem(uhggroup.iceskating.app.R.string.ics_bottom_bar_nav_item_cart_title, androidx.compose.material.icons.filled.ShoppingCartKt.getShoppingCart(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart.INSTANCE), new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem(uhggroup.iceskating.app.R.string.ics_bottom_bar_nav_item_orders_title, androidx.compose.material.icons.automirrored.filled.ListKt.getList(androidx.compose.material.icons.Icons.AutoMirrored.Filled.INSTANCE), uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders.INSTANCE), new uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem(uhggroup.iceskating.app.R.string.ics_bottom_bar_nav_item_settings_title, androidx.compose.material.icons.filled.SettingsKt.getSettings(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings.INSTANCE)});
    private static final java.util.List<kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> topBarHiddenScreens = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new kotlin.reflect.KClass[]{kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash.class), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding.class)});
    private static final java.util.List<kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> bottomBarHiddenScreens = kotlin.collections.CollectionsKt.listOf((java.lang.Object[]) new kotlin.reflect.KClass[]{kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash.class), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding.class), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.class), kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout.class)});

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$11(uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        AppRoot(appViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRootContent$lambda$3(androidx.navigation.NavHostController navHostController, androidx.navigation.NavDestination navDestination, int i, boolean z, boolean z2, boolean z3, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function0 function02, int i2, androidx.compose.runtime.Composer composer, int i3) {
        AppRootContent(navHostController, navDestination, i, z, z2, z3, function0, function1, function02, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x00a6  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0121  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x016f  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0194  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01f0  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x01ff  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AppRoot(uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel2;
        int i3;
        final uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel3;
        final androidx.navigation.NavHostController navHostControllerRememberNavController;
        java.lang.Object objRememberedValue;
        final androidx.compose.runtime.MutableState mutableState;
        boolean zChangedInstance;
        java.lang.Object objRememberedValue2;
        java.lang.Object objRememberedValue3;
        boolean zChangedInstance2;
        java.lang.Object objRememberedValue4;
        int i4;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(3159117);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AppRoot)N(viewModel)75@2965L16,76@3037L16,78@3079L23,79@3143L30,82@3269L34,87@3508L236,104@4091L36,106@4201L32,97@3750L489:AppRoot.kt#udo5m8");
        if ((i & 6) == 0) {
            if ((i2 & 1) == 0) {
                appViewModel2 = appViewModel;
                if (composerStartRestartGroup.changedInstance(appViewModel2)) {
                    i4 = 4;
                }
                i3 = i4 | i;
            } else {
                appViewModel2 = appViewModel;
            }
            i4 = 2;
            i3 = i4 | i;
        } else {
            appViewModel2 = appViewModel;
            i3 = i;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "73@2886L15");
            if ((i & 1) == 0 || composerStartRestartGroup.getDefaultsInvalid()) {
                if ((i2 & 1) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.AppViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    appViewModel2 = (uhggroup.iceskating.app.ui.viewmodel.AppViewModel) viewModelResolveViewModel;
                    i3 &= -15;
                }
                appViewModel3 = appViewModel2;
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(3159117, i3, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRoot (AppRoot.kt:74)");
                }
                androidx.compose.runtime.State stateCollectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(appViewModel3.getCartPopulatedState(), null, composerStartRestartGroup, 0, 1);
                androidx.compose.runtime.State stateCollectAsState2 = androidx.compose.runtime.SnapshotStateKt.collectAsState(appViewModel3.getItemsInCartState(), null, composerStartRestartGroup, 0, 1);
                navHostControllerRememberNavController = androidx.navigation.compose.NavHostControllerKt.rememberNavController(new androidx.navigation.Navigator[0], composerStartRestartGroup, 0);
                androidx.navigation.NavBackStackEntry navBackStackEntryAppRoot$lambda$2 = AppRoot$lambda$2(androidx.navigation.compose.NavHostControllerKt.currentBackStackEntryAsState(navHostControllerRememberNavController, composerStartRestartGroup, 0));
                androidx.navigation.NavDestination destination = navBackStackEntryAppRoot$lambda$2 == null ? navBackStackEntryAppRoot$lambda$2.getDestination() : null;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259042193, "CC(remember):AppRoot.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                boolean z = !matchesAnyRoute(destination, bottomBarHiddenScreens);
                boolean z2 = !matchesAnyRoute(destination, topBarHiddenScreens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259034343, "CC(remember):AppRoot.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(navHostControllerRememberNavController);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$6$0(navHostControllerRememberNavController, (uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) objRememberedValue2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                int iAppRoot$lambda$1 = AppRoot$lambda$1(stateCollectAsState2);
                boolean z3 = AppRoot$lambda$0(stateCollectAsState) instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259015887, "CC(remember):AppRoot.kt#9igjgp");
                objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue3 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$7$0(mutableState);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                }
                kotlin.jvm.functions.Function0 function0 = (kotlin.jvm.functions.Function0) objRememberedValue3;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259012371, "CC(remember):AppRoot.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(navHostControllerRememberNavController);
                objRememberedValue4 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2 || objRememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue4 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$8$0(navHostControllerRememberNavController);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue4);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                AppRootContent(navHostControllerRememberNavController, destination, iAppRoot$lambda$1, z3, z2, z, function0, function1, (kotlin.jvm.functions.Function0) objRememberedValue4, composerStartRestartGroup, 1572864);
                if (!AppRoot$lambda$4(mutableState)) {
                    composerStartRestartGroup.startReplaceGroup(-374597204);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "112@4390L103,111@4327L37,110@4286L217");
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259006252, "CC(remember):AppRoot.kt#9igjgp");
                    boolean zChangedInstance3 = composerStartRestartGroup.changedInstance(appViewModel3);
                    java.lang.Object objRememberedValue5 = composerStartRestartGroup.rememberedValue();
                    if (zChangedInstance3 || objRememberedValue5 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue5 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$9$0(appViewModel3, mutableState);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue5);
                    }
                    kotlin.jvm.functions.Function0 function02 = (kotlin.jvm.functions.Function0) objRememberedValue5;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259008334, "CC(remember):AppRoot.kt#9igjgp");
                    java.lang.Object objRememberedValue6 = composerStartRestartGroup.rememberedValue();
                    if (objRememberedValue6 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue6 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$10$0(mutableState);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue6);
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    uhggroup.iceskating.app.ui.composable.approot.ClearCartDialogKt.ClearCartDialog(null, function02, (kotlin.jvm.functions.Function0) objRememberedValue6, composerStartRestartGroup, 384, 1);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-374373291);
                    composerStartRestartGroup.endReplaceGroup();
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 1) != 0) {
                    i3 &= -15;
                }
                appViewModel3 = appViewModel2;
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                }
                androidx.compose.runtime.State stateCollectAsState3 = androidx.compose.runtime.SnapshotStateKt.collectAsState(appViewModel3.getCartPopulatedState(), null, composerStartRestartGroup, 0, 1);
                androidx.compose.runtime.State stateCollectAsState22 = androidx.compose.runtime.SnapshotStateKt.collectAsState(appViewModel3.getItemsInCartState(), null, composerStartRestartGroup, 0, 1);
                navHostControllerRememberNavController = androidx.navigation.compose.NavHostControllerKt.rememberNavController(new androidx.navigation.Navigator[0], composerStartRestartGroup, 0);
                androidx.navigation.NavBackStackEntry navBackStackEntryAppRoot$lambda$22 = AppRoot$lambda$2(androidx.navigation.compose.NavHostControllerKt.currentBackStackEntryAsState(navHostControllerRememberNavController, composerStartRestartGroup, 0));
                if (navBackStackEntryAppRoot$lambda$22 == null) {
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259042193, "CC(remember):AppRoot.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                }
                mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                boolean z4 = !matchesAnyRoute(destination, bottomBarHiddenScreens);
                boolean z22 = !matchesAnyRoute(destination, topBarHiddenScreens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259034343, "CC(remember):AppRoot.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(navHostControllerRememberNavController);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$6$0(navHostControllerRememberNavController, (uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) objRememberedValue2;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    int iAppRoot$lambda$12 = AppRoot$lambda$1(stateCollectAsState22);
                    boolean z32 = AppRoot$lambda$0(stateCollectAsState3) instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259015887, "CC(remember):AppRoot.kt#9igjgp");
                    objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                    if (objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    }
                    kotlin.jvm.functions.Function0 function03 = (kotlin.jvm.functions.Function0) objRememberedValue3;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1259012371, "CC(remember):AppRoot.kt#9igjgp");
                    zChangedInstance2 = composerStartRestartGroup.changedInstance(navHostControllerRememberNavController);
                    objRememberedValue4 = composerStartRestartGroup.rememberedValue();
                    if (!zChangedInstance2) {
                        objRememberedValue4 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function0
                            public final java.lang.Object invoke() {
                                return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$8$0(navHostControllerRememberNavController);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue4);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        AppRootContent(navHostControllerRememberNavController, destination, iAppRoot$lambda$12, z32, z22, z4, function03, function12, (kotlin.jvm.functions.Function0) objRememberedValue4, composerStartRestartGroup, 1572864);
                        if (!AppRoot$lambda$4(mutableState)) {
                        }
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        }
                    }
                }
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            appViewModel3 = appViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$11(appViewModel3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    private static final boolean AppRoot$lambda$4(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void AppRoot$lambda$5(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState, boolean z) {
        mutableState.setValue(java.lang.Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$6$0(androidx.navigation.NavHostController navHostController, uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem item) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "item");
        navHostController.navigate((androidx.navigation.NavHostController) item.getRoute(), new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$6$0$0((androidx.navigation.NavOptionsBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$6$0$0(androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo((androidx.navigation.NavOptionsBuilder) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot$lambda$6$0$0$0((androidx.navigation.PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        navigate.setRestoreState(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$6$0$0$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setSaveState(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$7$0(androidx.compose.runtime.MutableState mutableState) {
        AppRoot$lambda$5(mutableState, true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$8$0(androidx.navigation.NavHostController navHostController) {
        navHostController.popBackStack();
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$10$0(androidx.compose.runtime.MutableState mutableState) {
        AppRoot$lambda$5(mutableState, false);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRoot$lambda$9$0(uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel, androidx.compose.runtime.MutableState mutableState) {
        appViewModel.clearCart();
        AppRoot$lambda$5(mutableState, false);
        return kotlin.Unit.INSTANCE;
    }

    private static final void AppRootContent(final androidx.navigation.NavHostController navHostController, final androidx.navigation.NavDestination navDestination, final int i, final boolean z, final boolean z2, final boolean z3, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, final kotlin.jvm.functions.Function1<? super uhggroup.iceskating.app.ui.composable.approot.bottombar.BottomNavItem, kotlin.Unit> function1, final kotlin.jvm.functions.Function0<kotlin.Unit> function02, androidx.compose.runtime.Composer composer, final int i2) {
        int i3;
        final boolean z4;
        boolean z5;
        kotlin.jvm.functions.Function0<kotlin.Unit> function03;
        kotlin.jvm.functions.Function0<kotlin.Unit> function04;
        androidx.compose.runtime.Composer composer2;
        final androidx.navigation.NavDestination navDestination2 = navDestination;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-427878637);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AppRootContent)N(navController,currentDestination,itemsInCart,isCartNotEmpty,shouldShowTopBar,shouldShowBottomBar,onClearCartIconClick,onNavigateToRoute,onNavigateBack)133@4901L431,146@5355L334,156@5730L11,157@5760L700,132@4874L1586:AppRoot.kt#udo5m8");
        if ((i2 & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(navHostController) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(navDestination2) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            i3 |= composerStartRestartGroup.changed(i) ? 256 : 128;
        }
        if ((i2 & 3072) == 0) {
            z4 = z;
            i3 |= composerStartRestartGroup.changed(z4) ? 2048 : 1024;
        } else {
            z4 = z;
        }
        if ((i2 & 24576) == 0) {
            z5 = z2;
            i3 |= composerStartRestartGroup.changed(z5) ? 16384 : 8192;
        } else {
            z5 = z2;
        }
        if ((196608 & i2) == 0) {
            i3 |= composerStartRestartGroup.changed(z3) ? 131072 : 65536;
        }
        if ((1572864 & i2) == 0) {
            function03 = function0;
            i3 |= composerStartRestartGroup.changedInstance(function03) ? 1048576 : 524288;
        } else {
            function03 = function0;
        }
        if ((12582912 & i2) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function1) ? 8388608 : 4194304;
        }
        if ((100663296 & i2) == 0) {
            function04 = function02;
            i3 |= composerStartRestartGroup.changedInstance(function04) ? 67108864 : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasAuxSlotFlag;
        } else {
            function04 = function02;
        }
        if (!composerStartRestartGroup.shouldExecute((38347923 & i3) != 38347922, i3 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-427878637, i3, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRootContent (AppRoot.kt:131)");
            }
            final boolean z6 = z5;
            final kotlin.jvm.functions.Function0<kotlin.Unit> function05 = function03;
            final kotlin.jvm.functions.Function0<kotlin.Unit> function06 = function04;
            navDestination2 = navDestination;
            composer2 = composerStartRestartGroup;
            androidx.compose.material3.ScaffoldKt.m3334ScaffoldTvnljyQ(null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(127038415, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRootContent$lambda$0(z6, navDestination, z4, function05, function06, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1276870702, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRootContent$lambda$1(z3, i, navDestination2, function1, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, null, 0, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getBackground(), 0L, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-345424092, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function3
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRootContent$lambda$2(navHostController, (androidx.compose.foundation.layout.PaddingValues) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                }
            }, composerStartRestartGroup, 54), composer2, 805306800, 441);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRootContent$lambda$3(navHostController, navDestination2, i, z, z2, z3, function0, function1, function02, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRootContent$lambda$0(boolean z, androidx.navigation.NavDestination navDestination, boolean z2, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppRoot.kt#udo5m8");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(127038415, i, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRootContent.<anonymous> (AppRoot.kt:134)");
            }
            if (z) {
                composer.startReplaceGroup(735278255);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "135@4955L260");
                uhggroup.iceskating.app.ui.composable.approot.topbar.AppTopBarKt.AppTopBar(navDestination, z2, function0, function02, composer, 0);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(735567516);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "142@5285L11,142@5253L55");
                uhggroup.iceskating.app.ui.theme.SystemBarsKt.m11593StatusBarIconsForek8zF_U(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getBackground(), composer, 0);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRootContent$lambda$1(boolean z, int i, androidx.navigation.NavDestination navDestination, kotlin.jvm.functions.Function1 function1, androidx.compose.runtime.Composer composer, int i2) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:AppRoot.kt#udo5m8");
        if (composer.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1276870702, i2, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRootContent.<anonymous> (AppRoot.kt:147)");
            }
            if (z) {
                composer.startReplaceGroup(-1270209865);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "148@5412L253");
                uhggroup.iceskating.app.ui.composable.approot.bottombar.AppBottomBarKt.AppBottomBar(i, navDestination, navigationItems, function1, composer, 0);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-1269935980);
                composer.endReplaceGroup();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRootContent$lambda$2(final androidx.navigation.NavHostController navHostController, final androidx.compose.foundation.layout.PaddingValues paddingValues, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(paddingValues, "paddingValues");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(paddingValues)164@6214L240,162@6092L362:AppRoot.kt#udo5m8");
        if ((i & 6) == 0) {
            i |= composer.changed(paddingValues) ? 4 : 2;
        }
        if (!composer.shouldExecute((i & 19) != 18, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-345424092, i, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRootContent.<anonymous> (AppRoot.kt:162)");
            }
            androidx.compose.runtime.CompositionLocalKt.CompositionLocalProvider(uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding().provides(androidx.compose.ui.unit.Dp.m8849boximpl(paddingValues.getBottom())), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1195015196, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.approot.AppRootKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRootContent$lambda$2$0(navHostController, paddingValues, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composer, 54), composer, androidx.compose.runtime.ProvidedValue.$stable | 48);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppRootContent$lambda$2$0(androidx.navigation.NavHostController navHostController, androidx.compose.foundation.layout.PaddingValues paddingValues, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C165@6228L216:AppRoot.kt#udo5m8");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1195015196, i, -1, "uhggroup.iceskating.app.ui.composable.approot.AppRootContent.<anonymous>.<anonymous> (AppRoot.kt:165)");
            }
            uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost(navHostController, androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), 0.0f, paddingValues.getTop(), 0.0f, 0.0f, 13, null), composer, 0, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    public static final boolean matchesAnyRoute(androidx.navigation.NavDestination navDestination, java.util.List<? extends kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> routes) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(routes, "routes");
        if (navDestination != null) {
            java.util.List<? extends kotlin.reflect.KClass<? extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute>> list = routes;
            if (!(list instanceof java.util.Collection) || !list.isEmpty()) {
                java.util.Iterator<T> it = list.iterator();
                while (it.hasNext()) {
                    if (androidx.navigation.NavDestination.INSTANCE.hasRoute(navDestination, (kotlin.reflect.KClass) it.next())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<kotlin.Unit> AppRoot$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<kotlin.Unit>> state) {
        return state.getValue();
    }

    private static final int AppRoot$lambda$1(androidx.compose.runtime.State<java.lang.Integer> state) {
        return state.getValue().intValue();
    }

    private static final androidx.navigation.NavBackStackEntry AppRoot$lambda$2(androidx.compose.runtime.State<androidx.navigation.NavBackStackEntry> state) {
        return state.getValue();
    }
}
