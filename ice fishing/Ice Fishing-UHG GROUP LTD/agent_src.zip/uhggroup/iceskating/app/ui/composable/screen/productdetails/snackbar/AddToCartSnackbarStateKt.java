package uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar;

/* compiled from: AddToCartSnackbarState.kt */
@kotlin.Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\r\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0004\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"VisibleDurationMillis", "", "rememberAddToCartSnackbarState", "Luhggroup/iceskating/app/ui/composable/screen/productdetails/snackbar/AddToCartSnackbarState;", "(Landroidx/compose/runtime/Composer;I)Luhggroup/iceskating/app/ui/composable/screen/productdetails/snackbar/AddToCartSnackbarState;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AddToCartSnackbarStateKt {
    private static final long VisibleDurationMillis = 2500;

    public static final uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState rememberAddToCartSnackbarState(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -331116992, "C(rememberAddToCartSnackbarState)36@1055L24,37@1091L49:AddToCartSnackbarState.kt#7ufilt");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-331116992, i, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.rememberAddToCartSnackbarState (AddToCartSnackbarState.kt:35)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 773894976, "CC(rememberCoroutineScope)N(getContext)616@28039L68:Effects.kt#9igjgp");
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 683736516, "CC(remember):Effects.kt#9igjgp");
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = androidx.compose.runtime.EffectsKt.createCompositionCoroutineScope(kotlin.coroutines.EmptyCoroutineContext.INSTANCE, composer);
            composer.updateRememberedValue(objRememberedValue);
        }
        kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) objRememberedValue;
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -375845679, "CC(remember):AddToCartSnackbarState.kt#9igjgp");
        boolean zChanged = composer.changed(coroutineScope);
        java.lang.Object objRememberedValue2 = composer.rememberedValue();
        if (zChanged || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue2 = new uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState(coroutineScope);
            composer.updateRememberedValue(objRememberedValue2);
        }
        uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState addToCartSnackbarState = (uhggroup.iceskating.app.ui.composable.screen.productdetails.snackbar.AddToCartSnackbarState) objRememberedValue2;
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        return addToCartSnackbarState;
    }
}
