package uhggroup.iceskating.app.ui.composable.screen.onboarding;

/* compiled from: ICSOnboardingScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
final /* synthetic */ class ICSOnboardingScreenKt$ICSOnboardingScreen$2$1 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function0<kotlin.Unit> {
    ICSOnboardingScreenKt$ICSOnboardingScreen$2$1(java.lang.Object obj) {
        super(0, obj, uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.class, "setOnboarded", "setOnboarded()V", 0);
    }

    @Override // kotlin.jvm.functions.Function0
    public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
        invoke2();
        return kotlin.Unit.INSTANCE;
    }

    /* renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2() {
        ((uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel) this.receiver).setOnboarded();
    }
}
