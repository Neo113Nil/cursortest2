package uhggroup.iceskating.app.ui.composable.screen.home.filter;

/* compiled from: LazyDsl.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$2 implements kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object> {
    final /* synthetic */ java.util.List $items;
    final /* synthetic */ kotlin.jvm.functions.Function1 $key;

    public CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$2(kotlin.jvm.functions.Function1 function1, java.util.List list) {
        this.$key = function1;
        this.$items = list;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
        return invoke(num.intValue());
    }

    public final java.lang.Object invoke(int i) {
        return this.$key.invoke(this.$items.get(i));
    }
}
