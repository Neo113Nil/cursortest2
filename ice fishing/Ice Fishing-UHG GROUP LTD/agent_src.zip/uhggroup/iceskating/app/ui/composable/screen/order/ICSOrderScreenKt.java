package uhggroup.iceskating.app.ui.composable.screen.order;

/* compiled from: ICSOrderScreen.kt */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\u001a!\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a+\u0010\u0007\u001a\u00020\u00012\u0012\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\t2\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0003¢\u0006\u0002\u0010\f¨\u0006\r²\u0006\u0016\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\tX\u008a\u0084\u0002"}, d2 = {"ICSOrdersScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/OrderViewModel;", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/OrderViewModel;Landroidx/compose/runtime/Composer;II)V", "OrdersContent", "ordersState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "(Luhggroup/iceskating/app/ui/state/DataUiState;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSOrderScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSOrdersScreen$lambda$1(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.OrderViewModel orderViewModel, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ICSOrdersScreen(modifier, orderViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OrdersContent$lambda$1(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        OrdersContent(dataUiState, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final void ICSOrdersScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.OrderViewModel orderViewModel, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        final uhggroup.iceskating.app.ui.viewmodel.OrderViewModel orderViewModel2;
        final androidx.compose.ui.Modifier.Companion companion;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(568620275);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSOrdersScreen)N(modifier,viewModel)29@1354L16,31@1376L84:ICSOrderScreen.kt#gr4iox");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                orderViewModel2 = orderViewModel;
                int i5 = composerStartRestartGroup.changedInstance(orderViewModel2) ? 32 : 16;
                i3 |= i5;
            } else {
                orderViewModel2 = orderViewModel;
            }
            i3 |= i5;
        } else {
            orderViewModel2 = orderViewModel;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "27@1288L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    i3 &= -113;
                    orderViewModel2 = (uhggroup.iceskating.app.ui.viewmodel.OrderViewModel) viewModelResolveViewModel;
                }
            }
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(568620275, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.order.ICSOrdersScreen (ICSOrderScreen.kt:28)");
            }
            OrdersContent(ICSOrdersScreen$lambda$0(androidx.compose.runtime.SnapshotStateKt.collectAsState(orderViewModel2.getOrdersState(), null, composerStartRestartGroup, 0, 1)), companion, composerStartRestartGroup, (i3 << 3) & 112, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.ICSOrdersScreen$lambda$1(companion, orderViewModel2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void OrdersContent(final uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> dataUiState, final androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        final uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> dataUiState2;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1269518688);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(OrdersContent)N(ordersState,modifier)42@1620L7,44@1633L1228:ICSOrderScreen.kt#gr4iox");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(dataUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(modifier) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            dataUiState2 = dataUiState;
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (i4 != 0) {
                modifier = androidx.compose.ui.Modifier.INSTANCE;
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1269518688, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.order.OrdersContent (ICSOrderScreen.kt:41)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifier);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1236614990, "C50@1805L798,46@1672L1183:ICSOrderScreen.kt#gr4iox");
            dataUiState2 = dataUiState;
            uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt.DataBasedContainer(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), dataUiState2, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-1773963907, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.OrdersContent$lambda$0$0(dataUiState, dimens, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), uhggroup.iceskating.app.ui.composable.screen.order.ComposableSingletons$ICSOrderScreenKt.INSTANCE.getLambda$515512510$app_release(), null, composerStartRestartGroup, ((i3 << 3) & 112) | 3462, 16);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.OrdersContent$lambda$1(dataUiState2, modifier, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OrdersContent$lambda$0$0(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C59@2273L7,62@2410L179,53@1914L675:ICSOrderScreen.kt#gr4iox");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1773963907, i, -1, "uhggroup.iceskating.app.ui.composable.screen.order.OrdersContent.<anonymous>.<anonymous> (ICSOrderScreen.kt:51)");
            }
            kotlin.jvm.internal.Intrinsics.checkNotNull(dataUiState, "null cannot be cast to non-null type uhggroup.iceskating.app.ui.state.DataUiState.Populated<kotlin.collections.List<uhggroup.iceskating.app.data.entity.OrderEntity>>");
            final java.util.List list = (java.util.List) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData();
            androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
            float fM11620getScreenPaddingD9Ej5fM = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM2 = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM3 = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM4 = dimens.m11620getScreenPaddingD9Ej5fM();
            androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composer.consume(localContentBottomPadding);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.PaddingValues paddingValuesM1158PaddingValuesa9UjIt4 = androidx.compose.foundation.layout.PaddingKt.m1158PaddingValuesa9UjIt4(fM11620getScreenPaddingD9Ej5fM, fM11620getScreenPaddingD9Ej5fM3, fM11620getScreenPaddingD9Ej5fM2, androidx.compose.ui.unit.Dp.m8851constructorimpl(fM11620getScreenPaddingD9Ej5fM4 + ((androidx.compose.ui.unit.Dp) objConsume).m8865unboximpl()));
            androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical horizontalOrVerticalM836spacedBy0680j_4 = androidx.compose.foundation.layout.Arrangement.INSTANCE.m836spacedBy0680j_4(dimens.m11614getContentSpacingD9Ej5fM());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 322721424, "CC(remember):ICSOrderScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(list);
            java.lang.Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        return uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.OrdersContent$lambda$0$0$0$0(list, (androidx.compose.foundation.lazy.LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.lazy.LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM1158PaddingValuesa9UjIt4, false, horizontalOrVerticalM836spacedBy0680j_4, null, null, false, null, (kotlin.jvm.functions.Function1) objRememberedValue, composer, 6, 490);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OrdersContent$lambda$0$0$0$0(final java.util.List list, androidx.compose.foundation.lazy.LazyListScope LazyColumn) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final kotlin.jvm.functions.Function1 function1 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.OrdersContent$lambda$0$0$0$0$0((uhggroup.iceskating.app.data.entity.OrderEntity) obj);
            }
        };
        final uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$1 iCSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$1 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Void invoke(uhggroup.iceskating.app.data.entity.OrderEntity orderEntity) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object obj) {
                return invoke((uhggroup.iceskating.app.data.entity.OrderEntity) obj);
            }
        };
        LazyColumn.items(list.size(), new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$2
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return function1.invoke(list.get(i));
            }
        }, new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return iCSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$1.invoke(list.get(i));
            }
        }, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(802480018, true, new kotlin.jvm.functions.Function4<androidx.compose.foundation.lazy.LazyItemScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt$OrdersContent$lambda$0$0$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, java.lang.Integer num, androidx.compose.runtime.Composer composer, java.lang.Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, int i, androidx.compose.runtime.Composer composer, int i2) {
                int i3;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                uhggroup.iceskating.app.data.entity.OrderEntity orderEntity = (uhggroup.iceskating.app.data.entity.OrderEntity) list.get(i);
                composer.startReplaceGroup(-653998994);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(order)*64@2525L24:ICSOrderScreen.kt#gr4iox");
                uhggroup.iceskating.app.ui.composable.screen.order.card.OrderItemKt.OrderItem(orderEntity, null, composer, 0, 2);
                composer.endReplaceGroup();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.Object OrdersContent$lambda$0$0$0$0$0(uhggroup.iceskating.app.data.entity.OrderEntity order) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(order, "order");
        return order.getOrderNumber();
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> ICSOrdersScreen$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>>> state) {
        return (uhggroup.iceskating.app.ui.state.DataUiState) state.getValue();
    }
}
