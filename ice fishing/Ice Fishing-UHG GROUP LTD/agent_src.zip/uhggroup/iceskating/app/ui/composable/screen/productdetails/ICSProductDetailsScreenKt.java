package uhggroup.iceskating.app.ui.composable.screen.productdetails;

/* compiled from: ICSProductDetailsScreen.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a)\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0002\u0010\b\u001a3\u0010\t\u001a\u00020\u00012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b2\b\b\u0002\u0010\u0004\u001a\u00020\u00052\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00010\u000eH\u0003¢\u0006\u0002\u0010\u000f¨\u0006\u0010²\u0006\u0010\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u008a\u0084\u0002"}, d2 = {"ICSProductDetailsScreen", "", "productId", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/ProductDetailsViewModel;", "(ILandroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/ProductDetailsViewModel;Landroidx/compose/runtime/Composer;II)V", "ProductDetailsScreenContent", "productState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "Luhggroup/iceskating/app/data/model/Product;", "onAddToCart", "Lkotlin/Function0;", "(Luhggroup/iceskating/app/ui/state/DataUiState;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSProductDetailsScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSProductDetailsScreen$lambda$3(int i, androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel, int i2, int i3, androidx.compose.runtime.Composer composer, int i4) {
        ICSProductDetailsScreen(i, modifier, productDetailsViewModel, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i2 | 1), i3);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductDetailsScreenContent$lambda$1(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ProductDetailsScreenContent(dataUiState, modifier, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0058  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0108  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0119  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x016d  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0178  */
    /* JADX WARN: Removed duplicated region for block: B:83:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ICSProductDetailsScreen(final int i, androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel, androidx.compose.runtime.Composer composer, final int i2, final int i3) {
        int i4;
        androidx.compose.ui.Modifier modifier2;
        uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel2;
        final uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        int i5;
        uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel4;
        boolean zChangedInstance;
        uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$1$1 iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue;
        boolean zChangedInstance2;
        uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$2$1 iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(378891017);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSProductDetailsScreen)N(productId,modifier,viewModel)27@1274L16,29@1317L58,29@1296L79,36@1498L27,33@1381L150:ICSProductDetailsScreen.kt#eadzsu");
        if ((i2 & 6) == 0) {
            i4 = (composerStartRestartGroup.changed(i) ? 4 : 2) | i2;
        } else {
            i4 = i2;
        }
        int i6 = i3 & 2;
        if (i6 == 0) {
            if ((i2 & 48) == 0) {
                modifier2 = modifier;
                i4 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i2 & 384) != 0) {
                if ((i3 & 4) == 0) {
                    productDetailsViewModel2 = productDetailsViewModel;
                    int i7 = composerStartRestartGroup.changedInstance(productDetailsViewModel2) ? 256 : 128;
                    i4 |= i7;
                } else {
                    productDetailsViewModel2 = productDetailsViewModel;
                }
                i4 |= i7;
            } else {
                productDetailsViewModel2 = productDetailsViewModel;
            }
            if (!composerStartRestartGroup.shouldExecute((i4 & 147) == 146, i4 & 1)) {
                composerStartRestartGroup.startDefaults();
                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "25@1199L15");
                if ((i2 & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                    composerStartRestartGroup.skipToGroupEnd();
                    if ((i3 & 4) != 0) {
                        i4 &= -897;
                    }
                } else {
                    androidx.compose.ui.Modifier.Companion companion = i6 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                    if ((i3 & 4) != 0) {
                        composerStartRestartGroup.startReplaceGroup(-924953623);
                        androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                        if (current == null) {
                            throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                        }
                        androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                        composerStartRestartGroup.endReplaceGroup();
                        androidx.compose.ui.Modifier modifier3 = companion;
                        i5 = i4 & (-897);
                        productDetailsViewModel4 = (uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel) viewModelResolveViewModel;
                        modifier2 = modifier3;
                        composerStartRestartGroup.endDefaults();
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventStart(378891017, i5, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreen (ICSProductDetailsScreen.kt:26)");
                        }
                        androidx.compose.runtime.State stateCollectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(productDetailsViewModel4.getProductDetailsState(), null, composerStartRestartGroup, 0, 1);
                        kotlin.Unit unit = kotlin.Unit.INSTANCE;
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -957944989, "CC(remember):ICSProductDetailsScreen.kt#9igjgp");
                        zChangedInstance = composerStartRestartGroup.changedInstance(productDetailsViewModel4) | ((i5 & 14) == 4);
                        iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
                        if (!zChangedInstance || iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                            iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$1$1(productDetailsViewModel4, i, null);
                            composerStartRestartGroup.updateRememberedValue(iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue);
                        }
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        androidx.compose.runtime.EffectsKt.LaunchedEffect(unit, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue, composerStartRestartGroup, 6);
                        uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product> dataUiStateICSProductDetailsScreen$lambda$0 = ICSProductDetailsScreen$lambda$0(stateCollectAsState);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -957939228, "CC(remember):ICSProductDetailsScreen.kt#9igjgp");
                        zChangedInstance2 = composerStartRestartGroup.changedInstance(productDetailsViewModel4);
                        iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue = composerStartRestartGroup.rememberedValue();
                        if (!zChangedInstance2 || iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                            iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$2$1(productDetailsViewModel4);
                            composerStartRestartGroup.updateRememberedValue(iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue);
                        }
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        ProductDetailsScreenContent(dataUiStateICSProductDetailsScreen$lambda$0, modifier2, (kotlin.jvm.functions.Function0) ((kotlin.reflect.KFunction) iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue), composerStartRestartGroup, i5 & 112, 0);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                            androidx.compose.runtime.ComposerKt.traceEventEnd();
                        }
                        productDetailsViewModel3 = productDetailsViewModel4;
                    } else {
                        modifier2 = companion;
                    }
                }
                i5 = i4;
                productDetailsViewModel4 = productDetailsViewModel2;
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                }
                androidx.compose.runtime.State stateCollectAsState2 = androidx.compose.runtime.SnapshotStateKt.collectAsState(productDetailsViewModel4.getProductDetailsState(), null, composerStartRestartGroup, 0, 1);
                kotlin.Unit unit2 = kotlin.Unit.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -957944989, "CC(remember):ICSProductDetailsScreen.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(productDetailsViewModel4) | ((i5 & 14) == 4);
                iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance) {
                    iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$1$1(productDetailsViewModel4, i, null);
                    composerStartRestartGroup.updateRememberedValue(iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.EffectsKt.LaunchedEffect(unit2, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) iCSProductDetailsScreenKt$ICSProductDetailsScreen$1$1RememberedValue, composerStartRestartGroup, 6);
                    uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product> dataUiStateICSProductDetailsScreen$lambda$02 = ICSProductDetailsScreen$lambda$0(stateCollectAsState2);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -957939228, "CC(remember):ICSProductDetailsScreen.kt#9igjgp");
                    zChangedInstance2 = composerStartRestartGroup.changedInstance(productDetailsViewModel4);
                    iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue = composerStartRestartGroup.rememberedValue();
                    if (!zChangedInstance2) {
                        iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$ICSProductDetailsScreen$2$1(productDetailsViewModel4);
                        composerStartRestartGroup.updateRememberedValue(iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        ProductDetailsScreenContent(dataUiStateICSProductDetailsScreen$lambda$02, modifier2, (kotlin.jvm.functions.Function0) ((kotlin.reflect.KFunction) iCSProductDetailsScreenKt$ICSProductDetailsScreen$2$1RememberedValue), composerStartRestartGroup, i5 & 112, 0);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        }
                        productDetailsViewModel3 = productDetailsViewModel4;
                    }
                }
            } else {
                composerStartRestartGroup.skipToGroupEnd();
                productDetailsViewModel3 = productDetailsViewModel2;
            }
            final androidx.compose.ui.Modifier modifier4 = modifier2;
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt.ICSProductDetailsScreen$lambda$3(i, modifier4, productDetailsViewModel3, i2, i3, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i4 |= 48;
        modifier2 = modifier;
        if ((i2 & 384) != 0) {
        }
        if (!composerStartRestartGroup.shouldExecute((i4 & 147) == 146, i4 & 1)) {
        }
        final androidx.compose.ui.Modifier modifier42 = modifier2;
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0058  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x018b  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0195  */
    /* JADX WARN: Removed duplicated region for block: B:56:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void ProductDetailsScreenContent(final uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product> dataUiState, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1757841768);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ProductDetailsScreenContent)N(productState,modifier,onAddToCart)46@1770L7,46@1700L728:ICSProductDetailsScreen.kt#eadzsu");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(dataUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(function0) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier modifier4 = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1757841768, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.ProductDetailsScreenContent (ICSProductDetailsScreen.kt:45)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localContentBottomPadding);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.Modifier modifierM1166paddingqDBjuR0$default = androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(modifier4, 0.0f, 0.0f, 0.0f, ((androidx.compose.ui.unit.Dp) objConsume).m8865unboximpl(), 7, null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1166paddingqDBjuR0$default);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 493701870, "C52@1925L236,48@1791L631:ICSProductDetailsScreen.kt#eadzsu");
                uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt.DataBasedContainer(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), dataUiState, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(559626565, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt.ProductDetailsScreenContent$lambda$0$0(dataUiState, function0, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54), uhggroup.iceskating.app.ui.composable.screen.productdetails.ComposableSingletons$ICSProductDetailsScreenKt.INSTANCE.m11497getLambda$1787610298$app_release(), null, composerStartRestartGroup, ((i3 << 3) & 112) | 3462, 16);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt.ProductDetailsScreenContent$lambda$1(dataUiState, modifier3, function0, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if ((i & 384) == 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductDetailsScreenContent$lambda$0$0(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C55@2025L122:ICSProductDetailsScreen.kt#eadzsu");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(559626565, i, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.ProductDetailsScreenContent.<anonymous>.<anonymous> (ICSProductDetailsScreen.kt:53)");
            }
            kotlin.jvm.internal.Intrinsics.checkNotNull(dataUiState, "null cannot be cast to non-null type uhggroup.iceskating.app.ui.state.DataUiState.Populated<uhggroup.iceskating.app.data.model.Product>");
            uhggroup.iceskating.app.ui.composable.screen.productdetails.layout.ProductDetailsLayoutKt.ProductDetailsLayout((uhggroup.iceskating.app.data.model.Product) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData(), null, function0, composer, 0, 2);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product> ICSProductDetailsScreen$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product>> state) {
        return state.getValue();
    }
}
