package uhggroup.iceskating.app.ui.composable.screen.onboarding;

/* compiled from: ICSOnboardingScreen.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\u001a/\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\b\u001a%\u0010\t\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0003¢\u0006\u0002\u0010\u000b\u001a\u001f\u0010\f\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0003¢\u0006\u0002\u0010\u000f¨\u0006\u0010²\u0006\n\u0010\u0011\u001a\u00020\u0012X\u008a\u0084\u0002"}, d2 = {"ICSOnboardingScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/OnboardingViewModel;", "onNavigateToHomeScreen", "Lkotlin/Function0;", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/OnboardingViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "OnboardingPager", "onFinishClick", "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "OnboardingPage", "content", "Luhggroup/iceskating/app/ui/composable/screen/onboarding/OnboardingContent;", "(Luhggroup/iceskating/app/ui/composable/screen/onboarding/OnboardingContent;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release", "onboardingSetState", ""}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSOnboardingScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSOnboardingScreen$lambda$3(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel onboardingViewModel, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ICSOnboardingScreen(modifier, onboardingViewModel, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingPage$lambda$1(uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContent onboardingContent, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        OnboardingPage(onboardingContent, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingPager$lambda$2(androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        OnboardingPager(modifier, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final void ICSOnboardingScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel onboardingViewModel, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToHomeScreen, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel onboardingViewModel2;
        androidx.compose.ui.Modifier.Companion companion;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToHomeScreen, "onNavigateToHomeScreen");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-497725686);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSOnboardingScreen)N(modifier,viewModel,onNavigateToHomeScreen)36@1750L16,38@1807L88,38@1772L123,46@1971L23,44@1901L100:ICSOnboardingScreen.kt#760l7a");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                onboardingViewModel2 = onboardingViewModel;
                int i5 = composerStartRestartGroup.changedInstance(onboardingViewModel2) ? 32 : 16;
                i3 |= i5;
            } else {
                onboardingViewModel2 = onboardingViewModel;
            }
            i3 |= i5;
        } else {
            onboardingViewModel2 = onboardingViewModel;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToHomeScreen) ? 256 : 128;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) != 146, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "33@1630L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    i3 &= -113;
                    onboardingViewModel2 = (uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel) viewModelResolveViewModel;
                }
            }
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-497725686, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreen (ICSOnboardingScreen.kt:35)");
            }
            androidx.compose.runtime.State stateCollectAsState = androidx.compose.runtime.SnapshotStateKt.collectAsState(onboardingViewModel2.getOnboardingSetState(), null, composerStartRestartGroup, 0, 1);
            java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(ICSOnboardingScreen$lambda$0(stateCollectAsState));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1573005534, "CC(remember):ICSOnboardingScreen.kt#9igjgp");
            boolean zChanged = composerStartRestartGroup.changed(stateCollectAsState) | ((i3 & 896) == 256);
            uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$ICSOnboardingScreen$1$1 iCSOnboardingScreenKt$ICSOnboardingScreen$1$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (zChanged || iCSOnboardingScreenKt$ICSOnboardingScreen$1$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                iCSOnboardingScreenKt$ICSOnboardingScreen$1$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$ICSOnboardingScreen$1$1(onNavigateToHomeScreen, stateCollectAsState, null);
                composerStartRestartGroup.updateRememberedValue(iCSOnboardingScreenKt$ICSOnboardingScreen$1$1RememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.EffectsKt.LaunchedEffect(boolValueOf, (kotlin.jvm.functions.Function2<? super kotlinx.coroutines.CoroutineScope, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object>) iCSOnboardingScreenKt$ICSOnboardingScreen$1$1RememberedValue, composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1573000351, "CC(remember):ICSOnboardingScreen.kt#9igjgp");
            boolean zChangedInstance = composerStartRestartGroup.changedInstance(onboardingViewModel2);
            uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$ICSOnboardingScreen$2$1 iCSOnboardingScreenKt$ICSOnboardingScreen$2$1RememberedValue = composerStartRestartGroup.rememberedValue();
            if (zChangedInstance || iCSOnboardingScreenKt$ICSOnboardingScreen$2$1RememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                iCSOnboardingScreenKt$ICSOnboardingScreen$2$1RememberedValue = new uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$ICSOnboardingScreen$2$1(onboardingViewModel2);
                composerStartRestartGroup.updateRememberedValue(iCSOnboardingScreenKt$ICSOnboardingScreen$2$1RememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            OnboardingPager(companion, (kotlin.jvm.functions.Function0) ((kotlin.reflect.KFunction) iCSOnboardingScreenKt$ICSOnboardingScreen$2$1RememberedValue), composerStartRestartGroup, i3 & 14, 0);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            final androidx.compose.ui.Modifier modifier3 = companion;
            final uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel onboardingViewModel3 = onboardingViewModel2;
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.ICSOnboardingScreen$lambda$3(modifier3, onboardingViewModel3, onNavigateToHomeScreen, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    private static final void OnboardingPager(androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        final androidx.compose.ui.Modifier modifier2;
        int i3;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1050871473);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(OnboardingPager)N(modifier,onFinishClick)55@2145L7,56@2193L31,56@2174L50,57@2250L24,63@2461L11,68@2715L7,60@2360L1164:ICSOnboardingScreen.kt#760l7a");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function0) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1050871473, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingPager (ICSOnboardingScreen.kt:54)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -570165586, "CC(remember):ICSOnboardingScreen.kt#9igjgp");
            java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        return java.lang.Integer.valueOf(uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.OnboardingPager$lambda$0$0());
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            final androidx.compose.foundation.pager.PagerState pagerStateRememberPagerState = androidx.compose.foundation.pager.PagerStateKt.rememberPagerState(0, 0.0f, (kotlin.jvm.functions.Function0) objRememberedValue, composerStartRestartGroup, 384, 3);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 773894976, "CC(rememberCoroutineScope)N(getContext)616@28039L68:Effects.kt#9igjgp");
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 683736516, "CC(remember):Effects.kt#9igjgp");
            java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = androidx.compose.runtime.EffectsKt.createCompositionCoroutineScope(kotlin.coroutines.EmptyCoroutineContext.INSTANCE, composerStartRestartGroup);
                composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
            }
            final kotlinx.coroutines.CoroutineScope coroutineScope = (kotlinx.coroutines.CoroutineScope) objRememberedValue2;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            boolean z = pagerStateRememberPagerState.getCurrentPage() == kotlin.collections.CollectionsKt.getLastIndex(uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContentKt.getOnboardingPagesContent());
            androidx.compose.ui.Modifier modifierM324backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(companion, 0.0f, 1, null), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getBackground(), null, 2, null);
            float fM11620getScreenPaddingD9Ej5fM = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM2 = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM3 = dimens.m11620getScreenPaddingD9Ej5fM();
            float fM11620getScreenPaddingD9Ej5fM4 = dimens.m11620getScreenPaddingD9Ej5fM();
            androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> localContentBottomPadding = uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.getLocalContentBottomPadding();
            androidx.compose.ui.Modifier modifier3 = companion;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume2 = composerStartRestartGroup.consume(localContentBottomPadding);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.ui.Modifier modifierM1165paddingqDBjuR0 = androidx.compose.foundation.layout.PaddingKt.m1165paddingqDBjuR0(modifierM324backgroundbw27NRU$default, fM11620getScreenPaddingD9Ej5fM, fM11620getScreenPaddingD9Ej5fM2, fM11620getScreenPaddingD9Ej5fM3, androidx.compose.ui.unit.Dp.m8851constructorimpl(fM11620getScreenPaddingD9Ej5fM4 + ((androidx.compose.ui.unit.Dp) objConsume2).m8865unboximpl()));
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1165paddingqDBjuR0);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -258919997, "C71@2755L238,85@3230L277,80@3003L515:ICSOnboardingScreen.kt#760l7a");
            final boolean z2 = z;
            androidx.compose.foundation.pager.PagerKt.m1481HorizontalPager8jOkeI(pagerStateRememberPagerState, androidx.compose.foundation.layout.ColumnScope.weight$default(columnScopeInstance, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), 1.0f, false, 2, null), null, null, 0, 0.0f, null, null, false, false, null, null, null, null, uhggroup.iceskating.app.ui.composable.screen.onboarding.ComposableSingletons$ICSOnboardingScreenKt.INSTANCE.m11488getLambda$169637370$app_release(), composerStartRestartGroup, 0, 24576, 16380);
            composerStartRestartGroup = composerStartRestartGroup;
            int size = uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContentKt.getOnboardingPagesContent().size();
            int currentPage = pagerStateRememberPagerState.getCurrentPage();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -2086547526, "CC(remember):ICSOnboardingScreen.kt#9igjgp");
            boolean zChanged = composerStartRestartGroup.changed(z2) | ((i3 & 112) == 32) | composerStartRestartGroup.changedInstance(coroutineScope) | composerStartRestartGroup.changed(pagerStateRememberPagerState);
            java.lang.Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
            if (zChanged || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue3 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        return uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.OnboardingPager$lambda$1$0$0(z2, function0, coroutineScope, pagerStateRememberPagerState);
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            uhggroup.iceskating.app.ui.composable.screen.onboarding.controls.OnboardingControlsKt.OnboardingControls(size, currentPage, z2, function0, (kotlin.jvm.functions.Function0) objRememberedValue3, null, composerStartRestartGroup, (i3 << 6) & 7168, 32);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
            modifier2 = modifier3;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.OnboardingPager$lambda$2(modifier2, function0, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int OnboardingPager$lambda$0$0() {
        return uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContentKt.getOnboardingPagesContent().size();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingPager$lambda$1$0$0(boolean z, kotlin.jvm.functions.Function0 function0, kotlinx.coroutines.CoroutineScope coroutineScope, androidx.compose.foundation.pager.PagerState pagerState) {
        if (!z) {
            kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$OnboardingPager$1$1$1$1(pagerState, null), 3, null);
        } else {
            function0.invoke();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void OnboardingPage(final uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingContent onboardingContent, final androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1673094229);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(OnboardingPage)N(content,modifier)103@3668L7,105@3681L438:ICSOnboardingScreen.kt#760l7a");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(onboardingContent) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 != 0) {
            i3 |= 48;
        } else if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(modifier) ? 32 : 16;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 19) != 18, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            if (i4 != 0) {
                modifier = androidx.compose.ui.Modifier.INSTANCE;
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1673094229, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.OnboardingPage (ICSOnboardingScreen.kt:102)");
            }
            androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
            java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
            androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(modifier, 0.0f, 1, null);
            androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
            androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical center = androidx.compose.foundation.layout.Arrangement.INSTANCE.getCenter();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(center, centerHorizontally, composerStartRestartGroup, 54);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierFillMaxSize$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 422994063, "C110@3858L37,112@3905L53,115@4004L32,116@4064L38,114@3968L145:ICSOnboardingScreen.kt#760l7a");
            uhggroup.iceskating.app.ui.composable.screen.onboarding.icon.OnboardingIconKt.OnboardingIcon(onboardingContent.getIcons(), null, composerStartRestartGroup, 0, 2);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11621getSectionGapD9Ej5fM()), composerStartRestartGroup, 0);
            uhggroup.iceskating.app.ui.composable.screen.onboarding.text.OnboardingTextKt.OnboardingText(androidx.compose.ui.res.StringResources_androidKt.stringResource(onboardingContent.getTitleRes(), composerStartRestartGroup, 0), androidx.compose.ui.res.StringResources_androidKt.stringResource(onboardingContent.getDescriptionRes(), composerStartRestartGroup, 0), null, composerStartRestartGroup, 0, 4);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.OnboardingPage$lambda$1(onboardingContent, modifier, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean ICSOnboardingScreen$lambda$0(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue().booleanValue();
    }
}
