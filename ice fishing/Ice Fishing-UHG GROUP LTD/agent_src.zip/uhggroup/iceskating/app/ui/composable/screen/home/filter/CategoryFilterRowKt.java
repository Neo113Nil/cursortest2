package uhggroup.iceskating.app.ui.composable.screen.home.filter;

/* compiled from: CategoryFilterRow.kt */
@kotlin.Metadata(d1 = {"\u00008\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a7\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\u0014\u0010\n\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\u0004\u0012\u00020\u00050\u000bH\u0007¢\u0006\u0002\u0010\f\u001a5\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\b\u001a\u00020\t2\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00050\u0013H\u0003¢\u0006\u0002\u0010\u0014\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\u0015"}, d2 = {"MARKER_SIZE", "Landroidx/compose/ui/unit/Dp;", "F", "MARKER_BORDER_WIDTH", "CategoryFilterRow", "", "selectedCategory", "Luhggroup/iceskating/app/data/model/ProductCategory;", "modifier", "Landroidx/compose/ui/Modifier;", "onCategoryClick", "Lkotlin/Function1;", "(Luhggroup/iceskating/app/data/model/ProductCategory;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "CategoryChip", "isSelected", "", "title", "", "onClick", "Lkotlin/Function0;", "(ZLjava/lang/String;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CategoryFilterRowKt {
    private static final float MARKER_SIZE = androidx.compose.ui.unit.Dp.m8851constructorimpl(8);
    private static final float MARKER_BORDER_WIDTH = androidx.compose.ui.unit.Dp.m8851constructorimpl(1);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryChip$lambda$1(boolean z, java.lang.String str, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        CategoryChip(z, str, modifier, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryFilterRow$lambda$1(uhggroup.iceskating.app.data.model.ProductCategory productCategory, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function1 function1, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        CategoryFilterRow(productCategory, modifier, function1, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:64:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void CategoryFilterRow(final uhggroup.iceskating.app.data.model.ProductCategory productCategory, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function1<? super uhggroup.iceskating.app.data.model.ProductCategory, kotlin.Unit> onCategoryClick, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onCategoryClick, "onCategoryClick");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(144555877);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CategoryFilterRow)N(selectedCategory,modifier,onCategoryClick)41@1687L7,47@1908L534,43@1700L742:CategoryFilterRow.kt#w0ba9k");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(productCategory == null ? -1 : productCategory.ordinal()) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(onCategoryClick) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(144555877, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRow (CategoryFilterRow.kt:40)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.ui.Modifier modifierFillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null);
                androidx.compose.foundation.layout.PaddingValues paddingValuesM1157PaddingValuesYgX7TsA$default = androidx.compose.foundation.layout.PaddingKt.m1157PaddingValuesYgX7TsA$default(dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null);
                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical horizontalOrVerticalM836spacedBy0680j_4 = androidx.compose.foundation.layout.Arrangement.INSTANCE.m836spacedBy0680j_4(dimens.m11619getItemSpacingD9Ej5fM());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1479257691, "CC(remember):CategoryFilterRow.kt#9igjgp");
                boolean z = ((i3 & 14) == 4) | ((i3 & 896) == 256);
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (z || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryFilterRow$lambda$0$0(productCategory, onCategoryClick, (androidx.compose.foundation.lazy.LazyListScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.ui.Modifier modifier4 = companion;
                androidx.compose.foundation.lazy.LazyDslKt.LazyRow(modifierFillMaxWidth$default, null, paddingValuesM1157PaddingValuesYgX7TsA$default, false, horizontalOrVerticalM836spacedBy0680j_4, null, null, false, null, (kotlin.jvm.functions.Function1) objRememberedValue, composerStartRestartGroup, 0, 490);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryFilterRow$lambda$1(productCategory, modifier3, onCategoryClick, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if ((i & 384) == 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryFilterRow$lambda$0$0(final uhggroup.iceskating.app.data.model.ProductCategory productCategory, final kotlin.jvm.functions.Function1 function1, androidx.compose.foundation.lazy.LazyListScope LazyRow) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(LazyRow, "$this$LazyRow");
        androidx.compose.foundation.lazy.LazyListScope.item$default(LazyRow, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-833764536, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryFilterRow$lambda$0$0$0(productCategory, function1, (androidx.compose.foundation.lazy.LazyItemScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }), 3, null);
        final kotlin.enums.EnumEntries<uhggroup.iceskating.app.data.model.ProductCategory> entries = uhggroup.iceskating.app.data.model.ProductCategory.getEntries();
        final uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$1 categoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$1 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Void invoke(uhggroup.iceskating.app.data.model.ProductCategory productCategory2) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object obj) {
                return invoke((uhggroup.iceskating.app.data.model.ProductCategory) obj);
            }
        };
        LazyRow.items(entries.size(), null, new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return categoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$1.invoke(entries.get(i));
            }
        }, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(802480018, true, new kotlin.jvm.functions.Function4<androidx.compose.foundation.lazy.LazyItemScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$CategoryFilterRow$lambda$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, java.lang.Integer num, androidx.compose.runtime.Composer composer, java.lang.Integer num2) throws android.content.res.Resources.NotFoundException {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, int i, androidx.compose.runtime.Composer composer, int i2) throws android.content.res.Resources.NotFoundException {
                int i3;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final uhggroup.iceskating.app.data.model.ProductCategory productCategory2 = (uhggroup.iceskating.app.data.model.ProductCategory) entries.get(i);
                composer.startReplaceGroup(410470186);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(category)*59@2321L33,60@2382L29,57@2224L202:CategoryFilterRow.kt#w0ba9k");
                boolean z = productCategory == productCategory2;
                java.lang.String strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(productCategory2.getTitleRes(), composer, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -679490804, "CC(remember):CategoryFilterRow.kt#9igjgp");
                boolean zChanged = composer.changed(function1) | composer.changed(productCategory2.ordinal());
                java.lang.Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function12 = function1;
                    objRememberedValue = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$CategoryFilterRow$1$1$2$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function12.invoke(productCategory2);
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryChip(z, strStringResource, null, (kotlin.jvm.functions.Function0) objRememberedValue, composer, 0, 4);
                composer.endReplaceGroup();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryFilterRow$lambda$0$0$0(uhggroup.iceskating.app.data.model.ProductCategory productCategory, final kotlin.jvm.functions.Function1 function1, androidx.compose.foundation.lazy.LazyItemScope item, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "$this$item");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C51@2030L41,52@2099L25,49@1937L202:CategoryFilterRow.kt#w0ba9k");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-833764536, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRow.<anonymous>.<anonymous>.<anonymous> (CategoryFilterRow.kt:49)");
            }
            boolean z = productCategory == null;
            java.lang.String strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.ics_category_all, composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1911170913, "CC(remember):CategoryFilterRow.kt#9igjgp");
            boolean zChanged = composer.changed(function1);
            java.lang.Object objRememberedValue = composer.rememberedValue();
            if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryFilterRow$lambda$0$0$0$0$0(function1);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            CategoryChip(z, strStringResource, null, (kotlin.jvm.functions.Function0) objRememberedValue, composer, 0, 4);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryFilterRow$lambda$0$0$0$0$0(kotlin.jvm.functions.Function1 function1) {
        function1.invoke(null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0056  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x015c  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:63:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void CategoryChip(final boolean z, final java.lang.String str, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        long surfaceContainerLow;
        long onSurfaceVariant;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1677519098);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CategoryChip)N(isSelected,title,modifier,onClick)73@2621L7,91@3202L21,92@3231L1020,76@2697L1554:CategoryFilterRow.kt#w0ba9k");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(z) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(str) ? 32 : 16;
        }
        int i4 = i2 & 4;
        if (i4 == 0) {
            if ((i & 384) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 256 : 128;
            }
            if ((i & 3072) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(function0) ? 2048 : 1024;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1677519098, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryChip (CategoryFilterRow.kt:72)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeM1543RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11616getControlCornerRadiusD9Ej5fM());
                androidx.compose.ui.Modifier modifierM370clickableoSLSa3U$default = androidx.compose.foundation.ClickableKt.m370clickableoSLSa3U$default(androidx.compose.ui.draw.ClipKt.clip(companion, roundedCornerShapeM1543RoundedCornerShape0680j_4), false, null, null, null, function0, 15, null);
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(-1267617756);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "82@2885L11");
                    surfaceContainerLow = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSecondaryContainer();
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-1267544317);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "84@2959L11");
                    surfaceContainerLow = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerLow();
                    composerStartRestartGroup.endReplaceGroup();
                }
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(-1267435166);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "87@3069L11");
                    onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSecondaryContainer();
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-1267359898);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "89@3145L11");
                    onSurfaceVariant = androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant();
                    composerStartRestartGroup.endReplaceGroup();
                }
                androidx.compose.foundation.BorderStroke borderStrokeM11517controlBorderStrokeIv8Zu3U = uhggroup.iceskating.app.ui.theme.BordersKt.m11517controlBorderStrokeIv8Zu3U(0L, composerStartRestartGroup, 0, 1);
                androidx.compose.runtime.internal.ComposableLambda composableLambdaRememberComposableLambda = androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1083644607, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryChip$lambda$0(z, dimens, str, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54);
                androidx.compose.ui.Modifier modifier4 = companion;
                composer2 = composerStartRestartGroup;
                androidx.compose.material3.SurfaceKt.m3545SurfaceT9BRK9s(modifierM370clickableoSLSa3U$default, roundedCornerShapeM1543RoundedCornerShape0680j_4, surfaceContainerLow, onSurfaceVariant, 0.0f, 0.0f, borderStrokeM11517controlBorderStrokeIv8Zu3U, composableLambdaRememberComposableLambda, composer2, 12582912, 48);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryFilterRowKt.CategoryChip$lambda$1(z, str, modifier3, function0, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 384;
        modifier2 = modifier;
        if ((i & 3072) == 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) == 1170, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CategoryChip$lambda$0(boolean z, uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, java.lang.String str, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.ui.Modifier modifierM341borderxT4_qwU;
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C93@3241L1004:CategoryFilterRow.kt#w0ba9k");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1083644607, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.filter.CategoryChip.<anonymous> (CategoryFilterRow.kt:93)");
            }
            androidx.compose.ui.Modifier modifierM1163paddingVpY3zN4 = androidx.compose.foundation.layout.PaddingKt.m1163paddingVpY3zN4(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(12), androidx.compose.ui.unit.Dp.m8851constructorimpl(8));
            androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composer, 48);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierM1163paddingVpY3zN4);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -588069019, "C97@3408L636,114@4058L53,118@4199L10,116@4125L110:CategoryFilterRow.kt#w0ba9k");
            androidx.compose.ui.Modifier modifierClip = androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, MARKER_SIZE), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
            if (z) {
                composer.startReplaceGroup(-587906735);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "103@3658L11");
                modifierM341borderxT4_qwU = androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), null, 2, null);
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-587785835);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "107@3872L11");
                modifierM341borderxT4_qwU = androidx.compose.foundation.BorderKt.m341borderxT4_qwU(androidx.compose.ui.Modifier.INSTANCE, MARKER_BORDER_WIDTH, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOutlineVariant(), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape());
                composer.endReplaceGroup();
            }
            androidx.compose.foundation.layout.BoxKt.Box(modifierClip.then(modifierM341borderxT4_qwU), composer, 0);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11619getItemSpacingD9Ej5fM()), composer, 0);
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelLarge(), composer, 0, 0, 131070);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
