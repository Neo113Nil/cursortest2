package uhggroup.iceskating.app.ui.composable.screen.checkout.form;

/* compiled from: CheckoutForm.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a{\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00010\r2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00010\r2\u0012\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00010\rH\u0007¢\u0006\u0002\u0010\u0010¨\u0006\u0011"}, d2 = {"CheckoutForm", "", "customerFirstName", "", "customerLastName", "customerEmail", "isEmailInvalid", "", "modifier", "Landroidx/compose/ui/Modifier;", "focusManager", "Landroidx/compose/ui/focus/FocusManager;", "onFirstNameChanged", "Lkotlin/Function1;", "onLastNameChanged", "onEmailChanged", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/ui/Modifier;Landroidx/compose/ui/focus/FocusManager;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CheckoutFormKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutForm$lambda$1(java.lang.String str, java.lang.String str2, java.lang.String str3, boolean z, androidx.compose.ui.Modifier modifier, androidx.compose.ui.focus.FocusManager focusManager, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, kotlin.jvm.functions.Function1 function13, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        CheckoutForm(str, str2, str3, z, modifier, focusManager, function1, function12, function13, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x047d  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0487  */
    /* JADX WARN: Removed duplicated region for block: B:117:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00c6  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00d7  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00f8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void CheckoutForm(final java.lang.String customerFirstName, final java.lang.String customerLastName, final java.lang.String customerEmail, final boolean z, androidx.compose.ui.Modifier modifier, final androidx.compose.ui.focus.FocusManager focusManager, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onFirstNameChanged, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onLastNameChanged, final kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onEmailChanged, androidx.compose.runtime.Composer composer, final int i, final int i2) throws android.content.res.Resources.NotFoundException {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        java.lang.String strStringResource;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerFirstName, "customerFirstName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerLastName, "customerLastName");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(customerEmail, "customerEmail");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(focusManager, "focusManager");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onFirstNameChanged, "onFirstNameChanged");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onLastNameChanged, "onLastNameChanged");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onEmailChanged, "onEmailChanged");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-111657239);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CheckoutForm)N(customerFirstName,customerLastName,customerEmail,isEmailInvalid,modifier,focusManager,onFirstNameChanged,onLastNameChanged,onEmailChanged)38@1559L2699:CheckoutForm.kt#8w22kd");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(customerFirstName) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(customerLastName) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changed(customerEmail) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changed(z) ? 2048 : 1024;
        }
        int i4 = i2 & 16;
        if (i4 == 0) {
            if ((i & 24576) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 16384 : 8192;
            }
            if ((196608 & i) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(focusManager) ? 131072 : 65536;
            }
            if ((1572864 & i) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(onFirstNameChanged) ? 1048576 : 524288;
            }
            if ((12582912 & i) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(onLastNameChanged) ? 8388608 : 4194304;
            }
            if ((100663296 & i) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(onEmailChanged) ? 67108864 : androidx.compose.runtime.composer.linkbuffer.GroupFlagsKt.HasAuxSlotFlag;
            }
            if (composerStartRestartGroup.shouldExecute((38347923 & i3) == 38347922, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-111657239, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutForm (CheckoutForm.kt:37)");
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -951309519, "C40@1622L42,41@1700L11,42@1760L10,39@1597L198,45@1805L40,48@1880L44,49@1960L11,50@2024L10,47@1855L201,53@2066L41,58@2247L55,66@2642L47,55@2117L597,70@2724L41,75@2903L54,83@3296L47,72@2775L593,87@3378L41,92@3551L50,106@4198L29,89@3429L823:CheckoutForm.kt#8w22kd");
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_headline, composerStartRestartGroup, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnBackground(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getHeadlineSmall(), composerStartRestartGroup, 0, 0, 131066);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(8)), composerStartRestartGroup, 6);
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_invitation, composerStartRestartGroup, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getBodyMedium(), composerStartRestartGroup, 0, 0, 131066);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(20)), composerStartRestartGroup, 6);
                java.lang.String strStringResource2 = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_text_field_first_name, composerStartRestartGroup, 0);
                androidx.compose.ui.Modifier modifierFillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.ui.graphics.vector.ImageVector person = androidx.compose.material.icons.outlined.PersonKt.getPerson(androidx.compose.material.icons.Icons.Outlined.INSTANCE);
                androidx.compose.foundation.text.KeyboardOptions keyboardOptions = new androidx.compose.foundation.text.KeyboardOptions(androidx.compose.ui.text.input.KeyboardCapitalization.INSTANCE.m8515getWordsIUNYP9k(), (java.lang.Boolean) null, 0, androidx.compose.ui.text.input.ImeAction.INSTANCE.m8482getNexteUduSuo(), (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 118, (kotlin.jvm.internal.DefaultConstructorMarker) null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2047553410, "CC(remember):CheckoutForm.kt#9igjgp");
                boolean zChangedInstance = composerStartRestartGroup.changedInstance(focusManager);
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt.CheckoutForm$lambda$0$0$0(focusManager, (androidx.compose.foundation.text.KeyboardActionScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                int i5 = i3;
                androidx.compose.ui.Modifier modifier4 = companion;
                uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt.CheckoutTextField(customerFirstName, onFirstNameChanged, strStringResource2, modifierFillMaxWidth$default, false, false, person, null, null, keyboardOptions, new androidx.compose.foundation.text.KeyboardActions(null, null, (kotlin.jvm.functions.Function1) objRememberedValue, null, null, null, 59, null), composerStartRestartGroup, ((i3 >> 15) & 112) | (i3 & 14) | 805309440, 0, 432);
                float f = 12;
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f)), composerStartRestartGroup, 6);
                java.lang.String strStringResource3 = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_text_field_last_name, composerStartRestartGroup, 0);
                androidx.compose.ui.Modifier modifierFillMaxWidth$default2 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.ui.graphics.vector.ImageVector badge = androidx.compose.material.icons.outlined.BadgeKt.getBadge(androidx.compose.material.icons.Icons.Outlined.INSTANCE);
                androidx.compose.foundation.text.KeyboardOptions keyboardOptions2 = new androidx.compose.foundation.text.KeyboardOptions(androidx.compose.ui.text.input.KeyboardCapitalization.INSTANCE.m8515getWordsIUNYP9k(), (java.lang.Boolean) null, 0, androidx.compose.ui.text.input.ImeAction.INSTANCE.m8482getNexteUduSuo(), (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 118, (kotlin.jvm.internal.DefaultConstructorMarker) null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2047574338, "CC(remember):CheckoutForm.kt#9igjgp");
                boolean zChangedInstance2 = composerStartRestartGroup.changedInstance(focusManager);
                java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance2 || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt.CheckoutForm$lambda$0$1$0(focusManager, (androidx.compose.foundation.text.KeyboardActionScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt.CheckoutTextField(customerLastName, onLastNameChanged, strStringResource3, modifierFillMaxWidth$default2, false, false, badge, null, null, keyboardOptions2, new androidx.compose.foundation.text.KeyboardActions(null, null, (kotlin.jvm.functions.Function1) objRememberedValue2, null, null, null, 59, null), composerStartRestartGroup, ((i5 >> 3) & 14) | 805309440 | ((i5 >> 18) & 112), 0, 432);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(f)), composerStartRestartGroup, 6);
                java.lang.String strStringResource4 = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_text_field_email, composerStartRestartGroup, 0);
                androidx.compose.ui.Modifier modifierFillMaxWidth$default3 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
                androidx.compose.ui.graphics.vector.ImageVector mailOutline = androidx.compose.material.icons.outlined.MailOutlineKt.getMailOutline(androidx.compose.material.icons.Icons.Outlined.INSTANCE);
                if (z) {
                    composerStartRestartGroup.startReplaceGroup(-949211843);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "97@3810L50");
                    strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_email_error_text, composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                } else {
                    composerStartRestartGroup.startReplaceGroup(-949124392);
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "99@3898L55");
                    strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.checkout_email_supporting_text, composerStartRestartGroup, 0);
                    composerStartRestartGroup.endReplaceGroup();
                }
                java.lang.String str = strStringResource;
                androidx.compose.foundation.text.KeyboardOptions keyboardOptions3 = new androidx.compose.foundation.text.KeyboardOptions(0, (java.lang.Boolean) null, androidx.compose.ui.text.input.KeyboardType.INSTANCE.m8535getEmailPjHm6EE(), androidx.compose.ui.text.input.ImeAction.INSTANCE.m8480getDoneeUduSuo(), (androidx.compose.ui.text.input.PlatformImeOptions) null, (java.lang.Boolean) null, (androidx.compose.ui.text.intl.LocaleList) null, 115, (kotlin.jvm.internal.DefaultConstructorMarker) null);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2047603184, "CC(remember):CheckoutForm.kt#9igjgp");
                boolean zChangedInstance3 = composerStartRestartGroup.changedInstance(focusManager);
                java.lang.Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance3 || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt.CheckoutForm$lambda$0$2$0(focusManager, (androidx.compose.foundation.text.KeyboardActionScope) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.composable.screen.checkout.field.CheckoutTextFieldKt.CheckoutTextField(customerEmail, onEmailChanged, strStringResource4, modifierFillMaxWidth$default3, false, z, mailOutline, str, null, keyboardOptions3, new androidx.compose.foundation.text.KeyboardActions((kotlin.jvm.functions.Function1) objRememberedValue3, null, null, null, null, null, 62, null), composerStartRestartGroup, ((i5 >> 6) & 14) | 805309440 | ((i5 >> 21) & 112) | (458752 & (i5 << 6)), 0, 272);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.checkout.form.CheckoutFormKt.CheckoutForm$lambda$1(customerFirstName, customerLastName, customerEmail, z, modifier3, focusManager, onFirstNameChanged, onLastNameChanged, onEmailChanged, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 24576;
        modifier2 = modifier;
        if ((196608 & i) == 0) {
        }
        if ((1572864 & i) == 0) {
        }
        if ((12582912 & i) == 0) {
        }
        if ((100663296 & i) == 0) {
        }
        if (composerStartRestartGroup.shouldExecute((38347923 & i3) == 38347922, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutForm$lambda$0$0$0(androidx.compose.ui.focus.FocusManager focusManager, androidx.compose.foundation.text.KeyboardActionScope KeyboardActions) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(KeyboardActions, "$this$KeyboardActions");
        focusManager.mo5626moveFocus3ESFkO8(androidx.compose.ui.focus.FocusDirection.INSTANCE.m5616getDowndhqQ8s());
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutForm$lambda$0$1$0(androidx.compose.ui.focus.FocusManager focusManager, androidx.compose.foundation.text.KeyboardActionScope KeyboardActions) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(KeyboardActions, "$this$KeyboardActions");
        focusManager.mo5626moveFocus3ESFkO8(androidx.compose.ui.focus.FocusDirection.INSTANCE.m5616getDowndhqQ8s());
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutForm$lambda$0$2$0(androidx.compose.ui.focus.FocusManager focusManager, androidx.compose.foundation.text.KeyboardActionScope KeyboardActions) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(KeyboardActions, "$this$KeyboardActions");
        androidx.compose.ui.focus.FocusManager.clearFocus$default(focusManager, false, 1, null);
        return kotlin.Unit.INSTANCE;
    }
}
