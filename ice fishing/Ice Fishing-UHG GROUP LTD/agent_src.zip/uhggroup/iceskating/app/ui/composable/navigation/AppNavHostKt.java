package uhggroup.iceskating.app.ui.composable.navigation;

/* compiled from: AppNavHost.kt */
@kotlin.Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007"}, d2 = {"AppNavHost", "", "navController", "Landroidx/navigation/NavHostController;", "modifier", "Landroidx/compose/ui/Modifier;", "(Landroidx/navigation/NavHostController;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppNavHostKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$1(androidx.navigation.NavHostController navHostController, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        AppNavHost(navHostController, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AppNavHost(final androidx.navigation.NavHostController navController, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navController, "navController");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-480028459);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AppNavHost)N(navController,modifier)26@1166L2447,22@1039L2574:AppNavHost.kt#lkihw9");
        if ((i & 6) == 0) {
            i3 = i | (composerStartRestartGroup.changedInstance(navController) ? 4 : 2);
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-480028459, i3, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost (AppNavHost.kt:21)");
                }
                uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash splash = uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1745838812, "CC(remember):AppNavHost.kt#9igjgp");
                boolean zChangedInstance = composerStartRestartGroup.changedInstance(navController);
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda7
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0(navController, (androidx.navigation.NavGraphBuilder) obj);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                int i5 = (i3 & 14) | 48 | ((i3 << 3) & 896);
                modifier3 = companion;
                androidx.navigation.compose.NavHostKt.NavHost(navController, splash, modifier3, (androidx.compose.ui.Alignment) null, (kotlin.reflect.KClass<?>) null, (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) null, (kotlin.jvm.functions.Function1<androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, (kotlin.jvm.functions.Function1<? super androidx.navigation.NavGraphBuilder, kotlin.Unit>) objRememberedValue, composerStartRestartGroup, i5, 0, 2040);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$1(navController, modifier3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0(final androidx.navigation.NavHostController navHostController, androidx.navigation.NavGraphBuilder NavHost) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
        androidx.compose.runtime.internal.ComposableLambda composableLambdaComposableLambdaInstance = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1282368652, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda19
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0(navHostController, (androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        });
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, composableLambdaComposableLambdaInstance);
        androidx.compose.runtime.internal.ComposableLambda composableLambdaComposableLambdaInstance2 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-778408291, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda20
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$1(navHostController, (androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        });
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, composableLambdaComposableLambdaInstance2);
        androidx.compose.runtime.internal.ComposableLambda composableLambdaComposableLambdaInstance3 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1761401668, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$2(navHostController, (androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        });
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, composableLambdaComposableLambdaInstance3);
        kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1550572251$app_release = uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.INSTANCE.getLambda$1550572251$app_release();
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, lambda$1550572251$app_release);
        androidx.compose.runtime.internal.ComposableLambda composableLambdaComposableLambdaInstance4 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(567578874, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$3(navHostController, (androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        });
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, composableLambdaComposableLambdaInstance4);
        androidx.compose.runtime.internal.ComposableLambda composableLambdaComposableLambdaInstance5 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-415414503, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function4
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$4(navHostController, (androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
            }
        });
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, composableLambdaComposableLambdaInstance5);
        kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> function4M11462getLambda$1398407880$app_release = uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.INSTANCE.m11462getLambda$1398407880$app_release();
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, function4M11462getLambda$1398407880$app_release);
        kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1913566039$app_release = uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.INSTANCE.getLambda$1913566039$app_release();
        androidx.navigation.compose.NavGraphBuilderKt.composable(NavHost, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings.class), (java.util.Map<kotlin.reflect.KType, androidx.navigation.NavType<?>>) kotlin.collections.MapsKt.emptyMap(), (java.util.List<androidx.navigation.NavDeepLink>) kotlin.collections.CollectionsKt.emptyList(), (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.EnterTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.ExitTransition>) null, (kotlin.jvm.functions.Function1<? super androidx.compose.animation.AnimatedContentTransitionScope<androidx.navigation.NavBackStackEntry>, androidx.compose.animation.SizeTransform>) null, lambda$1913566039$app_release);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0(final androidx.navigation.NavHostController navHostController, androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)29@1276L301,37@1620L307,28@1218L723:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-1282368652, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost.<anonymous>.<anonymous>.<anonymous> (AppNavHost.kt:28)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 299341985, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$0$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        kotlin.jvm.functions.Function0 function0 = (kotlin.jvm.functions.Function0) objRememberedValue;
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 299352999, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance2 = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue2 = composer.rememberedValue();
        if (zChangedInstance2 || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue2 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$1$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue2);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt.ICSSplashScreen(null, null, function0, (kotlin.jvm.functions.Function0) objRememberedValue2, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$0$0(final androidx.navigation.NavHostController navHostController) {
        navHostController.navigate((androidx.navigation.NavHostController) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$0$0$0(navHostController, (androidx.navigation.NavOptionsBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$0$0$0(androidx.navigation.NavHostController navHostController, androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo(navHostController.getGraph().getStartDestinationId(), new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda14
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$0$0$0$0((androidx.navigation.PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$0$0$0$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$1$0(final androidx.navigation.NavHostController navHostController) {
        navHostController.navigate((androidx.navigation.NavHostController) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda16
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$1$0$0(navHostController, (androidx.navigation.NavOptionsBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$1$0$0(androidx.navigation.NavHostController navHostController, androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo(navHostController.getGraph().getStartDestinationId(), new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$0$1$0$0$0((androidx.navigation.PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$0$1$0$0$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$1(final androidx.navigation.NavHostController navHostController, androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)50@2069L274,49@2007L350:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-778408291, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost.<anonymous>.<anonymous>.<anonymous> (AppNavHost.kt:49)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -726055441, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$1$0$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        uhggroup.iceskating.app.ui.composable.screen.onboarding.ICSOnboardingScreenKt.ICSOnboardingScreen(null, null, (kotlin.jvm.functions.Function0) objRememberedValue, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$1$0$0(androidx.navigation.NavHostController navHostController) {
        navHostController.navigate((androidx.navigation.NavHostController) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda9
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$1$0$0$0((androidx.navigation.NavOptionsBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$1$0$0$0(androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo((androidx.navigation.NavOptionsBuilder) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda15
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$1$0$0$0$0((androidx.navigation.PopUpToBuilder) obj);
            }
        });
        navigate.setLaunchSingleTop(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$1$0$0$0$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$2(final androidx.navigation.NavHostController navHostController, androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)63@2477L161,62@2417L235:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-1761401668, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost.<anonymous>.<anonymous>.<anonymous> (AppNavHost.kt:62)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -489885795, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function1
                public final java.lang.Object invoke(java.lang.Object obj) {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$2$0$0(navHostController, ((java.lang.Integer) obj).intValue());
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        uhggroup.iceskating.app.ui.composable.screen.home.ICSHomeScreenKt.ICSHomeScreen(null, null, (kotlin.jvm.functions.Function1) objRememberedValue, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$2$0$0(androidx.navigation.NavHostController navHostController, int i) {
        androidx.navigation.NavController.navigate$default(navHostController, new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails(i), (androidx.navigation.NavOptions) null, (androidx.navigation.Navigator.Extras) null, 6, (java.lang.Object) null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$3(final androidx.navigation.NavHostController navHostController, androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)80@3028L81,79@2968L155:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(567578874, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost.<anonymous>.<anonymous>.<anonymous> (AppNavHost.kt:79)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -17546229, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$3$0$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen(null, null, (kotlin.jvm.functions.Function0) objRememberedValue, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$3$0$0(androidx.navigation.NavHostController navHostController) {
        androidx.navigation.NavController.navigate$default(navHostController, uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout.INSTANCE, (androidx.navigation.NavOptions) null, (androidx.navigation.Navigator.Extras) null, 6, (java.lang.Object) null);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$4(final androidx.navigation.NavHostController navHostController, androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)88@3249L172,87@3187L248:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-415414503, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.AppNavHost.<anonymous>.<anonymous>.<anonymous> (AppNavHost.kt:87)");
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 218623749, "CC(remember):AppNavHost.kt#9igjgp");
        boolean zChangedInstance = composer.changedInstance(navHostController);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$4$0$0(navHostController);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        uhggroup.iceskating.app.ui.composable.screen.checkout.ICSCheckoutScreenKt.ICSCheckoutScreen(null, null, (kotlin.jvm.functions.Function0) objRememberedValue, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$4$0$0(androidx.navigation.NavHostController navHostController) {
        navHostController.navigate((androidx.navigation.NavHostController) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda17
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$4$0$0$0((androidx.navigation.NavOptionsBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$4$0$0$0(androidx.navigation.NavOptionsBuilder navigate) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
        navigate.popUpTo((androidx.navigation.NavOptionsBuilder) uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home.INSTANCE, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.navigation.AppNavHostKt.AppNavHost$lambda$0$0$4$0$0$0$0((androidx.navigation.PopUpToBuilder) obj);
            }
        });
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AppNavHost$lambda$0$0$4$0$0$0$0(androidx.navigation.PopUpToBuilder popUpTo) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
        popUpTo.setInclusive(false);
        return kotlin.Unit.INSTANCE;
    }
}
