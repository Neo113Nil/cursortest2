package uhggroup.iceskating.app.ui.composable.screen.home.slider;

/* compiled from: FeaturedSlider.kt */
@kotlin.Metadata(d1 = {"\u0000(\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\b\u001aH\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062!\u0010\u0007\u001a\u001d\u0012\u0013\u0012\u00110\t¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u00010\bH\u0007¢\u0006\u0002\u0010\r\u001a'\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\t2\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\u0003¢\u0006\u0002\u0010\u0011¨\u0006\u0012"}, d2 = {"FeaturedSlider", "", "products", "", "Luhggroup/iceskating/app/data/model/Product;", "modifier", "Landroidx/compose/ui/Modifier;", "onProductClick", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", androidx.autofill.HintConstants.AUTOFILL_HINT_NAME, "productId", "(Ljava/util/List;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "PagerIndicator", "pageCount", "currentPage", "(IILandroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class FeaturedSliderKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit FeaturedSlider$lambda$2(java.util.List list, androidx.compose.ui.Modifier modifier, kotlin.jvm.functions.Function1 function1, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        FeaturedSlider(list, modifier, function1, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit PagerIndicator$lambda$1(int i, int i2, androidx.compose.ui.Modifier modifier, int i3, int i4, androidx.compose.runtime.Composer composer, int i5) {
        PagerIndicator(i, i2, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i3 | 1), i4);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0120  */
    /* JADX WARN: Removed duplicated region for block: B:54:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void FeaturedSlider(final java.util.List<uhggroup.iceskating.app.data.model.Product> products, androidx.compose.ui.Modifier modifier, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onProductClick, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        androidx.compose.runtime.Composer composer2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(products, "products");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onProductClick, "onProductClick");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-884694149);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(FeaturedSlider)N(products,modifier,onProductClick)45@1981L17,45@1962L36,46@2028L7,53@2256L2916,48@2041L3131:FeaturedSlider.kt#wtmjmn");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(products) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(onProductClick) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier modifier4 = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-884694149, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSlider (FeaturedSlider.kt:44)");
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 212453004, "CC(remember):FeaturedSlider.kt#9igjgp");
                boolean zChangedInstance = composerStartRestartGroup.changedInstance(products);
                java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return java.lang.Integer.valueOf(products.size());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final androidx.compose.foundation.pager.PagerState pagerStateRememberPagerState = androidx.compose.foundation.pager.PagerStateKt.rememberPagerState(0, 0.0f, (kotlin.jvm.functions.Function0) objRememberedValue, composerStartRestartGroup, 0, 3);
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                composer2 = composerStartRestartGroup;
                androidx.compose.ui.Modifier modifier5 = modifier4;
                androidx.compose.foundation.pager.PagerKt.m1481HorizontalPager8jOkeI(pagerStateRememberPagerState, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(modifier4, 0.0f, 1, null), androidx.compose.foundation.layout.PaddingKt.m1157PaddingValuesYgX7TsA$default(dimens.m11620getScreenPaddingD9Ej5fM(), 0.0f, 2, null), null, 0, dimens.m11614getContentSpacingD9Ej5fM(), null, null, false, false, null, null, null, null, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1151028412, true, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function4
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider$lambda$1(products, onProductClick, dimens, pagerStateRememberPagerState, (androidx.compose.foundation.pager.PagerScope) obj, ((java.lang.Integer) obj2).intValue(), (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
                    }
                }, composerStartRestartGroup, 54), composer2, 0, 24576, 16344);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier5;
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider$lambda$2(products, modifier3, onProductClick, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if ((i & 384) == 0) {
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) == 146, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit FeaturedSlider$lambda$1(final java.util.List list, final kotlin.jvm.functions.Function1 function1, final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, final androidx.compose.foundation.pager.PagerState pagerState, androidx.compose.foundation.pager.PagerScope HorizontalPager, int i, androidx.compose.runtime.Composer composer, int i2) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(HorizontalPager, "$this$HorizontalPager");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(page)60@2441L30,63@2631L11,64@2706L11,62@2572L179,66@2774L18,67@2804L2362,56@2312L2854:FeaturedSlider.kt#wtmjmn");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(1151028412, i2, -1, "uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSlider.<anonymous> (FeaturedSlider.kt:54)");
        }
        final uhggroup.iceskating.app.data.model.Product product = (uhggroup.iceskating.app.data.model.Product) list.get(i);
        androidx.compose.ui.Modifier modifierM1218height3ABfNKs = androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.unit.Dp.m8851constructorimpl(180));
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1963252486, "CC(remember):FeaturedSlider.kt#9igjgp");
        boolean zChanged = composer.changed(function1) | composer.changed(product);
        java.lang.Object objRememberedValue = composer.rememberedValue();
        if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function0
                public final java.lang.Object invoke() {
                    return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider$lambda$1$0$0(function1, product);
                }
            };
            composer.updateRememberedValue(objRememberedValue);
        }
        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
        androidx.compose.material3.CardKt.Card(androidx.compose.foundation.ClickableKt.m370clickableoSLSa3U$default(modifierM1218height3ABfNKs, false, null, null, null, (kotlin.jvm.functions.Function0) objRememberedValue, 15, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11612getCardCornerRadiusD9Ej5fM()), androidx.compose.material3.CardDefaults.INSTANCE.m2544cardColorsro_MJ88(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimaryContainer(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnPrimaryContainer(), 0L, 0L, composer, androidx.compose.material3.CardDefaults.$stable << 12, 12), null, uhggroup.iceskating.app.ui.theme.BordersKt.m11516cardBorderStrokeIv8Zu3U(0L, composer, 0, 1), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(477798830, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function3
            public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider$lambda$1$1(product, list, pagerState, dimens, (androidx.compose.foundation.layout.ColumnScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
            }
        }, composer, 54), composer, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit FeaturedSlider$lambda$1$0$0(kotlin.jvm.functions.Function1 function1, uhggroup.iceskating.app.data.model.Product product) {
        function1.invoke(java.lang.Integer.valueOf(product.getId()));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit FeaturedSlider$lambda$1$1(final uhggroup.iceskating.app.data.model.Product product, java.util.List list, androidx.compose.foundation.pager.PagerState pagerState, uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.compose.foundation.layout.ColumnScope Card, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Card, "$this$Card");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C68@2818L2338:FeaturedSlider.kt#wtmjmn");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(477798830, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSlider.<anonymous>.<anonymous> (FeaturedSlider.kt:68)");
            }
            androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierFillMaxSize$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -971247084, "C69@2875L139,77@3170L11,74@3032L194,80@3244L1584,118@4846L296:FeaturedSlider.kt#wtmjmn");
            uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt.ProductImage(product.getImageUrl(), boxScopeInstance.matchParentSize(androidx.compose.ui.Modifier.INSTANCE), null, null, composer, 0, 12);
            androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(boxScopeInstance.matchParentSize(androidx.compose.ui.Modifier.INSTANCE), androidx.compose.ui.graphics.Color.m5981copywmQWz5c$default(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getScrim(), 0.35f, 0.0f, 0.0f, 0.0f, 14, null), null, 2, null), composer, 0);
            androidx.compose.ui.Modifier modifierM1164paddingVpY3zN4$default = androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getCenter()), 0.0f, 1, null), androidx.compose.ui.unit.Dp.m8851constructorimpl(24), 0.0f, 2, null);
            androidx.compose.ui.Alignment.Horizontal centerHorizontally = androidx.compose.ui.Alignment.INSTANCE.getCenterHorizontally();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), centerHorizontally, composer, 48);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode2 = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierM1164paddingVpY3zN4$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl2 = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, java.lang.Integer.valueOf(iHashCode2), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, modifierMaterializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -546726326, "C88@3609L11,89@3694L11,90@3750L306,87@3547L509,98@4078L54,103@4297L10,100@4154L338,109@4514L55,112@4628L45,114@4766L10,111@4591L219:FeaturedSlider.kt#wtmjmn");
            androidx.compose.material3.BadgeKt.m2496BadgeeopBjH0(null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getSecondaryContainer(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSecondaryContainer(), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1569174935, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                    return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.FeaturedSlider$lambda$1$1$0$0$0(product, (androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                }
            }, composer, 54), composer, 3072, 1);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11619getItemSpacingD9Ej5fM()), composer, 0);
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(product.getTitle(), null, androidx.compose.ui.graphics.Color.INSTANCE.m6019getWhite0d7_KjU(), null, 0L, null, null, null, 0L, null, androidx.compose.ui.text.style.TextAlign.m8722boximpl(androidx.compose.ui.text.style.TextAlign.INSTANCE.m8729getCentere0LSkKk()), 0L, androidx.compose.ui.text.style.TextOverflow.INSTANCE.m8787getEllipsisgIe3tQ8(), false, 2, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getTitleMedium(), composer, 384, 24960, 109562);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11622getTightSpacingD9Ej5fM()), composer, 0);
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.price, new java.lang.Object[]{java.lang.Double.valueOf(product.getPrice())}, composer, 0), null, androidx.compose.ui.graphics.Color.INSTANCE.m6019getWhite0d7_KjU(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getTitleSmall(), composer, 384, 0, 131066);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            PagerIndicator(list.size(), pagerState.getCurrentPage(), androidx.compose.foundation.layout.PaddingKt.m1166paddingqDBjuR0$default(boxScopeInstance.align(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.Alignment.INSTANCE.getBottomCenter()), 0.0f, 0.0f, 0.0f, dimens.m11613getCardPaddingD9Ej5fM(), 7, null), composer, 0, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit FeaturedSlider$lambda$1$1$0$0$0(uhggroup.iceskating.app.data.model.Product product, androidx.compose.foundation.layout.RowScope Badge, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Badge, "$this$Badge");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C92@3817L41,94@3986L10,91@3776L258:FeaturedSlider.kt#wtmjmn");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1569174935, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSlider.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (FeaturedSlider.kt:91)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(product.getCategory().getTitleRes(), composer, 0), androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(6), 0.0f, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelSmall(), composer, 48, 0, 131068);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x005b  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x01a9  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x01b3  */
    /* JADX WARN: Removed duplicated region for block: B:72:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void PagerIndicator(final int i, final int i2, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i3, final int i4) {
        int i5;
        androidx.compose.ui.Modifier modifier2;
        androidx.compose.ui.Modifier.Companion companion;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1430548227);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(PagerIndicator)N(pageCount,currentPage,modifier)136@5301L603:FeaturedSlider.kt#wtmjmn");
        if ((i3 & 6) == 0) {
            i5 = (composerStartRestartGroup.changed(i) ? 4 : 2) | i3;
        } else {
            i5 = i3;
        }
        if ((i3 & 48) == 0) {
            i5 |= composerStartRestartGroup.changed(i2) ? 32 : 16;
        }
        int i6 = i4 & 4;
        if (i6 == 0) {
            if ((i3 & 384) == 0) {
                modifier2 = modifier;
                i5 |= composerStartRestartGroup.changed(modifier2) ? 256 : 128;
            }
            if (composerStartRestartGroup.shouldExecute((i5 & 147) == 146, i5 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                companion = modifier2;
            } else {
                companion = i6 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(1430548227, i5, -1, "uhggroup.iceskating.app.ui.composable.screen.home.slider.PagerIndicator (FeaturedSlider.kt:135)");
                }
                androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical center = androidx.compose.foundation.layout.Arrangement.INSTANCE.getCenter();
                androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(center, centerVertically, composerStartRestartGroup, 54);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1588037485, "C:FeaturedSlider.kt#wtmjmn");
                composerStartRestartGroup.startReplaceGroup(-1611340970);
                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "*144@5548L340");
                int i7 = 0;
                while (i7 < i) {
                    boolean z = i7 == i2;
                    androidx.compose.foundation.layout.BoxKt.Box(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.foundation.layout.PaddingKt.m1164paddingVpY3zN4$default(androidx.compose.ui.Modifier.INSTANCE, androidx.compose.ui.unit.Dp.m8851constructorimpl(3), 0.0f, 2, null), androidx.compose.ui.unit.Dp.m8851constructorimpl(z ? 8 : 6)), androidx.compose.foundation.shape.RoundedCornerShapeKt.getCircleShape()), z ? androidx.compose.ui.graphics.Color.INSTANCE.m6019getWhite0d7_KjU() : androidx.compose.ui.graphics.Color.m5981copywmQWz5c$default(androidx.compose.ui.graphics.Color.INSTANCE.m6019getWhite0d7_KjU(), 0.5f, 0.0f, 0.0f, 0.0f, 14, null), null, 2, null), composerStartRestartGroup, 0);
                    i7++;
                }
                composerStartRestartGroup.endReplaceGroup();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                final androidx.compose.ui.Modifier modifier3 = companion;
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.home.slider.FeaturedSliderKt.PagerIndicator$lambda$1(i, i2, modifier3, i3, i4, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i5 |= 384;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i5 & 147) == 146, i5 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }
}
