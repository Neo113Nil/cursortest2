package uhggroup.iceskating.app.ui.composable.screen.onboarding.icon;

/* compiled from: OnboardingIcon.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a%\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\t\u001a\u00020\nH\u0007¢\u0006\u0002\u0010\u000b\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\f"}, d2 = {"BackdropSize", "Landroidx/compose/ui/unit/Dp;", "F", "IconSize", "OnboardingIcon", "", "icons", "", "Landroidx/compose/ui/graphics/vector/ImageVector;", "modifier", "Landroidx/compose/ui/Modifier;", "(Ljava/util/List;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OnboardingIconKt {
    private static final float BackdropSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(140);
    private static final float IconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(56);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit OnboardingIcon$lambda$1(java.util.List list, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        OnboardingIcon(list, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x018d  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0197  */
    /* JADX WARN: Removed duplicated region for block: B:48:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void OnboardingIcon(final java.util.List<androidx.compose.ui.graphics.vector.ImageVector> icons, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(icons, "icons");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(540396162);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(OnboardingIcon)N(icons,modifier)25@898L7,32@1095L11,33@1138L18,28@967L466:OnboardingIcon.kt#lw7y9p");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(icons) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                modifier3 = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(540396162, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.onboarding.icon.OnboardingIcon (OnboardingIcon.kt:24)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.foundation.shape.RoundedCornerShape roundedCornerShapeM1543RoundedCornerShape0680j_4 = androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(((uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume).m11617getCornerRadiusD9Ej5fM());
                androidx.compose.ui.Modifier modifierImageBorder = uhggroup.iceskating.app.ui.theme.BordersKt.imageBorder(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.ui.draw.ClipKt.clip(androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(modifier3, BackdropSize), roundedCornerShapeM1543RoundedCornerShape0680j_4), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getPrimaryContainer(), null, 2, null), roundedCornerShapeM1543RoundedCornerShape0680j_4, composerStartRestartGroup, 0);
                androidx.compose.ui.Alignment center = androidx.compose.ui.Alignment.INSTANCE.getCenter();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierImageBorder);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1558959723, "C39@1338L11,36@1219L208:OnboardingIcon.kt#lw7y9p");
                androidx.compose.material3.IconKt.m3011Iconww6aTOc((androidx.compose.ui.graphics.vector.ImageVector) kotlin.collections.CollectionsKt.first((java.util.List) icons), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, IconSize), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnPrimaryContainer(), composerStartRestartGroup, 432, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.onboarding.icon.OnboardingIconKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.onboarding.icon.OnboardingIconKt.OnboardingIcon$lambda$1(icons, modifier3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }
}
