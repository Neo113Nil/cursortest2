package uhggroup.iceskating.app.ui.composable.screen.shared;

/* compiled from: DataBasedContainer.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$DataBasedContainerKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1653390135 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1653390135, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt.lambda_1653390135$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1653390135$app_release() {
        return lambda$1653390135;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1653390135$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C:DataBasedContainer.kt#kegtjg");
        if (composer.shouldExecute((i & 3) != 2, i & 1)) {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1653390135, i, -1, "uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt.lambda$1653390135.<anonymous> (DataBasedContainer.kt:13)");
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composer.skipToGroupEnd();
        }
        return kotlin.Unit.INSTANCE;
    }
}
