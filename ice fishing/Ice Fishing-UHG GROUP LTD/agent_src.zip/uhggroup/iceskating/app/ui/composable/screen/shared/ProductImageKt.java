package uhggroup.iceskating.app.ui.composable.screen.shared;

/* compiled from: ProductImage.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\u001a5\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0007\u001a\u00020\bH\u0007¢\u0006\u0002\u0010\t¨\u0006\n²\u0006\n\u0010\u000b\u001a\u00020\fX\u008a\u008e\u0002"}, d2 = {"ProductImage", "", "imageUrl", "", "modifier", "Landroidx/compose/ui/Modifier;", "contentDescription", "contentScale", "Landroidx/compose/ui/layout/ContentScale;", "(Ljava/lang/String;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/ui/layout/ContentScale;Landroidx/compose/runtime/Composer;II)V", "app_release", "isLoading", ""}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductImageKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductImage$lambda$4(java.lang.String str, androidx.compose.ui.Modifier modifier, java.lang.String str2, androidx.compose.ui.layout.ContentScale contentScale, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        ProductImage(str, modifier, str2, contentScale, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:110:0x02ce  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x02da  */
    /* JADX WARN: Removed duplicated region for block: B:115:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x005e  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x008f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ProductImage(final java.lang.String imageUrl, androidx.compose.ui.Modifier modifier, java.lang.String str, androidx.compose.ui.layout.ContentScale contentScale, androidx.compose.runtime.Composer composer, final int i, final int i2) throws android.content.res.Resources.NotFoundException {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        java.lang.String str2;
        int i4;
        androidx.compose.ui.layout.ContentScale crop;
        final androidx.compose.ui.Modifier modifier3;
        final java.lang.String str3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        java.lang.String strStringResource;
        androidx.compose.ui.Modifier modifier4;
        java.lang.String str4;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(1484935484);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ProductImage)N(imageUrl,modifier,contentDescription,contentScale)25@1003L43,27@1101L11,27@1052L767:ProductImage.kt#kegtjg");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(imageUrl) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i5 = i2 & 2;
        if (i5 != 0) {
            i3 |= 48;
        } else {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) != 0) {
                if ((i2 & 4) == 0) {
                    str2 = str;
                    int i6 = composerStartRestartGroup.changed(str2) ? 256 : 128;
                    i3 |= i6;
                } else {
                    str2 = str;
                }
                i3 |= i6;
            } else {
                str2 = str;
            }
            i4 = i2 & 8;
            if (i4 != 0) {
                if ((i & 3072) == 0) {
                    crop = contentScale;
                    i3 |= composerStartRestartGroup.changed(crop) ? 2048 : 1024;
                }
                if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
                    composerStartRestartGroup.startDefaults();
                    androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "22@874L50");
                    if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                        composerStartRestartGroup.skipToGroupEnd();
                        if ((i2 & 4) != 0) {
                            i3 &= -897;
                        }
                        modifier4 = modifier2;
                        str4 = str2;
                    } else {
                        androidx.compose.ui.Modifier.Companion companion = i5 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                        if ((i2 & 4) != 0) {
                            strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.product_image_description, composerStartRestartGroup, 0);
                            i3 &= -897;
                        } else {
                            strStringResource = str2;
                        }
                        if (i4 != 0) {
                            modifier4 = companion;
                            str4 = strStringResource;
                            crop = androidx.compose.ui.layout.ContentScale.INSTANCE.getCrop();
                        } else {
                            modifier4 = companion;
                            str4 = strStringResource;
                        }
                    }
                    composerStartRestartGroup.endDefaults();
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventStart(1484935484, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.shared.ProductImage (ProductImage.kt:24)");
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1093865511, "CC(remember):ProductImage.kt#9igjgp");
                    int i7 = i3 & 14;
                    boolean z = i7 == 4;
                    java.lang.Object objRememberedValue = composerStartRestartGroup.rememberedValue();
                    if (z || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(true, null, 2, null);
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                    }
                    final androidx.compose.runtime.MutableState mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.ui.Modifier modifierM324backgroundbw27NRU$default = androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(modifier4, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHighest(), null, 2, null);
                    androidx.compose.ui.Modifier modifier5 = modifier4;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
                    androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                    int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                    androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                    androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM324backgroundbw27NRU$default);
                    kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                    if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                        androidx.compose.runtime.ComposablesKt.invalidApplier();
                    }
                    composerStartRestartGroup.startReusableNode();
                    if (composerStartRestartGroup.getInserting()) {
                        composerStartRestartGroup.createNode(constructor);
                    } else {
                        composerStartRestartGroup.useNode();
                    }
                    androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                    androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                    androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                    androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1895163253, "C32@1321L50,33@1393L50,34@1468L50,36@1585L20,37@1631L21,38@1676L20,28@1149L558:ProductImage.kt#kegtjg");
                    androidx.compose.ui.Modifier modifierMatchParentSize = boxScopeInstance.matchParentSize(androidx.compose.ui.Modifier.INSTANCE);
                    androidx.compose.ui.graphics.painter.Painter painterPainterResource = androidx.compose.ui.res.PainterResources_androidKt.painterResource(uhggroup.iceskating.app.R.drawable.ic_launcher_background, composerStartRestartGroup, 0);
                    androidx.compose.ui.graphics.painter.Painter painterPainterResource2 = androidx.compose.ui.res.PainterResources_androidKt.painterResource(uhggroup.iceskating.app.R.drawable.ic_launcher_background, composerStartRestartGroup, 0);
                    androidx.compose.ui.graphics.painter.Painter painterPainterResource3 = androidx.compose.ui.res.PainterResources_androidKt.painterResource(uhggroup.iceskating.app.R.drawable.ic_launcher_background, composerStartRestartGroup, 0);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -354494390, "CC(remember):ProductImage.kt#9igjgp");
                    boolean zChanged = composerStartRestartGroup.changed(mutableState);
                    java.lang.Object objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                    if (zChanged || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object invoke(java.lang.Object obj) {
                                return uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt.ProductImage$lambda$3$0$0(mutableState, (coil3.compose.AsyncImagePainter.State.Loading) obj);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    }
                    kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) objRememberedValue2;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -354492917, "CC(remember):ProductImage.kt#9igjgp");
                    boolean zChanged2 = composerStartRestartGroup.changed(mutableState);
                    java.lang.Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                    if (zChanged2 || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object invoke(java.lang.Object obj) {
                                return uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt.ProductImage$lambda$3$1$0(mutableState, (coil3.compose.AsyncImagePainter.State.Success) obj);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                    }
                    kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) objRememberedValue3;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -354491478, "CC(remember):ProductImage.kt#9igjgp");
                    boolean zChanged3 = composerStartRestartGroup.changed(mutableState);
                    java.lang.Object objRememberedValue4 = composerStartRestartGroup.rememberedValue();
                    if (zChanged3 || objRememberedValue4 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                        objRememberedValue4 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object invoke(java.lang.Object obj) {
                                return uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt.ProductImage$lambda$3$2$0(mutableState, (coil3.compose.AsyncImagePainter.State.Error) obj);
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue4);
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    coil3.compose.SingletonAsyncImageKt.m9459AsyncImagex1rPTaM(imageUrl, str4, modifierMatchParentSize, painterPainterResource, painterPainterResource2, painterPainterResource3, function1, function12, (kotlin.jvm.functions.Function1) objRememberedValue4, null, crop, 0.0f, null, 0, false, composerStartRestartGroup, i7 | ((i3 >> 3) & 112) | (androidx.compose.ui.graphics.painter.Painter.$stable << 9) | (androidx.compose.ui.graphics.painter.Painter.$stable << 12) | (androidx.compose.ui.graphics.painter.Painter.$stable << 15), (i3 >> 9) & 14, 31232);
                    if (ProductImage$lambda$1(mutableState)) {
                        composerStartRestartGroup.startReplaceGroup(1895723515);
                        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "42@1746L57");
                        uhggroup.iceskating.app.ui.composable.screen.shared.loadingplaceholder.LoadingPlaceholderKt.LoadingPlaceholder(boxScopeInstance.matchParentSize(androidx.compose.ui.Modifier.INSTANCE), composerStartRestartGroup, 0, 0);
                        composerStartRestartGroup.endReplaceGroup();
                    } else {
                        composerStartRestartGroup.startReplaceGroup(1895801356);
                        composerStartRestartGroup.endReplaceGroup();
                    }
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    composerStartRestartGroup.endNode();
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        androidx.compose.runtime.ComposerKt.traceEventEnd();
                    }
                    str3 = str4;
                    modifier3 = modifier5;
                } else {
                    composerStartRestartGroup.skipToGroupEnd();
                    modifier3 = modifier2;
                    str3 = str2;
                }
                final androidx.compose.ui.layout.ContentScale contentScale2 = crop;
                scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
                if (scopeUpdateScopeEndRestartGroup != null) {
                    scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                            return uhggroup.iceskating.app.ui.composable.screen.shared.ProductImageKt.ProductImage$lambda$4(imageUrl, modifier3, str3, contentScale2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                        }
                    });
                    return;
                }
                return;
            }
            i3 |= 3072;
            crop = contentScale;
            if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            }
            final androidx.compose.ui.layout.ContentScale contentScale22 = crop;
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup != null) {
            }
        }
        modifier2 = modifier;
        if ((i & 384) != 0) {
        }
        i4 = i2 & 8;
        if (i4 != 0) {
        }
        crop = contentScale;
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
        }
        final androidx.compose.ui.layout.ContentScale contentScale222 = crop;
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
        }
    }

    private static final boolean ProductImage$lambda$1(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void ProductImage$lambda$2(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState, boolean z) {
        mutableState.setValue(java.lang.Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductImage$lambda$3$0$0(androidx.compose.runtime.MutableState mutableState, coil3.compose.AsyncImagePainter.State.Loading it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        ProductImage$lambda$2(mutableState, true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductImage$lambda$3$1$0(androidx.compose.runtime.MutableState mutableState, coil3.compose.AsyncImagePainter.State.Success it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        ProductImage$lambda$2(mutableState, false);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductImage$lambda$3$2$0(androidx.compose.runtime.MutableState mutableState, coil3.compose.AsyncImagePainter.State.Error it) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        ProductImage$lambda$2(mutableState, true);
        return kotlin.Unit.INSTANCE;
    }
}
