package uhggroup.iceskating.app.ui.composable.approot;

/* compiled from: ContentBottomPadding.kt */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"LocalContentBottomPadding", "Landroidx/compose/runtime/ProvidableCompositionLocal;", "Landroidx/compose/ui/unit/Dp;", "getLocalContentBottomPadding", "()Landroidx/compose/runtime/ProvidableCompositionLocal;", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ContentBottomPaddingKt {
    private static final androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> LocalContentBottomPadding = androidx.compose.runtime.CompositionLocalKt.compositionLocalOf$default(null, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function0
        public final java.lang.Object invoke() {
            return uhggroup.iceskating.app.ui.composable.approot.ContentBottomPaddingKt.LocalContentBottomPadding$lambda$0();
        }
    }, 1, null);

    public static final androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.unit.Dp> getLocalContentBottomPadding() {
        return LocalContentBottomPadding;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final androidx.compose.ui.unit.Dp LocalContentBottomPadding$lambda$0() {
        return androidx.compose.ui.unit.Dp.m8849boximpl(androidx.compose.ui.unit.Dp.m8851constructorimpl(0));
    }
}
