package uhggroup.iceskating.app.ui.composable.screen.home;

/* compiled from: ICSHomeScreen.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ICSHomeScreenKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt();

    /* renamed from: lambda$-485815720, reason: not valid java name */
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f58lambda$485815720 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-485815720, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt.lambda__485815720$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    /* renamed from: getLambda$-485815720$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11478getLambda$485815720$app_release() {
        return f58lambda$485815720;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__485815720$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C80@3252L58,79@3200L184:ICSHomeScreen.kt#8md9ri");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-485815720, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.ComposableSingletons$ICSHomeScreenKt.lambda$-485815720.<anonymous> (ICSHomeScreen.kt:79)");
            }
            uhggroup.iceskating.app.ui.composable.screen.shared.DataEmptyContentKt.DataEmptyContent(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.products_state_empty_primary_text, composer, 0), null, null, null, composer, 6, 28);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
