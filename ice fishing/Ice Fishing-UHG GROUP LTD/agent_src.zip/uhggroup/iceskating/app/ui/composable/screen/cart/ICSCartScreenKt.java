package uhggroup.iceskating.app.ui.composable.screen.cart;

/* compiled from: ICSCartScreen.kt */
@kotlin.Metadata(d1 = {"\u0000<\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0005\u001a/\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\b\u001a}\u0010\t\u001a\u00020\u00012\u0012\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000b2\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00010\u00112\u0012\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00010\u00112\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00010\u00112\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0003¢\u0006\u0002\u0010\u0016¨\u0006\u0017²\u0006\u0016\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000bX\u008a\u0084\u0002²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u0084\u0002"}, d2 = {"ICSCartScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/CartViewModel;", "onNavigateToCheckoutScreen", "Lkotlin/Function0;", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/CartViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "CartScreenContent", "cartItemsState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/ui/state/CartItemUiState;", "totalPrice", "", "onPlusItemClick", "Lkotlin/Function1;", "", "onMinusItemClick", "onDeleteItemClick", "onCompleteOrderButtonClick", "(Luhggroup/iceskating/app/ui/state/DataUiState;Landroidx/compose/ui/Modifier;DLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSCartScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CartScreenContent$lambda$1(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, androidx.compose.ui.Modifier modifier, double d, kotlin.jvm.functions.Function1 function1, kotlin.jvm.functions.Function1 function12, kotlin.jvm.functions.Function1 function13, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        CartScreenContent(dataUiState, modifier, d, function1, function12, function13, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSCartScreen$lambda$5(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, kotlin.jvm.functions.Function0 function0, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ICSCartScreen(modifier, cartViewModel, function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0142  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x019a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ICSCartScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToCheckoutScreen, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel2;
        final androidx.compose.ui.Modifier.Companion companion;
        final uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel3;
        final uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel4;
        int i4;
        boolean zChangedInstance;
        java.lang.Object objRememberedValue;
        boolean zChangedInstance2;
        java.lang.Object objRememberedValue2;
        boolean zChangedInstance3;
        java.lang.Object objRememberedValue3;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToCheckoutScreen, "onNavigateToCheckoutScreen");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1094869260);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSCartScreen)N(modifier,viewModel,onNavigateToCheckoutScreen)33@1596L29,34@1669L29,36@1726L71,40@1826L68,44@1924L63,48@1993L327:ICSCartScreen.kt#8m9skv");
        int i5 = i2 & 1;
        if (i5 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                cartViewModel2 = cartViewModel;
                int i6 = composerStartRestartGroup.changedInstance(cartViewModel2) ? 32 : 16;
                i3 |= i6;
            } else {
                cartViewModel2 = cartViewModel;
            }
            i3 |= i6;
        } else {
            cartViewModel2 = cartViewModel;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToCheckoutScreen) ? 256 : 128;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 147) != 146, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "30@1480L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i5 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-924953623);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.CartViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    cartViewModel4 = (uhggroup.iceskating.app.ui.viewmodel.CartViewModel) viewModelResolveViewModel;
                    i4 = i3 & (-113);
                }
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1094869260, i4, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreen (ICSCartScreen.kt:32)");
                }
                androidx.compose.runtime.State stateCollectAsStateWithLifecycle = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(cartViewModel4.getCartItemsState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
                androidx.compose.runtime.State stateCollectAsStateWithLifecycle2 = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(cartViewModel4.getTotalPrice(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97639323, "CC(remember):ICSCartScreen.kt#9igjgp");
                zChangedInstance = composerStartRestartGroup.changedInstance(cartViewModel4);
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$2$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                kotlin.jvm.functions.Function1 function1 = (kotlin.jvm.functions.Function1) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97642520, "CC(remember):ICSCartScreen.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(cartViewModel4);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2 || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$3$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                kotlin.jvm.functions.Function1 function12 = (kotlin.jvm.functions.Function1) objRememberedValue2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97645651, "CC(remember):ICSCartScreen.kt#9igjgp");
                zChangedInstance3 = composerStartRestartGroup.changedInstance(cartViewModel4);
                objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance3 || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$4$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                CartScreenContent(ICSCartScreen$lambda$0(stateCollectAsStateWithLifecycle), companion, ICSCartScreen$lambda$1(stateCollectAsStateWithLifecycle2), function1, function12, (kotlin.jvm.functions.Function1) objRememberedValue3, onNavigateToCheckoutScreen, composerStartRestartGroup, ((i4 << 12) & 3670016) | ((i4 << 3) & 112), 0);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                cartViewModel3 = cartViewModel4;
            }
            i4 = i3;
            cartViewModel4 = cartViewModel2;
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            androidx.compose.runtime.State stateCollectAsStateWithLifecycle3 = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(cartViewModel4.getCartItemsState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
            androidx.compose.runtime.State stateCollectAsStateWithLifecycle22 = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(cartViewModel4.getTotalPrice(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97639323, "CC(remember):ICSCartScreen.kt#9igjgp");
            zChangedInstance = composerStartRestartGroup.changedInstance(cartViewModel4);
            objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (!zChangedInstance) {
                objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$2$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                    }
                };
                composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                kotlin.jvm.functions.Function1 function13 = (kotlin.jvm.functions.Function1) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97642520, "CC(remember):ICSCartScreen.kt#9igjgp");
                zChangedInstance2 = composerStartRestartGroup.changedInstance(cartViewModel4);
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (!zChangedInstance2) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function1
                        public final java.lang.Object invoke(java.lang.Object obj) {
                            return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$3$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                    kotlin.jvm.functions.Function1 function122 = (kotlin.jvm.functions.Function1) objRememberedValue2;
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                    androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 97645651, "CC(remember):ICSCartScreen.kt#9igjgp");
                    zChangedInstance3 = composerStartRestartGroup.changedInstance(cartViewModel4);
                    objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                    if (!zChangedInstance3) {
                        objRememberedValue3 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function1
                            public final java.lang.Object invoke(java.lang.Object obj) {
                                return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$4$0(cartViewModel4, ((java.lang.Integer) obj).intValue());
                            }
                        };
                        composerStartRestartGroup.updateRememberedValue(objRememberedValue3);
                        androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                        CartScreenContent(ICSCartScreen$lambda$0(stateCollectAsStateWithLifecycle3), companion, ICSCartScreen$lambda$1(stateCollectAsStateWithLifecycle22), function13, function122, (kotlin.jvm.functions.Function1) objRememberedValue3, onNavigateToCheckoutScreen, composerStartRestartGroup, ((i4 << 12) & 3670016) | ((i4 << 3) & 112), 0);
                        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                        }
                        cartViewModel3 = cartViewModel4;
                    }
                }
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            companion = modifier2;
            cartViewModel3 = cartViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.ICSCartScreen$lambda$5(companion, cartViewModel3, onNavigateToCheckoutScreen, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSCartScreen$lambda$2$0(uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, int i) {
        cartViewModel.incrementProductInCart(i);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSCartScreen$lambda$3$0(uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, int i) {
        cartViewModel.decrementItemInCart(i);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSCartScreen$lambda$4$0(uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, int i) {
        cartViewModel.deleteFromCart(i);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x01e0  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x01ea  */
    /* JADX WARN: Removed duplicated region for block: B:87:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static final void CartScreenContent(final uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>> dataUiState, androidx.compose.ui.Modifier modifier, final double d, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function1, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function12, final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function13, final kotlin.jvm.functions.Function0<kotlin.Unit> function0, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        double d2;
        kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function14;
        kotlin.jvm.functions.Function0<kotlin.Unit> function02;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(487872777);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CartScreenContent)N(cartItemsState,modifier,totalPrice,onPlusItemClick,onMinusItemClick,onDeleteItemClick,onCompleteOrderButtonClick)69@2670L7,71@2683L1843:ICSCartScreen.kt#8m9skv");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(dataUiState) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if ((i & 384) != 0) {
                d2 = d;
                i3 |= composerStartRestartGroup.changed(d2) ? 256 : 128;
            } else {
                d2 = d;
            }
            if ((i & 3072) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(function1) ? 2048 : 1024;
            }
            if ((i & 24576) == 0) {
                i3 |= composerStartRestartGroup.changedInstance(function12) ? 16384 : 8192;
            }
            if ((196608 & i) != 0) {
                function14 = function13;
                i3 |= composerStartRestartGroup.changedInstance(function14) ? 131072 : 65536;
            } else {
                function14 = function13;
            }
            if ((1572864 & i) != 0) {
                function02 = function0;
                i3 |= composerStartRestartGroup.changedInstance(function02) ? 1048576 : 524288;
            } else {
                function02 = function0;
            }
            if (composerStartRestartGroup.shouldExecute((599187 & i3) == 599186, i3 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(487872777, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.CartScreenContent (ICSCartScreen.kt:68)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                int i5 = i3;
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.ui.Modifier modifier4 = companion;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -152591062, "C77@2858L1310,73@2722L1798:ICSCartScreen.kt#8m9skv");
                final double d3 = d2;
                final kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> function15 = function14;
                final kotlin.jvm.functions.Function0<kotlin.Unit> function03 = function02;
                uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt.DataBasedContainer(androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), dataUiState, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(-250575220, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.CartScreenContent$lambda$0$0(dataUiState, dimens, function1, function12, function15, d3, function03, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                }, composerStartRestartGroup, 54), uhggroup.iceskating.app.ui.composable.screen.cart.ComposableSingletons$ICSCartScreenKt.INSTANCE.getLambda$1546875243$app_release(), null, composerStartRestartGroup, ((i5 << 3) & 112) | 3462, 16);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.CartScreenContent$lambda$1(dataUiState, modifier3, d, function1, function12, function13, function0, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if ((i & 384) != 0) {
        }
        if ((i & 3072) == 0) {
        }
        if ((i & 24576) == 0) {
        }
        if ((196608 & i) != 0) {
        }
        if ((1572864 & i) != 0) {
        }
        if (composerStartRestartGroup.shouldExecute((599187 & i3) == 599186, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CartScreenContent$lambda$0$0(uhggroup.iceskating.app.ui.state.DataUiState dataUiState, uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, final kotlin.jvm.functions.Function1 function1, final kotlin.jvm.functions.Function1 function12, final kotlin.jvm.functions.Function1 function13, double d, kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C80@2974L1180:ICSCartScreen.kt#8m9skv");
        int quantity = 0;
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-250575220, i, -1, "uhggroup.iceskating.app.ui.composable.screen.cart.CartScreenContent.<anonymous>.<anonymous> (ICSCartScreen.kt:78)");
            }
            kotlin.jvm.internal.Intrinsics.checkNotNull(dataUiState, "null cannot be cast to non-null type uhggroup.iceskating.app.ui.state.DataUiState.Populated<kotlin.collections.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>");
            final java.util.List list = (java.util.List) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData();
            androidx.compose.ui.Modifier modifierFillMaxSize$default = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierFillMaxSize$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 174513315, "C87@3370L505,81@3038L837,98@3897L239:ICSCartScreen.kt#8m9skv");
            androidx.compose.ui.Modifier modifierWeight$default = androidx.compose.foundation.layout.ColumnScope.weight$default(columnScopeInstance, androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), 1.0f, false, 2, null);
            androidx.compose.foundation.layout.PaddingValues paddingValuesM1155PaddingValues0680j_4 = androidx.compose.foundation.layout.PaddingKt.m1155PaddingValues0680j_4(dimens.m11620getScreenPaddingD9Ej5fM());
            androidx.compose.foundation.layout.Arrangement.HorizontalOrVertical horizontalOrVerticalM836spacedBy0680j_4 = androidx.compose.foundation.layout.Arrangement.INSTANCE.m836spacedBy0680j_4(dimens.m11614getContentSpacingD9Ej5fM());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1795475825, "CC(remember):ICSCartScreen.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(list) | composer.changed(function1) | composer.changed(function12) | composer.changed(function13);
            java.lang.Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final java.lang.Object invoke(java.lang.Object obj) {
                        return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.CartScreenContent$lambda$0$0$0$0$0(list, function1, function12, function13, (androidx.compose.foundation.lazy.LazyListScope) obj);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.lazy.LazyDslKt.LazyColumn(modifierWeight$default, null, paddingValuesM1155PaddingValues0680j_4, false, horizontalOrVerticalM836spacedBy0680j_4, null, null, false, null, (kotlin.jvm.functions.Function1) objRememberedValue, composer, 0, 490);
            java.util.Iterator it = list.iterator();
            while (it.hasNext()) {
                quantity += ((uhggroup.iceskating.app.ui.state.CartItemUiState) it.next()).getQuantity();
            }
            uhggroup.iceskating.app.ui.composable.screen.cart.summary.CartSummaryKt.CartSummary(quantity, d, null, function0, composer, 0, 4);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CartScreenContent$lambda$0$0$0$0$0(final java.util.List list, final kotlin.jvm.functions.Function1 function1, final kotlin.jvm.functions.Function1 function12, final kotlin.jvm.functions.Function1 function13, androidx.compose.foundation.lazy.LazyListScope LazyColumn) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final kotlin.jvm.functions.Function1 function14 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt.CartScreenContent$lambda$0$0$0$0$0$0((uhggroup.iceskating.app.ui.state.CartItemUiState) obj);
            }
        };
        final uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$1 iCSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$1 = new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Void invoke(uhggroup.iceskating.app.ui.state.CartItemUiState cartItemUiState) {
                return null;
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object obj) {
                return invoke((uhggroup.iceskating.app.ui.state.CartItemUiState) obj);
            }
        };
        LazyColumn.items(list.size(), new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$2
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return function14.invoke(list.get(i));
            }
        }, new kotlin.jvm.functions.Function1<java.lang.Integer, java.lang.Object>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Integer num) {
                return invoke(num.intValue());
            }

            public final java.lang.Object invoke(int i) {
                return iCSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$1.invoke(list.get(i));
            }
        }, androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(802480018, true, new kotlin.jvm.functions.Function4<androidx.compose.foundation.lazy.LazyItemScope, java.lang.Integer, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$lambda$0$0$0$0$0$$inlined$items$default$4
            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ kotlin.Unit invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, java.lang.Integer num, androidx.compose.runtime.Composer composer, java.lang.Integer num2) throws android.content.res.Resources.NotFoundException {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return kotlin.Unit.INSTANCE;
            }

            public final void invoke(androidx.compose.foundation.lazy.LazyItemScope lazyItemScope, int i, androidx.compose.runtime.Composer composer, int i2) throws android.content.res.Resources.NotFoundException {
                int i3;
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                if ((i2 & 6) == 0) {
                    i3 = (composer.changed(lazyItemScope) ? 4 : 2) | i2;
                } else {
                    i3 = i2;
                }
                if ((i2 & 48) == 0) {
                    i3 |= composer.changed(i) ? 32 : 16;
                }
                if (!composer.shouldExecute((i3 & 147) != 146, i3 & 1)) {
                    composer.skipToGroupEnd();
                    return;
                }
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(802480018, i3, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                }
                final uhggroup.iceskating.app.ui.state.CartItemUiState cartItemUiState = (uhggroup.iceskating.app.ui.state.CartItemUiState) list.get(i);
                composer.startReplaceGroup(-680140109);
                androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(item)*91@3589L35,92@3673L36,93@3759L37,89@3488L339:ICSCartScreen.kt#8m9skv");
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -437579072, "CC(remember):ICSCartScreen.kt#9igjgp");
                boolean zChanged = composer.changed(function1) | composer.changed(cartItemUiState);
                java.lang.Object objRememberedValue = composer.rememberedValue();
                if (zChanged || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function15 = function1;
                    objRememberedValue = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$1$1$1$1$1$2$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function15.invoke(java.lang.Integer.valueOf(cartItemUiState.getProductId()));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue);
                }
                kotlin.jvm.functions.Function0 function0 = (kotlin.jvm.functions.Function0) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -437576383, "CC(remember):ICSCartScreen.kt#9igjgp");
                boolean zChanged2 = composer.changed(function12) | composer.changed(cartItemUiState);
                java.lang.Object objRememberedValue2 = composer.rememberedValue();
                if (zChanged2 || objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function16 = function12;
                    objRememberedValue2 = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$1$1$1$1$1$2$2$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function16.invoke(java.lang.Integer.valueOf(cartItemUiState.getProductId()));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue2);
                }
                kotlin.jvm.functions.Function0 function02 = (kotlin.jvm.functions.Function0) objRememberedValue2;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -437573630, "CC(remember):ICSCartScreen.kt#9igjgp");
                boolean zChanged3 = composer.changed(function13) | composer.changed(cartItemUiState);
                java.lang.Object objRememberedValue3 = composer.rememberedValue();
                if (zChanged3 || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    final kotlin.jvm.functions.Function1 function17 = function13;
                    objRememberedValue3 = (kotlin.jvm.functions.Function0) new kotlin.jvm.functions.Function0<kotlin.Unit>() { // from class: uhggroup.iceskating.app.ui.composable.screen.cart.ICSCartScreenKt$CartScreenContent$1$1$1$1$1$2$3$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ kotlin.Unit invoke() {
                            invoke2();
                            return kotlin.Unit.INSTANCE;
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function17.invoke(java.lang.Integer.valueOf(cartItemUiState.getProductId()));
                        }
                    };
                    composer.updateRememberedValue(objRememberedValue3);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
                uhggroup.iceskating.app.ui.composable.screen.cart.card.CartItemKt.CartItem(cartItemUiState, null, function0, function02, (kotlin.jvm.functions.Function0) objRememberedValue3, composer, 0, 2);
                composer.endReplaceGroup();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
        }));
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.Object CartScreenContent$lambda$0$0$0$0$0$0(uhggroup.iceskating.app.ui.state.CartItemUiState item) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(item, "item");
        return java.lang.Integer.valueOf(item.getProductId());
    }

    private static final uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>> ICSCartScreen$lambda$0(androidx.compose.runtime.State<? extends uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>> state) {
        return (uhggroup.iceskating.app.ui.state.DataUiState) state.getValue();
    }

    private static final double ICSCartScreen$lambda$1(androidx.compose.runtime.State<java.lang.Double> state) {
        return state.getValue().doubleValue();
    }
}
