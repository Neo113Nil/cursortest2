package uhggroup.iceskating.app.ui.composable.screen.shared;

/* compiled from: DataBasedContainer.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u001af\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\u00062\u0011\u0010\u0007\u001a\r\u0012\u0004\u0012\u00020\u00010\b¢\u0006\u0002\b\t2\u0011\u0010\n\u001a\r\u0012\u0004\u0012\u00020\u00010\b¢\u0006\u0002\b\t2\u0013\b\u0002\u0010\u000b\u001a\r\u0012\u0004\u0012\u00020\u00010\b¢\u0006\u0002\b\tH\u0007¢\u0006\u0002\u0010\f¨\u0006\r"}, d2 = {"DataBasedContainer", "", androidx.exifinterface.media.ExifInterface.GPS_DIRECTION_TRUE, "modifier", "Landroidx/compose/ui/Modifier;", "dataState", "Luhggroup/iceskating/app/ui/state/DataUiState;", "dataPopulated", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "dataEmpty", "dataInitial", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/state/DataUiState;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class DataBasedContainerKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit DataBasedContainer$lambda$1(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.state.DataUiState dataUiState, kotlin.jvm.functions.Function2 function2, kotlin.jvm.functions.Function2 function22, kotlin.jvm.functions.Function2 function23, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        DataBasedContainer(modifier, dataUiState, function2, function22, function23, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final <T> void DataBasedContainer(androidx.compose.ui.Modifier modifier, final uhggroup.iceskating.app.ui.state.DataUiState<? extends T> dataState, final kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> dataPopulated, final kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> dataEmpty, kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> function2, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataState, "dataState");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataPopulated, "dataPopulated");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(dataEmpty, "dataEmpty");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1191086711);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(DataBasedContainer)N(modifier,dataState,dataPopulated,dataEmpty,dataInitial)15@487L317:DataBasedContainer.kt#kegtjg");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(modifier) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerStartRestartGroup.changed(dataState) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(dataPopulated) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(dataEmpty) ? 2048 : 1024;
        }
        int i5 = i2 & 16;
        if (i5 != 0) {
            i3 |= 24576;
        } else if ((i & 24576) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(function2) ? 16384 : 8192;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 9363) != 9362, i3 & 1)) {
            if (i4 != 0) {
                modifier = androidx.compose.ui.Modifier.INSTANCE;
            }
            if (i5 != 0) {
                function2 = uhggroup.iceskating.app.ui.composable.screen.shared.ComposableSingletons$DataBasedContainerKt.INSTANCE.getLambda$1653390135$app_release();
            }
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1191086711, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainer (DataBasedContainer.kt:14)");
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = androidx.compose.foundation.layout.BoxKt.maybeCachedBoxMeasurePolicy(androidx.compose.ui.Alignment.INSTANCE.getTopStart(), false);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifier);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composerStartRestartGroup.startReusableNode();
            if (composerStartRestartGroup.getInserting()) {
                composerStartRestartGroup.createNode(constructor);
            } else {
                composerStartRestartGroup.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
            androidx.compose.foundation.layout.BoxScopeInstance boxScopeInstance = androidx.compose.foundation.layout.BoxScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -653030464, "C:DataBasedContainer.kt#kegtjg");
            if (kotlin.jvm.internal.Intrinsics.areEqual(dataState, uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE)) {
                composerStartRestartGroup.startReplaceGroup(-652984058);
                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "18@594L13");
                function2.invoke(composerStartRestartGroup, java.lang.Integer.valueOf((i3 >> 12) & 14));
                composerStartRestartGroup.endReplaceGroup();
            } else if (dataState instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated) {
                composerStartRestartGroup.startReplaceGroup(-652897692);
                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "22@681L15");
                dataPopulated.invoke(composerStartRestartGroup, java.lang.Integer.valueOf((i3 >> 6) & 14));
                composerStartRestartGroup.endReplaceGroup();
            } else {
                if (!kotlin.jvm.internal.Intrinsics.areEqual(dataState, uhggroup.iceskating.app.ui.state.DataUiState.Empty.INSTANCE)) {
                    composerStartRestartGroup.startReplaceGroup(2057144483);
                    composerStartRestartGroup.endReplaceGroup();
                    throw new kotlin.NoWhenBranchMatchedException();
                }
                composerStartRestartGroup.startReplaceGroup(-652816472);
                androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "26@763L11");
                dataEmpty.invoke(composerStartRestartGroup, java.lang.Integer.valueOf((i3 >> 9) & 14));
                composerStartRestartGroup.endReplaceGroup();
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            composerStartRestartGroup.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
        }
        final androidx.compose.ui.Modifier modifier2 = modifier;
        final kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> function22 = function2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.shared.DataBasedContainerKt.DataBasedContainer$lambda$1(modifier2, dataState, dataPopulated, dataEmpty, function22, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }
}
