package uhggroup.iceskating.app.ui.composable.screen.productdetails.header;

/* compiled from: ProductHeader.kt */
@kotlin.Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006¨\u0006\u0007"}, d2 = {"ProductHeader", "", "product", "Luhggroup/iceskating/app/data/model/Product;", "modifier", "Landroidx/compose/ui/Modifier;", "(Luhggroup/iceskating/app/data/model/Product;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductHeaderKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ProductHeader$lambda$1(uhggroup.iceskating.app.data.model.Product product, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        ProductHeader(product, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0225  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0230  */
    /* JADX WARN: Removed duplicated region for block: B:49:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ProductHeader(final uhggroup.iceskating.app.data.model.Product product, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        final androidx.compose.ui.Modifier modifier2;
        androidx.compose.runtime.Composer composer2;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(product, "product");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-1332677369);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ProductHeader)N(product,modifier)19@692L7,21@705L745:ProductHeader.kt#amlny1");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changed(product) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i4 = i2 & 2;
        if (i4 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
                composer2 = composerStartRestartGroup;
                composer2.skipToGroupEnd();
            } else {
                androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-1332677369, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.header.ProductHeader (ProductHeader.kt:18)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, companion);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -372899787, "C23@768L41,24@845L11,25@900L10,22@743L190,28@943L55,32@1082L11,33@1142L10,30@1008L166,36@1184L57,39@1276L45,40@1357L11,41@1412L10,38@1251L193:ProductHeader.kt#amlny1");
                composer2 = composerStartRestartGroup;
                androidx.compose.ui.Modifier modifier3 = companion;
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(product.getCategory().getTitleRes(), composerStartRestartGroup, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getTitleMedium(), composer2, 0, 0, 131066);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11622getTightSpacingD9Ej5fM()), composer2, 0);
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(product.getTitle(), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getOnBackground(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer2, androidx.compose.material3.MaterialTheme.$stable).getTitleLarge(), composer2, 0, 0, 131066);
                androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11614getContentSpacingD9Ej5fM()), composer2, 0);
                androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.price, new java.lang.Object[]{java.lang.Double.valueOf(product.getPrice())}, composer2, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer2, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer2, androidx.compose.material3.MaterialTheme.$stable).getTitleLarge(), composer2, 0, 0, 131066);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer2);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier2 = modifier3;
            }
            scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.header.ProductHeaderKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.productdetails.header.ProductHeaderKt.ProductHeader$lambda$1(product, modifier2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        if (composerStartRestartGroup.shouldExecute((i3 & 19) == 18, i3 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }
}
