package uhggroup.iceskating.app.ui.composable.screen.splash;

/* compiled from: ICSSplashScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1", f = "ICSSplashScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
/* loaded from: classes3.dex */
final class ICSSplashScreenKt$ICSSplashScreen$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.Boolean> $isAnimationFinished$delegate;
    final /* synthetic */ kotlin.jvm.functions.Function0<kotlin.Unit> $onNavigateToHomeScreen;
    final /* synthetic */ kotlin.jvm.functions.Function0<kotlin.Unit> $onNavigateToOnboarding;
    final /* synthetic */ androidx.compose.runtime.State<java.lang.Boolean> $onboardedState$delegate;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ICSSplashScreenKt$ICSSplashScreen$1$1(kotlin.jvm.functions.Function0<kotlin.Unit> function0, kotlin.jvm.functions.Function0<kotlin.Unit> function02, androidx.compose.runtime.State<java.lang.Boolean> state, androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1> continuation) {
        super(2, continuation);
        this.$onNavigateToHomeScreen = function0;
        this.$onNavigateToOnboarding = function02;
        this.$onboardedState$delegate = state;
        this.$isAnimationFinished$delegate = mutableState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
        return new uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1(this.$onNavigateToHomeScreen, this.$onNavigateToOnboarding, this.$onboardedState$delegate, this.$isAnimationFinished$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
        return ((uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
        kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            kotlin.ResultKt.throwOnFailure(obj);
            java.lang.Boolean boolICSSplashScreen$lambda$0 = uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt.ICSSplashScreen$lambda$0(this.$onboardedState$delegate);
            if (uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt.ICSSplashScreen$lambda$2(this.$isAnimationFinished$delegate) && boolICSSplashScreen$lambda$0 != null) {
                (boolICSSplashScreen$lambda$0.booleanValue() ? this.$onNavigateToHomeScreen : this.$onNavigateToOnboarding).invoke();
            }
            return kotlin.Unit.INSTANCE;
        }
        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
