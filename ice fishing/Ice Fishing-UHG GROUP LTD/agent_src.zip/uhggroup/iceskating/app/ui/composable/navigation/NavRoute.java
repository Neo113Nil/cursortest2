package uhggroup.iceskating.app.ui.composable.navigation;

/* compiled from: NavRoute.kt */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\b\u0004\u0005\u0006\u0007\b\t\n\u000bB\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\b\f\r\u000e\u000f\u0010\u0011\u0012\u0013¨\u0006\u0014"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "", "<init>", "()V", "Splash", "Onboarding", "Home", "Cart", "Checkout", "Orders", "Settings", "ProductDetails", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Cart;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Checkout;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Home;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Onboarding;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Orders;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$ProductDetails;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Settings;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Splash;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public abstract class NavRoute {
    public static final int $stable = 0;

    public /* synthetic */ NavRoute(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Splash;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Splash extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Splash$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash._init_$_anonymous_();
            }
        });

        private Splash() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Splash> serializer() {
            return get$cachedSerializer();
        }
    }

    private NavRoute() {
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Onboarding;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Onboarding extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Onboarding$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding._init_$_anonymous_();
            }
        });

        private Onboarding() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Onboarding> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Home;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Home extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Home$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home._init_$_anonymous_();
            }
        });

        private Home() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Home> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Cart;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Cart extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Cart$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart._init_$_anonymous_();
            }
        });

        private Cart() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Cart> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Checkout;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Checkout extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Checkout$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout._init_$_anonymous_();
            }
        });

        private Checkout() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Checkout> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Orders;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Orders extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Orders$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders._init_$_anonymous_();
            }
        });

        private Orders() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Orders> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00000\u0005¨\u0006\u0006"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$Settings;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final class Settings extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings();
        private static final /* synthetic */ kotlin.Lazy<kotlinx.serialization.KSerializer<java.lang.Object>> $cachedSerializer$delegate = kotlin.LazyKt.lazy(kotlin.LazyThreadSafetyMode.PUBLICATION, new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.navigation.NavRoute$Settings$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final java.lang.Object invoke() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings._init_$_anonymous_();
            }
        });

        private Settings() {
            super(null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final /* synthetic */ kotlinx.serialization.KSerializer _init_$_anonymous_() {
            return new kotlinx.serialization.internal.ObjectSerializer("uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings", INSTANCE, new java.lang.annotation.Annotation[0]);
        }

        private final /* synthetic */ kotlinx.serialization.KSerializer get$cachedSerializer() {
            return $cachedSerializer$delegate.getValue();
        }

        public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.Settings> serializer() {
            return get$cachedSerializer();
        }
    }

    /* compiled from: NavRoute.kt */
    @kotlin.Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 \u001e2\u00020\u0001:\u0002\u001d\u001eB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005B#\b\u0010\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b\u0004\u0010\tJ\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0014\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011HÖ\u0083\u0004J\n\u0010\u0012\u001a\u00020\u0003HÖ\u0081\u0004J\n\u0010\u0013\u001a\u00020\u0014HÖ\u0081\u0004J%\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001bH\u0001¢\u0006\u0002\b\u001cR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u001f"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$ProductDetails;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute;", "id", "", "<init>", "(I)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(IILkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getId", "()I", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$app_release", "$serializer", "Companion", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlinx.serialization.Serializable
    public static final /* data */ class ProductDetails extends uhggroup.iceskating.app.ui.composable.navigation.NavRoute {
        public static final int $stable = 0;

        /* renamed from: Companion, reason: from kotlin metadata */
        public static final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.Companion INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.Companion(null);
        private final int id;

        public static /* synthetic */ uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails copy$default(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails productDetails, int i, int i2, java.lang.Object obj) {
            if ((i2 & 1) != 0) {
                i = productDetails.id;
            }
            return productDetails.copy(i);
        }

        /* renamed from: component1, reason: from getter */
        public final int getId() {
            return this.id;
        }

        public final uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails copy(int id) {
            return new uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails(id);
        }

        public boolean equals(java.lang.Object other) {
            if (this == other) {
                return true;
            }
            return (other instanceof uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails) && this.id == ((uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails) other).id;
        }

        public int hashCode() {
            return java.lang.Integer.hashCode(this.id);
        }

        public java.lang.String toString() {
            return "ProductDetails(id=" + this.id + ")";
        }

        /* compiled from: NavRoute.kt */
        @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$ProductDetails$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Luhggroup/iceskating/app/ui/composable/navigation/NavRoute$ProductDetails;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
        public static final class Companion {
            public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            public final kotlinx.serialization.KSerializer<uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails> serializer() {
                return uhggroup.iceskating.app.ui.composable.navigation.NavRoute$ProductDetails$$serializer.INSTANCE;
            }
        }

        public ProductDetails(int i) {
            super(null);
            this.id = i;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public /* synthetic */ ProductDetails(int i, int i2, kotlinx.serialization.internal.SerializationConstructorMarker serializationConstructorMarker) {
            super(null);
            if (1 != (i & 1)) {
                kotlinx.serialization.internal.PluginExceptionsKt.throwMissingFieldException(i, 1, uhggroup.iceskating.app.ui.composable.navigation.NavRoute$ProductDetails$$serializer.INSTANCE.getDescriptor());
            }
            this.id = i2;
        }

        public final int getId() {
            return this.id;
        }
    }
}
