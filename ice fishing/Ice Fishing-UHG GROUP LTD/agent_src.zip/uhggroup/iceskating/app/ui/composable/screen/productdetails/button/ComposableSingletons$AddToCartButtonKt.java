package uhggroup.iceskating.app.ui.composable.screen.productdetails.button;

/* compiled from: AddToCartButton.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$AddToCartButtonKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt();

    /* renamed from: lambda$-1749145767, reason: not valid java name */
    private static kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f61lambda$1749145767 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1749145767, false, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
            return uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt.lambda__1749145767$lambda$0((androidx.compose.foundation.layout.RowScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
        }
    });

    /* renamed from: getLambda$-1749145767$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function3<androidx.compose.foundation.layout.RowScope, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11499getLambda$1749145767$app_release() {
        return f61lambda$1749145767;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__1749145767$lambda$0(androidx.compose.foundation.layout.RowScope Button, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Button, "$this$Button");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C50@1795L49,51@1884L10,49@1766L155:AddToCartButton.kt#81h3xa");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(-1749145767, i, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt.lambda$-1749145767.<anonymous> (AddToCartButton.kt:49)");
            }
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.button_add_to_cart_label, composer, 0), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getTitleMedium(), composer, 0, 0, 131070);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
