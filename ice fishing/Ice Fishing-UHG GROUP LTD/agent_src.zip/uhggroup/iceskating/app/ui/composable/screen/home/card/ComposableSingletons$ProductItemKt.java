package uhggroup.iceskating.app.ui.composable.screen.home.card;

/* compiled from: ProductItem.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$ProductItemKt {
    public static final uhggroup.iceskating.app.ui.composable.screen.home.card.ComposableSingletons$ProductItemKt INSTANCE = new uhggroup.iceskating.app.ui.composable.screen.home.card.ComposableSingletons$ProductItemKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1617139574 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1617139574, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.home.card.ComposableSingletons$ProductItemKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ui.composable.screen.home.card.ComposableSingletons$ProductItemKt.lambda_1617139574$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1617139574$app_release() {
        return lambda$1617139574;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1617139574$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C106@4165L53,107@4261L11,104@4065L236:ProductItem.kt#8tsbww");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1617139574, i, -1, "uhggroup.iceskating.app.ui.composable.screen.home.card.ComposableSingletons$ProductItemKt.lambda$1617139574.<anonymous> (ProductItem.kt:104)");
            }
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.filled.AddKt.getAdd(androidx.compose.material.icons.Icons.INSTANCE.getDefault()), androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.add_to_cart_icon_description, composer, 0), (androidx.compose.ui.Modifier) null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnPrimary(), composer, 0, 4);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
