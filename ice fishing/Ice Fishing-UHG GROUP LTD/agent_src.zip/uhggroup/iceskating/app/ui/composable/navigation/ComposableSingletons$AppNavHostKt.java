package uhggroup.iceskating.app.ui.composable.navigation;

/* compiled from: AppNavHost.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$AppNavHostKt {
    public static final uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt INSTANCE = new uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt();
    private static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1550572251 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1550572251, false, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function4
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
            return uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda_1550572251$lambda$0((androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
        }
    });

    /* renamed from: lambda$-1398407880, reason: not valid java name */
    private static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> f55lambda$1398407880 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(-1398407880, false, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function4
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
            return uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda__1398407880$lambda$0((androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
        }
    });
    private static kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$1913566039 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(1913566039, false, new kotlin.jvm.functions.Function4() { // from class: uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function4
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3, java.lang.Object obj4) {
            return uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda_1913566039$lambda$0((androidx.compose.animation.AnimatedContentScope) obj, (androidx.navigation.NavBackStackEntry) obj2, (androidx.compose.runtime.Composer) obj3, ((java.lang.Integer) obj4).intValue());
        }
    });

    /* renamed from: getLambda$-1398407880$app_release, reason: not valid java name */
    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> m11462getLambda$1398407880$app_release() {
        return f55lambda$1398407880;
    }

    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1550572251$app_release() {
        return lambda$1550572251;
    }

    public final kotlin.jvm.functions.Function4<androidx.compose.animation.AnimatedContentScope, androidx.navigation.NavBackStackEntry, androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$1913566039$app_release() {
        return lambda$1913566039;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda__1398407880$lambda$0(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)97@3497L17:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(-1398407880, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda$-1398407880.<anonymous> (AppNavHost.kt:97)");
        }
        uhggroup.iceskating.app.ui.composable.screen.order.ICSOrderScreenKt.ICSOrdersScreen(null, null, composer, 0, 3);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1913566039$lambda$0(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry it, androidx.compose.runtime.Composer composer, int i) throws android.content.res.Resources.NotFoundException {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(it, "it");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(it)101@3578L19:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(1913566039, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda$1913566039.<anonymous> (AppNavHost.kt:101)");
        }
        uhggroup.iceskating.app.ui.composable.screen.settings.ICSSettingsScreenKt.ICSSettingsScreen(null, composer, 0, 1);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_1550572251$lambda$0(androidx.compose.animation.AnimatedContentScope composable, androidx.navigation.NavBackStackEntry backStackEntry, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(composable, "$this$composable");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(backStackEntry, "backStackEntry");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "CN(backStackEntry)73@2823L85:AppNavHost.kt#lkihw9");
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventStart(1550572251, i, -1, "uhggroup.iceskating.app.ui.composable.navigation.ComposableSingletons$AppNavHostKt.lambda$1550572251.<anonymous> (AppNavHost.kt:72)");
        }
        uhggroup.iceskating.app.ui.composable.screen.productdetails.ICSProductDetailsScreenKt.ICSProductDetailsScreen(((uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails) androidx.navigation.NavBackStackEntryKt.toRoute(backStackEntry, kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.composable.navigation.NavRoute.ProductDetails.class))).getId(), null, null, composer, 0, 6);
        if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            androidx.compose.runtime.ComposerKt.traceEventEnd();
        }
        return kotlin.Unit.INSTANCE;
    }
}
