package uhggroup.iceskating.app.ui.composable.screen.checkout;

/* compiled from: CheckoutDialog.kt */
@kotlin.Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u001b\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003H\u0007¢\u0006\u0002\u0010\u0004¨\u0006\u0005"}, d2 = {"CheckoutDialog", "", "onConfirm", "Lkotlin/Function0;", "(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CheckoutDialogKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutDialog$lambda$1(kotlin.jvm.functions.Function0 function0, int i, androidx.compose.runtime.Composer composer, int i2) {
        CheckoutDialog(function0, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return kotlin.Unit.INSTANCE;
    }

    public static final void CheckoutDialog(final kotlin.jvm.functions.Function0<kotlin.Unit> onConfirm, androidx.compose.runtime.Composer composer, final int i) {
        int i2;
        androidx.compose.runtime.Composer composer2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onConfirm, "onConfirm");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(34950145);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CheckoutDialog)N(onConfirm)21@743L332,48@1778L11,49@1854L11,50@1918L11,19@668L1285:CheckoutDialog.kt#yz6ycr");
        if ((i & 6) == 0) {
            i2 = i | (composerStartRestartGroup.changedInstance(onConfirm) ? 4 : 2);
        } else {
            i2 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i2 & 3) != 2, i2 & 1)) {
            composer2 = composerStartRestartGroup;
            composer2.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(34950145, i2, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialog (CheckoutDialog.kt:18)");
            }
            composer2 = composerStartRestartGroup;
            androidx.compose.material3.AndroidAlertDialog_androidKt.m2434AlertDialogOix01E0(onConfirm, androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1088788041, true, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialogKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialogKt.CheckoutDialog$lambda$0(onConfirm, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            }, composerStartRestartGroup, 54), null, null, null, uhggroup.iceskating.app.ui.composable.screen.checkout.ComposableSingletons$CheckoutDialogKt.INSTANCE.getLambda$1815721037$app_release(), uhggroup.iceskating.app.ui.composable.screen.checkout.ComposableSingletons$CheckoutDialogKt.INSTANCE.getLambda$1997454286$app_release(), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHigh(), 0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), 0.0f, null, composer2, (i2 & 14) | 1769520, 0, 12956);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialogKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialogKt.CheckoutDialog$lambda$1(onConfirm, i, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CheckoutDialog$lambda$0(kotlin.jvm.functions.Function0 function0, androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C25@913L11,24@846L105,22@757L308:CheckoutDialog.kt#yz6ycr");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1088788041, i, -1, "uhggroup.iceskating.app.ui.composable.screen.checkout.CheckoutDialog.<anonymous> (CheckoutDialog.kt:22)");
            }
            androidx.compose.material3.ButtonKt.TextButton(function0, null, false, null, androidx.compose.material3.ButtonDefaults.INSTANCE.m2533textButtonColorsro_MJ88(0L, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), 0L, 0L, composer, androidx.compose.material3.ButtonDefaults.$stable << 12, 13), null, null, null, null, uhggroup.iceskating.app.ui.composable.screen.checkout.ComposableSingletons$CheckoutDialogKt.INSTANCE.getLambda$484528966$app_release(), composer, 805306368, 494);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
