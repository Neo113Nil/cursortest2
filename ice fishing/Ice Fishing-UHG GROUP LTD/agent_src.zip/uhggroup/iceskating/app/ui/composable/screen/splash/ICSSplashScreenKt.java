package uhggroup.iceskating.app.ui.composable.screen.splash;

/* compiled from: ICSSplashScreen.kt */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\u001a=\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\t¨\u0006\n²\u0006\f\u0010\u000b\u001a\u0004\u0018\u00010\fX\u008a\u0084\u0002²\u0006\n\u0010\r\u001a\u00020\fX\u008a\u008e\u0002"}, d2 = {"ICSSplashScreen", "", "modifier", "Landroidx/compose/ui/Modifier;", "viewModel", "Luhggroup/iceskating/app/ui/viewmodel/SplashViewModel;", "onNavigateToHomeScreen", "Lkotlin/Function0;", "onNavigateToOnboarding", "(Landroidx/compose/ui/Modifier;Luhggroup/iceskating/app/ui/viewmodel/SplashViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_release", "onboardedState", "", "isAnimationFinished"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ICSSplashScreenKt {
    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSSplashScreen$lambda$6(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.SplashViewModel splashViewModel, kotlin.jvm.functions.Function0 function0, kotlin.jvm.functions.Function0 function02, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        ICSSplashScreen(modifier, splashViewModel, function0, function02, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:66:0x0108  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x015c  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0166  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x017e  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x01c4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void ICSSplashScreen(androidx.compose.ui.Modifier modifier, uhggroup.iceskating.app.ui.viewmodel.SplashViewModel splashViewModel, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToHomeScreen, final kotlin.jvm.functions.Function0<kotlin.Unit> onNavigateToOnboarding, androidx.compose.runtime.Composer composer, final int i, final int i2) throws android.content.res.Resources.NotFoundException {
        androidx.compose.ui.Modifier modifier2;
        int i3;
        uhggroup.iceskating.app.ui.viewmodel.SplashViewModel splashViewModel2;
        final androidx.compose.ui.Modifier modifier3;
        final uhggroup.iceskating.app.ui.viewmodel.SplashViewModel splashViewModel3;
        androidx.compose.ui.Modifier.Companion companion;
        uhggroup.iceskating.app.ui.viewmodel.SplashViewModel splashViewModel4;
        int i4;
        androidx.compose.runtime.State stateCollectAsStateWithLifecycle;
        java.lang.Object objRememberedValue;
        final androidx.compose.runtime.MutableState mutableState;
        boolean zChanged;
        int i5;
        int i6;
        androidx.compose.ui.Modifier modifier4;
        uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1 iCSSplashScreenKt$ICSSplashScreen$1$1;
        java.lang.Object objRememberedValue2;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToHomeScreen, "onNavigateToHomeScreen");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onNavigateToOnboarding, "onNavigateToOnboarding");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(-571561578);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(ICSSplashScreen)N(modifier,viewModel,onNavigateToHomeScreen,onNavigateToOnboarding)21@853L29,23@915L34,25@1007L200,25@955L252,34@1287L30,32@1213L111:ICSSplashScreen.kt#k9vs7e");
        int i7 = i2 & 1;
        if (i7 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if ((i & 48) == 0) {
            if ((i2 & 2) == 0) {
                splashViewModel2 = splashViewModel;
                int i8 = composerStartRestartGroup.changedInstance(splashViewModel2) ? 32 : 16;
                i3 |= i8;
            } else {
                splashViewModel2 = splashViewModel;
            }
            i3 |= i8;
        } else {
            splashViewModel2 = splashViewModel;
        }
        if ((i & 384) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToHomeScreen) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= composerStartRestartGroup.changedInstance(onNavigateToOnboarding) ? 2048 : 1024;
        }
        if (composerStartRestartGroup.shouldExecute((i3 & 1171) != 1170, i3 & 1)) {
            composerStartRestartGroup.startDefaults();
            androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "17@701L15");
            if ((i & 1) != 0 && !composerStartRestartGroup.getDefaultsInvalid()) {
                composerStartRestartGroup.skipToGroupEnd();
                if ((i2 & 2) != 0) {
                    i3 &= -113;
                }
                companion = modifier2;
            } else {
                companion = i7 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if ((i2 & 2) != 0) {
                    composerStartRestartGroup.startReplaceGroup(-1614864554);
                    androidx.lifecycle.ViewModelStoreOwner current = androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.INSTANCE.getCurrent(composerStartRestartGroup, androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner.$stable);
                    if (current == null) {
                        throw new java.lang.IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                    }
                    androidx.lifecycle.ViewModel viewModelResolveViewModel = org.koin.viewmodel.GetViewModelKt.resolveViewModel(kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(uhggroup.iceskating.app.ui.viewmodel.SplashViewModel.class), current.getViewModelStore(), null, org.koin.viewmodel.CreationExtrasExtKt.defaultExtras(current), null, org.koin.compose.KoinApplicationKt.currentKoinScope(composerStartRestartGroup, 0), null);
                    composerStartRestartGroup.endReplaceGroup();
                    splashViewModel4 = (uhggroup.iceskating.app.ui.viewmodel.SplashViewModel) viewModelResolveViewModel;
                    i4 = i3 & (-113);
                }
                composerStartRestartGroup.endDefaults();
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(-571561578, i4, -1, "uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreen (ICSSplashScreen.kt:20)");
                }
                stateCollectAsStateWithLifecycle = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(splashViewModel4.getOnboardedState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485147160, "CC(remember):ICSSplashScreen.kt#9igjgp");
                objRememberedValue = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue);
                }
                mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                java.lang.Boolean boolValueOf = java.lang.Boolean.valueOf(ICSSplashScreen$lambda$2(mutableState));
                java.lang.Boolean boolICSSplashScreen$lambda$0 = ICSSplashScreen$lambda$0(stateCollectAsStateWithLifecycle);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485150270, "CC(remember):ICSSplashScreen.kt#9igjgp");
                zChanged = composerStartRestartGroup.changed(stateCollectAsStateWithLifecycle) | ((i4 & 896) != 256) | ((i4 & 7168) == 2048);
                java.lang.Object objRememberedValue3 = composerStartRestartGroup.rememberedValue();
                if (!zChanged || objRememberedValue3 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    i5 = 0;
                    i6 = i4;
                    modifier4 = companion;
                    iCSSplashScreenKt$ICSSplashScreen$1$1 = new uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1(onNavigateToHomeScreen, onNavigateToOnboarding, stateCollectAsStateWithLifecycle, mutableState, null);
                    composerStartRestartGroup.updateRememberedValue(iCSSplashScreenKt$ICSSplashScreen$1$1);
                } else {
                    i5 = 0;
                    modifier4 = companion;
                    iCSSplashScreenKt$ICSSplashScreen$1$1 = objRememberedValue3;
                    i6 = i4;
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.EffectsKt.LaunchedEffect(boolValueOf, boolICSSplashScreen$lambda$0, (kotlin.jvm.functions.Function2) iCSSplashScreenKt$ICSSplashScreen$1$1, composerStartRestartGroup, i5);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485159060, "CC(remember):ICSSplashScreen.kt#9igjgp");
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final java.lang.Object invoke() {
                            return uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt.ICSSplashScreen$lambda$5$0(mutableState);
                        }
                    };
                    composerStartRestartGroup.updateRememberedValue(objRememberedValue2);
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt.SplashContent(modifier4, (kotlin.jvm.functions.Function0) objRememberedValue2, composerStartRestartGroup, (i6 & 14) | 48, i5);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
                splashViewModel3 = splashViewModel4;
            }
            i4 = i3;
            splashViewModel4 = splashViewModel2;
            composerStartRestartGroup.endDefaults();
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
            }
            stateCollectAsStateWithLifecycle = androidx.lifecycle.compose.FlowExtKt.collectAsStateWithLifecycle(splashViewModel4.getOnboardedState(), (androidx.lifecycle.LifecycleOwner) null, (androidx.lifecycle.Lifecycle.State) null, (kotlin.coroutines.CoroutineContext) null, composerStartRestartGroup, 0, 7);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485147160, "CC(remember):ICSSplashScreen.kt#9igjgp");
            objRememberedValue = composerStartRestartGroup.rememberedValue();
            if (objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
            }
            mutableState = (androidx.compose.runtime.MutableState) objRememberedValue;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
            java.lang.Boolean boolValueOf2 = java.lang.Boolean.valueOf(ICSSplashScreen$lambda$2(mutableState));
            java.lang.Boolean boolICSSplashScreen$lambda$02 = ICSSplashScreen$lambda$0(stateCollectAsStateWithLifecycle);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485150270, "CC(remember):ICSSplashScreen.kt#9igjgp");
            zChanged = composerStartRestartGroup.changed(stateCollectAsStateWithLifecycle) | ((i4 & 896) != 256) | ((i4 & 7168) == 2048);
            java.lang.Object objRememberedValue32 = composerStartRestartGroup.rememberedValue();
            if (zChanged) {
                i5 = 0;
                i6 = i4;
                modifier4 = companion;
                iCSSplashScreenKt$ICSSplashScreen$1$1 = new uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$ICSSplashScreen$1$1(onNavigateToHomeScreen, onNavigateToOnboarding, stateCollectAsStateWithLifecycle, mutableState, null);
                composerStartRestartGroup.updateRememberedValue(iCSSplashScreenKt$ICSSplashScreen$1$1);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.EffectsKt.LaunchedEffect(boolValueOf2, boolICSSplashScreen$lambda$02, (kotlin.jvm.functions.Function2) iCSSplashScreenKt$ICSSplashScreen$1$1, composerStartRestartGroup, i5);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 485159060, "CC(remember):ICSSplashScreen.kt#9igjgp");
                objRememberedValue2 = composerStartRestartGroup.rememberedValue();
                if (objRememberedValue2 == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                }
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.composable.screen.splash.SplashContentKt.SplashContent(modifier4, (kotlin.jvm.functions.Function0) objRememberedValue2, composerStartRestartGroup, (i6 & 14) | 48, i5);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                }
                modifier3 = modifier4;
                splashViewModel3 = splashViewModel4;
            }
        } else {
            composerStartRestartGroup.skipToGroupEnd();
            modifier3 = modifier2;
            splashViewModel3 = splashViewModel2;
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.splash.ICSSplashScreenKt.ICSSplashScreen$lambda$6(modifier3, splashViewModel3, onNavigateToHomeScreen, onNavigateToOnboarding, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean ICSSplashScreen$lambda$2(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void ICSSplashScreen$lambda$3(androidx.compose.runtime.MutableState<java.lang.Boolean> mutableState, boolean z) {
        mutableState.setValue(java.lang.Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit ICSSplashScreen$lambda$5$0(androidx.compose.runtime.MutableState mutableState) {
        ICSSplashScreen$lambda$3(mutableState, true);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.Boolean ICSSplashScreen$lambda$0(androidx.compose.runtime.State<java.lang.Boolean> state) {
        return state.getValue();
    }
}
