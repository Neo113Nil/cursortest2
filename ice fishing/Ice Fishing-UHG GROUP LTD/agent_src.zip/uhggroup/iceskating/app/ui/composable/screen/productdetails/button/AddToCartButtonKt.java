package uhggroup.iceskating.app.ui.composable.screen.productdetails.button;

/* compiled from: AddToCartButton.kt */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a%\u0010\u0003\u001a\u00020\u00042\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bH\u0007¢\u0006\u0002\u0010\t\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\n"}, d2 = {"ButtonHeight", "Landroidx/compose/ui/unit/Dp;", "F", "AddToCartButton", "", "onClick", "Lkotlin/Function0;", "modifier", "Landroidx/compose/ui/Modifier;", "(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AddToCartButtonKt {
    private static final float ButtonHeight = androidx.compose.ui.unit.Dp.m8851constructorimpl(52);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit AddToCartButton$lambda$1(kotlin.jvm.functions.Function0 function0, androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) {
        AddToCartButton(function0, modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x01e5  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x01ef  */
    /* JADX WARN: Removed duplicated region for block: B:48:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void AddToCartButton(final kotlin.jvm.functions.Function0<kotlin.Unit> onClick, androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) {
        int i3;
        androidx.compose.ui.Modifier modifier2;
        int i4;
        final androidx.compose.ui.Modifier modifier3;
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onClick, "onClick");
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(959172607);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(AddToCartButton)N(onClick,modifier)26@968L7,31@1083L11,28@981L956:AddToCartButton.kt#81h3xa");
        if ((i & 6) == 0) {
            i3 = (composerStartRestartGroup.changedInstance(onClick) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        int i5 = i2 & 2;
        if (i5 == 0) {
            if ((i & 48) == 0) {
                modifier2 = modifier;
                i3 |= composerStartRestartGroup.changed(modifier2) ? 32 : 16;
            }
            i4 = i3;
            if (composerStartRestartGroup.shouldExecute((i4 & 19) == 18, i4 & 1)) {
                composerStartRestartGroup.skipToGroupEnd();
                modifier3 = modifier2;
            } else {
                androidx.compose.ui.Modifier modifier4 = i5 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventStart(959172607, i4, -1, "uhggroup.iceskating.app.ui.composable.screen.productdetails.button.AddToCartButton (AddToCartButton.kt:25)");
                }
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.ui.Modifier modifierM1162padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m1162padding3ABfNKs(androidx.compose.foundation.BackgroundKt.m324backgroundbw27NRU$default(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(modifier4, 0.0f, 1, null), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerHighest(), null, 2, null), dimens.m11613getCardPaddingD9Ej5fM());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
                androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composerStartRestartGroup, 0);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
                int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composerStartRestartGroup, 0));
                androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composerStartRestartGroup.getCurrentCompositionLocalMap();
                androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composerStartRestartGroup, modifierM1162padding3ABfNKs);
                kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
                if (!(composerStartRestartGroup.getApplier() instanceof androidx.compose.runtime.Applier)) {
                    androidx.compose.runtime.ComposablesKt.invalidApplier();
                }
                composerStartRestartGroup.startReusableNode();
                if (composerStartRestartGroup.getInserting()) {
                    composerStartRestartGroup.createNode(constructor);
                } else {
                    composerStartRestartGroup.useNode();
                }
                androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composerStartRestartGroup);
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
                androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
                androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 771430409, "C40@1427L112,45@1638L11,46@1704L11,44@1577L163,34@1178L753:AddToCartButton.kt#81h3xa");
                float f = 0;
                modifier3 = modifier4;
                androidx.compose.material3.ButtonKt.Button(onClick, androidx.compose.foundation.layout.SizeKt.m1218height3ABfNKs(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null), ButtonHeight), false, androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11616getControlCornerRadiusD9Ej5fM()), androidx.compose.material3.ButtonDefaults.INSTANCE.m2522buttonColorsro_MJ88(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnPrimary(), 0L, 0L, composerStartRestartGroup, androidx.compose.material3.ButtonDefaults.$stable << 12, 12), androidx.compose.material3.ButtonDefaults.INSTANCE.m2523buttonElevationR_JCAzs(androidx.compose.ui.unit.Dp.m8851constructorimpl(f), androidx.compose.ui.unit.Dp.m8851constructorimpl(f), 0.0f, 0.0f, 0.0f, composerStartRestartGroup, (androidx.compose.material3.ButtonDefaults.$stable << 15) | 54, 28), null, null, null, uhggroup.iceskating.app.ui.composable.screen.productdetails.button.ComposableSingletons$AddToCartButtonKt.INSTANCE.m11499getLambda$1749145767$app_release(), composerStartRestartGroup, (i4 & 14) | 805306416, 452);
                composerStartRestartGroup = composerStartRestartGroup;
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                composerStartRestartGroup.endNode();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
            }
            scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.productdetails.button.AddToCartButtonKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                        return uhggroup.iceskating.app.ui.composable.screen.productdetails.button.AddToCartButtonKt.AddToCartButton$lambda$1(onClick, modifier3, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                    }
                });
                return;
            }
            return;
        }
        i3 |= 48;
        modifier2 = modifier;
        i4 = i3;
        if (composerStartRestartGroup.shouldExecute((i4 & 19) == 18, i4 & 1)) {
        }
        scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
        }
    }
}
