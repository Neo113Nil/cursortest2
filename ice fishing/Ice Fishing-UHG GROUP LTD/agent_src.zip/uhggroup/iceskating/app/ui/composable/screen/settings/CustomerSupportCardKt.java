package uhggroup.iceskating.app.ui.composable.screen.settings;

/* compiled from: CustomerSupportCard.kt */
@kotlin.Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0017\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0002\u0010\b\"\u0010\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002\"\u0010\u0010\u0003\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0002¨\u0006\t"}, d2 = {"LeadingIconSize", "Landroidx/compose/ui/unit/Dp;", "F", "TrailingIconSize", "CustomerSupportCard", "", "modifier", "Landroidx/compose/ui/Modifier;", "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_release"}, k = 2, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CustomerSupportCardKt {
    private static final float LeadingIconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(22);
    private static final float TrailingIconSize = androidx.compose.ui.unit.Dp.m8851constructorimpl(18);

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CustomerSupportCard$lambda$0(androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        CustomerSupportCard(modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CustomerSupportCard$lambda$2(androidx.compose.ui.Modifier modifier, int i, int i2, androidx.compose.runtime.Composer composer, int i3) throws android.content.res.Resources.NotFoundException {
        CustomerSupportCard(modifier, composer, androidx.compose.runtime.RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return kotlin.Unit.INSTANCE;
    }

    public static final void CustomerSupportCard(androidx.compose.ui.Modifier modifier, androidx.compose.runtime.Composer composer, final int i, final int i2) throws android.content.res.Resources.NotFoundException {
        final androidx.compose.ui.Modifier modifier2;
        int i3;
        androidx.compose.runtime.Composer composerStartRestartGroup = composer.startRestartGroup(784424827);
        androidx.compose.runtime.ComposerKt.sourceInformation(composerStartRestartGroup, "C(CustomerSupportCard)N(modifier)35@1499L50,38@1618L7,39@1663L7,45@1872L11,46@1946L11,44@1817L161,48@1997L18,49@2023L1562,41@1676L1909:CustomerSupportCard.kt#yd110y");
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
            modifier2 = modifier;
        } else if ((i & 6) == 0) {
            modifier2 = modifier;
            i3 = (composerStartRestartGroup.changed(modifier2) ? 4 : 2) | i;
        } else {
            modifier2 = modifier;
            i3 = i;
        }
        if (!composerStartRestartGroup.shouldExecute((i3 & 3) != 2, i3 & 1)) {
            composerStartRestartGroup.skipToGroupEnd();
        } else {
            final androidx.compose.ui.Modifier.Companion companion = i4 != 0 ? androidx.compose.ui.Modifier.INSTANCE : modifier2;
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(784424827, i3, -1, "uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCard (CustomerSupportCard.kt:34)");
            }
            final java.lang.String strStringResource = androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.ics_customer_support_link, composerStartRestartGroup, 0);
            if (!kotlin.text.StringsKt.isBlank(strStringResource)) {
                androidx.compose.runtime.ProvidableCompositionLocal<uhggroup.iceskating.app.ui.theme.dimens.Dimens> localDimens = uhggroup.iceskating.app.ui.theme.ThemeKt.getLocalDimens();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume = composerStartRestartGroup.consume(localDimens);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens = (uhggroup.iceskating.app.ui.theme.dimens.Dimens) objConsume;
                androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.ui.platform.UriHandler> localUriHandler = androidx.compose.ui.platform.CompositionLocalsKt.getLocalUriHandler();
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composerStartRestartGroup, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                java.lang.Object objConsume2 = composerStartRestartGroup.consume(localUriHandler);
                androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composerStartRestartGroup);
                final androidx.compose.ui.platform.UriHandler uriHandler = (androidx.compose.ui.platform.UriHandler) objConsume2;
                androidx.compose.ui.Modifier modifier3 = companion;
                androidx.compose.material3.CardKt.Card(androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(companion, 0.0f, 1, null), androidx.compose.foundation.shape.RoundedCornerShapeKt.m1543RoundedCornerShape0680j_4(dimens.m11612getCardCornerRadiusD9Ej5fM()), androidx.compose.material3.CardDefaults.INSTANCE.m2544cardColorsro_MJ88(androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getSurfaceContainerLow(), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composerStartRestartGroup, androidx.compose.material3.MaterialTheme.$stable).getOnSurface(), 0L, 0L, composerStartRestartGroup, androidx.compose.material3.CardDefaults.$stable << 12, 12), null, uhggroup.iceskating.app.ui.theme.BordersKt.m11516cardBorderStrokeIv8Zu3U(0L, composerStartRestartGroup, 0, 1), androidx.compose.runtime.internal.ComposableLambdaKt.rememberComposableLambda(1902532205, true, new kotlin.jvm.functions.Function3() { // from class: uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2, java.lang.Object obj3) {
                        return uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt.CustomerSupportCard$lambda$1(uriHandler, strStringResource, dimens, (androidx.compose.foundation.layout.ColumnScope) obj, (androidx.compose.runtime.Composer) obj2, ((java.lang.Integer) obj3).intValue());
                    }
                }, composerStartRestartGroup, 54), composerStartRestartGroup, androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                modifier2 = modifier3;
            } else {
                if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                    androidx.compose.runtime.ComposerKt.traceEventEnd();
                }
                androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup = composerStartRestartGroup.endRestartGroup();
                if (scopeUpdateScopeEndRestartGroup != null) {
                    scopeUpdateScopeEndRestartGroup.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function2
                        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                            return uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt.CustomerSupportCard$lambda$0(companion, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                        }
                    });
                    return;
                }
                return;
            }
        }
        androidx.compose.runtime.ScopeUpdateScope scopeUpdateScopeEndRestartGroup2 = composerStartRestartGroup.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup2 != null) {
            scopeUpdateScopeEndRestartGroup2.updateScope(new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function2
                public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
                    return uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt.CustomerSupportCard$lambda$2(modifier2, i, i2, (androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CustomerSupportCard$lambda$1(final androidx.compose.ui.platform.UriHandler uriHandler, final java.lang.String str, uhggroup.iceskating.app.ui.theme.dimens.Dimens dimens, androidx.compose.foundation.layout.ColumnScope Card, androidx.compose.runtime.Composer composer, int i) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(Card, "$this$Card");
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C53@2129L35,50@2033L1546:CustomerSupportCard.kt#yd110y");
        if (!composer.shouldExecute((i & 17) != 16, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(1902532205, i, -1, "uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCard.<anonymous> (CustomerSupportCard.kt:50)");
            }
            androidx.compose.ui.Modifier modifierFillMaxWidth$default = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(androidx.compose.ui.Modifier.INSTANCE, 0.0f, 1, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1322615664, "CC(remember):CustomerSupportCard.kt#9igjgp");
            boolean zChangedInstance = composer.changedInstance(uriHandler) | composer.changed(str);
            java.lang.Object objRememberedValue = composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == androidx.compose.runtime.Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new kotlin.jvm.functions.Function0() { // from class: uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final java.lang.Object invoke() {
                        return uhggroup.iceskating.app.ui.composable.screen.settings.CustomerSupportCardKt.CustomerSupportCard$lambda$1$0$0(uriHandler, str);
                    }
                };
                composer.updateRememberedValue(objRememberedValue);
            }
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.ui.Modifier modifierM1162padding3ABfNKs = androidx.compose.foundation.layout.PaddingKt.m1162padding3ABfNKs(androidx.compose.foundation.ClickableKt.m370clickableoSLSa3U$default(modifierFillMaxWidth$default, false, null, null, null, (kotlin.jvm.functions.Function0) objRememberedValue, 15, null), dimens.m11613getCardPaddingD9Ej5fM());
            androidx.compose.ui.Alignment.Vertical centerVertically = androidx.compose.ui.Alignment.INSTANCE.getCenterVertically();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyRowMeasurePolicy = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getStart(), centerVertically, composer, 48);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierM1162padding3ABfNKs);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, measurePolicyRowMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, currentCompositionLocalMap, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, java.lang.Integer.valueOf(iHashCode), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl, modifierMaterializeModifier, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
            androidx.compose.foundation.layout.RowScopeInstance rowScopeInstance = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1674980888, "C60@2440L11,57@2295L238,64@2547L56,66@2617L620,82@3251L56,87@3466L11,84@3321L248:CustomerSupportCard.kt#yd110y");
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.outlined.SupportAgentKt.getSupportAgent(androidx.compose.material.icons.Icons.Outlined.INSTANCE), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, LeadingIconSize), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), composer, 432, 0);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11614getContentSpacingD9Ej5fM()), composer, 0);
            androidx.compose.ui.Modifier modifierWeight$default = androidx.compose.foundation.layout.RowScope.weight$default(rowScopeInstance, androidx.compose.ui.Modifier.INSTANCE, 1.0f, false, 2, null);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
            androidx.compose.ui.layout.MeasurePolicy measurePolicyColumnMeasurePolicy = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(androidx.compose.foundation.layout.Arrangement.INSTANCE.getTop(), androidx.compose.ui.Alignment.INSTANCE.getStart(), composer, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)N(content,modifier,measurePolicy)81@3355L27,84@3521L415:Layout.kt#80mrfh");
            int iHashCode2 = java.lang.Long.hashCode(androidx.compose.runtime.ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
            androidx.compose.runtime.CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            androidx.compose.ui.Modifier modifierMaterializeModifier2 = androidx.compose.ui.ComposedModifierKt.materializeModifier(composer, modifierWeight$default);
            kotlin.jvm.functions.Function0<androidx.compose.ui.node.ComposeUiNode> constructor2 = androidx.compose.ui.node.ComposeUiNode.INSTANCE.getConstructor();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)410@16187L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof androidx.compose.runtime.Applier)) {
                androidx.compose.runtime.ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            } else {
                composer.useNode();
            }
            androidx.compose.runtime.Composer composerM5083constructorimpl2 = androidx.compose.runtime.Updater.m5083constructorimpl(composer);
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, measurePolicyColumnMeasurePolicy, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, currentCompositionLocalMap2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, java.lang.Integer.valueOf(iHashCode2), androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetCompositeKeyHash());
            androidx.compose.runtime.Updater.m5089reconcileimpl(composerM5083constructorimpl2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getApplyOnDeactivatedNodeAssertion());
            androidx.compose.runtime.Updater.m5091setimpl(composerM5083constructorimpl2, modifierMaterializeModifier2, androidx.compose.ui.node.ComposeUiNode.INSTANCE.getSetModifier());
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
            androidx.compose.foundation.layout.ColumnScopeInstance columnScopeInstance = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE;
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(composer, 545469975, "C68@2707L63,69@2814L11,70@2886L10,67@2674L252,75@3032L11,76@3095L10,73@2944L279:CustomerSupportCard.kt#yd110y");
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(androidx.compose.ui.res.StringResources_androidKt.stringResource(uhggroup.iceskating.app.R.string.settings_screen_customer_support_label, composer, 0), null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getLabelSmall(), composer, 0, 0, 131066);
            androidx.compose.material3.TextKt.m3717TextNvy7gAk(str, null, androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, androidx.compose.ui.text.style.TextOverflow.INSTANCE.m8787getEllipsisgIe3tQ8(), false, 1, 0, null, androidx.compose.material3.MaterialTheme.INSTANCE.getTypography(composer, androidx.compose.material3.MaterialTheme.$stable).getBodyMedium(), composer, 0, 24960, 110586);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.foundation.layout.SpacerKt.Spacer(androidx.compose.foundation.layout.SizeKt.m1237width3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, dimens.m11614getContentSpacingD9Ej5fM()), composer, 0);
            androidx.compose.material3.IconKt.m3011Iconww6aTOc(androidx.compose.material.icons.outlined.ArrowOutwardKt.getArrowOutward(androidx.compose.material.icons.Icons.Outlined.INSTANCE), (java.lang.String) null, androidx.compose.foundation.layout.SizeKt.m1232size3ABfNKs(androidx.compose.ui.Modifier.INSTANCE, TrailingIconSize), androidx.compose.material3.MaterialTheme.INSTANCE.getColorScheme(composer, androidx.compose.material3.MaterialTheme.$stable).getOnSurfaceVariant(), composer, 432, 0);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            composer.endNode();
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(composer);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit CustomerSupportCard$lambda$1$0$0(androidx.compose.ui.platform.UriHandler uriHandler, java.lang.String str) {
        uriHandler.openUri(str);
        return kotlin.Unit.INSTANCE;
    }
}
