package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: CartViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u000e\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0019J\u0016\u0010\u001c\u001a\u00020\u00122\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\f0\u000bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R#\u0010\r\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\n0\u000e8F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\u000e8F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0010¨\u0006\u001e"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/CartViewModel;", "Landroidx/lifecycle/ViewModel;", "cartRepository", "Luhggroup/iceskating/app/data/repository/CartRepository;", "productRepository", "Luhggroup/iceskating/app/data/repository/ProductRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/CartRepository;Luhggroup/iceskating/app/data/repository/ProductRepository;)V", "_cartItemsState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/ui/state/CartItemUiState;", "cartItemsState", "Lkotlinx/coroutines/flow/StateFlow;", "getCartItemsState", "()Lkotlinx/coroutines/flow/StateFlow;", "_totalPrice", "", "totalPrice", "getTotalPrice", "observeCartItems", "", "incrementProductInCart", "productId", "", "deleteFromCart", "decrementItemInCart", "calculateTotalPrice", "items", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CartViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>> _cartItemsState;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Double> _totalPrice;
    private final uhggroup.iceskating.app.data.repository.CartRepository cartRepository;
    private final uhggroup.iceskating.app.data.repository.ProductRepository productRepository;

    public CartViewModel(uhggroup.iceskating.app.data.repository.CartRepository cartRepository, uhggroup.iceskating.app.data.repository.ProductRepository productRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartRepository, "cartRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productRepository, "productRepository");
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this._cartItemsState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE);
        this._totalPrice = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(java.lang.Double.valueOf(0.0d));
        observeCartItems();
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>> getCartItemsState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._cartItemsState);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Double> getTotalPrice() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._totalPrice);
    }

    /* compiled from: CartViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CartViewModel$observeCartItems$1", f = "CartViewModel.kt", i = {}, l = {58}, m = "invokeSuspend", n = {}, nl = {61}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CartViewModel$observeCartItems$1, reason: invalid class name and case insensitive filesystem */
    static final class C05401 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C05401(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.new C05401(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.flow.Flow flowCombine = kotlinx.coroutines.flow.FlowKt.combine(uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.cartRepository.observeAll(), uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.productRepository.observeAll(), new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401.C00861(uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this, null));
                final uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel = uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this;
                this.label = 1;
                if (flowCombine.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: uhggroup.iceskating.app.ui.viewmodel.CartViewModel.observeCartItems.1.2
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        return emit((uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                    }

                    public final java.lang.Object emit(uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>> dataUiState, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                        cartViewModel._cartItemsState.setValue(dataUiState);
                        return kotlin.Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }

        /* compiled from: CartViewModel.kt */
        @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00050\u00022\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00070\u0002H\n"}, d2 = {"<anonymous>", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/ui/state/CartItemUiState;", "cartItems", "Luhggroup/iceskating/app/data/entity/CartItemEntity;", "products", "Luhggroup/iceskating/app/data/model/Product;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
        @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CartViewModel$observeCartItems$1$1", f = "CartViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
        /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CartViewModel$observeCartItems$1$1, reason: invalid class name and collision with other inner class name */
        static final class C00861 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function3<java.util.List<? extends uhggroup.iceskating.app.data.entity.CartItemEntity>, java.util.List<? extends uhggroup.iceskating.app.data.model.Product>, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<? extends uhggroup.iceskating.app.ui.state.CartItemUiState>>>, java.lang.Object> {
            /* synthetic */ java.lang.Object L$0;
            /* synthetic */ java.lang.Object L$1;
            int label;
            final /* synthetic */ uhggroup.iceskating.app.ui.viewmodel.CartViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C00861(uhggroup.iceskating.app.ui.viewmodel.CartViewModel cartViewModel, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401.C00861> continuation) {
                super(3, continuation);
                this.this$0 = cartViewModel;
            }

            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ java.lang.Object invoke(java.util.List<? extends uhggroup.iceskating.app.data.entity.CartItemEntity> list, java.util.List<? extends uhggroup.iceskating.app.data.model.Product> list2, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<? extends uhggroup.iceskating.app.ui.state.CartItemUiState>>> continuation) {
                return invoke2((java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>) list, (java.util.List<uhggroup.iceskating.app.data.model.Product>) list2, (kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>>) continuation);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final java.lang.Object invoke2(java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity> list, java.util.List<uhggroup.iceskating.app.data.model.Product> list2, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.state.DataUiState<? extends java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState>>> continuation) {
                uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401.C00861 c00861 = new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401.C00861(this.this$0, continuation);
                c00861.L$0 = list;
                c00861.L$1 = list2;
                return c00861.invokeSuspend(kotlin.Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity> list = (java.util.List) this.L$0;
                java.util.List list2 = (java.util.List) this.L$1;
                kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label != 0) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
                java.util.List list3 = list2;
                java.util.LinkedHashMap linkedHashMap = new java.util.LinkedHashMap(kotlin.ranges.RangesKt.coerceAtLeast(kotlin.collections.MapsKt.mapCapacity(kotlin.collections.CollectionsKt.collectionSizeOrDefault(list3, 10)), 16));
                for (java.lang.Object obj2 : list3) {
                    linkedHashMap.put(kotlin.coroutines.jvm.internal.Boxing.boxInt(((uhggroup.iceskating.app.data.model.Product) obj2).getId()), obj2);
                }
                java.util.ArrayList arrayList = new java.util.ArrayList();
                for (uhggroup.iceskating.app.data.entity.CartItemEntity cartItemEntity : list) {
                    uhggroup.iceskating.app.data.model.Product product = (uhggroup.iceskating.app.data.model.Product) linkedHashMap.get(kotlin.coroutines.jvm.internal.Boxing.boxInt(cartItemEntity.getId()));
                    uhggroup.iceskating.app.ui.state.CartItemUiState cartItemUiState = product != null ? new uhggroup.iceskating.app.ui.state.CartItemUiState(product.getId(), product.getTitle(), product.getPrice(), cartItemEntity.getQuantity(), product.getImageUrl()) : null;
                    if (cartItemUiState != null) {
                        arrayList.add(cartItemUiState);
                    }
                }
                java.util.ArrayList arrayList2 = arrayList;
                if (arrayList2.isEmpty()) {
                    return uhggroup.iceskating.app.ui.state.DataUiState.Empty.INSTANCE;
                }
                this.this$0._totalPrice.setValue(kotlin.coroutines.jvm.internal.Boxing.boxDouble(this.this$0.calculateTotalPrice(arrayList2)));
                return new uhggroup.iceskating.app.ui.state.DataUiState.Populated(arrayList2);
            }
        }
    }

    private final void observeCartItems() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05401(null), 3, null);
    }

    /* compiled from: CartViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CartViewModel$incrementProductInCart$1", f = "CartViewModel.kt", i = {}, l = {66}, m = "invokeSuspend", n = {}, nl = {67}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CartViewModel$incrementProductInCart$1, reason: invalid class name and case insensitive filesystem */
    static final class C05391 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $productId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05391(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05391> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.new C05391(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05391) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.cartRepository.incrementQuantity(this.$productId, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void incrementProductInCart(int productId) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05391(productId, null), 3, null);
    }

    /* compiled from: CartViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CartViewModel$deleteFromCart$1", f = "CartViewModel.kt", i = {}, l = {72}, m = "invokeSuspend", n = {}, nl = {73}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CartViewModel$deleteFromCart$1, reason: invalid class name and case insensitive filesystem */
    static final class C05381 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $productId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05381(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05381> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.new C05381(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05381) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.cartRepository.deleteById(this.$productId, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void deleteFromCart(int productId) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.C05381(productId, null), 3, null);
    }

    /* compiled from: CartViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CartViewModel$decrementItemInCart$1", f = "CartViewModel.kt", i = {0, 0}, l = {79}, m = "invokeSuspend", n = {"product", "$i$a$-let-CartViewModel$decrementItemInCart$1$1"}, nl = {80}, s = {"L$0", "I$0"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CartViewModel$decrementItemInCart$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $productId;
        int I$0;
        java.lang.Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CartViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.new AnonymousClass1(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.CartViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                uhggroup.iceskating.app.data.model.Product byId = uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.productRepository.getById(this.$productId);
                if (byId != null) {
                    uhggroup.iceskating.app.data.repository.CartRepository cartRepository = uhggroup.iceskating.app.ui.viewmodel.CartViewModel.this.cartRepository;
                    this.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(byId);
                    this.I$0 = 0;
                    this.label = 1;
                    if (cartRepository.decrementProductQuantityOrRemove(byId, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void decrementItemInCart(int productId) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.CartViewModel.AnonymousClass1(productId, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final double calculateTotalPrice(java.util.List<uhggroup.iceskating.app.ui.state.CartItemUiState> items) {
        java.util.Iterator<T> it = items.iterator();
        double productPrice = 0.0d;
        while (it.hasNext()) {
            productPrice += ((uhggroup.iceskating.app.ui.state.CartItemUiState) it.next()).getProductPrice() * r7.getQuantity();
        }
        return productPrice;
    }
}
