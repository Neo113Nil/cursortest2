package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: CheckoutViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\u0006\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u000e\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0017J\u000e\u0010*\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0017J\u000e\u0010+\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0017J\u0006\u0010,\u001a\u00020(J\b\u0010-\u001a\u00020\u0013H\u0002J\b\u0010.\u001a\u00020\u0017H\u0002J\u000e\u0010/\u001a\u00020\u0017H\u0082@¢\u0006\u0002\u00100J\u000e\u00101\u001a\u000202H\u0082@¢\u0006\u0002\u00100R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u000e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000f8F¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00130\u000f8F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0011R+\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00178F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR+\u0010\u001f\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00178F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\"\u0010\u001e\u001a\u0004\b \u0010\u001a\"\u0004\b!\u0010\u001cR+\u0010#\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00178F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b&\u0010\u001e\u001a\u0004\b$\u0010\u001a\"\u0004\b%\u0010\u001c¨\u00063"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/CheckoutViewModel;", "Landroidx/lifecycle/ViewModel;", "cartRepository", "Luhggroup/iceskating/app/data/repository/CartRepository;", "productRepository", "Luhggroup/iceskating/app/data/repository/ProductRepository;", "orderRepository", "Luhggroup/iceskating/app/data/repository/OrderRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/CartRepository;Luhggroup/iceskating/app/data/repository/ProductRepository;Luhggroup/iceskating/app/data/repository/OrderRepository;)V", "_orderState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "orderState", "Lkotlinx/coroutines/flow/StateFlow;", "getOrderState", "()Lkotlinx/coroutines/flow/StateFlow;", "_emailInvalidState", "", "emailInvalidState", "getEmailInvalidState", "<set-?>", "", "customerFirstName", "getCustomerFirstName", "()Ljava/lang/String;", "setCustomerFirstName", "(Ljava/lang/String;)V", "customerFirstName$delegate", "Landroidx/compose/runtime/MutableState;", "customerLastName", "getCustomerLastName", "setCustomerLastName", "customerLastName$delegate", "customerEmail", "getCustomerEmail", "setCustomerEmail", "customerEmail$delegate", "updateCustomerFirstName", "", "input", "updateCustomerLastName", "updateCustomerEmail", "placeOrder", "isEmailValid", "generateOrderNumber", "formOrderDescription", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "calculateOrderPrice", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class CheckoutViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _emailInvalidState;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.entity.OrderEntity>> _orderState;
    private final uhggroup.iceskating.app.data.repository.CartRepository cartRepository;

    /* renamed from: customerEmail$delegate, reason: from kotlin metadata */
    private final androidx.compose.runtime.MutableState customerEmail;

    /* renamed from: customerFirstName$delegate, reason: from kotlin metadata */
    private final androidx.compose.runtime.MutableState customerFirstName;

    /* renamed from: customerLastName$delegate, reason: from kotlin metadata */
    private final androidx.compose.runtime.MutableState customerLastName;
    private final uhggroup.iceskating.app.data.repository.OrderRepository orderRepository;
    private final uhggroup.iceskating.app.data.repository.ProductRepository productRepository;

    /* compiled from: CheckoutViewModel.kt */
    @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel", f = "CheckoutViewModel.kt", i = {}, l = {101}, m = "calculateOrderPrice", n = {}, nl = {androidx.core.location.LocationRequestCompat.QUALITY_BALANCED_POWER_ACCURACY}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel$calculateOrderPrice$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        int label;
        /* synthetic */ java.lang.Object result;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.calculateOrderPrice(this);
        }
    }

    /* compiled from: CheckoutViewModel.kt */
    @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel", f = "CheckoutViewModel.kt", i = {}, l = {94}, m = "formOrderDescription", n = {}, nl = {-1}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel$formOrderDescription$1, reason: invalid class name and case insensitive filesystem */
    static final class C05411 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        int label;
        /* synthetic */ java.lang.Object result;

        C05411(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05411> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.formOrderDescription(this);
        }
    }

    public CheckoutViewModel(uhggroup.iceskating.app.data.repository.CartRepository cartRepository, uhggroup.iceskating.app.data.repository.ProductRepository productRepository, uhggroup.iceskating.app.data.repository.OrderRepository orderRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartRepository, "cartRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productRepository, "productRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(orderRepository, "orderRepository");
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
        this._orderState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Empty.INSTANCE);
        this._emailInvalidState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(false);
        this.customerFirstName = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
        this.customerLastName = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
        this.customerEmail = androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.entity.OrderEntity>> getOrderState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._orderState);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> getEmailInvalidState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._emailInvalidState);
    }

    private final void setCustomerFirstName(java.lang.String str) {
        this.customerFirstName.setValue(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final java.lang.String getCustomerFirstName() {
        return (java.lang.String) this.customerFirstName.getValue();
    }

    private final void setCustomerLastName(java.lang.String str) {
        this.customerLastName.setValue(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final java.lang.String getCustomerLastName() {
        return (java.lang.String) this.customerLastName.getValue();
    }

    private final void setCustomerEmail(java.lang.String str) {
        this.customerEmail.setValue(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final java.lang.String getCustomerEmail() {
        return (java.lang.String) this.customerEmail.getValue();
    }

    public final void updateCustomerFirstName(java.lang.String input) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(input, "input");
        setCustomerFirstName(input);
    }

    public final void updateCustomerLastName(java.lang.String input) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(input, "input");
        setCustomerLastName(input);
    }

    public final void updateCustomerEmail(java.lang.String input) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(input, "input");
        setCustomerEmail(input);
        if (this._emailInvalidState.getValue().booleanValue()) {
            this._emailInvalidState.setValue(false);
        }
    }

    /* compiled from: CheckoutViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel$placeOrder$1", f = "CheckoutViewModel.kt", i = {2, 3}, l = {65, 69, 73, 74}, m = "invokeSuspend", n = {"order", "order"}, nl = {66, 70, 74, 75}, s = {"L$0", "L$0"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel$placeOrder$1, reason: invalid class name and case insensitive filesystem */
    static final class C05421 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        java.lang.Object L$0;
        java.lang.Object L$1;
        java.lang.Object L$2;
        java.lang.Object L$3;
        java.lang.Object L$4;
        int label;

        C05421(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05421> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.new C05421(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05421) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:33:0x0113, code lost:
        
            if (r13.this$0.cartRepository.deleteAll(r13) != r0) goto L35;
         */
        /* JADX WARN: Removed duplicated region for block: B:31:0x0101  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object value;
            java.lang.Object value2;
            java.lang.String str;
            java.lang.String str2;
            java.lang.String customerEmail;
            java.lang.String str3;
            java.lang.String str4;
            java.lang.String str5;
            uhggroup.iceskating.app.data.entity.OrderEntity orderEntity;
            uhggroup.iceskating.app.data.entity.OrderEntity orderEntity2;
            java.lang.Object value3;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                if (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.isEmailValid()) {
                    kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this._emailInvalidState;
                    do {
                        value2 = mutableStateFlow.getValue();
                        ((java.lang.Boolean) value2).booleanValue();
                    } while (!mutableStateFlow.compareAndSet(value2, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(false)));
                    java.lang.String strGenerateOrderNumber = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.generateOrderNumber();
                    this.L$0 = strGenerateOrderNumber;
                    this.label = 1;
                    java.lang.Object objFormOrderDescription = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.formOrderDescription(this);
                    if (objFormOrderDescription != coroutine_suspended) {
                        str = strGenerateOrderNumber;
                        obj = objFormOrderDescription;
                    }
                    return coroutine_suspended;
                }
                kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow2 = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this._emailInvalidState;
                do {
                    value = mutableStateFlow2.getValue();
                    ((java.lang.Boolean) value).booleanValue();
                } while (!mutableStateFlow2.compareAndSet(value, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(true)));
                return kotlin.Unit.INSTANCE;
            }
            if (i == 1) {
                java.lang.String str6 = (java.lang.String) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                str = str6;
            } else {
                if (i == 2) {
                    customerEmail = (java.lang.String) this.L$4;
                    java.lang.String str7 = (java.lang.String) this.L$3;
                    java.lang.String str8 = (java.lang.String) this.L$2;
                    str2 = (java.lang.String) this.L$1;
                    java.lang.String str9 = (java.lang.String) this.L$0;
                    kotlin.ResultKt.throwOnFailure(obj);
                    str3 = str8;
                    str4 = str9;
                    str5 = str7;
                    java.lang.String str10 = customerEmail;
                    double dDoubleValue = ((java.lang.Number) obj).doubleValue();
                    java.time.LocalDateTime localDateTimeTruncatedTo = java.time.LocalDateTime.now().truncatedTo(java.time.temporal.ChronoUnit.MINUTES);
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(localDateTimeTruncatedTo, "truncatedTo(...)");
                    orderEntity = new uhggroup.iceskating.app.data.entity.OrderEntity(str4, str2, str3, str5, str10, dDoubleValue, localDateTimeTruncatedTo);
                    this.L$0 = orderEntity;
                    this.L$1 = null;
                    this.L$2 = null;
                    this.L$3 = null;
                    this.L$4 = null;
                    this.label = 3;
                    if (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.orderRepository.save(orderEntity, this) != coroutine_suspended) {
                        orderEntity2 = orderEntity;
                        this.L$0 = orderEntity2;
                        this.label = 4;
                    }
                    return coroutine_suspended;
                }
                if (i != 3) {
                    if (i != 4) {
                        throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    uhggroup.iceskating.app.data.entity.OrderEntity orderEntity3 = (uhggroup.iceskating.app.data.entity.OrderEntity) this.L$0;
                    kotlin.ResultKt.throwOnFailure(obj);
                    orderEntity2 = orderEntity3;
                    kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow3 = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this._orderState;
                    do {
                        value3 = mutableStateFlow3.getValue();
                    } while (!mutableStateFlow3.compareAndSet(value3, new uhggroup.iceskating.app.ui.state.DataUiState.Populated(orderEntity2)));
                    return kotlin.Unit.INSTANCE;
                }
                orderEntity2 = (uhggroup.iceskating.app.data.entity.OrderEntity) this.L$0;
                kotlin.ResultKt.throwOnFailure(obj);
                this.L$0 = orderEntity2;
                this.label = 4;
            }
            str2 = (java.lang.String) obj;
            java.lang.String customerFirstName = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.getCustomerFirstName();
            java.lang.String customerLastName = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.getCustomerLastName();
            customerEmail = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.getCustomerEmail();
            this.L$0 = str;
            this.L$1 = str2;
            this.L$2 = customerFirstName;
            this.L$3 = customerLastName;
            this.L$4 = customerEmail;
            this.label = 2;
            java.lang.Object objCalculateOrderPrice = uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.calculateOrderPrice(this);
            if (objCalculateOrderPrice != coroutine_suspended) {
                java.lang.String str11 = str;
                str3 = customerFirstName;
                str4 = str11;
                str5 = customerLastName;
                obj = objCalculateOrderPrice;
                java.lang.String str102 = customerEmail;
                double dDoubleValue2 = ((java.lang.Number) obj).doubleValue();
                java.time.LocalDateTime localDateTimeTruncatedTo2 = java.time.LocalDateTime.now().truncatedTo(java.time.temporal.ChronoUnit.MINUTES);
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(localDateTimeTruncatedTo2, "truncatedTo(...)");
                orderEntity = new uhggroup.iceskating.app.data.entity.OrderEntity(str4, str2, str3, str5, str102, dDoubleValue2, localDateTimeTruncatedTo2);
                this.L$0 = orderEntity;
                this.L$1 = null;
                this.L$2 = null;
                this.L$3 = null;
                this.L$4 = null;
                this.label = 3;
                if (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.this.orderRepository.save(orderEntity, this) != coroutine_suspended) {
                }
            }
            return coroutine_suspended;
        }
    }

    public final void placeOrder() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05421(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean isEmailValid() {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(getCustomerEmail()).matches();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final java.lang.String generateOrderNumber() {
        kotlin.ranges.IntRange intRange = new kotlin.ranges.IntRange(1, 8);
        java.util.ArrayList arrayList = new java.util.ArrayList(kotlin.collections.CollectionsKt.collectionSizeOrDefault(intRange, 10));
        java.util.Iterator<java.lang.Integer> it = intRange.iterator();
        while (it.hasNext()) {
            ((kotlin.collections.IntIterator) it).nextInt();
            arrayList.add(java.lang.Character.valueOf(kotlin.text.StringsKt.random("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", kotlin.random.Random.INSTANCE)));
        }
        return kotlin.collections.CollectionsKt.joinToString$default(arrayList, "", null, null, 0, null, null, 62, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object formOrderDescription(kotlin.coroutines.Continuation<? super java.lang.String> continuation) {
        uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05411 c05411;
        if (continuation instanceof uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05411) {
            c05411 = (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05411) continuation;
            if ((c05411.label & Integer.MIN_VALUE) != 0) {
                c05411.label -= Integer.MIN_VALUE;
            } else {
                c05411 = new uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.C05411(continuation);
            }
        }
        java.lang.Object all = c05411.result;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = c05411.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(all);
            uhggroup.iceskating.app.data.repository.CartRepository cartRepository = this.cartRepository;
            c05411.label = 1;
            all = cartRepository.getAll(c05411);
            if (all == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(all);
        }
        return kotlin.collections.CollectionsKt.joinToString$default((java.lang.Iterable) all, ", ", null, null, 0, null, new kotlin.jvm.functions.Function1() { // from class: uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final java.lang.Object invoke(java.lang.Object obj) {
                return uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.formOrderDescription$lambda$0(this.f$0, (uhggroup.iceskating.app.data.entity.CartItemEntity) obj);
            }
        }, 30, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final java.lang.CharSequence formOrderDescription$lambda$0(uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel checkoutViewModel, uhggroup.iceskating.app.data.entity.CartItemEntity cartItem) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartItem, "cartItem");
        uhggroup.iceskating.app.data.model.Product byId = checkoutViewModel.productRepository.getById(cartItem.getId());
        return (byId != null ? byId.getTitle() : null) + " x " + cartItem.getQuantity();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final java.lang.Object calculateOrderPrice(kotlin.coroutines.Continuation<? super java.lang.Double> continuation) {
        uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.AnonymousClass1 anonymousClass1;
        if (continuation instanceof uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.AnonymousClass1) {
            anonymousClass1 = (uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.AnonymousClass1) continuation;
            if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                anonymousClass1.label -= Integer.MIN_VALUE;
            } else {
                anonymousClass1 = new uhggroup.iceskating.app.ui.viewmodel.CheckoutViewModel.AnonymousClass1(continuation);
            }
        }
        java.lang.Object all = anonymousClass1.result;
        java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = anonymousClass1.label;
        if (i == 0) {
            kotlin.ResultKt.throwOnFailure(all);
            uhggroup.iceskating.app.data.repository.CartRepository cartRepository = this.cartRepository;
            anonymousClass1.label = 1;
            all = cartRepository.getAll(anonymousClass1);
            if (all == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            kotlin.ResultKt.throwOnFailure(all);
        }
        java.util.Iterator it = ((java.lang.Iterable) all).iterator();
        double quantity = 0.0d;
        while (it.hasNext()) {
            uhggroup.iceskating.app.data.model.Product byId = this.productRepository.getById(((uhggroup.iceskating.app.data.entity.CartItemEntity) it.next()).getId());
            quantity += r4.getQuantity() * (byId != null ? byId.getPrice() : 0.0d);
        }
        return kotlin.coroutines.jvm.internal.Boxing.boxDouble(quantity);
    }
}
