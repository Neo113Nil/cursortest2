package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: ProductDetailsViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013J\u0006\u0010\u0014\u001a\u00020\u0011R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\r8F¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0015"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/ProductDetailsViewModel;", "Landroidx/lifecycle/ViewModel;", "productRepository", "Luhggroup/iceskating/app/data/repository/ProductRepository;", "cartRepository", "Luhggroup/iceskating/app/data/repository/CartRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/ProductRepository;Luhggroup/iceskating/app/data/repository/CartRepository;)V", "_productDetailState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "Luhggroup/iceskating/app/data/model/Product;", "productDetailsState", "Lkotlinx/coroutines/flow/StateFlow;", "getProductDetailsState", "()Lkotlinx/coroutines/flow/StateFlow;", "observeProductDetails", "", "productId", "", "addProductToCart", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductDetailsViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product>> _productDetailState;
    private final uhggroup.iceskating.app.data.repository.CartRepository cartRepository;
    private final uhggroup.iceskating.app.data.repository.ProductRepository productRepository;

    public ProductDetailsViewModel(uhggroup.iceskating.app.data.repository.ProductRepository productRepository, uhggroup.iceskating.app.data.repository.CartRepository cartRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productRepository, "productRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartRepository, "cartRepository");
        this.productRepository = productRepository;
        this.cartRepository = cartRepository;
        this._productDetailState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE);
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<uhggroup.iceskating.app.data.model.Product>> getProductDetailsState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._productDetailState);
    }

    /* compiled from: ProductDetailsViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel$observeProductDetails$1", f = "ProductDetailsViewModel.kt", i = {}, l = {26}, m = "invokeSuspend", n = {}, nl = {31}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel$observeProductDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C05431 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $productId;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05431(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.C05431> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this.new C05431(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.C05431) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.flow.Flow<uhggroup.iceskating.app.data.model.Product> flowObserveById = uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this.productRepository.observeById(this.$productId);
                final uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel productDetailsViewModel = uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this;
                this.label = 1;
                if (flowObserveById.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.observeProductDetails.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        return emit((uhggroup.iceskating.app.data.model.Product) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                    }

                    /* JADX WARN: Multi-variable type inference failed */
                    public final java.lang.Object emit(uhggroup.iceskating.app.data.model.Product product, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                        java.lang.Object value;
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = productDetailsViewModel._productDetailState;
                        do {
                            value = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.compareAndSet(value, uhggroup.iceskating.app.ui.state.DataUiState.INSTANCE.from((uhggroup.iceskating.app.ui.state.DataUiState.Companion) product)));
                        return kotlin.Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void observeProductDetails(int productId) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.C05431(productId, null), 3, null);
    }

    /* compiled from: ProductDetailsViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel$addProductToCart$1", f = "ProductDetailsViewModel.kt", i = {0}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_7}, m = "invokeSuspend", n = {"state"}, nl = {40}, s = {"L$0"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel$addProductToCart$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        java.lang.Object L$0;
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                uhggroup.iceskating.app.ui.state.DataUiState dataUiState = (uhggroup.iceskating.app.ui.state.DataUiState) uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this._productDetailState.getValue();
                if (dataUiState instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated) {
                    this.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(dataUiState);
                    this.label = 1;
                    if (uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.this.cartRepository.incrementProductQuantityOrAdd((uhggroup.iceskating.app.data.model.Product) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData(), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void addProductToCart() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.ProductDetailsViewModel.AnonymousClass1(null), 3, null);
    }
}
