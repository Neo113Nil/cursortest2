package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: OnboardingViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\n8F¢\u0006\u0006\u001a\u0004\b\u000b\u0010\f¨\u0006\u000f"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/OnboardingViewModel;", "Landroidx/lifecycle/ViewModel;", "onboardingRepository", "Luhggroup/iceskating/app/data/repository/OnboardingRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/OnboardingRepository;)V", "_onboardingSetState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "onboardingSetState", "Lkotlinx/coroutines/flow/StateFlow;", "getOnboardingSetState", "()Lkotlinx/coroutines/flow/StateFlow;", "setOnboarded", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OnboardingViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Boolean> _onboardingSetState;
    private final uhggroup.iceskating.app.data.repository.OnboardingRepository onboardingRepository;

    public OnboardingViewModel(uhggroup.iceskating.app.data.repository.OnboardingRepository onboardingRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onboardingRepository, "onboardingRepository");
        this.onboardingRepository = onboardingRepository;
        this._onboardingSetState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(false);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> getOnboardingSetState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._onboardingSetState);
    }

    /* compiled from: OnboardingViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel$setOnboarded$1", f = "OnboardingViewModel.kt", i = {}, l = {21}, m = "invokeSuspend", n = {}, nl = {22}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel$setOnboarded$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object value;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.this.onboardingRepository.setOnboardingState(true, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.this._onboardingSetState;
            do {
                value = mutableStateFlow.getValue();
                ((java.lang.Boolean) value).booleanValue();
            } while (!mutableStateFlow.compareAndSet(value, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(true)));
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void setOnboarded() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.OnboardingViewModel.AnonymousClass1(null), 3, null);
    }
}
