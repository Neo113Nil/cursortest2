package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: OrderViewModel.kt */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u000f\u001a\u00020\u0010H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u0006\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R#\u0010\u000b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b0\f8F¢\u0006\u0006\u001a\u0004\b\r\u0010\u000e¨\u0006\u0011"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/OrderViewModel;", "Landroidx/lifecycle/ViewModel;", "orderRepository", "Luhggroup/iceskating/app/data/repository/OrderRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/OrderRepository;)V", "_ordersState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/data/entity/OrderEntity;", "ordersState", "Lkotlinx/coroutines/flow/StateFlow;", "getOrdersState", "()Lkotlinx/coroutines/flow/StateFlow;", "observeOrders", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class OrderViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>>> _ordersState;
    private final uhggroup.iceskating.app.data.repository.OrderRepository orderRepository;

    public OrderViewModel(uhggroup.iceskating.app.data.repository.OrderRepository orderRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(orderRepository, "orderRepository");
        this.orderRepository = orderRepository;
        this._ordersState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE);
        observeOrders();
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>>> getOrdersState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._ordersState);
    }

    /* compiled from: OrderViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.OrderViewModel$observeOrders$1", f = "OrderViewModel.kt", i = {}, l = {28}, m = "invokeSuspend", n = {}, nl = {31}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.OrderViewModel$observeOrders$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>> flowObserveAll = uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.this.orderRepository.observeAll();
                final uhggroup.iceskating.app.ui.viewmodel.OrderViewModel orderViewModel = uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.this;
                this.label = 1;
                if (flowObserveAll.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.observeOrders.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        return emit((java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity>) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                    }

                    /* JADX WARN: Multi-variable type inference failed */
                    public final java.lang.Object emit(java.util.List<uhggroup.iceskating.app.data.entity.OrderEntity> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                        java.lang.Object value;
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = orderViewModel._ordersState;
                        do {
                            value = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.compareAndSet(value, uhggroup.iceskating.app.ui.state.DataUiState.INSTANCE.from((java.util.List) list)));
                        return kotlin.Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    private final void observeOrders() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.OrderViewModel.AnonymousClass1(null), 3, null);
    }
}
