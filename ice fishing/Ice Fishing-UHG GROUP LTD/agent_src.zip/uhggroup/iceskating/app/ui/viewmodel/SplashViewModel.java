package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: SplashViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/SplashViewModel;", "Landroidx/lifecycle/ViewModel;", "onboardingRepository", "Luhggroup/iceskating/app/data/repository/OnboardingRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/OnboardingRepository;)V", "onboardedState", "Lkotlinx/coroutines/flow/StateFlow;", "", "getOnboardedState", "()Lkotlinx/coroutines/flow/StateFlow;", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class SplashViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> onboardedState;
    private final uhggroup.iceskating.app.data.repository.OnboardingRepository onboardingRepository;

    public SplashViewModel(uhggroup.iceskating.app.data.repository.OnboardingRepository onboardingRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(onboardingRepository, "onboardingRepository");
        this.onboardingRepository = onboardingRepository;
        final kotlinx.coroutines.flow.Flow<java.lang.Boolean> flowObserveOnboardingState = onboardingRepository.observeOnboardingState();
        this.onboardedState = kotlinx.coroutines.flow.FlowKt.stateIn(new kotlinx.coroutines.flow.Flow<java.lang.Boolean>() { // from class: uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1

            /* compiled from: Emitters.kt */
            @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
            /* renamed from: uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1$2, reason: invalid class name */
            public static final class AnonymousClass2<T> implements kotlinx.coroutines.flow.FlowCollector {
                final /* synthetic */ kotlinx.coroutines.flow.FlowCollector $this_unsafeFlow;

                @kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
                @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1$2", f = "SplashViewModel.kt", i = {0, 0, 0, 0, 0}, l = {50}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1"}, nl = {49}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 2)
                /* renamed from: uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1$2$1, reason: invalid class name */
                public static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
                    int I$0;
                    java.lang.Object L$0;
                    java.lang.Object L$1;
                    java.lang.Object L$2;
                    java.lang.Object L$3;
                    int label;
                    /* synthetic */ java.lang.Object result;

                    public AnonymousClass1(kotlin.coroutines.Continuation continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final java.lang.Object invokeSuspend(java.lang.Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2.this.emit(null, this);
                    }
                }

                public AnonymousClass2(kotlinx.coroutines.flow.FlowCollector flowCollector) {
                    this.$this_unsafeFlow = flowCollector;
                }

                /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
                @Override // kotlinx.coroutines.flow.FlowCollector
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final java.lang.Object emit(java.lang.Object obj, kotlin.coroutines.Continuation continuation) {
                    uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2.AnonymousClass1 anonymousClass1;
                    if (continuation instanceof uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) {
                        anonymousClass1 = (uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2.AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2.AnonymousClass1(continuation);
                        }
                    }
                    java.lang.Object obj2 = anonymousClass1.result;
                    java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = anonymousClass1.label;
                    if (i == 0) {
                        kotlin.ResultKt.throwOnFailure(obj2);
                        kotlinx.coroutines.flow.FlowCollector flowCollector = this.$this_unsafeFlow;
                        java.lang.Boolean boolBoxBoolean = kotlin.coroutines.jvm.internal.Boxing.boxBoolean(kotlin.jvm.internal.Intrinsics.areEqual((java.lang.Boolean) obj, kotlin.coroutines.jvm.internal.Boxing.boxBoolean(true)));
                        anonymousClass1.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(obj);
                        anonymousClass1.L$1 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(anonymousClass1);
                        anonymousClass1.L$2 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(obj);
                        anonymousClass1.L$3 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(flowCollector);
                        anonymousClass1.I$0 = 0;
                        anonymousClass1.label = 1;
                        if (flowCollector.emit(boolBoxBoolean, anonymousClass1) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else {
                        if (i != 1) {
                            throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        int i2 = anonymousClass1.I$0;
                        java.lang.Object obj3 = anonymousClass1.L$2;
                        java.lang.Object obj4 = anonymousClass1.L$0;
                        kotlin.ResultKt.throwOnFailure(obj2);
                    }
                    return kotlin.Unit.INSTANCE;
                }
            }

            @Override // kotlinx.coroutines.flow.Flow
            public java.lang.Object collect(kotlinx.coroutines.flow.FlowCollector<? super java.lang.Boolean> flowCollector, kotlin.coroutines.Continuation continuation) {
                java.lang.Object objCollect = flowObserveOnboardingState.collect(new uhggroup.iceskating.app.ui.viewmodel.SplashViewModel$special$$inlined$map$1.AnonymousClass2(flowCollector), continuation);
                return objCollect == kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : kotlin.Unit.INSTANCE;
            }
        }, androidx.lifecycle.ViewModelKt.getViewModelScope(this), kotlinx.coroutines.flow.SharingStarted.INSTANCE.getEagerly(), null);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Boolean> getOnboardedState() {
        return this.onboardedState;
    }
}
