package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: AppViewModel.kt */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0012\u001a\u00020\tH\u0002J\u0006\u0010\u0013\u001a\u00020\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u000b8F¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000b8F¢\u0006\u0006\u001a\u0004\b\u0011\u0010\r¨\u0006\u0014"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/AppViewModel;", "Landroidx/lifecycle/ViewModel;", "cartRepository", "Luhggroup/iceskating/app/data/repository/CartRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/CartRepository;)V", "_cartPopulatedState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "cartPopulatedState", "Lkotlinx/coroutines/flow/StateFlow;", "getCartPopulatedState", "()Lkotlinx/coroutines/flow/StateFlow;", "_itemsInCartState", "", "itemsInCartState", "getItemsInCartState", "observeCart", "clearCart", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class AppViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<kotlin.Unit>> _cartPopulatedState;
    private final kotlinx.coroutines.flow.MutableStateFlow<java.lang.Integer> _itemsInCartState;
    private final uhggroup.iceskating.app.data.repository.CartRepository cartRepository;

    public AppViewModel(uhggroup.iceskating.app.data.repository.CartRepository cartRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartRepository, "cartRepository");
        this.cartRepository = cartRepository;
        this._cartPopulatedState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE);
        this._itemsInCartState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(0);
        observeCart();
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<kotlin.Unit>> getCartPopulatedState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._cartPopulatedState);
    }

    public final kotlinx.coroutines.flow.StateFlow<java.lang.Integer> getItemsInCartState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._itemsInCartState);
    }

    /* compiled from: AppViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.AppViewModel$observeCart$1", f = "AppViewModel.kt", i = {}, l = {31}, m = "invokeSuspend", n = {}, nl = {41}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.AppViewModel$observeCart$1, reason: invalid class name and case insensitive filesystem */
    static final class C05371 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C05371(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.AppViewModel.C05371> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.AppViewModel.this.new C05371(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.AppViewModel.C05371) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>> flowObserveAll = uhggroup.iceskating.app.ui.viewmodel.AppViewModel.this.cartRepository.observeAll();
                final uhggroup.iceskating.app.ui.viewmodel.AppViewModel appViewModel = uhggroup.iceskating.app.ui.viewmodel.AppViewModel.this;
                this.label = 1;
                if (flowObserveAll.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: uhggroup.iceskating.app.ui.viewmodel.AppViewModel.observeCart.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        return emit((java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity>) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                    }

                    /* JADX WARN: Multi-variable type inference failed */
                    public final java.lang.Object emit(java.util.List<uhggroup.iceskating.app.data.entity.CartItemEntity> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                        java.lang.Object value;
                        java.lang.Object obj2;
                        java.lang.Object value2;
                        int quantity;
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = appViewModel._cartPopulatedState;
                        do {
                            value = mutableStateFlow.getValue();
                            if (!list.isEmpty()) {
                                obj2 = (uhggroup.iceskating.app.ui.state.DataUiState) new uhggroup.iceskating.app.ui.state.DataUiState.Populated(kotlin.Unit.INSTANCE);
                            } else {
                                obj2 = (uhggroup.iceskating.app.ui.state.DataUiState) uhggroup.iceskating.app.ui.state.DataUiState.Empty.INSTANCE;
                            }
                        } while (!mutableStateFlow.compareAndSet(value, obj2));
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow2 = appViewModel._itemsInCartState;
                        do {
                            value2 = mutableStateFlow2.getValue();
                            ((java.lang.Number) value2).intValue();
                            java.util.Iterator<T> it = list.iterator();
                            quantity = 0;
                            while (it.hasNext()) {
                                quantity += ((uhggroup.iceskating.app.data.entity.CartItemEntity) it.next()).getQuantity();
                            }
                        } while (!mutableStateFlow2.compareAndSet(value2, kotlin.coroutines.jvm.internal.Boxing.boxInt(quantity)));
                        return kotlin.Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    private final void observeCart() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.AppViewModel.C05371(null), 3, null);
    }

    /* compiled from: AppViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.AppViewModel$clearCart$1", f = "AppViewModel.kt", i = {}, l = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_15}, m = "invokeSuspend", n = {}, nl = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_16}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.AppViewModel$clearCart$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        AnonymousClass1(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.AppViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.AppViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.AppViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                this.label = 1;
                if (uhggroup.iceskating.app.ui.viewmodel.AppViewModel.this.cartRepository.deleteAll(this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void clearCart() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.AppViewModel.AnonymousClass1(null), 3, null);
    }
}
