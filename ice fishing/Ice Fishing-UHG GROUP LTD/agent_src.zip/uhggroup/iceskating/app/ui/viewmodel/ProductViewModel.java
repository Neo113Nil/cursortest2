package uhggroup.iceskating.app.ui.viewmodel;

/* compiled from: ProductViewModel.kt */
@kotlin.Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\b\u0010\u0011\u001a\u00020\u0012H\u0002J\u000e\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0015R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R#\u0010\r\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\n0\u000e8F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010¨\u0006\u0016"}, d2 = {"Luhggroup/iceskating/app/ui/viewmodel/ProductViewModel;", "Landroidx/lifecycle/ViewModel;", "productRepository", "Luhggroup/iceskating/app/data/repository/ProductRepository;", "cartRepository", "Luhggroup/iceskating/app/data/repository/CartRepository;", "<init>", "(Luhggroup/iceskating/app/data/repository/ProductRepository;Luhggroup/iceskating/app/data/repository/CartRepository;)V", "_productsState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Luhggroup/iceskating/app/ui/state/DataUiState;", "", "Luhggroup/iceskating/app/data/model/Product;", "productsState", "Lkotlinx/coroutines/flow/StateFlow;", "getProductsState", "()Lkotlinx/coroutines/flow/StateFlow;", "observeProducts", "", "addToCart", "productId", "", "app_release"}, k = 1, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ProductViewModel extends androidx.lifecycle.ViewModel {
    public static final int $stable = 8;
    private final kotlinx.coroutines.flow.MutableStateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.model.Product>>> _productsState;
    private final uhggroup.iceskating.app.data.repository.CartRepository cartRepository;
    private final uhggroup.iceskating.app.data.repository.ProductRepository productRepository;

    public ProductViewModel(uhggroup.iceskating.app.data.repository.ProductRepository productRepository, uhggroup.iceskating.app.data.repository.CartRepository cartRepository) {
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(productRepository, "productRepository");
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(cartRepository, "cartRepository");
        this.productRepository = productRepository;
        this.cartRepository = cartRepository;
        this._productsState = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(uhggroup.iceskating.app.ui.state.DataUiState.Initial.INSTANCE);
        observeProducts();
    }

    public final kotlinx.coroutines.flow.StateFlow<uhggroup.iceskating.app.ui.state.DataUiState<java.util.List<uhggroup.iceskating.app.data.model.Product>>> getProductsState() {
        return kotlinx.coroutines.flow.FlowKt.asStateFlow(this._productsState);
    }

    /* compiled from: ProductViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.ProductViewModel$observeProducts$1", f = "ProductViewModel.kt", i = {}, l = {29}, m = "invokeSuspend", n = {}, nl = {32}, s = {}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.ProductViewModel$observeProducts$1, reason: invalid class name and case insensitive filesystem */
    static final class C05441 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;

        C05441(kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.C05441> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this.new C05441(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.C05441) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                kotlinx.coroutines.flow.Flow<java.util.List<uhggroup.iceskating.app.data.model.Product>> flowObserveAll = uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this.productRepository.observeAll();
                final uhggroup.iceskating.app.ui.viewmodel.ProductViewModel productViewModel = uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this;
                this.label = 1;
                if (flowObserveAll.collect(new kotlinx.coroutines.flow.FlowCollector() { // from class: uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.observeProducts.1.1
                    @Override // kotlinx.coroutines.flow.FlowCollector
                    public /* bridge */ /* synthetic */ java.lang.Object emit(java.lang.Object obj2, kotlin.coroutines.Continuation continuation) {
                        return emit((java.util.List<uhggroup.iceskating.app.data.model.Product>) obj2, (kotlin.coroutines.Continuation<? super kotlin.Unit>) continuation);
                    }

                    /* JADX WARN: Multi-variable type inference failed */
                    public final java.lang.Object emit(java.util.List<uhggroup.iceskating.app.data.model.Product> list, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
                        java.lang.Object value;
                        kotlinx.coroutines.flow.MutableStateFlow mutableStateFlow = productViewModel._productsState;
                        do {
                            value = mutableStateFlow.getValue();
                        } while (!mutableStateFlow.compareAndSet(value, uhggroup.iceskating.app.ui.state.DataUiState.INSTANCE.from((java.util.List) list)));
                        return kotlin.Unit.INSTANCE;
                    }
                }, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    private final void observeProducts() {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.C05441(null), 3, null);
    }

    /* compiled from: ProductViewModel.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "uhggroup.iceskating.app.ui.viewmodel.ProductViewModel$addToCart$1", f = "ProductViewModel.kt", i = {0, 0}, l = {40}, m = "invokeSuspend", n = {"products", "product"}, nl = {androidx.core.view.MotionEventCompat.AXIS_GENERIC_11}, s = {"L$0", "L$1"}, v = 2)
    /* renamed from: uhggroup.iceskating.app.ui.viewmodel.ProductViewModel$addToCart$1, reason: invalid class name */
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ int $productId;
        java.lang.Object L$0;
        java.lang.Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(int i, kotlin.coroutines.Continuation<? super uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.AnonymousClass1> continuation) {
            super(2, continuation);
            this.$productId = i;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object obj, kotlin.coroutines.Continuation<?> continuation) {
            return uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this.new AnonymousClass1(this.$productId, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope coroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit> continuation) {
            return ((uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(kotlin.Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object obj) {
            java.lang.Object next;
            java.lang.Object coroutine_suspended = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                kotlin.ResultKt.throwOnFailure(obj);
                uhggroup.iceskating.app.ui.state.DataUiState dataUiState = (uhggroup.iceskating.app.ui.state.DataUiState) uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this._productsState.getValue();
                if (dataUiState instanceof uhggroup.iceskating.app.ui.state.DataUiState.Populated) {
                    java.lang.Iterable iterable = (java.lang.Iterable) ((uhggroup.iceskating.app.ui.state.DataUiState.Populated) dataUiState).getData();
                    int i2 = this.$productId;
                    java.util.Iterator it = iterable.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it.next();
                        if (((uhggroup.iceskating.app.data.model.Product) next).getId() == i2) {
                            break;
                        }
                    }
                    uhggroup.iceskating.app.data.model.Product product = (uhggroup.iceskating.app.data.model.Product) next;
                    if (product == null) {
                        return kotlin.Unit.INSTANCE;
                    }
                    this.L$0 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(dataUiState);
                    this.L$1 = kotlin.coroutines.jvm.internal.SpillingKt.nullOutSpilledVariable(product);
                    this.label = 1;
                    if (uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.this.cartRepository.incrementProductQuantityOrAdd(product, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
            } else {
                if (i != 1) {
                    throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                kotlin.ResultKt.throwOnFailure(obj);
            }
            return kotlin.Unit.INSTANCE;
        }
    }

    public final void addToCart(int productId) {
        kotlinx.coroutines.BuildersKt__Builders_commonKt.launch$default(androidx.lifecycle.ViewModelKt.getViewModelScope(this), null, null, new uhggroup.iceskating.app.ui.viewmodel.ProductViewModel.AnonymousClass1(productId, null), 3, null);
    }
}
