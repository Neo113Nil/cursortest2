package uhggroup.iceskating.app;

/* compiled from: MainActivity.kt */
@kotlin.Metadata(k = 3, mv = {2, 3, 0}, xi = androidx.compose.ui.tooling.preview.AndroidUiModes.UI_MODE_NIGHT_MASK)
/* loaded from: classes3.dex */
public final class ComposableSingletons$MainActivityKt {
    public static final uhggroup.iceskating.app.ComposableSingletons$MainActivityKt INSTANCE = new uhggroup.iceskating.app.ComposableSingletons$MainActivityKt();
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$464550496 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(464550496, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ComposableSingletons$MainActivityKt.lambda_464550496$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });
    private static kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> lambda$638942806 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambdaInstance(638942806, false, new kotlin.jvm.functions.Function2() { // from class: uhggroup.iceskating.app.ComposableSingletons$MainActivityKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final java.lang.Object invoke(java.lang.Object obj, java.lang.Object obj2) {
            return uhggroup.iceskating.app.ComposableSingletons$MainActivityKt.lambda_638942806$lambda$0((androidx.compose.runtime.Composer) obj, ((java.lang.Integer) obj2).intValue());
        }
    });

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$464550496$app_release() {
        return lambda$464550496;
    }

    public final kotlin.jvm.functions.Function2<androidx.compose.runtime.Composer, java.lang.Integer, kotlin.Unit> getLambda$638942806$app_release() {
        return lambda$638942806;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_638942806$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C14@504L53:MainActivity.kt#3z4o8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(638942806, i, -1, "uhggroup.iceskating.app.ComposableSingletons$MainActivityKt.lambda$638942806.<anonymous> (MainActivity.kt:14)");
            }
            uhggroup.iceskating.app.ui.theme.ThemeKt.ICSAppTheme(lambda$464550496, composer, 6);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kotlin.Unit lambda_464550496$lambda$0(androidx.compose.runtime.Composer composer, int i) {
        androidx.compose.runtime.ComposerKt.sourceInformation(composer, "C15@534L9:MainActivity.kt#3z4o8u");
        if (!composer.shouldExecute((i & 3) != 2, i & 1)) {
            composer.skipToGroupEnd();
        } else {
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventStart(464550496, i, -1, "uhggroup.iceskating.app.ComposableSingletons$MainActivityKt.lambda$464550496.<anonymous> (MainActivity.kt:15)");
            }
            uhggroup.iceskating.app.ui.composable.approot.AppRootKt.AppRoot(null, composer, 0, 1);
            if (androidx.compose.runtime.ComposerKt.isTraceInProgress()) {
                androidx.compose.runtime.ComposerKt.traceEventEnd();
            }
        }
        return kotlin.Unit.INSTANCE;
    }
}
