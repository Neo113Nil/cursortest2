package com.example.app.common;

import android.app.Application;
import android.content.Context;
import defpackage.mo;

/* compiled from: r8-map-id-161697eccf6b82e6c2fa6c15f7925607c6e8998ae790f71bebfc1da724f9cf39 */
/* loaded from: classes.dex */
public class App extends Application {
    @Override // android.app.Application
    public final void onCreate() {
        super.onCreate();
        Context context = mo.ChPfqV;
        mo.ChPfqV = getApplicationContext();
    }
}
