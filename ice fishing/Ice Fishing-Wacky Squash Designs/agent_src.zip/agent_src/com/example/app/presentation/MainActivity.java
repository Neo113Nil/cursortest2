package com.example.app.presentation;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.example.app.presentation.MainActivity;
import defpackage.aw;
import defpackage.bj0;
import defpackage.d40;
import defpackage.d50;
import defpackage.dk0;
import defpackage.ej;
import defpackage.f40;
import defpackage.hg1;
import defpackage.ir0;
import defpackage.jg;
import defpackage.jw1;
import defpackage.k71;
import defpackage.kw1;
import defpackage.l7;
import defpackage.lw1;
import defpackage.ml;
import defpackage.mw1;
import defpackage.pi0;
import defpackage.pk1;
import defpackage.qi0;
import defpackage.r40;
import defpackage.r7;
import defpackage.ru1;
import defpackage.rv;
import defpackage.s40;
import defpackage.sv;
import defpackage.tk1;
import defpackage.tv;
import defpackage.u51;
import defpackage.ui;
import defpackage.um1;
import defpackage.uo;
import defpackage.uv;
import defpackage.vv;
import defpackage.wv;
import defpackage.xn;
import defpackage.xv;
import defpackage.yi;
import defpackage.yl;
import defpackage.yl0;
import defpackage.yv;
import defpackage.zi;
import defpackage.zj1;
import defpackage.zv;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* compiled from: r8-map-id-161697eccf6b82e6c2fa6c15f7925607c6e8998ae790f71bebfc1da724f9cf39 */
/* loaded from: classes.dex */
public final class MainActivity extends ej {
    public static final /* synthetic */ int QLiWlt = 0;
    public final pk1 J6NaGC;
    public boolean TwJO0c;
    public boolean wfmmkk;
    public final yl0 bZBCQ3 = new yl0(18, new f40(this));
    public final bj0 hQsJgJ = new bj0(this, true);
    public boolean Wk2ocb = true;

    public MainActivity() {
        final int i = 1;
        ((k71) this.pze0kd.dGmwc2).byJMqy("android:support:lifecycle", new yi(this, i));
        final int i2 = 0;
        this.L1Qzbt.add(new ml(this) { // from class: e40
            public final /* synthetic */ MainActivity iycySh;

            {
                this.iycySh = this;
            }

            @Override // defpackage.ml
            public final void accept(Object obj) {
                int i3 = i2;
                MainActivity mainActivity = this.iycySh;
                switch (i3) {
                    case 0:
                        mainActivity.bZBCQ3.bZBCQ3();
                        break;
                    default:
                        mainActivity.bZBCQ3.bZBCQ3();
                        break;
                }
            }
        });
        this.BaVbm7.add(new ml(this) { // from class: e40
            public final /* synthetic */ MainActivity iycySh;

            {
                this.iycySh = this;
            }

            @Override // defpackage.ml
            public final void accept(Object obj) {
                int i3 = i;
                MainActivity mainActivity = this.iycySh;
                switch (i3) {
                    case 0:
                        mainActivity.bZBCQ3.bZBCQ3();
                        break;
                    default:
                        mainActivity.bZBCQ3.bZBCQ3();
                        break;
                }
            }
        });
        zi ziVar = new zi(this, i);
        yl ylVar = this.k3E8iQ;
        ylVar.getClass();
        Context context = ylVar.iycySh;
        if (context != null) {
            ziVar.ChPfqV(context);
        }
        ylVar.ChPfqV.add(ziVar);
        this.J6NaGC = new pk1(new ui(this, 5));
    }

    public static boolean WmzUOa(r40 r40Var) {
        boolean zWmzUOa = false;
        for (d40 d40Var : r40Var.dGmwc2.WY69sH()) {
            if (d40Var != null) {
                f40 f40Var = d40Var.hQsJgJ;
                if ((f40Var == null ? null : f40Var.m4yudp) != null) {
                    zWmzUOa |= WmzUOa(d40Var.oab4uq());
                }
                d50 d50Var = d40Var.IxKGbf;
                qi0 qi0Var = qi0.WmzUOa;
                qi0 qi0Var2 = qi0.pze0kd;
                if (d50Var != null) {
                    d50Var.oab4uq();
                    if (d50Var.pze0kd.WmzUOa.compareTo(qi0Var2) >= 0) {
                        bj0 bj0Var = d40Var.IxKGbf.pze0kd;
                        bj0Var.dGmwc2("setCurrentState");
                        bj0Var.Y9udmh(qi0Var);
                        zWmzUOa = true;
                    }
                }
                if (d40Var.AfkXTK.WmzUOa.compareTo(qi0Var2) >= 0) {
                    bj0 bj0Var2 = d40Var.AfkXTK;
                    bj0Var2.dGmwc2("setCurrentState");
                    bj0Var2.Y9udmh(qi0Var);
                    zWmzUOa = true;
                }
            }
        }
        return zWmzUOa;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0046  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                        return;
                    }
                    break;
                case 100470631:
                    if (str2.equals("--dump-dumpable")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            return;
                        }
                    }
                    break;
                case 472614934:
                    if (str2.equals("--list-dumpables")) {
                    }
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                        return;
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill") && Build.VERSION.SDK_INT >= 26) {
                        return;
                    }
                    break;
            }
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.TwJO0c);
        printWriter.print(" mResumed=");
        printWriter.print(this.wfmmkk);
        printWriter.print(" mStopped=");
        printWriter.print(this.Wk2ocb);
        if (getApplication() != null) {
            ru1 ru1VarGTL3m9 = gTL3m9();
            ru1VarGTL3m9.getClass();
            xn xnVar = xn.iycySh;
            xnVar.getClass();
            uo uoVar = new uo(ru1VarGTL3m9, dk0.dGmwc2, xnVar);
            jg jgVarChPfqV = u51.ChPfqV(dk0.class);
            String strChPfqV = jgVarChPfqV.ChPfqV();
            if (strChPfqV == null) {
                r7.umX4nX("Local and anonymous classes can not be ViewModels");
                return;
            }
            hg1 hg1Var = ((dk0) uoVar.OdYKpl(jgVarChPfqV, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strChPfqV))).iycySh;
            if (hg1Var.WmzUOa > 0) {
                printWriter.print(str3);
                printWriter.println("Loaders:");
                if (hg1Var.WmzUOa > 0) {
                    if (hg1Var.oab4uq(0) != null) {
                        r7.oab4uq();
                        return;
                    }
                    printWriter.print(str3);
                    printWriter.print("  #");
                    printWriter.print(hg1Var.gTL3m9(0));
                    printWriter.print(": ");
                    throw null;
                }
            }
        }
        ((f40) this.bZBCQ3.k3E8iQ).NOUGRS.O5FVBW(str, fileDescriptor, printWriter, strArr);
    }

    @Override // defpackage.ej, android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        this.bZBCQ3.bZBCQ3();
        super.onActivityResult(i, i2, intent);
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x00d6, code lost:
    
        r5.run();
        r1 = getWindow();
        r1.getClass();
        r6.ChPfqV(r1);
        setRequestedOrientation(1);
        setContentView(com.chance.mega.trivoxbaob.R.layout.activity_main);
        r2 = findViewById(com.chance.mega.trivoxbaob.R.id.steamerHost);
        r3 = new defpackage.r7(22);
        r4 = defpackage.cu1.ChPfqV;
        defpackage.xt1.iycySh(r2, r3);
        r2 = defpackage.n7.k3E8iQ;
        r3 = null;
        r4 = r12.J6NaGC;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0103, code lost:
    
        if (r13 != null) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0105, code lost:
    
        r13 = (defpackage.l7) r4.getValue();
        r4 = r13.ChPfqV;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x0111, code lost:
    
        if (r4.Wk2ocb(com.chance.mega.trivoxbaob.R.id.steamerHost) != null) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0113, code lost:
    
        r5 = new defpackage.d9(r4);
        r5.BaVbm7 = true;
        r4 = new defpackage.en0();
        r6 = new android.os.Bundle();
        r6.putInt("menu_from_index", 0);
        r4.O5FVBW(r6);
        r5.Y9udmh(com.chance.mega.trivoxbaob.R.id.steamerHost, r4, null, 2);
        r5.gTL3m9(true);
        r13 = r13.dGmwc2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0134, code lost:
    
        r0 = r13.getValue();
        r1 = (defpackage.ir0) r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x0144, code lost:
    
        if (r13.WmzUOa(r0, new defpackage.ir0(r2, false)) == false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0147, code lost:
    
        r13 = r13.getString("steamer_tab");
        r1 = defpackage.n7.NOUGRS;
        r1.getClass();
        r5 = new defpackage.OdYKpl(0, r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x015b, code lost:
    
        if (r5.hasNext() == false) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x015d, code lost:
    
        r1 = r5.next();
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x016c, code lost:
    
        if (defpackage.zc0.umX4nX(((defpackage.n7) r1).name(), r13) == false) goto L72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x016e, code lost:
    
        r3 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x016f, code lost:
    
        r3 = (defpackage.n7) r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0171, code lost:
    
        if (r3 != null) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0174, code lost:
    
        r2 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x0175, code lost:
    
        r13 = (defpackage.l7) r4.getValue();
        r13.getClass();
        r1 = r13.dGmwc2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x0180, code lost:
    
        r3 = r1.getValue();
        r4 = (defpackage.ir0) r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x018d, code lost:
    
        if (r13.ChPfqV.ryQkYM() <= 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x018f, code lost:
    
        r5 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0191, code lost:
    
        r5 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0192, code lost:
    
        r4.getClass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x019e, code lost:
    
        if (r1.WmzUOa(r3, new defpackage.ir0(r2, r5)) == false) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x01a0, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:?, code lost:
    
        return;
     */
    @Override // defpackage.ej, defpackage.dj, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        pze0kd(bundle);
        Window window = getWindow();
        getWindow().getDecorView();
        int i = Build.VERSION.SDK_INT;
        um1 mw1Var = i >= 35 ? new mw1(window) : i >= 30 ? new lw1(window) : i >= 26 ? new kw1(window) : new jw1(window);
        mw1Var.k3E8iQ(true);
        mw1Var.oab4uq(true);
        int i2 = 2;
        tk1 tk1Var = new tk1(new zj1(i2));
        tk1 tk1Var2 = new tk1(new zj1(i2));
        aw awVar = tv.ChPfqV;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        aw zvVar = tv.ChPfqV;
        if (zvVar == null) {
            int i3 = Build.VERSION.SDK_INT;
            zvVar = i3 >= 35 ? new zv() : i3 >= 30 ? new yv() : i3 >= 29 ? new xv() : i3 >= 28 ? new wv() : i3 >= 26 ? new vv() : new uv();
            tv.ChPfqV = zvVar;
        }
        aw awVar2 = zvVar;
        rv rvVar = new rv(awVar2, tk1Var, tk1Var2, this, decorView);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i4 = 0;
        while (true) {
            if (i4 >= viewGroup.getChildCount()) {
                sv svVar = new sv(rvVar, viewGroup.getContext());
                svVar.setTag(awVar2);
                svVar.setVisibility(8);
                svVar.setWillNotDraw(true);
                viewGroup.addView(svVar);
                break;
            }
            int i5 = i4 + 1;
            View childAt = viewGroup.getChildAt(i4);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            if (childAt.getTag() instanceof aw) {
                break;
            } else {
                i4 = i5;
            }
        }
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((f40) this.bZBCQ3.k3E8iQ).NOUGRS.oab4uq.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        ((f40) this.bZBCQ3.k3E8iQ).NOUGRS.m4yudp();
        this.hQsJgJ.gTL3m9(pi0.ON_DESTROY);
    }

    @Override // defpackage.ej, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 6) {
            return ((f40) this.bZBCQ3.k3E8iQ).NOUGRS.byJMqy();
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.wfmmkk = false;
        s40 s40Var = ((f40) this.bZBCQ3.k3E8iQ).NOUGRS;
        if (s40Var.WmzUOa != null) {
            s40Var.gTL3m9();
        }
        s40Var.iVg7uf(5);
        this.hQsJgJ.gTL3m9(pi0.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        this.hQsJgJ.gTL3m9(pi0.ON_RESUME);
        s40 s40Var = ((f40) this.bZBCQ3.k3E8iQ).NOUGRS;
        s40Var.wJhtRE = false;
        s40Var.zr7uAp = false;
        s40Var.VV7sQL.k3E8iQ = false;
        s40Var.iVg7uf(7);
    }

    @Override // defpackage.ej, android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.bZBCQ3.bZBCQ3();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // android.app.Activity
    public final void onResume() {
        yl0 yl0Var = this.bZBCQ3;
        yl0Var.bZBCQ3();
        super.onResume();
        this.wfmmkk = true;
        ((f40) yl0Var.k3E8iQ).NOUGRS.TwJO0c(true);
    }

    @Override // defpackage.ej, defpackage.dj, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        super.onSaveInstanceState(bundle);
        bundle.putString("steamer_tab", ((ir0) ((l7) this.J6NaGC.getValue()).gTL3m9.oab4uq.getValue()).ChPfqV.name());
    }

    @Override // android.app.Activity
    public final void onStart() {
        yl0 yl0Var = this.bZBCQ3;
        yl0Var.bZBCQ3();
        f40 f40Var = (f40) yl0Var.k3E8iQ;
        super.onStart();
        this.Wk2ocb = false;
        if (!this.TwJO0c) {
            this.TwJO0c = true;
            s40 s40Var = f40Var.NOUGRS;
            s40Var.wJhtRE = false;
            s40Var.zr7uAp = false;
            s40Var.VV7sQL.k3E8iQ = false;
            s40Var.iVg7uf(4);
        }
        f40Var.NOUGRS.TwJO0c(true);
        this.hQsJgJ.gTL3m9(pi0.ON_START);
        s40 s40Var2 = f40Var.NOUGRS;
        s40Var2.wJhtRE = false;
        s40Var2.zr7uAp = false;
        s40Var2.VV7sQL.k3E8iQ = false;
        s40Var2.iVg7uf(5);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.bZBCQ3.bZBCQ3();
    }

    @Override // android.app.Activity
    public final void onStop() {
        yl0 yl0Var;
        super.onStop();
        this.Wk2ocb = true;
        do {
            yl0Var = this.bZBCQ3;
        } while (WmzUOa(((f40) yl0Var.k3E8iQ).NOUGRS));
        s40 s40Var = ((f40) yl0Var.k3E8iQ).NOUGRS;
        s40Var.zr7uAp = true;
        s40Var.VV7sQL.k3E8iQ = true;
        s40Var.iVg7uf(4);
        this.hQsJgJ.gTL3m9(pi0.ON_STOP);
    }

    public final void pze0kd(Bundle bundle) {
        super.onCreate(bundle);
        this.hQsJgJ.gTL3m9(pi0.ON_CREATE);
        s40 s40Var = ((f40) this.bZBCQ3.k3E8iQ).NOUGRS;
        s40Var.wJhtRE = false;
        s40Var.zr7uAp = false;
        s40Var.VV7sQL.k3E8iQ = false;
        s40Var.iVg7uf(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((f40) this.bZBCQ3.k3E8iQ).NOUGRS.oab4uq.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }
}
