package L;

/* loaded from: classes.dex */
public abstract class B {
}
