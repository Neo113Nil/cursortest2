package J0;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p.j;
import u0.l;

/* loaded from: classes.dex */
public abstract class c extends d {
    public static List P(b bVar) {
        Iterator it = bVar.iterator();
        if (!it.hasNext()) {
            return l.f2992e;
        }
        Object next = it.next();
        if (!it.hasNext()) {
            return j.q(next);
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(next);
        while (it.hasNext()) {
            arrayList.add(it.next());
        }
        return arrayList;
    }
}
