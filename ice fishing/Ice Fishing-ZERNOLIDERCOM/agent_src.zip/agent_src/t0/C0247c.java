package t0;

import E0.i;
import java.io.Serializable;

/* renamed from: t0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0247c implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final Throwable f2975e;

    public C0247c(Throwable th) {
        i.e(th, "exception");
        this.f2975e = th;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C0247c) {
            if (i.a(this.f2975e, ((C0247c) obj).f2975e)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f2975e.hashCode();
    }

    public final String toString() {
        return "Failure(" + this.f2975e + ')';
    }
}
