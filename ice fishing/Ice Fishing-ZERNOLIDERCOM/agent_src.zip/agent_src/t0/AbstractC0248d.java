package t0;

import java.io.Serializable;

/* renamed from: t0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0248d implements Serializable {
    public static final Throwable a(Object obj) {
        if (obj instanceof C0247c) {
            return ((C0247c) obj).f2975e;
        }
        return null;
    }
}
