package t0;

import E0.i;
import java.io.Serializable;

/* renamed from: t0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0249e implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public D0.a f2976e;

    /* renamed from: f, reason: collision with root package name */
    public volatile Object f2977f = C0250f.f2979a;

    /* renamed from: g, reason: collision with root package name */
    public final Object f2978g = this;

    public C0249e(D0.a aVar) {
        this.f2976e = aVar;
    }

    public final Object a() {
        Object obj;
        Object obj2 = this.f2977f;
        C0250f c0250f = C0250f.f2979a;
        if (obj2 != c0250f) {
            return obj2;
        }
        synchronized (this.f2978g) {
            obj = this.f2977f;
            if (obj == c0250f) {
                D0.a aVar = this.f2976e;
                i.b(aVar);
                obj = aVar.a();
                this.f2977f = obj;
                this.f2976e = null;
            }
        }
        return obj;
    }

    public final String toString() {
        return this.f2977f != C0250f.f2979a ? String.valueOf(a()) : "Lazy value not initialized yet.";
    }
}
