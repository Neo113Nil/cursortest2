package t0;

import E0.i;
import java.io.Serializable;

/* renamed from: t0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0246b implements Serializable {

    /* renamed from: e, reason: collision with root package name */
    public final Object f2973e;

    /* renamed from: f, reason: collision with root package name */
    public final Object f2974f;

    public C0246b(Object obj, Object obj2) {
        this.f2973e = obj;
        this.f2974f = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0246b)) {
            return false;
        }
        C0246b c0246b = (C0246b) obj;
        return i.a(this.f2973e, c0246b.f2973e) && i.a(this.f2974f, c0246b.f2974f);
    }

    public final int hashCode() {
        Object obj = this.f2973e;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f2974f;
        return hashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        return "(" + this.f2973e + ", " + this.f2974f + ')';
    }
}
