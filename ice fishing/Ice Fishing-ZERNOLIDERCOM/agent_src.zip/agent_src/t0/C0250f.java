package t0;

/* renamed from: t0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0250f {

    /* renamed from: a, reason: collision with root package name */
    public static final C0250f f2979a = new C0250f();
}
