package t0;

/* renamed from: t0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0251g {

    /* renamed from: a, reason: collision with root package name */
    public static final C0251g f2980a = new C0251g();

    public final String toString() {
        return "kotlin.Unit";
    }
}
