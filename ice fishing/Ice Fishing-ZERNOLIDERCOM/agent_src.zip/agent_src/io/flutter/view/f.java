package io.flutter.view;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public int f2521a;

    /* renamed from: b, reason: collision with root package name */
    public int f2522b;

    /* renamed from: c, reason: collision with root package name */
    public int f2523c;

    /* renamed from: d, reason: collision with root package name */
    public String f2524d;

    /* renamed from: e, reason: collision with root package name */
    public String f2525e;
}
