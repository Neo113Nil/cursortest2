package io.flutter.view;

import android.view.View;

/* loaded from: classes.dex */
public final class m {

    /* renamed from: a, reason: collision with root package name */
    public final View f2611a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2612b;

    public m(View view, int i2) {
        this.f2611a = view;
        this.f2612b = i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return this.f2612b == mVar.f2612b && this.f2611a.equals(mVar.f2611a);
    }

    public final int hashCode() {
        return ((this.f2611a.hashCode() + 31) * 31) + this.f2612b;
    }
}
