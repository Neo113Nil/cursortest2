package io.flutter.view;

import android.opengl.Matrix;
import android.os.Build;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import d0.InterfaceC0121k;
import d0.InterfaceC0122l;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class b implements InterfaceC0121k, InterfaceC0122l {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Object f2492a;

    public /* synthetic */ b(Object obj) {
        this.f2492a = obj;
    }

    public void a(ByteBuffer byteBuffer, String[] strArr, ByteBuffer[] byteBufferArr) {
        io.flutter.plugin.platform.h hVar;
        ArrayList arrayList;
        Iterator it;
        g gVar;
        int i2;
        int i3;
        g gVar2;
        String str;
        float f2;
        float f3;
        Integer num;
        h hVar2;
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        for (ByteBuffer byteBuffer2 : byteBufferArr) {
            byteBuffer2.order(ByteOrder.LITTLE_ENDIAN);
        }
        h hVar3 = (h) this.f2492a;
        hVar3.getClass();
        ArrayList arrayList2 = new ArrayList();
        while (true) {
            boolean hasRemaining = byteBuffer.hasRemaining();
            hVar = hVar3.f2583e;
            if (!hasRemaining) {
                break;
            }
            g b2 = hVar3.b(byteBuffer.getInt());
            b2.f2530E = true;
            b2.f2536K = b2.r;
            b2.f2537L = b2.f2568p;
            b2.f2531F = b2.f2554c;
            b2.f2532G = b2.f2556d;
            b2.f2533H = b2.f2559g;
            b2.f2534I = b2.f2560h;
            b2.f2535J = b2.f2564l;
            b2.f2554c = byteBuffer.getLong();
            b2.f2556d = byteBuffer.getInt();
            b2.f2557e = byteBuffer.getInt();
            b2.f2558f = byteBuffer.getInt();
            b2.f2559g = byteBuffer.getInt();
            b2.f2560h = byteBuffer.getInt();
            b2.f2561i = byteBuffer.getInt();
            b2.f2562j = byteBuffer.getInt();
            b2.f2563k = byteBuffer.getInt();
            byteBuffer.getInt();
            b2.f2564l = byteBuffer.getFloat();
            b2.f2565m = byteBuffer.getFloat();
            b2.f2566n = byteBuffer.getFloat();
            b2.f2567o = h.c(byteBuffer, strArr);
            b2.f2568p = h.c(byteBuffer, strArr);
            b2.f2569q = g.D(byteBuffer, byteBufferArr);
            b2.r = h.c(byteBuffer, strArr);
            b2.f2570s = g.D(byteBuffer, byteBufferArr);
            b2.f2571t = h.c(byteBuffer, strArr);
            b2.f2572u = g.D(byteBuffer, byteBufferArr);
            b2.f2573v = h.c(byteBuffer, strArr);
            b2.f2574w = g.D(byteBuffer, byteBufferArr);
            b2.f2575x = h.c(byteBuffer, strArr);
            b2.f2576y = g.D(byteBuffer, byteBufferArr);
            b2.f2577z = h.c(byteBuffer, strArr);
            b2.f2526A = h.c(byteBuffer, strArr);
            b2.f2527B = h.c(byteBuffer, strArr);
            b2.f2528C = byteBuffer.getInt();
            byteBuffer.getInt();
            b2.f2538M = byteBuffer.getFloat();
            b2.f2539N = byteBuffer.getFloat();
            b2.f2540O = byteBuffer.getFloat();
            b2.f2541P = byteBuffer.getFloat();
            float[] fArr = b2.f2542Q;
            if (fArr == null) {
                fArr = new float[16];
            }
            for (int i4 = 0; i4 < 16; i4++) {
                fArr[i4] = byteBuffer.getFloat();
            }
            b2.f2542Q = fArr;
            float[] fArr2 = b2.f2543R;
            if (fArr2 == null) {
                fArr2 = new float[16];
            }
            for (int i5 = 0; i5 < 16; i5++) {
                fArr2[i5] = byteBuffer.getFloat();
            }
            b2.f2543R = fArr2;
            b2.f2549Y = true;
            b2.f2551a0 = true;
            int i6 = byteBuffer.getInt();
            ArrayList arrayList3 = b2.T;
            arrayList3.clear();
            int i7 = 0;
            while (true) {
                hVar2 = b2.f2550a;
                if (i7 >= i6) {
                    break;
                }
                g b3 = hVar2.b(byteBuffer.getInt());
                b3.f2544S = b2;
                arrayList3.add(b3);
                i7++;
            }
            int i8 = byteBuffer.getInt();
            ArrayList arrayList4 = b2.f2545U;
            arrayList4.clear();
            for (int i9 = 0; i9 < i8; i9++) {
                g b4 = hVar2.b(byteBuffer.getInt());
                b4.f2544S = b2;
                arrayList4.add(b4);
            }
            int i10 = byteBuffer.getInt();
            if (i10 == 0) {
                b2.f2546V = null;
            } else {
                ArrayList arrayList5 = b2.f2546V;
                if (arrayList5 == null) {
                    b2.f2546V = new ArrayList(i10);
                } else {
                    arrayList5.clear();
                }
                for (int i11 = 0; i11 < i10; i11++) {
                    f a2 = hVar2.a(byteBuffer.getInt());
                    int i12 = a2.f2523c;
                    if (i12 == 1) {
                        b2.f2547W = a2;
                    } else if (i12 == 2) {
                        b2.f2548X = a2;
                    } else {
                        b2.f2546V.add(a2);
                    }
                    b2.f2546V.add(a2);
                }
            }
            if (!b2.E(14)) {
                if (b2.E(6)) {
                    hVar3.f2591m = b2;
                }
                if (b2.f2530E) {
                    arrayList2.add(b2);
                }
                int i13 = b2.f2561i;
                if (i13 != -1 && !hVar.g(i13)) {
                    hVar.f(b2.f2561i);
                }
            }
        }
        HashSet hashSet = new HashSet();
        HashMap hashMap = hVar3.f2585g;
        g gVar3 = (g) hashMap.get(0);
        ArrayList arrayList6 = new ArrayList();
        if (gVar3 != null) {
            float[] fArr3 = new float[16];
            Matrix.setIdentityM(fArr3, 0);
            gVar3.I(fArr3, hashSet, false);
            gVar3.A(arrayList6);
        }
        Iterator it2 = arrayList6.iterator();
        g gVar4 = null;
        while (true) {
            boolean hasNext = it2.hasNext();
            arrayList = hVar3.f2594p;
            if (!hasNext) {
                break;
            }
            g gVar5 = (g) it2.next();
            if (!arrayList.contains(Integer.valueOf(gVar5.f2552b))) {
                gVar4 = gVar5;
            }
        }
        if (gVar4 == null && !arrayList6.isEmpty()) {
            gVar4 = (g) arrayList6.get(arrayList6.size() - 1);
        }
        if (gVar4 != null && (gVar4.f2552b != hVar3.f2595q || arrayList6.size() != arrayList.size())) {
            hVar3.f2595q = gVar4.f2552b;
            String C2 = gVar4.C();
            if (C2 == null) {
                C2 = " ";
            }
            if (Build.VERSION.SDK_INT >= 28) {
                hVar3.f2579a.setAccessibilityPaneTitle(C2);
            } else {
                AccessibilityEvent d2 = hVar3.d(gVar4.f2552b, 32);
                d2.getText().add(C2);
                hVar3.h(d2);
            }
        }
        arrayList.clear();
        Iterator it3 = arrayList6.iterator();
        while (it3.hasNext()) {
            arrayList.add(Integer.valueOf(((g) it3.next()).f2552b));
        }
        Iterator it4 = hashMap.entrySet().iterator();
        while (it4.hasNext()) {
            g gVar6 = (g) ((Map.Entry) it4.next()).getValue();
            if (!hashSet.contains(gVar6)) {
                gVar6.f2544S = null;
                if (gVar6.f2561i != -1 && (num = hVar3.f2588j) != null) {
                    View platformViewOfNode = hVar3.f2582d.platformViewOfNode(num.intValue());
                    hVar.f(gVar6.f2561i);
                    if (platformViewOfNode == null) {
                        hVar3.g(hVar3.f2588j.intValue(), 65536);
                        hVar3.f2588j = null;
                    }
                }
                int i14 = gVar6.f2561i;
                if (i14 != -1) {
                    hVar.f(i14);
                }
                g gVar7 = hVar3.f2587i;
                if (gVar7 == gVar6) {
                    hVar3.g(gVar7.f2552b, 65536);
                    hVar3.f2587i = null;
                }
                if (hVar3.f2591m == gVar6) {
                    hVar3.f2591m = null;
                }
                if (hVar3.f2593o == gVar6) {
                    hVar3.f2593o = null;
                }
                it4.remove();
            }
        }
        int i15 = 2048;
        AccessibilityEvent d3 = hVar3.d(0, 2048);
        d3.setContentChangeTypes(1);
        hVar3.h(d3);
        Iterator it5 = arrayList2.iterator();
        while (it5.hasNext()) {
            g gVar8 = (g) it5.next();
            if (!Float.isNaN(gVar8.f2564l) && !Float.isNaN(gVar8.f2535J) && gVar8.f2535J != gVar8.f2564l) {
                AccessibilityEvent d4 = hVar3.d(gVar8.f2552b, 4096);
                float f4 = gVar8.f2564l;
                float f5 = gVar8.f2565m;
                if (Float.isInfinite(f5)) {
                    if (f4 > 70000.0f) {
                        f4 = 70000.0f;
                    }
                    f5 = 100000.0f;
                }
                if (Float.isInfinite(gVar8.f2566n)) {
                    f2 = f5 + 100000.0f;
                    if (f4 < -70000.0f) {
                        f4 = -70000.0f;
                    }
                    f3 = f4 + 100000.0f;
                } else {
                    float f6 = gVar8.f2566n;
                    f2 = f5 - f6;
                    f3 = f4 - f6;
                }
                if (g.z(gVar8, e.SCROLL_UP) || g.z(gVar8, e.SCROLL_DOWN)) {
                    d4.setScrollY((int) f3);
                    d4.setMaxScrollY((int) f2);
                } else if (g.z(gVar8, e.SCROLL_LEFT) || g.z(gVar8, e.SCROLL_RIGHT)) {
                    d4.setScrollX((int) f3);
                    d4.setMaxScrollX((int) f2);
                }
                int i16 = gVar8.f2562j;
                if (i16 > 0) {
                    d4.setItemCount(i16);
                    d4.setFromIndex(gVar8.f2563k);
                    Iterator it6 = gVar8.f2545U.iterator();
                    int i17 = 0;
                    while (it6.hasNext()) {
                        if (!((g) it6.next()).E(14)) {
                            i17++;
                        }
                    }
                    d4.setToIndex((gVar8.f2563k + i17) - 1);
                }
                hVar3.h(d4);
            }
            if (gVar8.E(16) && (((str = gVar8.f2568p) != null || gVar8.f2537L != null) && (str == null || !str.equals(gVar8.f2537L)))) {
                AccessibilityEvent d5 = hVar3.d(gVar8.f2552b, i15);
                d5.setContentChangeTypes(1);
                hVar3.h(d5);
            }
            g gVar9 = hVar3.f2587i;
            if (gVar9 == null || gVar9.f2552b != gVar8.f2552b) {
                it = it5;
            } else {
                it = it5;
                if ((E0.h.d(3) & gVar8.f2531F) == 0 && gVar8.E(3)) {
                    AccessibilityEvent d6 = hVar3.d(gVar8.f2552b, 4);
                    d6.getText().add(gVar8.f2568p);
                    hVar3.h(d6);
                }
            }
            g gVar10 = hVar3.f2591m;
            if (gVar10 != null && (i2 = gVar10.f2552b) == (i3 = gVar8.f2552b) && ((gVar2 = hVar3.f2592n) == null || gVar2.f2552b != i2)) {
                hVar3.f2592n = gVar10;
                hVar3.h(hVar3.d(i3, 8));
            } else if (gVar10 == null) {
                hVar3.f2592n = null;
            }
            g gVar11 = hVar3.f2591m;
            if (gVar11 != null && gVar11.f2552b == gVar8.f2552b && (gVar8.f2531F & E0.h.d(5)) != 0 && gVar8.E(5) && ((gVar = hVar3.f2587i) == null || gVar.f2552b == hVar3.f2591m.f2552b)) {
                String str2 = gVar8.f2536K;
                if (str2 == null) {
                    str2 = "";
                }
                String str3 = gVar8.r;
                String str4 = str3 != null ? str3 : "";
                AccessibilityEvent d7 = hVar3.d(gVar8.f2552b, 16);
                d7.setBeforeText(str2);
                d7.getText().add(str4);
                int i18 = 0;
                while (i18 < str2.length() && i18 < str4.length() && str2.charAt(i18) == str4.charAt(i18)) {
                    i18++;
                }
                if (i18 < str2.length() || i18 < str4.length()) {
                    d7.setFromIndex(i18);
                    int length = str2.length() - 1;
                    int length2 = str4.length() - 1;
                    while (length >= i18 && length2 >= i18 && str2.charAt(length) == str4.charAt(length2)) {
                        length--;
                        length2--;
                    }
                    d7.setRemovedCount((length - i18) + 1);
                    d7.setAddedCount((length2 - i18) + 1);
                } else {
                    d7 = null;
                }
                if (d7 != null) {
                    hVar3.h(d7);
                }
                if (gVar8.f2533H != gVar8.f2559g || gVar8.f2534I != gVar8.f2560h) {
                    AccessibilityEvent d8 = hVar3.d(gVar8.f2552b, 8192);
                    d8.getText().add(str4);
                    d8.setFromIndex(gVar8.f2559g);
                    d8.setToIndex(gVar8.f2560h);
                    d8.setItemCount(str4.length());
                    hVar3.h(d8);
                }
            }
            it5 = it;
            i15 = 2048;
        }
    }
}
