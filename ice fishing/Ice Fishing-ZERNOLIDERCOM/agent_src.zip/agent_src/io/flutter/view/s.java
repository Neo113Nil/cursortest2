package io.flutter.view;

import android.hardware.display.DisplayManager;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.Objects;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: e, reason: collision with root package name */
    public static s f2617e;

    /* renamed from: f, reason: collision with root package name */
    public static q f2618f;

    /* renamed from: b, reason: collision with root package name */
    public final FlutterJNI f2620b;

    /* renamed from: a, reason: collision with root package name */
    public long f2619a = -1;

    /* renamed from: c, reason: collision with root package name */
    public r f2621c = new r(this, 0);

    /* renamed from: d, reason: collision with root package name */
    public final b f2622d = new b(this);

    public s(FlutterJNI flutterJNI) {
        this.f2620b = flutterJNI;
    }

    public static s a(DisplayManager displayManager, FlutterJNI flutterJNI) {
        if (f2617e == null) {
            f2617e = new s(flutterJNI);
        }
        if (f2618f == null) {
            s sVar = f2617e;
            Objects.requireNonNull(sVar);
            q qVar = new q(sVar, displayManager);
            f2618f = qVar;
            displayManager.registerDisplayListener(qVar, null);
        }
        if (f2617e.f2619a == -1) {
            float refreshRate = displayManager.getDisplay(0).getRefreshRate();
            f2617e.f2619a = (long) (1.0E9d / refreshRate);
            flutterJNI.setRefreshRateFPS(refreshRate);
        }
        return f2617e;
    }
}
