package io.flutter.view;

/* loaded from: classes.dex */
public abstract class k {

    /* renamed from: a, reason: collision with root package name */
    public int f2602a;

    /* renamed from: b, reason: collision with root package name */
    public int f2603b;

    /* renamed from: c, reason: collision with root package name */
    public int f2604c;
}
