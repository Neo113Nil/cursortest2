package io.flutter.view;

import D.C0013n;
import android.graphics.Rect;
import android.opengl.Matrix;
import android.text.SpannableString;
import android.text.TextUtils;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: A, reason: collision with root package name */
    public String f2526A;

    /* renamed from: B, reason: collision with root package name */
    public String f2527B;

    /* renamed from: C, reason: collision with root package name */
    public int f2528C;

    /* renamed from: F, reason: collision with root package name */
    public long f2531F;

    /* renamed from: G, reason: collision with root package name */
    public int f2532G;

    /* renamed from: H, reason: collision with root package name */
    public int f2533H;

    /* renamed from: I, reason: collision with root package name */
    public int f2534I;

    /* renamed from: J, reason: collision with root package name */
    public float f2535J;

    /* renamed from: K, reason: collision with root package name */
    public String f2536K;

    /* renamed from: L, reason: collision with root package name */
    public String f2537L;

    /* renamed from: M, reason: collision with root package name */
    public float f2538M;

    /* renamed from: N, reason: collision with root package name */
    public float f2539N;

    /* renamed from: O, reason: collision with root package name */
    public float f2540O;

    /* renamed from: P, reason: collision with root package name */
    public float f2541P;

    /* renamed from: Q, reason: collision with root package name */
    public float[] f2542Q;

    /* renamed from: R, reason: collision with root package name */
    public float[] f2543R;

    /* renamed from: S, reason: collision with root package name */
    public g f2544S;

    /* renamed from: V, reason: collision with root package name */
    public ArrayList f2546V;

    /* renamed from: W, reason: collision with root package name */
    public f f2547W;

    /* renamed from: X, reason: collision with root package name */
    public f f2548X;
    public float[] Z;

    /* renamed from: a, reason: collision with root package name */
    public final h f2550a;

    /* renamed from: b0, reason: collision with root package name */
    public float[] f2553b0;

    /* renamed from: c, reason: collision with root package name */
    public long f2554c;

    /* renamed from: c0, reason: collision with root package name */
    public Rect f2555c0;

    /* renamed from: d, reason: collision with root package name */
    public int f2556d;

    /* renamed from: e, reason: collision with root package name */
    public int f2557e;

    /* renamed from: f, reason: collision with root package name */
    public int f2558f;

    /* renamed from: g, reason: collision with root package name */
    public int f2559g;

    /* renamed from: h, reason: collision with root package name */
    public int f2560h;

    /* renamed from: i, reason: collision with root package name */
    public int f2561i;

    /* renamed from: j, reason: collision with root package name */
    public int f2562j;

    /* renamed from: k, reason: collision with root package name */
    public int f2563k;

    /* renamed from: l, reason: collision with root package name */
    public float f2564l;

    /* renamed from: m, reason: collision with root package name */
    public float f2565m;

    /* renamed from: n, reason: collision with root package name */
    public float f2566n;

    /* renamed from: o, reason: collision with root package name */
    public String f2567o;

    /* renamed from: p, reason: collision with root package name */
    public String f2568p;

    /* renamed from: q, reason: collision with root package name */
    public ArrayList f2569q;
    public String r;

    /* renamed from: s, reason: collision with root package name */
    public ArrayList f2570s;

    /* renamed from: t, reason: collision with root package name */
    public String f2571t;

    /* renamed from: u, reason: collision with root package name */
    public ArrayList f2572u;

    /* renamed from: v, reason: collision with root package name */
    public String f2573v;

    /* renamed from: w, reason: collision with root package name */
    public ArrayList f2574w;

    /* renamed from: x, reason: collision with root package name */
    public String f2575x;

    /* renamed from: y, reason: collision with root package name */
    public ArrayList f2576y;

    /* renamed from: z, reason: collision with root package name */
    public String f2577z;

    /* renamed from: b, reason: collision with root package name */
    public int f2552b = -1;

    /* renamed from: D, reason: collision with root package name */
    public int f2529D = -1;

    /* renamed from: E, reason: collision with root package name */
    public boolean f2530E = false;
    public final ArrayList T = new ArrayList();

    /* renamed from: U, reason: collision with root package name */
    public final ArrayList f2545U = new ArrayList();

    /* renamed from: Y, reason: collision with root package name */
    public boolean f2549Y = true;

    /* renamed from: a0, reason: collision with root package name */
    public boolean f2551a0 = true;

    public g(h hVar) {
        this.f2550a = hVar;
    }

    public static ArrayList D(ByteBuffer byteBuffer, ByteBuffer[] byteBufferArr) {
        int i2 = byteBuffer.getInt();
        if (i2 == -1) {
            return null;
        }
        ArrayList arrayList = new ArrayList(i2);
        for (int i3 = 0; i3 < i2; i3++) {
            int i4 = byteBuffer.getInt();
            int i5 = byteBuffer.getInt();
            int i6 = F.j.c(2)[byteBuffer.getInt()];
            int b2 = F.j.b(i6);
            if (b2 == 0) {
                byteBuffer.getInt();
                j jVar = new j();
                jVar.f2602a = i4;
                jVar.f2603b = i5;
                jVar.f2604c = i6;
                arrayList.add(jVar);
            } else if (b2 == 1) {
                ByteBuffer byteBuffer2 = byteBufferArr[byteBuffer.getInt()];
                i iVar = new i();
                iVar.f2602a = i4;
                iVar.f2603b = i5;
                iVar.f2604c = i6;
                iVar.f2601d = StandardCharsets.UTF_8.decode(byteBuffer2).toString();
                arrayList.add(iVar);
            }
        }
        return arrayList;
    }

    public static void H(float[] fArr, float[] fArr2, float[] fArr3) {
        Matrix.multiplyMV(fArr, 0, fArr2, 0, fArr3, 0);
        float f2 = fArr[3];
        fArr[0] = fArr[0] / f2;
        fArr[1] = fArr[1] / f2;
        fArr[2] = fArr[2] / f2;
        fArr[3] = 0.0f;
    }

    public static Rect f(g gVar) {
        return gVar.f2555c0;
    }

    public static boolean k(g gVar, e eVar) {
        return (gVar.f2556d & eVar.f2520e) != 0;
    }

    public static boolean o(g gVar) {
        if (gVar.E(4)) {
            return true;
        }
        String str = gVar.f2526A;
        if (str == null || str.isEmpty()) {
            return gVar.E(23);
        }
        return false;
    }

    public static SpannableString t(g gVar) {
        C0013n c0013n = new C0013n();
        c0013n.f243a = gVar.r;
        c0013n.f244b = gVar.f2570s;
        c0013n.f245c = gVar.B();
        return c0013n.a();
    }

    public static CharSequence u(g gVar) {
        C0013n c0013n = new C0013n();
        c0013n.f243a = gVar.f2568p;
        c0013n.f244b = gVar.f2569q;
        c0013n.f246d = gVar.f2526A;
        c0013n.f245c = gVar.B();
        SpannableString a2 = c0013n.a();
        C0013n c0013n2 = new C0013n();
        c0013n2.f243a = gVar.f2575x;
        c0013n2.f244b = gVar.f2576y;
        c0013n2.f245c = gVar.B();
        CharSequence[] charSequenceArr = {a2, c0013n2.a()};
        CharSequence charSequence = null;
        for (int i2 = 0; i2 < 2; i2++) {
            CharSequence charSequence2 = charSequenceArr[i2];
            if (charSequence2 != null && charSequence2.length() > 0) {
                charSequence = (charSequence == null || charSequence.length() == 0) ? charSequence2 : TextUtils.concat(charSequence, ", ", charSequence2);
            }
        }
        return charSequence;
    }

    public static CharSequence v(g gVar) {
        C0013n c0013n = new C0013n();
        c0013n.f243a = gVar.r;
        c0013n.f244b = gVar.f2570s;
        c0013n.f245c = gVar.B();
        SpannableString a2 = c0013n.a();
        C0013n c0013n2 = new C0013n();
        c0013n2.f243a = gVar.f2568p;
        c0013n2.f244b = gVar.f2569q;
        c0013n2.f246d = gVar.f2526A;
        c0013n2.f245c = gVar.B();
        SpannableString a3 = c0013n2.a();
        C0013n c0013n3 = new C0013n();
        c0013n3.f243a = gVar.f2575x;
        c0013n3.f244b = gVar.f2576y;
        c0013n3.f245c = gVar.B();
        CharSequence[] charSequenceArr = {a2, a3, c0013n3.a()};
        CharSequence charSequence = null;
        for (int i2 = 0; i2 < 3; i2++) {
            CharSequence charSequence2 = charSequenceArr[i2];
            if (charSequence2 != null && charSequence2.length() > 0) {
                charSequence = (charSequence == null || charSequence.length() == 0) ? charSequence2 : TextUtils.concat(charSequence, ", ", charSequence2);
            }
        }
        return charSequence;
    }

    public static boolean z(g gVar, e eVar) {
        return (gVar.f2532G & eVar.f2520e) != 0;
    }

    public final void A(ArrayList arrayList) {
        if (E(12)) {
            arrayList.add(this);
        }
        Iterator it = this.T.iterator();
        while (it.hasNext()) {
            ((g) it.next()).A(arrayList);
        }
    }

    public final String B() {
        String str = this.f2527B;
        return (str == null || str.isEmpty()) ? this.f2550a.f2590l : this.f2527B;
    }

    public final String C() {
        String str;
        if (E(13) && (str = this.f2568p) != null && !str.isEmpty()) {
            return this.f2568p;
        }
        Iterator it = this.T.iterator();
        while (it.hasNext()) {
            String C2 = ((g) it.next()).C();
            if (C2 != null && !C2.isEmpty()) {
                return C2;
            }
        }
        return null;
    }

    public final boolean E(int i2) {
        return (this.f2554c & ((long) E0.h.d(i2))) != 0;
    }

    public final g F(float[] fArr, boolean z2) {
        float f2 = fArr[3];
        boolean z3 = false;
        float f3 = fArr[0] / f2;
        float f4 = fArr[1] / f2;
        if (f3 < this.f2538M || f3 >= this.f2540O || f4 < this.f2539N || f4 >= this.f2541P) {
            return null;
        }
        float[] fArr2 = new float[4];
        Iterator it = this.f2545U.iterator();
        while (it.hasNext()) {
            g gVar = (g) it.next();
            if (!gVar.E(14)) {
                if (gVar.f2549Y) {
                    gVar.f2549Y = false;
                    if (gVar.Z == null) {
                        gVar.Z = new float[16];
                    }
                    if (!Matrix.invertM(gVar.Z, 0, gVar.f2543R, 0)) {
                        Arrays.fill(gVar.Z, 0.0f);
                    }
                }
                Matrix.multiplyMV(fArr2, 0, gVar.Z, 0, fArr, 0);
                g F2 = gVar.F(fArr2, z2);
                if (F2 != null) {
                    return F2;
                }
            }
        }
        if (z2 && this.f2561i != -1) {
            z3 = true;
        }
        if (G() || z3) {
            return this;
        }
        return null;
    }

    public final boolean G() {
        String str;
        String str2;
        String str3;
        if (E(12)) {
            return false;
        }
        if (E(22)) {
            return true;
        }
        if (E(32)) {
            return false;
        }
        int i2 = this.f2556d;
        int i3 = h.f2578x;
        return ((i2 & (-61)) == 0 && (this.f2554c & ((long) 10682871)) == 0 && ((str = this.f2568p) == null || str.isEmpty()) && (((str2 = this.r) == null || str2.isEmpty()) && ((str3 = this.f2575x) == null || str3.isEmpty()))) ? false : true;
    }

    public final void I(float[] fArr, HashSet hashSet, boolean z2) {
        hashSet.add(this);
        if (this.f2551a0) {
            z2 = true;
        }
        if (z2) {
            if (this.f2553b0 == null) {
                this.f2553b0 = new float[16];
            }
            if (this.f2542Q == null) {
                this.f2542Q = new float[16];
            }
            Matrix.multiplyMM(this.f2553b0, 0, fArr, 0, this.f2542Q, 0);
            float[] fArr2 = {this.f2538M, this.f2539N, 0.0f, 1.0f};
            float[] fArr3 = new float[4];
            float[] fArr4 = new float[4];
            float[] fArr5 = new float[4];
            float[] fArr6 = new float[4];
            H(fArr3, this.f2553b0, fArr2);
            fArr2[0] = this.f2540O;
            fArr2[1] = this.f2539N;
            H(fArr4, this.f2553b0, fArr2);
            fArr2[0] = this.f2540O;
            fArr2[1] = this.f2541P;
            H(fArr5, this.f2553b0, fArr2);
            fArr2[0] = this.f2538M;
            fArr2[1] = this.f2541P;
            H(fArr6, this.f2553b0, fArr2);
            if (this.f2555c0 == null) {
                this.f2555c0 = new Rect();
            }
            this.f2555c0.set(Math.round(Math.min(fArr3[0], Math.min(fArr4[0], Math.min(fArr5[0], fArr6[0])))), Math.round(Math.min(fArr3[1], Math.min(fArr4[1], Math.min(fArr5[1], fArr6[1])))), Math.round(Math.max(fArr3[0], Math.max(fArr4[0], Math.max(fArr5[0], fArr6[0])))), Math.round(Math.max(fArr3[1], Math.max(fArr4[1], Math.max(fArr5[1], fArr6[1])))));
            this.f2551a0 = false;
        }
        Iterator it = this.T.iterator();
        int i2 = -1;
        while (it.hasNext()) {
            g gVar = (g) it.next();
            gVar.f2529D = i2;
            i2 = gVar.f2552b;
            gVar.I(this.f2553b0, hashSet, z2);
        }
    }
}
