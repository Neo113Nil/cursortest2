package io.flutter.plugin.editing;

import D.C0013n;
import L.C0038n;
import android.graphics.Rect;
import c0.r;
import l0.C0211o;
import l0.C0213q;

/* loaded from: classes.dex */
public final class j implements a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ l f2418a;

    public /* synthetic */ j(l lVar) {
        this.f2418a = lVar;
    }

    public void a(int i2, C0211o c0211o) {
        l lVar = this.f2418a;
        lVar.c();
        lVar.f2427f = c0211o;
        lVar.f2426e = new C0038n(2, i2);
        lVar.f2429h.e(lVar);
        C0013n c0013n = c0211o.f2744j;
        lVar.f2429h = new f(c0013n != null ? (C0213q) c0013n.f245c : null, lVar.f2422a);
        lVar.d(c0211o);
        lVar.f2430i = true;
        if (lVar.f2426e.f582b == 3) {
            lVar.f2437p = false;
        }
        lVar.f2434m = null;
        lVar.f2429h.a(lVar);
    }

    public void b(double d2, double d3, double[] dArr) {
        l lVar = this.f2418a;
        lVar.getClass();
        double[] dArr2 = new double[4];
        boolean z2 = dArr[3] == 0.0d && dArr[7] == 0.0d && dArr[15] == 1.0d;
        double d4 = dArr[12];
        double d5 = dArr[15];
        double d6 = d4 / d5;
        dArr2[1] = d6;
        dArr2[0] = d6;
        double d7 = dArr[13] / d5;
        dArr2[3] = d7;
        dArr2[2] = d7;
        k kVar = new k(z2, dArr, dArr2);
        kVar.a(d2, 0.0d);
        kVar.a(d2, d3);
        kVar.a(0.0d, d3);
        double d8 = lVar.f2422a.getContext().getResources().getDisplayMetrics().density;
        lVar.f2434m = new Rect((int) (dArr2[0] * d8), (int) (dArr2[2] * d8), (int) Math.ceil(dArr2[1] * d8), (int) Math.ceil(dArr2[3] * d8));
    }

    public void c(C0213q c0213q) {
        C0213q c0213q2;
        int i2;
        int i3;
        l lVar = this.f2418a;
        r rVar = lVar.f2422a;
        if (!lVar.f2430i && (c0213q2 = lVar.f2436o) != null && (i2 = c0213q2.f2754d) >= 0 && (i3 = c0213q2.f2755e) > i2) {
            int i4 = i3 - i2;
            int i5 = c0213q.f2755e;
            int i6 = c0213q.f2754d;
            boolean z2 = true;
            if (i4 == i5 - i6) {
                int i7 = 0;
                while (true) {
                    if (i7 >= i4) {
                        z2 = false;
                        break;
                    } else if (c0213q2.f2751a.charAt(i7 + i2) != c0213q.f2751a.charAt(i7 + i6)) {
                        break;
                    } else {
                        i7++;
                    }
                }
            }
            lVar.f2430i = z2;
        }
        lVar.f2436o = c0213q;
        lVar.f2429h.f(c0213q);
        if (lVar.f2430i) {
            lVar.f2423b.restartInput(rVar);
            lVar.f2430i = false;
        }
    }
}
