package io.flutter.plugin.editing;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public String f2410a;

    /* renamed from: b, reason: collision with root package name */
    public String f2411b;

    /* renamed from: c, reason: collision with root package name */
    public int f2412c;

    /* renamed from: d, reason: collision with root package name */
    public int f2413d;

    /* renamed from: e, reason: collision with root package name */
    public int f2414e;

    /* renamed from: f, reason: collision with root package name */
    public int f2415f;

    /* renamed from: g, reason: collision with root package name */
    public int f2416g;

    /* renamed from: h, reason: collision with root package name */
    public int f2417h;
}
