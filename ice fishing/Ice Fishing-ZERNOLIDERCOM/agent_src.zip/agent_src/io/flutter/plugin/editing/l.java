package io.flutter.plugin.editing;

import D.C0013n;
import L.C0026b;
import L.C0038n;
import L.Q;
import android.graphics.Rect;
import android.os.Build;
import android.text.Selection;
import android.util.Log;
import android.util.SparseArray;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.InputMethodManager;
import c0.AbstractC0099a;
import c0.r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import l0.C0199c;
import l0.C0211o;
import l0.C0213q;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class l implements e {

    /* renamed from: a, reason: collision with root package name */
    public final r f2422a;

    /* renamed from: b, reason: collision with root package name */
    public final InputMethodManager f2423b;

    /* renamed from: c, reason: collision with root package name */
    public final AutofillManager f2424c;

    /* renamed from: d, reason: collision with root package name */
    public final Q f2425d;

    /* renamed from: e, reason: collision with root package name */
    public C0038n f2426e = new C0038n(1, 0);

    /* renamed from: f, reason: collision with root package name */
    public C0211o f2427f;

    /* renamed from: g, reason: collision with root package name */
    public SparseArray f2428g;

    /* renamed from: h, reason: collision with root package name */
    public f f2429h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f2430i;

    /* renamed from: j, reason: collision with root package name */
    public c f2431j;

    /* renamed from: k, reason: collision with root package name */
    public final io.flutter.plugin.platform.k f2432k;

    /* renamed from: l, reason: collision with root package name */
    public final io.flutter.plugin.platform.j f2433l;

    /* renamed from: m, reason: collision with root package name */
    public Rect f2434m;

    /* renamed from: n, reason: collision with root package name */
    public final ImeSyncDeferringInsetsCallback f2435n;

    /* renamed from: o, reason: collision with root package name */
    public C0213q f2436o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f2437p;

    public l(r rVar, Q q2, C0199c c0199c, io.flutter.plugin.platform.k kVar, io.flutter.plugin.platform.j jVar) {
        this.f2422a = rVar;
        this.f2429h = new f(null, rVar);
        this.f2423b = (InputMethodManager) rVar.getContext().getSystemService("input_method");
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            this.f2424c = AbstractC0099a.e(rVar.getContext().getSystemService(AbstractC0099a.j()));
        } else {
            this.f2424c = null;
        }
        if (i2 >= 30) {
            ImeSyncDeferringInsetsCallback imeSyncDeferringInsetsCallback = new ImeSyncDeferringInsetsCallback(rVar);
            this.f2435n = imeSyncDeferringInsetsCallback;
            imeSyncDeferringInsetsCallback.install();
            imeSyncDeferringInsetsCallback.setImeVisibilityListener(new j(this));
        }
        this.f2425d = q2;
        q2.f520g = new j(this);
        ((C0026b) q2.f519f).D("TextInputClient.requestExistingInputState", null, null);
        this.f2432k = kVar;
        kVar.f2467j = this;
        this.f2433l = jVar;
        jVar.getClass();
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:0x0086, code lost:
    
        if (r10 == r0.f2755e) goto L38;
     */
    @Override // io.flutter.plugin.editing.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void a(boolean z2) {
        AutofillManager autofillManager;
        AutofillValue forText;
        if (z2) {
            String fVar = this.f2429h.toString();
            if (Build.VERSION.SDK_INT >= 26 && (autofillManager = this.f2424c) != null && this.f2428g != null) {
                int hashCode = ((String) this.f2427f.f2744j.f243a).hashCode();
                forText = AutofillValue.forText(fVar);
                autofillManager.notifyValueChanged(this.f2422a, hashCode, forText);
            }
        }
        f fVar2 = this.f2429h;
        fVar2.getClass();
        int selectionStart = Selection.getSelectionStart(fVar2);
        f fVar3 = this.f2429h;
        fVar3.getClass();
        int selectionEnd = Selection.getSelectionEnd(fVar3);
        f fVar4 = this.f2429h;
        fVar4.getClass();
        int composingSpanStart = BaseInputConnection.getComposingSpanStart(fVar4);
        f fVar5 = this.f2429h;
        fVar5.getClass();
        int composingSpanEnd = BaseInputConnection.getComposingSpanEnd(fVar5);
        f fVar6 = this.f2429h;
        fVar6.getClass();
        ArrayList arrayList = fVar6.f2398e;
        ArrayList arrayList2 = new ArrayList(arrayList);
        arrayList.clear();
        if (this.f2436o != null) {
            if (this.f2429h.toString().equals(this.f2436o.f2751a)) {
                C0213q c0213q = this.f2436o;
                if (selectionStart == c0213q.f2752b) {
                    if (selectionEnd == c0213q.f2753c) {
                        if (composingSpanStart == c0213q.f2754d) {
                        }
                    }
                }
            }
            this.f2429h.toString();
            boolean z3 = this.f2427f.f2739e;
            Q q2 = this.f2425d;
            if (z3) {
                int i2 = this.f2426e.f583c;
                q2.getClass();
                arrayList2.size();
                HashMap hashMap = new HashMap();
                JSONArray jSONArray = new JSONArray();
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    i iVar = (i) it.next();
                    iVar.getClass();
                    JSONObject jSONObject = new JSONObject();
                    try {
                        jSONObject.put("oldText", iVar.f2410a.toString());
                        jSONObject.put("deltaText", iVar.f2411b.toString());
                        jSONObject.put("deltaStart", iVar.f2412c);
                        jSONObject.put("deltaEnd", iVar.f2413d);
                        jSONObject.put("selectionBase", iVar.f2414e);
                        jSONObject.put("selectionExtent", iVar.f2415f);
                        jSONObject.put("composingBase", iVar.f2416g);
                        jSONObject.put("composingExtent", iVar.f2417h);
                    } catch (JSONException e2) {
                        Log.e("TextEditingDelta", "unable to create JSONObject: " + e2);
                    }
                    jSONArray.put(jSONObject);
                }
                hashMap.put("deltas", jSONArray);
                ((C0026b) q2.f519f).D("TextInputClient.updateEditingStateWithDeltas", Arrays.asList(Integer.valueOf(i2), hashMap), null);
                this.f2429h.f2398e.clear();
            } else {
                int i3 = this.f2426e.f583c;
                String fVar7 = this.f2429h.toString();
                q2.getClass();
                ((C0026b) q2.f519f).D("TextInputClient.updateEditingState", Arrays.asList(Integer.valueOf(i3), Q.o(fVar7, selectionStart, selectionEnd, composingSpanStart, composingSpanEnd)), null);
            }
            this.f2436o = new C0213q(this.f2429h.toString(), selectionStart, selectionEnd, composingSpanStart, composingSpanEnd);
            return;
        }
        this.f2429h.f2398e.clear();
    }

    public final void b() {
        this.f2432k.f2467j = null;
        this.f2433l.getClass();
        this.f2425d.f520g = null;
        c();
        this.f2429h.e(this);
        ImeSyncDeferringInsetsCallback imeSyncDeferringInsetsCallback = this.f2435n;
        if (imeSyncDeferringInsetsCallback != null) {
            imeSyncDeferringInsetsCallback.remove();
        }
    }

    public final void c() {
        AutofillManager autofillManager;
        C0211o c0211o;
        C0013n c0013n;
        if (Build.VERSION.SDK_INT < 26 || (autofillManager = this.f2424c) == null || (c0211o = this.f2427f) == null || (c0013n = c0211o.f2744j) == null || this.f2428g == null) {
            return;
        }
        autofillManager.notifyViewExited(this.f2422a, ((String) c0013n.f243a).hashCode());
    }

    public final void d(C0211o c0211o) {
        C0013n c0013n;
        AutofillValue forText;
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        if (c0211o == null || (c0013n = c0211o.f2744j) == null) {
            this.f2428g = null;
            return;
        }
        SparseArray sparseArray = new SparseArray();
        this.f2428g = sparseArray;
        C0211o[] c0211oArr = c0211o.f2746l;
        if (c0211oArr == null) {
            sparseArray.put(((String) c0013n.f243a).hashCode(), c0211o);
            return;
        }
        for (C0211o c0211o2 : c0211oArr) {
            C0013n c0013n2 = c0211o2.f2744j;
            if (c0013n2 != null) {
                SparseArray sparseArray2 = this.f2428g;
                String str = (String) c0013n2.f243a;
                sparseArray2.put(str.hashCode(), c0211o2);
                AutofillManager autofillManager = this.f2424c;
                int hashCode = str.hashCode();
                forText = AutofillValue.forText(((C0213q) c0013n2.f245c).f2751a);
                autofillManager.notifyValueChanged(this.f2422a, hashCode, forText);
            }
        }
    }
}
