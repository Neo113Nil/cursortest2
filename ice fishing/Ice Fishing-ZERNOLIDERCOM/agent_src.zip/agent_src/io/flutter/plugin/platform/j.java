package io.flutter.plugin.platform;

import L.Q;
import android.app.Activity;
import android.util.SparseArray;
import android.view.Surface;
import android.view.SurfaceControl;
import d0.C0119i;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.ArrayList;
import l0.C0199c;

/* loaded from: classes.dex */
public final class j implements h {

    /* renamed from: e, reason: collision with root package name */
    public C0119i f2449e;

    /* renamed from: f, reason: collision with root package name */
    public Activity f2450f;

    /* renamed from: g, reason: collision with root package name */
    public c0.r f2451g;

    /* renamed from: i, reason: collision with root package name */
    public C0199c f2453i;

    /* renamed from: h, reason: collision with root package name */
    public FlutterJNI f2452h = null;

    /* renamed from: o, reason: collision with root package name */
    public Surface f2459o = null;

    /* renamed from: p, reason: collision with root package name */
    public SurfaceControl f2460p = null;

    /* renamed from: q, reason: collision with root package name */
    public final A.j f2461q = new A.j(27, this);

    /* renamed from: j, reason: collision with root package name */
    public final a f2454j = new a();

    /* renamed from: k, reason: collision with root package name */
    public final SparseArray f2455k = new SparseArray();

    /* renamed from: l, reason: collision with root package name */
    public final SparseArray f2456l = new SparseArray();

    /* renamed from: m, reason: collision with root package name */
    public final ArrayList f2457m = new ArrayList();

    /* renamed from: n, reason: collision with root package name */
    public final ArrayList f2458n = new ArrayList();

    public j() {
        if (Q.f516h == null) {
            Q.f516h = new Q(8);
        }
    }

    @Override // io.flutter.plugin.platform.h
    public final void a() {
        this.f2454j.f2438a = null;
    }

    @Override // io.flutter.plugin.platform.h
    public final void d(io.flutter.view.h hVar) {
        this.f2454j.f2438a = hVar;
    }

    @Override // io.flutter.plugin.platform.h
    public final void f(int i2) {
        if (this.f2455k.get(i2) != null) {
            throw new ClassCastException();
        }
    }

    @Override // io.flutter.plugin.platform.h
    public final boolean g(int i2) {
        return false;
    }
}
