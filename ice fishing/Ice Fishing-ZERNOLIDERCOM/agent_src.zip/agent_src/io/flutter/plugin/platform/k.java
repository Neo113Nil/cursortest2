package io.flutter.plugin.platform;

import L.Q;
import android.app.Activity;
import android.util.SparseArray;
import android.view.View;
import c0.C0108j;
import d0.C0113c;
import d0.C0119i;
import h.C0173s;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.HashMap;
import java.util.HashSet;
import l0.C0199c;

/* loaded from: classes.dex */
public final class k implements h {

    /* renamed from: f, reason: collision with root package name */
    public Activity f2463f;

    /* renamed from: g, reason: collision with root package name */
    public c0.r f2464g;

    /* renamed from: i, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f2466i;

    /* renamed from: j, reason: collision with root package name */
    public io.flutter.plugin.editing.l f2467j;

    /* renamed from: k, reason: collision with root package name */
    public C0199c f2468k;

    /* renamed from: x, reason: collision with root package name */
    public final Q f2480x;

    /* renamed from: h, reason: collision with root package name */
    public FlutterJNI f2465h = null;

    /* renamed from: s, reason: collision with root package name */
    public int f2475s = 0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f2476t = false;

    /* renamed from: u, reason: collision with root package name */
    public boolean f2477u = true;

    /* renamed from: y, reason: collision with root package name */
    public final A.j f2481y = new A.j(26, this);

    /* renamed from: e, reason: collision with root package name */
    public final C0119i f2462e = new C0119i(2);

    /* renamed from: m, reason: collision with root package name */
    public final HashMap f2470m = new HashMap();

    /* renamed from: l, reason: collision with root package name */
    public final a f2469l = new a();

    /* renamed from: n, reason: collision with root package name */
    public final HashMap f2471n = new HashMap();

    /* renamed from: q, reason: collision with root package name */
    public final SparseArray f2474q = new SparseArray();

    /* renamed from: v, reason: collision with root package name */
    public final HashSet f2478v = new HashSet();

    /* renamed from: w, reason: collision with root package name */
    public final HashSet f2479w = new HashSet();
    public final SparseArray r = new SparseArray();

    /* renamed from: o, reason: collision with root package name */
    public final SparseArray f2472o = new SparseArray();

    /* renamed from: p, reason: collision with root package name */
    public final SparseArray f2473p = new SparseArray();

    public k() {
        if (Q.f516h == null) {
            Q.f516h = new Q(8);
        }
        this.f2480x = Q.f516h;
    }

    public static void b(k kVar, C0173s c0173s) {
        kVar.getClass();
        int i2 = c0173s.f2259b;
        if (i2 == 0 || i2 == 1) {
            return;
        }
        throw new IllegalStateException("Trying to create a view with unknown direction value: " + i2 + "(view id: " + c0173s.f2258a + ")");
    }

    @Override // io.flutter.plugin.platform.h
    public final void a() {
        this.f2469l.f2438a = null;
    }

    public final void c() {
        int i2 = 0;
        while (true) {
            SparseArray sparseArray = this.f2474q;
            if (i2 >= sparseArray.size()) {
                return;
            }
            b bVar = (b) sparseArray.valueAt(i2);
            bVar.d();
            bVar.f1710e.close();
            i2++;
        }
    }

    @Override // io.flutter.plugin.platform.h
    public final void d(io.flutter.view.h hVar) {
        this.f2469l.f2438a = hVar;
    }

    public final void e(boolean z2) {
        int i2 = 0;
        while (true) {
            SparseArray sparseArray = this.f2474q;
            if (i2 >= sparseArray.size()) {
                break;
            }
            int keyAt = sparseArray.keyAt(i2);
            b bVar = (b) sparseArray.valueAt(i2);
            if (this.f2478v.contains(Integer.valueOf(keyAt))) {
                C0113c c0113c = this.f2464g.f1749n;
                if (c0113c != null) {
                    bVar.a(c0113c.f1786b);
                }
                z2 &= bVar.e();
            } else {
                if (!this.f2476t) {
                    bVar.d();
                }
                bVar.setVisibility(8);
                this.f2464g.removeView(bVar);
            }
            i2++;
        }
        int i3 = 0;
        while (true) {
            SparseArray sparseArray2 = this.f2473p;
            if (i3 >= sparseArray2.size()) {
                return;
            }
            int keyAt2 = sparseArray2.keyAt(i3);
            View view = (View) sparseArray2.get(keyAt2);
            if (!this.f2479w.contains(Integer.valueOf(keyAt2)) || (!z2 && this.f2477u)) {
                view.setVisibility(8);
            } else {
                view.setVisibility(0);
            }
            i3++;
        }
    }

    @Override // io.flutter.plugin.platform.h
    public final void f(int i2) {
        if (g(i2)) {
            ((q) this.f2470m.get(Integer.valueOf(i2))).getClass();
        } else if (this.f2472o.get(i2) != null) {
            throw new ClassCastException();
        }
    }

    @Override // io.flutter.plugin.platform.h
    public final boolean g(int i2) {
        return this.f2470m.containsKey(Integer.valueOf(i2));
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final void h() {
        if (!this.f2477u || this.f2476t) {
            return;
        }
        c0.r rVar = this.f2464g;
        rVar.f1745j.c();
        C0108j c0108j = rVar.f1744i;
        if (c0108j == null) {
            C0108j c0108j2 = new C0108j(rVar.getContext(), rVar.getWidth(), rVar.getHeight(), 1);
            rVar.f1744i = c0108j2;
            rVar.addView(c0108j2);
        } else {
            c0108j.g(rVar.getWidth(), rVar.getHeight());
        }
        rVar.f1746k = rVar.f1745j;
        C0108j c0108j3 = rVar.f1744i;
        rVar.f1745j = c0108j3;
        C0113c c0113c = rVar.f1749n;
        if (c0113c != null) {
            c0108j3.a(c0113c.f1786b);
        }
        this.f2476t = true;
    }

    public final int i(double d2) {
        return (int) Math.round(d2 * this.f2463f.getResources().getDisplayMetrics().density);
    }
}
