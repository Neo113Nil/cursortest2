package io.flutter.plugin.platform;

import L.Q;
import android.os.Build;
import android.view.Window;
import c0.AbstractActivityC0104f;
import l0.C0202f;
import w.S;
import w.T;
import w.V;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractActivityC0104f f2444a;

    /* renamed from: b, reason: collision with root package name */
    public final Q f2445b;

    /* renamed from: c, reason: collision with root package name */
    public final AbstractActivityC0104f f2446c;

    /* renamed from: d, reason: collision with root package name */
    public C0202f f2447d;

    /* renamed from: e, reason: collision with root package name */
    public int f2448e;

    public e(AbstractActivityC0104f abstractActivityC0104f, Q q2, AbstractActivityC0104f abstractActivityC0104f2) {
        A.j jVar = new A.j(25, this);
        this.f2444a = abstractActivityC0104f;
        this.f2445b = q2;
        q2.f520g = jVar;
        this.f2446c = abstractActivityC0104f2;
        this.f2448e = 1280;
    }

    public final void a(C0202f c0202f) {
        Window window = this.f2444a.getWindow();
        window.getDecorView();
        int i2 = Build.VERSION.SDK_INT;
        p.j v2 = i2 >= 30 ? new V(window) : i2 >= 26 ? new T(window) : new S(window);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 < 30) {
            window.addFlags(Integer.MIN_VALUE);
            window.clearFlags(201326592);
        }
        int i4 = c0202f.f2692b;
        if (i4 != 0) {
            int b2 = F.j.b(i4);
            if (b2 == 0) {
                v2.v(false);
            } else if (b2 == 1) {
                v2.v(true);
            }
        }
        Integer num = c0202f.f2691a;
        if (num != null) {
            window.setStatusBarColor(num.intValue());
        }
        Boolean bool = c0202f.f2693c;
        if (bool != null && i3 >= 29) {
            window.setStatusBarContrastEnforced(bool.booleanValue());
        }
        if (i3 >= 26) {
            int i5 = c0202f.f2695e;
            if (i5 != 0) {
                int b3 = F.j.b(i5);
                if (b3 == 0) {
                    v2.u(false);
                } else if (b3 == 1) {
                    v2.u(true);
                }
            }
            Integer num2 = c0202f.f2694d;
            if (num2 != null) {
                window.setNavigationBarColor(num2.intValue());
            }
        }
        Integer num3 = c0202f.f2696f;
        if (num3 != null && i3 >= 28) {
            window.setNavigationBarDividerColor(num3.intValue());
        }
        Boolean bool2 = c0202f.f2697g;
        if (bool2 != null && i3 >= 29) {
            window.setNavigationBarContrastEnforced(bool2.booleanValue());
        }
        this.f2447d = c0202f;
    }

    public final void b() {
        this.f2444a.getWindow().getDecorView().setSystemUiVisibility(this.f2448e);
        C0202f c0202f = this.f2447d;
        if (c0202f != null) {
            a(c0202f);
        }
    }
}
