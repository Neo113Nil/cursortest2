package io.flutter.embedding.engine.renderer;

import android.os.Handler;
import android.view.Surface;
import c0.C0105g;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.view.o;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicLong;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final FlutterJNI f2371a;

    /* renamed from: b, reason: collision with root package name */
    public Surface f2372b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f2373c;

    /* renamed from: d, reason: collision with root package name */
    public final Handler f2374d;

    /* renamed from: e, reason: collision with root package name */
    public final HashSet f2375e;

    /* renamed from: f, reason: collision with root package name */
    public final ArrayList f2376f;

    /* renamed from: g, reason: collision with root package name */
    public final C0105g f2377g;

    public h(FlutterJNI flutterJNI) {
        new AtomicLong(0L);
        this.f2373c = false;
        this.f2374d = new Handler();
        this.f2375e = new HashSet();
        this.f2376f = new ArrayList();
        C0105g c0105g = new C0105g(3, this);
        this.f2377g = c0105g;
        this.f2371a = flutterJNI;
        flutterJNI.addIsDisplayingFlutterUiListener(c0105g);
    }

    public final void a(i iVar) {
        this.f2371a.addIsDisplayingFlutterUiListener(iVar);
        if (this.f2373c) {
            iVar.a();
        }
    }

    public final void b(int i2) {
        Iterator it = this.f2375e.iterator();
        while (it.hasNext()) {
            o oVar = (o) ((WeakReference) it.next()).get();
            if (oVar != null) {
                oVar.onTrimMemory(i2);
            } else {
                it.remove();
            }
        }
    }

    public final void c(i iVar) {
        this.f2371a.removeIsDisplayingFlutterUiListener(iVar);
    }

    public final void d() {
        Iterator it = this.f2376f.iterator();
        while (it.hasNext()) {
            ((FlutterRenderer$ImageReaderSurfaceProducer) it.next()).getClass();
        }
    }

    public final void e() {
        if (this.f2372b != null) {
            this.f2371a.onSurfaceDestroyed();
            if (this.f2373c) {
                this.f2377g.b();
            }
            this.f2373c = false;
            this.f2372b = null;
        }
    }
}
