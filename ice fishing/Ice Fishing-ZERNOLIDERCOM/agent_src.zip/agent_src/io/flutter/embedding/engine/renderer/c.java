package io.flutter.embedding.engine.renderer;

import android.media.Image;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final Image f2341a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ FlutterRenderer$ImageReaderSurfaceProducer f2342b;

    public c(FlutterRenderer$ImageReaderSurfaceProducer flutterRenderer$ImageReaderSurfaceProducer, Image image) {
        this.f2342b = flutterRenderer$ImageReaderSurfaceProducer;
        this.f2341a = image;
    }
}
