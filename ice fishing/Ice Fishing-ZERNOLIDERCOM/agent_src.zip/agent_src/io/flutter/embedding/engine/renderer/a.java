package io.flutter.embedding.engine.renderer;

import android.graphics.Rect;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final Rect f2337a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2338b;

    /* renamed from: c, reason: collision with root package name */
    public final int f2339c;

    public a(Rect rect, int i2, int i3) {
        this.f2337a = rect;
        this.f2338b = i2;
        this.f2339c = i3;
    }
}
