package io.flutter.embedding.engine.renderer;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public float f2350a = 1.0f;

    /* renamed from: b, reason: collision with root package name */
    public int f2351b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f2352c = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f2353d = 0;

    /* renamed from: e, reason: collision with root package name */
    public int f2354e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f2355f = 0;

    /* renamed from: g, reason: collision with root package name */
    public int f2356g = 0;

    /* renamed from: h, reason: collision with root package name */
    public int f2357h = 0;

    /* renamed from: i, reason: collision with root package name */
    public int f2358i = 0;

    /* renamed from: j, reason: collision with root package name */
    public int f2359j = 0;

    /* renamed from: k, reason: collision with root package name */
    public int f2360k = 0;

    /* renamed from: l, reason: collision with root package name */
    public int f2361l = 0;

    /* renamed from: m, reason: collision with root package name */
    public int f2362m = 0;

    /* renamed from: n, reason: collision with root package name */
    public int f2363n = 0;

    /* renamed from: o, reason: collision with root package name */
    public int f2364o = 0;

    /* renamed from: p, reason: collision with root package name */
    public int f2365p = 0;

    /* renamed from: q, reason: collision with root package name */
    public int f2366q = 0;
    public int r = 0;

    /* renamed from: s, reason: collision with root package name */
    public int f2367s = 0;

    /* renamed from: t, reason: collision with root package name */
    public int f2368t = -1;

    /* renamed from: u, reason: collision with root package name */
    public final ArrayList f2369u = new ArrayList();

    /* renamed from: v, reason: collision with root package name */
    public final ArrayList f2370v = new ArrayList();
}
