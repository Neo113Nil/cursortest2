package j;

import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;

/* renamed from: j.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0185a implements Iterable {

    /* renamed from: e, reason: collision with root package name */
    public final WeakHashMap f2623e = new WeakHashMap();

    public C0185a() {
        new HashMap();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0185a)) {
            return false;
        }
        C0185a c0185a = (C0185a) obj;
        c0185a.getClass();
        iterator();
        c0185a.iterator();
        return true;
    }

    public final int hashCode() {
        iterator();
        return 0;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        C0186b c0186b = new C0186b();
        this.f2623e.put(c0186b, Boolean.FALSE);
        return c0186b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("[");
        iterator();
        sb.append("]");
        return sb.toString();
    }
}
