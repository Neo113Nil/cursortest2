package e0;

/* renamed from: e0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0128e {
    void a(RunnableC0126c runnableC0126c);
}
