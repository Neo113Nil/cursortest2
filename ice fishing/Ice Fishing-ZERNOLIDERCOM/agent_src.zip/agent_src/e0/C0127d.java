package e0;

import java.nio.ByteBuffer;

/* renamed from: e0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0127d {

    /* renamed from: a, reason: collision with root package name */
    public final ByteBuffer f1850a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1851b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1852c;

    public C0127d(long j2, ByteBuffer byteBuffer, int i2) {
        this.f1850a = byteBuffer;
        this.f1851b = i2;
        this.f1852c = j2;
    }
}
