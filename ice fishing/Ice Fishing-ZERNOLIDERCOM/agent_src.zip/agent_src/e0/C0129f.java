package e0;

import m0.InterfaceC0218d;

/* renamed from: e0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0129f {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0218d f1853a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0128e f1854b;

    public C0129f(InterfaceC0218d interfaceC0218d, InterfaceC0128e interfaceC0128e) {
        this.f1853a = interfaceC0218d;
        this.f1854b = interfaceC0128e;
    }
}
