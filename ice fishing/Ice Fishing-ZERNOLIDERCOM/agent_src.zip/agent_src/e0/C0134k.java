package e0;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/* renamed from: e0.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0134k implements InterfaceC0128e {

    /* renamed from: a, reason: collision with root package name */
    public final Handler f1871a;

    public C0134k() {
        Looper mainLooper = Looper.getMainLooper();
        this.f1871a = Build.VERSION.SDK_INT >= 28 ? Handler.createAsync(mainLooper) : new Handler(mainLooper);
    }

    @Override // e0.InterfaceC0128e
    public final void a(RunnableC0126c runnableC0126c) {
        this.f1871a.post(runnableC0126c);
    }
}
