package e0;

/* renamed from: e0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0124a {

    /* renamed from: a, reason: collision with root package name */
    public final String f1835a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1836b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1837c;

    public C0124a(String str, String str2) {
        this.f1835a = str;
        this.f1836b = null;
        this.f1837c = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0124a.class != obj.getClass()) {
            return false;
        }
        C0124a c0124a = (C0124a) obj;
        if (this.f1835a.equals(c0124a.f1835a)) {
            return this.f1837c.equals(c0124a.f1837c);
        }
        return false;
    }

    public final int hashCode() {
        return this.f1837c.hashCode() + (this.f1835a.hashCode() * 31);
    }

    public final String toString() {
        return "DartEntrypoint( bundle path: " + this.f1835a + ", function: " + this.f1837c + " )";
    }

    public C0124a(String str, String str2, String str3) {
        this.f1835a = str;
        this.f1836b = str2;
        this.f1837c = str3;
    }
}
