package e0;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: e0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0131h implements InterfaceC0128e {

    /* renamed from: a, reason: collision with root package name */
    public final ExecutorService f1858a;

    /* renamed from: b, reason: collision with root package name */
    public final ConcurrentLinkedQueue f1859b = new ConcurrentLinkedQueue();

    /* renamed from: c, reason: collision with root package name */
    public final AtomicBoolean f1860c = new AtomicBoolean(false);

    public C0131h(ExecutorService executorService) {
        this.f1858a = executorService;
    }

    @Override // e0.InterfaceC0128e
    public final void a(RunnableC0126c runnableC0126c) {
        this.f1859b.add(runnableC0126c);
        this.f1858a.execute(new androidx.lifecycle.k(1, this));
    }
}
