package e0;

import L.C0026b;
import a.AbstractC0069a;
import android.os.Build;
import android.os.Trace;
import android.util.Log;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import m0.InterfaceC0218d;
import s0.AbstractC0243a;

/* renamed from: e0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0132i implements m0.f, InterfaceC0133j {

    /* renamed from: e, reason: collision with root package name */
    public final FlutterJNI f1861e;

    /* renamed from: f, reason: collision with root package name */
    public final HashMap f1862f;

    /* renamed from: g, reason: collision with root package name */
    public final HashMap f1863g;

    /* renamed from: h, reason: collision with root package name */
    public final Object f1864h;

    /* renamed from: i, reason: collision with root package name */
    public final AtomicBoolean f1865i;

    /* renamed from: j, reason: collision with root package name */
    public final HashMap f1866j;

    /* renamed from: k, reason: collision with root package name */
    public int f1867k;

    /* renamed from: l, reason: collision with root package name */
    public final C0134k f1868l;

    /* renamed from: m, reason: collision with root package name */
    public final WeakHashMap f1869m;

    /* renamed from: n, reason: collision with root package name */
    public final A.j f1870n;

    public C0132i(FlutterJNI flutterJNI) {
        A.j jVar = new A.j(18, false);
        jVar.f30f = (ExecutorService) C0026b.C().f526h;
        this.f1862f = new HashMap();
        this.f1863g = new HashMap();
        this.f1864h = new Object();
        this.f1865i = new AtomicBoolean(false);
        this.f1866j = new HashMap();
        this.f1867k = 1;
        this.f1868l = new C0134k();
        this.f1869m = new WeakHashMap();
        this.f1861e = flutterJNI;
        this.f1870n = jVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [e0.c] */
    public final void a(final String str, final C0129f c0129f, final ByteBuffer byteBuffer, final int i2, final long j2) {
        InterfaceC0128e interfaceC0128e = c0129f != null ? c0129f.f1854b : null;
        String a2 = AbstractC0243a.a("PlatformChannel ScheduleHandler on " + str);
        if (Build.VERSION.SDK_INT >= 29) {
            N.a.a(AbstractC0069a.K(a2), i2);
        } else {
            String K2 = AbstractC0069a.K(a2);
            try {
                if (AbstractC0069a.f1083g == null) {
                    AbstractC0069a.f1083g = Trace.class.getMethod("asyncTraceBegin", Long.TYPE, String.class, Integer.TYPE);
                }
                AbstractC0069a.f1083g.invoke(null, Long.valueOf(AbstractC0069a.f1081e), K2, Integer.valueOf(i2));
            } catch (Exception e2) {
                AbstractC0069a.t("asyncTraceBegin", e2);
            }
        }
        ?? r02 = new Runnable() { // from class: e0.c
            @Override // java.lang.Runnable
            public final void run() {
                long j3 = j2;
                FlutterJNI flutterJNI = C0132i.this.f1861e;
                StringBuilder sb = new StringBuilder("PlatformChannel ScheduleHandler on ");
                String str2 = str;
                sb.append(str2);
                String a3 = AbstractC0243a.a(sb.toString());
                int i3 = Build.VERSION.SDK_INT;
                int i4 = i2;
                if (i3 >= 29) {
                    N.a.b(AbstractC0069a.K(a3), i4);
                } else {
                    String K3 = AbstractC0069a.K(a3);
                    try {
                        if (AbstractC0069a.f1084h == null) {
                            AbstractC0069a.f1084h = Trace.class.getMethod("asyncTraceEnd", Long.TYPE, String.class, Integer.TYPE);
                        }
                        AbstractC0069a.f1084h.invoke(null, Long.valueOf(AbstractC0069a.f1081e), K3, Integer.valueOf(i4));
                    } catch (Exception e3) {
                        AbstractC0069a.t("asyncTraceEnd", e3);
                    }
                }
                try {
                    AbstractC0243a.b("DartMessenger#handleMessageFromDart on " + str2);
                    C0129f c0129f2 = c0129f;
                    ByteBuffer byteBuffer2 = byteBuffer;
                    try {
                        if (c0129f2 != null) {
                            try {
                                try {
                                    c0129f2.f1853a.p(byteBuffer2, new C0130g(flutterJNI, i4));
                                } catch (Exception e4) {
                                    Log.e("DartMessenger", "Uncaught exception in binary message listener", e4);
                                    flutterJNI.invokePlatformMessageEmptyResponseCallback(i4);
                                }
                            } catch (Error e5) {
                                Thread currentThread = Thread.currentThread();
                                if (currentThread.getUncaughtExceptionHandler() == null) {
                                    throw e5;
                                }
                                currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, e5);
                            }
                        } else {
                            flutterJNI.invokePlatformMessageEmptyResponseCallback(i4);
                        }
                        if (byteBuffer2 != null && byteBuffer2.isDirect()) {
                            byteBuffer2.limit(0);
                        }
                        Trace.endSection();
                    } finally {
                    }
                } finally {
                    flutterJNI.cleanupMessageData(j3);
                }
            }
        };
        InterfaceC0128e interfaceC0128e2 = interfaceC0128e;
        if (interfaceC0128e == null) {
            interfaceC0128e2 = this.f1868l;
        }
        interfaceC0128e2.a(r02);
    }

    @Override // m0.f
    public final E.a d(m0.i iVar) {
        A.j jVar = this.f1870n;
        jVar.getClass();
        C0131h c0131h = new C0131h((ExecutorService) jVar.f30f);
        E.a aVar = new E.a(16);
        this.f1869m.put(aVar, c0131h);
        return aVar;
    }

    @Override // m0.f
    public final void f(String str, InterfaceC0218d interfaceC0218d) {
        g(str, interfaceC0218d, null);
    }

    @Override // m0.f
    public final void g(String str, InterfaceC0218d interfaceC0218d, E.a aVar) {
        InterfaceC0128e interfaceC0128e;
        if (interfaceC0218d == null) {
            synchronized (this.f1864h) {
                this.f1862f.remove(str);
            }
            return;
        }
        if (aVar != null) {
            interfaceC0128e = (InterfaceC0128e) this.f1869m.get(aVar);
            if (interfaceC0128e == null) {
                throw new IllegalArgumentException("Unrecognized TaskQueue, use BinaryMessenger to create your TaskQueue (ex makeBackgroundTaskQueue).");
            }
        } else {
            interfaceC0128e = null;
        }
        synchronized (this.f1864h) {
            try {
                this.f1862f.put(str, new C0129f(interfaceC0218d, interfaceC0128e));
                List<C0127d> list = (List) this.f1863g.remove(str);
                if (list == null) {
                    return;
                }
                for (C0127d c0127d : list) {
                    a(str, (C0129f) this.f1862f.get(str), c0127d.f1850a, c0127d.f1851b, c0127d.f1852c);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // m0.f
    public final void m(String str, ByteBuffer byteBuffer, m0.e eVar) {
        AbstractC0243a.b("DartMessenger#send on " + str);
        try {
            int i2 = this.f1867k;
            this.f1867k = i2 + 1;
            if (eVar != null) {
                this.f1866j.put(Integer.valueOf(i2), eVar);
            }
            FlutterJNI flutterJNI = this.f1861e;
            if (byteBuffer == null) {
                flutterJNI.dispatchEmptyPlatformMessage(str, i2);
            } else {
                flutterJNI.dispatchPlatformMessage(str, byteBuffer, byteBuffer.position(), i2);
            }
            Trace.endSection();
        } catch (Throwable th) {
            try {
                Trace.endSection();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }
}
