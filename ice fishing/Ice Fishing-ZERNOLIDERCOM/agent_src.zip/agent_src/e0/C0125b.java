package e0;

import android.content.res.AssetManager;
import android.os.Trace;
import android.util.Log;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Objects;
import m0.InterfaceC0218d;
import s0.AbstractC0243a;

/* renamed from: e0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0125b implements m0.f {

    /* renamed from: e, reason: collision with root package name */
    public final FlutterJNI f1838e;

    /* renamed from: f, reason: collision with root package name */
    public final AssetManager f1839f;

    /* renamed from: g, reason: collision with root package name */
    public final long f1840g;

    /* renamed from: h, reason: collision with root package name */
    public final C0132i f1841h;

    /* renamed from: i, reason: collision with root package name */
    public final A.j f1842i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1843j;

    public C0125b(FlutterJNI flutterJNI, AssetManager assetManager, long j2) {
        this.f1843j = false;
        A.j jVar = new A.j(16, this);
        this.f1838e = flutterJNI;
        this.f1839f = assetManager;
        this.f1840g = j2;
        C0132i c0132i = new C0132i(flutterJNI);
        this.f1841h = c0132i;
        c0132i.g("flutter/isolate", jVar, null);
        this.f1842i = new A.j(17, c0132i);
        if (flutterJNI.isAttached()) {
            this.f1843j = true;
        }
    }

    public final void a(C0124a c0124a, List list) {
        if (this.f1843j) {
            Log.w("DartExecutor", "Attempted to run a DartExecutor that is already running.");
            return;
        }
        AbstractC0243a.b("DartExecutor#executeDartEntrypoint");
        try {
            Objects.toString(c0124a);
            this.f1838e.runBundleAndSnapshotFromLibrary(c0124a.f1835a, c0124a.f1837c, c0124a.f1836b, this.f1839f, list, this.f1840g);
            this.f1843j = true;
            Trace.endSection();
        } catch (Throwable th) {
            try {
                Trace.endSection();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    @Override // m0.f
    public final E.a d(m0.i iVar) {
        return ((C0132i) this.f1842i.f30f).d(iVar);
    }

    @Override // m0.f
    public final void f(String str, InterfaceC0218d interfaceC0218d) {
        this.f1842i.f(str, interfaceC0218d);
    }

    @Override // m0.f
    public final void g(String str, InterfaceC0218d interfaceC0218d, E.a aVar) {
        this.f1842i.g(str, interfaceC0218d, aVar);
    }

    @Override // m0.f
    public final void m(String str, ByteBuffer byteBuffer, m0.e eVar) {
        this.f1842i.m(str, byteBuffer, eVar);
    }
}
