package v0;

import D0.p;

/* loaded from: classes.dex */
public abstract class a implements g {

    /* renamed from: e, reason: collision with root package name */
    public final h f2995e;

    public a(h hVar) {
        this.f2995e = hVar;
    }

    @Override // v0.i
    public final i f(i iVar) {
        E0.i.e(iVar, "context");
        return iVar == j.f3000e ? this : (i) iVar.m(this, new b(1));
    }

    @Override // v0.i
    public i g(h hVar) {
        return p.j.s(this, hVar);
    }

    @Override // v0.g
    public final h getKey() {
        return this.f2995e;
    }

    @Override // v0.i
    public g i(h hVar) {
        return p.j.m(this, hVar);
    }

    @Override // v0.i
    public final Object m(Object obj, p pVar) {
        return pVar.f(obj, this);
    }
}
