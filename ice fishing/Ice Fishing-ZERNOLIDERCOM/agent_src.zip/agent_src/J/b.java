package J;

import android.content.res.AssetManager;
import android.os.Build;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final Executor f418a;

    /* renamed from: b, reason: collision with root package name */
    public final e f419b;

    /* renamed from: c, reason: collision with root package name */
    public final byte[] f420c;

    /* renamed from: d, reason: collision with root package name */
    public final File f421d;

    /* renamed from: e, reason: collision with root package name */
    public final String f422e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f423f = false;

    /* renamed from: g, reason: collision with root package name */
    public c[] f424g;

    /* renamed from: h, reason: collision with root package name */
    public byte[] f425h;

    public b(AssetManager assetManager, Executor executor, e eVar, String str, File file) {
        this.f418a = executor;
        this.f419b = eVar;
        this.f422e = str;
        this.f421d = file;
        int i2 = Build.VERSION.SDK_INT;
        byte[] bArr = null;
        if (i2 <= 34) {
            switch (i2) {
                case 25:
                    bArr = f.f442h;
                    break;
                case 26:
                    bArr = f.f441g;
                    break;
                case 27:
                    bArr = f.f440f;
                    break;
                case 28:
                case 29:
                case 30:
                    bArr = f.f439e;
                    break;
                case 31:
                case 32:
                case 33:
                case 34:
                    bArr = f.f438d;
                    break;
            }
        }
        this.f420c = bArr;
    }

    public final FileInputStream a(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e2) {
            String message = e2.getMessage();
            if (message != null && message.contains("compressed")) {
                this.f419b.j();
            }
            return null;
        }
    }

    public final void b(final int i2, final Serializable serializable) {
        this.f418a.execute(new Runnable() { // from class: J.a
            @Override // java.lang.Runnable
            public final void run() {
                b.this.f419b.e(i2, serializable);
            }
        });
    }
}
