package k;

import D.C0013n;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class e implements Iterator {

    /* renamed from: e, reason: collision with root package name */
    public final int f2637e;

    /* renamed from: f, reason: collision with root package name */
    public int f2638f;

    /* renamed from: g, reason: collision with root package name */
    public int f2639g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2640h = false;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ C0013n f2641i;

    public e(C0013n c0013n, int i2) {
        this.f2641i = c0013n;
        this.f2637e = i2;
        this.f2638f = ((C0188a) c0013n.f246d).f2655g;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f2639g < this.f2638f;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object b2 = this.f2641i.b(this.f2639g, this.f2637e);
        this.f2639g++;
        this.f2640h = true;
        return b2;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f2640h) {
            throw new IllegalStateException();
        }
        int i2 = this.f2639g - 1;
        this.f2639g = i2;
        this.f2638f--;
        this.f2640h = false;
        this.f2641i.c(i2);
    }
}
