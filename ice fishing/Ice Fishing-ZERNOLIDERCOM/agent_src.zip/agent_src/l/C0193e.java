package l;

import a.AbstractC0069a;

/* renamed from: l.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0193e extends AbstractC0069a {
    @Override // a.AbstractC0069a
    public final boolean c(AbstractFutureC0195g abstractFutureC0195g, C0191c c0191c) {
        C0191c c0191c2 = C0191c.f2663b;
        synchronized (abstractFutureC0195g) {
            try {
                if (abstractFutureC0195g.f2678b != c0191c) {
                    return false;
                }
                abstractFutureC0195g.f2678b = c0191c2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // a.AbstractC0069a
    public final boolean d(AbstractFutureC0195g abstractFutureC0195g, Object obj, Object obj2) {
        synchronized (abstractFutureC0195g) {
            try {
                if (abstractFutureC0195g.f2677a != obj) {
                    return false;
                }
                abstractFutureC0195g.f2677a = obj2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // a.AbstractC0069a
    public final boolean e(AbstractFutureC0195g abstractFutureC0195g, C0194f c0194f, C0194f c0194f2) {
        synchronized (abstractFutureC0195g) {
            try {
                if (abstractFutureC0195g.f2679c != c0194f) {
                    return false;
                }
                abstractFutureC0195g.f2679c = c0194f2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // a.AbstractC0069a
    public final void y(C0194f c0194f, C0194f c0194f2) {
        c0194f.f2672b = c0194f2;
    }

    @Override // a.AbstractC0069a
    public final void z(C0194f c0194f, Thread thread) {
        c0194f.f2671a = thread;
    }
}
