package l;

import a.AbstractC0069a;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* renamed from: l.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0192d extends AbstractC0069a {

    /* renamed from: i, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2665i;

    /* renamed from: j, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2666j;

    /* renamed from: k, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2667k;

    /* renamed from: l, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2668l;

    /* renamed from: m, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f2669m;

    public C0192d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f2665i = atomicReferenceFieldUpdater;
        this.f2666j = atomicReferenceFieldUpdater2;
        this.f2667k = atomicReferenceFieldUpdater3;
        this.f2668l = atomicReferenceFieldUpdater4;
        this.f2669m = atomicReferenceFieldUpdater5;
    }

    @Override // a.AbstractC0069a
    public final boolean c(AbstractFutureC0195g abstractFutureC0195g, C0191c c0191c) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        C0191c c0191c2 = C0191c.f2663b;
        do {
            atomicReferenceFieldUpdater = this.f2668l;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0195g, c0191c, c0191c2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0195g) == c0191c);
        return false;
    }

    @Override // a.AbstractC0069a
    public final boolean d(AbstractFutureC0195g abstractFutureC0195g, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f2669m;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0195g, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0195g) == obj);
        return false;
    }

    @Override // a.AbstractC0069a
    public final boolean e(AbstractFutureC0195g abstractFutureC0195g, C0194f c0194f, C0194f c0194f2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f2667k;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0195g, c0194f, c0194f2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0195g) == c0194f);
        return false;
    }

    @Override // a.AbstractC0069a
    public final void y(C0194f c0194f, C0194f c0194f2) {
        this.f2666j.lazySet(c0194f, c0194f2);
    }

    @Override // a.AbstractC0069a
    public final void z(C0194f c0194f, Thread thread) {
        this.f2665i.lazySet(c0194f, thread);
    }
}
