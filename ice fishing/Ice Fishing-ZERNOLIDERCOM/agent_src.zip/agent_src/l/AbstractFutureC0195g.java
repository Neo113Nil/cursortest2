package l;

import a.AbstractC0069a;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: l.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractFutureC0195g implements Future {

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f2673d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* renamed from: e, reason: collision with root package name */
    public static final Logger f2674e = Logger.getLogger(AbstractFutureC0195g.class.getName());

    /* renamed from: f, reason: collision with root package name */
    public static final AbstractC0069a f2675f;

    /* renamed from: g, reason: collision with root package name */
    public static final Object f2676g;

    /* renamed from: a, reason: collision with root package name */
    public volatile Object f2677a;

    /* renamed from: b, reason: collision with root package name */
    public volatile C0191c f2678b;

    /* renamed from: c, reason: collision with root package name */
    public volatile C0194f f2679c;

    static {
        AbstractC0069a c0193e;
        try {
            c0193e = new C0192d(AtomicReferenceFieldUpdater.newUpdater(C0194f.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(C0194f.class, C0194f.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0195g.class, C0194f.class, "c"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0195g.class, C0191c.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0195g.class, Object.class, "a"));
            th = null;
        } catch (Throwable th) {
            th = th;
            c0193e = new C0193e();
        }
        f2675f = c0193e;
        if (th != null) {
            f2674e.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        f2676g = new Object();
    }

    public static void b(AbstractFutureC0195g abstractFutureC0195g) {
        C0194f c0194f;
        C0191c c0191c;
        do {
            c0194f = abstractFutureC0195g.f2679c;
        } while (!f2675f.e(abstractFutureC0195g, c0194f, C0194f.f2670c));
        while (c0194f != null) {
            Thread thread = c0194f.f2671a;
            if (thread != null) {
                c0194f.f2671a = null;
                LockSupport.unpark(thread);
            }
            c0194f = c0194f.f2672b;
        }
        do {
            c0191c = abstractFutureC0195g.f2678b;
        } while (!f2675f.c(abstractFutureC0195g, c0191c));
        C0191c c0191c2 = null;
        while (c0191c != null) {
            C0191c c0191c3 = c0191c.f2664a;
            c0191c.f2664a = c0191c2;
            c0191c2 = c0191c;
            c0191c = c0191c3;
        }
        while (c0191c2 != null) {
            c0191c2 = c0191c2.f2664a;
            try {
                throw null;
            } catch (RuntimeException e2) {
                f2674e.log(Level.SEVERE, "RuntimeException while executing runnable null with executor null", (Throwable) e2);
            }
        }
    }

    public static Object c(Object obj) {
        if (obj instanceof C0189a) {
            CancellationException cancellationException = ((C0189a) obj).f2662a;
            CancellationException cancellationException2 = new CancellationException("Task was cancelled.");
            cancellationException2.initCause(cancellationException);
            throw cancellationException2;
        }
        if (obj instanceof AbstractC0190b) {
            ((AbstractC0190b) obj).getClass();
            throw new ExecutionException((Throwable) null);
        }
        if (obj == f2676g) {
            return null;
        }
        return obj;
    }

    public static Object d(AbstractFutureC0195g abstractFutureC0195g) {
        Object obj;
        boolean z2 = false;
        while (true) {
            try {
                obj = abstractFutureC0195g.get();
                break;
            } catch (InterruptedException unused) {
                z2 = true;
            } catch (Throwable th) {
                if (z2) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z2) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(StringBuilder sb) {
        try {
            Object d2 = d(this);
            sb.append("SUCCESS, result=[");
            sb.append(d2 == this ? "this future" : String.valueOf(d2));
            sb.append("]");
        } catch (CancellationException unused) {
            sb.append("CANCELLED");
        } catch (RuntimeException e2) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e2.getClass());
            sb.append(" thrown from get()]");
        } catch (ExecutionException e3) {
            sb.append("FAILURE, cause=[");
            sb.append(e3.getCause());
            sb.append("]");
        }
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z2) {
        Object obj = this.f2677a;
        if (obj != null) {
            return false;
        }
        if (!f2675f.d(this, obj, f2673d ? new C0189a(z2, new CancellationException("Future.cancel() was called.")) : z2 ? C0189a.f2660b : C0189a.f2661c)) {
            return false;
        }
        b(this);
        return true;
    }

    public final void e(C0194f c0194f) {
        c0194f.f2671a = null;
        while (true) {
            C0194f c0194f2 = this.f2679c;
            if (c0194f2 == C0194f.f2670c) {
                return;
            }
            C0194f c0194f3 = null;
            while (c0194f2 != null) {
                C0194f c0194f4 = c0194f2.f2672b;
                if (c0194f2.f2671a != null) {
                    c0194f3 = c0194f2;
                } else if (c0194f3 != null) {
                    c0194f3.f2672b = c0194f4;
                    if (c0194f3.f2671a == null) {
                        break;
                    }
                } else if (!f2675f.e(this, c0194f2, c0194f4)) {
                    break;
                }
                c0194f2 = c0194f4;
            }
            return;
        }
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j2, TimeUnit timeUnit) {
        long nanos = timeUnit.toNanos(j2);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f2677a;
        if (obj != null) {
            return c(obj);
        }
        long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            C0194f c0194f = this.f2679c;
            C0194f c0194f2 = C0194f.f2670c;
            if (c0194f != c0194f2) {
                C0194f c0194f3 = new C0194f();
                do {
                    AbstractC0069a abstractC0069a = f2675f;
                    abstractC0069a.y(c0194f3, c0194f);
                    if (abstractC0069a.e(this, c0194f, c0194f3)) {
                        do {
                            LockSupport.parkNanos(this, nanos);
                            if (Thread.interrupted()) {
                                e(c0194f3);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f2677a;
                            if (obj2 != null) {
                                return c(obj2);
                            }
                            nanos = nanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        e(c0194f3);
                    } else {
                        c0194f = this.f2679c;
                    }
                } while (c0194f != c0194f2);
            }
            return c(this.f2677a);
        }
        while (nanos > 0) {
            Object obj3 = this.f2677a;
            if (obj3 != null) {
                return c(obj3);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = nanoTime - System.nanoTime();
        }
        String abstractFutureC0195g = toString();
        String obj4 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = obj4.toLowerCase(locale);
        String str = "Waited " + j2 + " " + timeUnit.toString().toLowerCase(locale);
        if (nanos + 1000 < 0) {
            String str2 = str + " (plus ";
            long j3 = -nanos;
            long convert = timeUnit.convert(j3, TimeUnit.NANOSECONDS);
            long nanos2 = j3 - timeUnit.toNanos(convert);
            boolean z2 = convert == 0 || nanos2 > 1000;
            if (convert > 0) {
                String str3 = str2 + convert + " " + lowerCase;
                if (z2) {
                    str3 = str3 + ",";
                }
                str2 = str3 + " ";
            }
            if (z2) {
                str2 = str2 + nanos2 + " nanoseconds ";
            }
            str = str2 + "delay)";
        }
        if (isDone()) {
            throw new TimeoutException(str + " but future completed as timeout expired");
        }
        throw new TimeoutException(str + " for " + abstractFutureC0195g);
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f2677a instanceof C0189a;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return this.f2677a != null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (this.f2677a instanceof C0189a) {
            sb.append("CANCELLED");
        } else if (isDone()) {
            a(sb);
        } else {
            try {
                if (this instanceof ScheduledFuture) {
                    str = "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
                } else {
                    str = null;
                }
            } catch (RuntimeException e2) {
                str = "Exception thrown from implementation: " + e2.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb.append("PENDING, info=[");
                sb.append(str);
                sb.append("]");
            } else if (isDone()) {
                a(sb);
            } else {
                sb.append("PENDING");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f2677a;
            if (obj2 != null) {
                return c(obj2);
            }
            C0194f c0194f = this.f2679c;
            C0194f c0194f2 = C0194f.f2670c;
            if (c0194f != c0194f2) {
                C0194f c0194f3 = new C0194f();
                do {
                    AbstractC0069a abstractC0069a = f2675f;
                    abstractC0069a.y(c0194f3, c0194f);
                    if (abstractC0069a.e(this, c0194f, c0194f3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f2677a;
                            } else {
                                e(c0194f3);
                                throw new InterruptedException();
                            }
                        } while (obj == null);
                        return c(obj);
                    }
                    c0194f = this.f2679c;
                } while (c0194f != c0194f2);
            }
            return c(this.f2677a);
        }
        throw new InterruptedException();
    }
}
