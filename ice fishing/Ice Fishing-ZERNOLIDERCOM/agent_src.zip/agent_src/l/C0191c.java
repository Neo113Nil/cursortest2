package l;

/* renamed from: l.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0191c {

    /* renamed from: b, reason: collision with root package name */
    public static final C0191c f2663b = new C0191c();

    /* renamed from: a, reason: collision with root package name */
    public C0191c f2664a;
}
