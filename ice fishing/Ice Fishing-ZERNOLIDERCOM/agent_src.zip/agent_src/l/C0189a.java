package l;

import java.util.concurrent.CancellationException;

/* renamed from: l.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0189a {

    /* renamed from: b, reason: collision with root package name */
    public static final C0189a f2660b;

    /* renamed from: c, reason: collision with root package name */
    public static final C0189a f2661c;

    /* renamed from: a, reason: collision with root package name */
    public final CancellationException f2662a;

    static {
        if (AbstractFutureC0195g.f2673d) {
            f2661c = null;
            f2660b = null;
        } else {
            f2661c = new C0189a(false, null);
            f2660b = new C0189a(true, null);
        }
    }

    public C0189a(boolean z2, CancellationException cancellationException) {
        this.f2662a = cancellationException;
    }
}
