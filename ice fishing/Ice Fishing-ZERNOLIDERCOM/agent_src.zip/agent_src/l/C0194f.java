package l;

/* renamed from: l.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0194f {

    /* renamed from: c, reason: collision with root package name */
    public static final C0194f f2670c = new C0194f();

    /* renamed from: a, reason: collision with root package name */
    public volatile Thread f2671a;

    /* renamed from: b, reason: collision with root package name */
    public volatile C0194f f2672b;

    public C0194f() {
        AbstractFutureC0195g.f2675f.z(this, Thread.currentThread());
    }
}
