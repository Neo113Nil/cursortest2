package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0071a {
    protected int memoizedHashCode;

    public abstract int a(W w2);

    public abstract void b(C0083m c0083m);
}
