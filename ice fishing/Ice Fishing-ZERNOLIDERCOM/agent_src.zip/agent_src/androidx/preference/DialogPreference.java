package androidx.preference;

import I.a;
import a.AbstractC0069a;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.pengsnow.battlefun.R;

/* loaded from: classes.dex */
public abstract class DialogPreference extends Preference {
    public DialogPreference(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f405b, i2, 0);
        AbstractC0069a.r(obtainStyledAttributes, 9, 0);
        AbstractC0069a.r(obtainStyledAttributes, 8, 1);
        if (obtainStyledAttributes.getDrawable(6) == null) {
            obtainStyledAttributes.getDrawable(2);
        }
        AbstractC0069a.r(obtainStyledAttributes, 11, 3);
        AbstractC0069a.r(obtainStyledAttributes, 10, 4);
        obtainStyledAttributes.getResourceId(7, obtainStyledAttributes.getResourceId(5, 0));
        obtainStyledAttributes.recycle();
    }

    public DialogPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, AbstractC0069a.o(context, R.attr.dialogPreferenceStyle, android.R.attr.dialogPreferenceStyle));
    }
}
