package androidx.preference;

import a.AbstractC0069a;
import android.content.Context;
import android.util.AttributeSet;
import com.pengsnow.battlefun.R;

/* loaded from: classes.dex */
public class PreferenceCategory extends PreferenceGroup {
    public PreferenceCategory(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, AbstractC0069a.o(context, R.attr.preferenceCategoryStyle, android.R.attr.preferenceCategoryStyle));
    }
}
