package K0;

/* loaded from: classes.dex */
public abstract class g extends f {
}
