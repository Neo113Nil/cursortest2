package f;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import g.k;
import java.lang.reflect.Constructor;
import w.AbstractC0267f;

/* renamed from: f.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0137c {

    /* renamed from: A, reason: collision with root package name */
    public CharSequence f1875A;

    /* renamed from: D, reason: collision with root package name */
    public final /* synthetic */ C0138d f1878D;

    /* renamed from: a, reason: collision with root package name */
    public final Menu f1879a;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1886h;

    /* renamed from: i, reason: collision with root package name */
    public int f1887i;

    /* renamed from: j, reason: collision with root package name */
    public int f1888j;

    /* renamed from: k, reason: collision with root package name */
    public CharSequence f1889k;

    /* renamed from: l, reason: collision with root package name */
    public CharSequence f1890l;

    /* renamed from: m, reason: collision with root package name */
    public int f1891m;

    /* renamed from: n, reason: collision with root package name */
    public char f1892n;

    /* renamed from: o, reason: collision with root package name */
    public int f1893o;

    /* renamed from: p, reason: collision with root package name */
    public char f1894p;

    /* renamed from: q, reason: collision with root package name */
    public int f1895q;
    public int r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f1896s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f1897t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1898u;

    /* renamed from: v, reason: collision with root package name */
    public int f1899v;

    /* renamed from: w, reason: collision with root package name */
    public int f1900w;

    /* renamed from: x, reason: collision with root package name */
    public String f1901x;

    /* renamed from: y, reason: collision with root package name */
    public String f1902y;

    /* renamed from: z, reason: collision with root package name */
    public CharSequence f1903z;

    /* renamed from: B, reason: collision with root package name */
    public ColorStateList f1876B = null;

    /* renamed from: C, reason: collision with root package name */
    public PorterDuff.Mode f1877C = null;

    /* renamed from: b, reason: collision with root package name */
    public int f1880b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f1881c = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f1882d = 0;

    /* renamed from: e, reason: collision with root package name */
    public int f1883e = 0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1884f = true;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1885g = true;

    public C0137c(C0138d c0138d, Menu menu) {
        this.f1878D = c0138d;
        this.f1879a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f1878D.f1908c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    public final void b(MenuItem menuItem) {
        boolean z2 = false;
        menuItem.setChecked(this.f1896s).setVisible(this.f1897t).setEnabled(this.f1898u).setCheckable(this.r >= 1).setTitleCondensed(this.f1890l).setIcon(this.f1891m);
        int i2 = this.f1899v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f1902y;
        C0138d c0138d = this.f1878D;
        if (str != null) {
            if (c0138d.f1908c.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            if (c0138d.f1909d == null) {
                c0138d.f1909d = C0138d.a(c0138d.f1908c);
            }
            Object obj = c0138d.f1909d;
            String str2 = this.f1902y;
            MenuItemOnMenuItemClickListenerC0136b menuItemOnMenuItemClickListenerC0136b = new MenuItemOnMenuItemClickListenerC0136b();
            menuItemOnMenuItemClickListenerC0136b.f1873a = obj;
            Class<?> cls = obj.getClass();
            try {
                menuItemOnMenuItemClickListenerC0136b.f1874b = cls.getMethod(str2, MenuItemOnMenuItemClickListenerC0136b.f1872c);
                menuItem.setOnMenuItemClickListener(menuItemOnMenuItemClickListenerC0136b);
            } catch (Exception e2) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                inflateException.initCause(e2);
                throw inflateException;
            }
        }
        boolean z3 = menuItem instanceof k;
        if (z3) {
        }
        if (this.r >= 2 && z3) {
            k kVar = (k) menuItem;
            kVar.f2006x = (kVar.f2006x & (-5)) | 4;
        }
        String str3 = this.f1901x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0138d.f1904e, c0138d.f1906a));
            z2 = true;
        }
        int i3 = this.f1900w;
        if (i3 > 0) {
            if (z2) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            } else {
                menuItem.setActionView(i3);
            }
        }
        CharSequence charSequence = this.f1903z;
        boolean z4 = menuItem instanceof k;
        if (z4) {
            ((k) menuItem).e(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0267f.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f1875A;
        if (z4) {
            ((k) menuItem).g(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0267f.m(menuItem, charSequence2);
        }
        char c2 = this.f1892n;
        int i4 = this.f1893o;
        if (z4) {
            ((k) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0267f.g(menuItem, c2, i4);
        }
        char c3 = this.f1894p;
        int i5 = this.f1895q;
        if (z4) {
            ((k) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0267f.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f1877C;
        if (mode != null) {
            if (z4) {
                ((k) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0267f.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f1876B;
        if (colorStateList != null) {
            if (z4) {
                ((k) menuItem).setIconTintList(colorStateList);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0267f.i(menuItem, colorStateList);
            }
        }
    }
}
