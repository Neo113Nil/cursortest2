package F0;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class d extends e implements Serializable {
}
