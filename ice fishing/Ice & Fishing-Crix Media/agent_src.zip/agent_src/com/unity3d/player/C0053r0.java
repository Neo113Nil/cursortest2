package com.unity3d.player;

import android.view.WindowInsets;
import com.unity3d.player.UnityPlayer;

/* renamed from: com.unity3d.player.r0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0053r0 extends UnityPlayer.b {
    public final /* synthetic */ WindowInsets b;
    public final /* synthetic */ E0 c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0053r0(E0 e0, WindowInsets windowInsets) {
        super();
        this.c = e0;
        this.b = windowInsets;
    }

    @Override // com.unity3d.player.UnityPlayer.b
    public final void a() {
        this.c.a.nativeOnApplyWindowInsets(this.b);
    }
}
