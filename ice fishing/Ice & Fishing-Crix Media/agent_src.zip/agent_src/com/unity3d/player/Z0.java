package com.unity3d.player;

/* loaded from: classes.dex */
public final class Z0 implements W0 {
    public final /* synthetic */ a1 a;

    public Z0(a1 a1Var) {
        this.a = a1Var;
    }
}
