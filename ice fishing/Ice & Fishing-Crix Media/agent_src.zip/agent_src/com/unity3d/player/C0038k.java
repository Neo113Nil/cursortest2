package com.unity3d.player;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;

/* renamed from: com.unity3d.player.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0038k extends CameraCaptureSession.StateCallback {
    public final /* synthetic */ C0048p a;

    public C0038k(C0048p c0048p) {
        this.a = c0048p;
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public void onConfigured(CameraCaptureSession cameraCaptureSession) {
        C0048p c0048p = this.a;
        if (c0048p.b == null) {
            return;
        }
        synchronized (c0048p.t) {
            C0048p c0048p2 = this.a;
            c0048p2.r = cameraCaptureSession;
            try {
                c0048p2.q = c0048p2.b.createCaptureRequest(1);
                C0048p c0048p3 = this.a;
                c0048p3.q.addTarget(c0048p3.w);
                C0048p c0048p4 = this.a;
                c0048p4.q.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, c0048p4.n);
                this.a.e();
            } catch (CameraAccessException e) {
                com.unity3d.player.a.t.Log(6, "Camera2: CameraAccessException " + e);
            } catch (IllegalStateException e2) {
                com.unity3d.player.a.t.Log(6, "Camera2: IllegalStateException " + e2);
            }
        }
    }

    @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
    public final void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
        this.a.A = 3;
        com.unity3d.player.a.t.Log(6, "Camera2: CaptureSession configuration failed.");
    }
}
