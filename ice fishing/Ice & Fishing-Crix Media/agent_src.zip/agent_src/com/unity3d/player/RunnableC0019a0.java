package com.unity3d.player;

/* renamed from: com.unity3d.player.a0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0019a0 implements Runnable {
    public final /* synthetic */ UnityPlayer a;

    public RunnableC0019a0(UnityPlayer unityPlayer) {
        this.a = unityPlayer;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.a.setupUnityToBePaused();
        this.a.windowFocusChanged(false);
        this.a.m_UnityPlayerLifecycleEvents.onUnityPlayerUnloaded();
    }
}
