package com.unity3d.player;

import com.unity3d.player.UnityPlayer;

/* renamed from: com.unity3d.player.p0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0049p0 extends UnityPlayer.b {
    public final /* synthetic */ boolean b;
    public final /* synthetic */ C0051q0 c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0049p0(C0051q0 c0051q0, boolean z) {
        super();
        this.c = c0051q0;
        this.b = z;
    }

    @Override // com.unity3d.player.UnityPlayer.b
    public final void a() {
        UnityPlayer.permissionResponseToNative(this.c.a, this.b);
    }
}
