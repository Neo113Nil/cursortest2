package com.unity3d.player;

/* renamed from: com.unity3d.player.j0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0037j0 implements Runnable {
    public final /* synthetic */ boolean a;
    public final /* synthetic */ UnityPlayer b;

    public RunnableC0037j0(UnityPlayer unityPlayer, boolean z) {
        this.b = unityPlayer;
        this.a = z;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean shouldRunWithoutFocus;
        this.b.m_RunWithoutFocus = this.a;
        shouldRunWithoutFocus = this.b.shouldRunWithoutFocus();
        if (shouldRunWithoutFocus) {
            return;
        }
        UnityPlayer unityPlayer = this.b;
        com.unity3d.player.a.S s = unityPlayer.mState;
        if (s.a || s.c) {
            return;
        }
        unityPlayer.setupUnityToBePaused();
    }
}
