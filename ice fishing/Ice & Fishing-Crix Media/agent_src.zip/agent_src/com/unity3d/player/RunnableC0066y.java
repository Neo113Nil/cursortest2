package com.unity3d.player;

/* renamed from: com.unity3d.player.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0066y implements Runnable {
    public final /* synthetic */ DialogC0068z a;

    public RunnableC0066y(DialogC0068z dialogC0068z) {
        this.a = dialogC0068z;
    }

    @Override // java.lang.Runnable
    public final void run() {
        E e = this.a.d;
        e.a(e.b(), true);
    }
}
