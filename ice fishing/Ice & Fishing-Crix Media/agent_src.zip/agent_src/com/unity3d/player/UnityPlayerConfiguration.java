package com.unity3d.player;

/* loaded from: classes.dex */
public final class UnityPlayerConfiguration {
    public static boolean isDebugMode() {
        return false;
    }

    public static boolean isDevelopmentPlayer() {
        return false;
    }

    public static String getUnityVersion() {
        return "6000.4.7f1";
    }
}
