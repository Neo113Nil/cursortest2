package com.unity3d.player;

/* loaded from: classes.dex */
public final class c1 implements Runnable {
    public final /* synthetic */ e1 a;

    public c1(e1 e1Var) {
        this.a = e1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        e1 e1Var = this.a;
        VideoPlayer videoPlayer = e1Var.f;
        if (videoPlayer != null) {
            e1Var.a.addViewToPlayer(videoPlayer, true);
            e1 e1Var2 = this.a;
            e1Var2.i = true;
            e1Var2.f.requestFocus();
        }
    }
}
