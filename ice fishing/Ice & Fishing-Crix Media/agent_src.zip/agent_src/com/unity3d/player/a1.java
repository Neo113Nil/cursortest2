package com.unity3d.player;

import android.widget.FrameLayout;

/* loaded from: classes.dex */
public final class a1 implements Runnable {
    public final /* synthetic */ String a;
    public final /* synthetic */ int b;
    public final /* synthetic */ int c;
    public final /* synthetic */ int d;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ long f;
    public final /* synthetic */ long g;
    public final /* synthetic */ e1 h;

    public a1(e1 e1Var, String str, int i, int i2, int i3, boolean z, long j, long j2) {
        this.h = e1Var;
        this.a = str;
        this.b = i;
        this.c = i2;
        this.d = i3;
        this.e = z;
        this.f = j;
        this.g = j2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        e1 e1Var = this.h;
        if (e1Var.f != null) {
            com.unity3d.player.a.t.Log(5, "Video already playing");
            e1 e1Var2 = this.h;
            e1Var2.g = 2;
            e1Var2.d.release();
            return;
        }
        e1 e1Var3 = this.h;
        e1Var.f = new VideoPlayer(e1Var3.b, e1Var3.a, this.a, this.b, this.c, this.d, this.e, this.f, this.g, new Z0(this));
        e1 e1Var4 = this.h;
        if (e1Var4.f != null) {
            FrameLayout frameLayout = e1Var4.a.getFrameLayout();
            frameLayout.bringToFront();
            frameLayout.addView(this.h.f);
        }
    }
}
