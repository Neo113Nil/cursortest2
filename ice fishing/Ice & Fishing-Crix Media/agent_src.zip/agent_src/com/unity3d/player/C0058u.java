package com.unity3d.player;

/* renamed from: com.unity3d.player.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0058u {
    public long a;
    public final boolean b;

    public C0058u(long j, boolean z) {
        this.a = j;
        this.b = z;
    }
}
