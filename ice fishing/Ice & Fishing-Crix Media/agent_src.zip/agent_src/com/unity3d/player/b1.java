package com.unity3d.player;

/* loaded from: classes.dex */
public final class b1 implements Runnable {
    public final /* synthetic */ e1 a;

    public b1(e1 e1Var) {
        this.a = e1Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.a.a.onPause();
    }
}
