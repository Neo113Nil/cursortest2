package com.unity3d.player;

/* loaded from: classes.dex */
public final class O0 {
    public final /* synthetic */ P0 a;

    public O0(P0 p0) {
        this.a = p0;
    }

    public final void a() {
        this.a.m.nativeSoftInputLostFocus();
        this.a.m.reportSoftInputStr(null, 1, false);
    }
}
