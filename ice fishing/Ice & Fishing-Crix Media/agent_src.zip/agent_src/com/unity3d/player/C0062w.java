package com.unity3d.player;

import android.view.KeyEvent;
import android.widget.TextView;

/* renamed from: com.unity3d.player.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0062w implements TextView.OnEditorActionListener {
    public final /* synthetic */ AbstractC0064x a;

    public C0062w(AbstractC0064x abstractC0064x) {
        this.a = abstractC0064x;
    }

    @Override // android.widget.TextView.OnEditorActionListener
    public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i == 6) {
            AbstractC0064x abstractC0064x = this.a;
            abstractC0064x.a(abstractC0064x.b(), false);
        }
        return false;
    }
}
