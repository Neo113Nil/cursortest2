package com.unity3d.player;

/* loaded from: classes.dex */
public final class X0 implements Runnable {
    public final VideoPlayer a;
    public boolean b = false;

    public X0(VideoPlayer videoPlayer) {
        this.a = videoPlayer;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z;
        try {
            Thread.sleep(5000L);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
        if (this.b) {
            return;
        }
        z = VideoPlayer.LOG;
        if (z) {
            VideoPlayer.Log("Stopping the video player due to timeout.");
        }
        this.a.cancelOnPrepare();
    }
}
