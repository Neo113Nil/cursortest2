package com.unity3d.player;

import android.content.Context;
import android.widget.FrameLayout;
import com.unity3d.player.a.C0007g;

/* loaded from: classes.dex */
public final class V extends FrameLayout {
    public final C0007g a;
    public final UnityPlayerForActivityOrService b;
    public final com.unity3d.player.a.C c;

    public V(UnityPlayerForActivityOrService unityPlayerForActivityOrService) {
        super(unityPlayerForActivityOrService.getContext());
        Context context = unityPlayerForActivityOrService.getContext();
        this.c = new com.unity3d.player.a.C(context);
        this.b = unityPlayerForActivityOrService;
        C0007g c0007g = new C0007g(unityPlayerForActivityOrService);
        this.a = c0007g;
        c0007g.setId(context.getResources().getIdentifier("unitySurfaceView", "id", context.getPackageName()));
        unityPlayerForActivityOrService.applySurfaceViewSettings(c0007g);
        c0007g.getHolder().addCallback(new U(this));
        c0007g.setFocusable(true);
        c0007g.setFocusableInTouchMode(true);
        c0007g.setContentDescription(context.getResources().getString(context.getResources().getIdentifier("game_view_content_description", "string", context.getPackageName())));
        addView(c0007g, new FrameLayout.LayoutParams(-1, -1, 17));
    }
}
