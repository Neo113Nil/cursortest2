package com.unity3d.player;

import android.graphics.SurfaceTexture;

/* renamed from: com.unity3d.player.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0044n implements SurfaceTexture.OnFrameAvailableListener {
    public final /* synthetic */ C0048p a;

    public C0044n(C0048p c0048p) {
        this.a = c0048p;
    }

    @Override // android.graphics.SurfaceTexture.OnFrameAvailableListener
    public final void onFrameAvailable(SurfaceTexture surfaceTexture) {
        ((Camera2Wrapper) this.a.a).a(surfaceTexture);
    }
}
