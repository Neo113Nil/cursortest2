package com.unity3d.player;

/* loaded from: classes.dex */
public final class Y0 implements Runnable {
    public final /* synthetic */ Z0 a;

    public Y0(Z0 z0) {
        this.a = z0;
    }

    @Override // java.lang.Runnable
    public final void run() {
        e1 e1Var = this.a.a.h;
        VideoPlayer videoPlayer = e1Var.f;
        if (videoPlayer != null) {
            e1Var.a.removeViewFromPlayer(videoPlayer);
            e1Var.i = false;
            e1Var.f.destroyPlayer();
            e1Var.f = null;
            C0041l0 c0041l0 = e1Var.c;
            if (c0041l0 != null) {
                c0041l0.a();
            }
        }
        this.a.a.h.a.onResume();
    }
}
