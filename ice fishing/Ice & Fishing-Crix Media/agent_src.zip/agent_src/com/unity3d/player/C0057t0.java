package com.unity3d.player;

/* renamed from: com.unity3d.player.t0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0057t0 {
    public final /* synthetic */ RunnableC0059u0 a;

    public C0057t0(RunnableC0059u0 runnableC0059u0) {
        this.a = runnableC0059u0;
    }
}
