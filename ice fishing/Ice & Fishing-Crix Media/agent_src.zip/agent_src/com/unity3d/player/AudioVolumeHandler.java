package com.unity3d.player;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import com.unity3d.player.a.C0008h;
import com.unity3d.player.a.C0010j;
import com.unity3d.player.a.InterfaceC0009i;

/* loaded from: classes.dex */
public class AudioVolumeHandler implements InterfaceC0009i {
    public C0010j a;

    @Override // com.unity3d.player.a.InterfaceC0009i
    public final native void onAudioVolumeChanged(int i);

    public AudioVolumeHandler(Context context) {
        C0010j c0010j = new C0010j(context);
        this.a = c0010j;
        c0010j.c = new C0008h(new Handler(Looper.getMainLooper()), c0010j.b, this);
        context.getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, c0010j.c);
    }
}
