package com.unity3d.player;

/* renamed from: com.unity3d.player.l0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0041l0 {
    public final /* synthetic */ UnityPlayer a;

    public C0041l0(UnityPlayer unityPlayer) {
        this.a = unityPlayer;
    }

    public final void a() {
        this.a.mVideoPlayerProxy = null;
    }
}
