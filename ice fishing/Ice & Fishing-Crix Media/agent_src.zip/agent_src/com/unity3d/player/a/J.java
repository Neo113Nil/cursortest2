package com.unity3d.player.a;

import android.content.DialogInterface;
import com.unity3d.player.O0;

/* loaded from: classes.dex */
public final class J implements DialogInterface.OnCancelListener {
    public final /* synthetic */ com.unity3d.player.E a;

    public J(com.unity3d.player.E e) {
        this.a = e;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        O0 o0 = this.a.f;
        if (o0 != null) {
            o0.a();
        }
    }
}
