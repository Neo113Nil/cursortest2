package com.unity3d.player.a;

import com.unity3d.player.C0057t0;
import com.unity3d.player.O0;

/* loaded from: classes.dex */
public interface r {
    void a();

    void a(O0 o0);

    void a(C0057t0 c0057t0);

    void a(String str, int i, boolean z, boolean z2, boolean z3, boolean z4, String str2, int i2, boolean z5, boolean z6);

    void hide();

    boolean isConsumeOutsideTouchesEnabled();

    void setCharacterLimit(int i);

    void setHideInputField(boolean z);

    void setSelection(int i, int i2);

    void setText(String str);
}
