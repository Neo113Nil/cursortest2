package com.unity3d.player.a;

import android.content.Context;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import com.unity3d.player.C0048p;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/* renamed from: com.unity3d.player.a.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0014n extends C0048p {
    public static HashMap F;
    public String E;

    public C0014n(InterfaceC0017q interfaceC0017q) {
        super(interfaceC0017q);
        this.E = null;
    }

    public static String[] a(Context context) {
        String[] cameraIdList = C0048p.getCameraManager(context).getCameraIdList();
        ArrayList arrayList = new ArrayList();
        F = new HashMap();
        for (String str : cameraIdList) {
            arrayList.add(str);
            F.put(str, str);
        }
        for (String str2 : cameraIdList) {
            CameraCharacteristics cameraCharacteristics = C0048p.getCameraManager(context).getCameraCharacteristics(str2);
            int[] iArr = (int[]) cameraCharacteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            int length = iArr.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    t.Log(4, "Camera2 " + str2 + " is a simple camera");
                    break;
                }
                if (iArr[i] == 11) {
                    t.Log(4, "Camera2 " + str2 + " is a logical camera backed by two or more physical cameras");
                    for (String str3 : cameraCharacteristics.getPhysicalCameraIds()) {
                        if (arrayList.indexOf(str3) == -1) {
                            arrayList.add(str3);
                            F.put(str3, str2);
                        }
                        t.Log(4, "Physical camera2 found : " + str3);
                    }
                } else {
                    i++;
                }
            }
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    @Override // com.unity3d.player.C0048p
    public String getCameraIdToOpen(Context context, int i) {
        String str = C0048p.getCameraIds(context)[i];
        String str2 = (String) F.get(str);
        if (str2.equals(str)) {
            this.E = null;
            return str;
        }
        this.E = str;
        return str2;
    }

    @Override // com.unity3d.player.C0048p
    public CameraCaptureSession.CaptureCallback getCaptureCallback() {
        if (this.s == null) {
            this.s = new C0012l(this);
        }
        return this.s;
    }

    @Override // com.unity3d.player.C0048p
    public void createCaptureSession(CameraCaptureSession.StateCallback stateCallback) {
        OutputConfiguration outputConfiguration = new OutputConfiguration(this.w);
        String str = this.E;
        if (str != null) {
            outputConfiguration.setPhysicalCameraId(str);
        }
        this.b.createCaptureSession(new SessionConfiguration(0, Collections.singletonList(outputConfiguration), new ExecutorC0013m(this.d), stateCallback));
    }
}
