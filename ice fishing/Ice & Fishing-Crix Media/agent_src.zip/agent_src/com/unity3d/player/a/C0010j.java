package com.unity3d.player.a;

import android.content.Context;
import android.media.AudioManager;

/* renamed from: com.unity3d.player.a.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0010j {
    public final Context a;
    public final AudioManager b;
    public C0008h c;

    public C0010j(Context context) {
        this.a = context;
        this.b = (AudioManager) context.getSystemService("audio");
    }
}
