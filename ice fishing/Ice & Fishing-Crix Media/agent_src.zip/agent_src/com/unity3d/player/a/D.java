package com.unity3d.player.a;

/* loaded from: classes.dex */
public final class D extends C0004d {
    public D() {
        this.a = false;
    }
}
