package com.unity3d.player.a;

/* JADX WARN: $VALUES field not found */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: com.unity3d.player.a.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0015o {
    public static final EnumC0015o b = new EnumC0015o("ActivityOrService", 0, 0);
    public static final EnumC0015o c = new EnumC0015o("GameActivity", 1, 1);
    public final int a;

    public EnumC0015o(String str, int i, int i2) {
        this.a = i2;
    }
}
