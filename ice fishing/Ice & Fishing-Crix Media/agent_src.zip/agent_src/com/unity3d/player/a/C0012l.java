package com.unity3d.player.a;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.view.Surface;
import com.unity3d.player.C0046o;

/* renamed from: com.unity3d.player.a.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0012l extends C0046o {
    @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
    public final void onCaptureBufferLost(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, Surface surface, long j) {
    }

    public C0012l(C0014n c0014n) {
        super(c0014n);
    }
}
