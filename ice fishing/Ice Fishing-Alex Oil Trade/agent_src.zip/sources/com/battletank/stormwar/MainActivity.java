package com.battletank.stormwar;

/* loaded from: classes.dex */
public final class MainActivity extends e0.AbstractActivityC0107f {

    /* renamed from: j, reason: collision with root package name */
    public static final /* synthetic */ int f1668j = 0;
}
