package e0;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1787a = false;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ e0.z f1788b;

    public y(e0.z zVar) {
        this.f1788b = zVar;
    }

    public final void a(boolean z2) {
        if (this.f1787a) {
            throw new java.lang.IllegalStateException("The onKeyEventHandledCallback should be called exactly once.");
        }
        this.f1787a = true;
        e0.z zVar = this.f1788b;
        int i2 = zVar.f1790b - 1;
        zVar.f1790b = i2;
        boolean z3 = z2 | zVar.f1791c;
        zVar.f1791c = z3;
        if (i2 != 0 || z3) {
            return;
        }
        zVar.f1792d.F(zVar.f1789a);
    }
}
