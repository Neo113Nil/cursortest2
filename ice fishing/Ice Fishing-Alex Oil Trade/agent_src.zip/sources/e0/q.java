package e0;

/* loaded from: classes.dex */
public final class q implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ io.flutter.embedding.engine.renderer.h f1740a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ androidx.lifecycle.k f1741b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ e0.r f1742c;

    public q(e0.r rVar, io.flutter.embedding.engine.renderer.h hVar, androidx.lifecycle.k kVar) {
        this.f1742c = rVar;
        this.f1740a = hVar;
        this.f1741b = kVar;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
        e0.C0111j c0111j;
        this.f1740a.c(this);
        this.f1741b.run();
        e0.r rVar = this.f1742c;
        if ((rVar.f1753i instanceof e0.C0111j) || (c0111j = rVar.f1752h) == null) {
            return;
        }
        c0111j.d();
        e0.C0111j c0111j2 = rVar.f1752h;
        if (c0111j2 != null) {
            c0111j2.f1720e.close();
            rVar.removeView(rVar.f1752h);
            rVar.f1752h = null;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
    }
}
