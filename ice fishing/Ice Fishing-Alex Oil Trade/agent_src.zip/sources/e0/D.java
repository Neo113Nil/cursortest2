package e0;

/* loaded from: classes.dex */
public final class D {

    /* renamed from: a, reason: collision with root package name */
    public int f1674a;

    /* renamed from: b, reason: collision with root package name */
    public final java.lang.Object[] f1675b;

    public /* synthetic */ D(int i2, java.lang.Object[] objArr) {
        this.f1674a = i2;
        this.f1675b = objArr;
    }

    public D(int i2) {
        if (i2 <= 0) {
            throw new java.lang.IllegalArgumentException("The max pool size must be > 0");
        }
        this.f1675b = new java.lang.Object[i2];
    }
}
