package e0;

/* loaded from: classes.dex */
public final class H implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ java.lang.Runnable f1682a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ e0.J f1683b;

    public H(e0.J j2, java.lang.Runnable runnable) {
        this.f1683b = j2;
        this.f1682a = runnable;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
        this.f1682a.run();
        io.flutter.embedding.engine.renderer.h hVar = this.f1683b.f1687b;
        if (hVar != null) {
            hVar.c(this);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
    }
}
