package e0;

/* loaded from: classes.dex */
public final class m implements android.view.TextureView.SurfaceTextureListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e0.n f1733a;

    public m(e0.n nVar) {
        this.f1733a = nVar;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureAvailable(android.graphics.SurfaceTexture surfaceTexture, int i2, int i3) {
        e0.n nVar = this.f1733a;
        nVar.f1734e = true;
        if ((nVar.f1736g == null || nVar.f1735f) ? false : true) {
            nVar.e();
        }
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture surfaceTexture) {
        e0.n nVar = this.f1733a;
        boolean z2 = false;
        nVar.f1734e = false;
        io.flutter.embedding.engine.renderer.h hVar = nVar.f1736g;
        if (hVar != null && !nVar.f1735f) {
            z2 = true;
        }
        if (z2) {
            if (hVar == null) {
                throw new java.lang.IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            android.view.Surface surface = nVar.f1737h;
            if (surface != null) {
                surface.release();
                nVar.f1737h = null;
            }
        }
        android.view.Surface surface2 = nVar.f1737h;
        if (surface2 != null) {
            surface2.release();
            nVar.f1737h = null;
        }
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture surfaceTexture, int i2, int i3) {
        e0.n nVar = this.f1733a;
        io.flutter.embedding.engine.renderer.h hVar = nVar.f1736g;
        if (hVar == null || nVar.f1735f) {
            return;
        }
        if (hVar == null) {
            throw new java.lang.IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2375a.onSurfaceChanged(i2, i3);
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureUpdated(android.graphics.SurfaceTexture surfaceTexture) {
    }
}
