package e0;

/* loaded from: classes.dex */
public final class p implements io.flutter.embedding.engine.renderer.j {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e0.r f1739a;

    public p(e0.r rVar) {
        this.f1739a = rVar;
    }
}
