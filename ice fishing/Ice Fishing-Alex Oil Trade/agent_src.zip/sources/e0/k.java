package e0;

/* loaded from: classes.dex */
public final class k implements android.view.SurfaceHolder.Callback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e0.l f1727a;

    public k(e0.l lVar) {
        this.f1727a = lVar;
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(android.view.SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        e0.l lVar = this.f1727a;
        io.flutter.embedding.engine.renderer.h hVar = lVar.f1730g;
        if (hVar == null || lVar.f1729f) {
            return;
        }
        if (hVar == null) {
            throw new java.lang.IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
        }
        hVar.f2375a.onSurfaceChanged(i3, i4);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(android.view.SurfaceHolder surfaceHolder) {
        e0.l lVar = this.f1727a;
        lVar.f1728e = true;
        if ((lVar.f1730g == null || lVar.f1729f) ? false : true) {
            lVar.e();
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(android.view.SurfaceHolder surfaceHolder) {
        e0.l lVar = this.f1727a;
        boolean z2 = false;
        lVar.f1728e = false;
        io.flutter.embedding.engine.renderer.h hVar = lVar.f1730g;
        if (hVar != null && !lVar.f1729f) {
            z2 = true;
        }
        if (z2) {
            if (hVar == null) {
                throw new java.lang.IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
        }
    }
}
