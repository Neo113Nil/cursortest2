package e0;

/* loaded from: classes.dex */
public final class I {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1684a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ e0.J f1685b;

    public /* synthetic */ I(e0.J j2, int i2) {
        this.f1684a = i2;
        this.f1685b = j2;
    }

    private final void a() {
    }
}
