package e0;

/* renamed from: e0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0108g implements io.flutter.embedding.engine.renderer.i {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1704a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ java.lang.Object f1705b;

    public /* synthetic */ C0108g(int i2, java.lang.Object obj) {
        this.f1704a = i2;
        this.f1705b = obj;
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void a() {
        switch (this.f1704a) {
            case 0:
                e0.C0110i c0110i = (e0.C0110i) this.f1705b;
                e0.AbstractActivityC0107f abstractActivityC0107f = c0110i.f1708a;
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    abstractActivityC0107f.reportFullyDrawn();
                } else {
                    abstractActivityC0107f.getClass();
                }
                c0110i.f1715h = true;
                c0110i.f1716i = true;
                break;
            case 1:
                e0.r rVar = (e0.r) this.f1705b;
                rVar.f1756l = true;
                java.util.Iterator it = rVar.f1755k.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).a();
                }
                break;
            case G.k.FLOAT_FIELD_NUMBER /* 2 */:
                e0.J j2 = (e0.J) this.f1705b;
                j2.f1686a.setAlpha(1.0f);
                io.flutter.embedding.engine.renderer.h hVar = j2.f1687b;
                if (hVar != null) {
                    hVar.c(this);
                    break;
                }
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1705b).f2377c = true;
                break;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.i
    public final void b() {
        switch (this.f1704a) {
            case 0:
                e0.C0110i c0110i = (e0.C0110i) this.f1705b;
                c0110i.f1708a.getClass();
                c0110i.f1715h = false;
                break;
            case 1:
                e0.r rVar = (e0.r) this.f1705b;
                rVar.f1756l = false;
                java.util.Iterator it = rVar.f1755k.iterator();
                while (it.hasNext()) {
                    ((io.flutter.embedding.engine.renderer.i) it.next()).b();
                }
                break;
            case G.k.FLOAT_FIELD_NUMBER /* 2 */:
                break;
            default:
                ((io.flutter.embedding.engine.renderer.h) this.f1705b).f2377c = false;
                break;
        }
    }

    private final void c() {
    }
}
