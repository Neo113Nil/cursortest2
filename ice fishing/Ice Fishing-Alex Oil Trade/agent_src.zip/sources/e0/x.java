package e0;

/* loaded from: classes.dex */
public final class x implements e0.InterfaceC0101A {

    /* renamed from: e, reason: collision with root package name */
    public final o0.f f1783e;

    /* renamed from: f, reason: collision with root package name */
    public final java.util.HashMap f1784f = new java.util.HashMap();

    /* renamed from: g, reason: collision with root package name */
    public final java.util.HashMap f1785g;

    /* renamed from: h, reason: collision with root package name */
    public final U0.i f1786h;

    public x(o0.f fVar) {
        java.util.HashMap map = new java.util.HashMap();
        this.f1785g = map;
        this.f1786h = new U0.i();
        this.f1783e = fVar;
        e0.B b2 = e0.F.f1677a;
        e0.E e2 = new e0.E();
        e2.f1676a = false;
        e0.E e3 = new e0.E[]{e2}[0];
        e3.getClass();
        map.put(4294967556L, e3);
    }

    public final void a(e0.u uVar, final e0.y yVar) throws java.io.UnsupportedEncodingException {
        long j2;
        long j3;
        byte[] bytes = null;
        o0.e eVar = yVar == null ? null : new o0.e() { // from class: e0.v
            @Override // o0.e
            public final void a(java.nio.ByteBuffer byteBuffer) {
                java.lang.Boolean boolValueOf = java.lang.Boolean.FALSE;
                if (byteBuffer != null) {
                    byteBuffer.rewind();
                    if (byteBuffer.capacity() != 0) {
                        boolValueOf = java.lang.Boolean.valueOf(byteBuffer.get() != 0);
                    }
                } else {
                    android.util.Log.w("KeyEmbedderResponder", "A null reply was received when sending a key event to the framework.");
                }
                yVar.a(boolValueOf.booleanValue());
            }
        };
        try {
            java.lang.String str = uVar.f1776g;
            if (str != null) {
                bytes = str.getBytes("UTF-8");
            }
            int length = bytes == null ? 0 : bytes.length;
            java.nio.ByteBuffer byteBufferAllocateDirect = java.nio.ByteBuffer.allocateDirect(length + 56);
            byteBufferAllocateDirect.order(java.nio.ByteOrder.LITTLE_ENDIAN);
            byteBufferAllocateDirect.putLong(length);
            byteBufferAllocateDirect.putLong(uVar.f1770a);
            int i2 = uVar.f1771b;
            if (i2 == 1) {
                j2 = 0;
            } else if (i2 == 2) {
                j2 = 1;
            } else {
                if (i2 != 3) {
                    throw null;
                }
                j2 = 2;
            }
            byteBufferAllocateDirect.putLong(j2);
            byteBufferAllocateDirect.putLong(uVar.f1772c);
            byteBufferAllocateDirect.putLong(uVar.f1773d);
            byteBufferAllocateDirect.putLong(uVar.f1774e ? 1L : 0L);
            int i3 = uVar.f1775f;
            if (i3 == 1) {
                j3 = 0;
            } else if (i3 == 2) {
                j3 = 1;
            } else if (i3 == 3) {
                j3 = 2;
            } else if (i3 == 4) {
                j3 = 3;
            } else {
                if (i3 != 5) {
                    throw null;
                }
                j3 = 4;
            }
            byteBufferAllocateDirect.putLong(j3);
            if (bytes != null) {
                byteBufferAllocateDirect.put(bytes);
            }
            this.f1783e.n("flutter/keydata", byteBufferAllocateDirect, eVar);
        } catch (java.io.UnsupportedEncodingException unused) {
            throw new java.lang.AssertionError("UTF-8 not supported");
        }
    }

    public final void b(boolean z2, java.lang.Long l2, java.lang.Long l3, long j2) throws java.io.UnsupportedEncodingException {
        e0.u uVar = new e0.u();
        uVar.f1770a = j2;
        uVar.f1771b = z2 ? 1 : 2;
        uVar.f1773d = l2.longValue();
        uVar.f1772c = l3.longValue();
        uVar.f1776g = null;
        uVar.f1774e = true;
        uVar.f1775f = 1;
        if (l3.longValue() != 0 && l2.longValue() != 0) {
            if (!z2) {
                l2 = null;
            }
            c(l3, l2);
        }
        a(uVar, null);
    }

    public final void c(java.lang.Long l2, java.lang.Long l3) {
        java.util.HashMap map = this.f1784f;
        if (l3 != null) {
            if (((java.lang.Long) map.put(l2, l3)) != null) {
                throw new java.lang.AssertionError("The key was not empty");
            }
        } else if (((java.lang.Long) map.remove(l2)) == null) {
            throw new java.lang.AssertionError("The key was empty");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:138:0x02ed  */
    /* JADX WARN: Removed duplicated region for block: B:139:0x02fc  */
    @Override // e0.InterfaceC0101A
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void f(final android.view.KeyEvent keyEvent, e0.y yVar) throws java.io.UnsupportedEncodingException {
        java.lang.Long lValueOf;
        boolean z2;
        int i2;
        int i3;
        java.lang.String str;
        e0.E e2;
        long j2;
        java.util.HashMap map;
        java.lang.Boolean[] boolArr;
        java.util.HashMap map2;
        int i4;
        e0.D[] dArr;
        boolean[] zArr;
        int i5;
        int i6;
        int i7;
        int i8;
        if (keyEvent.getScanCode() == 0 && keyEvent.getKeyCode() == 0) {
            j2 = 0;
        } else {
            long scanCode = keyEvent.getScanCode();
            if (scanCode == 0) {
                lValueOf = java.lang.Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            } else {
                lValueOf = (java.lang.Long) e0.F.f1677a.get(java.lang.Long.valueOf(scanCode));
                if (lValueOf == null) {
                    lValueOf = java.lang.Long.valueOf((keyEvent.getScanCode() & 4294967295L) | 73014444032L);
                }
            }
            java.lang.Long l2 = lValueOf;
            java.lang.Long lValueOf2 = (java.lang.Long) e0.F.f1678b.get(java.lang.Long.valueOf(keyEvent.getKeyCode()));
            if (lValueOf2 == null) {
                lValueOf2 = java.lang.Long.valueOf((keyEvent.getKeyCode() & 4294967295L) | 73014444032L);
            }
            java.lang.Long l3 = lValueOf2;
            java.util.ArrayList arrayList = new java.util.ArrayList();
            e0.D[] dArr2 = e0.F.f1679c;
            int length = dArr2.length;
            int i9 = 0;
            while (true) {
                java.util.HashMap map3 = this.f1784f;
                int i10 = 2;
                if (i9 >= length) {
                    java.util.HashMap map4 = map3;
                    boolean z3 = false;
                    java.util.HashMap map5 = this.f1785g;
                    for (e0.E e3 : map5.values()) {
                        int metaState = keyEvent.getMetaState();
                        e3.getClass();
                        boolean z4 = (metaState & 1048576) != 0 ? true : z3;
                        if (4294967556L == l3.longValue() || e3.f1676a == z4) {
                            map = map4;
                        } else {
                            java.util.HashMap map6 = map4;
                            boolean zContainsKey = map6.containsKey(458809L);
                            boolean z5 = !zContainsKey;
                            if (!zContainsKey) {
                                e3.f1676a = !e3.f1676a;
                            }
                            map = map6;
                            b(z5, 4294967556L, 458809L, keyEvent.getEventTime());
                            if (zContainsKey) {
                                e3.f1676a = !e3.f1676a;
                            }
                            b(zContainsKey, 4294967556L, 458809L, keyEvent.getEventTime());
                        }
                        map4 = map;
                        z3 = false;
                    }
                    java.util.HashMap map7 = map4;
                    int action = keyEvent.getAction();
                    if (action != 0) {
                        z2 = action != 1;
                        j2 = 0;
                    }
                    java.lang.Long l4 = (java.lang.Long) map7.get(l2);
                    if (!z2) {
                        if (l4 != null) {
                            i2 = 1;
                            i3 = 2;
                            str = null;
                        }
                        j2 = 0;
                    } else if (l4 == null) {
                        i3 = 1;
                        char cCharValue = this.f1786h.a(keyEvent.getUnicodeChar()).charValue();
                        if (cCharValue != 0) {
                        }
                        str = cCharValue != 0 ? "" + cCharValue : null;
                        i2 = 1;
                    } else if (keyEvent.getRepeatCount() > 0) {
                        i3 = 3;
                        char cCharValue2 = this.f1786h.a(keyEvent.getUnicodeChar()).charValue();
                        str = cCharValue2 != 0 ? "" + cCharValue2 : null;
                        i2 = 1;
                    } else {
                        b(false, l4, l2, keyEvent.getEventTime());
                        i3 = 1;
                        char cCharValue22 = this.f1786h.a(keyEvent.getUnicodeChar()).charValue();
                        if (cCharValue22 != 0) {
                        }
                        str = cCharValue22 != 0 ? "" + cCharValue22 : null;
                        i2 = 1;
                    }
                    if (i3 != 3) {
                        c(l2, z2 ? l3 : null);
                    }
                    if (i3 == i2 && (e2 = (e0.E) map5.get(l3)) != null) {
                        e2.f1676a = (e2.f1676a ? 1 : 0) ^ i2;
                    }
                    e0.u uVar = new e0.u();
                    int source = keyEvent.getSource();
                    if (source == 513) {
                        uVar.f1775f = 2;
                    } else if (source == 1025) {
                        uVar.f1775f = 3;
                    } else if (source == 16777232) {
                        uVar.f1775f = 4;
                    } else if (source != 33554433) {
                        uVar.f1775f = 1;
                    } else {
                        uVar.f1775f = 5;
                    }
                    uVar.f1770a = keyEvent.getEventTime();
                    uVar.f1771b = i3;
                    uVar.f1773d = l3.longValue();
                    uVar.f1772c = l2.longValue();
                    uVar.f1776g = str;
                    uVar.f1774e = false;
                    a(uVar, yVar);
                    java.util.Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        ((java.lang.Runnable) it.next()).run();
                    }
                    return;
                }
                e0.D d2 = dArr2[i9];
                boolean z6 = (keyEvent.getMetaState() & d2.f1674a) != 0;
                long jLongValue = l3.longValue();
                final long jLongValue2 = l2.longValue();
                e0.C[] cArr = (e0.C[]) d2.f1675b;
                boolean[] zArr2 = new boolean[2];
                java.lang.Boolean[] boolArr2 = new java.lang.Boolean[2];
                int i11 = 0;
                boolean z7 = false;
                while (i11 < i10) {
                    final e0.C c2 = cArr[i11];
                    boolean[] zArr3 = zArr2;
                    boolean zContainsKey2 = map3.containsKey(java.lang.Long.valueOf(c2.f1672a));
                    zArr3[i11] = zContainsKey2;
                    int i12 = i11;
                    if (c2.f1673b == jLongValue) {
                        boolean z8 = keyEvent.getRepeatCount() > 0;
                        int action2 = keyEvent.getAction();
                        if (action2 == 0) {
                            i7 = z8 ? 3 : 1;
                        } else {
                            if (action2 != 1) {
                                throw new java.lang.AssertionError("Unexpected event type");
                            }
                            i7 = 2;
                        }
                        int iB = G.j.b(i7);
                        if (iB == 0) {
                            boolArr = boolArr2;
                            map2 = map3;
                            i4 = length;
                            dArr = dArr2;
                            zArr = zArr3;
                            i5 = 2;
                            i6 = i9;
                            boolArr[i12] = java.lang.Boolean.FALSE;
                            if (!z6) {
                                final int i13 = 0;
                                arrayList.add(new java.lang.Runnable(this) { // from class: e0.w

                                    /* renamed from: f, reason: collision with root package name */
                                    public final /* synthetic */ e0.x f1779f;

                                    {
                                        this.f1779f = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() throws java.io.UnsupportedEncodingException {
                                        switch (i13) {
                                            case 0:
                                                e0.x xVar = this.f1779f;
                                                xVar.getClass();
                                                xVar.b(false, java.lang.Long.valueOf(c2.f1673b), java.lang.Long.valueOf(jLongValue2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                e0.x xVar2 = this.f1779f;
                                                xVar2.getClass();
                                                xVar2.b(false, java.lang.Long.valueOf(c2.f1673b), java.lang.Long.valueOf(jLongValue2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                        } else if (iB == 1) {
                            boolArr = boolArr2;
                            map2 = map3;
                            i4 = length;
                            dArr = dArr2;
                            zArr = zArr3;
                            i5 = 2;
                            i6 = i9;
                            boolArr[i12] = java.lang.Boolean.valueOf(zArr[i12]);
                        } else if (iB != 2) {
                            boolArr = boolArr2;
                            i5 = 2;
                            map2 = map3;
                            i4 = length;
                            dArr = dArr2;
                            zArr = zArr3;
                            i6 = i9;
                        } else {
                            if (z6) {
                                boolArr = boolArr2;
                                i8 = 2;
                                map2 = map3;
                                i4 = length;
                                dArr = dArr2;
                                zArr = zArr3;
                                i6 = i9;
                            } else {
                                final int i14 = 1;
                                boolArr = boolArr2;
                                i8 = 2;
                                zArr = zArr3;
                                i6 = i9;
                                map2 = map3;
                                dArr = dArr2;
                                i4 = length;
                                arrayList.add(new java.lang.Runnable(this) { // from class: e0.w

                                    /* renamed from: f, reason: collision with root package name */
                                    public final /* synthetic */ e0.x f1779f;

                                    {
                                        this.f1779f = this;
                                    }

                                    @Override // java.lang.Runnable
                                    public final void run() throws java.io.UnsupportedEncodingException {
                                        switch (i14) {
                                            case 0:
                                                e0.x xVar = this.f1779f;
                                                xVar.getClass();
                                                xVar.b(false, java.lang.Long.valueOf(c2.f1673b), java.lang.Long.valueOf(jLongValue2), keyEvent.getEventTime());
                                                break;
                                            default:
                                                e0.x xVar2 = this.f1779f;
                                                xVar2.getClass();
                                                xVar2.b(false, java.lang.Long.valueOf(c2.f1673b), java.lang.Long.valueOf(jLongValue2), keyEvent.getEventTime());
                                                break;
                                        }
                                    }
                                });
                            }
                            boolArr[i12] = java.lang.Boolean.valueOf(zArr[i12]);
                            i5 = i8;
                        }
                        z7 = true;
                    } else {
                        boolArr = boolArr2;
                        map2 = map3;
                        i4 = length;
                        dArr = dArr2;
                        zArr = zArr3;
                        i5 = 2;
                        i6 = i9;
                        z7 = z7 || zContainsKey2;
                    }
                    i11 = i12 + 1;
                    i10 = i5;
                    zArr2 = zArr;
                    length = i4;
                    boolArr2 = boolArr;
                    i9 = i6;
                    dArr2 = dArr;
                    map3 = map2;
                }
                java.lang.Boolean[] boolArr3 = boolArr2;
                int i15 = i10;
                boolean[] zArr4 = zArr2;
                int i16 = i9;
                int i17 = length;
                e0.D[] dArr3 = dArr2;
                boolean z9 = keyEvent.getDeviceId() == -1;
                if (z6) {
                    for (int i18 = 0; i18 < i15; i18++) {
                        if (boolArr3[i18] == null) {
                            if (z7 || z9) {
                                boolArr3[i18] = java.lang.Boolean.valueOf(zArr4[i18]);
                            } else {
                                boolArr3[i18] = java.lang.Boolean.TRUE;
                                z7 = true;
                            }
                        }
                    }
                    if (!z7 && !z9) {
                        boolArr3[0] = java.lang.Boolean.TRUE;
                    }
                } else {
                    for (int i19 = 0; i19 < i15; i19++) {
                        if (boolArr3[i19] == null) {
                            boolArr3[i19] = java.lang.Boolean.FALSE;
                        }
                    }
                }
                for (int i20 = 0; i20 < i15; i20++) {
                    if (zArr4[i20] != boolArr3[i20].booleanValue()) {
                        e0.C c3 = cArr[i20];
                        b(boolArr3[i20].booleanValue(), java.lang.Long.valueOf(c3.f1673b), java.lang.Long.valueOf(c3.f1672a), keyEvent.getEventTime());
                    }
                }
                i9 = i16 + 1;
                length = i17;
                dArr2 = dArr3;
            }
        }
        b(true, java.lang.Long.valueOf(j2), java.lang.Long.valueOf(j2), 0L);
        yVar.a(true);
    }
}
