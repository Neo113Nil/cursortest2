package e0;

/* loaded from: classes.dex */
public final class J implements android.view.SurfaceHolder.Callback2 {

    /* renamed from: a, reason: collision with root package name */
    public final e0.l f1686a;

    /* renamed from: b, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1687b;

    /* renamed from: c, reason: collision with root package name */
    public final e0.k f1688c;

    /* renamed from: d, reason: collision with root package name */
    public final e0.C0108g f1689d = new e0.C0108g(2, this);

    /* renamed from: e, reason: collision with root package name */
    public final e0.I f1690e;

    public J(e0.k kVar, e0.l lVar, io.flutter.embedding.engine.renderer.h hVar) {
        boolean z2 = android.os.Build.VERSION.SDK_INT < 26;
        this.f1690e = z2 ? new e0.I(this, 1) : new e0.I(this, 0);
        this.f1688c = kVar;
        this.f1687b = hVar;
        this.f1686a = lVar;
        if (z2) {
            lVar.setAlpha(0.0f);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(android.view.SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        e0.k kVar = this.f1688c;
        if (kVar != null) {
            kVar.surfaceChanged(surfaceHolder, i2, i3, i4);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(android.view.SurfaceHolder surfaceHolder) {
        e0.k kVar = this.f1688c;
        if (kVar != null) {
            kVar.surfaceCreated(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(android.view.SurfaceHolder surfaceHolder) {
        e0.k kVar = this.f1688c;
        if (kVar != null) {
            kVar.surfaceDestroyed(surfaceHolder);
        }
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeededAsync(android.view.SurfaceHolder surfaceHolder, java.lang.Runnable runnable) {
        io.flutter.embedding.engine.renderer.h hVar = this.f1687b;
        if (hVar == null) {
            return;
        }
        hVar.a(new e0.H(this, runnable));
    }

    @Override // android.view.SurfaceHolder.Callback2
    public final void surfaceRedrawNeeded(android.view.SurfaceHolder surfaceHolder) {
    }
}
