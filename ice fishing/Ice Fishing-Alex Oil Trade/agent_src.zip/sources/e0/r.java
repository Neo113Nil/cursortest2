package e0;

/* loaded from: classes.dex */
public final class r extends android.widget.FrameLayout {

    /* renamed from: A, reason: collision with root package name */
    public final e0.p f1743A;

    /* renamed from: B, reason: collision with root package name */
    public final e0.C0108g f1744B;

    /* renamed from: C, reason: collision with root package name */
    public V.i f1745C;

    /* renamed from: D, reason: collision with root package name */
    public int f1746D;

    /* renamed from: E, reason: collision with root package name */
    public int f1747E;

    /* renamed from: F, reason: collision with root package name */
    public e0.t f1748F;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1749e;

    /* renamed from: f, reason: collision with root package name */
    public final e0.l f1750f;

    /* renamed from: g, reason: collision with root package name */
    public final e0.n f1751g;

    /* renamed from: h, reason: collision with root package name */
    public e0.C0111j f1752h;

    /* renamed from: i, reason: collision with root package name */
    public android.view.View f1753i;

    /* renamed from: j, reason: collision with root package name */
    public android.view.View f1754j;

    /* renamed from: k, reason: collision with root package name */
    public final java.util.HashSet f1755k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f1756l;

    /* renamed from: m, reason: collision with root package name */
    public f0.C0115c f1757m;

    /* renamed from: n, reason: collision with root package name */
    public final java.util.HashSet f1758n;

    /* renamed from: o, reason: collision with root package name */
    public M.Q f1759o;

    /* renamed from: p, reason: collision with root package name */
    public io.flutter.plugin.editing.l f1760p;

    /* renamed from: q, reason: collision with root package name */
    public io.flutter.plugin.editing.h f1761q;

    /* renamed from: r, reason: collision with root package name */
    public p0.C0226a f1762r;
    public M.C0026b s;

    /* renamed from: t, reason: collision with root package name */
    public e0.C0103b f1763t;

    /* renamed from: u, reason: collision with root package name */
    public io.flutter.view.h f1764u;

    /* renamed from: v, reason: collision with root package name */
    public android.view.textservice.TextServicesManager f1765v;

    /* renamed from: w, reason: collision with root package name */
    public B.j f1766w;

    /* renamed from: x, reason: collision with root package name */
    public final io.flutter.embedding.engine.renderer.g f1767x;

    /* renamed from: y, reason: collision with root package name */
    public final B.j f1768y;

    /* renamed from: z, reason: collision with root package name */
    public final C.a f1769z;

    public r(e0.AbstractActivityC0107f abstractActivityC0107f, e0.l lVar) {
        super(abstractActivityC0107f, null);
        this.f1749e = false;
        this.f1755k = new java.util.HashSet();
        this.f1758n = new java.util.HashSet();
        this.f1767x = new io.flutter.embedding.engine.renderer.g();
        this.f1768y = new B.j(14, this);
        this.f1769z = new C.a(this, new android.os.Handler(android.os.Looper.getMainLooper()), 1);
        this.f1743A = new e0.p(this);
        this.f1744B = new e0.C0108g(1, this);
        this.f1748F = new e0.t();
        this.f1750f = lVar;
        this.f1753i = lVar;
        b();
    }

    /* JADX WARN: Type inference failed for: r0v38, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final void a() {
        android.util.SparseArray sparseArray;
        java.util.Objects.toString(this.f1757m);
        if (!c()) {
            return;
        }
        java.util.Iterator it = this.f1758n.iterator();
        if (it.hasNext()) {
            it.next().getClass();
            throw new java.lang.ClassCastException();
        }
        getContext().getContentResolver().unregisterContentObserver(this.f1769z);
        io.flutter.plugin.platform.k kVar = this.f1757m.s;
        int i2 = 0;
        while (true) {
            android.util.SparseArray sparseArray2 = kVar.f2481r;
            if (i2 >= sparseArray2.size()) {
                break;
            }
            kVar.f2470g.removeView((io.flutter.plugin.platform.g) sparseArray2.valueAt(i2));
            i2++;
        }
        int i3 = 0;
        while (true) {
            android.util.SparseArray sparseArray3 = kVar.f2479p;
            if (i3 >= sparseArray3.size()) {
                kVar.d();
                if (kVar.f2470g == null) {
                    android.util.Log.e("PlatformViewsController", "removeOverlaySurfaces called while flutter view is null");
                } else {
                    int i4 = 0;
                    while (true) {
                        sparseArray = kVar.f2480q;
                        if (i4 >= sparseArray.size()) {
                            break;
                        }
                        kVar.f2470g.removeView((android.view.View) sparseArray.valueAt(i4));
                        i4++;
                    }
                    sparseArray.clear();
                }
                kVar.f2470g = null;
                kVar.f2482t = false;
                android.util.SparseArray sparseArray4 = kVar.f2478o;
                if (sparseArray4.size() > 0) {
                    sparseArray4.valueAt(0).getClass();
                    throw new java.lang.ClassCastException();
                }
                io.flutter.plugin.platform.j jVar = this.f1757m.f1852t;
                int i5 = 0;
                while (true) {
                    android.util.SparseArray sparseArray5 = jVar.f2461l;
                    if (i5 >= sparseArray5.size()) {
                        android.view.Surface surface = jVar.f2464o;
                        if (surface != null) {
                            surface.release();
                            jVar.f2464o = null;
                            jVar.f2465p = null;
                        }
                        jVar.f2456g = null;
                        android.util.SparseArray sparseArray6 = jVar.f2460k;
                        if (sparseArray6.size() > 0) {
                            sparseArray6.valueAt(0).getClass();
                            throw new java.lang.ClassCastException();
                        }
                        this.f1757m.s.a();
                        this.f1757m.f1852t.a();
                        io.flutter.view.h hVar = this.f1764u;
                        hVar.f2606t = true;
                        hVar.f2592e.a();
                        hVar.f2605r = null;
                        android.view.accessibility.AccessibilityManager accessibilityManager = hVar.f2590c;
                        accessibilityManager.removeAccessibilityStateChangeListener(hVar.f2607u);
                        accessibilityManager.removeTouchExplorationStateChangeListener(hVar.f2608v);
                        hVar.f2593f.unregisterContentObserver(hVar.f2609w);
                        M.C0026b c0026b = hVar.f2589b;
                        c0026b.f524h = null;
                        ((io.flutter.embedding.engine.FlutterJNI) c0026b.f522f).setAccessibilityDelegate(null);
                        this.f1764u = null;
                        this.f1760p.f2427b.restartInput(this);
                        this.f1760p.b();
                        int size = ((java.util.HashSet) this.s.f522f).size();
                        if (size > 0) {
                            android.util.Log.w("KeyboardManager", "A KeyboardManager was destroyed with " + size + " unhandled redispatch event(s).");
                        }
                        io.flutter.plugin.editing.h hVar2 = this.f1761q;
                        if (hVar2 != null) {
                            hVar2.f2410a.f2711f = null;
                            android.view.textservice.SpellCheckerSession spellCheckerSession = hVar2.f2412c;
                            if (spellCheckerSession != null) {
                                spellCheckerSession.close();
                            }
                        }
                        M.Q q2 = this.f1759o;
                        if (q2 != null) {
                            ((n0.C0205c) q2.f518g).f2711f = null;
                        }
                        io.flutter.embedding.engine.renderer.h hVar3 = this.f1757m.f1835b;
                        this.f1756l = false;
                        hVar3.c(this.f1744B);
                        boolean z2 = this.f1749e;
                        io.flutter.embedding.engine.FlutterJNI flutterJNI = hVar3.f2375a;
                        if (z2) {
                            flutterJNI.removeResizingFlutterUiListener(this.f1743A);
                        }
                        hVar3.e();
                        flutterJNI.setSemanticsEnabled(false);
                        android.view.View view = this.f1754j;
                        if (view != null && this.f1753i == this.f1752h) {
                            this.f1753i = view;
                        }
                        this.f1753i.d();
                        e0.C0111j c0111j = this.f1752h;
                        if (c0111j != null) {
                            c0111j.f1720e.close();
                            removeView(this.f1752h);
                            this.f1752h = null;
                        }
                        this.f1754j = null;
                        this.f1757m = null;
                        return;
                    }
                    if (sparseArray5.valueAt(i5) != null) {
                        throw new java.lang.ClassCastException();
                    }
                    jVar.f2456g.removeView(null);
                    i5++;
                }
            } else {
                if (sparseArray3.valueAt(i3) != null) {
                    throw new java.lang.ClassCastException();
                }
                kVar.f2470g.removeView(null);
                i3++;
            }
        }
    }

    @Override // android.view.View
    public final void autofill(android.util.SparseArray sparseArray) {
        n0.C0217o c0217o;
        E.C0013n c0013n;
        E.C0013n c0013n2;
        io.flutter.plugin.editing.l lVar = this.f1760p;
        if (lVar == null || android.os.Build.VERSION.SDK_INT < 26 || (c0217o = lVar.f2431f) == null || lVar.f2432g == null || (c0013n = c0217o.f2772j) == null) {
            return;
        }
        java.util.HashMap map = new java.util.HashMap();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            n0.C0217o c0217o2 = (n0.C0217o) lVar.f2432g.get(sparseArray.keyAt(i2));
            if (c0217o2 != null && (c0013n2 = c0217o2.f2772j) != null) {
                java.lang.String string = e0.AbstractC0102a.f(sparseArray.valueAt(i2)).getTextValue().toString();
                n0.C0219q c0219q = new n0.C0219q(string, string.length(), string.length(), -1, -1);
                java.lang.String str = (java.lang.String) c0013n2.f246a;
                if (str.equals((java.lang.String) c0013n.f246a)) {
                    lVar.f2433h.f(c0219q);
                } else {
                    map.put(str, c0219q);
                }
            }
        }
        int i3 = lVar.f2430e.f581c;
        M.Q q2 = lVar.f2429d;
        q2.getClass();
        map.size();
        java.util.HashMap map2 = new java.util.HashMap();
        for (java.util.Map.Entry entry : map.entrySet()) {
            n0.C0219q c0219q2 = (n0.C0219q) entry.getValue();
            map2.put((java.lang.String) entry.getKey(), M.Q.p(c0219q2.f2779a, c0219q2.f2780b, c0219q2.f2781c, -1, -1));
        }
        ((M.C0026b) q2.f517f).D("TextInputClient.updateEditingStateWithTag", java.util.Arrays.asList(java.lang.Integer.valueOf(i3), map2), null);
    }

    public final void b() {
        e0.l lVar = this.f1750f;
        if (lVar != null) {
            addView(lVar);
        } else {
            e0.n nVar = this.f1751g;
            if (nVar != null) {
                addView(nVar);
            } else {
                addView(this.f1752h);
            }
        }
        this.f1749e = a.AbstractC0069a.s(getContext());
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            setImportantForAutofill(1);
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    public final boolean c() {
        f0.C0115c c0115c = this.f1757m;
        if (c0115c != null) {
            if (c0115c.f1835b == this.f1753i.getAttachedRenderer()) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean checkInputConnectionProxy(android.view.View view) {
        f0.C0115c c0115c = this.f1757m;
        if (c0115c == null) {
            return super.checkInputConnectionProxy(view);
        }
        io.flutter.plugin.platform.k kVar = c0115c.s;
        if (view == null) {
            kVar.getClass();
            return false;
        }
        java.util.HashMap map = kVar.f2477n;
        if (!map.containsKey(view.getContext())) {
            return false;
        }
        android.view.View view2 = (android.view.View) map.get(view.getContext());
        if (view2 == view) {
            return true;
        }
        return view2.checkInputConnectionProxy(view);
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d() {
        boolean z2;
        java.lang.String str;
        boolean z3;
        char c2 = (getResources().getConfiguration().uiMode & 48) == 32 ? (char) 2 : (char) 1;
        android.view.textservice.TextServicesManager textServicesManager = this.f1765v;
        if (textServicesManager == null) {
            z2 = false;
        } else {
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                java.util.Iterator it = textServicesManager.getEnabledSpellCheckerInfos().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        z3 = false;
                        break;
                    } else if (((android.view.textservice.SpellCheckerInfo) it.next()).getPackageName().equals("com.google.android.inputmethod.latin")) {
                        z3 = true;
                        break;
                    }
                }
                if (!this.f1765v.isSpellCheckerEnabled() || !z3) {
                }
            }
            z2 = true;
        }
        n0.C0216n c0216n = this.f1757m.f1848o;
        c0216n.getClass();
        java.util.HashMap map = new java.util.HashMap();
        map.put("textScaleFactor", java.lang.Float.valueOf(getResources().getConfiguration().fontScale));
        android.util.DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        map.put("nativeSpellCheckServiceDefined", java.lang.Boolean.valueOf(z2));
        map.put("brieflyShowPassword", java.lang.Boolean.valueOf(android.provider.Settings.System.getInt(getContext().getContentResolver(), "show_password", 1) == 1));
        map.put("alwaysUse24HourFormat", java.lang.Boolean.valueOf(android.text.format.DateFormat.is24HourFormat(getContext())));
        if (c2 == 1) {
            str = "light";
        } else {
            if (c2 != 2) {
                throw null;
            }
            str = "dark";
        }
        map.put("platformBrightness", str);
        java.util.Objects.toString(map.get("textScaleFactor"));
        java.util.Objects.toString(map.get("alwaysUse24HourFormat"));
        java.util.Objects.toString(map.get("platformBrightness"));
        boolean z4 = android.os.Build.VERSION.SDK_INT >= 34;
        E.C0013n c0013n = c0216n.f2762b;
        if (!z4 || displayMetrics == null) {
            c0013n.i(map, null);
            return;
        }
        n0.C0215m c0215m = new n0.C0215m(displayMetrics);
        M.C0026b c0026b = c0216n.f2761a;
        ((java.util.concurrent.ConcurrentLinkedQueue) c0026b.f523g).add(c0215m);
        n0.C0215m c0215m2 = (n0.C0215m) c0026b.f524h;
        c0026b.f524h = c0215m;
        M.Q q2 = c0215m2 != null ? new M.Q(c0026b, c0215m2, 18, false) : null;
        map.put("configurationId", java.lang.Integer.valueOf(c0215m.f2759a));
        c0013n.i(map, q2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(android.view.KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            getKeyDispatcherState().startTracking(keyEvent, this);
        } else if (keyEvent.getAction() == 1) {
            getKeyDispatcherState().handleUpEvent(keyEvent);
        }
        return (c() && this.s.B(keyEvent)) || super.dispatchKeyEvent(keyEvent);
    }

    public final void e() {
        if (!c()) {
            android.util.Log.w("FlutterView", "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine.");
            return;
        }
        float f2 = getResources().getDisplayMetrics().density;
        io.flutter.embedding.engine.renderer.g gVar = this.f1767x;
        gVar.f2350a = f2;
        gVar.f2368t = android.view.ViewConfiguration.get(getContext()).getScaledTouchSlop();
        io.flutter.embedding.engine.renderer.h hVar = this.f1757m.f1835b;
        hVar.getClass();
        int i2 = gVar.f2351b;
        if (i2 == 0) {
            int i3 = gVar.f2353d;
            int i4 = gVar.f2354e;
            if (i3 <= 0 && i4 <= 0) {
                return;
            }
        } else {
            int i5 = gVar.f2352c;
            if (i5 == 0) {
                int i6 = gVar.f2355f;
                int i7 = gVar.f2356g;
                if (i6 <= 0 && i7 <= 0) {
                    return;
                }
            } else if (i2 <= 0 || i5 <= 0 || gVar.f2350a <= 0.0f) {
                return;
            }
        }
        java.util.ArrayList arrayList = gVar.f2373y;
        arrayList.size();
        java.util.ArrayList arrayList2 = gVar.f2374z;
        arrayList2.size();
        int size = arrayList2.size() + arrayList.size();
        int[] iArr = new int[size * 4];
        int[] iArr2 = new int[size];
        int[] iArr3 = new int[size];
        for (int i8 = 0; i8 < arrayList.size(); i8++) {
            io.flutter.embedding.engine.renderer.a aVar = (io.flutter.embedding.engine.renderer.a) arrayList.get(i8);
            int i9 = i8 * 4;
            android.graphics.Rect rect = aVar.f2337a;
            iArr[i9] = rect.left;
            iArr[i9 + 1] = rect.top;
            iArr[i9 + 2] = rect.right;
            iArr[i9 + 3] = rect.bottom;
            iArr2[i8] = G.j.b(aVar.f2338b);
            iArr3[i8] = G.j.b(aVar.f2339c);
        }
        int size2 = arrayList.size() * 4;
        for (int i10 = 0; i10 < arrayList2.size(); i10++) {
            io.flutter.embedding.engine.renderer.a aVar2 = (io.flutter.embedding.engine.renderer.a) arrayList2.get(i10);
            int i11 = (i10 * 4) + size2;
            android.graphics.Rect rect2 = aVar2.f2337a;
            iArr[i11] = rect2.left;
            iArr[i11 + 1] = rect2.top;
            iArr[i11 + 2] = rect2.right;
            iArr[i11 + 3] = rect2.bottom;
            iArr2[arrayList.size() + i10] = G.j.b(aVar2.f2338b);
            iArr3[arrayList.size() + i10] = G.j.b(aVar2.f2339c);
        }
        hVar.f2375a.setViewportMetrics(gVar.f2350a, gVar.f2351b, gVar.f2352c, gVar.f2357h, gVar.f2358i, gVar.f2359j, gVar.f2360k, gVar.f2361l, gVar.f2362m, gVar.f2363n, gVar.f2364o, gVar.f2365p, gVar.f2366q, gVar.f2367r, gVar.s, gVar.f2368t, iArr, iArr2, iArr3, gVar.f2353d, gVar.f2354e, gVar.f2355f, gVar.f2356g, gVar.f2369u, gVar.f2370v, gVar.f2371w, gVar.f2372x);
    }

    @Override // android.view.View
    public android.view.accessibility.AccessibilityNodeProvider getAccessibilityNodeProvider() {
        io.flutter.view.h hVar = this.f1764u;
        if (hVar == null || !hVar.f2590c.isEnabled()) {
            return null;
        }
        return this.f1764u;
    }

    public f0.C0115c getAttachedFlutterEngine() {
        return this.f1757m;
    }

    public o0.f getBinaryMessenger() {
        return this.f1757m.f1836c;
    }

    public e0.C0111j getCurrentImageSurface() {
        return this.f1752h;
    }

    public io.flutter.embedding.engine.renderer.g getViewportMetrics() {
        return this.f1767x;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x013d  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0154  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0174  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final android.view.WindowInsets onApplyWindowInsets(android.view.WindowInsets windowInsets) {
        char c2;
        int i2;
        android.view.Window window;
        android.view.DisplayCutout displayCutout;
        android.view.WindowInsets windowInsetsOnApplyWindowInsets = super.onApplyWindowInsets(windowInsets);
        int i3 = android.os.Build.VERSION.SDK_INT;
        io.flutter.embedding.engine.renderer.g gVar = this.f1767x;
        if (i3 == 29) {
            android.graphics.Insets systemGestureInsets = windowInsets.getSystemGestureInsets();
            gVar.f2365p = systemGestureInsets.top;
            gVar.f2366q = systemGestureInsets.right;
            gVar.f2367r = systemGestureInsets.bottom;
            gVar.s = systemGestureInsets.left;
        }
        boolean z2 = (getWindowSystemUiVisibility() & 4) == 0;
        boolean z3 = (getWindowSystemUiVisibility() & 2) == 0;
        if (i3 >= 30) {
            android.graphics.Insets insets = windowInsets.getInsets(android.view.WindowInsets.Type.systemBars());
            gVar.f2357h = insets.top;
            gVar.f2358i = insets.right;
            gVar.f2359j = insets.bottom;
            gVar.f2360k = insets.left;
            android.graphics.Insets insets2 = windowInsets.getInsets(android.view.WindowInsets.Type.ime());
            gVar.f2361l = insets2.top;
            gVar.f2362m = insets2.right;
            gVar.f2363n = insets2.bottom;
            gVar.f2364o = insets2.left;
            android.graphics.Insets insets3 = windowInsets.getInsets(android.view.WindowInsets.Type.systemGestures());
            gVar.f2365p = insets3.top;
            gVar.f2366q = insets3.right;
            gVar.f2367r = insets3.bottom;
            gVar.s = insets3.left;
            android.view.DisplayCutout displayCutout2 = windowInsets.getDisplayCutout();
            if (displayCutout2 != null) {
                android.graphics.Insets waterfallInsets = displayCutout2.getWaterfallInsets();
                gVar.f2357h = java.lang.Math.max(java.lang.Math.max(gVar.f2357h, waterfallInsets.top), displayCutout2.getSafeInsetTop());
                gVar.f2358i = java.lang.Math.max(java.lang.Math.max(gVar.f2358i, waterfallInsets.right), displayCutout2.getSafeInsetRight());
                gVar.f2359j = java.lang.Math.max(java.lang.Math.max(gVar.f2359j, waterfallInsets.bottom), displayCutout2.getSafeInsetBottom());
                gVar.f2360k = java.lang.Math.max(java.lang.Math.max(gVar.f2360k, waterfallInsets.left), displayCutout2.getSafeInsetLeft());
            }
            i2 = 0;
        } else if (!z3) {
            android.content.Context context = getContext();
            if (context.getResources().getConfiguration().orientation != 2) {
                c2 = 1;
                gVar.f2357h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
                gVar.f2358i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
                if (!z3) {
                    int systemWindowInsetBottom = ((((double) windowInsets.getSystemWindowInsetBottom()) > (((double) getRootView().getHeight()) * 0.18d) ? 1 : (((double) windowInsets.getSystemWindowInsetBottom()) == (((double) getRootView().getHeight()) * 0.18d) ? 0 : -1)) < 0 ? 0 : windowInsets.getSystemWindowInsetBottom()) == 0 ? windowInsets.getSystemWindowInsetBottom() : 0;
                    gVar.f2359j = systemWindowInsetBottom;
                    gVar.f2360k = (c2 == 2 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetLeft();
                    gVar.f2361l = 0;
                    gVar.f2362m = 0;
                    gVar.f2363n = ((double) windowInsets.getSystemWindowInsetBottom()) < ((double) getRootView().getHeight()) * 0.18d ? 0 : windowInsets.getSystemWindowInsetBottom();
                    i2 = 0;
                    gVar.f2364o = 0;
                }
            } else {
                int rotation = ((android.hardware.display.DisplayManager) context.getSystemService("display")).getDisplay(0).getRotation();
                if (rotation == 1) {
                    c2 = 3;
                } else if (rotation == 3) {
                    c2 = 2;
                } else if (rotation == 0 || rotation == 2) {
                    c2 = 4;
                }
                gVar.f2357h = !z2 ? windowInsets.getSystemWindowInsetTop() : 0;
                if (c2 != 3) {
                    gVar.f2358i = (c2 != 3 || c2 == 4) ? 0 : windowInsets.getSystemWindowInsetRight();
                    if (!z3) {
                    }
                }
            }
        }
        java.util.ArrayList arrayList = new java.util.ArrayList();
        if (i3 >= 28 && (displayCutout = windowInsets.getDisplayCutout()) != null) {
            for (android.graphics.Rect rect : displayCutout.getBoundingRects()) {
                rect.toString();
                arrayList.add(new io.flutter.embedding.engine.renderer.a(rect, 4, 1));
            }
        }
        java.util.ArrayList arrayList2 = gVar.f2374z;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            e0.t tVar = this.f1748F;
            android.content.Context context2 = getContext();
            tVar.getClass();
            android.app.Activity activityN = p.g.n(context2);
            android.view.WindowInsets rootWindowInsets = null;
            if (activityN != null && (window = activityN.getWindow()) != null) {
                rootWindowInsets = window.getDecorView().getRootWindowInsets();
            }
            java.util.List listEmptyList = rootWindowInsets == null ? java.util.Collections.emptyList() : rootWindowInsets.getBoundingRects(android.view.WindowInsets.Type.captionBar());
            int iMax = gVar.f2357h;
            java.util.Iterator it = listEmptyList.iterator();
            while (it.hasNext()) {
                iMax = java.lang.Math.max(iMax, ((android.graphics.Rect) it.next()).bottom);
            }
            gVar.f2357h = iMax;
        }
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            android.view.RoundedCorner roundedCorner = windowInsets.getRoundedCorner(0);
            android.view.RoundedCorner roundedCorner2 = windowInsets.getRoundedCorner(1);
            android.view.RoundedCorner roundedCorner3 = windowInsets.getRoundedCorner(2);
            android.view.RoundedCorner roundedCorner4 = windowInsets.getRoundedCorner(3);
            gVar.f2369u = roundedCorner != null ? roundedCorner.getRadius() : i2;
            gVar.f2370v = roundedCorner2 != null ? roundedCorner2.getRadius() : i2;
            gVar.f2371w = roundedCorner3 != null ? roundedCorner3.getRadius() : i2;
            gVar.f2372x = roundedCorner4 != null ? roundedCorner4.getRadius() : i2;
        }
        e();
        return windowInsetsOnApplyWindowInsets;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v8, types: [Q0.d] */
    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        B.j jVar;
        x0.j jVar2 = x0.j.f3087e;
        super.onAttachedToWindow();
        try {
            V.g gVar = V.h.f1017c;
            android.content.Context context = getContext();
            gVar.getClass();
            jVar = new B.j(15, new M.Q(V.g.a(context)));
        } catch (java.lang.NoClassDefFoundError unused) {
            jVar = null;
        }
        this.f1766w = jVar;
        android.app.Activity activityN = p.g.n(getContext());
        B.j jVar3 = this.f1766w;
        if (jVar3 == null || activityN == null) {
            return;
        }
        this.f1745C = new V.i(1, this);
        android.content.Context context2 = getContext();
        java.util.concurrent.Executor executorA = android.os.Build.VERSION.SDK_INT >= 28 ? o.b.a(context2) : new t.ExecutorC0233a(new android.os.Handler(context2.getMainLooper()));
        V.i iVar = this.f1745C;
        M.Q q2 = (M.Q) jVar3.f32f;
        G0.i.e(executorA, "executor");
        G0.i.e(iVar, "consumer");
        V.b bVar = (V.b) q2.f517f;
        bVar.getClass();
        Q0.c cVar = new Q0.c(new V.j(bVar, activityN, null), jVar2, -2, 1);
        U0.d dVar = N0.B.f619a;
        O0.c cVar2 = S0.p.f934a;
        if (cVar2.f(N0.C0061t.f690f) != null) {
            throw new java.lang.IllegalArgumentException(("Flow context cannot contain job in it. Had " + cVar2).toString());
        }
        Q0.c cVarA = cVar;
        if (!cVar2.equals(jVar2)) {
            cVarA = R0.l.a(cVar, cVar2, 0, 0, 6);
        }
        M.Q q3 = (M.Q) q2.f518g;
        q3.getClass();
        G0.i.e(cVarA, "flow");
        java.util.concurrent.locks.ReentrantLock reentrantLock = (java.util.concurrent.locks.ReentrantLock) q3.f517f;
        reentrantLock.lock();
        java.util.LinkedHashMap linkedHashMap = (java.util.LinkedHashMap) q3.f518g;
        try {
            if (linkedHashMap.get(iVar) == null) {
                x0.i j2 = new N0.J(executorA);
                if (j2.f(N0.C0061t.f690f) == null) {
                    j2 = j2.g(new N0.T(null));
                }
                T.a aVar = new T.a(cVarA, iVar, null);
                x0.i iVarA = N0.AbstractC0063v.a(j2, jVar2, true);
                U0.d dVar2 = N0.B.f619a;
                if (iVarA != dVar2 && iVarA.f(x0.e.f3086e) == null) {
                    iVarA = iVarA.g(dVar2);
                }
                N0.AbstractC0043a e0Var = new N0.e0(iVarA, true);
                e0Var.W(1, e0Var, aVar);
                linkedHashMap.put(iVar, e0Var);
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // android.view.View
    public final void onConfigurationChanged(android.content.res.Configuration configuration) throws java.lang.Exception {
        super.onConfigurationChanged(configuration);
        if (this.f1757m != null) {
            this.f1762r.b(configuration);
            d();
            p.g.b(getContext(), this.f1757m);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:73:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00b1  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo editorInfo) {
        int i2;
        int i3;
        int i4;
        if (!c()) {
            return super.onCreateInputConnection(editorInfo);
        }
        io.flutter.plugin.editing.l lVar = this.f1760p;
        M.C0026b c0026b = this.s;
        M.C0038n c0038n = lVar.f2430e;
        int i5 = c0038n.f580b;
        if (i5 == 1) {
            lVar.f2435j = null;
            return null;
        }
        int i6 = 4;
        if (i5 == 4) {
            return null;
        }
        if (i5 == 3) {
            if (lVar.f2441p) {
                return lVar.f2435j;
            }
            lVar.f2436k.e(c0038n.f581c);
            throw null;
        }
        n0.C0217o c0217o = lVar.f2431f;
        n0.C0218p c0218p = c0217o.f2769g;
        int i7 = c0218p.f2776a;
        if (i7 != 2) {
            if (i7 == 5) {
                int i8 = c0218p.f2777b ? 4098 : 2;
                if (c0218p.f2778c) {
                    i2 = i8 | 8192;
                    i6 = i2;
                } else {
                    i6 = i8;
                }
            } else if (i7 == 6) {
                i6 = 3;
            } else if (i7 == 11) {
                i6 = 0;
            } else {
                i2 = i7 == 7 ? 131073 : (i7 == 8 || i7 == 13) ? 33 : (i7 == 9 || i7 == 12) ? 17 : i7 == 10 ? 145 : i7 == 3 ? 97 : i7 == 4 ? 113 : 1;
                if (!c0217o.f2763a) {
                    if (c0217o.f2764b) {
                        i2 |= 32768;
                    }
                    i4 = c0217o.f2765c ? 524416 : 524432;
                    i3 = c0217o.f2768f;
                    if (i3 != 1) {
                        i2 |= 4096;
                    } else if (i3 == 2) {
                        i2 |= 8192;
                    } else if (i3 == 3) {
                        i2 |= 16384;
                    }
                    i6 = i2;
                }
                i2 |= i4;
                i3 = c0217o.f2768f;
                if (i3 != 1) {
                }
                i6 = i2;
            }
        }
        editorInfo.inputType = i6;
        editorInfo.imeOptions = 33554432;
        int i9 = android.os.Build.VERSION.SDK_INT;
        if (i9 >= 26 && !c0217o.f2766d) {
            editorInfo.imeOptions = 50331648;
        }
        int iIntValue = c0217o.f2770h.intValue();
        n0.C0217o c0217o2 = lVar.f2431f;
        java.lang.String str = c0217o2.f2771i;
        if (str != null) {
            editorInfo.actionLabel = str;
            editorInfo.actionId = iIntValue;
        }
        editorInfo.imeOptions = iIntValue | editorInfo.imeOptions;
        if (c0217o2.f2775m != null) {
            editorInfo.hintLocales = new android.os.LocaleList(lVar.f2431f.f2775m);
        }
        java.lang.String[] strArr = lVar.f2431f.f2773k;
        if (strArr != null) {
            editorInfo.contentMimeTypes = strArr;
        }
        if (i9 >= 34) {
            if (editorInfo.extras == null) {
                editorInfo.extras = new android.os.Bundle();
            }
            editorInfo.extras.putBoolean("androidx.core.view.inputmethod.EditorInfoCompat.STYLUS_HANDWRITING_ENABLED", true);
        }
        io.flutter.plugin.editing.c cVar = new io.flutter.plugin.editing.c(this, lVar.f2430e.f581c, lVar.f2429d, c0026b, lVar.f2433h, editorInfo);
        io.flutter.plugin.editing.f fVar = lVar.f2433h;
        fVar.getClass();
        editorInfo.initialSelStart = android.text.Selection.getSelectionStart(fVar);
        io.flutter.plugin.editing.f fVar2 = lVar.f2433h;
        fVar2.getClass();
        editorInfo.initialSelEnd = android.text.Selection.getSelectionEnd(fVar2);
        lVar.f2435j = cVar;
        return cVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        V.i iVar;
        B.j jVar = this.f1766w;
        if (jVar != null && (iVar = this.f1745C) != null) {
            M.Q q2 = (M.Q) ((M.Q) jVar.f32f).f518g;
            q2.getClass();
            java.util.concurrent.locks.ReentrantLock reentrantLock = (java.util.concurrent.locks.ReentrantLock) q2.f517f;
            reentrantLock.lock();
            java.util.LinkedHashMap linkedHashMap = (java.util.LinkedHashMap) q2.f518g;
            try {
                N0.P p2 = (N0.P) linkedHashMap.get(iVar);
                if (p2 != null) {
                    p2.a(null);
                }
            } finally {
                reentrantLock.unlock();
            }
        }
        this.f1745C = null;
        this.f1766w = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(android.view.MotionEvent motionEvent) {
        if (c()) {
            e0.C0103b c0103b = this.f1763t;
            android.content.Context context = getContext();
            c0103b.getClass();
            boolean zIsFromSource = motionEvent.isFromSource(2);
            boolean z2 = motionEvent.getActionMasked() == 7 || motionEvent.getActionMasked() == 8;
            if (zIsFromSource && z2) {
                int iB = e0.C0103b.b(motionEvent.getActionMasked());
                java.nio.ByteBuffer byteBufferAllocateDirect = java.nio.ByteBuffer.allocateDirect(motionEvent.getPointerCount() * 288);
                byteBufferAllocateDirect.order(java.nio.ByteOrder.LITTLE_ENDIAN);
                c0103b.a(motionEvent, motionEvent.getActionIndex(), iB, 0, e0.C0103b.f1691f, byteBufferAllocateDirect, context);
                if (byteBufferAllocateDirect.position() % 288 != 0) {
                    throw new java.lang.AssertionError("Packet position is not on field boundary.");
                }
                c0103b.f1692a.f2375a.dispatchPointerDataPacket(byteBufferAllocateDirect, byteBufferAllocateDirect.position());
                return true;
            }
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(android.view.MotionEvent motionEvent) {
        return !c() ? super.onHoverEvent(motionEvent) : this.f1764u.e(motionEvent, false);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        this.f1746D = android.view.View.MeasureSpec.getMode(i2);
        this.f1747E = android.view.View.MeasureSpec.getMode(i3);
        super.onMeasure(i2, i3);
    }

    @Override // android.view.View
    public final void onProvideAutofillVirtualStructure(android.view.ViewStructure viewStructure, int i2) {
        android.graphics.Rect rect;
        super.onProvideAutofillVirtualStructure(viewStructure, i2);
        io.flutter.plugin.editing.l lVar = this.f1760p;
        if (lVar == null || android.os.Build.VERSION.SDK_INT < 26 || lVar.f2432g == null) {
            return;
        }
        java.lang.String str = (java.lang.String) lVar.f2431f.f2772j.f246a;
        android.view.autofill.AutofillId autofillId = viewStructure.getAutofillId();
        for (int i3 = 0; i3 < lVar.f2432g.size(); i3++) {
            int iKeyAt = lVar.f2432g.keyAt(i3);
            E.C0013n c0013n = ((n0.C0217o) lVar.f2432g.valueAt(i3)).f2772j;
            if (c0013n != null) {
                viewStructure.addChildCount(1);
                android.view.ViewStructure viewStructureNewChild = viewStructure.newChild(i3);
                viewStructureNewChild.setAutofillId(autofillId, iKeyAt);
                java.lang.String[] strArr = (java.lang.String[]) c0013n.f247b;
                if (strArr.length > 0) {
                    viewStructureNewChild.setAutofillHints(strArr);
                }
                viewStructureNewChild.setAutofillType(1);
                viewStructureNewChild.setVisibility(0);
                java.lang.String str2 = (java.lang.String) c0013n.f249d;
                if (str2 != null) {
                    viewStructureNewChild.setHint(str2);
                }
                if (str.hashCode() != iKeyAt || (rect = lVar.f2438m) == null) {
                    viewStructureNewChild.setDimens(0, 0, 0, 0, 1, 1);
                    viewStructureNewChild.setAutofillValue(android.view.autofill.AutofillValue.forText(((n0.C0219q) c0013n.f248c).f2779a));
                } else {
                    viewStructureNewChild.setDimens(rect.left, rect.top, 0, 0, rect.width(), lVar.f2438m.height());
                    viewStructureNewChild.setAutofillValue(android.view.autofill.AutofillValue.forText(lVar.f2433h));
                }
            }
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        io.flutter.embedding.engine.renderer.g gVar = this.f1767x;
        gVar.f2351b = i2;
        gVar.f2352c = i3;
        boolean z2 = this.f1749e;
        if (z2 && this.f1747E == 0) {
            gVar.f2355f = 0;
            gVar.f2356g = 8192;
        } else {
            gVar.f2355f = i3;
            gVar.f2356g = i3;
        }
        if (z2 && this.f1746D == 0) {
            gVar.f2353d = 0;
            gVar.f2354e = 8192;
        } else {
            gVar.f2353d = i2;
            gVar.f2354e = i2;
        }
        e();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        java.nio.ByteBuffer byteBuffer;
        java.nio.ByteBuffer byteBuffer2;
        int i2;
        if (!c()) {
            return super.onTouchEvent(motionEvent);
        }
        requestUnbufferedDispatch(motionEvent);
        e0.C0103b c0103b = this.f1763t;
        android.graphics.Matrix matrix = e0.C0103b.f1691f;
        c0103b.getClass();
        int actionMasked = motionEvent.getActionMasked();
        int iB = e0.C0103b.b(motionEvent.getActionMasked());
        char c2 = 5;
        int i3 = 1;
        boolean z2 = actionMasked == 0 || actionMasked == 5;
        boolean z3 = !z2 && (actionMasked == 1 || actionMasked == 6);
        int toolType = motionEvent.getToolType(motionEvent.getActionIndex());
        if (toolType == 1) {
            c2 = 0;
        } else if (toolType == 2) {
            c2 = 2;
        } else if (toolType == 3) {
            c2 = 1;
        } else if (toolType == 4) {
            c2 = 3;
        }
        int i4 = (z3 && c2 == 0) ? 1 : 0;
        int pointerCount = motionEvent.getPointerCount();
        java.nio.ByteBuffer byteBufferAllocateDirect = java.nio.ByteBuffer.allocateDirect((pointerCount + i4) * 288);
        byteBufferAllocateDirect.order(java.nio.ByteOrder.LITTLE_ENDIAN);
        if (z2) {
            c0103b.a(motionEvent, motionEvent.getActionIndex(), iB, 0, matrix, byteBufferAllocateDirect, null);
            byteBuffer = byteBufferAllocateDirect;
        } else {
            java.nio.ByteBuffer byteBuffer3 = byteBufferAllocateDirect;
            if (z3) {
                int i5 = 0;
                while (i5 < pointerCount) {
                    if (i5 == motionEvent.getActionIndex() || motionEvent.getToolType(i5) != i3) {
                        byteBuffer2 = byteBuffer3;
                        i2 = pointerCount;
                    } else {
                        byteBuffer2 = byteBuffer3;
                        i2 = pointerCount;
                        c0103b.a(motionEvent, i5, 5, 1, matrix, byteBuffer2, null);
                    }
                    i5++;
                    pointerCount = i2;
                    byteBuffer3 = byteBuffer2;
                    i3 = 1;
                }
                byteBuffer = byteBuffer3;
                c0103b.a(motionEvent, motionEvent.getActionIndex(), iB, 0, matrix, byteBuffer, null);
                if (i4 != 0) {
                    c0103b.a(motionEvent, motionEvent.getActionIndex(), 2, 0, matrix, byteBuffer, null);
                }
            } else {
                byteBuffer = byteBuffer3;
                for (int i6 = 0; i6 < pointerCount; i6++) {
                    c0103b.a(motionEvent, i6, iB, (pointerCount << 8) | 2, matrix, byteBuffer, null);
                }
            }
        }
        if (byteBuffer.position() % 288 != 0) {
            throw new java.lang.AssertionError("Packet position is not on field boundary");
        }
        c0103b.f1692a.f2375a.dispatchPointerDataPacket(byteBuffer, byteBuffer.position());
        return true;
    }

    public void setDelegate(e0.t tVar) {
        this.f1748F = tVar;
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        android.view.View view = this.f1753i;
        if (view instanceof e0.l) {
            ((e0.l) view).setVisibility(i2);
        }
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Object, java.util.List] */
    public void setWindowInfoListenerDisplayFeatures(V.k kVar) {
        ?? r8 = kVar.f1024a;
        java.util.ArrayList arrayList = new java.util.ArrayList();
        for (V.c cVar : r8) {
            cVar.f1005a.c().toString();
            S.b bVar = cVar.f1005a;
            int iB = bVar.b();
            V.b bVar2 = V.b.f998h;
            int i2 = 2;
            int i3 = ((iB == 0 || bVar.a() == 0) ? V.b.f997g : bVar2) == bVar2 ? 3 : 2;
            V.b bVar3 = V.b.f999i;
            V.b bVar4 = cVar.f1007c;
            if (bVar4 != bVar3) {
                i2 = bVar4 == V.b.f1000j ? 3 : 1;
            }
            arrayList.add(new io.flutter.embedding.engine.renderer.a(bVar.c(), i3, i2));
        }
        java.util.ArrayList arrayList2 = this.f1767x.f2373y;
        arrayList2.clear();
        arrayList2.addAll(arrayList);
        e();
    }

    public r(e0.AbstractActivityC0107f abstractActivityC0107f, e0.n nVar) {
        super(abstractActivityC0107f, null);
        this.f1749e = false;
        this.f1755k = new java.util.HashSet();
        this.f1758n = new java.util.HashSet();
        this.f1767x = new io.flutter.embedding.engine.renderer.g();
        this.f1768y = new B.j(14, this);
        this.f1769z = new C.a(this, new android.os.Handler(android.os.Looper.getMainLooper()), 1);
        this.f1743A = new e0.p(this);
        this.f1744B = new e0.C0108g(1, this);
        this.f1748F = new e0.t();
        this.f1751g = nVar;
        this.f1753i = nVar;
        b();
    }
}
