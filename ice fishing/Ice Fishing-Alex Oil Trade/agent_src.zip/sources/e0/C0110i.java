package e0;

/* renamed from: e0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0110i {

    /* renamed from: a, reason: collision with root package name */
    public e0.AbstractActivityC0107f f1708a;

    /* renamed from: b, reason: collision with root package name */
    public f0.C0115c f1709b;

    /* renamed from: c, reason: collision with root package name */
    public e0.r f1710c;

    /* renamed from: d, reason: collision with root package name */
    public io.flutter.plugin.platform.e f1711d;

    /* renamed from: e, reason: collision with root package name */
    public s0.C0232a f1712e;

    /* renamed from: f, reason: collision with root package name */
    public e0.ViewTreeObserverOnPreDrawListenerC0109h f1713f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1714g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1715h;

    /* renamed from: j, reason: collision with root package name */
    public boolean f1717j;

    /* renamed from: k, reason: collision with root package name */
    public java.lang.Integer f1718k;

    /* renamed from: l, reason: collision with root package name */
    public final e0.C0108g f1719l = new e0.C0108g(0, this);

    /* renamed from: i, reason: collision with root package name */
    public boolean f1716i = false;

    public C0110i(e0.AbstractActivityC0107f abstractActivityC0107f) {
        this.f1708a = abstractActivityC0107f;
    }

    public final void a(f0.C0120h c0120h) {
        java.lang.String strB = this.f1708a.b();
        if (strB == null || strB.isEmpty()) {
            strB = ((j0.d) M.C0026b.C().f523g).f2646e.f2634b;
        }
        g0.C0137a c0137a = new g0.C0137a(strB, this.f1708a.e());
        java.lang.String strF = this.f1708a.f();
        if (strF == null) {
            e0.AbstractActivityC0107f abstractActivityC0107f = this.f1708a;
            abstractActivityC0107f.getClass();
            strF = d(abstractActivityC0107f.getIntent());
            if (strF == null) {
                strF = "/";
            }
        }
        c0120h.f1883b = c0137a;
        c0120h.f1884c = strF;
        c0120h.f1885d = (java.util.List) this.f1708a.getIntent().getSerializableExtra("dart_entrypoint_args");
    }

    public final void b() {
        if (this.f1708a.i()) {
            throw new java.lang.AssertionError("The internal FlutterEngine created by " + this.f1708a + " has been attached to by another activity. To persist a FlutterEngine beyond the ownership of this activity, explicitly create a FlutterEngine");
        }
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1708a;
        abstractActivityC0107f.getClass();
        android.util.Log.w("FlutterActivity", "FlutterActivity " + abstractActivityC0107f + " connection to the engine " + abstractActivityC0107f.f1701f.f1709b + " evicted by another attaching activity");
        e0.C0110i c0110i = abstractActivityC0107f.f1701f;
        if (c0110i != null) {
            c0110i.e();
            abstractActivityC0107f.f1701f.f();
        }
    }

    public final void c() {
        if (this.f1708a == null) {
            throw new java.lang.IllegalStateException("Cannot execute method on a destroyed FlutterActivityAndFragmentDelegate.");
        }
    }

    public final java.lang.String d(android.content.Intent intent) {
        boolean z2;
        android.net.Uri data;
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1708a;
        abstractActivityC0107f.getClass();
        try {
            android.os.Bundle bundleG = abstractActivityC0107f.g();
            z2 = (bundleG == null || !bundleG.containsKey("flutter_deeplinking_enabled")) ? true : bundleG.getBoolean("flutter_deeplinking_enabled");
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            z2 = false;
        }
        if (!z2 || (data = intent.getData()) == null) {
            return null;
        }
        return data.toString();
    }

    public final void e() {
        c();
        if (this.f1713f != null) {
            this.f1710c.getViewTreeObserver().removeOnPreDrawListener(this.f1713f);
            this.f1713f = null;
        }
        e0.r rVar = this.f1710c;
        if (rVar != null) {
            rVar.a();
            e0.r rVar2 = this.f1710c;
            rVar2.f1755k.remove(this.f1719l);
        }
    }

    public final void f() {
        if (this.f1717j) {
            c();
            this.f1708a.getClass();
            this.f1708a.getClass();
            e0.AbstractActivityC0107f abstractActivityC0107f = this.f1708a;
            abstractActivityC0107f.getClass();
            if (abstractActivityC0107f.isChangingConfigurations()) {
                K.b bVar = this.f1709b.f1837d;
                if (bVar.f()) {
                    u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#detachFromActivityForConfigChanges");
                    try {
                        bVar.f421a = true;
                        for (r0.C0231a c0231a : ((java.util.HashMap) bVar.f426f).values()) {
                            ((java.util.HashSet) c0231a.f2836f.f1859c).remove(c0231a);
                            c0231a.f2836f = null;
                        }
                        bVar.d();
                        android.os.Trace.endSection();
                    } finally {
                    }
                } else {
                    android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
                }
            } else {
                this.f1709b.f1837d.c();
            }
            io.flutter.plugin.platform.e eVar = this.f1711d;
            if (eVar != null) {
                eVar.f2449b.f518g = null;
                this.f1711d = null;
            }
            s0.C0232a c0232a = this.f1712e;
            if (c0232a != null) {
                c0232a.f2841c.f2711f = null;
                c0232a.f2839a = null;
                this.f1712e = null;
            }
            this.f1708a.getClass();
            f0.C0115c c0115c = this.f1709b;
            if (c0115c != null) {
                n0.C0206d c0206d = c0115c.f1840g;
                c0206d.a(1, c0206d.f2714c);
            }
            if (this.f1708a.i()) {
                f0.C0115c c0115c2 = this.f1709b;
                java.util.Iterator it = c0115c2.f1854v.iterator();
                while (it.hasNext()) {
                    ((f0.InterfaceC0114b) it.next()).b();
                }
                K.b bVar2 = c0115c2.f1837d;
                bVar2.e();
                java.util.HashMap map = (java.util.HashMap) bVar2.f422b;
                java.util.Iterator it2 = new java.util.HashSet(map.keySet()).iterator();
                while (it2.hasNext()) {
                    java.lang.Class cls = (java.lang.Class) it2.next();
                    l0.InterfaceC0193a interfaceC0193a = (l0.InterfaceC0193a) map.get(cls);
                    if (interfaceC0193a != null) {
                        u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#remove ".concat(cls.getSimpleName()));
                        try {
                            if (interfaceC0193a instanceof r0.C0231a) {
                                if (bVar2.f()) {
                                    r0.C0231a c0231a2 = (r0.C0231a) interfaceC0193a;
                                    ((java.util.HashSet) c0231a2.f2836f.f1859c).remove(c0231a2);
                                    c0231a2.f2836f = null;
                                }
                                ((java.util.HashMap) bVar2.f426f).remove(cls);
                            }
                            interfaceC0193a.g((M.Q) bVar2.f425e);
                            map.remove(cls);
                            android.os.Trace.endSection();
                        } finally {
                        }
                    }
                }
                map.clear();
                while (true) {
                    io.flutter.plugin.platform.k kVar = c0115c2.s;
                    android.util.SparseArray sparseArray = kVar.f2478o;
                    if (sparseArray.size() <= 0) {
                        break;
                    }
                    kVar.f2487y.v(sparseArray.keyAt(0));
                }
                while (true) {
                    io.flutter.plugin.platform.j jVar = c0115c2.f1852t;
                    android.util.SparseArray sparseArray2 = jVar.f2460k;
                    if (sparseArray2.size() <= 0) {
                        break;
                    }
                    jVar.f2467r.v(sparseArray2.keyAt(0));
                }
                c0115c2.f1836c.f2028e.setPlatformMessageHandler(null);
                io.flutter.embedding.engine.FlutterJNI flutterJNI = c0115c2.f1834a;
                flutterJNI.removeEngineLifecycleListener(c0115c2.f1856x);
                flutterJNI.setDeferredComponentManager(null);
                flutterJNI.detachFromNativeAndReleaseResources();
                M.C0026b.C().getClass();
                f0.C0115c.f1833z.remove(java.lang.Long.valueOf(c0115c2.f1855w));
                if (this.f1708a.d() != null) {
                    if (f0.C0122j.f1890c == null) {
                        f0.C0122j.f1890c = new f0.C0122j(1);
                    }
                    f0.C0122j c0122j = f0.C0122j.f1890c;
                    c0122j.f1891a.remove(this.f1708a.d());
                }
                this.f1709b = null;
            }
            this.f1717j = false;
        }
    }
}
