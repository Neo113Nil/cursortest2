package e0;

/* renamed from: e0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0104c {
    public static /* synthetic */ android.media.ImageReader.Builder c(int i2, int i3) {
        return new android.media.ImageReader.Builder(i2, i3);
    }

    public static /* synthetic */ void h() {
    }
}
