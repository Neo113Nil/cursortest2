package e0;

/* renamed from: e0.A, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0101A {
    void f(android.view.KeyEvent keyEvent, e0.y yVar);
}
