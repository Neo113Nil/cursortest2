package e0;

/* loaded from: classes.dex */
public final class C {

    /* renamed from: a, reason: collision with root package name */
    public final long f1672a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1673b;

    public C(long j2, long j3) {
        this.f1672a = j2;
        this.f1673b = j3;
    }
}
