package e0;

/* loaded from: classes.dex */
public final class l extends android.view.SurfaceView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: e, reason: collision with root package name */
    public boolean f1728e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1729f;

    /* renamed from: g, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1730g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f1731h;

    /* renamed from: i, reason: collision with root package name */
    public final e0.J f1732i;

    public l(e0.AbstractActivityC0107f abstractActivityC0107f, boolean z2) {
        super(abstractActivityC0107f, null);
        this.f1728e = false;
        this.f1729f = false;
        this.f1731h = false;
        e0.J j2 = new e0.J(new e0.k(this), this, this.f1730g);
        this.f1732i = j2;
        if (z2) {
            getHolder().setFormat(-2);
            setZOrderOnTop(true);
        }
        this.f1731h = a.AbstractC0069a.s(getContext());
        getHolder().addCallback(j2);
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1730g;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1730g = hVar;
        e0.I i2 = this.f1732i.f1690e;
        switch (i2.f1684a) {
            case 0:
                i2.f1685b.f1687b = hVar;
                break;
            default:
                e0.J j2 = i2.f1685b;
                io.flutter.embedding.engine.renderer.h hVar3 = j2.f1687b;
                if (hVar3 != null) {
                    hVar3.c(j2.f1689d);
                }
                j2.f1687b = hVar;
                break;
        }
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1730g == null) {
            android.util.Log.w("FlutterSurfaceView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        e0.I i2 = this.f1732i.f1690e;
        switch (i2.f1684a) {
            case 0:
                break;
            default:
                e0.J j2 = i2.f1685b;
                io.flutter.embedding.engine.renderer.h hVar = j2.f1687b;
                if (hVar != null) {
                    hVar.a(j2.f1689d);
                    break;
                }
                break;
        }
        if (this.f1728e) {
            e();
        }
        this.f1729f = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c() {
        if (this.f1730g == null) {
            android.util.Log.w("FlutterSurfaceView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1729f = true;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1730g == null) {
            android.util.Log.w("FlutterSurfaceView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1730g;
            if (hVar == null) {
                throw new java.lang.IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
        }
        e0.I i2 = this.f1732i.f1690e;
        switch (i2.f1684a) {
            case 0:
                i2.f1685b.f1687b = null;
                break;
            default:
                e0.J j2 = i2.f1685b;
                j2.f1686a.setAlpha(0.0f);
                io.flutter.embedding.engine.renderer.h hVar2 = j2.f1687b;
                if (hVar2 != null) {
                    hVar2.c(j2.f1689d);
                }
                j2.f1687b = null;
                break;
        }
        this.f1730g = null;
    }

    public final void e() {
        if (this.f1730g == null || getHolder() == null) {
            throw new java.lang.IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getHolder() are non-null.");
        }
        io.flutter.embedding.engine.renderer.h hVar = this.f1730g;
        android.view.Surface surface = getHolder().getSurface();
        boolean z2 = this.f1729f;
        if (!z2) {
            hVar.e();
        }
        hVar.f2376b = surface;
        io.flutter.embedding.engine.FlutterJNI flutterJNI = hVar.f2375a;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface);
        } else {
            flutterJNI.onSurfaceCreated(surface);
        }
    }

    @Override // android.view.SurfaceView, android.view.View
    public final boolean gatherTransparentRegion(android.graphics.Region region) {
        if (getAlpha() < 1.0f) {
            return false;
        }
        int[] iArr = new int[2];
        getLocationInWindow(iArr);
        int i2 = iArr[0];
        region.op(i2, iArr[1], (getRight() + i2) - getLeft(), (getBottom() + iArr[1]) - getTop(), android.graphics.Region.Op.DIFFERENCE);
        return true;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1730g;
    }

    @Override // android.view.SurfaceView, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1731h) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = android.view.View.MeasureSpec.getMode(i2);
        setMeasuredDimension(java.lang.Math.max(android.view.View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), java.lang.Math.max(android.view.View.MeasureSpec.getSize(i3), android.view.View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }
}
