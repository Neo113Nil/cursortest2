package e0;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public final android.view.KeyEvent f1789a;

    /* renamed from: b, reason: collision with root package name */
    public int f1790b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1791c = false;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ M.C0026b f1792d;

    public z(M.C0026b c0026b, android.view.KeyEvent keyEvent) {
        this.f1792d = c0026b;
        this.f1790b = ((e0.InterfaceC0101A[]) c0026b.f523g).length;
        this.f1789a = keyEvent;
    }
}
