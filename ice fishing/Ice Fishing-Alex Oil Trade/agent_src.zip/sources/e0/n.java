package e0;

/* loaded from: classes.dex */
public final class n extends android.view.TextureView implements io.flutter.embedding.engine.renderer.k {

    /* renamed from: e, reason: collision with root package name */
    public boolean f1734e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1735f;

    /* renamed from: g, reason: collision with root package name */
    public io.flutter.embedding.engine.renderer.h f1736g;

    /* renamed from: h, reason: collision with root package name */
    public android.view.Surface f1737h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f1738i;

    public n(e0.AbstractActivityC0107f abstractActivityC0107f) {
        super(abstractActivityC0107f, null);
        this.f1734e = false;
        this.f1735f = false;
        this.f1738i = false;
        setSurfaceTextureListener(new e0.m(this));
        this.f1738i = a.AbstractC0069a.s(getContext());
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void a(io.flutter.embedding.engine.renderer.h hVar) {
        io.flutter.embedding.engine.renderer.h hVar2 = this.f1736g;
        if (hVar2 != null) {
            hVar2.e();
        }
        this.f1736g = hVar;
        b();
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void b() {
        if (this.f1736g == null) {
            android.util.Log.w("FlutterTextureView", "resume() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (this.f1734e) {
            e();
        }
        this.f1735f = false;
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void c() {
        if (this.f1736g == null) {
            android.util.Log.w("FlutterTextureView", "pause() invoked when no FlutterRenderer was attached.");
        } else {
            this.f1735f = true;
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public final void d() {
        if (this.f1736g == null) {
            android.util.Log.w("FlutterTextureView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
            return;
        }
        if (getWindowToken() != null) {
            io.flutter.embedding.engine.renderer.h hVar = this.f1736g;
            if (hVar == null) {
                throw new java.lang.IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
            }
            hVar.e();
            android.view.Surface surface = this.f1737h;
            if (surface != null) {
                surface.release();
                this.f1737h = null;
            }
        }
        this.f1736g = null;
    }

    public final void e() {
        if (this.f1736g == null || getSurfaceTexture() == null) {
            throw new java.lang.IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getSurfaceTexture() are non-null.");
        }
        android.view.Surface surface = this.f1737h;
        if (surface != null) {
            surface.release();
            this.f1737h = null;
        }
        android.view.Surface surface2 = new android.view.Surface(getSurfaceTexture());
        this.f1737h = surface2;
        io.flutter.embedding.engine.renderer.h hVar = this.f1736g;
        boolean z2 = this.f1735f;
        if (!z2) {
            hVar.e();
        }
        hVar.f2376b = surface2;
        io.flutter.embedding.engine.FlutterJNI flutterJNI = hVar.f2375a;
        if (z2) {
            flutterJNI.onSurfaceWindowChanged(surface2);
        } else {
            flutterJNI.onSurfaceCreated(surface2);
        }
    }

    @Override // io.flutter.embedding.engine.renderer.k
    public io.flutter.embedding.engine.renderer.h getAttachedRenderer() {
        return this.f1736g;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (!this.f1738i) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = android.view.View.MeasureSpec.getMode(i2);
        setMeasuredDimension(java.lang.Math.max(android.view.View.MeasureSpec.getSize(i2), mode == 0 ? 1 : 0), java.lang.Math.max(android.view.View.MeasureSpec.getSize(i3), android.view.View.MeasureSpec.getMode(i3) == 0 ? 1 : 0));
    }

    public void setRenderSurface(android.view.Surface surface) {
        this.f1737h = surface;
    }
}
