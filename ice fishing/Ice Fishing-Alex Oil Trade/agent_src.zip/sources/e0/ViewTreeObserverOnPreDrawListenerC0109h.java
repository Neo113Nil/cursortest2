package e0;

/* renamed from: e0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class ViewTreeObserverOnPreDrawListenerC0109h implements android.view.ViewTreeObserver.OnPreDrawListener {

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ e0.r f1706e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ e0.C0110i f1707f;

    public ViewTreeObserverOnPreDrawListenerC0109h(e0.C0110i c0110i, e0.r rVar) {
        this.f1707f = c0110i;
        this.f1706e = rVar;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        e0.C0110i c0110i = this.f1707f;
        if (c0110i.f1715h && c0110i.f1713f != null) {
            this.f1706e.getViewTreeObserver().removeOnPreDrawListener(this);
            c0110i.f1713f = null;
        }
        return c0110i.f1715h;
    }
}
