package e0;

/* renamed from: e0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0107f extends android.app.Activity implements androidx.lifecycle.i {

    /* renamed from: i, reason: collision with root package name */
    public static final int f1699i = android.view.View.generateViewId();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1700e = false;

    /* renamed from: f, reason: collision with root package name */
    public e0.C0110i f1701f;

    /* renamed from: g, reason: collision with root package name */
    public final androidx.lifecycle.j f1702g;

    /* renamed from: h, reason: collision with root package name */
    public final android.window.OnBackInvokedCallback f1703h;

    public AbstractActivityC0107f() {
        int i2 = android.os.Build.VERSION.SDK_INT;
        this.f1703h = i2 < 33 ? null : i2 >= 34 ? new e0.C0106e(this) : new android.window.OnBackInvokedCallback() { // from class: e0.d
            public final void onBackInvoked() {
                this.f1697a.onBackPressed();
            }
        };
        this.f1702g = new androidx.lifecycle.j(this);
    }

    @Override // androidx.lifecycle.i
    public final androidx.lifecycle.j a() {
        return this.f1702g;
    }

    public final java.lang.String b() {
        java.lang.String dataString;
        if ((getApplicationInfo().flags & 2) == 0 || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public final int c() {
        if (!getIntent().hasExtra("background_mode")) {
            return 1;
        }
        java.lang.String stringExtra = getIntent().getStringExtra("background_mode");
        if (stringExtra == null) {
            throw new java.lang.NullPointerException("Name is null");
        }
        if (stringExtra.equals("opaque")) {
            return 1;
        }
        if (stringExtra.equals("transparent")) {
            return 2;
        }
        throw new java.lang.IllegalArgumentException("No enum constant io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode.".concat(stringExtra));
    }

    public final java.lang.String d() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public final java.lang.String e() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            android.os.Bundle bundleG = g();
            java.lang.String string = bundleG != null ? bundleG.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public final java.lang.String f() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            android.os.Bundle bundleG = g();
            if (bundleG != null) {
                return bundleG.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public final android.os.Bundle g() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public final void h(boolean z2) {
        if (z2 && !this.f1700e) {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f1703h);
                this.f1700e = true;
                return;
            }
            return;
        }
        if (z2 || !this.f1700e || android.os.Build.VERSION.SDK_INT < 33) {
            return;
        }
        getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1703h);
        this.f1700e = false;
    }

    public final boolean i() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (d() != null || this.f1701f.f1714g) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public final boolean j() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : d() == null;
    }

    public final boolean k(java.lang.String str) {
        e0.C0110i c0110i = this.f1701f;
        if (c0110i == null) {
            android.util.Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after release.");
            return false;
        }
        if (c0110i.f1717j) {
            return true;
        }
        android.util.Log.w("FlutterActivity", "FlutterActivity " + hashCode() + " " + str + " called after detach.");
        return false;
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, android.content.Intent intent) {
        if (k("onActivityResult")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            if (c0110i.f1709b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            java.util.Objects.toString(intent);
            K.b bVar = c0110i.f1709b.f1837d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
                return;
            }
            u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                ((f0.C0116d) bVar.f428h).d(i2, i3, intent);
                android.os.Trace.endSection();
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (k("onBackPressed")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                c0115c.f1842i.f2708a.D("popRoute", null, null);
            } else {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:204:0x04c9  */
    /* JADX WARN: Removed duplicated region for block: B:211:0x0574  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x057f  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x05d1 A[LOOP:1: B:218:0x05c9->B:220:0x05d1, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:224:0x05e8  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x05df A[EDGE_INSN: B:290:0x05df->B:221:0x05df BREAK  A[LOOP:1: B:218:0x05c9->B:220:0x05d1], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:292:0x05fc A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r6v14, types: [android.view.View, io.flutter.embedding.engine.renderer.k] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(android.os.Bundle bundle) throws java.lang.IllegalAccessException, java.lang.IllegalArgumentException, java.lang.reflect.InvocationTargetException {
        byte[] byteArray;
        io.flutter.plugin.platform.k kVar;
        int i2;
        android.util.SparseArray sparseArray;
        int i3;
        android.util.SparseArray sparseArray2;
        int i4;
        try {
            android.os.Bundle bundleG = g();
            if (bundleG != null && (i4 = bundleG.getInt("io.flutter.embedding.android.NormalTheme", -1)) != -1) {
                setTheme(i4);
            }
        } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
            android.util.Log.e("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
        super.onCreate(bundle);
        if (bundle != null) {
            h(bundle.getBoolean("enableOnBackInvokedCallbackState"));
        }
        e0.C0110i c0110i = new e0.C0110i(this);
        this.f1701f = c0110i;
        c0110i.c();
        if (c0110i.f1709b == null) {
            java.lang.String strD = c0110i.f1708a.d();
            if (strD != null) {
                if (f0.C0122j.f1890c == null) {
                    f0.C0122j.f1890c = new f0.C0122j(1);
                }
                f0.C0115c c0115c = (f0.C0115c) f0.C0122j.f1890c.f1891a.get(strD);
                c0110i.f1709b = c0115c;
                c0110i.f1714g = true;
                if (c0115c == null) {
                    throw new java.lang.IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + strD + "'");
                }
            } else {
                c0110i.f1708a.getClass();
                c0110i.f1709b = null;
                java.lang.String stringExtra = c0110i.f1708a.getIntent().getStringExtra("cached_engine_group_id");
                if (stringExtra != null) {
                    if (f0.C0122j.f1889b == null) {
                        synchronized (f0.C0122j.class) {
                            try {
                                if (f0.C0122j.f1889b == null) {
                                    f0.C0122j.f1889b = new f0.C0122j(0);
                                }
                            } finally {
                            }
                        }
                    }
                    f0.C0121i c0121i = (f0.C0121i) f0.C0122j.f1889b.f1891a.get(stringExtra);
                    if (c0121i == null) {
                        throw new java.lang.IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + stringExtra + "'");
                    }
                    e0.AbstractActivityC0107f abstractActivityC0107f = c0110i.f1708a;
                    abstractActivityC0107f.getClass();
                    f0.C0120h c0120h = new f0.C0120h(abstractActivityC0107f);
                    c0110i.a(c0120h);
                    c0110i.f1709b = c0121i.a(c0120h);
                    c0110i.f1714g = false;
                } else {
                    e0.AbstractActivityC0107f abstractActivityC0107f2 = c0110i.f1708a;
                    abstractActivityC0107f2.getClass();
                    android.content.Intent intent = abstractActivityC0107f2.getIntent();
                    if (intent.getExtras() != null) {
                        for (java.lang.String str : intent.getExtras().keySet()) {
                            f0.C0117e c0117eA = f0.AbstractC0118f.a(str);
                            if (c0117eA == null) {
                                c0117eA = f0.AbstractC0118f.a("--".concat(str));
                            }
                            if (c0117eA == null) {
                                c0117eA = f0.AbstractC0118f.a("--" + str + "=");
                            }
                            if (c0117eA != null) {
                                break;
                            }
                        }
                    }
                    e0.AbstractActivityC0107f abstractActivityC0107f3 = c0110i.f1708a;
                    abstractActivityC0107f3.getClass();
                    android.content.Intent intent2 = c0110i.f1708a.getIntent();
                    java.util.ArrayList arrayList = new java.util.ArrayList();
                    if (intent2.getBooleanExtra("trace-startup", false)) {
                        arrayList.add("--trace-startup");
                    }
                    if (intent2.getBooleanExtra("start-paused", false)) {
                        arrayList.add("--start-paused");
                    }
                    int intExtra = intent2.getIntExtra("vm-service-port", 0);
                    if (intExtra > 0) {
                        arrayList.add("--vm-service-port=" + intExtra);
                    }
                    if (intent2.getBooleanExtra("disable-service-auth-codes", false)) {
                        arrayList.add("--disable-service-auth-codes");
                    }
                    if (intent2.getBooleanExtra("endless-trace-buffer", false)) {
                        arrayList.add("--endless-trace-buffer");
                    }
                    if (intent2.getBooleanExtra("use-test-fonts", false)) {
                        arrayList.add("--use-test-fonts");
                    }
                    if (intent2.getBooleanExtra("enable-dart-profiling", false)) {
                        arrayList.add("--enable-dart-profiling");
                    }
                    if (intent2.getBooleanExtra("profile-startup", false)) {
                        arrayList.add("--profile-startup");
                    }
                    if (intent2.getBooleanExtra("enable-software-rendering", false)) {
                        arrayList.add("--enable-software-rendering");
                    }
                    if (intent2.getBooleanExtra("skia-deterministic-rendering", false)) {
                        arrayList.add("--skia-deterministic-rendering");
                    }
                    if (intent2.getBooleanExtra("trace-skia", false)) {
                        arrayList.add("--trace-skia");
                    }
                    java.lang.String stringExtra2 = intent2.getStringExtra("trace-skia-allowlist");
                    if (stringExtra2 != null) {
                        arrayList.add("--trace-skia-allowlist=".concat(stringExtra2));
                    }
                    if (intent2.getBooleanExtra("trace-systrace", false)) {
                        arrayList.add("--trace-systrace");
                    }
                    if (intent2.hasExtra("trace-to-file")) {
                        arrayList.add("--trace-to-file=" + intent2.getStringExtra("trace-to-file"));
                    }
                    if (intent2.hasExtra("profile-microtasks")) {
                        arrayList.add("--profile-microtasks");
                    }
                    if (intent2.hasExtra("enable-impeller")) {
                        if (intent2.getBooleanExtra("enable-impeller", false)) {
                            arrayList.add("--enable-impeller=true");
                        } else {
                            arrayList.add("--enable-impeller=false");
                        }
                    }
                    if (intent2.getBooleanExtra("enable-vulkan-validation", false)) {
                        arrayList.add("--enable-vulkan-validation");
                    }
                    if (intent2.hasExtra("enable-hcpp-and-surface-control")) {
                        if (intent2.getBooleanExtra("enable-hcpp-and-surface-control", false)) {
                            arrayList.add("--enable-hcpp-and-surface-control=true");
                        } else {
                            arrayList.add("--enable-hcpp-and-surface-control=false");
                        }
                    }
                    if (intent2.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
                        arrayList.add("--dump-skp-on-shader-compilation");
                    }
                    if (intent2.getBooleanExtra("cache-sksl", false)) {
                        arrayList.add("--cache-sksl");
                    }
                    if (intent2.getBooleanExtra("purge-persistent-cache", false)) {
                        arrayList.add("--purge-persistent-cache");
                    }
                    if (intent2.getBooleanExtra("verbose-logging", false)) {
                        arrayList.add("--verbose-logging");
                    }
                    if (intent2.hasExtra("dart-flags")) {
                        arrayList.add("--dart-flags=" + intent2.getStringExtra("dart-flags"));
                    }
                    java.util.HashSet hashSet = new java.util.HashSet(arrayList);
                    f0.C0121i c0121i2 = new f0.C0121i(abstractActivityC0107f3, (java.lang.String[]) hashSet.toArray(new java.lang.String[hashSet.size()]));
                    e0.AbstractActivityC0107f abstractActivityC0107f4 = c0110i.f1708a;
                    abstractActivityC0107f4.getClass();
                    f0.C0120h c0120h2 = new f0.C0120h(abstractActivityC0107f4);
                    c0120h2.f1886e = false;
                    c0120h2.f1887f = c0110i.f1708a.j();
                    c0110i.a(c0120h2);
                    c0110i.f1709b = c0121i2.a(c0120h2);
                    c0110i.f1714g = false;
                }
            }
        }
        c0110i.f1708a.getClass();
        K.b bVar = c0110i.f1709b.f1837d;
        androidx.lifecycle.j jVar = c0110i.f1708a.f1702g;
        bVar.getClass();
        u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            e0.C0110i c0110i2 = (e0.C0110i) bVar.f427g;
            if (c0110i2 != null) {
                c0110i2.b();
            }
            bVar.e();
            bVar.f427g = c0110i;
            e0.AbstractActivityC0107f abstractActivityC0107f5 = c0110i.f1708a;
            abstractActivityC0107f5.getClass();
            bVar.b(abstractActivityC0107f5, jVar);
            android.os.Trace.endSection();
            e0.AbstractActivityC0107f abstractActivityC0107f6 = c0110i.f1708a;
            abstractActivityC0107f6.getClass();
            e0.AbstractActivityC0107f abstractActivityC0107f7 = c0110i.f1708a;
            f0.C0115c c0115c2 = c0110i.f1709b;
            abstractActivityC0107f7.getClass();
            c0110i.f1711d = new io.flutter.plugin.platform.e(abstractActivityC0107f7, c0115c2.f1845l, abstractActivityC0107f7);
            e0.AbstractActivityC0107f abstractActivityC0107f8 = c0110i.f1708a;
            f0.C0115c c0115c3 = c0110i.f1709b;
            abstractActivityC0107f8.getClass();
            c0110i.f1712e = new s0.C0232a(f1699i, abstractActivityC0107f6, c0115c3.f1847n);
            e0.AbstractActivityC0107f abstractActivityC0107f9 = c0110i.f1708a;
            f0.C0115c c0115c4 = c0110i.f1709b;
            com.battletank.stormwar.MainActivity mainActivity = (com.battletank.stormwar.MainActivity) abstractActivityC0107f9;
            mainActivity.getClass();
            G0.i.e(c0115c4, "flutterEngine");
            if (!mainActivity.f1701f.f1714g) {
                a.AbstractC0069a.C(c0115c4);
            }
            new M.C0026b(c0115c4.f1836c.f2032i, "battletank.ember.plate", o0.o.f2794a, 8).J(new b0.b(mainActivity));
            c0110i.f1717j = true;
            e0.C0110i c0110i3 = this.f1701f;
            c0110i3.c();
            if (bundle != null) {
                bundle.getBundle("plugins");
                byteArray = bundle.getByteArray("framework");
            } else {
                byteArray = null;
            }
            if (c0110i3.f1708a.j()) {
                n0.C0214l c0214l = c0110i3.f1709b.f1844k;
                c0214l.f2756e = true;
                n0.C0213k c0213k = c0214l.f2755d;
                if (c0213k != null) {
                    c0213k.c(n0.C0214l.a(byteArray));
                    c0214l.f2755d = null;
                    c0214l.f2753b = byteArray;
                } else if (c0214l.f2757f) {
                    c0214l.f2754c.D("push", n0.C0214l.a(byteArray), new n0.C0213k(0, c0214l, byteArray));
                } else {
                    c0214l.f2753b = byteArray;
                }
            }
            c0110i3.f1708a.getClass();
            K.b bVar2 = c0110i3.f1709b.f1837d;
            if (bVar2.f()) {
                u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onRestoreInstanceState");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((f0.C0116d) bVar2.f428h).f1862f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
            }
            this.f1702g.a(androidx.lifecycle.d.ON_CREATE);
            if (c() == 2) {
                getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            }
            e0.C0110i c0110i4 = this.f1701f;
            boolean z2 = (c() == 1 ? (char) 1 : (char) 2) == 1;
            c0110i4.c();
            if (c0110i4.f1708a.c() == 1) {
                e0.AbstractActivityC0107f abstractActivityC0107f10 = c0110i4.f1708a;
                abstractActivityC0107f10.getClass();
                e0.l lVar = new e0.l(abstractActivityC0107f10, c0110i4.f1708a.c() != 1);
                c0110i4.f1708a.getClass();
                e0.AbstractActivityC0107f abstractActivityC0107f11 = c0110i4.f1708a;
                abstractActivityC0107f11.getClass();
                c0110i4.f1710c = new e0.r(abstractActivityC0107f11, lVar);
            } else {
                e0.AbstractActivityC0107f abstractActivityC0107f12 = c0110i4.f1708a;
                abstractActivityC0107f12.getClass();
                e0.n nVar = new e0.n(abstractActivityC0107f12);
                nVar.setOpaque(c0110i4.f1708a.c() == 1);
                c0110i4.f1708a.getClass();
                e0.AbstractActivityC0107f abstractActivityC0107f13 = c0110i4.f1708a;
                abstractActivityC0107f13.getClass();
                c0110i4.f1710c = new e0.r(abstractActivityC0107f13, nVar);
            }
            c0110i4.f1710c.f1755k.add(c0110i4.f1719l);
            c0110i4.f1708a.getClass();
            e0.r rVar = c0110i4.f1710c;
            f0.C0115c c0115c5 = c0110i4.f1709b;
            rVar.getClass();
            java.util.Objects.toString(c0115c5);
            if (!rVar.c()) {
                rVar.f1757m = c0115c5;
                io.flutter.embedding.engine.renderer.h hVar = c0115c5.f1835b;
                rVar.f1756l = hVar.f2377c;
                rVar.f1753i.a(hVar);
                e0.C0108g c0108g = rVar.f1744B;
                hVar.a(c0108g);
                if (rVar.f1749e) {
                    hVar.f2375a.addResizingFlutterUiListener(rVar.f1743A);
                }
                rVar.f1759o = new M.Q(rVar, rVar.f1757m.f1841h);
                f0.C0115c c0115c6 = rVar.f1757m;
                rVar.f1760p = new io.flutter.plugin.editing.l(rVar, c0115c6.f1851r, c0115c6.f1846m, c0115c6.s, c0115c6.f1852t);
                try {
                    android.view.textservice.TextServicesManager textServicesManager = (android.view.textservice.TextServicesManager) rVar.getContext().getSystemService("textservices");
                    rVar.f1765v = textServicesManager;
                    rVar.f1761q = new io.flutter.plugin.editing.h(textServicesManager, rVar.f1757m.f1849p);
                } catch (java.lang.Exception unused2) {
                    android.util.Log.e("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
                }
                new M.Q(rVar, rVar.f1760p.f2427b, rVar.f1757m.f1846m);
                rVar.f1762r = rVar.f1757m.f1838e;
                rVar.s = new M.C0026b(rVar);
                rVar.f1763t = new e0.C0103b(rVar.f1757m.f1835b, false);
                io.flutter.view.h hVar2 = new io.flutter.view.h(rVar, c0115c5.f1839f, (android.view.accessibility.AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), c0115c5.f1853u);
                rVar.f1764u = hVar2;
                hVar2.f2605r = rVar.f1768y;
                boolean zIsEnabled = hVar2.f2590c.isEnabled();
                boolean zIsTouchExplorationEnabled = rVar.f1764u.f2590c.isTouchExplorationEnabled();
                if (rVar.f1757m.f1835b.f2375a.getIsSoftwareRenderingEnabled()) {
                    rVar.setWillNotDraw((zIsEnabled || zIsTouchExplorationEnabled) ? false : true);
                } else {
                    rVar.setWillNotDraw(false);
                }
                f0.C0115c c0115c7 = rVar.f1757m;
                c0115c7.s.f2475l.f2442a = rVar.f1764u;
                new e0.C0103b(c0115c7.f1835b, true);
                f0.C0115c c0115c8 = rVar.f1757m;
                c0115c8.f1852t.f2459j.f2442a = rVar.f1764u;
                new e0.C0103b(c0115c8.f1835b, true);
                rVar.f1760p.f2427b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(android.provider.Settings.System.getUriFor("show_password"), false, rVar.f1769z);
                rVar.e();
                kVar = c0115c5.s;
                kVar.f2470g = rVar;
                i2 = 0;
                while (true) {
                    sparseArray = kVar.f2481r;
                    if (i2 < sparseArray.size()) {
                        break;
                    }
                    kVar.f2470g.addView((io.flutter.plugin.platform.g) sparseArray.valueAt(i2));
                    i2++;
                }
                i3 = 0;
                while (true) {
                    sparseArray2 = kVar.f2479p;
                    if (i3 < sparseArray2.size()) {
                        android.util.SparseArray sparseArray3 = kVar.f2478o;
                        if (sparseArray3.size() > 0) {
                            sparseArray3.valueAt(0).getClass();
                            throw new java.lang.ClassCastException();
                        }
                        io.flutter.plugin.platform.j jVar2 = c0115c5.f1852t;
                        jVar2.f2456g = rVar;
                        int i5 = 0;
                        while (true) {
                            android.util.SparseArray sparseArray4 = jVar2.f2461l;
                            if (i5 >= sparseArray4.size()) {
                                android.util.SparseArray sparseArray5 = jVar2.f2460k;
                                if (sparseArray5.size() > 0) {
                                    sparseArray5.valueAt(0).getClass();
                                    throw new java.lang.ClassCastException();
                                }
                                java.util.Iterator it2 = rVar.f1758n.iterator();
                                if (it2.hasNext()) {
                                    it2.next().getClass();
                                    throw new java.lang.ClassCastException();
                                }
                                if (rVar.f1756l) {
                                    c0108g.a();
                                }
                            } else {
                                if (sparseArray4.valueAt(i5) != null) {
                                    throw new java.lang.ClassCastException();
                                }
                                jVar2.f2456g.addView(null);
                                i5++;
                            }
                        }
                    } else {
                        if (sparseArray2.valueAt(i3) != null) {
                            throw new java.lang.ClassCastException();
                        }
                        kVar.f2470g.addView(null);
                        i3++;
                    }
                }
            } else if (c0115c5 != rVar.f1757m) {
                rVar.a();
                rVar.f1757m = c0115c5;
                io.flutter.embedding.engine.renderer.h hVar3 = c0115c5.f1835b;
                rVar.f1756l = hVar3.f2377c;
                rVar.f1753i.a(hVar3);
                e0.C0108g c0108g2 = rVar.f1744B;
                hVar3.a(c0108g2);
                if (rVar.f1749e) {
                }
                rVar.f1759o = new M.Q(rVar, rVar.f1757m.f1841h);
                f0.C0115c c0115c62 = rVar.f1757m;
                rVar.f1760p = new io.flutter.plugin.editing.l(rVar, c0115c62.f1851r, c0115c62.f1846m, c0115c62.s, c0115c62.f1852t);
                android.view.textservice.TextServicesManager textServicesManager2 = (android.view.textservice.TextServicesManager) rVar.getContext().getSystemService("textservices");
                rVar.f1765v = textServicesManager2;
                rVar.f1761q = new io.flutter.plugin.editing.h(textServicesManager2, rVar.f1757m.f1849p);
                new M.Q(rVar, rVar.f1760p.f2427b, rVar.f1757m.f1846m);
                rVar.f1762r = rVar.f1757m.f1838e;
                rVar.s = new M.C0026b(rVar);
                rVar.f1763t = new e0.C0103b(rVar.f1757m.f1835b, false);
                io.flutter.view.h hVar22 = new io.flutter.view.h(rVar, c0115c5.f1839f, (android.view.accessibility.AccessibilityManager) rVar.getContext().getSystemService("accessibility"), rVar.getContext().getContentResolver(), c0115c5.f1853u);
                rVar.f1764u = hVar22;
                hVar22.f2605r = rVar.f1768y;
                boolean zIsEnabled2 = hVar22.f2590c.isEnabled();
                boolean zIsTouchExplorationEnabled2 = rVar.f1764u.f2590c.isTouchExplorationEnabled();
                if (rVar.f1757m.f1835b.f2375a.getIsSoftwareRenderingEnabled()) {
                }
                f0.C0115c c0115c72 = rVar.f1757m;
                c0115c72.s.f2475l.f2442a = rVar.f1764u;
                new e0.C0103b(c0115c72.f1835b, true);
                f0.C0115c c0115c82 = rVar.f1757m;
                c0115c82.f1852t.f2459j.f2442a = rVar.f1764u;
                new e0.C0103b(c0115c82.f1835b, true);
                rVar.f1760p.f2427b.restartInput(rVar);
                rVar.d();
                rVar.getContext().getContentResolver().registerContentObserver(android.provider.Settings.System.getUriFor("show_password"), false, rVar.f1769z);
                rVar.e();
                kVar = c0115c5.s;
                kVar.f2470g = rVar;
                i2 = 0;
                while (true) {
                    sparseArray = kVar.f2481r;
                    if (i2 < sparseArray.size()) {
                    }
                    kVar.f2470g.addView((io.flutter.plugin.platform.g) sparseArray.valueAt(i2));
                    i2++;
                }
                i3 = 0;
                while (true) {
                    sparseArray2 = kVar.f2479p;
                    if (i3 < sparseArray2.size()) {
                    }
                    kVar.f2470g.addView(null);
                    i3++;
                }
            }
            c0110i4.f1710c.setId(f1699i);
            if (z2) {
                e0.r rVar2 = c0110i4.f1710c;
                if (c0110i4.f1708a.c() != 1) {
                    throw new java.lang.IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
                }
                if (c0110i4.f1713f != null) {
                    rVar2.getViewTreeObserver().removeOnPreDrawListener(c0110i4.f1713f);
                }
                c0110i4.f1713f = new e0.ViewTreeObserverOnPreDrawListenerC0109h(c0110i4, rVar2);
                rVar2.getViewTreeObserver().addOnPreDrawListener(c0110i4.f1713f);
            }
            setContentView(c0110i4.f1710c);
            android.view.Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            if (android.os.Build.VERSION.SDK_INT < 35) {
                window.setStatusBarColor(1073741824);
            }
            window.getDecorView().setSystemUiVisibility(1280);
        } catch (java.lang.Throwable th3) {
            try {
                android.os.Trace.endSection();
            } catch (java.lang.Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (k("onDestroy")) {
            this.f1701f.e();
            this.f1701f.f();
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f1703h);
            this.f1700e = false;
        }
        e0.C0110i c0110i = this.f1701f;
        if (c0110i != null) {
            c0110i.f1708a = null;
            c0110i.f1709b = null;
            c0110i.f1710c = null;
            c0110i.f1711d = null;
            c0110i.f1712e = null;
            this.f1701f = null;
        }
        this.f1702g.a(androidx.lifecycle.d.ON_DESTROY);
    }

    @Override // android.app.Activity
    public final void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        if (k("onNewIntent")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            K.b bVar = c0115c.f1837d;
            if (bVar.f()) {
                u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onNewIntent");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((f0.C0116d) bVar.f428h).f1860d).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
            }
            java.lang.String strD = c0110i.d(intent);
            if (strD == null || strD.isEmpty()) {
                return;
            }
            n0.C0203a c0203a = c0110i.f1709b.f1842i;
            c0203a.getClass();
            java.util.HashMap map = new java.util.HashMap();
            map.put("location", strD);
            c0203a.f2708a.D("pushRouteInformation", map, null);
        }
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        if (k("onPause")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            c0110i.f1708a.getClass();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                n0.C0206d c0206d = c0115c.f1840g;
                c0206d.a(3, c0206d.f2714c);
            }
        }
        this.f1702g.a(androidx.lifecycle.d.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        if (k("onPostResume")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            if (c0110i.f1709b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            io.flutter.plugin.platform.e eVar = c0110i.f1711d;
            if (eVar != null) {
                eVar.b();
            }
            java.util.Iterator it = c0110i.f1709b.s.f2476m.values().iterator();
            if (it.hasNext()) {
                ((io.flutter.plugin.platform.q) it.next()).getClass();
                throw null;
            }
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, java.lang.String[] strArr, int[] iArr) {
        if (k("onRequestPermissionsResult")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            if (c0110i.f1709b == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            java.util.Arrays.toString(strArr);
            java.util.Arrays.toString(iArr);
            K.b bVar = c0110i.f1709b.f1837d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
                return;
            }
            u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                java.util.Iterator it = ((java.util.HashSet) ((f0.C0116d) bVar.f428h).f1858b).iterator();
                if (!it.hasNext()) {
                    android.os.Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new java.lang.ClassCastException();
                    }
                    throw null;
                }
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f1702g.a(androidx.lifecycle.d.ON_RESUME);
        if (k("onResume")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            c0110i.f1709b.f1835b.d();
            c0110i.f1708a.getClass();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                n0.C0206d c0206d = c0115c.f1840g;
                c0206d.a(2, c0206d.f2714c);
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(android.os.Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (k("onSaveInstanceState")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            if (c0110i.f1708a.j()) {
                bundle.putByteArray("framework", c0110i.f1709b.f1844k.f2753b);
            }
            c0110i.f1708a.getClass();
            android.os.Bundle bundle2 = new android.os.Bundle();
            K.b bVar = c0110i.f1709b.f1837d;
            if (bVar.f()) {
                u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onSaveInstanceState");
                try {
                    java.util.Iterator it = ((java.util.HashSet) ((f0.C0116d) bVar.f428h).f1862f).iterator();
                    if (it.hasNext()) {
                        if (it.next() != null) {
                            throw new java.lang.ClassCastException();
                        }
                        throw null;
                    }
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th) {
                    try {
                        android.os.Trace.endSection();
                    } catch (java.lang.Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
            }
            bundle.putBundle("plugins", bundle2);
            if (c0110i.f1708a.d() == null || c0110i.f1708a.i()) {
                return;
            }
            bundle.putBoolean("enableOnBackInvokedCallbackState", c0110i.f1708a.f1700e);
        }
    }

    @Override // android.app.Activity
    public final void onStart() {
        android.os.Bundle bundleG;
        super.onStart();
        this.f1702g.a(androidx.lifecycle.d.ON_START);
        if (k("onStart")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            if (c0110i.f1708a.d() == null && !c0110i.f1709b.f1836c.f2033j) {
                java.lang.String strF = c0110i.f1708a.f();
                if (strF == null) {
                    e0.AbstractActivityC0107f abstractActivityC0107f = c0110i.f1708a;
                    abstractActivityC0107f.getClass();
                    strF = c0110i.d(abstractActivityC0107f.getIntent());
                    if (strF == null) {
                        strF = "/";
                    }
                }
                e0.AbstractActivityC0107f abstractActivityC0107f2 = c0110i.f1708a;
                abstractActivityC0107f2.getClass();
                try {
                    bundleG = abstractActivityC0107f2.g();
                } catch (android.content.pm.PackageManager.NameNotFoundException unused) {
                }
                java.lang.String string = bundleG != null ? bundleG.getString("io.flutter.EntrypointUri") : null;
                c0110i.f1708a.e();
                c0110i.f1709b.f1842i.f2708a.D("setInitialRoute", strF, null);
                java.lang.String strB = c0110i.f1708a.b();
                if (strB == null || strB.isEmpty()) {
                    strB = ((j0.d) M.C0026b.C().f523g).f2646e.f2634b;
                }
                c0110i.f1709b.f1836c.a(string == null ? new g0.C0137a(strB, c0110i.f1708a.e()) : new g0.C0137a(strB, string, c0110i.f1708a.e()), (java.util.List) c0110i.f1708a.getIntent().getSerializableExtra("dart_entrypoint_args"));
            }
            java.lang.Integer num = c0110i.f1718k;
            if (num != null) {
                c0110i.f1710c.setVisibility(num.intValue());
            }
        }
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        if (k("onStop")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            c0110i.f1708a.getClass();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                n0.C0206d c0206d = c0115c.f1840g;
                c0206d.a(5, c0206d.f2714c);
            }
            c0110i.f1718k = java.lang.Integer.valueOf(c0110i.f1710c.getVisibility());
            c0110i.f1710c.setVisibility(8);
            f0.C0115c c0115c2 = c0110i.f1709b;
            if (c0115c2 != null) {
                c0115c2.f1835b.b(40);
            }
        }
        this.f1702g.a(androidx.lifecycle.d.ON_STOP);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (k("onTrimMemory")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                if (c0110i.f1716i && i2 >= 10) {
                    io.flutter.embedding.engine.FlutterJNI flutterJNI = c0115c.f1836c.f2028e;
                    if (flutterJNI.isAttached()) {
                        flutterJNI.notifyLowMemoryWarning();
                    }
                    n0.C0204b c0204b = c0110i.f1709b.f1850q;
                    c0204b.getClass();
                    java.util.HashMap map = new java.util.HashMap(1);
                    map.put("type", "memoryPressure");
                    c0204b.f2709a.i(map, null);
                }
                c0110i.f1709b.f1835b.b(i2);
                io.flutter.plugin.platform.k kVar = c0110i.f1709b.s;
                if (i2 < 40) {
                    kVar.getClass();
                    return;
                }
                java.util.Iterator it = kVar.f2476m.values().iterator();
                if (it.hasNext()) {
                    ((io.flutter.plugin.platform.q) it.next()).getClass();
                    throw null;
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        if (k("onUserLeaveHint")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
                return;
            }
            K.b bVar = c0115c.f1837d;
            if (!bVar.f()) {
                android.util.Log.e("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
                return;
            }
            u0.AbstractC0248a.b("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                java.util.Iterator it = ((java.util.HashSet) ((f0.C0116d) bVar.f428h).f1861e).iterator();
                if (!it.hasNext()) {
                    android.os.Trace.endSection();
                } else {
                    if (it.next() != null) {
                        throw new java.lang.ClassCastException();
                    }
                    throw null;
                }
            } catch (java.lang.Throwable th) {
                try {
                    android.os.Trace.endSection();
                } catch (java.lang.Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (k("onWindowFocusChanged")) {
            e0.C0110i c0110i = this.f1701f;
            c0110i.c();
            c0110i.f1708a.getClass();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                n0.C0206d c0206d = c0115c.f1840g;
                if (z2) {
                    c0206d.a(c0206d.f2712a, true);
                } else {
                    c0206d.a(c0206d.f2712a, false);
                }
            }
        }
    }
}
