package e0;

/* renamed from: e0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0103b {

    /* renamed from: f, reason: collision with root package name */
    public static final android.graphics.Matrix f1691f = new android.graphics.Matrix();

    /* renamed from: a, reason: collision with root package name */
    public final io.flutter.embedding.engine.renderer.h f1692a;

    /* renamed from: b, reason: collision with root package name */
    public final M.Q f1693b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1694c;

    /* renamed from: d, reason: collision with root package name */
    public final java.util.HashMap f1695d = new java.util.HashMap();

    /* renamed from: e, reason: collision with root package name */
    public int f1696e;

    public C0103b(io.flutter.embedding.engine.renderer.h hVar, boolean z2) {
        this.f1692a = hVar;
        if (M.Q.f514h == null) {
            M.Q.f514h = new M.Q(8);
        }
        this.f1693b = M.Q.f514h;
        this.f1694c = z2;
    }

    public static int b(int i2) {
        if (i2 == 0) {
            return 4;
        }
        if (i2 == 1) {
            return 6;
        }
        if (i2 == 5) {
            return 4;
        }
        if (i2 == 6) {
            return 6;
        }
        if (i2 == 2) {
            return 5;
        }
        if (i2 == 7) {
            return 3;
        }
        if (i2 == 3) {
            return 0;
        }
        return i2 == 8 ? 3 : -1;
    }

    public final void a(android.view.MotionEvent motionEvent, int i2, int i3, int i4, android.graphics.Matrix matrix, java.nio.ByteBuffer byteBuffer, android.content.Context context) {
        int i5;
        long buttonState;
        int i6;
        int i7;
        long jIncrementAndGet;
        double min;
        double max;
        android.view.MotionEvent motionEvent2;
        int i8;
        double d2;
        double d3;
        double scaledVerticalScrollFactor;
        e0.C0103b c0103b;
        float fC;
        android.view.InputDevice.MotionRange motionRange;
        if (i3 == -1) {
            return;
        }
        int i9 = 3;
        int pointerId = (motionEvent.getPointerId(i2) << 3) | (motionEvent.getToolType(i2) & 7);
        int toolType = motionEvent.getToolType(i2);
        if (toolType == 1) {
            i9 = 0;
        } else if (toolType == 2) {
            i9 = 2;
        } else if (toolType == 3) {
            i9 = 1;
        } else if (toolType != 4) {
            i9 = 5;
        }
        float[] fArr = {motionEvent.getX(i2), motionEvent.getY(i2)};
        matrix.mapPoints(fArr);
        java.util.HashMap map = this.f1695d;
        if (i9 == 1) {
            buttonState = motionEvent.getButtonState() & 31;
            if (buttonState == 0 && motionEvent.getSource() == 8194) {
                i5 = 4;
                if (i3 == 4) {
                    map.put(java.lang.Integer.valueOf(pointerId), fArr);
                }
            } else {
                i5 = 4;
            }
        } else {
            i5 = 4;
            buttonState = i9 == 2 ? (motionEvent.getButtonState() >> 4) & 15 : 0L;
        }
        boolean zContainsKey = map.containsKey(java.lang.Integer.valueOf(pointerId));
        if (zContainsKey) {
            i6 = i3 == i5 ? 7 : i3 == 5 ? 8 : (i3 == 6 || i3 == 0) ? 9 : -1;
            if (i6 == -1) {
                return;
            }
        } else {
            i6 = -1;
        }
        if (this.f1694c) {
            M.Q q2 = this.f1693b;
            q2.getClass();
            i7 = pointerId;
            jIncrementAndGet = e0.G.f1680b.incrementAndGet();
            ((android.util.LongSparseArray) q2.f517f).put(jIncrementAndGet, android.view.MotionEvent.obtain(motionEvent));
            ((java.util.PriorityQueue) q2.f518g).add(java.lang.Long.valueOf(jIncrementAndGet));
        } else {
            i7 = pointerId;
            jIncrementAndGet = 0;
        }
        int i10 = motionEvent.getActionMasked() == 8 ? 1 : 0;
        long eventTime = motionEvent.getEventTime() * 1000;
        byteBuffer.putLong(jIncrementAndGet);
        byteBuffer.putLong(eventTime);
        if (zContainsKey) {
            byteBuffer.putLong(i6);
            byteBuffer.putLong(4L);
        } else {
            byteBuffer.putLong(i3);
            byteBuffer.putLong(i9);
        }
        byteBuffer.putLong(i10);
        int i11 = i7;
        byteBuffer.putLong(i11);
        byteBuffer.putLong(0L);
        if (zContainsKey) {
            float[] fArr2 = (float[]) map.get(java.lang.Integer.valueOf(i11));
            byteBuffer.putDouble(fArr2[0]);
            byteBuffer.putDouble(fArr2[1]);
        } else {
            byteBuffer.putDouble(fArr[0]);
            byteBuffer.putDouble(fArr[1]);
        }
        byteBuffer.putDouble(0.0d);
        byteBuffer.putDouble(0.0d);
        byteBuffer.putLong(buttonState);
        byteBuffer.putLong(0L);
        byteBuffer.putLong(0L);
        byteBuffer.putDouble(motionEvent.getPressure(i2));
        if (motionEvent.getDevice() == null || (motionRange = motionEvent.getDevice().getMotionRange(2)) == null) {
            min = 0.0d;
            max = 1.0d;
        } else {
            min = motionRange.getMin();
            max = motionRange.getMax();
        }
        byteBuffer.putDouble(min);
        byteBuffer.putDouble(max);
        if (i9 == 2) {
            motionEvent2 = motionEvent;
            i8 = i2;
            byteBuffer.putDouble(motionEvent2.getAxisValue(24, i8));
            byteBuffer.putDouble(0.0d);
        } else {
            motionEvent2 = motionEvent;
            i8 = i2;
            byteBuffer.putDouble(0.0d);
            byteBuffer.putDouble(0.0d);
        }
        byteBuffer.putDouble(motionEvent.getSize(i2));
        byteBuffer.putDouble(motionEvent.getToolMajor(i2));
        byteBuffer.putDouble(motionEvent.getToolMinor(i2));
        byteBuffer.putDouble(0.0d);
        byteBuffer.putDouble(0.0d);
        byteBuffer.putDouble(motionEvent2.getAxisValue(8, i8));
        if (i9 == 2) {
            byteBuffer.putDouble(motionEvent2.getAxisValue(25, i8));
        } else {
            byteBuffer.putDouble(0.0d);
        }
        byteBuffer.putLong(i4);
        if (i10 == 1) {
            if (context != null) {
                int i12 = android.os.Build.VERSION.SDK_INT;
                if (i12 >= 26) {
                    fC = android.view.ViewConfiguration.get(context).getScaledHorizontalScrollFactor();
                    c0103b = this;
                } else {
                    c0103b = this;
                    fC = c0103b.c(context);
                }
                d3 = fC;
                scaledVerticalScrollFactor = i12 >= 26 ? android.view.ViewConfiguration.get(context).getScaledVerticalScrollFactor() : c0103b.c(context);
            } else {
                d3 = 48.0d;
                scaledVerticalScrollFactor = 48.0d;
            }
            byteBuffer.putDouble(d3 * (-motionEvent2.getAxisValue(10, i8)));
            byteBuffer.putDouble(scaledVerticalScrollFactor * (-motionEvent2.getAxisValue(9, i8)));
        } else {
            byteBuffer.putDouble(0.0d);
            byteBuffer.putDouble(0.0d);
        }
        if (zContainsKey) {
            float[] fArr3 = (float[]) map.get(java.lang.Integer.valueOf(i11));
            byteBuffer.putDouble(fArr[0] - fArr3[0]);
            byteBuffer.putDouble(fArr[1] - fArr3[1]);
            d2 = 0.0d;
        } else {
            d2 = 0.0d;
            byteBuffer.putDouble(0.0d);
            byteBuffer.putDouble(0.0d);
        }
        byteBuffer.putDouble(d2);
        byteBuffer.putDouble(d2);
        byteBuffer.putDouble(1.0d);
        byteBuffer.putDouble(d2);
        byteBuffer.putLong(0L);
        if (zContainsKey && i6 == 9) {
            map.remove(java.lang.Integer.valueOf(i11));
        }
    }

    public final int c(android.content.Context context) {
        if (this.f1696e == 0) {
            android.util.TypedValue typedValue = new android.util.TypedValue();
            if (!context.getTheme().resolveAttribute(android.R.attr.listPreferredItemHeight, typedValue, true)) {
                return 48;
            }
            this.f1696e = (int) typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f1696e;
    }
}
