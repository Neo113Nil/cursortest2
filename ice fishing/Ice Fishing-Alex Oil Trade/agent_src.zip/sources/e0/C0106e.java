package e0;

/* renamed from: e0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0106e implements android.window.OnBackAnimationCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e0.AbstractActivityC0107f f1698a;

    public C0106e(e0.AbstractActivityC0107f abstractActivityC0107f) {
        this.f1698a = abstractActivityC0107f;
    }

    public final void onBackCancelled() {
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1698a;
        if (abstractActivityC0107f.k("cancelBackGesture")) {
            e0.C0110i c0110i = abstractActivityC0107f.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                c0115c.f1843j.f2708a.D("cancelBackGesture", null, null);
            } else {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked cancelBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackInvoked() {
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1698a;
        if (abstractActivityC0107f.k("commitBackGesture")) {
            e0.C0110i c0110i = abstractActivityC0107f.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c != null) {
                c0115c.f1843j.f2708a.D("commitBackGesture", null, null);
            } else {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked commitBackGesture() before FlutterFragment was attached to an Activity.");
            }
        }
    }

    public final void onBackProgressed(android.window.BackEvent backEvent) {
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1698a;
        if (abstractActivityC0107f.k("updateBackGestureProgress")) {
            e0.C0110i c0110i = abstractActivityC0107f.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked updateBackGestureProgress() before FlutterFragment was attached to an Activity.");
                return;
            }
            n0.C0203a c0203a = c0115c.f1843j;
            c0203a.getClass();
            c0203a.f2708a.D("updateBackGestureProgress", n0.C0203a.a(backEvent), null);
        }
    }

    public final void onBackStarted(android.window.BackEvent backEvent) {
        e0.AbstractActivityC0107f abstractActivityC0107f = this.f1698a;
        if (abstractActivityC0107f.k("startBackGesture")) {
            e0.C0110i c0110i = abstractActivityC0107f.f1701f;
            c0110i.c();
            f0.C0115c c0115c = c0110i.f1709b;
            if (c0115c == null) {
                android.util.Log.w("FlutterActivityAndFragmentDelegate", "Invoked startBackGesture() before FlutterFragment was attached to an Activity.");
                return;
            }
            n0.C0203a c0203a = c0115c.f1843j;
            c0203a.getClass();
            c0203a.f2708a.D("startBackGesture", n0.C0203a.a(backEvent), null);
        }
    }
}
