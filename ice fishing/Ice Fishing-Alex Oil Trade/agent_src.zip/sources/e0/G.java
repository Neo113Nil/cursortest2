package e0;

/* loaded from: classes.dex */
public final class G {

    /* renamed from: b, reason: collision with root package name */
    public static final java.util.concurrent.atomic.AtomicLong f1680b = new java.util.concurrent.atomic.AtomicLong(0);

    /* renamed from: a, reason: collision with root package name */
    public final long f1681a;

    public G(long j2) {
        this.f1681a = j2;
    }
}
