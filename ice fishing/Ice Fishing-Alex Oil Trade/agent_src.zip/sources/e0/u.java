package e0;

/* loaded from: classes.dex */
public final class u {

    /* renamed from: a, reason: collision with root package name */
    public long f1770a;

    /* renamed from: b, reason: collision with root package name */
    public int f1771b;

    /* renamed from: c, reason: collision with root package name */
    public long f1772c;

    /* renamed from: d, reason: collision with root package name */
    public long f1773d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1774e;

    /* renamed from: f, reason: collision with root package name */
    public int f1775f;

    /* renamed from: g, reason: collision with root package name */
    public java.lang.String f1776g;
}
