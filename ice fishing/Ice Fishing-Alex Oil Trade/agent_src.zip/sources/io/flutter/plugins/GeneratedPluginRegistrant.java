package io.flutter.plugins;

/* loaded from: classes.dex */
public final class GeneratedPluginRegistrant {
    private static final java.lang.String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(f0.C0115c c0115c) {
        try {
            c0115c.f1837d.a(new t0.J());
        } catch (java.lang.Exception e2) {
            android.util.Log.e(TAG, "Error registering plugin shared_preferences_android, io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin", e2);
        }
    }
}
